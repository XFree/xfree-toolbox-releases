#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
# Push current common.sh + apply.sh then debug one section
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB=/root/xfree-toolbox
scp "${SCP_OPTS[@]}" lib/common.sh "$SSH_TARGET:$TB/lib/common.sh"
scp "${SCP_OPTS[@]}" zapret/apply.sh zapret/lib.sh "$SSH_TARGET:$TB/zapret/"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
ROOT=/root/xfree-toolbox
. "$ROOT/lib/common.sh"
. "$ROOT/zapret/lib.sh"

src="$ROOT/profiles/default/zapret/sections/youtube_29/fqdn.d"
dst=/etc/xfree-toolbox/zapret/state/sections/youtube_29/fqdn.d
echo "PROFILE fqdn before anything:"
ls -la "$src"
echo "find src type f:"
find "$src" -mindepth 1 -maxdepth 1 -type f | sort
echo "--- run sync with set -x ---"
set -x
common_sync_dir_mirror "$src" "$dst"
set +x
echo "dst after:"
ls -la "$dst"
echo "profile after sync (must still have file):"
ls -la "$src"

# Now source build_merged_file from apply without running main
# Extract by running a mini script
sed -n '/^build_merged_file()/,/^}/p' "$ROOT/zapret/apply.sh" > /tmp/bmf.sh
# apply.sh has set -eu at top - just eval the function
build_merged_file() {
  src_dir="$1"
  dst_file="$2"
  kind="$3"
  disable_ipv6="${4:-0}"
  mkdir -p "$(dirname -- "$dst_file")"
  if [ ! -d "$src_dir" ]; then
    : > "$dst_file"
    return 0
  fi
  tmp_file="$(mktemp)"
  trap 'rm -f "$tmp_file"' EXIT INT TERM
  echo "DEBUG merge: src_dir=$src_dir glob:" >&2
  ls -la "$src_dir" >&2
  for f in "$src_dir"/*.lst; do
    echo "DEBUG consider $f exists=$( [ -f "$f" ] && echo y || echo n )" >&2
    [ -f "$f" ] || continue
    cat "$f" | common_norm_domains_stream >> "$tmp_file"
  done
  echo "DEBUG tmp lines=$(wc -l < "$tmp_file")" >&2
  if [ -s "$tmp_file" ]; then
    awk '!seen[$0]++' "$tmp_file" > "$dst_file"
  else
    : > "$dst_file"
  fi
  rm -f "$tmp_file"
  trap - EXIT INT TERM
}
out=/tmp/yt-merge-out.txt
build_merged_file "$dst" "$out" fqdn
echo "merged lines=$(wc -l < "$out")"
head -3 "$out"
REMOTE
