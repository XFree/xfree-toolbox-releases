#!/bin/sh
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
. ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" 'grep -n "createHandlerFn" /www/luci-static/resources/ui.js | head -20; awk "BEGIN{p=0} /createHandlerFn\\(ctx|createHandlerFn\\(context|prototype.createHandlerFn|createHandlerFn:/{p=1} p{print NR\":\"\$0; c++; if(c>40) exit}" /www/luci-static/resources/ui.js'
