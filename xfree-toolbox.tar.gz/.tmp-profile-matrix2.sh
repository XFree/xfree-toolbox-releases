#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"

ssh "${SSH_OPTS[@]}" "$SSH_TARGET" 'sh -s' <<'REMOTE'
set -eu
TB=/root/xfree-toolbox
export ROOT_DIR="$TB"

stage() {
  name="$1"; shift
  /usr/bin/time -f "$name real=%e" "$@" >/tmp/xfree-stage.out 2>/tmp/xfree-stage.err || true
  cat /tmp/xfree-stage.err
  wc -c /tmp/xfree-stage.out | awk '{print "  bytes="$1}'
}

echo "=== direct shell stages ==="
stage catalog sh -c '
  . "'"$TB"'/lib/common.sh"
  . "'"$TB"'/lib/upstreams.sh"
  . "'"$TB"'/lib/selection/upstream-selection.sh"
  selection_upstream_init_all "'"$TB"'"
  selection_catalog_prepare "'"$TB"'" >/dev/null
'

stage matrix_fn sh -c '
  . "'"$TB"'/lib/common.sh"
  . "'"$TB"'/lib/upstreams.sh"
  . "'"$TB"'/lib/selection/upstream-selection.sh"
  selection_upstream_init_all "'"$TB"'"
  selection_upstream_json_matrix >/tmp/xfree-matrix-direct.json
'

stage emit_only sh -c '
  . "'"$TB"'/lib/common.sh"
  . "'"$TB"'/lib/upstreams.sh"
  . "'"$TB"'/lib/selection/upstream-selection.sh"
  selection_upstream_init_all "'"$TB"'"
  _cat=$(selection_catalog_prepare "'"$TB"'")
  _cols=$(mktemp); _present=$(mktemp); _checked=$(mktemp)
  : > "$_cols"; : > "$_present"
  # minimal: reuse previous full matrix checked by calling resolve only after register
  selection_iface_list_scope_ids 2>/dev/null | while read id; do
    [ -n "$id" ] || continue
    selection_matrix_register_scope iface "$id" "$id" all "$_cols" "$_present"
  done
  if command -v dns_routing_list_instances_tsv >/dev/null 2>&1; then
    dns_routing_list_instances_tsv 2>/dev/null | while IFS="|" read idx id host rest; do
      [ -n "$id" ] || continue
      selection_matrix_register_scope dns "$id" "${host:-$id}" fqdn_only "$_cols" "$_present"
    done
  fi
  if [ -d "${SELECTION_ZAPRET_SECTIONS:-}" ]; then
    for d in "$SELECTION_ZAPRET_SECTIONS"/*; do
      [ -d "$d" ] || continue
      id=$(basename "$d")
      selection_matrix_register_scope zapret "$id" "$id" all "$_cols" "$_present"
    done
  fi
  selection_zapret_disable_flags 2>/dev/null || true
  selection_matrix_resolve_checked "$_cat/files.tsv" "$_cols" "$_present" "$_checked" \
    "${SELECTION_ZAPRET_DV4:-0}" "${SELECTION_ZAPRET_DV6:-0}"
  selection_json_emit_matrix "$_cat/entities.tsv" "$_cols" "$_checked" >/tmp/xfree-emit.json
  rm -f "$_cols" "$_present" "$_checked"
'

echo "=== ubus ==="
stage ubus1 ubus call xfree-toolbox upstreamSelection '{"action":"matrix","target":"-","scope":"-","mode":"-","tags_json":""}'
stage ubus2 ubus call xfree-toolbox upstreamSelection '{"action":"matrix","target":"-","scope":"-","mode":"-","tags_json":""}'

echo "=== get-model one scope for compare ==="
stage model_iface ubus call xfree-toolbox upstreamSelection '{"action":"get-model","target":"iface","scope":"warp","mode":"all","tags_json":""}'
stage model_zap ubus call xfree-toolbox upstreamSelection '{"action":"get-model","target":"zapret","scope":"youtube_1","mode":"all","tags_json":""}'

echo "=== rpcd script source cost ==="
stage source_only sh -c '
  . "'"$TB"'/lib/common.sh"
  . "'"$TB"'/lib/upstreams.sh"
  . "'"$TB"'/lib/selection/upstream-selection.sh"
  selection_upstream_init_all "'"$TB"'"
  echo ok
'
REMOTE
