#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE' || true
set +e
echo "=== origin of server=/protonvpn.com/8.8.8.8 ==="
uci show dhcp | grep -n proton
uci -q get dhcp.@dnsmasq[0].server
echo "=== uci changes / history hints ==="
ls -la /etc/config/dhcp /etc/config/dhcp-* 2>/dev/null | head
grep -n proton /etc/config/dhcp 2>/dev/null
echo "=== https-dns-proxy instances ==="
uci show https-dns-proxy 2>/dev/null | head -80
echo "=== curl with resolved IP (bypass DNS) ==="
curl -sI --connect-timeout 10 --max-time 15 --resolve account.protonvpn.com:443:185.159.159.143 https://account.protonvpn.com/ 2>&1 | head -20
echo "=== curl via @77.88 after temporary? just show dig via yandex path ==="
# query DoH proxy with socat/nc if available - skip
echo "=== dns cache flush test: query yandex common via https-dns using curl DoH ==="
curl -sG --connect-timeout 10 --max-time 15 \
  --data-urlencode 'name=account.protonvpn.com' \
  --data-urlencode 'type=A' \
  'https://common.dot.dns.yandex.net/dns-query' \
  -H 'accept: application/dns-json' 2>&1 | head -c 400; echo
curl -sG --connect-timeout 10 --max-time 15 \
  --data-urlencode 'name=account.protonvpn.com' \
  --data-urlencode 'type=A' \
  'https://dns.google/resolve' 2>&1 | head -c 400; echo
curl -sG --connect-timeout 10 --max-time 15 \
  --data-urlencode 'name=account.protonvpn.com' \
  --data-urlencode 'type=A' \
  'https://cloudflare-dns.com/dns-query' \
  -H 'accept: application/dns-json' 2>&1 | head -c 400; echo
echo "=== done3 ==="
REMOTE
