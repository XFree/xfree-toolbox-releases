#!/bin/sh
# shellcheck shell=sh
set -eu

# normalize-conf.sh: нормализация WireGuard / AmneziaWG .conf файлов
# - Детектирует формат (Amnezia / Keenetic / Proton / WireGuard)
# - Преобразует диапазоны чисел (напр. PersistentKeepalive 25-35) в валидные для OpenWrt integer
# - Сохраняет директивы Amnezia 2.0 (HeaderProtectionKey, ContentPaddingAddition, RekeyAfterTime и др.)
# - Генерирует или дополняет .conf.meta

SOURCE_FILE=""
DEST_FILE=""
WRITE_META=0
IN_PLACE=0
KIND_OVERRIDE=""

usage() {
    cat <<EOF2
Usage:
  $(basename "$0") [options] [SOURCE_FILE]

Options:
  --source <path>     Входной .conf файл
  --dest <path>       Выходной .conf файл (если не указан — вывод в stdout)
  --in-place          Нормализовать файл на месте
  --write-meta        Создать сопутствующий .conf.meta файл
  --kind <kind>       Принудительно задать GENERATOR_KIND (amnezia|custom|proton|warp)
  -h, --help          Справка
EOF2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --source)
            SOURCE_FILE="$2"
            shift 2
            ;;
        --dest)
            DEST_FILE="$2"
            shift 2
            ;;
        --in-place)
            IN_PLACE=1
            shift
            ;;
        --write-meta)
            WRITE_META=1
            shift
            ;;
        --kind)
            KIND_OVERRIDE="$2"
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        -*)
            echo "[-] Неизвестный параметр: $1" >&2
            usage >&2
            exit 1
            ;;
        *)
            if [ -z "$SOURCE_FILE" ]; then
                SOURCE_FILE="$1"
            else
                echo "[-] Лишний позиционный аргумент: $1" >&2
                exit 1
            fi
            shift
            ;;
    esac
done

if [ -z "$SOURCE_FILE" ] && [ -t 0 ]; then
    usage >&2
    exit 1
fi

TMP_INPUT=""
cleanup() {
    if [ -n "$TMP_INPUT" ] && [ -f "$TMP_INPUT" ]; then
        rm -f "$TMP_INPUT"
    fi
    return 0
}
trap cleanup EXIT INT TERM

if [ -z "$SOURCE_FILE" ] || [ "$SOURCE_FILE" = "-" ]; then
    TMP_INPUT="$(mktemp "${TMPDIR:-/tmp}/norm-input.XXXXXX")"
    cat > "$TMP_INPUT"
    SOURCE_FILE="$TMP_INPUT"
fi

[ -f "$SOURCE_FILE" ] || { echo "[-] Файл не найден: $SOURCE_FILE" >&2; exit 1; }

# Детектирование типа конфига
detect_kind() {
    file="$1"
    if [ -n "$KIND_OVERRIDE" ]; then
        printf '%s\n' "$KIND_OVERRIDE"
        return 0
    fi
    if grep -qEi '(# VPN Key: vpn://|# Keenetic:|HeaderProtectionKey|RekeyAfterTime|ContentPaddingAddition)' "$file" 2>/dev/null; then
        printf 'amnezia\n'
        return 0
    fi
    if grep -qEi '(# imported-from=proton|# XFREE_CONF_LIST_HINT=proton)' "$file" 2>/dev/null; then
        printf 'proton\n'
        return 0
    fi
    if grep -qEi 'warp' "$file" 2>/dev/null; then
        printf 'warp\n'
        return 0
    fi
    printf 'custom\n'
}

DETECTED_KIND="$(detect_kind "$SOURCE_FILE")"

TMP_OUTPUT="$(mktemp "${TMPDIR:-/tmp}/norm-output.XXXXXX")"

# Построчная нормализация конфига
awk '
BEGIN {
    # Числовые ключи, которые в OpenWrt / WireGuard / AWG должны быть целым числом
    num_keys["persistentkeepalive"] = 1
    num_keys["mtu"] = 1
    num_keys["jc"] = 1
    num_keys["jmin"] = 1
    num_keys["jmax"] = 1
    num_keys["s1"] = 1
    num_keys["s2"] = 1
    num_keys["s3"] = 1
    num_keys["s4"] = 1
    num_keys["h1"] = 1
    num_keys["h2"] = 1
    num_keys["h3"] = 1
    num_keys["h4"] = 1
    num_keys["port"] = 1
    num_keys["listenport"] = 1
}

function trim(s) {
    sub(/^[[:space:]]+/, "", s)
    sub(/[[:space:]]+$/, "", s)
    return s
}

{
    line = $0
    gsub(/\r/, "", line)

    # Пропуск пустых строк и комментариев без изменений
    if (line ~ /^[[:space:]]*([#;]|$)/) {
        print line
        next
    }

    # Секции [Interface], [Peer] и т.д.
    if (line ~ /^[[:space:]]*\[/) {
        print line
        next
    }

    eq_pos = index(line, "=")
    if (eq_pos == 0) {
        print line
        next
    }

    key = trim(substr(line, 1, eq_pos - 1))
    val_part = substr(line, eq_pos + 1)
    val = trim(val_part)

    # Отделяем инлайн-комментарий, если есть
    comment = ""
    c_pos = index(val, "#")
    if (c_pos == 0) c_pos = index(val, ";")
    if (c_pos > 0) {
        comment = substr(val, c_pos)
        val = trim(substr(val, 1, c_pos - 1))
    }

    key_l = tolower(key)

    # 1. Нормализация диапазонов чисел (напр. PersistentKeepalive 25-35)
    if (key_l in num_keys && match(val, /^[0-9]+[[:space:]]*-[[[:space:]]*[0-9]+$/)) {
        split(val, parts, "-")
        first_num = trim(parts[1])
        printf "# [original: %s = %s%s]\n", key, val, (comment != "" ? " " comment : "")
        printf "%s = %s\n", key, first_num
        next
    }

    # Любой другой параметр выводим штатно
    if (comment != "") {
        printf "%s = %s %s\n", key, val, comment
    } else {
        printf "%s = %s\n", key, val
    }
}
' "$SOURCE_FILE" > "$TMP_OUTPUT"

# Определение выходного файла
TARGET_FILE=""
if [ "$IN_PLACE" = "1" ]; then
    TARGET_FILE="$SOURCE_FILE"
elif [ -n "$DEST_FILE" ]; then
    TARGET_FILE="$DEST_FILE"
fi

if [ -n "$TARGET_FILE" ]; then
    mkdir -p "$(dirname "$TARGET_FILE")"
    mv "$TMP_OUTPUT" "$TARGET_FILE"
    TMP_OUTPUT=""
    printf '[+] Конфиг нормализован [%s]: %s\n' "$DETECTED_KIND" "$TARGET_FILE"
else
    cat "$TMP_OUTPUT"
    rm -f "$TMP_OUTPUT"
    TMP_OUTPUT=""
fi

# Генерация .meta если запрошено
if [ "$WRITE_META" = "1" ] && [ -n "$TARGET_FILE" ]; then
    META_FILE="${TARGET_FILE}.meta"
    if [ ! -f "$META_FILE" ]; then
        endpoint="$(awk -F= 'tolower($1) ~ /^[[:space:]]*endpoint/ { sub(/^[[:space:]]+/, "", $2); sub(/[[:space:]]+$/, "", $2); print $2; exit }' "$TARGET_FILE")"
        endpoint_host="${endpoint%:*}"
        pubkey="$(awk -F= 'tolower($1) ~ /^[[:space:]]*publickey/ { sub(/^[[:space:]]+/, "", $2); sub(/[[:space:]]+$/, "", $2); print $2; exit }' "$TARGET_FILE")"
        base_name="$(basename "$TARGET_FILE" .conf)"

        server_name="Amnezia ($base_name)"
        if [ "$DETECTED_KIND" = "amnezia" ]; then
            server_name="AmneziaWG ($base_name)"
        elif [ "$DETECTED_KIND" = "custom" ]; then
            server_name="Custom WG ($base_name)"
        fi

        cat > "$META_FILE" <<EOF2
NAME_SCHEMA_VERSION='7'
GENERATOR_KIND='$DETECTED_KIND'
PROFILE_BASENAME='$base_name'
PROFILE_LABEL='$server_name'
PROFILE_MODE='local'
COUNTRY_FILTER='auto'
SELECTION_MODE='import'
SERVER_NAME='$server_name'
SERVER_COUNTRY='-'
SERVER_CITY='${endpoint_host:-unknown}'
ENDPOINT_HOST='${endpoint_host:-}'
PEER_PUBLIC_KEY='${pubkey:-}'
SOURCE_KIND='amnezia_normalized_conf'
GENERATED_AT_UTC='$(date -u +"%Y-%m-%dT%H:%M:%SZ")'
EOF2
        printf '[+] Создан meta-файл: %s\n' "$META_FILE"
    fi
fi

exit 0
