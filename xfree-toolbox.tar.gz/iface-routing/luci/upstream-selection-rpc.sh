#!/bin/sh
# Thin JSON entry for LuCI/rpcd → lib/selection (target=iface).
# Legacy CLI: list-interfaces | get-model IFACE | save IFACE [tags...]
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
IFACE_ROUTING_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$IFACE_ROUTING_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/selection/upstream-selection.sh"

selection_iface_init_module "$IFACE_ROUTING_DIR" || {
	selection_json_error "missing ui.conf or iface-routing module"
	exit 0
}

case "${1:-}" in
list-interfaces | list-scopes)
	selection_upstream_json_list_scopes iface
	;;
get-model)
	selection_upstream_json_get_model iface "${2:-}" "${3:-all}"
	;;
save)
	iface="${2:-}"
	shift 2 || shift 1 || true
	selection_upstream_json_save iface "$iface" all "$@"
	;;
*)
	selection_json_error "usage: list-scopes | get-model IFACE [mode] | save IFACE [tags...]"
	;;
esac
