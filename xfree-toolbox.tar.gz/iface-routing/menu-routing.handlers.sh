#!/bin/sh
# Hand-written handlers for cli.run component=custom in iface-routing/menu-routing.yaml.
# shellcheck shell=sh

iface_lists_apply_title() {
	apply_label="Применить выбранные сайты"
	if iface_state_any_iface_lists_out_of_sync "$INTERFACES_DIR" "$SYSTEM_INTERFACES_DIR"; then
		apply_label="Применить выбранные сайты *"
	fi
	printf '%s' "$apply_label"
}

iface_lists_run_upstream_preflight() {
	upstreams_handlers="$ROOT_DIR/upstreams/menu.handlers.sh"
	[ -f "$upstreams_handlers" ] || {
		ui_msgbox "Ошибка" "Не найден:\n$upstreams_handlers"
		return 1
	}

	[ -f "$ROOT_DIR/lib/upstreams.sh" ] && . "$ROOT_DIR/lib/upstreams.sh"
	UPSTREAMS_MODULE_DIR="$ROOT_DIR/upstreams"
	# shellcheck disable=SC1090
	. "$upstreams_handlers"

	update_selected_modules
	check_active_list_updates_one_mode profiles 1
}

iface_lists_update_and_apply_menu() {
	if ! ui_confirm "Обновить и применить" \
"Сначала: обновление upstream и списков в profiles/.
Затем: применение DNS-redirect и маршрутизации (lib/apply-dns-and-iface-routing.sh).

Продолжить?"; then
		return 0
	fi

	apply_routing_sh="${IFACE_LISTS_MENU_apply_routing:-$SCRIPT_DIR/apply-routing.sh}"

	ui_run_with_output_batch_begin
	iface_lists_run_upstream_preflight || {
		ui_run_with_output_batch_end "Обновить и применить"
		return 0
	}
	run_log 'Применение маршрутизации' "$apply_routing_sh"
	ui_run_with_output_batch_end "Обновить и применить"
}
