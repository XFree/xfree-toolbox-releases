#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
UI_SH="$ROOT_DIR/lib/ui.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

[ -f "$UI_SH" ] || {
    echo "[-] Не найден ui.sh: $UI_SH" >&2
    exit 1
}
. "$UI_SH"

if command -v load_base_config >/dev/null 2>&1; then
    load_base_config "$SCRIPT_DIR"
fi

if command -v load_module_config >/dev/null 2>&1; then
    load_module_config "$CONFIG_FILE"
elif [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
fi

GENERATOR_SH="$SCRIPT_DIR/generate.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"
_DEFAULT_WARP_CONF="$(xfree_profile_warp_conf_dir "$PROFILE_DIR")"
PROFILE_WARP_CONF_DIR="${PROFILE_WARP_CONF_DIR:-${PROFILE_WARP_GENERATED_DIR:-$_DEFAULT_WARP_CONF}}"
CONF_DIR="${CONF_DIR:-$PROFILE_WARP_CONF_DIR}"

STATE_DIR="/tmp/domain-routing-warp"
mkdir -p "$STATE_DIR"

SERVER_FILE="$STATE_DIR/server"
PROFILE_FILE="$STATE_DIR/profile"
NAME_FILE="$STATE_DIR/name"
MODE_FILE="$STATE_DIR/mode"
I1_MODE_FILE="$STATE_DIR/i1_mode"
I1_DOMAIN_FILE="$STATE_DIR/i1_domain"

default_server() { printf '%s\n' "xfree"; }
default_profile() { printf '%s\n' "2.0:1"; }
default_mode() { printf '%s\n' "local"; }
default_i1_mode() { printf '%s\n' "fixed"; }

normalize_server_token() {
    srv="$1"
    case "$srv" in
        xfree|def|FL|NL|PL|DE|LV|RU) printf '%s\n' "$srv" ;;
        PL1|PL2) printf 'PL\n' ;;
        ltePL|lteFL|LTEPL|LTEFL) default_server ;;
        *) default_server ;;
    esac
}

get_selected_server() {
    if [ -f "$SERVER_FILE" ]; then
        normalize_server_token "$(cat "$SERVER_FILE")"
    else
        default_server
    fi
}

set_selected_server() {
    printf '%s\n' "$1" > "$SERVER_FILE"
}

normalize_profile_token() {
    profile="$1"
    case "$profile" in
        1.5:*)
            printf '2.0:%s\n' "${profile#1.5:}"
            ;;
        2.0:*)
            printf '%s\n' "$profile"
            ;;
        [123])
            printf '2.0:%s\n' "$profile"
            ;;
        *)
            default_profile
            ;;
    esac
}

get_selected_profile() {
    if [ -f "$PROFILE_FILE" ]; then
        normalize_profile_token "$(cat "$PROFILE_FILE")"
    else
        default_profile
    fi
}

set_selected_profile() {
    printf '%s\n' "$1" > "$PROFILE_FILE"
}

get_selected_version() {
    get_selected_profile | cut -d: -f1
}

get_selected_variant() {
    get_selected_profile | cut -d: -f2
}

get_selected_name() {
    [ -f "$NAME_FILE" ] && cat "$NAME_FILE" || true
}

set_selected_name() {
    printf '%s\n' "$1" > "$NAME_FILE"
}

get_selected_mode() {
    [ -f "$MODE_FILE" ] && cat "$MODE_FILE" || default_mode
}

set_selected_mode() {
    printf '%s\n' "$1" > "$MODE_FILE"
}

get_selected_i1_mode() {
    [ -f "$I1_MODE_FILE" ] && cat "$I1_MODE_FILE" || default_i1_mode
}

set_selected_i1_mode() {
    printf '%s\n' "$1" > "$I1_MODE_FILE"
}

get_selected_i1_domain() {
    [ -f "$I1_DOMAIN_FILE" ] && cat "$I1_DOMAIN_FILE" || true
}

set_selected_i1_domain() {
    printf '%s\n' "$1" > "$I1_DOMAIN_FILE"
}

server_label() {
    case "$1" in
        xfree) printf '%s\n' "xfree (узкий CF)" ;;
        def)   printf '%s\n' "def (Cloudflare, как warp-generator)" ;;
        FL)    printf '%s\n' "Финляндия" ;;
        NL)    printf '%s\n' "Нидерланды" ;;
        PL)    printf '%s\n' "Польша" ;;
        DE)    printf '%s\n' "Германия" ;;
        LV)    printf '%s\n' "Латвия" ;;
        RU)    printf '%s\n' "Россия" ;;
        *)     printf '%s\n' "$1" ;;
    esac
}

server_endpoint_hint() {
    case "$1" in
        xfree)
            printf '%s\n' "${WARP_XFREE_DEF_HOST_PREFIX:-162.159.195.}${WARP_XFREE_DEF_HOST_OCTET_MIN:-1}–${WARP_XFREE_DEF_HOST_OCTET_MAX:-10}"
            ;;
        def)
            printf '%s\n' "префиксы CF, октет ${WARP_CF_DEF_OCTET_MIN:-1}–${WARP_CF_DEF_OCTET_MAX:-10}"
            ;;
        PL)  printf '%s\n' "pl.tribukvy.ltd" ;;
        DE)  printf '%s\n' "de.tribukvy.ltd" ;;
        RU)  printf '%s\n' "ru0.tribukvy.ltd" ;;
        NL)  printf '%s\n' "nl.tribukvy.ltd" ;;
        FL)  printf '%s\n' "fi.tribukvy.ltd" ;;
        LV)  printf '%s\n' "lv.tribukvy.ltd" ;;
        *)   printf '%s\n' "—" ;;
    esac
}

profile_label() {
    case "$1" in
        "2.0:1") printf '%s\n' "AWG 2.0 (Вариант 1)" ;;
        "2.0:2") printf '%s\n' "AWG 2.0 (Вариант 2)" ;;
        "2.0:3") printf '%s\n' "AWG 2.0 (Вариант 3)" ;;
        *) printf '%s\n' "$1" ;;
    esac
}

mode_label() {
    case "$1" in
        local) printf '%s\n' "Local (под систему)" ;;
        raw)   printf '%s\n' "Raw (исходный)" ;;
        *)     printf '%s\n' "$1" ;;
    esac
}

i1_mode_label() {
    case "$1" in
        fixed)  printf '%s\n' "Fixed (preset)" ;;
        random) printf '%s\n' "Random (каждый раз новый)" ;;
        domain) printf '%s\n' "Domain-seeded (стабильно от домена)" ;;
        *)      printf '%s\n' "$1" ;;
    esac
}

show_status() {
    srv="$(get_selected_server)"
    profile="$(get_selected_profile)"
    mode="$(get_selected_mode)"
    i1_mode="$(get_selected_i1_mode)"
    i1_domain="$(get_selected_i1_domain)"
    name="$(get_selected_name)"
    [ -n "$name" ] || name="<авто>"
    [ -n "$i1_domain" ] || i1_domain="<не задан>"

    ui_msgbox "WARP генератор" "Текущие параметры

Сервер:  $(server_label "$srv") [$srv]
Endpoint: $(server_endpoint_hint "$srv")
Профиль: $(profile_label "$profile") (AWG 2.0)
Режим:   $(mode_label "$mode") [$mode]
I1:      $(i1_mode_label "$i1_mode") [$i1_mode]
I1 seed: $i1_domain
Имя:     $name
Каталог: $CONF_DIR"
}

select_server() {
    set -- "xfree" "xfree — 162.159.195.1–10"
    if _menu_item_visible expert; then
        set -- "$@" \
            "def" "def — Cloudflare (широкие префиксы)" \
            "FL" "Финляндия" \
            "NL" "Нидерланды" \
            "PL" "Польша" \
            "DE" "Германия" \
            "LV" "Латвия" \
            "RU" "Россия"
    fi

    if _menu_item_visible expert; then
        _srv_prompt="Серверы (без LTE). def — как на warp-generator.github.io; страны — tribukvy."
        _srv_menu_h=10
    else
        _srv_prompt="Сервер xfree (узкий пул Cloudflare). def и страны — в режиме эксперт."
        _srv_menu_h=4
    fi

    choice="$(ui_menu "WARP генератор" "$_srv_prompt" 22 78 "$_srv_menu_h" "$@" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_server "$choice"
}

select_profile() {
    choice="$(ui_menu "WARP генератор" "Выберите вариант AWG 2.0" 18 78 8 \
        "2.0:1" "Вариант 1" \
        "2.0:2" "Вариант 2" \
        "2.0:3" "Вариант 3" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_profile "$choice"
}

select_mode() {
    choice="$(ui_menu "WARP генератор" "Выберите режим генерации" 16 78 6 \
        "local" "Local (под систему)" \
        "raw"   "Raw (исходный)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_mode "$choice"
}

select_i1_mode() {
    choice="$(ui_menu "WARP генератор" "Режим генерации I1" 16 90 6 \
        "fixed"  "Fixed (текущий preset)" \
        "random" "Random (новый I1 на каждую генерацию)" \
        "domain" "Domain-seeded (стабильно по домену)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_i1_mode "$choice"
}

edit_i1_domain() {
    cur="$(get_selected_i1_domain)"
    result="$(ui_inputbox "WARP генератор" "Введите домен/seed для режима I1=domain.
Пример: example.com
Пусто = режим domain будет недоступен." "$cur" || true)"
    [ -n "${result+x}" ] || return 0
    set_selected_i1_domain "$result"
}

edit_name() {
    cur="$(get_selected_name)"
    result="$(ui_inputbox "WARP генератор" "Введите базовое имя файла без .conf.
Пусто = имя будет выбрано автоматически." "$cur" || true)"
    [ -n "${result+x}" ] || return 0
    set_selected_name "$result"
}

generate_config() {
    mkdir -p "$CONF_DIR"

    srv="$(get_selected_server)"
    profile="$(get_selected_profile)"
    var="$(get_selected_variant)"
    mode="$(get_selected_mode)"
    i1_mode="$(get_selected_i1_mode)"
    i1_domain="$(get_selected_i1_domain)"
    name="$(get_selected_name)"

    cmd="'$GENERATOR_SH' --server '$srv' --variant '$var' --$mode"
    cmd="$cmd --i1-mode '$i1_mode'"
    if [ "$i1_mode" = "domain" ] && [ -n "$i1_domain" ]; then
        cmd="$cmd --i1-domain '$i1_domain'"
    fi
    if [ -n "$name" ]; then
        cmd="$cmd --name '$name'"
    fi

    if ui_confirm "WARP генератор" "Сгенерировать новый конфиг?

Сервер:  $(server_label "$srv") [$srv]
Профиль: $(profile_label "$profile") [$profile]
Режим:   $(mode_label "$mode") [$mode]
I1:      $(i1_mode_label "$i1_mode") [$i1_mode]
I1 seed: ${i1_domain:-<не задан>}
Имя:     ${name:-<авто>}" ; then
        ui_menu_invoke_with_output "Генерация WARP-конфига" sh -c "$cmd"
    fi
}

show_last_configs() {
    mkdir -p "$CONF_DIR"
    tmp="${UI_TMP_ROOT:-/tmp}/warp-conf-list.$$"
    : > "$tmp"

    ls -1t "$CONF_DIR"/*.conf 2>/dev/null > "$tmp" || true

    if [ ! -s "$tmp" ]; then
        ui_msgbox "WARP генератор" "В каталоге нет .conf файлов:
$CONF_DIR"
        rm -f "$tmp"
        return 0
    fi

    ui_show_textbox "Последние конфиги" "$tmp" 24 100
    rm -f "$tmp"
}

main() {
    [ -x "$GENERATOR_SH" ] || chmod +x "$GENERATOR_SH" 2>/dev/null || true
    [ -x "$GENERATOR_SH" ] || die "Генератор не исполняемый: $GENERATOR_SH"
    # Host store (profile-generator): no mode toggle — always full menu.
    if [ -n "${XFREE_VPN_STORE_ID:-}" ]; then
        export XFREE_MENU_MODE=expert
    fi
    menu_mode_normalize

    while :; do
        srv="$(get_selected_server)"
        profile="$(get_selected_profile)"
        mode="$(get_selected_mode)"
        i1_mode="$(get_selected_i1_mode)"
        i1_domain="$(get_selected_i1_domain)"
        name="$(get_selected_name)"
        [ -n "$name" ] || name="<авто>"

        hint="Генерация совместимого .conf

Сервер:  $(server_label "$srv") [$srv]
Профиль: $(profile_label "$profile") [$profile]
Режим:   $(mode_label "$mode") [$mode]
Имя:     $name"
        if _menu_item_visible expert; then
            hint="$hint
I1:      $(i1_mode_label "$i1_mode") [$i1_mode]
Seed:    ${i1_domain:-<не задан>}"
        fi

        set -- \
            "1" "Показать текущие параметры" \
            "2" "Выбрать сервер" \
            "3" "Выбрать вариант AWG 2.0" \
            "4" "Выбрать режим генерации"
        if _menu_item_visible expert; then
            set -- "$@" \
                "5" "Режим генерации I1" \
                "6" "Задать I1 domain/seed"
        fi
        set -- "$@" \
            "7" "Задать имя файла" \
            "8" "Сгенерировать конфиг" \
            "9" "Показать последние .conf" \
            "0" "Назад"

        choice="$(ui_menu "WARP генератор" "$hint" 24 90 10 "$@" || true)"

        case "${choice:-}" in
            1) show_status ;;
            2) select_server ;;
            3) select_profile ;;
            4) select_mode ;;
            5) select_i1_mode ;;
            6) edit_i1_domain ;;
            7) edit_name ;;
            8) generate_config ;;
            9) show_last_configs ;;
            0|"") break ;;
        esac
    done
}

main "$@"
