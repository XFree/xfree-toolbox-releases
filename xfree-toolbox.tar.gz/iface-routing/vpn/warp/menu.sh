#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
UI_SH="$ROOT_DIR/lib/ui.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

[ -f "$UI_SH" ] || {
    echo "[-] Не найден ui.sh: $UI_SH" >&2
    exit 1
}
. "$UI_SH"

if command -v load_base_config >/dev/null 2>&1; then
    load_base_config "$SCRIPT_DIR"
fi

if command -v load_module_config >/dev/null 2>&1; then
    load_module_config "$CONFIG_FILE"
elif [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
fi

GENERATOR_SH="$SCRIPT_DIR/generate.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"
_DEFAULT_WARP_CONF="$(xfree_profile_warp_conf_dir "$PROFILE_DIR")"
PROFILE_WARP_CONF_DIR="${PROFILE_WARP_CONF_DIR:-${PROFILE_WARP_GENERATED_DIR:-$_DEFAULT_WARP_CONF}}"
CONF_DIR="${CONF_DIR:-$PROFILE_WARP_CONF_DIR}"

STATE_DIR="/tmp/domain-routing-warp"
mkdir -p "$STATE_DIR"

SERVER_FILE="$STATE_DIR/server"
PROFILE_FILE="$STATE_DIR/profile"
NAME_FILE="$STATE_DIR/name"
MODE_FILE="$STATE_DIR/mode"
I1_MODE_FILE="$STATE_DIR/i1_mode"
I1_DOMAIN_FILE="$STATE_DIR/i1_domain"
SELECTION_FILE="$STATE_DIR/selection"
EXCLUDE_RU_FILE="$STATE_DIR/exclude_ru"
AWG_NOISE_FILE="$STATE_DIR/awg_noise"
I1_ENTROPY_FILE="$STATE_DIR/i1_entropy"

default_server() { printf '%s\n' "${DEFAULT_SERVER:-def}"; }
default_profile() { printf '%s\n' "2.0:1"; }
default_mode() { printf '%s\n' "local"; }
default_i1_mode() { printf '%s\n' "fixed"; }
default_selection_mode() { printf '%s\n' "${DEFAULT_SELECTION_MODE:-best}"; }
default_exclude_ru() { printf '%s\n' "${WARP_EXCLUDE_RU:-1}"; }
default_awg_noise() { printf '%s\n' "${DEFAULT_AWG_NOISE_ENABLED:-1}"; }
default_i1_entropy() { printf '%s\n' "${DEFAULT_AWG_I1_ENTROPY:-off}"; }

normalize_server_token() {
    srv="$1"
    case "$srv" in
        xfree|def|FL|NL|PL|DE|LV|RU|lteFL|ltePL|lteDE) printf '%s\n' "$srv" ;;
        LTEFL) printf 'lteFL\n' ;;
        LTEPL) printf 'ltePL\n' ;;
        LTEDE) printf 'lteDE\n' ;;
        PL1|PL2) printf 'PL\n' ;;
        *) default_server ;;
    esac
}

get_selected_server() {
    if [ -f "$SERVER_FILE" ]; then
        normalize_server_token "$(cat "$SERVER_FILE")"
    else
        default_server
    fi
}

set_selected_server() {
    printf '%s\n' "$1" > "$SERVER_FILE"
}

normalize_profile_token() {
    profile="$1"
    case "$profile" in
        1.5:*)
            printf '2.0:%s\n' "${profile#1.5:}"
            ;;
        2.0:*)
            printf '%s\n' "$profile"
            ;;
        [123])
            printf '2.0:%s\n' "$profile"
            ;;
        *)
            default_profile
            ;;
    esac
}

get_selected_profile() {
    if [ -f "$PROFILE_FILE" ]; then
        normalize_profile_token "$(cat "$PROFILE_FILE")"
    else
        default_profile
    fi
}

set_selected_profile() {
    printf '%s\n' "$1" > "$PROFILE_FILE"
}

get_selected_version() {
    get_selected_profile | cut -d: -f1
}

get_selected_variant() {
    get_selected_profile | cut -d: -f2
}

get_selected_name() {
    [ -f "$NAME_FILE" ] && cat "$NAME_FILE" || true
}

set_selected_name() {
    printf '%s\n' "$1" > "$NAME_FILE"
}

get_selected_mode() {
    [ -f "$MODE_FILE" ] && cat "$MODE_FILE" || default_mode
}

set_selected_mode() {
    printf '%s\n' "$1" > "$MODE_FILE"
}

get_selected_i1_mode() {
    [ -f "$I1_MODE_FILE" ] && cat "$I1_MODE_FILE" || default_i1_mode
}

set_selected_i1_mode() {
    printf '%s\n' "$1" > "$I1_MODE_FILE"
}

get_selected_i1_domain() {
    [ -f "$I1_DOMAIN_FILE" ] && cat "$I1_DOMAIN_FILE" || true
}

set_selected_i1_domain() {
    printf '%s\n' "$1" > "$I1_DOMAIN_FILE"
}

normalize_selection_mode() {
    case "$1" in
        best|random) printf '%s\n' "$1" ;;
        *) default_selection_mode ;;
    esac
}

get_selected_selection_mode() {
    if [ -f "$SELECTION_FILE" ]; then
        normalize_selection_mode "$(cat "$SELECTION_FILE")"
    else
        default_selection_mode
    fi
}

set_selected_selection_mode() {
    printf '%s\n' "$1" > "$SELECTION_FILE"
}

normalize_exclude_ru() {
    case "$1" in
        1|yes|on|true) printf '1\n' ;;
        0|no|off|false) printf '0\n' ;;
        *) default_exclude_ru ;;
    esac
}

get_selected_exclude_ru() {
    if [ -f "$EXCLUDE_RU_FILE" ]; then
        normalize_exclude_ru "$(cat "$EXCLUDE_RU_FILE")"
    else
        default_exclude_ru
    fi
}

set_selected_exclude_ru() {
    printf '%s\n' "$1" > "$EXCLUDE_RU_FILE"
}

get_selected_awg_noise() {
    if [ -f "$AWG_NOISE_FILE" ]; then
        awg_normalize_noise_enabled "$(cat "$AWG_NOISE_FILE")" 1
    else
        default_awg_noise
    fi
}

set_selected_awg_noise() {
    printf '%s\n' "$(awg_normalize_noise_enabled "$1" 1)" > "$AWG_NOISE_FILE"
}

get_selected_i1_entropy() {
    if [ -f "$I1_ENTROPY_FILE" ]; then
        awg_normalize_i1_entropy "$(cat "$I1_ENTROPY_FILE")" off
    else
        default_i1_entropy
    fi
}

set_selected_i1_entropy() {
    printf '%s\n' "$(awg_normalize_i1_entropy "$1" off)" > "$I1_ENTROPY_FILE"
}

selection_mode_label() {
    case "$1" in
        best) printf '%s\n' "Топ-5 по колонии" ;;
        random) printf '%s\n' "Случайный endpoint" ;;
        *) printf '%s\n' "$1" ;;
    esac
}

exclude_ru_label() {
    case "$1" in
        1) printf '%s\n' "вкл" ;;
        0) printf '%s\n' "выкл" ;;
        *) printf '%s\n' "$1" ;;
    esac
}

server_label() {
    case "$1" in
        xfree) printf '%s\n' "xfree (узкий CF)" ;;
        def)   printf '%s\n' "def (Cloudflare, как warp-generator)" ;;
        FL)    printf '%s\n' "Финляндия (рег.)" ;;
        NL)    printf '%s\n' "Нидерланды (рег.)" ;;
        PL)    printf '%s\n' "Польша (рег.)" ;;
        DE)    printf '%s\n' "Германия (рег.)" ;;
        LV)    printf '%s\n' "Латвия (рег.)" ;;
        RU)    printf '%s\n' "Россия (рег.)" ;;
        lteFL) printf '%s\n' "[LTE] Финляндия" ;;
        ltePL) printf '%s\n' "[LTE] Польша" ;;
        lteDE) printf '%s\n' "[LTE] Германия" ;;
        *)     printf '%s\n' "$1" ;;
    esac
}

server_endpoint_hint() {
    case "$1" in
        xfree)
            printf '%s\n' "${WARP_XFREE_DEF_HOST_PREFIX:-162.159.195.}${WARP_XFREE_DEF_HOST_OCTET_MIN:-1}–${WARP_XFREE_DEF_HOST_OCTET_MAX:-10}"
            ;;
        def)
            printf '%s\n' "префиксы CF, октет ${WARP_CF_DEF_OCTET_MIN:-1}–${WARP_CF_DEF_OCTET_MAX:-10}"
            ;;
        PL)  printf '%s\n' "pl.tribukvy.ltd" ;;
        DE)  printf '%s\n' "de.tribukvy.ltd" ;;
        RU)  printf '%s\n' "ru0.tribukvy.ltd" ;;
        NL)  printf '%s\n' "nl.tribukvy.ltd" ;;
        FL)  printf '%s\n' "fi.tribukvy.ltd" ;;
        LV)  printf '%s\n' "lv.tribukvy.ltd" ;;
        ltePL) printf '%s\n' "tel.pl.tribukvy.ltd (без порта 988)" ;;
        lteFL) printf '%s\n' "tel.fi.tribukvy.ltd (без порта 1010)" ;;
        lteDE) printf '%s\n' "tel.de.tribukvy.ltd" ;;
        *)   printf '%s\n' "—" ;;
    esac
}

profile_label() {
    case "$1" in
        "2.0:1") printf '%s\n' "AWG 2.0 (Вариант 1)" ;;
        "2.0:2") printf '%s\n' "AWG 2.0 (Вариант 2)" ;;
        "2.0:3") printf '%s\n' "AWG 2.0 (Вариант 3)" ;;
        *) printf '%s\n' "$1" ;;
    esac
}

mode_label() {
    case "$1" in
        local) printf '%s\n' "Local (под систему)" ;;
        raw)   printf '%s\n' "Raw (исходный)" ;;
        *)     printf '%s\n' "$1" ;;
    esac
}

i1_mode_label() {
    case "$1" in
        fixed)  printf '%s\n' "Fixed (preset)" ;;
        random) printf '%s\n' "Random (каждый раз новый)" ;;
        domain) printf '%s\n' "Domain-seeded (стабильно от домена)" ;;
        *)      printf '%s\n' "$1" ;;
    esac
}

show_status() {
    srv="$(get_selected_server)"
    profile="$(get_selected_profile)"
    mode="$(get_selected_mode)"
    i1_mode="$(get_selected_i1_mode)"
    i1_domain="$(get_selected_i1_domain)"
    sel="$(get_selected_selection_mode)"
    exclude_ru="$(get_selected_exclude_ru)"
    awg_noise="$(get_selected_awg_noise)"
    i1_entropy="$(get_selected_i1_entropy)"
    name="$(get_selected_name)"
    [ -n "$name" ] || name="<авто>"
    [ -n "$i1_domain" ] || i1_domain="<не задан>"

    ui_msgbox "WARP генератор" "Текущие параметры

Сервер:  $(server_label "$srv") [$srv]
Endpoint: $(server_endpoint_hint "$srv")
Выбор:   $(selection_mode_label "$sel") [$sel]
Фильтр RU: $(exclude_ru_label "$exclude_ru")
Профиль: $(profile_label "$profile") (AWG 2.0)
Шум:     $(awg_noise_label "$awg_noise")
Энтропия: $(awg_i1_entropy_label "$i1_entropy")
Режим:   $(mode_label "$mode") [$mode]
I1:      $(i1_mode_label "$i1_mode") [$i1_mode]
I1 seed: $i1_domain
Имя:     $name
Каталог: $CONF_DIR"
}

select_server() {
    set -- \
        "def" "def — Cloudflare, октет 1–10" \
        "xfree" "xfree — 162.159.195.1–10"
    if _menu_item_visible expert; then
        set -- "$@" \
            "FL" "Финляндия (рег. — бот llimonix)" \
            "NL" "Нидерланды (рег. — бот llimonix)" \
            "PL" "Польша (рег. — бот llimonix)" \
            "DE" "Германия (рег. — бот llimonix)" \
            "LV" "Латвия (рег. — бот llimonix)" \
            "RU" "Россия (рег. — бот llimonix)" \
            "lteFL" "[LTE] Финляндия (без бота; порт ≠1010)" \
            "ltePL" "[LTE] Польша (без бота; порт ≠988)" \
            "lteDE" "[LTE] Германия (без бота)"
    fi

    if _menu_item_visible expert; then
        _srv_prompt="def/xfree — Cloudflare. Страны (рег.) — бот llimonix. [LTE] — без бота, свой фильтр портов. EE снят. См. warp-generation.github.io"
        _srv_menu_h=14
    else
        _srv_prompt="def — пул Cloudflare. xfree — узкий 162.159.195. Страны (рег.) и [LTE] — в режиме эксперт."
        _srv_menu_h=6
    fi

    choice="$(ui_menu "WARP генератор" "$_srv_prompt" 22 78 "$_srv_menu_h" "$@" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_server "$choice"
}

select_profile() {
    choice="$(ui_menu "WARP генератор" "Выберите вариант AWG 2.0" 18 78 8 \
        "2.0:1" "Вариант 1" \
        "2.0:2" "Вариант 2" \
        "2.0:3" "Вариант 3" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_profile "$choice"
}

select_selection_mode() {
    choice="$(ui_menu "WARP генератор" "Как выбирать точку входа.
best проверяет до 5 разных IP через /cdn-cgi/trace и берёт самый быстрый." 18 78 6 \
        "best" "Топ-5 по колонии + задержка" \
        "random" "Случайный endpoint" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_selection_mode "$choice"
}

select_exclude_ru() {
    choice="$(ui_menu "WARP генератор" "Фильтр колоний в России (DME, LED, KJA, SVX).
loc= в trace — страна клиента, она не фильтруется." 18 78 6 \
        "1" "Вкл — пропускать колонии RU" \
        "0" "Выкл" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_exclude_ru "$choice"
}

select_mode() {
    choice="$(ui_menu "WARP генератор" "Выберите режим генерации" 16 78 6 \
        "local" "Local (под систему)" \
        "raw"   "Raw (исходный)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_mode "$choice"
}

select_i1_mode() {
    choice="$(ui_menu "WARP генератор" "Режим генерации I1" 16 90 6 \
        "fixed"  "Fixed (текущий preset)" \
        "random" "Random (новый I1 на каждую генерацию)" \
        "domain" "Domain-seeded (стабильно по домену)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_i1_mode "$choice"
}

edit_i1_domain() {
    cur="$(get_selected_i1_domain)"
    result="$(ui_inputbox "WARP генератор" "Введите домен/seed для режима I1=domain.
Пример: example.com
Пусто = режим domain будет недоступен." "$cur" || true)"
    [ -n "${result+x}" ] || return 0
    set_selected_i1_domain "$result"
}

edit_name() {
    cur="$(get_selected_name)"
    result="$(ui_inputbox "WARP генератор" "Введите базовое имя файла без .conf.
Пусто = имя будет выбрано автоматически." "$cur" || true)"
    [ -n "${result+x}" ] || return 0
    set_selected_name "$result"
}

select_awg_noise() {
    choice="$(ui_menu "WARP генератор" "Шум AmneziaWG (junk packets Jc, Jmin, Jmax)" 16 78 4 \
        "1" "С шумом (Jc=4, Jmin=40, Jmax=70, по умолчанию)" \
        "0" "Без шума (Jc=0)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_awg_noise "$choice"
}

select_i1_entropy() {
    choice="$(ui_menu "WARP генератор" "Энтропия I1 (дополнительные теги после <b 0x…>)" 20 80 8 \
        "off" "Без энтропии (по умолчанию)" \
        "r32" "<r 32> · 32 байта" \
        "r64" "<r 64> · 64 байта (паранойя)" \
        "t" "<t> · timestamp" \
        "c" "<c> · счётчик" \
        "rc10" "<rc 10> · 10 букв" \
        "rd6" "<rd 6> · 6 цифр" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_i1_entropy "$choice"
}

generate_config() {
    mkdir -p "$CONF_DIR"

    srv="$(get_selected_server)"
    profile="$(get_selected_profile)"
    var="$(get_selected_variant)"
    mode="$(get_selected_mode)"
    sel="$(get_selected_selection_mode)"
    exclude_ru="$(get_selected_exclude_ru)"
    awg_noise="$(get_selected_awg_noise)"
    i1_entropy="$(get_selected_i1_entropy)"
    i1_mode="$(get_selected_i1_mode)"
    i1_domain="$(get_selected_i1_domain)"
    name="$(get_selected_name)"

    cmd="'$GENERATOR_SH' --server '$srv' --variant '$var' --$mode"
    cmd="$cmd --$sel"
    if [ "$exclude_ru" = "1" ]; then
        cmd="$cmd --exclude-ru"
    else
        cmd="$cmd --allow-ru"
    fi
    case "$awg_noise" in
        0) cmd="$cmd --no-noise" ;;
        *) cmd="$cmd --with-noise" ;;
    esac
    case "$i1_entropy" in
        off) cmd="$cmd --no-i1-entropy" ;;
        *)   cmd="$cmd --i1-entropy '$i1_entropy'" ;;
    esac
    cmd="$cmd --i1-mode '$i1_mode'"
    if [ "$i1_mode" = "domain" ] && [ -n "$i1_domain" ]; then
        cmd="$cmd --i1-domain '$i1_domain'"
    fi
    if [ -n "$name" ]; then
        cmd="$cmd --name '$name'"
    fi

    if ui_confirm "WARP генератор" "Сгенерировать новый конфиг?

Сервер:  $(server_label "$srv") [$srv]
Выбор:   $(selection_mode_label "$sel") [$sel]
Фильтр RU: $(exclude_ru_label "$exclude_ru")
Профиль: $(profile_label "$profile") [$profile]
Шум:     $(awg_noise_label "$awg_noise")
Энтропия: $(awg_i1_entropy_label "$i1_entropy")
Режим:   $(mode_label "$mode") [$mode]
I1:      $(i1_mode_label "$i1_mode") [$i1_mode]
I1 seed: ${i1_domain:-<не задан>}
Имя:     ${name:-<авто>}" ; then
        ui_menu_invoke_with_output "Генерация WARP-конфига" sh -c "$cmd"
    fi
}

show_last_configs() {
    mkdir -p "$CONF_DIR"
    tmp="${UI_TMP_ROOT:-/tmp}/warp-conf-list.$$"
    : > "$tmp"

    ls -1t "$CONF_DIR"/*.conf 2>/dev/null > "$tmp" || true

    if [ ! -s "$tmp" ]; then
        ui_msgbox "WARP генератор" "В каталоге нет .conf файлов:
$CONF_DIR"
        rm -f "$tmp"
        return 0
    fi

    ui_show_textbox "Последние конфиги" "$tmp" 24 100
    rm -f "$tmp"
}

main() {
    [ -x "$GENERATOR_SH" ] || chmod +x "$GENERATOR_SH" 2>/dev/null || true
    [ -x "$GENERATOR_SH" ] || die "Генератор не исполняемый: $GENERATOR_SH"
    # Host store (profile-generator): no mode toggle — always full menu.
    if [ -n "${XFREE_VPN_STORE_ID:-}" ]; then
        export XFREE_MENU_MODE=expert
    fi
    menu_mode_normalize

    while :; do
        srv="$(get_selected_server)"
        profile="$(get_selected_profile)"
        mode="$(get_selected_mode)"
        sel="$(get_selected_selection_mode)"
        exclude_ru="$(get_selected_exclude_ru)"
        awg_noise="$(get_selected_awg_noise)"
        i1_entropy="$(get_selected_i1_entropy)"
        i1_mode="$(get_selected_i1_mode)"
        i1_domain="$(get_selected_i1_domain)"
        name="$(get_selected_name)"
        [ -n "$name" ] || name="<авто>"

        hint="Генерация совместимого .conf

Сервер:  $(server_label "$srv") [$srv]
Выбор:   $(selection_mode_label "$sel") [$sel], RU=$(exclude_ru_label "$exclude_ru")
Профиль: $(profile_label "$profile") [$profile]
Шум:     $(awg_noise_label "$awg_noise")
Режим:   $(mode_label "$mode") [$mode]
Имя:     $name"
        if _menu_item_visible expert; then
            hint="$hint
I1:      $(i1_mode_label "$i1_mode") [$i1_mode], энтропия: $(awg_i1_entropy_label "$i1_entropy")
Seed:    ${i1_domain:-<не задан>}"
        fi

        set -- \
            "1" "Показать текущие параметры" \
            "2" "Выбрать сервер" \
            "10" "Выбор endpoint (топ-5 / случайный)" \
            "11" "Фильтр колоний RU" \
            "3" "Выбрать вариант AWG 2.0" \
            "12" "Шум AmneziaWG (Jc/Jmin/Jmax)" \
            "4" "Выбрать режим генерации"
        if _menu_item_visible expert; then
            set -- "$@" \
                "13" "Энтропия I1: $(awg_i1_entropy_label "$i1_entropy")" \
                "5" "Режим генерации I1" \
                "6" "Задать I1 domain/seed"
        fi
        set -- "$@" \
            "7" "Задать имя файла" \
            "8" "Сгенерировать конфиг" \
            "9" "Показать последние .conf" \
            "0" "Назад"

        choice="$(ui_menu "WARP генератор" "$hint" 28 90 14 "$@" || true)"

        case "${choice:-}" in
            1) show_status ;;
            2) select_server ;;
            10) select_selection_mode ;;
            11) select_exclude_ru ;;
            3) select_profile ;;
            12) select_awg_noise ;;
            4) select_mode ;;
            13) select_i1_entropy ;;
            5) select_i1_mode ;;
            6) edit_i1_domain ;;
            7) edit_name ;;
            8) generate_config ;;
            9) show_last_configs ;;
            0|"") break ;;
        esac
    done
}

main "$@"
