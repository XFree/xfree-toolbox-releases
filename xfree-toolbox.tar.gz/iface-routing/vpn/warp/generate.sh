#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
WG_MODE_SH="$VPN_DIR/lib/wg-mode.sh"
WARP_API_SH="$VPN_DIR/lib/warp-api.sh"
ENSURE_WG_TOOL_SH="$VPN_DIR/lib/ensure-wg-tool.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

[ -f "$WG_MODE_SH" ] || {
    echo "[-] Не найден wg-mode.sh: $WG_MODE_SH" >&2
    exit 1
}
. "$WG_MODE_SH"

[ -f "$WARP_API_SH" ] || {
    echo "[-] Не найден warp-api.sh: $WARP_API_SH" >&2
    exit 1
}
[ -f "$ENSURE_WG_TOOL_SH" ] || {
    echo "[-] Не найден ensure-wg-tool.sh: $ENSURE_WG_TOOL_SH" >&2
    exit 1
}
. "$WARP_API_SH"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"

if command -v load_base_config >/dev/null 2>&1; then
    load_base_config "$SCRIPT_DIR"
fi

if command -v load_module_config >/dev/null 2>&1; then
    load_module_config "$CONFIG_FILE"
elif [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
fi

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"
PROFILE_WARP_GENERATED_DIR="${PROFILE_WARP_GENERATED_DIR:-$(xfree_profile_warp_conf_dir "$PROFILE_DIR")}"
CONF_DIR="${CONF_DIR:-$PROFILE_WARP_GENERATED_DIR}"
RAW_DEFAULT_DNS="${RAW_DEFAULT_DNS:-1.1.1.1, 1.0.0.1, 2606:4700:4700::1111, 2606:4700:4700::1001}"
LOCAL_DEFAULT_DNS="${LOCAL_DEFAULT_DNS:-127.0.0.1}"
RAW_DEFAULT_ALLOWED_IPS="${RAW_DEFAULT_ALLOWED_IPS:-0.0.0.0/0, ::/0}"
LOCAL_DEFAULT_ALLOWED_IPS="${LOCAL_DEFAULT_ALLOWED_IPS:-0.0.0.0/0, ::/0}"
LOCAL_DEFAULT_PERSISTENT_KEEPALIVE="${LOCAL_DEFAULT_PERSISTENT_KEEPALIVE:-25}"
DEFAULT_SERVER="${DEFAULT_SERVER:-def}"
DEFAULT_VERSION="${DEFAULT_VERSION:-2.0}"
DEFAULT_VARIANT="${DEFAULT_VARIANT:-auto}"
DEFAULT_MODE="${DEFAULT_MODE:-local}"
DEFAULT_SELECTION_MODE="${DEFAULT_SELECTION_MODE:-best}"
DEFAULT_AWG_NOISE_ENABLED="${DEFAULT_AWG_NOISE_ENABLED:-1}"
DEFAULT_AWG_I1_ENTROPY="${DEFAULT_AWG_I1_ENTROPY:-off}"
WARP_EXCLUDE_RU="${WARP_EXCLUDE_RU:-1}"
WARP_PROBE_ATTEMPT_MAX="${WARP_PROBE_ATTEMPT_MAX:-50}"

QUIET=0
MODE="$DEFAULT_MODE"
SERVER="$DEFAULT_SERVER"
SELECTION_MODE="$DEFAULT_SELECTION_MODE"
EXCLUDE_RU="$WARP_EXCLUDE_RU"
MAX_SERVERS="$WARP_PROBE_ATTEMPT_MAX"
VERSION="$DEFAULT_VERSION"
VARIANT="$DEFAULT_VARIANT"
AWG_NOISE_ENABLED="$DEFAULT_AWG_NOISE_ENABLED"
AWG_I1_ENTROPY="$DEFAULT_AWG_I1_ENTROPY"
DNS=""
ALLOWED_IPS=""
NAME=""
ENDPOINT_OVERRIDE=""
I1_MODE="fixed"
I1_DOMAIN=""

usage() {
    cat <<EOF2
Usage:
  $(basename "$0") [options]

Options:
  --local
  --raw
  --server <xfree|def|FL|NL|PL|DE|LV|RU|lteFL|ltePL|lteDE>
  --best              топ-5 IP по колонии (/cdn-cgi/trace), самый быстрый
  --random            один случайный endpoint
  --exclude-ru        отбросить колонии DME/LED/KJA/SVX
  --allow-ru          не фильтровать колонии RU
  --max-servers <N>   макс. количество проверяемых серверов (по умолч. 50)
  --variant <1|2|3>
  --noise <0|1>       шум AmneziaWG (1 = Jc=4, Jmin=40, Jmax=70; 0 = Jc=0)
  --with-noise        включить шум AWG (по умолчанию включен)
  --no-noise          отключить шум AWG (Jc=0)
  --i1-entropy <mode> энтропия I1: off (по умолч.) | r32 | r64 | t | c | rc10 | rd6
  --with-i1-entropy   включить энтропию I1 (<r 32>)
  --no-i1-entropy     отключить энтропию I1 (по умолчанию)
  --i1-mode <fixed|random|domain>
  --i1-domain <seed>
  --dns <ip-list>
  --allowed-ips <cidr-list>
  --name <basename>
  --endpoint <host:port>
  --quiet
  -h, --help
EOF2
}

utc_now_iso() {
    date -u +"%Y-%m-%dT%H:%M:%SZ"
}

utc_now_compact() {
    date -u +"%Y%m%d-%H%M%SZ"
}

set_variant_base_params() {
    _v="$1"
    case "$_v" in auto|'') _v=1 ;; esac
    awg_set_variant_base_params "$_v"
}

reset_version_extensions() {
    AWG_HAS_S3=0
    AWG_HAS_S4=0
    AWG_S3=''
    AWG_S4=''
}

apply_awg20_extensions() {
    AWG_HAS_S3=1
    AWG_HAS_S4=1
    AWG_S3='0'
    AWG_S4='0'
}

variant_params() {
    variant="$1"

    reset_version_extensions
    set_variant_base_params "$variant"
    apply_awg20_extensions
}

sanitize_slug() {
    value="$1"
    value="$(common_lower_ascii "$value")"
    value="$(printf '%s' "$value" | tr -cs 'a-z0-9.' '-')"
    value="$(printf '%s' "$value" | sed 's/^-*//; s/-*$//; s/--*/-/g')"
    [ -n "$value" ] || value="na"
    printf '%s\n' "$value"
}

endpoint_host_part() {
    printf '%s\n' "$1" | sed 's/:.*$//'
}

endpoint_port_part() {
    printf '%s\n' "$1" | sed 's/^.*://'
}

endpoint_label() {
    ep="$1"
    host="$(endpoint_host_part "$ep")"
    case "$host" in
        engage.cloudflareclient.com) printf 'cf-edge' ;;
        162.159.192.*) printf 'cf-162-159-192' ;;
        162.159.195.*) printf 'cf-162-159-195' ;;
        *)
            host="$(printf '%s' "$host" | sed 's/\./-/g')"
            printf '%s' "$host"
            ;;
    esac
}

normalize_version() {
    case "$1" in
        2.0) printf '%s\n' "$1" ;;
        1.5) die "AWG 1.5 снят с поддержки; используйте AWG 2.0 (варианты 1–3)" ;;
        *) die "Неизвестная версия AWG: $1 (поддерживается только 2.0)" ;;
    esac
}

normalize_variant() {
    awg_normalize_variant "$1"
}

build_generated_name_base() {
    server_slug="$(sanitize_slug "$SERVER")"
    version_slug="awg$(sanitize_slug "$VERSION")"
    variant_slug="v$(sanitize_slug "$VARIANT")"
    endpoint_slug="$(sanitize_slug "$(endpoint_label "$ENDPOINT")")"
    mode_slug="$(sanitize_slug "$MODE")"

    printf 'warp-%s-%s-%s-%s-%s\n' \
        "$server_slug" \
        "$version_slug" \
        "$variant_slug" \
        "$endpoint_slug" \
        "$mode_slug"
}

pick_unique_name() {
    base="$1"
    stamp="$(utc_now_compact)"
    candidate="${base}-${stamp}"
    [ ! -f "$CONF_DIR/${candidate}.conf" ] && {
        printf '%s\n' "$candidate"
        return 0
    }

    seq=2
    while :; do
        candidate="${base}-${stamp}-${seq}"
        [ ! -f "$CONF_DIR/${candidate}.conf" ] && {
            printf '%s\n' "$candidate"
            return 0
        }
        seq=$((seq + 1))
    done
}

write_conf() {
    outfile="$1"
    : > "$outfile"

    write_common_local_comment_block "$outfile"

    {
        printf '[Interface]\n'
        printf 'PrivateKey=%s\n' "$WARP_GEN_PRIV"
        printf 'MTU=1280\n'
        if [ -n "$CF_IPV6" ]; then
            printf 'Address=%s, %s\n' "$CF_IPV4" "$CF_IPV6"
        else
            printf 'Address=%s\n' "$CF_IPV4"
        fi
        printf 'DNS=%s\n' "$DNS"
        printf 'S1=%s\n' "$AWG_S1"
        printf 'S2=%s\n' "$AWG_S2"
        [ "${AWG_HAS_S3:-0}" = "1" ] && printf 'S3=%s\n' "$AWG_S3"
        [ "${AWG_HAS_S4:-0}" = "1" ] && printf 'S4=%s\n' "$AWG_S4"
        printf 'Jc=%s\n' "$AWG_JC"
        printf 'Jmin=%s\n' "$AWG_JMIN"
        printf 'Jmax=%s\n' "$AWG_JMAX"
        printf 'H1=%s\n' "$AWG_H1"
        printf 'H2=%s\n' "$AWG_H2"
        printf 'H3=%s\n' "$AWG_H3"
        printf 'H4=%s\n' "$AWG_H4"
        printf 'I1=%s\n' "$AWG_I1"
        [ -n "$AWG_I2" ] && printf 'I2=%s\n' "$AWG_I2"
        printf '\n[Peer]\n'
        printf 'PublicKey=%s\n' "$CF_PEER_PUBLIC_KEY"
        printf 'AllowedIPs=%s\n' "$ALLOWED_IPS"
        printf 'Endpoint=%s\n' "$ENDPOINT"
        [ -n "$PERSISTENT_KEEPALIVE" ] && printf 'PersistentKeepalive=%s\n' "$PERSISTENT_KEEPALIVE"
    } >> "$outfile"
}

write_meta() {
    meta_file="$1"
    warp_list_city="$(endpoint_label "$ENDPOINT")"
    {
        printf "NAME_SCHEMA_VERSION='7'\n"
        printf "GENERATOR_POLICY_VERSION='%s'\n" "${WARP_GENERATOR_POLICY_VERSION:-1}"
        printf "GENERATOR_KIND='warp'\n"
        printf "PROFILE_BASENAME='%s'\n" "$NAME"
        printf "PROFILE_LABEL='%s'\n" "$PROFILE_LABEL"
        printf "PROFILE_MODE='%s'\n" "$MODE"
        printf "SERVER_ID='%s'\n" "$SERVER"
        printf "SERVER_NAME='%s'\n" "$(common_upper_ascii "$SERVER")"
        printf "SERVER_COUNTRY='%s'\n" "Cloudflare"
        printf "SERVER_CITY='%s'\n" "$warp_list_city"
        printf "COUNTRY_FILTER='%s'\n" "$(common_upper_ascii "$SERVER")"
        printf "AWG_VERSION='%s'\n" "$VERSION"
        printf "VARIANT_ID='%s'\n" "$VARIANT"
        printf "AWG_NOISE_ENABLED='%s'\n" "$AWG_NOISE_ENABLED"
        printf "AWG_I1_ENTROPY='%s'\n" "$AWG_I1_ENTROPY"
        case "$AWG_I1_ENTROPY" in
            off) printf "AWG_I1_ENTROPY_ENABLED='0'\n" ;;
            *)   printf "AWG_I1_ENTROPY_ENABLED='1'\n" ;;
        esac
        printf "I1_MODE='%s'\n" "$I1_MODE"
        [ -n "$I1_DOMAIN" ] && printf "I1_DOMAIN='%s'\n" "$I1_DOMAIN"
        printf "ENDPOINT='%s'\n" "$ENDPOINT"
        printf "ENDPOINT_HOST='%s'\n" "$(endpoint_host_part "$ENDPOINT")"
        printf "ENDPOINT_PORT='%s'\n" "$(endpoint_port_part "$ENDPOINT")"
        printf "ENDPOINT_LABEL='%s'\n" "$(endpoint_label "$ENDPOINT")"
        printf "SELECTION_MODE='%s'\n" "$SELECTION_MODE"
        printf "EXCLUDE_RU='%s'\n" "$EXCLUDE_RU"
        printf "MAX_SERVERS='%s'\n" "$MAX_SERVERS"
        [ -n "${WARP_PROBE_ROUNDS:-}" ] && printf "PROBE_ROUNDS='%s'\n" "$WARP_PROBE_ROUNDS"
        [ -n "${WARP_PROBE_TOP_N:-}" ] && printf "PROBE_TOP_N='%s'\n" "$WARP_PROBE_TOP_N"
        [ -n "${WARP_SELECTED_COLO:-}" ] && printf "ENDPOINT_COLO='%s'\n" "$WARP_SELECTED_COLO"
        [ -n "${WARP_SELECTED_LOC:-}" ] && printf "ENDPOINT_LOC='%s'\n" "$WARP_SELECTED_LOC"
        [ -n "${WARP_SELECTED_MS:-}" ] && printf "ENDPOINT_PROBE_MS='%s'\n" "$WARP_SELECTED_MS"
        case "$SERVER" in
            xfree|def)
                printf "DEF_ENDPOINT_POLICY='%s'\n" "$(warp_def_endpoint_policy "$SERVER")"
                ;;
        esac
        printf "DNS_VALUE='%s'\n" "$DNS"
        printf "ALLOWED_IPS='%s'\n" "$ALLOWED_IPS"
        printf "PERSISTENT_KEEPALIVE='%s'\n" "$PERSISTENT_KEEPALIVE"
        printf "ORIGINAL_DNS_VALUE='%s'\n" "$ORIGINAL_DNS"
        printf "ORIGINAL_ALLOWED_IPS='%s'\n" "$ORIGINAL_ALLOWED_IPS"
        printf "ORIGINAL_PERSISTENT_KEEPALIVE='%s'\n" "$ORIGINAL_PERSISTENT_KEEPALIVE"
        printf "GENERATED_AT_UTC='%s'\n" "$(utc_now_iso)"
    } > "$meta_file"
}

while [ $# -gt 0 ]; do
    case "$1" in
        --local) MODE="local" ;;
        --raw) MODE="raw" ;;
        --server) shift; SERVER="${1:-}" ;;
        --best) SELECTION_MODE="best" ;;
        --random) SELECTION_MODE="random" ;;
        --exclude-ru) EXCLUDE_RU="1" ;;
        --allow-ru) EXCLUDE_RU="0" ;;
        --max-servers) shift; MAX_SERVERS="${1:-50}" ;;
        --rounds) shift; WARP_PROBE_ROUNDS="${1:-5}" ;;
        --top-n) shift; WARP_PROBE_TOP_N="${1:-3}" ;;
        --version)
            die "Параметр --version устарел: WARP-генератор всегда использует AWG 2.0; укажите только --variant 1|2|3"
            ;;
        --variant) shift; VARIANT="${1:-}" ;;
        --noise) shift; AWG_NOISE_ENABLED="${1:-1}" ;;
        --with-noise) AWG_NOISE_ENABLED=1 ;;
        --no-noise) AWG_NOISE_ENABLED=0 ;;
        --i1-entropy) shift; AWG_I1_ENTROPY="${1:-off}" ;;
        --with-i1-entropy) AWG_I1_ENTROPY=r32 ;;
        --no-i1-entropy) AWG_I1_ENTROPY=off ;;
        --i1-mode) shift; I1_MODE="${1:-}" ;;
        --i1-domain) shift; I1_DOMAIN="${1:-}" ;;
        --dns) shift; DNS="${1:-}" ;;
        --allowed-ips) shift; ALLOWED_IPS="${1:-}" ;;
        --name) shift; NAME="${1:-}" ;;
        --endpoint) shift; ENDPOINT_OVERRIDE="${1:-}" ;;
        --quiet) QUIET=1 ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
    shift || true
done

case "$MAX_SERVERS" in
    ''|*[!0-9]*) MAX_SERVERS=50 ;;
esac
[ "$MAX_SERVERS" -gt 0 ] 2>/dev/null || MAX_SERVERS=50
WARP_PROBE_ATTEMPT_MAX="$MAX_SERVERS"
export WARP_PROBE_ROUNDS WARP_PROBE_TOP_N WARP_PROBE_ATTEMPT_MAX

MODE="$(normalize_mode "$MODE")"
VERSION="$(normalize_version "$VERSION")"
VARIANT="$(normalize_variant "$VARIANT")"
SERVER="$(warp_normalize_server "$SERVER")"
case "$SELECTION_MODE" in
    best|random) ;;
    *) die "Неизвестный режим выбора endpoint: $SELECTION_MODE (best|random)" ;;
esac
case "$EXCLUDE_RU" in
    1|yes|on|true) EXCLUDE_RU="1" ;;
    0|no|off|false) EXCLUDE_RU="0" ;;
    *) die "WARP_EXCLUDE_RU: ожидается 1 или 0" ;;
esac
WARP_EXCLUDE_RU="$EXCLUDE_RU"

info_err "WARP: проверка наличия wg/awg..."
sh "$ENSURE_WG_TOOL_SH" --install-if-missing >&2

require_cmd curl
require_cmd date
vpn_json_require_parser
mkdir -p "$CONF_DIR"

info_err "WARP: генерация новой пары ключей WireGuard..."
warp_generate_keys

info_err "WARP: регистрация клиента в Cloudflare WARP API..."
_reg_err_file="${TMPDIR:-/tmp}/warp-reg-err.$$"
if ! REG_RESP="$(warp_register "$WARP_GEN_PUB" 2>"$_reg_err_file")"; then
    _curl_err="$(cat "$_reg_err_file" 2>/dev/null || true)"
    rm -f "$_reg_err_file"
    case "$_curl_err" in
        *429*) die "Cloudflare API временно ограничил запросы на регистрацию (HTTP 429 Too Many Requests). Подождите 1–2 минуты перед повторной попыткой." ;;
        *) die "Не удалось зарегистрировать клиента в Cloudflare WARP API: ${_curl_err:-ошибка соединения}" ;;
    esac
fi
rm -f "$_reg_err_file"

CF_CLIENT_ID="$(warp_json_get "$REG_RESP" '@.result.id')"
CF_TOKEN="$(warp_json_get "$REG_RESP" '@.result.token')"

[ -n "$CF_CLIENT_ID" ] || die "Не удалось получить result.id от Cloudflare WARP API"
[ -n "$CF_TOKEN" ] || die "Не удалось получить result.token от Cloudflare WARP API"

info_err "WARP: активация учетной записи в Cloudflare..."
_enable_err_file="${TMPDIR:-/tmp}/warp-enable-err.$$"
if ! WARP_RESP="$(warp_enable "$CF_CLIENT_ID" "$CF_TOKEN" 2>"$_enable_err_file")"; then
    _curl_err="$(cat "$_enable_err_file" 2>/dev/null || true)"
    rm -f "$_enable_err_file"
    die "Не удалось активировать учетную запись в Cloudflare: ${_curl_err:-ошибка}"
fi
rm -f "$_enable_err_file"

CF_PEER_PUBLIC_KEY="$(warp_json_get "$WARP_RESP" '@.result.config.peers[0].public_key')"
CF_IPV4="$(warp_json_get "$WARP_RESP" '@.result.config.interface.addresses.v4')"
CF_IPV6="$(warp_json_get "$WARP_RESP" '@.result.config.interface.addresses.v6')"

[ -n "$CF_PEER_PUBLIC_KEY" ] || die "Не удалось получить public_key peer от Cloudflare"
[ -n "$CF_IPV4" ] || die "Не удалось получить IPv4 интерфейса от Cloudflare"

info_err "WARP: регистрация завершена успешно (IPv4: $CF_IPV4${CF_IPV6:+, IPv6: $CF_IPV6})"

export WARP_PEER_PUBLIC_KEY="$CF_PEER_PUBLIC_KEY"

variant_params "$VARIANT"
awg_apply_i1_mode
AWG_NOISE_ENABLED="$(awg_normalize_noise_enabled "$AWG_NOISE_ENABLED" 1)"
AWG_I1_ENTROPY="$(awg_normalize_i1_entropy "$AWG_I1_ENTROPY" off)"
awg_apply_noise_mode "$AWG_NOISE_ENABLED"
awg_apply_i1_entropy "$AWG_I1_ENTROPY"
export AWG_NOISE_ENABLED AWG_I1_ENTROPY

WARP_SELECTED_COLO=""
WARP_SELECTED_LOC=""
WARP_SELECTED_MS=""
if [ -n "$ENDPOINT_OVERRIDE" ]; then
    ENDPOINT="$ENDPOINT_OVERRIDE"
elif [ "$SELECTION_MODE" = "best" ]; then
    warp_select_endpoint_best "$SERVER"
else
    ENDPOINT="$(warp_build_endpoint "$SERVER")"
fi

ORIGINAL_DNS="$RAW_DEFAULT_DNS"
ORIGINAL_ALLOWED_IPS="$RAW_DEFAULT_ALLOWED_IPS"
ORIGINAL_PERSISTENT_KEEPALIVE=""
apply_mode_overrides

if [ -z "$NAME" ]; then
    NAME_BASE="$(build_generated_name_base)"
    NAME="$(pick_unique_name "$NAME_BASE")"
else
    NAME="$(sanitize_slug "$NAME")"
    [ -n "$NAME" ] || die "Имя после очистки пустое"
fi

PROFILE_LABEL="mode=$MODE server=$SERVER awg=$VERSION variant=$VARIANT endpoint=$(endpoint_label "$ENDPOINT") dns=$DNS"

OUTFILE="$CONF_DIR/${NAME}.conf"
METAFILE="$CONF_DIR/${NAME}.conf.meta"

info "Запись конфигурации: $OUTFILE"
write_conf "$OUTFILE"

info "Запись метаданных: $METAFILE"
write_meta "$METAFILE"

success "Конфигурация создана: $OUTFILE"
printf 'SOURCE=%s\n' "$OUTFILE"
printf 'META=%s\n' "$METAFILE"
printf 'NAME=%s\n' "$NAME"
printf 'MODE=%s\n' "$MODE"
printf 'SERVER=%s\n' "$SERVER"
printf 'AWG_VERSION=%s\n' "$VERSION"
printf 'VARIANT=%s\n' "$VARIANT"
printf 'AWG_NOISE_ENABLED=%s\n' "$AWG_NOISE_ENABLED"
printf 'AWG_I1_ENTROPY=%s\n' "$AWG_I1_ENTROPY"
printf 'ENDPOINT=%s\n' "$ENDPOINT"
