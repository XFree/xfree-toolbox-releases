#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
WG_MODE_SH="$VPN_DIR/lib/wg-mode.sh"
WARP_API_SH="$VPN_DIR/lib/warp-api.sh"
ENSURE_WG_TOOL_SH="$VPN_DIR/lib/ensure-wg-tool.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

[ -f "$WG_MODE_SH" ] || {
    echo "[-] Не найден wg-mode.sh: $WG_MODE_SH" >&2
    exit 1
}
. "$WG_MODE_SH"

[ -f "$WARP_API_SH" ] || {
    echo "[-] Не найден warp-api.sh: $WARP_API_SH" >&2
    exit 1
}
[ -f "$ENSURE_WG_TOOL_SH" ] || {
    echo "[-] Не найден ensure-wg-tool.sh: $ENSURE_WG_TOOL_SH" >&2
    exit 1
}
. "$WARP_API_SH"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"

if command -v load_base_config >/dev/null 2>&1; then
    load_base_config "$SCRIPT_DIR"
fi

if command -v load_module_config >/dev/null 2>&1; then
    load_module_config "$CONFIG_FILE"
elif [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
fi

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"
PROFILE_WARP_GENERATED_DIR="${PROFILE_WARP_GENERATED_DIR:-$(xfree_profile_warp_conf_dir "$PROFILE_DIR")}"
CONF_DIR="${CONF_DIR:-$PROFILE_WARP_GENERATED_DIR}"
RAW_DEFAULT_DNS="${RAW_DEFAULT_DNS:-1.1.1.1, 1.0.0.1, 2606:4700:4700::1111, 2606:4700:4700::1001}"
LOCAL_DEFAULT_DNS="${LOCAL_DEFAULT_DNS:-127.0.0.1}"
RAW_DEFAULT_ALLOWED_IPS="${RAW_DEFAULT_ALLOWED_IPS:-0.0.0.0/0, ::/0}"
LOCAL_DEFAULT_ALLOWED_IPS="${LOCAL_DEFAULT_ALLOWED_IPS:-0.0.0.0/0, ::/0}"
LOCAL_DEFAULT_PERSISTENT_KEEPALIVE="${LOCAL_DEFAULT_PERSISTENT_KEEPALIVE:-25}"
DEFAULT_SERVER="${DEFAULT_SERVER:-xfree}"
DEFAULT_VERSION="${DEFAULT_VERSION:-2.0}"
DEFAULT_VARIANT="${DEFAULT_VARIANT:-1}"
DEFAULT_MODE="${DEFAULT_MODE:-local}"

QUIET=0
MODE="$DEFAULT_MODE"
SERVER="$DEFAULT_SERVER"
VERSION="$DEFAULT_VERSION"
VARIANT="$DEFAULT_VARIANT"
DNS=""
ALLOWED_IPS=""
NAME=""
ENDPOINT_OVERRIDE=""
I1_MODE="fixed"
I1_DOMAIN=""

usage() {
    cat <<EOF2
Usage:
  $(basename "$0") [options]

Options:
  --local
  --raw
  --server <xfree|def|FL|NL|PL|DE|LV|RU>
  --variant <1|2|3>
  --i1-mode <fixed|random|domain>
  --i1-domain <seed>
  --dns <ip-list>
  --allowed-ips <cidr-list>
  --name <basename>
  --endpoint <host:port>
  --quiet
  -h, --help
EOF2
}

utc_now_iso() {
    date -u +"%Y-%m-%dT%H:%M:%SZ"
}

utc_now_compact() {
    date -u +"%Y%m%d-%H%M%SZ"
}

set_variant_base_params() {
    case "$1" in
        1)
            AWG_S1="0"
            AWG_S2="0"
            AWG_JC="4"
            AWG_JMIN="40"
            AWG_JMAX="70"
            AWG_H1="1"
            AWG_H2="2"
            AWG_H3="3"
            AWG_H4="4"
            AWG_I1='<b 0xce000000010897a297ecc34cd6dd000044d0ec2e2e1ea2991f467ace4222129b5a098823784694b4897b9986ae0b7280135fa85e196d9ad980b150122129ce2a9379531b0fd3e871ca5fdb883c369832f730e272d7b8b74f393f9f0fa43f11e510ecb2219a52984410c204cf875585340c62238e14ad04dff382f2c200e0ee22fe743b9c6b8b043121c5710ec289f471c91ee414fca8b8be8419ae8ce7ffc53837f6ade262891895f3f4cecd31bc93ac5599e18e4f01b472362b8056c3172b513051f8322d1062997ef4a383b01706598d08d48c221d30e74c7ce000cdad36b706b1bf9b0607c32ec4b3203a4ee21ab64df336212b9758280803fcab14933b0e7ee1e04a7becce3e2633f4852585c567894a5f9efe9706a151b615856647e8b7dba69ab357b3982f554549bef9256111b2d67afde0b496f16962d4957ff654232aa9e845b61463908309cfd9de0a6abf5f425f577d7e5f6440652aa8da5f73588e82e9470f3b21b27b28c649506ae1a7f5f15b876f56abc4615f49911549b9bb39dd804fde182bd2dcec0c33bad9b138ca07d4a4a1650a2c2686acea05727e2a78962a840ae428f55627516e73c83dd8893b02358e81b524b4d99fda6df52b3a8d7a5291326e7ac9d773c5b43b8444554ef5aea104a738ed650aa979674bbed38da58ac29d87c29d387d80b526065baeb073ce65f075ccb56e47533aef357dceaa8293a523c5f6f790be90e4731123d3c6152a70576e90b4ab5bc5ead01576c68ab633ff7d36dcde2a0b2c68897e1acfc4d6483aaaeb635dd63c96b2b6a7a2bfe042f6aed82e5363aa850aace12ee3b1a93f30d8ab9537df483152a5527faca21efc9981b304f11fc95336f5b9637b174c5a0659e2b22e159a9fed4b8e93047371175b1d6d9cc8ab745f3b2281537d1c75fb9451871864efa5d184c38c185fd203de206751b92620f7c369e031d2041e152040920ac2c5ab5340bfc9d0561176abf10a147287ea90758575ac6a9f5ac9f390d0d5b23ee12af583383d994e22c0cf42383834bcd3ada1b3825a0664d8f3fb678261d57601ddf94a8a68a7c273a18c08aa99c7ad8c6c42eab67718843597ec9930457359dfdfbce024afc2dcf9348579a57d8d3490b2fa99f278f1c37d87dad9b221acd575192ffae1784f8e60ec7cee4068b6b988f0433d96d6a1b1865f4e155e9fe020279f434f3bf1bd117b717b92f6cd1cc9bea7d45978bcc3f24bda631a36910110a6ec06da35f8966c9279d130347594f13e9e07514fa370754d1424c0a1545c5070ef9fb2acd14233e8a50bfc5978b5bdf8bc1714731f798d21e2004117c61f2989dd44f0cf027b27d4019e81ed4b5c31db347c4a3a4d85048d7093cf16753d7b0d15e078f5c7a5205dc2f87e330a1f716738dce1c6180e9d02869b5546f1c4d2748f8c90d9693cba4e0079297d22fd61402dea32ff0eb69ebd65a5d0b687d87e3a8b2c42b648aa723c7c7daf37abcc4bb85caea2ee8f55bec20e913b3324ab8f5c3304f820d42ad1b9f2ffc1a3af9927136b4419e1e579ab4c2ae3c776d293d397d575df181e6cae0a4ada5d67ecea171cca3288d57c7bbdaee3befe745fb7d634f70386d873b90c4d6c6596bb65af68f9e5121e67ebf0d89d3c909ceedfb32ce9575a7758ff080724e1ab5d5f43074ecb53a479af21ed03d7b6899c36631c0166f9d47e5e1d4528a5d3d3f744029c4b1c190cbfbad06f5f83f7ad0429fa9a2719c56ffe3783460e166de2d8>'
            AWG_I2=""
            ;;
        2)
            AWG_S1="0"
            AWG_S2="0"
            AWG_JC="4"
            AWG_JMIN="40"
            AWG_JMAX="70"
            AWG_H1="1"
            AWG_H2="2"
            AWG_H3="3"
            AWG_H4="4"
            AWG_I1='<b 0xc7000000010809a1ed4edbbe7615000044d017a61a0d774f04290f119e701ef0035df2b0ed571b0b575e6a07246b856eb6ec036fef07f1e07b861251ad737abeb67e64be714c1dcd865312b1b6c35c089c997aeb5c18f808696fe97289513945d84ca846467603e94e44224877f2c1d3261e4ac18740be4bd064369c94fc08978d99b54bf615250998639010c1284248e1d73004b81fcb20b559d8a17eced7eab3964b5b88ca7a3b8579fc8c1c934189e77143b4ac434138114b1048651b56545b87acbef0952763538f3ddeb37cfc6d58b4881c3b719d7ff78f6ee1324a2914a32381c05a64c700466d280be007253bb030d179c4f1b3dc221e1974e2ee6d6e2b9e8d709159b5ef22e1783dbba845c20ca1c83b066c73835920ad70b806df0aee0351e3fc9ab1e42e8b2a30fe235ff0612eee19744949cecee0463b76514ad90c1f7ceaa557c18586ab561d49482e73c85d0143785da14a441bf82f78783b61cccd44aecb1947516e79b5ca5a6b3a8aed6040fae0eeabdc55a88dc19ade832d99fca90c7a629cacc07192d7e47e3c6a271b95b0ea3392562a06a1cab79f40ea92916ebee197b7b5f14b251824e1ed20ff2ca80b1f03a43e45157589bc61b978e97851025b3b7ccc17d291e1cb60fe48a5c26829dce11dd23c2e73265a9ebf8617c985e4fee4681e863f990061f4dea465a7d2524bd0edcf4b48d4b8f25fc359b15babd2637284a4774077dca60091f1a781cfee1bef9713dd5943a579d7470bc5970542fbb27fdf77880a8d8751b1f642c7a3f019a05ab94bf63d3525ef34e9290b5c8d477f2714e6d6e3e4d35c1983f5e16fda57fcdf071b513f8f088dbe8d5a97577d17a5383a496c3f313adfdd47c962bbaebd6aa13b46439eb742622c29ca067db0ec1853064c3cbbffe0a215a19fce47d49703ed58ebbd89721172d256d1cf30188106fb2f863186511401fad54d087aa2fb3d1b85768db386bd7102e8060ac157bac011acdcdae2799b9aee1467c3424013455bd028fcaacdc3c77d28ea199967d617ea7d0d0815f3cc407934a76d1293dccba210d1709a13e5dd67c9ba47cd113f5bdd740358eff13164159fd09bc2f7ec6cfa64d9df7e2e2f88706b0ff3a92ccf6f078456cfe0bdd89292cfe2680badc1eac9f7d36efe8eb6912c7b164508d13e6c0911c15f73c233cbe4fc70ff2ade1e1be4bbb738e0939159e2078a9438f05b756a003371f4861481c38f1cdd2d7b06deb62869e9fe79a8abaa920646fa2e8fa28f0d80c136376c7b56046bae4c05c0cdf64efb8c47bbfc5a1a4c0b045061ef0d71618e0d206a1d7f245fd5c03191b152673ba8dff8e1b8de7c50234a93cba91e3888adb228cc02beded4b1c0946797d3ef02dec2edb6ad0ac21f89f4be364c317da7c22440e9f358d512203f4b7ab20388af68b8915d0152db2c8a0687bfaea870f7529bb92a22b35bd79bc6d490591406346ecd78342ee3563c4883a8251679691c2d4e963397e24653520795511b018915374c954bddb940a9d7a16d1c8bd798fc7dbfb0599a7074e13f87e14efa8d511bb2579ec029b1bda18fe971b30fbe19e986ff2686a69bf3f1bb929de93ae70345ebca998b11e0a2b41890cba628d8f6e7c4e94790735e5299b4ff07cd3080f7d53c9cbe1911d2cd5925b3213e033c272506a87886cf761a283a779564d3241e3c28f632e166b5d756e1786ce077614c4444e3f2aed5decb3613b925ea3e558c21d4faf8ba54edd0f3a5d4>'
            AWG_I2=""
            ;;
        3)
            AWG_S1="0"
            AWG_S2="0"
            AWG_JC="4"
            AWG_JMIN="40"
            AWG_JMAX="70"
            AWG_H1="1"
            AWG_H2="2"
            AWG_H3="3"
            AWG_H4="4"
            AWG_I1='<b 0x494e56495445207369703a626f624062696c6f78692e636f6d205349502f322e300d0a5669613a205349502f322e302f55445020706333332e61746c616e74612e636f6d3b6272616e63683d7a39684734624b3737366173646864730d0a4d61782d466f7277617264733a2037300d0a546f3a20426f62203c7369703a626f624062696c6f78692e636f6d3e0d0a46726f6d3a20416c696365203c7369703a616c6963654061746c616e74612e636f6d3e3b7461673d313932383330313737340d0a43616c6c2d49443a20613834623463373665363637313040706333332e61746c616e74612e636f6d0d0a435365713a2033313431353920494e564954450d0a436f6e746163743a203c7369703a616c69636540706333332e61746c616e74612e636f6d3e0d0a436f6e74656e742d547970653a206170706c69636174696f6e2f7364700d0a436f6e74656e742d4c656e6774683a20300d0a0d0a>'
            AWG_I2='<b 0x5349502f322e302031303020547279696e670d0a5669613a205349502f322e302f55445020706333332e61746c616e74612e636f6d3b6272616e63683d7a39684734624b3737366173646864730d0a546f3a20426f62203c7369703a626f624062696c6f78692e636f6d3e0d0a46726f6d3a20416c696365203c7369703a616c6963654061746c616e74612e636f6d3e3b7461673d313932383330313737340d0a43616c6c2d49443a20613834623463373665363637313040706333332e61746c616e74612e636f6d0d0a435365713a2033313431353920494e564954450d0a436f6e74656e742d4c656e6774683a20300d0a0d0a>'
            ;;
        *)
            die "Неизвестный вариант: $1"
            ;;
    esac
}

reset_version_extensions() {
    AWG_HAS_S3=0
    AWG_HAS_S4=0
    AWG_S3=''
    AWG_S4=''
}

apply_awg20_extensions() {
    AWG_HAS_S3=1
    AWG_HAS_S4=1
    AWG_S3='0'
    AWG_S4='0'
}

variant_params() {
    variant="$1"

    reset_version_extensions
    set_variant_base_params "$variant"
    apply_awg20_extensions
}

sanitize_slug() {
    value="$1"
    value="$(common_lower_ascii "$value")"
    value="$(printf '%s' "$value" | tr -cs 'a-z0-9.' '-')"
    value="$(printf '%s' "$value" | sed 's/^-*//; s/-*$//; s/--*/-/g')"
    [ -n "$value" ] || value="na"
    printf '%s\n' "$value"
}

endpoint_host_part() {
    printf '%s\n' "$1" | sed 's/:.*$//'
}

endpoint_port_part() {
    printf '%s\n' "$1" | sed 's/^.*://'
}

endpoint_label() {
    ep="$1"
    host="$(endpoint_host_part "$ep")"
    case "$host" in
        engage.cloudflareclient.com) printf 'cf-edge' ;;
        162.159.192.*) printf 'cf-162-159-192' ;;
        162.159.195.*) printf 'cf-162-159-195' ;;
        *)
            host="$(printf '%s' "$host" | sed 's/\./-/g')"
            printf '%s' "$host"
            ;;
    esac
}

normalize_version() {
    case "$1" in
        2.0) printf '%s\n' "$1" ;;
        1.5) die "AWG 1.5 снят с поддержки; используйте AWG 2.0 (варианты 1–3)" ;;
        *) die "Неизвестная версия AWG: $1 (поддерживается только 2.0)" ;;
    esac
}

normalize_variant() {
    case "$1" in
        1|2|3) printf '%s\n' "$1" ;;
        *) die "Неизвестный вариант AWG: $1" ;;
    esac
}

build_generated_name_base() {
    server_slug="$(sanitize_slug "$SERVER")"
    version_slug="awg$(sanitize_slug "$VERSION")"
    variant_slug="v$(sanitize_slug "$VARIANT")"
    endpoint_slug="$(sanitize_slug "$(endpoint_label "$ENDPOINT")")"
    mode_slug="$(sanitize_slug "$MODE")"

    printf 'warp-%s-%s-%s-%s-%s\n' \
        "$server_slug" \
        "$version_slug" \
        "$variant_slug" \
        "$endpoint_slug" \
        "$mode_slug"
}

pick_unique_name() {
    base="$1"
    stamp="$(utc_now_compact)"
    candidate="${base}-${stamp}"
    [ ! -f "$CONF_DIR/${candidate}.conf" ] && {
        printf '%s\n' "$candidate"
        return 0
    }

    seq=2
    while :; do
        candidate="${base}-${stamp}-${seq}"
        [ ! -f "$CONF_DIR/${candidate}.conf" ] && {
            printf '%s\n' "$candidate"
            return 0
        }
        seq=$((seq + 1))
    done
}

write_conf() {
    outfile="$1"
    : > "$outfile"

    write_common_local_comment_block "$outfile"

    {
        printf '[Interface]\n'
        printf 'PrivateKey=%s\n' "$WARP_GEN_PRIV"
        printf 'MTU=1280\n'
        if [ -n "$CF_IPV6" ]; then
            printf 'Address=%s, %s\n' "$CF_IPV4" "$CF_IPV6"
        else
            printf 'Address=%s\n' "$CF_IPV4"
        fi
        printf 'DNS=%s\n' "$DNS"
        printf 'S1=%s\n' "$AWG_S1"
        printf 'S2=%s\n' "$AWG_S2"
        [ "${AWG_HAS_S3:-0}" = "1" ] && printf 'S3=%s\n' "$AWG_S3"
        [ "${AWG_HAS_S4:-0}" = "1" ] && printf 'S4=%s\n' "$AWG_S4"
        printf 'Jc=%s\n' "$AWG_JC"
        printf 'Jmin=%s\n' "$AWG_JMIN"
        printf 'Jmax=%s\n' "$AWG_JMAX"
        printf 'H1=%s\n' "$AWG_H1"
        printf 'H2=%s\n' "$AWG_H2"
        printf 'H3=%s\n' "$AWG_H3"
        printf 'H4=%s\n' "$AWG_H4"
        printf 'I1=%s\n' "$AWG_I1"
        [ -n "$AWG_I2" ] && printf 'I2=%s\n' "$AWG_I2"
        printf '\n[Peer]\n'
        printf 'PublicKey=%s\n' "$CF_PEER_PUBLIC_KEY"
        printf 'AllowedIPs=%s\n' "$ALLOWED_IPS"
        printf 'Endpoint=%s\n' "$ENDPOINT"
        [ -n "$PERSISTENT_KEEPALIVE" ] && printf 'PersistentKeepalive=%s\n' "$PERSISTENT_KEEPALIVE"
    } >> "$outfile"
}

write_meta() {
    meta_file="$1"
    warp_list_city="$(endpoint_label "$ENDPOINT")"
    {
        printf "NAME_SCHEMA_VERSION='7'\n"
        printf "GENERATOR_KIND='warp'\n"
        printf "PROFILE_BASENAME='%s'\n" "$NAME"
        printf "PROFILE_LABEL='%s'\n" "$PROFILE_LABEL"
        printf "PROFILE_MODE='%s'\n" "$MODE"
        printf "SERVER_ID='%s'\n" "$SERVER"
        printf "SERVER_NAME='%s'\n" "$(common_upper_ascii "$SERVER")"
        printf "SERVER_COUNTRY='%s'\n" "Cloudflare"
        printf "SERVER_CITY='%s'\n" "$warp_list_city"
        printf "COUNTRY_FILTER='%s'\n" "$(common_upper_ascii "$SERVER")"
        printf "AWG_VERSION='%s'\n" "$VERSION"
        printf "VARIANT_ID='%s'\n" "$VARIANT"
        printf "I1_MODE='%s'\n" "$I1_MODE"
        [ -n "$I1_DOMAIN" ] && printf "I1_DOMAIN='%s'\n" "$I1_DOMAIN"
        printf "ENDPOINT='%s'\n" "$ENDPOINT"
        printf "ENDPOINT_HOST='%s'\n" "$(endpoint_host_part "$ENDPOINT")"
        printf "ENDPOINT_PORT='%s'\n" "$(endpoint_port_part "$ENDPOINT")"
        printf "ENDPOINT_LABEL='%s'\n" "$(endpoint_label "$ENDPOINT")"
        case "$SERVER" in
            xfree|def)
                printf "DEF_ENDPOINT_POLICY='%s'\n" "$(warp_def_endpoint_policy "$SERVER")"
                ;;
        esac
        printf "DNS_VALUE='%s'\n" "$DNS"
        printf "ALLOWED_IPS='%s'\n" "$ALLOWED_IPS"
        printf "PERSISTENT_KEEPALIVE='%s'\n" "$PERSISTENT_KEEPALIVE"
        printf "ORIGINAL_DNS_VALUE='%s'\n" "$ORIGINAL_DNS"
        printf "ORIGINAL_ALLOWED_IPS='%s'\n" "$ORIGINAL_ALLOWED_IPS"
        printf "ORIGINAL_PERSISTENT_KEEPALIVE='%s'\n" "$ORIGINAL_PERSISTENT_KEEPALIVE"
        printf "GENERATED_AT_UTC='%s'\n" "$(utc_now_iso)"
    } > "$meta_file"
}

while [ $# -gt 0 ]; do
    case "$1" in
        --local) MODE="local" ;;
        --raw) MODE="raw" ;;
        --server) shift; SERVER="${1:-}" ;;
        --version)
            die "Параметр --version устарел: WARP-генератор всегда использует AWG 2.0; укажите только --variant 1|2|3"
            ;;
        --variant) shift; VARIANT="${1:-}" ;;
        --i1-mode) shift; I1_MODE="${1:-}" ;;
        --i1-domain) shift; I1_DOMAIN="${1:-}" ;;
        --dns) shift; DNS="${1:-}" ;;
        --allowed-ips) shift; ALLOWED_IPS="${1:-}" ;;
        --name) shift; NAME="${1:-}" ;;
        --endpoint) shift; ENDPOINT_OVERRIDE="${1:-}" ;;
        --quiet) QUIET=1 ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
    shift || true
done

MODE="$(normalize_mode "$MODE")"
VERSION="$(normalize_version "$VERSION")"
VARIANT="$(normalize_variant "$VARIANT")"
SERVER="$(warp_normalize_server "$SERVER")"

info "Проверка наличия wg/awg"
sh "$ENSURE_WG_TOOL_SH" --install-if-missing

require_cmd curl
require_cmd date
vpn_json_require_parser
mkdir -p "$CONF_DIR"

info "Генерация ключей"
warp_generate_keys

info "Регистрация клиента в Cloudflare"
REG_RESP="$(warp_register "$WARP_GEN_PUB")"
CF_CLIENT_ID="$(warp_json_get "$REG_RESP" '@.result.id')"
CF_TOKEN="$(warp_json_get "$REG_RESP" '@.result.token')"

[ -n "$CF_CLIENT_ID" ] || die "Не удалось получить result.id"
[ -n "$CF_TOKEN" ] || die "Не удалось получить result.token"

info "Включение WARP"
WARP_RESP="$(warp_enable "$CF_CLIENT_ID" "$CF_TOKEN")"
CF_PEER_PUBLIC_KEY="$(warp_json_get "$WARP_RESP" '@.result.config.peers[0].public_key')"
CF_IPV4="$(warp_json_get "$WARP_RESP" '@.result.config.interface.addresses.v4')"
CF_IPV6="$(warp_json_get "$WARP_RESP" '@.result.config.interface.addresses.v6')"

[ -n "$CF_PEER_PUBLIC_KEY" ] || die "Не удалось получить public_key peer"
[ -n "$CF_IPV4" ] || die "Не удалось получить IPv4 интерфейса"

variant_params "$VARIANT"
awg_apply_i1_mode

ORIGINAL_DNS="$RAW_DEFAULT_DNS"
ORIGINAL_ALLOWED_IPS="$RAW_DEFAULT_ALLOWED_IPS"
ORIGINAL_PERSISTENT_KEEPALIVE=""
apply_mode_overrides

if [ -n "$ENDPOINT_OVERRIDE" ]; then
    ENDPOINT="$ENDPOINT_OVERRIDE"
else
    ENDPOINT="$(warp_build_endpoint "$SERVER")"
fi

if [ -z "$NAME" ]; then
    NAME_BASE="$(build_generated_name_base)"
    NAME="$(pick_unique_name "$NAME_BASE")"
else
    NAME="$(sanitize_slug "$NAME")"
    [ -n "$NAME" ] || die "Имя после очистки пустое"
fi

PROFILE_LABEL="mode=$MODE server=$SERVER awg=$VERSION variant=$VARIANT endpoint=$(endpoint_label "$ENDPOINT") dns=$DNS"

OUTFILE="$CONF_DIR/${NAME}.conf"
METAFILE="$CONF_DIR/${NAME}.conf.meta"

info "Записываю конфиг: $OUTFILE"
write_conf "$OUTFILE"

info "Записываю метаданные: $METAFILE"
write_meta "$METAFILE"

success "Конфиг создан: $OUTFILE"
printf 'SOURCE=%s\n' "$OUTFILE"
printf 'META=%s\n' "$METAFILE"
printf 'NAME=%s\n' "$NAME"
printf 'MODE=%s\n' "$MODE"
printf 'SERVER=%s\n' "$SERVER"
printf 'AWG_VERSION=%s\n' "$VERSION"
printf 'VARIANT=%s\n' "$VARIANT"
printf 'ENDPOINT=%s\n' "$ENDPOINT"
