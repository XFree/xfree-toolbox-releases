#!/bin/sh

DEFAULT_SERVER="def"
DEFAULT_VERSION="2.0"
DEFAULT_VARIANT="1"
DEFAULT_MODE="local"
# Версия политики gen-параметров в source.conf.meta (см. vpn/lib/warp-meta-policy.sh).
WARP_GENERATOR_POLICY_VERSION="1"
# best — топ-5 IP по /cdn-cgi/trace; random — один случайный endpoint.
DEFAULT_SELECTION_MODE="best"
# 1 — отбрасывать колонии RU (DME LED KJA SVX). loc= из trace — страна клиента, не колонии.
WARP_EXCLUDE_RU="1"
WARP_PROBE_TOP_N="5"
WARP_PROBE_ATTEMPT_MAX="20"
WARP_PROBE_TIMEOUT_SEC="4"
WARP_RU_COLOS="DME LED KJA SVX"

# def/xfree — Cloudflare. Страны tribukvy (рег. бот llimonix). lte* — tel.*.tribukvy, фильтр портов как warp-generation.
WARP_CF_DEF_OCTET_MIN="1"
WARP_CF_DEF_OCTET_MAX="10"

WARP_XFREE_DEF_HOST_PREFIX="162.159.195."
WARP_XFREE_DEF_HOST_OCTET_MIN="1"
WARP_XFREE_DEF_HOST_OCTET_MAX="10"

RAW_DEFAULT_DNS="1.1.1.1, 1.0.0.1, 2606:4700:4700::1111, 2606:4700:4700::1001"
RAW_DEFAULT_ALLOWED_IPS="0.0.0.0/0, ::/0"
LOCAL_DEFAULT_DNS="1.1.1.1, 1.0.0.1, 2606:4700:4700::1111, 2606:4700:4700::1001"
LOCAL_DEFAULT_ALLOWED_IPS="0.0.0.0/0, ::/0"
LOCAL_DEFAULT_PERSISTENT_KEEPALIVE="25"
