#!/bin/sh
# shellcheck shell=sh
set -eu

if [ -z "${ROOT_DIR:-}" ] || [ ! -f "${ROOT_DIR}/lib/common.sh" ]; then
    SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
    DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
    ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"
fi

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"

SOURCE_FILE=""
VLESS_URL=""
IFACE_NAME=""
TEST_IP="none"
EXPLICIT_OUT_DIR=""

usage() {
    cat <<EOF2
Usage: $(basename "$0") (--source FILE | --url "vless://...") --iface NAME [options]

Создание конфигурации VLESS (sing-box) интерфейса для iface-routing.

Опции:
  --source FILE          Путь к файлу конфигурации (.json или .txt c vless:// ссылкой)
  --url URL              Ссылка vless://...
  --iface NAME           Имя интерфейса (например: vless1, vless_us)
  --profile-dir DIR      Каталог профиля (по умолчанию: активный профиль)
  --out-dir DIR          Явный каталог для сгенерированных файлов (альтернатива --profile-dir)
  --test-ip IP           Контрольный IP для ping-проверки (по умолчанию: 1.1.1.1)
  -h, --help             Показать справку
EOF2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --source)
            shift
            [ "$#" -gt 0 ] || die "--source требует путь к файлу"
            SOURCE_FILE="$1"
            ;;
        --url)
            shift
            [ "$#" -gt 0 ] || die "--url требует ссылку"
            VLESS_URL="$1"
            ;;
        --iface)
            shift
            [ "$#" -gt 0 ] || die "--iface требует имя"
            IFACE_NAME="$1"
            ;;
        --profile-dir)
            shift
            [ "$#" -gt 0 ] || die "--profile-dir требует путь"
            PROFILE_DIR="$1"
            INTERFACES_DIR="$PROFILE_DIR/iface-routing/interfaces"
            ;;
        --out-dir|--output-dir)
            shift
            [ "$#" -gt 0 ] || die "$1 требует путь"
            EXPLICIT_OUT_DIR="$1"
            ;;
        --test-ip)
            shift
            [ "$#" -gt 0 ] || die "--test-ip требует IP"
            TEST_IP="$1"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift
done

url_decode() {
    printf '%s\n' "$1" | awk 'BEGIN {
        for (i=0; i<256; i++) {
            h = sprintf("%02X", i);
            map[h] = sprintf("%c", i);
            map[tolower(h)] = sprintf("%c", i);
        }
    }
    {
        s = $0;
        gsub(/\+/, " ", s);
        while (match(s, /%[0-9a-fA-F]{2}/)) {
            h = substr(s, RSTART + 1, 2);
            s = substr(s, 1, RSTART - 1) map[h] substr(s, RSTART + 3);
        }
        print s;
    }'
}

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

[ -n "$IFACE_NAME" ] || die "Не указано имя интерфейса (--iface)"
IFACE_NAME="$(sanitize_name "$IFACE_NAME")"
[ -n "$IFACE_NAME" ] || die "Недопустимое имя интерфейса"

# Read input content
INPUT_TEXT=""
if [ -n "$VLESS_URL" ]; then
    INPUT_TEXT="$VLESS_URL"
elif [ -n "$SOURCE_FILE" ]; then
    [ -f "$SOURCE_FILE" ] || die "Файл не найден: $SOURCE_FILE"
    INPUT_TEXT="$(cat "$SOURCE_FILE")"
else
    die "Необходимо указать --source FILE или --url URL"
fi

INPUT_TEXT="$(printf '%s' "$INPUT_TEXT" | tr -d '\r')"

# Compute stable sub-network IP for sing-box tun: 172.19.<subnet>.1/30
# Sum character ASCII values modulo 250 + 1
_sum=0
_len="${#IFACE_NAME}"
_i=1
while [ "$_i" -le "$_len" ]; do
    _ch="$(printf '%s' "$IFACE_NAME" | cut -c "$_i")"
    _ord="$(printf '%d' "'$_ch")"
    _sum=$(( (_sum + _ord) % 250 ))
    _i=$((_i + 1))
done
TUN_SUBNET=$(( _sum + 1 ))
TUN_DEV="tun-$IFACE_NAME"
# Ограничение длины сетевого интерфейса Linux (IFNAMSIZ=16, макс. 15 символов)
if [ "${#TUN_DEV}" -gt 15 ]; then
    TUN_DEV="tun-$(printf '%.11s' "$IFACE_NAME")"
fi

if [ -n "$EXPLICIT_OUT_DIR" ]; then
    TARGET_DIR="$EXPLICIT_OUT_DIR"
else
    TARGET_DIR="$INTERFACES_DIR/$IFACE_NAME/config"
fi
mkdir -p "$TARGET_DIR"

find_free_slot() {
    used_tables=" "
    used_marks=" "
    search_dir="$INTERFACES_DIR"
    if [ -d "$search_dir" ]; then
        for cfg in "$search_dir"/*/config/iface.conf "$search_dir"/*/iface.conf; do
            [ -f "$cfg" ] || continue
            cur_tbl="$(awk -F= '$1=="ROUTE_TABLE_ID"{gsub(/[ \047"]/,"",$2); print $2}' "$cfg" 2>/dev/null || true)"
            cur_mark="$(awk -F= '$1=="MARK_HEX"{gsub(/[ \047"]/,"",$2); print tolower($2)}' "$cfg" 2>/dev/null || true)"
            [ -n "$cur_tbl" ] && used_tables="${used_tables}${cur_tbl} "
            [ -n "$cur_mark" ] && used_marks="${used_marks}${cur_mark} "
        done
    fi

    slot_candidate=1
    while [ "$slot_candidate" -le 250 ]; do
        cand_tbl=$((200 + slot_candidate))
        cand_mark="$(printf '0x12%02x' "$slot_candidate" | tr '[:upper:]' '[:lower:]')"
        cand_mark_alt="$(printf '0x%x' "$((0x1200 + slot_candidate))" | tr '[:upper:]' '[:lower:]')"
        case "$used_tables" in
            *" $cand_tbl "*)
                slot_candidate=$((slot_candidate + 1))
                continue
                ;;
        esac
        case "$used_marks" in
            *" $cand_mark "*|*" $cand_mark_alt "*)
                slot_candidate=$((slot_candidate + 1))
                continue
                ;;
        esac
        printf '%s\n' "$slot_candidate"
        return 0
    done
    die "Не удалось найти свободный routing slot"
}

if [ -f "$TARGET_DIR/iface.conf" ]; then
    existing_tbl="$(awk -F= '$1=="ROUTE_TABLE_ID"{gsub(/[ \047"]/,"",$2); print $2}' "$TARGET_DIR/iface.conf" 2>/dev/null || true)"
    existing_mark="$(awk -F= '$1=="MARK_HEX"{gsub(/[ \047"]/,"",$2); print $2}' "$TARGET_DIR/iface.conf" 2>/dev/null || true)"
    if [ -n "$existing_tbl" ] && [ "$existing_tbl" -gt 100 ] && [ -n "$existing_mark" ]; then
        ROUTE_TABLE_ID="$existing_tbl"
        MARK_HEX="$existing_mark"
        IP_RULE_PREF="$(awk -F= '$1=="IP_RULE_PREF"{gsub(/[ \047"]/,"",$2); print $2}' "$TARGET_DIR/iface.conf" 2>/dev/null || true)"
        [ -n "$IP_RULE_PREF" ] || IP_RULE_PREF="$((10000 + (ROUTE_TABLE_ID - 100) * 10))"
    else
        SLOT="$(find_free_slot)"
        ROUTE_TABLE_ID="$((200 + SLOT))"
        MARK_HEX="$(printf '0x12%02x' "$SLOT")"
        IP_RULE_PREF="$((12000 + SLOT))"
    fi
else
    SLOT="$(find_free_slot)"
    ROUTE_TABLE_ID="$((200 + SLOT))"
    MARK_HEX="$(printf '0x12%02x' "$SLOT")"
    IP_RULE_PREF="$((12000 + SLOT))"
fi

ROUTE_TABLE_PREFIX="${ROUTE_TABLE_PREFIX:-xfree-routing-rt-}"
ROUTE_TABLE_NAME="${ROUTE_TABLE_PREFIX}${IFACE_NAME}"
NFT_FQDN4_SET_NAME="${IFACE_NAME}_fqdn4"
NFT_FQDN6_SET_NAME="${IFACE_NAME}_fqdn6"
NFT_PREFIX4_SET_NAME="${IFACE_NAME}_prefix4"
NFT_PREFIX6_SET_NAME="${IFACE_NAME}_prefix6"
NFT_CHAIN_NAME="mangle_prerouting_${IFACE_NAME}"
NFT_OUTPUT_CHAIN_NAME="mangle_output_${IFACE_NAME}"

if [ -z "$EXPLICIT_OUT_DIR" ]; then
    IFACE_ROOT="$INTERFACES_DIR/$IFACE_NAME"
    mkdir -p "$IFACE_ROOT/fqdn.d"
    mkdir -p "$IFACE_ROOT/fqdn.exclude.d"
    mkdir -p "$IFACE_ROOT/prefix.d"
    if [ -f "$ROOT_DIR/iface-routing/lib/default-excludes.sh" ]; then
        # shellcheck disable=SC1091
        . "$ROOT_DIR/iface-routing/lib/default-excludes.sh"
        iface_seed_default_excludes "$IFACE_ROOT" "$ROOT_DIR"
    fi
fi

# Check if input is a raw JSON sing-box configuration
is_json=0
case "$INPUT_TEXT" in
    \{*) is_json=1 ;;
esac

if [ "$is_json" = "1" ]; then
    info "Распознан JSON-формат конфигурации sing-box"
    # Ensure inbounds has tun device tun-$IFACE_NAME
    printf '%s\n' "$INPUT_TEXT" > "$TARGET_DIR/singbox.json"
    printf '%s\n' "$INPUT_TEXT" > "$TARGET_DIR/source.json"
    _server="$(grep -o '"server": *"[^"]*"' "$TARGET_DIR/singbox.json" | head -n1 | cut -d'"' -f4 || true)"
    _port="$(grep -o '"server_port": *[0-9]*' "$TARGET_DIR/singbox.json" | head -n1 | tr -cd '0-9' || true)"
    [ -n "$_port" ] || _port="443"
else
    # Parse vless:// link
    # Format: vless://uuid@server:port?query#name
    _url="$INPUT_TEXT"
    case "$_url" in
        vless://*) ;;
        *) die "Неизвестный формат ссылки (ожидался vless://... или JSON): $_url" ;;
    esac

    _rest="${_url#vless://}"
    # Remove #hash / display name
    _link_no_hash="${_rest%%#*}"
    _display_name="${_rest#*#}"
    [ "$_display_name" != "$_rest" ] || _display_name=""

    # Split auth_host and query
    _auth_host="${_link_no_hash%%\?*}"
    _query=""
    if [ "$_auth_host" != "$_link_no_hash" ]; then
        _query="${_link_no_hash#*\?}"
    fi

    # Parse uuid@server:port
    _uuid="${_auth_host%%@*}"
    _host_port="${_auth_host#*@}"
    _server="${_host_port%%:*}"
    _port="${_host_port#*:}"

    [ -n "$_uuid" ] || die "VLESS URL: отсутствует UUID"
    [ -n "$_server" ] || die "VLESS URL: отсутствует сервер"
    [ -n "$_port" ] || _port="443"

    # Default query parameter values
    _security=""
    _sni=""
    _pbk=""
    _sid=""
    _fp="chrome"
    _type="tcp"
    _flow=""
    _path=""
    _service_name=""

    if [ -n "$_query" ]; then
        # Parse query params separated by '&'
        _old_ifs="$IFS"
        IFS='&'
        for _param in $_query; do
            [ -n "$_param" ] || continue
            _pkey="${_param%%=*}"
            _pval="${_param#*=}"
            case "$_pkey" in
                security) _security="$_pval" ;;
                sni|serverName) _sni="$_pval" ;;
                pbk|publicKey) _pbk="$_pval" ;;
                sid|shortId) _sid="$_pval" ;;
                fp|fingerprint) _fp="$_pval" ;;
                type|transport) _type="$_pval" ;;
                flow) _flow="$_pval" ;;
                path) _path="$(url_decode "$_pval")" ;;
                serviceName) _service_name="$(url_decode "$_pval")" ;;
            esac
        done
        IFS="$_old_ifs"
    fi

    [ -n "$_sni" ] || _sni="$_server"

    info "Генерация sing-box конфигурации: server=$_server:$_port, security=${_security:-none}, type=$_type"

    # Build TLS/Reality configuration snippet
    _tls_json=""
    if [ "$_security" = "reality" ]; then
        _tls_json=$(cat <<EOFTLS
      "tls": {
        "enabled": true,
        "server_name": "$_sni",
        "utls": {
          "enabled": true,
          "fingerprint": "${_fp:-chrome}"
        },
        "reality": {
          "enabled": true,
          "public_key": "$_pbk",
          "short_id": "${_sid:-}"
        }
      },
EOFTLS
)
    elif [ "$_security" = "tls" ]; then
        _tls_json=$(cat <<EOFTLS
      "tls": {
        "enabled": true,
        "server_name": "$_sni",
        "utls": {
          "enabled": true,
          "fingerprint": "${_fp:-chrome}"
        }
      },
EOFTLS
)
    fi

    # Build transport snippet if not standard tcp
    _transport_json=""
    if [ "$_type" = "ws" ]; then
        _transport_json=$(cat <<EOFTR
      "transport": {
        "type": "ws",
        "path": "${_path:-/}"
      },
EOFTR
)
    elif [ "$_type" = "grpc" ]; then
        _transport_json=$(cat <<EOFTR
      "transport": {
        "type": "grpc",
        "service_name": "${_service_name:-}"
      },
EOFTR
)
    fi

    _flow_json=""
    if [ -n "$_flow" ]; then
        _flow_json="\"flow\": \"$_flow\","
    fi

    # Generate complete sing-box client configuration
    cat > "$TARGET_DIR/singbox.json" <<EOFJSON
{
  "log": {
    "level": "warn"
  },
  "inbounds": [
    {
      "type": "tun",
      "tag": "tun-in",
      "interface_name": "$TUN_DEV",
      "address": [
        "172.19.$TUN_SUBNET.1/30"
      ],
      "auto_route": false,
      "strict_route": false
    }
  ],
  "outbounds": [
    {
      "type": "vless",
      "tag": "proxy",
      "server": "$_server",
      "server_port": $_port,
      "uuid": "$_uuid",
      $_flow_json
      $_tls_json
      $_transport_json
      "packet_encoding": "xudp"
    },
    {
      "type": "direct",
      "tag": "direct"
    }
  ],
  "route": {
    "rules": [
      {
        "outbound": "proxy"
      }
    ],
    "auto_detect_interface": true
  }
}
EOFJSON

    printf '%s\n' "$INPUT_TEXT" > "$TARGET_DIR/source.vless"
fi

SOURCE_CONF="source.vless"
if [ "$is_json" = "1" ]; then
    SOURCE_CONF="source.json"
fi

# Generate iface.conf
cat > "$TARGET_DIR/iface.conf" <<EOFCONF
# shellcheck shell=sh

INTERFACE_NAME='$IFACE_NAME'
VPN_DEV='$TUN_DEV'

SOURCE_CONF='$SOURCE_CONF'
SOURCE_META='source.conf.meta'

NETWORK_DELETE_SECTIONS='$IFACE_NAME'
FIREWALL_MODEL='shared-vpn-zone'

MARK_HEX='$MARK_HEX'
ROUTE_TABLE_ID='$ROUTE_TABLE_ID'
ROUTE_TABLE_NAME='$ROUTE_TABLE_NAME'
IP_RULE_PREF='$IP_RULE_PREF'

ROUTING_MODE='vpn'
PROTOCOL_LABEL='VLESS (sing-box)'
TYPE='vless'
VPN_PROTO='vless'
CONFIG_FORMAT='singbox'

ENDPOINT_HOST='${_server:-}'
ENDPOINT_PORT='${_port:-443}'
ENDPOINT_PROTO='tcp'

HTTPS_PROBE_URL='https://cp.cloudflare.com/generate_204'

NFT_FQDN4_SET_NAME='$NFT_FQDN4_SET_NAME'
NFT_FQDN6_SET_NAME='$NFT_FQDN6_SET_NAME'
NFT_PREFIX4_SET_NAME='$NFT_PREFIX4_SET_NAME'
NFT_PREFIX6_SET_NAME='$NFT_PREFIX6_SET_NAME'
NFT_CHAIN_NAME='$NFT_CHAIN_NAME'
NFT_OUTPUT_CHAIN_NAME='$NFT_OUTPUT_CHAIN_NAME'

SELF_ROUTE_VIA=''
PBR_BYPASS_NETWORKS=''
EOFCONF

# Generate network.uci
cat > "$TARGET_DIR/network.uci" <<EOFNET
package network

config interface '$IFACE_NAME'
    option proto 'none'
    option device '$TUN_DEV'
    option defaultroute '0'
    option peerdns '0'
EOFNET

# Generate firewall.uci
cat > "$TARGET_DIR/firewall.uci" <<EOFFW
package firewall

config zone
    option name '$IFACE_NAME'
    list network '$IFACE_NAME'
    option input 'REJECT'
    option output 'ACCEPT'
    option forward 'REJECT'
    option masq '1'
    option mtu_fix '1'

config forwarding
    option src 'lan'
    option dest '$IFACE_NAME'
EOFFW

# Generate vless.uci
cat > "$TARGET_DIR/vless.uci" <<EOFVL
package vless

config vless '$IFACE_NAME'
    option enabled '1'
    option config '/etc/xfree-toolbox/iface-routing/vless/$IFACE_NAME.json'
EOFVL

# Metadata
cat > "$TARGET_DIR/source.conf.meta" <<EOFMETA
GENERATOR_KIND='vless'
IFACE_NAME='$IFACE_NAME'
VPN_DEV='$TUN_DEV'
VPN_PROTO='vless'
ENDPOINT_HOST='${_server:-}'
ENDPOINT_PORT='${_port:-443}'
ENDPOINT_PROTO='tcp'
CREATED_AT='$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)'
EOFMETA

success "Интерфейс VLESS '$IFACE_NAME' успешно сконфигурирован в $TARGET_DIR"
