#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
PKGMGR_SH="${PKGMGR_SH:-$ROOT_DIR/lib/pkgmgr.sh}"

[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"

# Если мы не на роутере с apk/opkg (например, при юнит-тестировании),
# предотвращаем fatal die() из pm_detect в pkgmgr.sh
if ! command -v opkg >/dev/null 2>&1 && ! command -v apk >/dev/null 2>&1; then
    PM="${PM:-stub}"
    export PM
fi

[ -f "$PKGMGR_SH" ] || die "Не найден pkgmgr.sh: $PKGMGR_SH"
. "$PKGMGR_SH"

ACTION="check"
MIN_SPACE_MB=35

usage() {
    cat <<EOF2
Usage: $(basename "$0") [options]

Управление пакетом sing-box (VLESS) для xfree-toolbox.
Включает обязательную проверку свободного места на диске перед установкой
для предотвращения переполнения flash-памяти (/overlay) и сбоя роутера.

Опции:
  --check                Проверить, установлен ли sing-box (код 0 если да, 1 если нет)
  --check-space [MB]     Проверить наличие свободного места (по умолчанию: $MIN_SPACE_MB МБ)
  --install-if-missing   Проверить место и установить sing-box (sing-box-tiny + kmod-tun + ca-bundle)
  --remove               Удалить sing-box для высвобождения места
  --status               Показать текущий статус sing-box и состояние диска
  -h, --help             Показать справку
EOF2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --check)
            ACTION="check"
            ;;
        --check-space)
            ACTION="check_space"
            if [ "$#" -ge 2 ] && [ -n "${2:-}" ]; then
                case "$2" in
                    [0-9]*)
                        MIN_SPACE_MB="$2"
                        shift
                        ;;
                esac
            fi
            ;;
        --install-if-missing)
            ACTION="install"
            ;;
        --remove)
            ACTION="remove"
            ;;
        --status)
            ACTION="status"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift
done

is_singbox_installed() {
    if command -v sing-box >/dev/null 2>&1; then
        return 0
    fi
    if pm_is_installed sing-box-tiny 2>/dev/null || pm_is_installed sing-box 2>/dev/null; then
        return 0
    fi
    return 1
}

get_singbox_version() {
    _bin="$(command -v sing-box 2>/dev/null || true)"
    if [ -n "$_bin" ]; then
        "$_bin" version 2>/dev/null | head -n1 | awk '{print $3}' || echo "installed"
    elif pm_is_installed sing-box-tiny 2>/dev/null; then
        echo "sing-box (tiny)"
    elif pm_is_installed sing-box 2>/dev/null; then
        echo "sing-box"
    else
        echo "not-installed"
    fi
}

get_overlay_free_mb() {
    _target="/overlay"
    [ -d "$_target" ] || _target="/"
    _df="$(df -k "$_target" 2>/dev/null | tail -n 1 || true)"
    [ -n "$_df" ] || { echo "0"; return 0; }
    _avail_k="$(printf '%s' "$_df" | awk '{print $4}')"
    case "$_avail_k" in
        ''|*[!0-9]*) echo "0" ;;
        *) echo "$((_avail_k / 1024))" ;;
    esac
}

check_disk_space() {
    _req="$1"
    _free="$(get_overlay_free_mb)"
    if [ "$_free" -lt "$_req" ]; then
        return 1
    fi
    return 0
}

case "$ACTION" in
    check)
        if is_singbox_installed; then
            ver="$(get_singbox_version)"
            success "sing-box установлен: $ver"
            exit 0
        else
            warn "sing-box не установлен"
            exit 1
        fi
        ;;

    check_space)
        free_mb="$(get_overlay_free_mb)"
        if [ "$free_mb" -ge "$MIN_SPACE_MB" ]; then
            success "Свободно на диске: ${free_mb} МБ (требуется: ${MIN_SPACE_MB} МБ)"
            exit 0
        else
            error "Недостаточно места: свободно ${free_mb} МБ, требуется минимум ${MIN_SPACE_MB} МБ"
            exit 1
        fi
        ;;

    status)
        free_mb="$(get_overlay_free_mb)"
        if is_singbox_installed; then
            ver="$(get_singbox_version)"
            echo "SINGBOX_STATUS=installed"
            echo "SINGBOX_VERSION=$ver"
        else
            echo "SINGBOX_STATUS=not-installed"
            echo "SINGBOX_VERSION=none"
        fi
        echo "OVERLAY_FREE_MB=$free_mb"
        echo "MIN_REQUIRED_MB=$MIN_SPACE_MB"
        exit 0
        ;;

    install)
        if is_singbox_installed; then
            success "sing-box уже установлен"
            exit 0
        fi

        free_mb="$(get_overlay_free_mb)"
        if [ "$free_mb" -lt "$MIN_SPACE_MB" ]; then
            echo "==========================================================" >&2
            echo "[-] ОШИБКА БЕЗОПАСНОСТИ: Недостаточно свободного места!" >&2
            echo "[-] Свободно на /overlay: ${free_mb} МБ" >&2
            echo "[-] Требуется минимум:   ${MIN_SPACE_MB} МБ (размер пакета sing-box)" >&2
            echo "[-] Установка sing-box ПРЕРВАНА для защиты роутера от сбоя." >&2
            echo "[-] Освободите место или используйте USB-накопитель (extroot)." >&2
            echo "==========================================================" >&2
            exit 1
        fi

        info "Проверка места пройдена (свободно ${free_mb} МБ >= ${MIN_SPACE_MB} МБ). Начинаю установку..."
        pm_update || warn "pm_update завершился с предупреждением"

        # Prefer sing-box-tiny (lower footprint ~32MB) over full sing-box (~45MB)
        if pm_install sing-box-tiny kmod-tun ca-bundle 2>/dev/null; then
            success "Установлен пакет sing-box-tiny с kmod-tun и ca-bundle"
        elif pm_install sing-box kmod-tun ca-bundle 2>/dev/null; then
            success "Установлен пакет sing-box с kmod-tun и ca-bundle"
        elif pm_install sing-box-tiny kmod-tun ca-certificates 2>/dev/null; then
            success "Установлен пакет sing-box-tiny с kmod-tun и ca-certificates"
        elif pm_install sing-box kmod-tun ca-certificates 2>/dev/null; then
            success "Установлен пакет sing-box с kmod-tun и ca-certificates"
        else
            die "Не удалось установить пакеты sing-box"
        fi

        if is_singbox_installed; then
            ver="$(get_singbox_version)"
            success "sing-box успешно установлен и готов к работе: $ver"
            exit 0
        else
            die "Проверка после установки не удалась: sing-box не найден в PATH"
        fi
        ;;

    remove)
        info "Удаление sing-box..."
        pm_remove sing-box-tiny 2>/dev/null || true
        pm_remove sing-box 2>/dev/null || true
        success "sing-box удален из системы"
        exit 0
        ;;
esac
