#!/bin/sh
# shellcheck shell=sh
set -eu

if [ -z "${ROOT_DIR:-}" ] || [ ! -f "${ROOT_DIR}/lib/common.sh" ]; then
    SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
    DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
    ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"
else
    VPN_DIR="$ROOT_DIR/iface-routing/vpn"
    DOMAIN_ROUTING_DIR="$ROOT_DIR/iface-routing"
    SCRIPT_DIR="$VPN_DIR/protocols"
fi

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
PKGMGR_SH="${PKGMGR_SH:-$ROOT_DIR/lib/pkgmgr.sh}"

[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"

[ -f "$PKGMGR_SH" ] || die "Не найден pkgmgr.sh: $PKGMGR_SH"
. "$PKGMGR_SH"

AWG_ENSURE_SCRIPT="$ROOT_DIR/awg-ingress/ensure-awg.sh"
OPENVPN_ENSURE_SCRIPT="$VPN_DIR/openvpn/ensure-openvpn.sh"

proto_awg_is_installed() {
    command -v awg >/dev/null 2>&1 || command -v wg >/dev/null 2>&1
}

proto_awg_status_label() {
    if command -v awg >/dev/null 2>&1; then
        echo "AmneziaWG"
    elif command -v wg >/dev/null 2>&1; then
        echo "WireGuard"
    else
        echo "Не установлен"
    fi
}

proto_awg_install() {
    if [ -f "$AWG_ENSURE_SCRIPT" ]; then
        sh "$AWG_ENSURE_SCRIPT" --install-if-missing
    else
        pm_update || true
        pm_install kmod-wireguard wireguard-tools
    fi
}

proto_openvpn_is_installed() {
    command -v openvpn >/dev/null 2>&1 || pm_is_installed openvpn-openssl || pm_is_installed openvpn-mbedtls
}

proto_openvpn_status_label() {
    if proto_openvpn_is_installed; then
        echo "Установлен"
    else
        echo "Не установлен"
    fi
}

proto_openvpn_install() {
    if [ -f "$OPENVPN_ENSURE_SCRIPT" ]; then
        sh "$OPENVPN_ENSURE_SCRIPT" --install-if-missing
    else
        pm_update || true
        if [ "$PM" = "apk" ]; then
            apk add --allow-untrusted -t kmod-ovpn-backports kmod-tun >/dev/null 2>&1 || true
        fi
        pm_install openvpn-openssl kmod-tun || pm_install openvpn-mbedtls kmod-tun || true
        proto_openvpn_is_installed || die "Не удалось установить OpenVPN"
    fi
}

proto_openvpn_remove() {
    if [ -f "$OPENVPN_ENSURE_SCRIPT" ]; then
        sh "$OPENVPN_ENSURE_SCRIPT" --remove
    else
        pm_remove openvpn-openssl 2>/dev/null || true
        pm_remove openvpn-mbedtls 2>/dev/null || true
        pm_remove openvpn 2>/dev/null || true
    fi
}

proto_vless_is_installed() {
    command -v sing-box >/dev/null 2>&1 || pm_is_installed sing-box-tiny || pm_is_installed sing-box
}

proto_vless_status_label() {
    if pm_is_installed sing-box-tiny; then
        echo "sing-box (tiny)"
    elif proto_vless_is_installed; then
        echo "sing-box"
    else
        echo "Не установлен"
    fi
}

proto_vless_install() {
    pm_update || true
    pm_install sing-box-tiny kmod-tun ca-bundle || pm_install sing-box kmod-tun ca-bundle || pm_install sing-box-tiny kmod-tun ca-certificates || pm_install sing-box kmod-tun ca-certificates
}

proto_vless_remove() {
    pm_remove sing-box-tiny 2>/dev/null || true
    pm_remove sing-box 2>/dev/null || true
}

FREETURN_LIB_SH="$ROOT_DIR/free-turn/lib.sh"
if [ -f "$FREETURN_LIB_SH" ]; then
    # shellcheck disable=SC1090
    . "$FREETURN_LIB_SH"
fi

proto_freeturn_is_installed() {
    [ -x "/opt/free-turn-proxy/client" ]
}

proto_freeturn_status_label() {
    if [ -f "$FREETURN_LIB_SH" ]; then
        ver="$(freeturn_client_get_installed_version 2>/dev/null || true)"
        if [ -n "$ver" ] && [ "$ver" != "not-installed" ]; then
            if [ "$ver" = "installed" ]; then
                echo "Установлен"
            else
                echo "$ver"
            fi
            return 0
        fi
    elif proto_freeturn_is_installed; then
        echo "Установлен"
        return 0
    fi
    echo "Не установлен"
}

proto_freeturn_install() {
    if [ -f "$FREETURN_LIB_SH" ]; then
        freeturn_install_client
    else
        die "Не найден модуль free-turn/lib.sh"
    fi
}

proto_freeturn_remove() {
    if [ -f "$FREETURN_LIB_SH" ]; then
        freeturn_uninstall_client
    else
        rm -f "/opt/free-turn-proxy/client" "/opt/free-turn-proxy/client-version"
    fi
}
