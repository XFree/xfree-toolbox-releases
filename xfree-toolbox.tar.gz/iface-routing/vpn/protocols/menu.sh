#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
UI_SH="${UI_SH:-$ROOT_DIR/lib/ui.sh}"

[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"

[ -f "$UI_SH" ] || { echo "[-] Не найден ui.sh: $UI_SH" >&2; exit 1; }
. "$UI_SH"

PROTOCOLS_SH="$SCRIPT_DIR/protocols.sh"
[ -f "$PROTOCOLS_SH" ] || die "Не найден protocols.sh: $PROTOCOLS_SH"
. "$PROTOCOLS_SH"

ui_init
ui_trap_cleanup_on_exit

protocols_main_menu() {
    while true; do
        awg_st="$(proto_awg_status_label)"
        ovpn_st="$(proto_openvpn_status_label)"
        vless_st="$(proto_vless_status_label)"
        ft_st="$(proto_freeturn_status_label)"
        fts_st="$(proto_freeturn_server_status_label)"

        choice="$(ui_menu "Компоненты протоколов VPN" \
"Управление пакетами сетевых протоколов VPN для роутера.
Устанавливайте только те протоколы, которые вам необходимы для экономии места на диске." \
            22 80 10 \
            "1" "OpenVPN (~0.4 MB)              [$ovpn_st]" \
            "2" "VLESS / sing-box (~15 MB, Beta) [$vless_st]" \
            "3" "AmneziaWG / WireGuard (ядро)    [$awg_st]" \
            "4" "FreeTurn Client (~16 MB)        [$ft_st]" \
            "5" "FreeTurn Server (~16 MB)        [$fts_st]" \
            "b" "Назад" || true)"

        case "$choice" in
            1)
                protocol_action_menu "OpenVPN" "openvpn" "$ovpn_st" "~0.4 MB"
                ;;
            2)
                protocol_action_menu "VLESS (sing-box)" "vless" "$vless_st" "~15 MB"
                ;;
            3)
                protocol_action_menu "AmneziaWG / WireGuard" "awg" "$awg_st" "ядро Linux"
                ;;
            4)
                protocol_action_menu "FreeTurn Client" "freeturn" "$ft_st" "~16 MB"
                ;;
            5)
                protocol_action_menu "FreeTurn Server" "freeturn_server" "$fts_st" "~16 MB"
                ;;
            b|"")
                break
                ;;
        esac
    done
}

protocol_action_menu() {
    proto_title="$1"
    proto_key="$2"
    proto_status="$3"
    proto_size="$4"

    while true; do
        current_status=""
        case "$proto_key" in
            openvpn) current_status="$(proto_openvpn_status_label)" ;;
            vless) current_status="$(proto_vless_status_label)" ;;
            awg) current_status="$(proto_awg_status_label)" ;;
            freeturn) current_status="$(proto_freeturn_status_label)" ;;
            freeturn_server) current_status="$(proto_freeturn_server_status_label)" ;;
        esac

        act="$(ui_menu "$proto_title" \
"Протокол: $proto_title
Примерный размер: $proto_size
Текущий статус: $current_status" \
            18 70 6 \
            "1" "Установить / Обновить пакет" \
            "2" "Удалить пакет (освободить место)" \
            "b" "Назад" || true)"

        case "$act" in
            1)
                case "$proto_key" in
                    openvpn)
                        ui_run_with_output "Установка OpenVPN" proto_openvpn_install
                        ;;
                    vless)
                        ui_run_with_output "Установка VLESS (sing-box)" proto_vless_install
                        ;;
                    awg)
                        ui_run_with_output "Установка AmneziaWG" proto_awg_install
                        ;;
                    freeturn)
                        ui_run_with_output "Установка FreeTurn Client" proto_freeturn_install
                        ;;
                    freeturn_server)
                        ui_run_with_output "Установка FreeTurn Server" proto_freeturn_server_install
                        ;;
                esac
                ;;
            2)
                case "$proto_key" in
                    openvpn)
                        ui_run_with_output "Удаление OpenVPN" proto_openvpn_remove
                        ;;
                    vless)
                        ui_run_with_output "Удаление VLESS (sing-box)" proto_vless_remove
                        ;;
                    awg)
                        ui_msgbox "Удаление" "Удаление драйвера AmneziaWG/WireGuard из ядра не поддерживается через меню во избежание сбоя сетевой подсистемы."
                        ;;
                    freeturn)
                        ui_run_with_output "Удаление FreeTurn Client" proto_freeturn_remove
                        ;;
                    freeturn_server)
                        ui_run_with_output "Удаление FreeTurn Server" proto_freeturn_server_remove
                        ;;
                esac
                ;;
            b|"")
                break
                ;;
        esac
    done
}

protocols_main_menu
