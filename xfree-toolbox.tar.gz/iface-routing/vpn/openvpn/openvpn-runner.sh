#!/bin/sh
# shellcheck shell=sh
# OpenVPN runner wrapper for xfree-toolbox
# Ensures credential / 2FA refresh before launching OpenVPN,
# and applies backoff delay on exit to prevent rapid restart spam to server.

REAL_OPENVPN="/usr/sbin/openvpn"

# Determine instance name from arguments
iface=""
prev=""
for arg in "$@"; do
    case "$prev" in
        --syslog)
            # format: openvpn(iface_name)
            case "$arg" in
                openvpn\(*\))
                    iface="${arg#openvpn(}"
                    iface="${iface%)}"
                    ;;
            esac
            ;;
        --config)
            if [ -z "$iface" ]; then
                _base="$(basename "$arg")"
                iface="${_base%.*}"
            fi
            ;;
    esac
    prev="$arg"
done

# If interface has dynamic credentials (e.g. 2FA / TOTP), execute auth refresh
if [ -n "$iface" ]; then
    LIFECYCLE_LIB="/root/xfree-toolbox/iface-routing/lib/iface-lifecycle.sh"
    [ -f "$LIFECYCLE_LIB" ] || LIFECYCLE_LIB="/etc/xfree-toolbox/iface-routing/lib/iface-lifecycle.sh"
    REFRESH_SH="/etc/xfree-toolbox/iface-routing/openvpn/refresh-auth.sh"

    if [ -f "$LIFECYCLE_LIB" ]; then
        # shellcheck disable=SC1090
        . "$LIFECYCLE_LIB"
        iface_refresh_credentials "$iface" >/dev/null 2>&1 || true
    elif [ -x "$REFRESH_SH" ]; then
        "$REFRESH_SH" "$iface" >/dev/null 2>&1 || true
    fi
fi

# Run real OpenVPN
"$REAL_OPENVPN" "$@"
rc=$?

# If OpenVPN exited with error, sleep 25 seconds before returning to procd
# to prevent rapid restart hammering and server lockout.
if [ "$rc" -ne 0 ]; then
    sleep 25
fi

exit "$rc"
