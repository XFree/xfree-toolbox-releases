#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
PKGMGR_SH="${PKGMGR_SH:-$ROOT_DIR/lib/pkgmgr.sh}"

[ -f "$COMMON_SH" ] && . "$COMMON_SH"

SECRET_INPUT="${1:-}"

if [ -z "$SECRET_INPUT" ]; then
    echo "Usage: $0 <BASE32_SECRET|/path/to/secret_file>" >&2
    exit 1
fi

if [ -f "$SECRET_INPUT" ]; then
    RAW_KEY="$(head -n1 "$SECRET_INPUT" | tr -d ' \r\n\t')"
else
    RAW_KEY="$(printf '%s' "$SECRET_INPUT" | tr -d ' \r\n\t')"
fi

case "$RAW_KEY" in
    *secret=*)
        SECRET_KEY="${RAW_KEY#*secret=}"
        SECRET_KEY="${SECRET_KEY%%&*}"
        ;;
    *)
        SECRET_KEY="$RAW_KEY"
        ;;
esac

SECRET_KEY="$(printf '%s' "$SECRET_KEY" | tr 'a-z' 'A-Z')"
[ -n "$SECRET_KEY" ] || { echo "[-] Secret key is empty" >&2; exit 1; }

ensure_oathtool() {
    if command -v oathtool >/dev/null 2>&1; then
        return 0
    fi
    if [ -f "$PKGMGR_SH" ]; then
        (
            # shellcheck disable=SC1090
            . "$PKGMGR_SH"
            pm_install oathtool 2>/dev/null || pm_install oath-toolkit 2>/dev/null || true
        ) 2>/dev/null || true
    fi
    command -v oathtool >/dev/null 2>&1
}

if ensure_oathtool; then
    oathtool --totp -b "$SECRET_KEY"
    exit 0
fi

# Fallback to python if available
if command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1; then
    PY_BIN="$(command -v python3 || command -v python)"
    "$PY_BIN" -c "
import hmac, hashlib, base64, time, struct, sys
secret = sys.argv[1].strip().replace(' ', '').upper()
missing_padding = len(secret) % 8
if missing_padding:
    secret += '=' * (8 - missing_padding)
key = base64.b32decode(secret, True)
counter = int(time.time() // 30)
msg = struct.pack('>Q', counter)
h = hmac.new(key, msg, hashlib.sha1).digest()
offset = h[-1] & 0x0F
code = struct.unpack('>I', h[offset:offset+4])[0] & 0x7FFFFFFF
print(f'{code % 1000000:06d}')
" "$SECRET_KEY"
    exit 0
fi

echo "[-] Для автоматической генерации TOTP требуется пакет oathtool (~35 КБ)" >&2
exit 1
