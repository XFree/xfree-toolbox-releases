#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
PKGMGR_SH="${PKGMGR_SH:-$ROOT_DIR/lib/pkgmgr.sh}"

[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"

[ -f "$PKGMGR_SH" ] || die "Не найден pkgmgr.sh: $PKGMGR_SH"
. "$PKGMGR_SH"

ACTION="check"

usage() {
    cat <<EOF2
Usage: $(basename "$0") [options]

Управление пакетом OpenVPN для xfree-toolbox.

Опции:
  --check                Проверить, установлен ли OpenVPN (код возврата 0 если да, 1 если нет)
  --install-if-missing   Установить OpenVPN (openvpn-openssl/mbedtls + kmod-tun), если отсутствует
  --remove               Удалить пакет OpenVPN для высвобождения места
  -h, --help             Показать справку
EOF2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --check)
            ACTION="check"
            ;;
        --install-if-missing)
            ACTION="install"
            ;;
        --remove)
            ACTION="remove"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift
done

is_openvpn_installed() {
    if command -v openvpn >/dev/null 2>&1; then
        return 0
    fi
    if pm_is_installed openvpn-openssl || pm_is_installed openvpn-mbedtls; then
        return 0
    fi
    return 1
}

case "$ACTION" in
    check)
        if is_openvpn_installed; then
            ovpn_bin="$(command -v openvpn 2>/dev/null || true)"
            ovpn_ver="$([ -n "$ovpn_bin" ] && "$ovpn_bin" --version 2>/dev/null | head -n1 || echo "installed")"
            success "OpenVPN установлен: $ovpn_ver ($ovpn_bin)"
            exit 0
        else
            warn "OpenVPN не установлен"
            exit 1
        fi
        ;;

    install)
        if is_openvpn_installed; then
            success "OpenVPN уже установлен"
            exit 0
        fi

        info "Устанавливаю OpenVPN и kmod-tun ($PM)..."
        pm_update || warn "pm_update завершился с предупреждением"

        if [ "$PM" = "apk" ]; then
            # OpenWrt 25.12 packaging quirk: openvpn-openssl depends on kmod-ovpn-backports,
            # which is not in target kmod feed (renamed to kmod-ovpn-dco-v2). Virtual constraint satisfies it.
            apk add --allow-untrusted -t kmod-ovpn-backports kmod-tun >/dev/null 2>&1 || true
        fi

        pm_install openvpn-openssl kmod-tun || pm_install openvpn-mbedtls kmod-tun || pm_install openvpn kmod-tun || true

        if is_openvpn_installed; then
            success "OpenVPN успешно установлен"
            exit 0
        fi

        die "Не удалось установить OpenVPN"
        ;;

    remove)
        if ! is_openvpn_installed; then
            info "OpenVPN не установлен, удаление не требуется"
            exit 0
        fi

        info "Удаляю пакеты OpenVPN для высвобождения места..."
        pm_remove openvpn-openssl 2>/dev/null || true
        pm_remove openvpn-mbedtls 2>/dev/null || true
        pm_remove openvpn 2>/dev/null || true

        if is_openvpn_installed; then
            warn "OpenVPN всё ещё присутствует в системе"
            exit 1
        fi

        success "OpenVPN успешно удалён"
        exit 0
        ;;
esac
