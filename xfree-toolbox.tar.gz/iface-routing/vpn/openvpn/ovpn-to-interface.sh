#!/bin/sh
# shellcheck shell=sh
set -eu

if [ -z "${ROOT_DIR:-}" ] || [ ! -f "${ROOT_DIR}/lib/common.sh" ]; then
    SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
    DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
    ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"
fi

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
ROUTE_TABLE_PREFIX="${ROUTE_TABLE_PREFIX:-xfree-routing-rt-}"

SOURCE_FILE=""
IFACE_NAME=""
AUTH_USER=""
AUTH_PASS=""
TOTP_SECRET=""
TOTP_AUTH_FORMAT=""
TEST_IP="none"
DNS_SERVERS=""

usage() {
    cat <<EOF2
Usage: $(basename "$0") --source FILE.ovpn --iface NAME [options]

Создание конфигурации OpenVPN интерфейса для iface-routing.

Опции:
  --source FILE          Путь к файлу конфигурации .ovpn
  --iface NAME           Имя интерфейса (например: corp, work, ovpn1)
  --profile-dir DIR      Каталог профиля (по умолчанию: активный профиль)
  --auth-user USER       Логин для OpenVPN
  --auth-pass PASS       Пароль для OpenVPN
  --totp-secret SECRET   Base32 секретный ключ TOTP (2FA)
  --auth-format FORMAT   Формат передачи 2FA (scrv1|concat|otp_first|none)
  --test-ip IP_OR_HOST   Контрольный IP или домен для ping проверки (по умолчанию: none)
  --dns SERVERS          DNS серверы через запятую (например: 172.29.252.10, 172.29.252.12)
  -h, --help             Показать справку
EOF2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --source)
            shift
            [ "$#" -gt 0 ] || die "--source требует путь к файлу"
            SOURCE_FILE="$1"
            ;;
        --iface)
            shift
            [ "$#" -gt 0 ] || die "--iface требует имя"
            IFACE_NAME="$1"
            ;;
        --auth-user)
            shift
            [ "$#" -gt 0 ] || die "--auth-user требует имя пользователя"
            AUTH_USER="$1"
            ;;
        --auth-pass)
            shift
            [ "$#" -gt 0 ] || die "--auth-pass требует пароль"
            AUTH_PASS="$1"
            ;;
        --totp-secret)
            shift
            [ "$#" -gt 0 ] || die "--totp-secret требует секретный ключ"
            TOTP_SECRET="$1"
            ;;
        --auth-format)
            shift
            [ "$#" -gt 0 ] || die "--auth-format требует формат"
            TOTP_AUTH_FORMAT="$1"
            ;;
        --test-ip)
            shift
            [ "$#" -gt 0 ] || die "--test-ip требует значение"
            TEST_IP="$1"
            ;;
        --dns)
            shift
            [ "$#" -gt 0 ] || die "--dns требует список DNS серверов"
            DNS_SERVERS="$1"
            ;;
        --profile-dir)
            shift
            [ "$#" -gt 0 ] || die "--profile-dir требует путь"
            if [ -d "$1" ]; then
                PROFILE_DIR="$1"
            else
                PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "$1")"
            fi
            INTERFACES_DIR="$PROFILE_DIR/iface-routing/interfaces"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift
done

[ -n "$SOURCE_FILE" ] || die "Не указан --source"
[ -f "$SOURCE_FILE" ] || die "Файл .ovpn не найден: $SOURCE_FILE"
[ -n "$IFACE_NAME" ] || die "Не указано --iface"

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

IFACE_NAME="$(sanitize_name "$IFACE_NAME")"
[ -n "$IFACE_NAME" ] || die "Некорректное имя интерфейса"

# Слотовая нумерация для маршрутизации
find_free_slot() {
    used_slots=" "
    if [ -d "$INTERFACES_DIR" ]; then
        for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
            [ -f "$cfg" ] || continue
            cur_slot="$(awk -F= '$1=="ROUTE_TABLE_ID"{gsub(/[ \047]/,"",$2); print $2}' "$cfg" 2>/dev/null || true)"
            case "$cur_slot" in
                ''|*[!0-9]*) ;;
                *) used_slots="${used_slots}$((cur_slot - 100)) " ;;
            esac
        done
    fi

    slot_candidate=1
    while [ "$slot_candidate" -le 250 ]; do
        case "$used_slots" in
            *" $slot_candidate "*)
                slot_candidate=$((slot_candidate + 1))
                ;;
            *)
                printf '%s\n' "$slot_candidate"
                return 0
                ;;
        esac
    done
    die "Не удалось найти свободный routing slot"
}

IFACE_CONFIG_DIR="$INTERFACES_DIR/$IFACE_NAME/config"
EXISTING_CONF="$IFACE_CONFIG_DIR/iface.conf"

if [ -f "$EXISTING_CONF" ]; then
    existing_tbl="$(awk -F= '$1=="ROUTE_TABLE_ID"{gsub(/[ \047]/,"",$2); print $2}' "$EXISTING_CONF" 2>/dev/null || true)"
    if [ -n "$existing_tbl" ] && [ "$existing_tbl" -gt 100 ]; then
        SLOT="$((existing_tbl - 100))"
    else
        SLOT="$(find_free_slot)"
    fi
else
    SLOT="$(find_free_slot)"
fi

MARK_HEX="$(printf '0x%x' "$((0x1100 + SLOT))")"
ROUTE_TABLE_ID="$((100 + SLOT))"
ROUTE_TABLE_NAME="${ROUTE_TABLE_PREFIX}${IFACE_NAME}"
IP_RULE_PREF="$((10000 + SLOT * 10))"
VPN_DEV="tun-${IFACE_NAME}"

NFT_FQDN4_SET_NAME="${IFACE_NAME}_fqdn4"
NFT_FQDN6_SET_NAME="${IFACE_NAME}_fqdn6"
NFT_PREFIX4_SET_NAME="${IFACE_NAME}_prefix4"
NFT_PREFIX6_SET_NAME="${IFACE_NAME}_prefix6"
NFT_CHAIN_NAME="mangle_prerouting_${IFACE_NAME}"
NFT_OUTPUT_CHAIN_NAME="mangle_output_${IFACE_NAME}"

mkdir -p "$IFACE_CONFIG_DIR"
mkdir -p "$INTERFACES_DIR/$IFACE_NAME/fqdn.d"
mkdir -p "$INTERFACES_DIR/$IFACE_NAME/fqdn.exclude.d"
mkdir -p "$INTERFACES_DIR/$IFACE_NAME/prefix.d"

# Автоматическое добавление инфраструктурных исключений XFT для новых туннелей
if [ ! -f "$INTERFACES_DIR/$IFACE_NAME/fqdn.exclude.d/user__group__xft.lst" ] && [ -f "$ROOT_DIR/upstreams/user/upstream/xft/fqdn-xft.lst" ]; then
    cp -f "$ROOT_DIR/upstreams/user/upstream/xft/fqdn-xft.lst" "$INTERFACES_DIR/$IFACE_NAME/fqdn.exclude.d/user__group__xft.lst"
fi

# 1. Сохраняем оригинал
src_real="$(readlink -f "$SOURCE_FILE" 2>/dev/null || printf '%s' "$SOURCE_FILE")"
dst_real="$(readlink -f "$IFACE_CONFIG_DIR/source.ovpn" 2>/dev/null || printf '%s' "$IFACE_CONFIG_DIR/source.ovpn")"
if [ "$src_real" != "$dst_real" ]; then
    cp -f "$SOURCE_FILE" "$IFACE_CONFIG_DIR/source.ovpn"
fi

# 2. Генерируем безопасный рабочий client.ovpn:
# - убираем системный redirect-gateway / перехват default route
# - убираем Windows-специфичные директивы (windows-driver, up/down scripts)
# - добавляем dev tun-<iface>, route-nopull, nobind
CLIENT_OVPN="$IFACE_CONFIG_DIR/client.ovpn"
awk '
    BEGIN { has_dev = 0; has_nobind = 0; has_nopull = 0; }
    { gsub(/\r$/, "", $0) }
    /^[[:space:]]*redirect-gateway/ { next }
    /^[[:space:]]*route-gateway/ { next }
    /^[[:space:]]*dev[[:space:]]/ { next }
    /^[[:space:]]*dev-type[[:space:]]/ { next }
    /^[[:space:]]*auth-user-pass/ { next }
    /^[[:space:]]*static-challenge/ { next }
    /^[[:space:]]*echo[[:space:]]/ { next }
    /^[[:space:]]*windows-driver/ { next }
    /^[[:space:]]*up[[:space:]]/ { next }
    /^[[:space:]]*down[[:space:]]/ { next }
    /^[[:space:]]*script-security/ { next }
    /^[[:space:]]*nobind/ { has_nobind = 1 }
    /^[[:space:]]*route-nopull/ { has_nopull = 1 }
    { print }
' "$SOURCE_FILE" > "$CLIENT_OVPN"

cat >> "$CLIENT_OVPN" <<EOF2

# --- Параметры интеграции xfree-toolbox ---
dev $VPN_DEV
dev-type tun
route-nopull
route-noexec
nobind
persist-tun
persist-key
auth-nocache
EOF2

auth_fmt="${TOTP_AUTH_FORMAT:-scrv1}"
if [ -f "$IFACE_CONFIG_DIR/credentials.env" ]; then
    [ -n "$AUTH_USER" ] || AUTH_USER="$(grep -E '^AUTH_USER=' "$IFACE_CONFIG_DIR/credentials.env" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
    [ -n "$AUTH_PASS" ] || AUTH_PASS="$(grep -E '^AUTH_PASS=' "$IFACE_CONFIG_DIR/credentials.env" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
    [ -n "$TOTP_SECRET" ] || TOTP_SECRET="$(grep -E '^TOTP_SECRET=' "$IFACE_CONFIG_DIR/credentials.env" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
    saved_fmt="$(grep -E '^TOTP_AUTH_FORMAT=' "$IFACE_CONFIG_DIR/credentials.env" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
    [ -z "$TOTP_AUTH_FORMAT" ] && [ -n "$saved_fmt" ] && auth_fmt="$saved_fmt"
fi

if [ -n "$AUTH_USER" ]; then
    cat >> "$CLIENT_OVPN" <<EOF2
auth-user-pass /etc/xfree-toolbox/iface-routing/openvpn/$IFACE_NAME.auth
EOF2

    cat > "$IFACE_CONFIG_DIR/credentials.env" <<EOF2
AUTH_USER='$AUTH_USER'
AUTH_PASS='$AUTH_PASS'
TOTP_SECRET='$TOTP_SECRET'
TOTP_AUTH_FORMAT='$auth_fmt'
EOF2
    chmod 600 "$IFACE_CONFIG_DIR/credentials.env" 2>/dev/null || true
fi

# Определение DNS серверов туннеля (аргумент, сохранённый конфиг или dhcp-option DNS)
if [ -z "$DNS_SERVERS" ]; then
    if [ -f "$EXISTING_CONF" ]; then
        DNS_SERVERS="$(grep -E '^DNS_VALUE=' "$EXISTING_CONF" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
    fi
    if [ -z "$DNS_SERVERS" ]; then
        parsed_dns="$(awk '
            BEGIN { dns = "" }
            /^[[:space:]]*dhcp-option[[:space:]]+DNS[[:space:]]+/ {
                ip = $3
                gsub(/\r$/, "", ip)
                if (ip ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) {
                    if (dns == "") dns = ip
                    else dns = dns ", " ip
                }
            }
            END { print dns }
        ' "$SOURCE_FILE" 2>/dev/null || true)"
        [ -n "$parsed_dns" ] && DNS_SERVERS="$parsed_dns"
    fi
fi

# Определение endpoint remote (хост, порт, протокол)
remote_line="$(awk '
    /^[[:space:]]*remote[[:space:]]+/ {
        gsub(/\r$/, "", $0)
        print $0
        exit
    }
' "$SOURCE_FILE" 2>/dev/null || true)"

ENDPOINT_HOST=""
ENDPOINT_PORT="1194"
ENDPOINT_PROTO="udp"
if [ -n "$remote_line" ]; then
    ENDPOINT_HOST="$(printf '%s' "$remote_line" | awk '{print $2}')"
    _rport="$(printf '%s' "$remote_line" | awk '{print $3}')"
    [ -n "$_rport" ] && ENDPOINT_PORT="$_rport"
    _rproto="$(printf '%s' "$remote_line" | awk '{print $4}')"
    case "$_rproto" in
        *tcp*) ENDPOINT_PROTO="tcp" ;;
        *) ENDPOINT_PROTO="udp" ;;
    esac
fi

case "$ENDPOINT_HOST" in
    *[!0-9.]*)
        printf '%s\n' "$ENDPOINT_HOST" > "$INTERFACES_DIR/$IFACE_NAME/fqdn.exclude.d/endpoint.lst"
        ;;
esac

if [ -z "$TEST_IP" ] && [ -f "$EXISTING_CONF" ]; then
    TEST_IP="$(grep -E '^TEST_IP=' "$EXISTING_CONF" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
fi
TEST_IP="$(printf '%s' "${TEST_IP:-none}" | sed -E 's|^https?://||; s|/.*$||; s|:[0-9]+$||')"
case "$TEST_IP" in
    ''|none|off|disable|disabled|0)
        TEST_IP='none'
        ;;
    *[!A-Za-z0-9_.-]*)
        die "Некорректный --test-ip '$TEST_IP': ожидается IP-адрес или домен (либо none)"
        ;;
esac

# 3. Генерируем iface.conf
cat > "$IFACE_CONFIG_DIR/iface.conf" <<EOF2
# shellcheck shell=sh

INTERFACE_NAME='$IFACE_NAME'
VPN_DEV='$VPN_DEV'

SOURCE_CONF='source.ovpn'
SOURCE_META='source.ovpn.meta'

NETWORK_DELETE_SECTIONS='$IFACE_NAME openvpn_$IFACE_NAME'
FIREWALL_MODEL='shared-vpn-zone'

MARK_HEX='$MARK_HEX'
ROUTE_TABLE_ID='$ROUTE_TABLE_ID'
ROUTE_TABLE_NAME='$ROUTE_TABLE_NAME'
IP_RULE_PREF='$IP_RULE_PREF'

ROUTING_MODE='vpn'
PROTOCOL_LABEL='OpenVPN'

ENDPOINT_HOST='$ENDPOINT_HOST'
ENDPOINT_PORT='$ENDPOINT_PORT'
ENDPOINT_PROTO='$ENDPOINT_PROTO'

TEST_IP='$TEST_IP'
DNS_VALUE='$DNS_SERVERS'
ORIGINAL_DNS_VALUE='$DNS_SERVERS'

NFT_FQDN4_SET_NAME='$NFT_FQDN4_SET_NAME'
NFT_FQDN6_SET_NAME='$NFT_FQDN6_SET_NAME'
NFT_PREFIX4_SET_NAME='$NFT_PREFIX4_SET_NAME'
NFT_PREFIX6_SET_NAME='$NFT_PREFIX6_SET_NAME'
NFT_CHAIN_NAME='$NFT_CHAIN_NAME'
NFT_OUTPUT_CHAIN_NAME='$NFT_OUTPUT_CHAIN_NAME'

SELF_ROUTE_VIA=''
PBR_BYPASS_NETWORKS=''
EOF2

# 4. Генерируем source.ovpn.meta
cat > "$IFACE_CONFIG_DIR/source.ovpn.meta" <<EOF2
GENERATOR_KIND='openvpn'
SOURCE_BASENAME='$(basename "$SOURCE_FILE")'
UPDATED_AT='$(date -Iseconds 2>/dev/null || date)'
ENDPOINT_HOST='$ENDPOINT_HOST'
ENDPOINT_PORT='$ENDPOINT_PORT'
ENDPOINT_PROTO='$ENDPOINT_PROTO'
TEST_IP='$TEST_IP'
DNS_VALUE='$DNS_SERVERS'
ORIGINAL_DNS_VALUE='$DNS_SERVERS'
EOF2

# Обеспечиваем совместимость с модулями, ожидающими source.conf.meta
ln -sf "source.ovpn.meta" "$IFACE_CONFIG_DIR/source.conf.meta" 2>/dev/null || cp -f "$IFACE_CONFIG_DIR/source.ovpn.meta" "$IFACE_CONFIG_DIR/source.conf.meta"


# 5. Генерируем network.uci
cat > "$IFACE_CONFIG_DIR/network.uci" <<EOF2
package network

config interface '$IFACE_NAME'
        option proto 'none'
        option device '$VPN_DEV'
        option defaultroute '0'
        option peerdns '0'
EOF2

# 6. Генерируем openvpn.uci
cat > "$IFACE_CONFIG_DIR/openvpn.uci" <<EOF2
package openvpn

config openvpn '$IFACE_NAME'
        option enabled '1'
        option config '/etc/xfree-toolbox/iface-routing/openvpn/$IFACE_NAME.ovpn'
EOF2

success "OpenVPN интерфейс '$IFACE_NAME' успешно сконфигурирован в $IFACE_CONFIG_DIR"
info "Device: $VPN_DEV, Routing Table: $ROUTE_TABLE_NAME ($ROUTE_TABLE_ID), Mark: $MARK_HEX"
