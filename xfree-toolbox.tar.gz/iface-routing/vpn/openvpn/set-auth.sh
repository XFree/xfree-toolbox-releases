#!/bin/sh
# shellcheck shell=sh
# Смена логина и пароля OpenVPN в профиле (credentials.env).
# Пароль не печатается: рабочий .auth собирает apply из этого файла.
set -eu

if [ -z "${ROOT_DIR:-}" ] || [ ! -f "${ROOT_DIR}/lib/common.sh" ]; then
    SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
    DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
    ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"
fi

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"

IFACE_NAME=""
AUTH_USER_NEW=""
AUTH_PASS_NEW=""
HAS_USER=0
HAS_PASS=0
PRINT_USER=0

usage() {
    cat <<EOF
Usage: $(basename "$0") --iface NAME (--auth-pass PASS | --print-user) [--auth-user USER] [--profile-dir DIR]

Меняет AUTH_USER и AUTH_PASS в профиле туннеля OpenVPN.
Секрет TOTP не изменяется. Пароль в вывод не попадает.
Применение на роутере — отдельный шаг (apply).
EOF
}

shell_sq() {
    printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\\\''/g")"
}

reject_newline() {
    _label="$1"
    _value="$2"
    case "$_value" in
        *'
'*) die "$_label содержит перевод строки" ;;
    esac
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --iface)
            shift
            [ "$#" -gt 0 ] || die "--iface требует имя"
            IFACE_NAME="$1"
            ;;
        --auth-user)
            shift
            [ "$#" -gt 0 ] || die "--auth-user требует имя пользователя"
            AUTH_USER_NEW="$1"
            HAS_USER=1
            ;;
        --auth-pass)
            shift
            [ "$#" -gt 0 ] || die "--auth-pass требует пароль"
            AUTH_PASS_NEW="$1"
            HAS_PASS=1
            ;;
        --print-user)
            PRINT_USER=1
            ;;
        --profile-dir)
            shift
            [ "$#" -gt 0 ] || die "--profile-dir требует путь"
            if [ -d "$1" ]; then
                PROFILE_DIR="$1"
            else
                PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "$1")"
            fi
            INTERFACES_DIR="$PROFILE_DIR/iface-routing/interfaces"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift
done

[ -n "$IFACE_NAME" ] || die "Не указано --iface"
case "$IFACE_NAME" in
    *[!A-Za-z0-9._-]*) die "Некорректное имя интерфейса" ;;
esac

IFACE_CONFIG_DIR="$INTERFACES_DIR/$IFACE_NAME/config"
[ -d "$IFACE_CONFIG_DIR" ] || die "Нет туннеля: $IFACE_NAME"
if [ ! -f "$IFACE_CONFIG_DIR/client.ovpn" ] && [ ! -f "$IFACE_CONFIG_DIR/source.ovpn" ] && [ ! -f "$IFACE_CONFIG_DIR/credentials.env" ]; then
    die "Туннель $IFACE_NAME не использует логин OpenVPN"
fi

AUTH_USER=""
AUTH_PASS=""
TOTP_SECRET=""
TOTP_AUTH_FORMAT=""
if [ -f "$IFACE_CONFIG_DIR/credentials.env" ]; then
    # shellcheck disable=SC1090
    . "$IFACE_CONFIG_DIR/credentials.env"
fi

if [ "$PRINT_USER" = "1" ]; then
    printf '%s\n' "${AUTH_USER:-}"
    exit 0
fi

[ "$HAS_PASS" = "1" ] || die "Не указан --auth-pass"
[ -n "$AUTH_PASS_NEW" ] || die "Пароль пустой"
reject_newline "Пароль" "$AUTH_PASS_NEW"

if [ "$HAS_USER" = "1" ]; then
    [ -n "$AUTH_USER_NEW" ] || die "Логин пустой"
    reject_newline "Логин" "$AUTH_USER_NEW"
    AUTH_USER="$AUTH_USER_NEW"
fi
[ -n "${AUTH_USER:-}" ] || die "Логин не задан"
AUTH_PASS="$AUTH_PASS_NEW"

auth_fmt="${TOTP_AUTH_FORMAT:-scrv1}"
cred="$IFACE_CONFIG_DIR/credentials.env"
tmp="${cred}.tmp.$$"
{
    printf 'AUTH_USER=%s\n' "$(shell_sq "$AUTH_USER")"
    printf 'AUTH_PASS=%s\n' "$(shell_sq "$AUTH_PASS")"
    printf 'TOTP_SECRET=%s\n' "$(shell_sq "${TOTP_SECRET:-}")"
    printf 'TOTP_AUTH_FORMAT=%s\n' "$(shell_sq "$auth_fmt")"
} >"$tmp"
chmod 600 "$tmp" 2>/dev/null || true
mv -f "$tmp" "$cred"

client="$IFACE_CONFIG_DIR/client.ovpn"
auth_line="auth-user-pass /etc/xfree-toolbox/iface-routing/openvpn/${IFACE_NAME}.auth"
if [ -f "$client" ] && ! grep -qE '^[[:space:]]*auth-user-pass[[:space:]]' "$client"; then
    printf '\n%s\n' "$auth_line" >>"$client"
fi

printf 'Пароль OpenVPN для %s записан в профиль (логин: %s).\n' "$IFACE_NAME" "$AUTH_USER"
