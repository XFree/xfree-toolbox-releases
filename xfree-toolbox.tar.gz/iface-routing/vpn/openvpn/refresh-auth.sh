#!/bin/sh
# shellcheck shell=sh
set -eu

iface="${1:-}"
[ -n "$iface" ] || { echo "Usage: $(basename "$0") <interface_name>" >&2; exit 1; }

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
TOTP_SCRIPT="${TOTP_SCRIPT:-$SCRIPT_DIR/totp-gen.sh}"

runtime_dir="${RUNTIME_OPENVPN_DIR:-/etc/xfree-toolbox/iface-routing/openvpn}"
env_file="$runtime_dir/$iface.env"
auth_file="$runtime_dir/$iface.auth"

[ -f "$env_file" ] || exit 0

AUTH_USER=""
AUTH_PASS=""
TOTP_SECRET=""
TOTP_AUTH_FORMAT=""

# shellcheck disable=SC1090
. "$env_file"

[ -n "${AUTH_USER:-}" ] || exit 0

otp_val=""
if [ -n "${TOTP_SECRET:-}" ]; then
    if [ -x "$TOTP_SCRIPT" ]; then
        otp_val="$("$TOTP_SCRIPT" "$TOTP_SECRET" 2>/dev/null || true)"
    elif command -v oathtool >/dev/null 2>&1; then
        otp_val="$(oathtool --totp -b "$TOTP_SECRET" 2>/dev/null || true)"
    fi
fi

encode_b64() {
    if command -v base64 >/dev/null 2>&1; then
        printf '%s' "$1" | base64 | tr -d '\r\n '
    elif command -v openssl >/dev/null 2>&1; then
        printf '%s' "$1" | openssl base64 | tr -d '\r\n '
    else
        echo "[-] base64 command not found" >&2
        return 1
    fi
}

tmp_auth="$auth_file.tmp.$$"
if [ -n "$otp_val" ]; then
    format="${TOTP_AUTH_FORMAT:-scrv1}"
    case "$format" in
        scrv1|SCRV1)
            b64_p="$(encode_b64 "$AUTH_PASS")"
            b64_o="$(encode_b64 "$otp_val")"
            printf '%s\nSCRV1:%s:%s\n' "$AUTH_USER" "$b64_p" "$b64_o" > "$tmp_auth"
            ;;
        concat)
            printf '%s\n%s%s\n' "$AUTH_USER" "$AUTH_PASS" "$otp_val" > "$tmp_auth"
            ;;
        otp_first)
            printf '%s\n%s%s\n' "$AUTH_USER" "$otp_val" "$AUTH_PASS" > "$tmp_auth"
            ;;
        *)
            b64_p="$(encode_b64 "$AUTH_PASS")"
            b64_o="$(encode_b64 "$otp_val")"
            printf '%s\nSCRV1:%s:%s\n' "$AUTH_USER" "$b64_p" "$b64_o" > "$tmp_auth"
            ;;
    esac
else
    printf '%s\n%s\n' "$AUTH_USER" "$AUTH_PASS" > "$tmp_auth"
fi
chmod 600 "$tmp_auth" 2>/dev/null || true
mv -f "$tmp_auth" "$auth_file"

