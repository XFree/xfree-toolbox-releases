#!/bin/sh
# shellcheck shell=sh
# CLI: пересобрать Proton .conf (guest или web с живой сессией) и применить.
#   sh renew-guest-iface.sh --iface NAME
#   sh renew-guest-iface.sh --all
#   sh renew-guest-iface.sh --iface NAME --if-due
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../../.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/iface-routing/vpn/lib/proton-guest-renew.sh"

IFACE=""
DO_ALL=0
IF_DUE=0

usage() {
    cat <<EOF
Usage: $(basename "$0") [--iface NAME | --all] [--if-due]

Rebuild Proton source.conf, then apply that iface.

  guest  — mint a new credentialless session (like WARP register) and a new .conf
  web    — AUTH/REFRESH cookies still valid, then API refresh+auth; dead session is skipped

  --if-due   skip unless CERT_EXPIRATION_UNIX is within skew (default 600s)
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --iface)
            shift
            [ "$#" -gt 0 ] || {
                echo "--iface требует имя" >&2
                exit 1
            }
            IFACE="$1"
            ;;
        --all) DO_ALL=1 ;;
        --if-due) IF_DUE=1 ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Неизвестный аргумент: $1" >&2
            usage
            exit 1
            ;;
    esac
    shift || true
done

[ "$DO_ALL" = "1" ] || [ -n "$IFACE" ] || {
    usage
    exit 1
}

USB_WATCH_ROOT_DIR="${USB_WATCH_ROOT_DIR:-$ROOT_DIR}"
export USB_WATCH_ROOT_DIR

renew_one() {
    _n="$1"
    proton_guest_renew_can_renew_iface "$_n" || {
        echo "пропуск $_n: не guest и нет валидной web-сессии (непросроченные AUTH/REFRESH cookies)" >&2
        return 1
    }
    if [ "$IF_DUE" = "1" ]; then
        proton_guest_renew_cert_due_iface "$_n" || {
            echo "пропуск $_n: certificate ещё не истекает" >&2
            return 0
        }
    fi
    echo "Proton renew: $_n"
    proton_guest_renew_execute "$_n"
}

if [ "$DO_ALL" = "1" ]; then
    _any=0
    _fail=0
    _list="$(proton_guest_renew_list_guest_ifaces || true)"
    [ -n "$_list" ] || {
        echo "нет guest Proton и нет web-интерфейсов с живой сессией" >&2
        exit 1
    }
    while IFS= read -r _n; do
        [ -n "$_n" ] || continue
        _any=1
        renew_one "$_n" || _fail=1
    done <<EOF
$_list
EOF
    [ "$_any" = "1" ] || {
        echo "нет guest Proton и нет web-интерфейсов с живой сессией" >&2
        exit 1
    }
    [ "$_fail" = "0" ]
    exit $?
fi

renew_one "$IFACE"
