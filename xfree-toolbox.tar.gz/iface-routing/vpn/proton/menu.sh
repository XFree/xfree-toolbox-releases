#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
UI_SH="$ROOT_DIR/lib/ui.sh"
PROTON_API_SH="$VPN_DIR/lib/proton-api.sh"
COUNTRIES_SH="$SCRIPT_DIR/countries.sh"
MODULE_CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

if command -v load_base_config >/dev/null 2>&1; then
    load_base_config "$SCRIPT_DIR"
fi

[ -f "$UI_SH" ] || {
    echo "[-] Не найден ui.sh: $UI_SH" >&2
    exit 1
}
. "$UI_SH"

[ -f "$PROTON_API_SH" ] || {
    echo "[-] Не найден proton-api.sh: $PROTON_API_SH" >&2
    exit 1
}
. "$PROTON_API_SH"

[ -f "$COUNTRIES_SH" ] || {
    echo "[-] Не найден countries.sh: $COUNTRIES_SH" >&2
    exit 1
}
. "$COUNTRIES_SH"

if command -v load_module_config >/dev/null 2>&1; then
    load_module_config "$MODULE_CONFIG_FILE"
elif [ -f "$MODULE_CONFIG_FILE" ]; then
    . "$MODULE_CONFIG_FILE"
fi

GENERATOR_SH="$SCRIPT_DIR/generate.sh"
IMPORT_CONF_SH="$SCRIPT_DIR/import-conf.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"
_DEFAULT_PROTON_CONF="$(xfree_profile_proton_conf_dir "$PROFILE_DIR")"
PROFILE_PROTON_CONF_DIR="${PROFILE_PROTON_CONF_DIR:-${PROFILE_PROTON_GENERATED_DIR:-$_DEFAULT_PROTON_CONF}}"
CONF_DIR="${CONF_DIR:-$PROFILE_PROTON_CONF_DIR}"

STATE_DIR="${PROTON_MENU_STATE_DIR:-/tmp/domain-routing-proton}"
mkdir -p "$STATE_DIR"

COUNTRY_FILE="$STATE_DIR/country"
PROFILE_FILE="$STATE_DIR/profile"
NAME_FILE="$STATE_DIR/name"
SELECTION_MODE_FILE="$STATE_DIR/selection_mode"
MTU_FILE="$STATE_DIR/mtu"
SESSION_FILE="$STATE_DIR/session"
SESSION_MODE_FILE="$STATE_DIR/session_mode"
FREE_ONLY_FILE="$STATE_DIR/free_only"
REQUIRE_IPV6_FILE="$STATE_DIR/require_ipv6"
AWG_NOISE_FILE="$STATE_DIR/awg_noise"
I1_ENTROPY_FILE="$STATE_DIR/i1_entropy"

DEFAULT_COUNTRY="${DEFAULT_COUNTRY:-NL}"
DEFAULT_PROFILE="${DEFAULT_PROFILE:-2.0:1}"
DEFAULT_MODE="${DEFAULT_MODE:-local}"
DEFAULT_SELECTION_MODE="${DEFAULT_SELECTION_MODE:-best}"
DEFAULT_MTU="${DEFAULT_MTU:-1420}"
: "${XFREE_STATE_ROOT:=/etc/xfree-toolbox}"
: "${XFREE_VPN_ROOT:=$XFREE_STATE_ROOT/vpn}"
PROTON_STATE_DIR="${PROTON_STATE_DIR:-$XFREE_VPN_ROOT/state/proton}"
PROTON_SESSIONS_DIR="${PROTON_SESSIONS_DIR:-$PROTON_STATE_DIR/sessions}"

default_country() { printf '%s\n' "$DEFAULT_COUNTRY"; }
default_profile() { printf '%s\n' "$DEFAULT_PROFILE"; }
default_selection_mode() { printf '%s\n' "$DEFAULT_SELECTION_MODE"; }
default_mtu() { printf '%s\n' "$DEFAULT_MTU"; }
default_session() { printf '%s\n' ""; }
default_free_only() { printf '%s\n' "${PROTON_USE_FREE_ONLY:-1}"; }
default_require_ipv6() { printf '%s\n' "${PROTON_REQUIRE_IPV6:-0}"; }
default_awg_noise() { printf '%s\n' "${DEFAULT_AWG_NOISE_ENABLED:-0}"; }
default_i1_entropy() { printf '%s\n' "${DEFAULT_AWG_I1_ENTROPY:-r32}"; }

get_selected_country() { [ -f "$COUNTRY_FILE" ] && cat "$COUNTRY_FILE" || default_country; }
set_selected_country() { printf '%s\n' "$1" > "$COUNTRY_FILE"; }

get_selected_profile() { [ -f "$PROFILE_FILE" ] && cat "$PROFILE_FILE" || default_profile; }
set_selected_profile() { printf '%s\n' "$1" > "$PROFILE_FILE"; }
get_selected_version() { get_selected_profile | cut -d: -f1; }
get_selected_variant() { get_selected_profile | cut -d: -f2; }

get_selected_name() { [ -f "$NAME_FILE" ] && cat "$NAME_FILE" || true; }
set_selected_name() { printf '%s\n' "$1" > "$NAME_FILE"; }

get_selected_selection_mode() { [ -f "$SELECTION_MODE_FILE" ] && cat "$SELECTION_MODE_FILE" || default_selection_mode; }
set_selected_selection_mode() { printf '%s\n' "$1" > "$SELECTION_MODE_FILE"; }

get_selected_mtu() { [ -f "$MTU_FILE" ] && cat "$MTU_FILE" || default_mtu; }
set_selected_mtu() { printf '%s\n' "$1" > "$MTU_FILE"; }

get_selected_session() { [ -f "$SESSION_FILE" ] && cat "$SESSION_FILE" || default_session; }
set_selected_session() { printf '%s\n' "$1" > "$SESSION_FILE"; }

# guest = mint credentialless session on each generate (WARP-style --acquire-guest).
# named = reuse cookies / leftover bundle via --session.
default_session_mode() {
    sess="$(get_selected_session)"
    [ -n "$sess" ] || { printf '%s\n' "guest"; return 0; }
    case "$sess" in
        guest-*) printf '%s\n' "guest" ;;
        *) printf '%s\n' "named" ;;
    esac
}

get_selected_session_mode() {
    if [ -f "$SESSION_MODE_FILE" ]; then
        _mode="$(tr -d '\r\n' <"$SESSION_MODE_FILE")"
        case "$_mode" in
            guest|named) printf '%s\n' "$_mode"; return 0 ;;
        esac
    fi
    default_session_mode
}

set_selected_session_mode() { printf '%s\n' "$1" > "$SESSION_MODE_FILE"; }

session_mode_is_guest() {
    [ "$(get_selected_session_mode)" = "guest" ]
}
get_selected_free_only() { [ -f "$FREE_ONLY_FILE" ] && cat "$FREE_ONLY_FILE" || default_free_only; }
set_selected_free_only() { printf '%s\n' "$1" > "$FREE_ONLY_FILE"; }
get_selected_require_ipv6() { [ -f "$REQUIRE_IPV6_FILE" ] && cat "$REQUIRE_IPV6_FILE" || default_require_ipv6; }
set_selected_require_ipv6() { printf '%s\n' "$1" > "$REQUIRE_IPV6_FILE"; }
get_selected_awg_noise() { [ -f "$AWG_NOISE_FILE" ] && cat "$AWG_NOISE_FILE" || default_awg_noise; }
set_selected_awg_noise() { printf '%s\n' "$(proton_awg_normalize_noise_enabled "$1")" > "$AWG_NOISE_FILE"; }
get_selected_i1_entropy() {
    if [ -f "$I1_ENTROPY_FILE" ]; then
        proton_awg_normalize_i1_entropy "$(cat "$I1_ENTROPY_FILE")"
    else
        proton_awg_normalize_i1_entropy "$(default_i1_entropy)"
    fi
}
set_selected_i1_entropy() { printf '%s\n' "$(proton_awg_normalize_i1_entropy "$1")" > "$I1_ENTROPY_FILE"; }

profile_label() {
    case "$1" in
        "2.0:1") printf '%s\n' "AWG 2.0 (Вариант 1)" ;;
        "2.0:2") printf '%s\n' "AWG 2.0 (Вариант 2)" ;;
        "2.0:3") printf '%s\n' "AWG 2.0 (Вариант 3)" ;;
        "1.5:1") printf '%s\n' "AWG 1.5 (Вариант 1)" ;;
        "1.5:2") printf '%s\n' "AWG 1.5 (Вариант 2)" ;;
        "1.5:3") printf '%s\n' "AWG 1.5 (Вариант 3)" ;;
        *) printf '%s\n' "$1" ;;
    esac
}

mode_label() {
    case "$1" in
        local) printf '%s\n' "Local (под систему)" ;;
        raw)   printf '%s\n' "Raw (исходный)" ;;
        *)     printf '%s\n' "$1" ;;
    esac
}

selection_mode_label() {
    case "$1" in
        best) printf '%s\n' "Лучший по загрузке + probe top-5" ;;
        interactive) printf '%s\n' "Ручной выбор из списка" ;;
        *) printf '%s\n' "$1" ;;
    esac
}

session_label() {
    if session_mode_is_guest; then
        printf '%s\n' "гостевая (новая при generate, как WARP)"
        return 0
    fi
    val="$1"
    [ -n "$val" ] || { printf '%s\n' "<не выбрана>"; return 0; }
    mode=""
    for cand in \
        "${PROTON_SESSIONS_DIR:-}/$val" \
        "${PROTON_STATE_DIR:-}/sessions/$val"; do
        [ -d "$cand" ] || continue
        mode="$(proton_session_auth_mode_from_dir "$cand" 2>/dev/null || true)"
        [ -n "$mode" ] && break
    done
    case "$mode" in
        guest) printf '%s [guest leftover]\n' "$val" ;;
        *) printf '%s\n' "$val" ;;
    esac
}

session_short_label() {
    val="$1"
    [ -n "$val" ] || { printf '%s\n' "<не выбрана>"; return 0; }
    basename "$val"
}

free_only_label() {
    case "$1" in
        1|yes|YES|true|TRUE) printf '%s\n' "только free" ;;
        0|no|NO|false|FALSE) printf '%s\n' "все tier" ;;
        *) printf '%s\n' "$1" ;;
    esac
}

require_ipv6_label() {
    case "$1" in
        1|yes|YES|true|TRUE) printf '%s\n' "только IPv6" ;;
        0|no|NO|false|FALSE) printf '%s\n' "все (IPv4 и IPv6)" ;;
        *) printf '%s\n' "$1" ;;
    esac
}

awg_noise_label() {
    case "$(proton_awg_normalize_noise_enabled "${1:-0}")" in
        1) printf '%s\n' "с шумом (Jc=4, Jmin=40, Jmax=70)" ;;
        *) printf '%s\n' "без шума (Jc/Jmin/Jmax=0)" ;;
    esac
}

i1_entropy_label() {
    proton_awg_i1_entropy_label "${1:-r32}"
}

list_sessions() {
    proton_list_relative_session_names
}

ensure_store_session_selection() {
    [ -n "${XFREE_VPN_STORE_ID:-}" ] || return 0
    if [ -f "$SESSION_MODE_FILE" ]; then
        _explicit="$(tr -d '\r\n' <"$SESSION_MODE_FILE")"
        [ "$_explicit" = "guest" ] && return 0
    fi
    session="$(get_selected_session)"
    if [ -n "$session" ] && proton_apply_rel_session_pick "$session"; then
        case "$session" in
            guest-*) return 0 ;;
        esac
        set_selected_session_mode named
        return 0
    fi
    latest="$(proton_newest_complete_session_name_in_dir "$PROTON_SESSIONS_DIR" 2>/dev/null || true)"
    [ -n "$latest" ] || {
        rm -f "$SESSION_FILE"
        return 0
    }
    case "$latest" in
        guest-*)
            # leftover credentialless bundle is not a permanent session
            return 0
            ;;
    esac
    set_selected_session "$latest"
    set_selected_session_mode named
}

select_named_session() {
    lines="$(list_sessions || true)"
    [ -n "${lines:-}" ] || {
        ui_msgbox "Proton генератор" "Каталоги постоянных сессий не найдены (state / профиль / PROTON_SESSIONS_DIR):

$(proton_state_sessions_dir)
${PROFILE_DIR:-}/vpn/proton/sessions
$PROTON_SESSIONS_DIR

Для гостевого режима выберите «Гостевая» — сессия создаётся при генерации .conf.
Постоянная сессия: cookies/Playwright (web) или уже лежащий бандл."
        return 1
    }

    choice="$(ui_select_from_lines "Proton генератор" "Выберите постоянную сессию Proton" "$lines" 22 100 12 || true)"
    [ -n "${choice:-}" ] || return 1
    set_selected_session_mode named
    set_selected_session "$choice"
    return 0
}

select_session() {
    current="$(session_label "$(get_selected_session)")"
    choice="$(ui_menu "Proton генератор" "Сессия для generate (raw, API)

Гостевая — как WARP: новая credentialless-сессия при каждой генерации
и при обновлении guest-.conf (--acquire-guest). Старые guest-* на диске
не переиспользуются.

Постоянная — cookies/Playwright или сохранённый бандл (--session).

Сейчас: $current" 20 92 6 \
        "guest" "Гостевая (новая сессия при каждой генерации .conf)" \
        "named" "Постоянная сессия (выбрать каталог)" \
        "0" "Назад" || true)"
    [ -n "${choice:-}" ] || return 0
    case "$choice" in
        guest)
            set_selected_session_mode guest
            ui_msgbox "Proton генератор" "Выбран гостевой режим (как WARP).

«Сгенерировать конфиг (raw, API)» вызовет --acquire-guest:
новая credentialless-сессия каждый раз.

Обновление уже созданного guest-туннеля тоже минтит новую сессию
(uplink renew / regenerate). Refresh старых guest-токенов для
нового .conf недостаточно — нужна новая гостевая сессия."
            ;;
        named)
            select_named_session || true
            ;;
        0|"") ;;
    esac
}

delete_selected_session() {
    if session_mode_is_guest; then
        ui_msgbox "Proton генератор" "Сейчас гостевой режим: постоянный каталог не выбран.

Чтобы удалить leftover guest-* или web-бандл, сначала выберите
«Постоянная сессия», затем этот пункт."
        return 0
    fi
    session="$(get_selected_session)"
    [ -n "$session" ] || {
        ui_msgbox "Proton генератор" "Сначала выберите постоянную сессию Proton."
        return 0
    }

    case "$session" in
        ""|.|..|*/*)
            ui_msgbox "Proton генератор" "Небезопасное имя сессии:

$session"
            return 0
            ;;
    esac

    if ! proton_apply_rel_session_pick "$session"; then
        state_s="${PROTON_STATE_DIR}/sessions"
        profile_s=""
        [ -n "${PROFILE_DIR:-}" ] && profile_s="$PROFILE_DIR/vpn/proton/sessions"
        miss_paths="$state_s/$session"
        if [ -n "$profile_s" ]; then
            miss_paths="$miss_paths
$profile_s/$session"
        fi
        miss_paths="$miss_paths
$PROTON_SESSIONS_DIR/$session"
        ui_msgbox "Proton генератор" "Каталог сессии не найден (нужны cookies.txt и x_pm_uid.txt). Проверьте:

$miss_paths"
        return 0
    fi
    target_dir="$PROTON_SESSION_DIR"

    if ui_confirm "Удалить Proton session" "Будет удалён каталог сессии:

$target_dir

Продолжить?"; then
        rm -rf "$target_dir"
        rm -f "$SESSION_FILE"
        success_msg="Сессия удалена:

$target_dir"
        ui_msgbox "Proton генератор" "$success_msg"
    fi
}

show_status() {
    country="$(get_selected_country)"
    profile="$(get_selected_profile)"
    selection_mode="$(get_selected_selection_mode)"
    free_only="$(get_selected_free_only)"
    require_ipv6="$(get_selected_require_ipv6)"
    awg_noise="$(get_selected_awg_noise)"
    i1_entropy="$(get_selected_i1_entropy)"
    mtu="$(get_selected_mtu)"
    session="$(get_selected_session)"
    name="$(get_selected_name)"
    [ -n "$name" ] || name="<авто>"

    ui_msgbox "Proton генератор" "Текущие параметры

Сессия:  $(session_label "$session")
Страна:  $(country_label "$country") [$country]
Профиль: $(profile_label "$profile") [$profile]
Шум:     $(awg_noise_label "$awg_noise") [$awg_noise]
I1:      $(i1_entropy_label "$i1_entropy") [$i1_entropy]
Выбор:   $(selection_mode_label "$selection_mode") [$selection_mode], servers=$(free_only_label "$free_only") [$free_only], ipv6=$(require_ipv6_label "$require_ipv6") [$require_ipv6]
MTU:     $mtu
Имя:     $name
Сессии:  $PROTON_SESSIONS_DIR
Каталог: $CONF_DIR"
}

list_countries_from_server() {
    session="$(get_selected_session)"
    if [ -z "$session" ]; then
        session="$(proton_newest_complete_session_name_in_dir "$PROTON_SESSIONS_DIR" 2>/dev/null || true)"
    fi
    [ -n "$session" ] || return 1

    PROTON_SELECTED_SESSION="$session"
    proton_require_auth >/dev/null 2>&1
    proton_fetch_logicals >/dev/null 2>&1

    use_free_only="$(get_selected_free_only)"
    case "$use_free_only" in
        1|yes|YES|true|TRUE) use_free_only=1 ;;
        0|no|NO|false|FALSE) use_free_only=0 ;;
        *) use_free_only=1 ;;
    esac
    require_ipv6="$(get_selected_require_ipv6)"
    case "$require_ipv6" in
        1|yes|YES|true|TRUE) require_ipv6=1 ;;
        *) require_ipv6=0 ;;
    esac

    PROTON_USE_FREE_ONLY="$use_free_only"
    PROTON_REQUIRE_IPV6="$require_ipv6"
    proton_list_country_codes_from_logicals \
        | sed '/^$/d' \
        | common_upper_ascii_stream \
        | sort -u
}

select_free_only_mode() {
    current="$(get_selected_free_only)"
    choice="$(ui_menu "Proton генератор" "Фильтр tier

Текущий: $(free_only_label "$current")" 16 80 6 \
        "1" "Только free (Tier=0)" \
        "0" "Все tier (free+paid)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_free_only "$choice"
    if [ "$choice" != "$current" ]; then
        ui_msgbox "Proton генератор" "Фильтр серверов обновлён:

$(free_only_label "$choice") [$choice]"
    fi
}

select_require_ipv6_mode() {
    current="$(get_selected_require_ipv6)"
    choice="$(ui_menu "Proton генератор" "Фильтр IPv6
Рядом с фильтром tier: все серверы или только с поддержкой IPv6.
Endpoint в .conf остаётся IPv4 (dual-stack узел).

Текущий: $(require_ipv6_label "$current")" 16 90 6 \
        "0" "Все серверы (IPv4 и IPv6)" \
        "1" "Только с поддержкой IPv6" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_require_ipv6 "$choice"
    if [ "$choice" != "$current" ]; then
        ui_msgbox "Proton генератор" "Фильтр IPv6 обновлён:

$(require_ipv6_label "$choice") [$choice]"
    fi
}

select_country() {
    session="$(get_selected_session)"
    if [ -z "$session" ]; then
        session="$(proton_newest_complete_session_name_in_dir "$PROTON_SESSIONS_DIR" 2>/dev/null || true)"
    fi
    [ -n "$session" ] || {
        if session_mode_is_guest; then
            ui_msgbox "Proton генератор" "В гостевом режиме список стран с API появится после первой генерации .conf (или если на диске уже есть leftover-бандл).

Сейчас страна фильтра: $(country_label "$(get_selected_country)") [$(get_selected_country)].
Генерация минтит новую credentialless-сессию."
        else
            ui_msgbox "Proton генератор" "Сначала выберите постоянную сессию Proton."
        fi
        return 0
    }

    countries="$(list_countries_from_server || true)"
    [ -n "${countries:-}" ] || {
        ui_msgbox "Proton генератор" "Не удалось получить список стран с сервера Proton."
        return 0
    }

    set --
    while IFS= read -r code; do
        [ -n "$code" ] || continue
        set -- "$@" "$code" "$(country_label "$code")"
    done <<EOF_COUNTRIES
$countries
EOF_COUNTRIES

    choice="$(ui_menu "Proton генератор" "Выберите страну фильтрации

Сессия: $(session_short_label "$session")" 22 80 14 "$@" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_country "$choice"
}

select_profile() {
    choice="$(ui_menu "Proton генератор" "Выберите профиль AWG" 20 90 10 \
        "2.0:1" "AWG 2.0 (Вариант 1)" \
        "2.0:2" "AWG 2.0 (Вариант 2)" \
        "2.0:3" "AWG 2.0 (Вариант 3)" \
        "1.5:1" "AWG 1.5 (Вариант 1)" \
        "1.5:2" "AWG 1.5 (Вариант 2)" \
        "1.5:3" "AWG 1.5 (Вариант 3)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_profile "$choice"
}

select_awg_noise() {
    current="$(get_selected_awg_noise)"
    choice="$(ui_menu "Proton генератор" "Шум AmneziaWG (junk packets: Jc, Jmin, Jmax)

Текущий: $(awg_noise_label "$current")" 18 90 6 \
        "0" "Без шума (Jc/Jmin/Jmax=0)" \
        "1" "С шумом (Jc=4, Jmin=40, Jmax=70)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_awg_noise "$choice"
}

select_i1_entropy() {
    current="$(get_selected_i1_entropy)"
    choice="$(ui_menu "Proton генератор" "Энтропия I1

К фиксированному I1 (<b 0x…>) дописывается выбранный тег AmneziaWG.

Текущий: $(i1_entropy_label "$current") [$current]" 22 92 10 \
        "r32" "<r 32> — 32 случайных байта (минимум)" \
        "r64" "<r 64> — 64 байта (паранойя)" \
        "t" "<t> — Unix timestamp (уникальность сессии)" \
        "c" "<c> — счётчик (уникальность I1–I5)" \
        "rc10" "<rc 10> — 10 случайных букв (HTTP)" \
        "rd6" "<rd 6> — 6 случайных цифр (ID в URL)" \
        "off" "Без энтропии (только <b 0x…>)" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_i1_entropy "$choice"
}

select_selection_mode() {
    choice="$(ui_menu "Proton генератор" "Выберите режим выбора сервера" 16 90 6 \
        "best" "Лучший по загрузке + probe top-5" \
        "interactive" "Ручной выбор из списка" || true)"
    [ -n "${choice:-}" ] || return 0
    set_selected_selection_mode "$choice"
}

edit_name() {
    cur="$(get_selected_name)"
    result="$(ui_inputbox "Proton генератор" "Введите базовое имя файла без .conf.
Пусто = имя будет выбрано автоматически." "$cur" || true)"
    [ -n "${result+x}" ] || return 0
    set_selected_name "$result"
}

proton_build_generate_cmd() {
    profile_mode="$1"
    session="$(get_selected_session)"
    country="$(get_selected_country)"
    ver="$(get_selected_version)"
    var="$(get_selected_variant)"
    selection_mode="$(get_selected_selection_mode)"
    free_only="$(get_selected_free_only)"
    require_ipv6="$(get_selected_require_ipv6)"
    awg_noise="$(get_selected_awg_noise)"
    i1_entropy="$(get_selected_i1_entropy)"
    mtu="$(get_selected_mtu)"
    name="$(get_selected_name)"

    if session_mode_is_guest; then
        cmd="'$GENERATOR_SH' --acquire-guest --country '$country' --version '$ver' --variant '$var' --$profile_mode --mtu '$mtu'"
    else
        cmd="'$GENERATOR_SH' --session '$session' --country '$country' --version '$ver' --variant '$var' --$profile_mode --mtu '$mtu'"
    fi

    case "$free_only" in
        1|yes|YES|true|TRUE) cmd="$cmd --free-only" ;;
        *) cmd="$cmd --all-tiers" ;;
    esac
    case "$require_ipv6" in
        1|yes|YES|true|TRUE) cmd="$cmd --ipv6-only" ;;
        *) cmd="$cmd --all-ip" ;;
    esac

    case "$selection_mode" in
        best) cmd="$cmd --best" ;;
        interactive) cmd="$cmd --interactive" ;;
    esac

    if [ "$(proton_awg_normalize_noise_enabled "$awg_noise")" = "1" ]; then
        cmd="$cmd --with-noise"
    fi
    cmd="$cmd --i1-entropy '$(proton_awg_normalize_i1_entropy "$i1_entropy")'"

    if [ -n "$name" ]; then
        cmd="$cmd --name '$name'"
    fi

    printf '%s\n' "$cmd"
}

generate_config_raw_api() {
    mkdir -p "$CONF_DIR"
    ensure_store_session_selection

    session="$(get_selected_session)"
    if session_mode_is_guest; then
        session_display="$(session_label "$session")"
    else
        [ -n "$session" ] || {
            ui_msgbox "Proton генератор" "Сначала выберите постоянную сессию Proton или гостевой режим.

${XFREE_VPN_STORE_ID:+ci/store/$XFREE_VPN_STORE_ID/vpn/proton/sessions — нет полного бандла (cookies+uid или guest tokens+uid).}"
            return 0
        }
        if ! proton_apply_rel_session_pick "$session"; then
            ui_msgbox "Proton генератор" "Сессия не найдена в текущем store:

$session

Каталог: $PROTON_SESSIONS_DIR"
            return 0
        fi
        session_display="$(session_label "$session")"
    fi

    country="$(get_selected_country)"
    profile="$(get_selected_profile)"
    selection_mode="$(get_selected_selection_mode)"
    free_only="$(get_selected_free_only)"
    require_ipv6="$(get_selected_require_ipv6)"
    awg_noise="$(get_selected_awg_noise)"
    i1_entropy="$(get_selected_i1_entropy)"
    mtu="$(get_selected_mtu)"
    name="$(get_selected_name)"
    cmd="$(proton_build_generate_cmd raw)"

    if ui_confirm "Proton генератор" "Сгенерировать конфиг (raw, API)?

Сессия:  $session_display
Страна:  $(country_label "$country") [$country]
Профиль: $(profile_label "$profile") [$profile]
Шум:     $(awg_noise_label "$awg_noise") [$awg_noise]
I1:      $(i1_entropy_label "$i1_entropy") [$i1_entropy]
Режим:   $(mode_label raw) [raw]
Выбор:   $(selection_mode_label "$selection_mode") [$selection_mode], servers=$(free_only_label "$free_only") [$free_only], ipv6=$(require_ipv6_label "$require_ipv6") [$require_ipv6]
MTU:     $mtu
Имя:     ${name:-<авто>}" ; then
        ui_menu_invoke_with_output "Генерация Proton-конфига (raw, API)" sh -c "$cmd"
    fi
}

import_config_raw() {
    mkdir -p "$CONF_DIR"

    country="$(get_selected_country)"
    ver="$(get_selected_version)"
    var="$(get_selected_variant)"
    awg_noise="$(get_selected_awg_noise)"
    i1_entropy="$(get_selected_i1_entropy)"
    mtu="$(get_selected_mtu)"
    name="$(get_selected_name)"

    source_mode="$(ui_menu "Proton генератор" "Сгенерировать конфиг (import --raw): источник" 16 90 6 \
        "1" "Из файла (путь к .conf)" \
        "2" "Вставить текст в терминал (stdin)" \
        "0" "Назад" || true)"
    [ -n "${source_mode:-}" ] || return 0
    [ "$source_mode" != "0" ] || return 0

    import_run_file() {
        source_file="$1"
        set -- "$IMPORT_CONF_SH" --version "$ver" --variant "$var" --country "$country" --raw --mtu "$mtu"
        [ -n "$name" ] && set -- "$@" --name "$name"
        [ "$(proton_awg_normalize_noise_enabled "$awg_noise")" = "1" ] && set -- "$@" --with-noise
        set -- "$@" --i1-entropy "$(proton_awg_normalize_i1_entropy "$i1_entropy")"
        set -- "$@" --from-file "$source_file"
        ui_menu_invoke_with_output "Сгенерировать конфиг (import --raw)" "$@"
    }

    preview_file() {
        source_file="$1"
        set -- "$IMPORT_CONF_SH" --version "$ver" --variant "$var" --country "$country" --raw --mtu "$mtu" --from-file "$source_file" --preview-only
        [ -n "$name" ] && set -- "$@" --name "$name"
        [ "$(proton_awg_normalize_noise_enabled "$awg_noise")" = "1" ] && set -- "$@" --with-noise
        set -- "$@" --i1-entropy "$(proton_awg_normalize_i1_entropy "$i1_entropy")"
        ui_menu_invoke_with_output "Предпросмотр (import --raw)" "$@"
    }

    preview_and_confirm_import() {
        source_file="$1"
        [ -f "$source_file" ] || {
            ui_msgbox "Proton генератор" "Файл не найден:

$source_file"
            return 0
        }
        preview_file "$source_file"
        if ui_confirm "Proton генератор" "Продолжить импорт и сохранить .conf/.meta?"; then
            import_run_file "$source_file"
        fi
    }

    case "$source_mode" in
        1)
            src_path="$(ui_inputbox "Proton генератор" "Введите путь к Proton .conf файлу" "" || true)"
            [ -n "${src_path:-}" ] || return 0
            preview_and_confirm_import "$src_path"
            ;;
        2)
            if ! ui_confirm "Proton генератор" "Откроется ввод Proton .conf на TTY (как при prepare-template):
по умолчанию nano, иначе vi, иначе cat+Ctrl+D. Переопределение: PROTON_MANUAL_CONF_EDITOR=nano|vi|cat."; then
                return 0
            fi
            tmp_import_file="${UI_TMP_ROOT:-/tmp}/proton-import-paste.$$"
            if ! ui_capture_tty_multiline_to_file \
                "Вставка Proton .conf" \
                "$tmp_import_file" \
                "После сохранения/ввода откроется предпросмотр импорта."; then
                rm -f "$tmp_import_file"
                return 0
            fi
            if [ ! -s "$tmp_import_file" ]; then
                rm -f "$tmp_import_file"
                ui_msgbox "Proton генератор" "Пустой ввод. Импорт отменён."
                return 0
            fi
            preview_and_confirm_import "$tmp_import_file"
            rm -f "$tmp_import_file"
            ;;
    esac
}

show_last_configs() {
    mkdir -p "$CONF_DIR"
    tmp="${UI_TMP_ROOT:-/tmp}/proton-conf-list.$$"
    : > "$tmp"

    ls -1t "$CONF_DIR"/*.conf 2>/dev/null | while IFS= read -r p; do
        [ -f "$p" ] || continue
        bn="$(basename "$p")"
        d="$(proton_conf_basename_menu_desc "$p" "$bn")"
        printf '%s — %s\n' "$bn" "$d"
    done > "$tmp"

    if [ ! -s "$tmp" ]; then
        ui_msgbox "Proton генератор" "В каталоге нет .conf файлов:
$CONF_DIR"
        rm -f "$tmp"
        return 0
    fi

    ui_show_textbox "Последние конфиги" "$tmp" 24 110
    rm -f "$tmp"
}

proton_menu_simple_hint() {
	printf '%s' "П.1 — гостевая сессия (как WARP) и значения по умолчанию. Остальные параметры — в экспертном режиме.

Каталог: $CONF_DIR"
}

proton_menu_expert_hint() {
	session="$(get_selected_session)"
	country="$(get_selected_country)"
	profile="$(get_selected_profile)"
	selection_mode="$(get_selected_selection_mode)"
	free_only="$(get_selected_free_only)"
	require_ipv6="$(get_selected_require_ipv6)"
	awg_noise="$(get_selected_awg_noise)"
	i1_entropy="$(get_selected_i1_entropy)"
	name="$(get_selected_name)"
	[ -n "$name" ] || name="<авто>"
	hint="Сессия:  $(session_label "$session")
Страна:  $(country_label "$country") [$country]
Фильтры: tier=$(free_only_label "$free_only") · ipv6=$(require_ipv6_label "$require_ipv6")
Профиль: $(profile_label "$profile") [$profile]
Выбор:   $(selection_mode_label "$selection_mode")
Имя:     $name
Шум:     $(awg_noise_label "$awg_noise")
I1:      $(i1_entropy_label "$i1_entropy")"
	printf '%s' "$hint"
}

main() {
    [ -x "$GENERATOR_SH" ] || chmod +x "$GENERATOR_SH" 2>/dev/null || true
    [ -x "$GENERATOR_SH" ] || die "Генератор не исполняемый: $GENERATOR_SH"
    [ -x "$IMPORT_CONF_SH" ] || chmod +x "$IMPORT_CONF_SH" 2>/dev/null || true
    [ -x "$IMPORT_CONF_SH" ] || die "Импортёр не исполняемый: $IMPORT_CONF_SH"
    # Host store (profile-generator): no mode toggle — always full menu.
    # Re-apply after load_base_config so root config.sh cannot force normal.
    if [ -n "${XFREE_VPN_STORE_ID:-}" ]; then
        export XFREE_MENU_MODE=expert
    fi
    menu_mode_normalize
    ensure_store_session_selection

    while :; do
        menu_title="Proton генератор"
        [ -n "${XFREE_VPN_STORE_ID:-}" ] && menu_title="Proton генератор (ci/store/$XFREE_VPN_STORE_ID)"

        if _menu_item_visible expert; then
            free_only="$(get_selected_free_only)"
            require_ipv6="$(get_selected_require_ipv6)"
            i1_entropy="$(get_selected_i1_entropy)"
            set -- \
                "1" "Показать текущие параметры" \
                "2" "Выбрать сессию (постоянная / гостевая)" \
                "3" "Фильтр tier: $(free_only_label "$free_only")" \
                "4" "Фильтр IPv6: $(require_ipv6_label "$require_ipv6")" \
                "5" "Удалить выбранную сессию" \
                "6" "Выбрать страну" \
                "7" "Выбрать профиль AWG" \
                "8" "Шум AmneziaWG (Jc/Jmin/Jmax)" \
                "9" "Энтропия I1: $(i1_entropy_label "$i1_entropy")" \
                "10" "Выбрать режим выбора сервера" \
                "11" "Задать имя файла" \
                "12" "Сгенерировать конфиг (raw, API)" \
                "13" "Сгенерировать конфиг (import --raw)" \
                "14" "Показать последние .conf" \
                "0" "Назад"
            menu_hint="$(proton_menu_expert_hint)"
            menu_h=34
            menu_list=18
            choice="$(ui_menu "$menu_title" "$menu_hint" "$menu_h" 100 "$menu_list" "$@" || true)"
            case "${choice:-}" in
                1) show_status ;;
                2) select_session ;;
                3) select_free_only_mode ;;
                4) select_require_ipv6_mode ;;
                5) delete_selected_session ;;
                6) select_country ;;
                7) select_profile ;;
                8) select_awg_noise ;;
                9) select_i1_entropy ;;
                10) select_selection_mode ;;
                11) edit_name ;;
                12) generate_config_raw_api ;;
                13) import_config_raw ;;
                14) show_last_configs ;;
                0|"") break ;;
            esac
        else
            set -- \
                "1" "Сгенерировать конфиг (raw, API)" \
                "2" "Сгенерировать конфиг (import --raw)" \
                "0" "Назад"
            menu_hint="$(proton_menu_simple_hint)"
            choice="$(ui_menu "$menu_title" "$menu_hint" 16 100 6 "$@" || true)"
            case "${choice:-}" in
                1) generate_config_raw_api ;;
                2) import_config_raw ;;
                0|"") break ;;
            esac
        fi
    done
}

main "$@"
