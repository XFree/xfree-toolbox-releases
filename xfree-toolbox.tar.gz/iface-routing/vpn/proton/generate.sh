#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
WG_MODE_SH="$VPN_DIR/lib/wg-mode.sh"
PROTON_API_SH="$VPN_DIR/lib/proton-api.sh"
ENSURE_WG_TOOL_SH="$VPN_DIR/lib/ensure-wg-tool.sh"
MODULE_CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
[ -f "$WG_MODE_SH" ] || {
    echo "[-] Не найден wg-mode.sh: $WG_MODE_SH" >&2
    exit 1
}
[ -f "$PROTON_API_SH" ] || {
    echo "[-] Не найден proton-api.sh: $PROTON_API_SH" >&2
    exit 1
}
[ -f "$ENSURE_WG_TOOL_SH" ] || {
    echo "[-] Не найден ensure-wg-tool.sh: $ENSURE_WG_TOOL_SH" >&2
    exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"
load_base_config "$SCRIPT_DIR"
. "$WG_MODE_SH"
. "$PROTON_API_SH"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"
load_module_config "$MODULE_CONFIG_FILE"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"
PROFILE_PROTON_GENERATED_DIR="${PROFILE_PROTON_GENERATED_DIR:-$(xfree_profile_proton_conf_dir "$PROFILE_DIR")}"
CONF_DIR="${CONF_DIR:-$PROFILE_PROTON_GENERATED_DIR}"
DEFAULT_MODE="${DEFAULT_MODE:-local}"
DEFAULT_VERSION="${DEFAULT_VERSION:-2.0}"
DEFAULT_VARIANT="${DEFAULT_VARIANT:-1}"
DEFAULT_COUNTRY="${DEFAULT_COUNTRY:-NL}"
DEFAULT_SELECTION_MODE="${DEFAULT_SELECTION_MODE:-best}"
DEFAULT_MTU="${DEFAULT_MTU:-1420}"
DEFAULT_SESSION="${DEFAULT_SESSION:-}"
PROTON_PLATFORM="${PROTON_PLATFORM:-Router}"
PROTON_DEVICE_NAME_PREFIX="${PROTON_DEVICE_NAME_PREFIX:-xfree-toolbox}"

RAW_DEFAULT_DNS="${RAW_DEFAULT_DNS:-}"
RAW_DEFAULT_ALLOWED_IPS="${RAW_DEFAULT_ALLOWED_IPS:-}"
LOCAL_DEFAULT_ALLOWED_IPS="${LOCAL_DEFAULT_ALLOWED_IPS:-0.0.0.0/0, ::/0}"
LOCAL_DEFAULT_PERSISTENT_KEEPALIVE="${LOCAL_DEFAULT_PERSISTENT_KEEPALIVE:-20}"

QUIET=0
MODE="$DEFAULT_MODE"
VERSION="$DEFAULT_VERSION"
VARIANT="$DEFAULT_VARIANT"
PROTON_COUNTRY_FILTER="$DEFAULT_COUNTRY"
PROTON_SELECTION_MODE="$DEFAULT_SELECTION_MODE"
PROTON_SELECTED_SESSION="$DEFAULT_SESSION"
ACQUIRE_GUEST=0
DNS=""
ALLOWED_IPS=""
PERSISTENT_KEEPALIVE=""
NAME=""
MTU="$DEFAULT_MTU"
AWG_NOISE_ENABLED="${DEFAULT_AWG_NOISE_ENABLED:-0}"
AWG_I1_ENTROPY="${DEFAULT_AWG_I1_ENTROPY:-${DEFAULT_AWG_I1_ENTROPY_ENABLED:-r32}}"

WG_GEN_PRIV=""
WG_GEN_PUB=""
PROTON_DEVICE_NAME=""

usage() {
    cat <<EOF2
Usage:
  $(basename "$0") [options]

Options:
  --local
  --raw
  --country <NL>
  --best
  --interactive
  --session <name-or-path>
  --acquire-guest    Новая credentialless-сессия (как WARP register), затем .conf
  --version <1.5|2.0>
  --variant <1|2|3>
  --dns <ip-list>
  --allowed-ips <cidr-list>
  --persistent-keepalive <seconds>
  --mtu <mtu>
  --name <basename>
  --free-only        Только бесплатные logical (Tier=0); то же, что PROTON_USE_FREE_ONLY=1
  --all-tiers        Все tier (free+paid); то же, что PROTON_USE_FREE_ONLY=0
  --ipv6-only        Только серверы с IPv6; то же, что PROTON_REQUIRE_IPV6=1
  --all-ip           Все серверы (IPv4 и IPv6); то же, что PROTON_REQUIRE_IPV6=0
  --with-noise       AmneziaWG junk packets (Jc/Jmin/Jmax из preset варианта); по умолчанию без шума
  --i1-entropy <mode>
                     Энтропия I1: r32 (default) | r64 | t | c | rc10 | rd6 | off
  --with-i1-entropy  То же, что --i1-entropy r32
  --no-i1-entropy    То же, что --i1-entropy off
  --quiet
  -h, --help

Переменная PROTON_USE_FREE_ONLY из config/env; флаги --free-only / --all-tiers переопределяют её.
PROTON_REQUIRE_IPV6 из config/env; флаги --ipv6-only / --all-ip переопределяют её (по умолчанию все адреса).
Если у выбранного сервера есть IPv6, в Address/AllowedIPs пишутся 2a07:b944::2:1/128 и ::/0; Endpoint остаётся IPv4.
По умолчанию AWG без junk/noise (Jc/Jmin/Jmax=0); DEFAULT_AWG_NOISE_ENABLED в config.sh.
По умолчанию I1 с энтропией <r 32>; DEFAULT_AWG_I1_ENTROPY в config.sh.
EOF2
}

utc_now_iso() {
    date -u +"%Y-%m-%dT%H:%M:%SZ"
}

utc_now_compact() {
    date -u +"%Y%m%d-%H%M%SZ"
}

build_device_name() {
    printf '%s-%s\n' "$PROTON_DEVICE_NAME_PREFIX" "$(utc_now_compact)"
}

sanitize_slug() {
    value="$1"
    value="$(common_lower_ascii "$value")"
    value="$(printf '%s' "$value" | tr -cs 'a-z0-9.' '-')"
    value="$(printf '%s' "$value" | sed 's/^-*//; s/-*$//; s/--*/-/g')"
    [ -n "$value" ] || value="na"
    printf '%s\n' "$value"
}

# Hint for UI lists (pipe-separated); '|' stripped from fields to keep one line parseable.
conf_list_hint_segment() {
    printf '%s' "$1" | tr '|' '/'
}


build_generated_name_base() {
    session_slug="$(sanitize_slug "${PROTON_SELECTED_SESSION_NAME:-session}")"
    server_slug="$(sanitize_slug "${PROTON_SELECTED_NAME:-srv}")"
    printf 'proton-%s-%s-awg%s-v%s-%s\n' \
        "$server_slug" \
        "$session_slug" \
        "$(sanitize_slug "$VERSION")" \
        "$(sanitize_slug "$VARIANT")" \
        "$(sanitize_slug "$MODE")"
}

pick_unique_name() {
    base="$1"
    stamp="$(utc_now_compact)"
    candidate="${base}-${stamp}"
    [ ! -f "$CONF_DIR/${candidate}.conf" ] && {
        printf '%s\n' "$candidate"
        return 0
    }

    seq=2
    while :; do
        candidate="${base}-${stamp}-${seq}"
        [ ! -f "$CONF_DIR/${candidate}.conf" ] && {
            printf '%s\n' "$candidate"
            return 0
        }
        seq=$((seq + 1))
    done
}

endpoint_host_part() {
    printf '%s\n' "$1" | sed 's/:.*$//'
}

endpoint_port_part() {
    printf '%s\n' "$1" | sed 's/^.*://'
}

x25519_private_from_ed25519_seed_b64() {
    seed_b64="$1"
    [ -n "$seed_b64" ] || die "Пустой ED25519 seed"

    tmp_dir="${TMPDIR:-/tmp}"
    tmp_seed="$tmp_dir/proton-ed25519-seed.$$"
    tmp_bin="$tmp_dir/proton-x25519-bin.$$"
    trap 'rm -f "$tmp_seed" "$tmp_bin"' EXIT HUP INT TERM

    seed_b64="$(proton_b64_pad "$seed_b64")"
    if ! printf '%s' "$seed_b64" | base64 -d > "$tmp_seed" 2>/dev/null; then
        rm -f "$tmp_seed" "$tmp_bin"
        trap - EXIT HUP INT TERM
        die "Не удалось декодировать ED25519 seed из base64"
    fi

    seed_size="$(wc -c < "$tmp_seed" | awk '{print $1}')"
    [ "$seed_size" = "32" ] || {
        rm -f "$tmp_seed" "$tmp_bin"
        trap - EXIT HUP INT TERM
        die "Ожидался ED25519 seed длиной 32 байта, получено: $seed_size"
    }

    hash_hex="$(sha512sum "$tmp_seed" | awk '{print $1}')"
    [ -n "$hash_hex" ] || {
        rm -f "$tmp_seed" "$tmp_bin"
        trap - EXIT HUP INT TERM
        die "Не удалось вычислить SHA-512 для ED25519 seed"
    }

    key_hex="$(printf '%s' "$hash_hex" | cut -c1-64)"

    first_dec=$(( 0x$(printf '%s' "$key_hex" | cut -c1-2) ))
    last_dec=$(( 0x$(printf '%s' "$key_hex" | cut -c63-64) ))

    first_dec=$(( first_dec & 248 ))
    last_dec=$(( (last_dec & 127) | 64 ))

    key_hex="$(printf '%02x' "$first_dec")$(printf '%s' "$key_hex" | cut -c3-62)$(printf '%02x' "$last_dec")"

    command -v proton_hex_to_b64 >/dev/null 2>&1 \
        || die "proton_hex_to_b64 недоступен (загрузите proton-crypto-fallback.sh через proton-api.sh)"
    # dash /bin/sh: printf %b не раскрывает \\xHH — только octal (см. xfree_hex_byte_append).
    result="$(proton_hex_to_b64 "$key_hex" "$tmp_bin")"
    [ -n "$result" ] || {
        rm -f "$tmp_seed" "$tmp_bin"
        trap - EXIT HUP INT TERM
        die "Не удалось закодировать X25519 private key в base64"
    }

    rm -f "$tmp_seed" "$tmp_bin"
    trap - EXIT HUP INT TERM
    printf '%s\n' "$result"
}

build_awg_from_proton() {
    case "$(common_lower_ascii "${WG_GEN_KEY_KIND:-ed25519}")" in
        x25519)
            WG_PRIVATE_KEY="$(proton_b64_pad "$WG_GEN_PRIV")"
            ;;
        *)
            WG_PRIVATE_KEY="$(x25519_private_from_ed25519_seed_b64 "$WG_GEN_PRIV")"
            ;;
    esac
    WG_PEER_PUBLIC_KEY="$PROTON_SELECTED_PEER_PUBLIC_KEY"
    proton_awg_apply_tunnel_addrs
    WG_PERSISTENT_KEEPALIVE="20"
    PROFILE_COMMENT="# ${PROTON_SELECTED_PEER_NAME}"
}

write_proton_awg_conf() {
    outfile="$1"
    : > "$outfile"

    [ -n "${PROTON_DEVICE_NAME:-}" ] && printf '# PROTON_DEVICE_NAME=%s\n' "$PROTON_DEVICE_NAME" >> "$outfile"
    [ -n "${PROFILE_COMMENT:-}" ] && printf '%s\n' "$PROFILE_COMMENT" >> "$outfile"
    hint_n="$(conf_list_hint_segment "${PROTON_SELECTED_NAME:-}")"
    [ -n "$hint_n" ] || hint_n="$(conf_list_hint_segment "${PROTON_SELECTED_PEER_NAME:-}")"
    [ -n "$hint_n" ] || hint_n="na"
    hint_c="$(conf_list_hint_segment "${PROTON_SELECTED_COUNTRY:-}")"
    [ -n "$hint_c" ] || hint_c="$(conf_list_hint_segment "${PROTON_COUNTRY_FILTER:-}")"
    [ -n "$hint_c" ] || hint_c="?"
    hint_city="$(conf_list_hint_segment "${PROTON_SELECTED_CITY:-}")"
    [ -n "$hint_city" ] || hint_city="?"
    printf '# XFREE_CONF_LIST_HINT=%s|%s|%s\n' "$hint_n" "$hint_c" "$hint_city" >> "$outfile"
    write_common_local_comment_block "$outfile"

    {
        printf '[Interface]\n'
        printf 'PrivateKey=%s\n' "$WG_PRIVATE_KEY"
        printf 'Address=%s\n' "$WG_ADDRESS"
        [ -n "$DNS" ] && printf 'DNS=%s\n' "$DNS"
        [ -n "$MTU" ] && printf 'MTU=%s\n' "$MTU"
        printf 'S1=%s\n' "$AWG_S1"
        printf 'S2=%s\n' "$AWG_S2"
        [ "${AWG_HAS_S3:-0}" = "1" ] && printf 'S3=%s\n' "$AWG_S3"
        [ "${AWG_HAS_S4:-0}" = "1" ] && printf 'S4=%s\n' "$AWG_S4"
        printf 'Jc=%s\n' "$AWG_JC"
        printf 'Jmin=%s\n' "$AWG_JMIN"
        printf 'Jmax=%s\n' "$AWG_JMAX"
        printf 'H1=%s\n' "$AWG_H1"
        printf 'H2=%s\n' "$AWG_H2"
        printf 'H3=%s\n' "$AWG_H3"
        printf 'H4=%s\n' "$AWG_H4"
        printf 'I1=%s\n' "$AWG_I1"
        [ -n "$AWG_I2" ] && printf 'I2=%s\n' "$AWG_I2"
        printf '\n[Peer]\n'
        printf 'PublicKey=%s\n' "$WG_PEER_PUBLIC_KEY"
        printf 'AllowedIPs=%s\n' "$ALLOWED_IPS"
        printf 'Endpoint=%s\n' "$WG_ENDPOINT"
        [ -n "$PERSISTENT_KEEPALIVE" ] && printf 'PersistentKeepalive=%s\n' "$PERSISTENT_KEEPALIVE"
    } >> "$outfile"
}

write_meta() {
    meta_file="$1"
    {
        printf "NAME_SCHEMA_VERSION='7'\n"
        printf "GENERATOR_KIND='proton'\n"
        printf "PROFILE_BASENAME='%s'\n" "$NAME"
        printf "PROFILE_LABEL='%s'\n" "$PROFILE_LABEL"
        printf "PROFILE_MODE='%s'\n" "$MODE"
        printf "COUNTRY_FILTER='%s'\n" "$PROTON_COUNTRY_FILTER"
        printf "SELECTION_MODE='%s'\n" "$PROTON_SELECTION_MODE"
        printf "SESSION_NAME='%s'\n" "$PROTON_SELECTED_SESSION_NAME"
        printf "SESSION_DIR='%s'\n" "$PROTON_SESSION_DIR"
        printf "SESSION_AUTH_MODE='%s'\n" "${PROTON_AUTH_MODE:-}"
        printf "SERVER_ID='%s'\n" "$PROTON_SELECTED_ID"
        printf "SERVER_NAME='%s'\n" "$PROTON_SELECTED_NAME"
        printf "SERVER_COUNTRY='%s'\n" "$PROTON_SELECTED_COUNTRY"
        printf "SERVER_CITY='%s'\n" "$PROTON_SELECTED_CITY"
        printf "SERVER_LOAD='%s'\n" "$PROTON_SELECTED_LOAD"
        printf "PEER_NAME='%s'\n" "$PROTON_SELECTED_PEER_NAME"
        printf "PEER_IP='%s'\n" "$PROTON_SELECTED_PEER_IP"
        printf "PEER_IPV6='%s'\n" "${PROTON_SELECTED_PEER_IPV6:-}"
        printf "HAS_IPV6='%s'\n" "${PROTON_SELECTED_HAS_IPV6:-0}"
        printf "ADDRESS='%s'\n" "${WG_ADDRESS:-}"
        printf "PEER_PUBLIC_KEY='%s'\n" "$PROTON_SELECTED_PEER_PUBLIC_KEY"
        printf "PROTON_PLATFORM='%s'\n" "$PROTON_PLATFORM"
        printf "PROTON_DEVICE_NAME='%s'\n" "$PROTON_DEVICE_NAME"
        printf "AWG_VERSION='%s'\n" "$VERSION"
        printf "VARIANT_ID='%s'\n" "$VARIANT"
        printf "AWG_NOISE_ENABLED='%s'\n" "$(proton_awg_normalize_noise_enabled "$AWG_NOISE_ENABLED")"
        printf "AWG_I1_ENTROPY='%s'\n" "$(proton_awg_normalize_i1_entropy "$AWG_I1_ENTROPY")"
        printf "AWG_I1_ENTROPY_ENABLED='%s'\n" "$(proton_awg_normalize_i1_entropy_enabled "$AWG_I1_ENTROPY")"
        printf "ENDPOINT='%s'\n" "$WG_ENDPOINT"
        printf "ENDPOINT_HOST='%s'\n" "$(endpoint_host_part "$WG_ENDPOINT")"
        printf "ENDPOINT_PORT='%s'\n" "$(endpoint_port_part "$WG_ENDPOINT")"
        printf "DNS_VALUE='%s'\n" "$DNS"
        printf "ALLOWED_IPS='%s'\n" "$ALLOWED_IPS"
        printf "PERSISTENT_KEEPALIVE='%s'\n" "$PERSISTENT_KEEPALIVE"
        printf "ORIGINAL_DNS_VALUE='%s'\n" "$ORIGINAL_DNS"
        printf "ORIGINAL_ALLOWED_IPS='%s'\n" "$ORIGINAL_ALLOWED_IPS"
        printf "ORIGINAL_PERSISTENT_KEEPALIVE='%s'\n" "$ORIGINAL_PERSISTENT_KEEPALIVE"
        printf "PROFILE_COMMENT='%s'\n" "$(printf '%s' "${PROFILE_COMMENT:-}" | sed "s/'/'\\''/g")"
        printf "GENERATED_AT_UTC='%s'\n" "$(utc_now_iso)"
        printf "CERT_MODE='%s'\n" "${PROTON_CERT_MODE:-}"
        printf "CERT_EXPIRATION_UNIX='%s'\n" "${PROTON_CERT_EXPIRATION_UNIX:-}"
        printf "CERT_EXPIRATION_UTC='%s'\n" "${PROTON_CERT_EXPIRATION_UTC:-}"
    } > "$meta_file"
}

while [ $# -gt 0 ]; do
    case "$1" in
        --local) MODE='local' ;;
        --raw) MODE='raw' ;;
        --country) shift; PROTON_COUNTRY_FILTER="${1:-}" ;;
        --best) PROTON_SELECTION_MODE='best' ;;
        --interactive) PROTON_SELECTION_MODE='interactive' ;;
        --session) shift; PROTON_SELECTED_SESSION="${1:-}" ;;
        --acquire-guest) ACQUIRE_GUEST=1 ;;
        --version) shift; VERSION="${1:-}" ;;
        --variant) shift; VARIANT="${1:-}" ;;
        --dns) shift; DNS="${1:-}" ;;
        --allowed-ips) shift; ALLOWED_IPS="${1:-}" ;;
        --persistent-keepalive) shift; PERSISTENT_KEEPALIVE="${1:-}" ;;
        --mtu) shift; MTU="${1:-}" ;;
        --name) shift; NAME="${1:-}" ;;
        --free-only) PROTON_USE_FREE_ONLY=1 ;;
        --all-tiers) PROTON_USE_FREE_ONLY=0 ;;
        --ipv6-only) PROTON_REQUIRE_IPV6=1 ;;
        --all-ip) PROTON_REQUIRE_IPV6=0 ;;
        --with-noise) AWG_NOISE_ENABLED=1 ;;
        --i1-entropy) shift; AWG_I1_ENTROPY="${1:-}" ;;
        --with-i1-entropy) AWG_I1_ENTROPY=r32 ;;
        --no-i1-entropy) AWG_I1_ENTROPY=off ;;
        --quiet) QUIET=1 ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
    shift || true
done

MODE="$(normalize_mode "$MODE")"
VERSION="$(proton_awg_normalize_version "$VERSION")"
VARIANT="$(proton_awg_normalize_variant "$VARIANT")"
PROTON_COUNTRY_FILTER="$(common_upper_ascii "$PROTON_COUNTRY_FILTER")"
PROTON_DEVICE_NAME="$(build_device_name)"
export PROTON_PLATFORM
export PROTON_DEVICE_NAME

info "Проверка наличия wg/awg"
sh "$ENSURE_WG_TOOL_SH" --install-if-missing

require_cmd curl
require_cmd date
vpn_json_require_parser
require_cmd sed
require_cmd awk
require_cmd base64
require_cmd sha512sum
mkdir -p "$CONF_DIR"

if [ "$ACQUIRE_GUEST" = "1" ]; then
    [ -z "${PROTON_SELECTED_SESSION:-}" ] || die "--acquire-guest нельзя совмещать с --session"
    dest="${PROTON_SESSIONS_DIR:-}"
    if [ -z "$dest" ]; then
        dest="$(xfree_profile_proton_sessions_dir "$PROFILE_DIR")"
    fi
    [ -n "$dest" ] || die "Не задан каталог Proton sessions для --acquire-guest"
    mkdir -p "$dest" || die "Не удалось создать $dest"
    PROTON_SESSIONS_DIR="$dest"
    export PROTON_SESSIONS_DIR
    info "Proton: новая guest-сессия (credentialless), как WARP register"
    if [ -n "${PROTON_GUEST_SESSION_NAME:-}" ]; then
        proton_guest_acquire_session "$dest" "$PROTON_GUEST_SESSION_NAME"
    else
        proton_guest_acquire_session "$dest"
    fi
    [ -n "${PROTON_SELECTED_SESSION_NAME:-}" ] || die "guest acquire не вернул имя сессии"
    PROTON_SELECTED_SESSION="$PROTON_SELECTED_SESSION_NAME"
fi

info "Проверка авторизации Proton"
proton_require_auth

info "Получение списка серверов Proton"
proton_fetch_logicals
export PROTON_COUNTRY_FILTER
proton_build_server_table
proton_select_server
proton_show_selected_server

info "Сформировано имя устройства Proton: $PROTON_DEVICE_NAME"
debug "Выбрана платформа Proton: $PROTON_PLATFORM"

info "Получение клиентских ключей Proton"
proton_get_keypair

info "Создание Proton certificate"
proton_create_certificate "$WG_GEN_PUB"
PROTON_CERT_MODE="$(proton_cert_json_field Mode)"
PROTON_CERT_EXPIRATION_UNIX="$(proton_cert_json_field ExpirationTime)"
PROTON_CERT_EXPIRATION_UTC="$(proton_unix_to_utc "$PROTON_CERT_EXPIRATION_UNIX")"
proton_show_certificate_summary
[ -n "$PROTON_CERT_EXPIRATION_UTC" ] && info "Туннель по этому .conf живёт до $PROTON_CERT_EXPIRATION_UTC (ExpirationTime сертификата), не до конца guest-сессии."

build_awg_from_proton

ORIGINAL_DNS="$WG_DNS"
ORIGINAL_ALLOWED_IPS="$WG_ALLOWED_IPS"
ORIGINAL_PERSISTENT_KEEPALIVE="$WG_PERSISTENT_KEEPALIVE"

apply_mode_overrides
AWG_NOISE_ENABLED="$(proton_awg_normalize_noise_enabled "$AWG_NOISE_ENABLED")"
AWG_I1_ENTROPY="$(proton_awg_normalize_i1_entropy "$AWG_I1_ENTROPY")"
proton_awg_version_variant_params "$VERSION" "$VARIANT" "$AWG_NOISE_ENABLED" "$AWG_I1_ENTROPY"

if [ -z "$NAME" ]; then
    NAME_BASE="$(build_generated_name_base)"
    NAME="$(pick_unique_name "$NAME_BASE")"
else
    NAME="$(sanitize_slug "$NAME")"
    [ -n "$NAME" ] || die "Имя после очистки пустое"
fi

PROFILE_LABEL="mode=$MODE country=$PROTON_COUNTRY_FILTER session=$PROTON_SELECTED_SESSION_NAME server=$PROTON_SELECTED_NAME awg=$VERSION variant=$VARIANT"
OUTFILE="$CONF_DIR/${NAME}.conf"
METAFILE="$CONF_DIR/${NAME}.conf.meta"

info "Записываю конфиг: $OUTFILE"
write_proton_awg_conf "$OUTFILE"

info "Записываю метаданные: $METAFILE"
write_meta "$METAFILE"

success "Конфиг создан: $OUTFILE"
printf 'SOURCE=%s\n' "$OUTFILE"
printf 'META=%s\n' "$METAFILE"
printf 'NAME=%s\n' "$NAME"
printf 'MODE=%s\n' "$MODE"
printf 'COUNTRY=%s\n' "$PROTON_COUNTRY_FILTER"
printf 'SESSION=%s\n' "$PROTON_SELECTED_SESSION_NAME"
printf 'SERVER=%s\n' "$PROTON_SELECTED_NAME"
printf 'AWG_VERSION=%s\n' "$VERSION"
printf 'VARIANT=%s\n' "$VARIANT"
printf 'ENDPOINT=%s\n' "$WG_ENDPOINT"
