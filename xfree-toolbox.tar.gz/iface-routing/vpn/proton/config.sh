#!/bin/sh

: "${XFREE_STATE_ROOT:=/etc/xfree-toolbox}"
: "${XFREE_VPN_ROOT:=$XFREE_STATE_ROOT/vpn}"

PROTON_STATE_DIR="${PROTON_STATE_DIR:-$XFREE_VPN_ROOT/state/proton}"
PROTON_SESSIONS_DIR="${PROTON_SESSIONS_DIR:-$PROTON_STATE_DIR/sessions}"
PROTON_GENERATED_DIR="${PROTON_GENERATED_DIR:-$XFREE_VPN_ROOT/generated/proton}"

PROTON_X_PM_APPVERSION="web-vpn-settings@5.0.327.1"
PROTON_X_PM_LOCALE="en_US"
PROTON_PLATFORM="Router"
PROTON_DEVICE_NAME_PREFIX="xfree-toolbox"
PROTON_CURL_CONNECT_TIMEOUT="20"
PROTON_CURL_MAX_TIME="45"
PROTON_CURL_CONNECT_RETRIES="3"
PROTON_CURL_IP_VERSION="4"
PROTON_REFRESH_BEFORE_AUTH="1"
PROTON_REFRESH_FAIL_HARD="0"
# 1 = после refresh копировать cookies/uid в другие корни с тем же именем сессии (state <-> профиль).
PROTON_SESSION_SYNC="1"
# Коллизия имён: freshness (mtime cookies/uid) или priority (state → профиль → PROTON_SESSIONS_DIR).
PROTON_SESSION_PICK="freshness"
PROTON_PROBE_TOP_N="5"
PROTON_PROBE_TIMEOUT_SEC="1"
# 1 = использовать только free-серверы (Tier=0), 0 = разрешить любые tier.
PROTON_USE_FREE_ONLY="1"
# 1 = только logicals с IPv6; 0 = все (IPv4-only тоже).
# Endpoint в .conf остаётся IPv4 (handshake). Если у выбранного сервера есть IPv6,
# в Address/AllowedIPs дописываются 2a07:b944::2:1/128 и ::/0.
PROTON_REQUIRE_IPV6="0"

# 1 = в Peer.Endpoint подставлять FQDN узла (имя peer из logicals), если похоже на hostname; 0 = только IPv4.
# При SELF_ROUTE_VIA: hotplug self-route при hostname в `wg show endpoints` делает DNS (getent/nslookup) к первому A;
# если резолв недоступен — маршрут не поставится; при сомнении оставьте 0.
PROTON_ENDPOINT_USE_HOSTNAME="0"

DEFAULT_COUNTRY="NL"
DEFAULT_SELECTION_MODE="best"

DEFAULT_VERSION="2.0"
DEFAULT_VARIANT="1"
DEFAULT_MODE="local"
DEFAULT_MTU="1420"
# 1 = junk packets (Jc/Jmin/Jmax из preset варианта AWG); 0 = без шума (0/0/0).
DEFAULT_AWG_NOISE_ENABLED="0"
# Энтропия I1: r32 (default, `<r 32>`), r64, t, c, rc10, rd6, off.
# 0/1 по-прежнему принимаются (0=off, 1=r32).
DEFAULT_AWG_I1_ENTROPY="r32"
DEFAULT_AWG_I1_ENTROPY_ENABLED="1"

LOCAL_DEFAULT_DNS="127.0.0.1"
LOCAL_DEFAULT_ALLOWED_IPS="0.0.0.0/0, ::/0"
LOCAL_DEFAULT_PERSISTENT_KEEPALIVE="20"
