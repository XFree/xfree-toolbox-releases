#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
WG_MODE_SH="$VPN_DIR/lib/wg-mode.sh"
PROTON_API_SH="$VPN_DIR/lib/proton-api.sh"
ENSURE_WG_TOOL_SH="$VPN_DIR/lib/ensure-wg-tool.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"
[ -f "$WG_MODE_SH" ] || { echo "[-] Не найден wg-mode.sh: $WG_MODE_SH" >&2; exit 1; }
. "$WG_MODE_SH"
[ -f "$PROTON_API_SH" ] || { echo "[-] Не найден proton-api.sh: $PROTON_API_SH" >&2; exit 1; }
. "$PROTON_API_SH"
[ -f "$ENSURE_WG_TOOL_SH" ] || { echo "[-] Не найден ensure-wg-tool.sh: $ENSURE_WG_TOOL_SH" >&2; exit 1; }

if command -v load_base_config >/dev/null 2>&1; then
    load_base_config "$SCRIPT_DIR"
fi
if command -v load_module_config >/dev/null 2>&1; then
    load_module_config "$CONFIG_FILE"
elif [ -f "$CONFIG_FILE" ]; then
    . "$CONFIG_FILE"
fi

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"
_DEFAULT_PROTON_CONF="$(xfree_profile_proton_conf_dir "$PROFILE_DIR")"
PROFILE_PROTON_CONF_DIR="${PROFILE_PROTON_CONF_DIR:-${PROFILE_PROTON_GENERATED_DIR:-$_DEFAULT_PROTON_CONF}}"
CONF_DIR="${CONF_DIR:-$PROFILE_PROTON_CONF_DIR}"

DEFAULT_MODE="${DEFAULT_MODE:-local}"
DEFAULT_VERSION="${DEFAULT_VERSION:-2.0}"
DEFAULT_VARIANT="${DEFAULT_VARIANT:-1}"
DEFAULT_MTU="${DEFAULT_MTU:-1420}"
DEFAULT_COUNTRY="${DEFAULT_COUNTRY:-ZZ}"

RAW_DEFAULT_DNS="${RAW_DEFAULT_DNS:-}"
RAW_DEFAULT_ALLOWED_IPS="${RAW_DEFAULT_ALLOWED_IPS:-}"
LOCAL_DEFAULT_ALLOWED_IPS="${LOCAL_DEFAULT_ALLOWED_IPS:-0.0.0.0/0, ::/0}"
LOCAL_DEFAULT_PERSISTENT_KEEPALIVE="${LOCAL_DEFAULT_PERSISTENT_KEEPALIVE:-20}"

MODE="$DEFAULT_MODE"
VERSION="$DEFAULT_VERSION"
VARIANT="$DEFAULT_VARIANT"
MTU="$DEFAULT_MTU"
COUNTRY="$DEFAULT_COUNTRY"
NAME=""
INPUT_FILE=""
FROM_STDIN=0
PREVIEW_ONLY=0
AWG_NOISE_ENABLED="${DEFAULT_AWG_NOISE_ENABLED:-0}"
AWG_I1_ENTROPY="${DEFAULT_AWG_I1_ENTROPY:-${DEFAULT_AWG_I1_ENTROPY_ENABLED:-r32}}"

SRC_PRIVATE_KEY=""
SRC_ADDRESS=""
SRC_DNS=""
SRC_PEER_PUBLIC_KEY=""
SRC_ALLOWED_IPS=""
SRC_ENDPOINT=""
SRC_KEEPALIVE=""

DNS=""
ALLOWED_IPS=""
PERSISTENT_KEEPALIVE=""

usage() {
    cat <<EOF2
Usage:
  $(basename "$0") [options]

Options:
  --from-file <path>
  --from-stdin
  --preview-only
  --local
  --raw
  --country <CC>
  --version <1.5|2.0>
  --variant <1|2|3>
  --mtu <mtu>
  --name <basename>
  --with-noise       AmneziaWG junk packets (Jc/Jmin/Jmax из preset); по умолчанию без шума
  --i1-entropy <mode>
                     Энтропия I1: r32 (default) | r64 | t | c | rc10 | rd6 | off
  --with-i1-entropy  То же, что --i1-entropy r32
  --no-i1-entropy    То же, что --i1-entropy off
  -h, --help
EOF2
}

utc_now_iso() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
utc_now_compact() { date -u +"%Y%m%d-%H%M%SZ"; }
sanitize_slug() {
    value="$1"
    value="$(common_lower_ascii "$value")"
    value="$(printf '%s' "$value" | tr -cs 'a-z0-9.' '-')"
    value="$(printf '%s' "$value" | sed 's/^-*//; s/-*$//; s/--*/-/g')"
    [ -n "$value" ] || value="na"
    printf '%s\n' "$value"
}
endpoint_host_part() { printf '%s\n' "$1" | sed 's/:.*$//'; }
endpoint_port_part() { printf '%s\n' "$1" | sed 's/^.*://'; }

conf_value() {
    section="$1"; key="$2"; file="$3"
    awk -F= -v want_sec="$section" -v want_key="$key" '
        BEGIN {
            want_sec_l = tolower(want_sec)
            want_key_l = tolower(want_key)
        }
        function trim(s) { sub(/^[[:space:]]+/, "", s); sub(/[[:space:]]+$/, "", s); return s }
        function strip_bom(s) { sub(/^\xef\xbb\xbf/, "", s); return s }
        /^[[:space:]]*\[/ {
            sec=$0
            sec=strip_bom(sec)
            gsub(/\r/, "", sec)
            gsub(/[\[\]]/, "", sec)
            sec=trim(sec)
            sec_l=tolower(sec)
            next
        }
        {
            line=$0
            line=strip_bom(line)
            gsub(/\r/, "", line)
            sub(/^[[:space:]]+/, "", line)
            # Drop full-line comments inside section.
            if (line ~ /^[#;]/) next
            # Proton templates may include spaces around "=".
            if (index(line, "=") == 0) next
            split(line,p,"=")
            k=trim(p[1])
            # Normalize common odd spaces around key (including NBSP).
            gsub(/\xc2\xa0/, " ", k)
            k=trim(k)
            k_l=tolower(k)
            if (k_l!=want_key_l) next
            # Prefer key from target section, but allow fallback when section marker is malformed.
            if (sec_l != want_sec_l && want_sec_l != "") {
                if (fallback == "") {
                    v_tmp=substr(line,index(line,"=")+1)
                    sub(/[[:space:]]*[;#].*$/, "", v_tmp)
                    fallback=trim(v_tmp)
                }
                next
            }
            v=substr(line,index(line,"=")+1)
            # Preserve inline value, but strip trailing comments and spaces.
            sub(/[[:space:]]*[;#].*$/, "", v)
            print trim(v)
            exit
        }
        END {
            if (fallback != "") print fallback
        }
    ' "$file"
}

build_generated_name_base() {
    endpoint_slug="$(sanitize_slug "$(endpoint_host_part "$SRC_ENDPOINT")")"
    av="$(proton_confname_compact_awg_version "$VERSION")"
    printf 'proton-imp-%s-a%s-v%s-%s\n' "$endpoint_slug" "$av" "$(sanitize_slug "$VARIANT")" "$(sanitize_slug "$MODE")"
}
pick_unique_name() {
    base="$1"; stamp="$(proton_conf_gen_stamp)"; candidate="${base}-${stamp}"
    [ ! -f "$CONF_DIR/${candidate}.conf" ] && { printf '%s\n' "$candidate"; return 0; }
    seq=2
    while :; do
        candidate="${base}-${stamp}-${seq}"
        [ ! -f "$CONF_DIR/${candidate}.conf" ] && { printf '%s\n' "$candidate"; return 0; }
        seq=$((seq + 1))
    done
}

write_conf() {
    outfile="$1"; : > "$outfile"
    printf '# imported-from=proton-conf\n' >> "$outfile"
    printf '# XFREE_CONF_LIST_HINT=proton-import|%s|%s\n' "$COUNTRY" "$(endpoint_host_part "$SRC_ENDPOINT")" >> "$outfile"
    write_common_local_comment_block "$outfile"
    {
        printf '[Interface]\n'
        printf 'PrivateKey=%s\n' "$SRC_PRIVATE_KEY"
        printf 'Address=%s\n' "$SRC_ADDRESS"
        if [ -n "$DNS" ]; then
            printf 'DNS=%s\n' "$DNS"
        fi
        if [ -n "$MTU" ]; then
            printf 'MTU=%s\n' "$MTU"
        fi
        printf 'S1=%s\n' "$AWG_S1"
        printf 'S2=%s\n' "$AWG_S2"
        if [ "${AWG_HAS_S3:-0}" = "1" ]; then
            printf 'S3=%s\n' "$AWG_S3"
        fi
        if [ "${AWG_HAS_S4:-0}" = "1" ]; then
            printf 'S4=%s\n' "$AWG_S4"
        fi
        printf 'Jc=%s\n' "$AWG_JC"
        printf 'Jmin=%s\n' "$AWG_JMIN"
        printf 'Jmax=%s\n' "$AWG_JMAX"
        printf 'H1=%s\n' "$AWG_H1"
        printf 'H2=%s\n' "$AWG_H2"
        printf 'H3=%s\n' "$AWG_H3"
        printf 'H4=%s\n' "$AWG_H4"
        printf 'I1=%s\n' "$AWG_I1"
        if [ -n "$AWG_I2" ]; then
            printf 'I2=%s\n' "$AWG_I2"
        fi
        printf '\n[Peer]\n'
        printf 'PublicKey=%s\n' "$SRC_PEER_PUBLIC_KEY"
        printf 'AllowedIPs=%s\n' "$ALLOWED_IPS"
        printf 'Endpoint=%s\n' "$SRC_ENDPOINT"
        if [ -n "$PERSISTENT_KEEPALIVE" ]; then
            printf 'PersistentKeepalive=%s\n' "$PERSISTENT_KEEPALIVE"
        fi
    } >> "$outfile"
}

write_meta() {
    meta_file="$1"
    {
        printf "NAME_SCHEMA_VERSION='7'\n"
        printf "GENERATOR_KIND='proton'\n"
        printf "PROFILE_BASENAME='%s'\n" "$NAME"
        printf "PROFILE_LABEL='%s'\n" "$PROFILE_LABEL"
        printf "PROFILE_MODE='%s'\n" "$MODE"
        printf "COUNTRY_FILTER='%s'\n" "$COUNTRY"
        printf "SELECTION_MODE='%s'\n" "import"
        printf "SESSION_NAME='%s'\n" "imported"
        printf "SESSION_DIR='%s'\n" "imported"
        printf "SERVER_ID='%s'\n" "imported"
        printf "SERVER_NAME='%s'\n" "Imported Proton config"
        printf "SERVER_COUNTRY='%s'\n" "$COUNTRY"
        printf "SERVER_CITY='%s'\n" "$(endpoint_host_part "$SRC_ENDPOINT")"
        printf "SERVER_LOAD='%s'\n" "n/a"
        printf "PEER_NAME='%s'\n" "imported"
        printf "PEER_IP='%s'\n" "$(endpoint_host_part "$SRC_ENDPOINT")"
        printf "PEER_PUBLIC_KEY='%s'\n" "$SRC_PEER_PUBLIC_KEY"
        printf "PROTON_PLATFORM='%s'\n" "import"
        printf "PROTON_DEVICE_NAME='%s'\n" "import"
        printf "AWG_VERSION='%s'\n" "$VERSION"
        printf "VARIANT_ID='%s'\n" "$VARIANT"
        printf "AWG_NOISE_ENABLED='%s'\n" "$(proton_awg_normalize_noise_enabled "$AWG_NOISE_ENABLED")"
        printf "AWG_I1_ENTROPY='%s'\n" "$(proton_awg_normalize_i1_entropy "$AWG_I1_ENTROPY")"
        printf "AWG_I1_ENTROPY_ENABLED='%s'\n" "$(proton_awg_normalize_i1_entropy_enabled "$AWG_I1_ENTROPY")"
        printf "ENDPOINT='%s'\n" "$SRC_ENDPOINT"
        printf "ENDPOINT_HOST='%s'\n" "$(endpoint_host_part "$SRC_ENDPOINT")"
        printf "ENDPOINT_PORT='%s'\n" "$(endpoint_port_part "$SRC_ENDPOINT")"
        printf "DNS_VALUE='%s'\n" "$DNS"
        printf "ALLOWED_IPS='%s'\n" "$ALLOWED_IPS"
        printf "PERSISTENT_KEEPALIVE='%s'\n" "$PERSISTENT_KEEPALIVE"
        printf "ORIGINAL_DNS_VALUE='%s'\n" "$ORIGINAL_DNS"
        printf "ORIGINAL_ALLOWED_IPS='%s'\n" "$ORIGINAL_ALLOWED_IPS"
        printf "ORIGINAL_PERSISTENT_KEEPALIVE='%s'\n" "$ORIGINAL_PERSISTENT_KEEPALIVE"
        printf "PROFILE_COMMENT='%s'\n" "imported proton config"
        printf "SOURCE_KIND='%s'\n" "proton_conf_import"
        printf "GENERATED_AT_UTC='%s'\n" "$(utc_now_iso)"
    } > "$meta_file"
}

while [ $# -gt 0 ]; do
    case "$1" in
        --from-file) shift; INPUT_FILE="${1:-}" ;;
        --from-stdin) FROM_STDIN=1 ;;
        --preview-only) PREVIEW_ONLY=1 ;;
        --local) MODE='local' ;;
        --raw) MODE='raw' ;;
        --country) shift; COUNTRY="${1:-}" ;;
        --version) shift; VERSION="${1:-}" ;;
        --variant) shift; VARIANT="${1:-}" ;;
        --mtu) shift; MTU="${1:-}" ;;
        --name) shift; NAME="${1:-}" ;;
        --with-noise) AWG_NOISE_ENABLED=1 ;;
        --i1-entropy) shift; AWG_I1_ENTROPY="${1:-}" ;;
        --with-i1-entropy) AWG_I1_ENTROPY=r32 ;;
        --no-i1-entropy) AWG_I1_ENTROPY=off ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
    shift || true
done

MODE="$(normalize_mode "$MODE")"
VERSION="$(proton_awg_normalize_version "$VERSION")"
VARIANT="$(proton_awg_normalize_variant "$VARIANT")"
COUNTRY="$(common_upper_ascii "$COUNTRY")"

info "Проверка наличия wg/awg"
sh "$ENSURE_WG_TOOL_SH" --install-if-missing

tmp_input=""
if [ "$FROM_STDIN" = "1" ]; then
    tmp_input="${TMPDIR:-/tmp}/proton-import.$$.conf"
    cat > "$tmp_input"
    INPUT_FILE="$tmp_input"
fi

[ -n "${INPUT_FILE:-}" ] || die "Не задан источник Proton-конфига (--from-file или --from-stdin)"
[ -f "$INPUT_FILE" ] || die "Файл не найден: $INPUT_FILE"

SRC_PRIVATE_KEY="$(conf_value "Interface" "PrivateKey" "$INPUT_FILE" || true)"
SRC_ADDRESS="$(conf_value "Interface" "Address" "$INPUT_FILE" || true)"
SRC_DNS="$(conf_value "Interface" "DNS" "$INPUT_FILE" || true)"
SRC_PEER_PUBLIC_KEY="$(conf_value "Peer" "PublicKey" "$INPUT_FILE" || true)"
SRC_ALLOWED_IPS="$(conf_value "Peer" "AllowedIPs" "$INPUT_FILE" || true)"
SRC_ENDPOINT="$(conf_value "Peer" "Endpoint" "$INPUT_FILE" || true)"
SRC_KEEPALIVE="$(conf_value "Peer" "PersistentKeepalive" "$INPUT_FILE" || true)"

[ -n "$SRC_PRIVATE_KEY" ] || die "В конфиге не найден Interface.PrivateKey"
[ -n "$SRC_ADDRESS" ] || die "В конфиге не найден Interface.Address"
[ -n "$SRC_PEER_PUBLIC_KEY" ] || die "В конфиге не найден Peer.PublicKey"
[ -n "$SRC_ENDPOINT" ] || die "В конфиге не найден Peer.Endpoint"

ORIGINAL_DNS="$SRC_DNS"
ORIGINAL_ALLOWED_IPS="$SRC_ALLOWED_IPS"
ORIGINAL_PERSISTENT_KEEPALIVE="$SRC_KEEPALIVE"

apply_mode_overrides
AWG_NOISE_ENABLED="$(proton_awg_normalize_noise_enabled "$AWG_NOISE_ENABLED")"
AWG_I1_ENTROPY="$(proton_awg_normalize_i1_entropy "$AWG_I1_ENTROPY")"
proton_awg_version_variant_params "$VERSION" "$VARIANT" "$AWG_NOISE_ENABLED" "$AWG_I1_ENTROPY"

mkdir -p "$CONF_DIR"
if [ -z "${NAME:-}" ]; then
    NAME_BASE="$(build_generated_name_base)"
    NAME="$(pick_unique_name "$NAME_BASE")"
else
    NAME="$(sanitize_slug "$NAME")"
    [ -n "$NAME" ] || die "Имя после очистки пустое"
fi

PROFILE_LABEL="mode=$MODE country=$COUNTRY session=import server=import awg=$VERSION variant=$VARIANT"

print_preview() {
    printf 'PREVIEW=proton-conf-import\n'
    printf 'INPUT=%s\n' "$INPUT_FILE"
    printf 'MODE=%s\n' "$MODE"
    printf 'COUNTRY=%s\n' "$COUNTRY"
    printf 'AWG_VERSION=%s\n' "$VERSION"
    printf 'VARIANT=%s\n' "$VARIANT"
    printf 'AWG_NOISE_ENABLED=%s\n' "$AWG_NOISE_ENABLED"
    printf 'AWG_I1_ENTROPY=%s\n' "$AWG_I1_ENTROPY"
    printf 'AWG_I1_ENTROPY_ENABLED=%s\n' "$(proton_awg_normalize_i1_entropy_enabled "$AWG_I1_ENTROPY")"
    printf 'MTU=%s\n' "$MTU"
    printf 'SRC_ADDRESS=%s\n' "$SRC_ADDRESS"
    printf 'SRC_DNS=%s\n' "${SRC_DNS:-<absent>}"
    printf 'SRC_ALLOWED_IPS=%s\n' "${SRC_ALLOWED_IPS:-<absent>}"
    printf 'SRC_ENDPOINT=%s\n' "$SRC_ENDPOINT"
    printf 'SRC_PERSISTENT_KEEPALIVE=%s\n' "${SRC_KEEPALIVE:-<absent>}"
    printf 'RESULT_DNS=%s\n' "${DNS:-<absent>}"
    printf 'RESULT_ALLOWED_IPS=%s\n' "${ALLOWED_IPS:-<absent>}"
    printf 'RESULT_PERSISTENT_KEEPALIVE=%s\n' "${PERSISTENT_KEEPALIVE:-<absent>}"
}

if [ "$PREVIEW_ONLY" = "1" ]; then
    print_preview
    [ -z "$tmp_input" ] || rm -f "$tmp_input"
    exit 0
fi

OUTFILE="$CONF_DIR/${NAME}.conf"
METAFILE="$CONF_DIR/${NAME}.conf.meta"

write_conf "$OUTFILE"
write_meta "$METAFILE"
[ -z "$tmp_input" ] || rm -f "$tmp_input"

success "Импорт завершен: $OUTFILE"
printf 'SOURCE=%s\n' "$OUTFILE"
printf 'META=%s\n' "$METAFILE"
printf 'NAME=%s\n' "$NAME"
printf 'MODE=%s\n' "$MODE"
