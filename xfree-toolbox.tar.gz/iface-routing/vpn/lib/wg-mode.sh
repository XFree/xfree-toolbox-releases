#!/bin/sh
# shellcheck shell=sh

# Common mode helpers for VPN generators that produce an AWG config.
# Expected variables before apply_mode_overrides():
#   MODE
#   ORIGINAL_DNS
#   ORIGINAL_ALLOWED_IPS
#   ORIGINAL_PERSISTENT_KEEPALIVE
# Optional defaults:
#   RAW_DEFAULT_DNS
#   RAW_DEFAULT_ALLOWED_IPS
#   LOCAL_DEFAULT_DNS
#   LOCAL_DEFAULT_ALLOWED_IPS
#   LOCAL_DEFAULT_PERSISTENT_KEEPALIVE
# Optional user overrides:
#   DNS
#   ALLOWED_IPS
#   PERSISTENT_KEEPALIVE
# Outputs:
#   DNS
#   ALLOWED_IPS
#   PERSISTENT_KEEPALIVE

normalize_mode() {
    case "$1" in
        local|raw) printf '%s\n' "$1" ;;
        *) die "Неизвестный режим: $1" ;;
    esac
}

_mode_pick_keepalive() {
    mode="$1"
    original="$2"

    case "$mode" in
        raw)
            printf '%s\n' "$original"
            ;;
        local)
            if [ -n "${PERSISTENT_KEEPALIVE:-}" ]; then
                printf '%s\n' "$PERSISTENT_KEEPALIVE"
            elif [ -n "$original" ]; then
                printf '%s\n' "$original"
            else
                printf '%s\n' "${LOCAL_DEFAULT_PERSISTENT_KEEPALIVE:-25}"
            fi
            ;;
        *)
            die "Неизвестный режим: $mode"
            ;;
    esac
}

apply_mode_overrides() {
    original_dns="${ORIGINAL_DNS:-}"
    original_allowed_ips="${ORIGINAL_ALLOWED_IPS:-}"
    original_keepalive="${ORIGINAL_PERSISTENT_KEEPALIVE:-}"

    case "$MODE" in
        raw)
            if [ -z "${DNS:-}" ]; then
                DNS="$original_dns"
                [ -n "$DNS" ] || DNS="${RAW_DEFAULT_DNS:-}"
            fi
            if [ -z "${ALLOWED_IPS:-}" ]; then
                ALLOWED_IPS="$original_allowed_ips"
                [ -n "$ALLOWED_IPS" ] || ALLOWED_IPS="${RAW_DEFAULT_ALLOWED_IPS:-}"
            fi
            PERSISTENT_KEEPALIVE="$(_mode_pick_keepalive raw "$original_keepalive")"
            ;;
        local)
            # DNS= is LOCAL_DEFAULT_DNS. Explicit --dns still wins.
            if [ -z "${DNS:-}" ]; then
                if [ -n "${LOCAL_DEFAULT_DNS:-}" ]; then
                    DNS="$LOCAL_DEFAULT_DNS"
                else
                    DNS="$original_dns"
                fi
            fi
            if [ -z "${ALLOWED_IPS:-}" ]; then
                if [ -n "${LOCAL_DEFAULT_ALLOWED_IPS:-}" ]; then
                    ALLOWED_IPS="$LOCAL_DEFAULT_ALLOWED_IPS"
                else
                    ALLOWED_IPS="$original_allowed_ips"
                fi
            fi
            PERSISTENT_KEEPALIVE="$(_mode_pick_keepalive local "$original_keepalive")"
            ;;
        *)
            die "Неизвестный режим: $MODE"
            ;;
    esac
}

comment_value() {
    value="$1"
    if [ -n "$value" ]; then
        printf '%s\n' "$value"
    else
        printf '<absent>\n'
    fi
}

write_common_local_comment_block() {
    outfile="$1"

    if [ "$MODE" != "local" ]; then
        return 0
    fi

    route_allowed_uci="${ROUTE_ALLOWED_IPS_UCI:-0}"
    case "$route_allowed_uci" in
        0|1) ;;
        *) route_allowed_uci="0" ;;
    esac
    default_route_uci="${DEFAULT_ROUTE_UCI:-0}"
    case "$default_route_uci" in
        0|1) ;;
        *) default_route_uci="0" ;;
    esac

    {
        printf '# --- xfree-toolbox ---\n'
        printf '# mode: local\n'
        printf '# original:\n'
        printf '#   DNS=%s\n' "$(comment_value "${ORIGINAL_DNS:-}")"
        printf '#   AllowedIPs=%s\n' "$(comment_value "${ORIGINAL_ALLOWED_IPS:-}")"
        printf '#   PersistentKeepalive=%s\n' "$(comment_value "${ORIGINAL_PERSISTENT_KEEPALIVE:-}")"
        printf '#   DefaultRoute=<uci-only>\n'
        printf '#   RouteAllowedIPs=<uci-only>\n'
        printf '# applied:\n'
        printf '#   DNS=%s\n' "$(comment_value "${DNS:-}")"
        printf '#   AllowedIPs=%s\n' "$(comment_value "${ALLOWED_IPS:-}")"
        printf '#   PersistentKeepalive=%s\n' "$(comment_value "${PERSISTENT_KEEPALIVE:-}")"
        printf '#   DefaultRoute=%s (replaced by UCI option defaultroute)\n' "$default_route_uci"
        printf '#   RouteAllowedIPs=%s (replaced by UCI option route_allowed_ips)\n' "$route_allowed_uci"
        printf '# uci-recommendation:\n'
        printf "#   option defaultroute '%s'\n" "$default_route_uci"
        printf "#   option route_allowed_ips '%s'\n" "$route_allowed_uci"
        printf '# ---\n\n'
    } >> "$outfile"
}

awg_hash_sha256() {
    value="$1"
    if command -v sha256sum >/dev/null 2>&1; then
        printf '%s' "$value" | sha256sum | awk '{print $1}'
        return 0
    fi
    if command -v openssl >/dev/null 2>&1; then
        printf '%s' "$value" | openssl dgst -sha256 2>/dev/null | awk '{print $NF}'
        return 0
    fi
    return 1
}

awg_i1_hex_payload() {
    printf '%s' "$1" | sed 's/^<b 0x//; s/>$//'
}

awg_i1_wrap_hex() {
    printf '<b 0x%s>\n' "$1"
}

awg_random_hex() {
    n="$1"
    [ "$n" -gt 0 ] 2>/dev/null || return 1
    bytes=$(( (n + 1) / 2 ))
    if command -v hexdump >/dev/null 2>&1; then
        hexdump -v -n "$bytes" -e '/1 "%02x"' /dev/urandom 2>/dev/null | cut -c1-"$n"
        return 0
    fi
    if command -v od >/dev/null 2>&1; then
        od -An -N "$bytes" -tx1 /dev/urandom 2>/dev/null | tr -d ' \n' | cut -c1-"$n"
        return 0
    fi
    return 1
}

awg_seeded_hex() {
    seed="$1"
    n="$2"
    out=""
    idx=0
    while [ "${#out}" -lt "$n" ]; do
        h="$(awg_hash_sha256 "${seed}:${idx}" || true)"
        [ -n "$h" ] || return 1
        out="${out}${h}"
        idx=$((idx + 1))
    done
    printf '%s\n' "$out" | cut -c1-"$n"
}

awg_normalize_i1_mode() {
    case "$1" in
        fixed|random|domain) printf '%s\n' "$1" ;;
        *) die "Неизвестный I1 mode: $1" ;;
    esac
}

# Shared I1 transformation for AWG presets.
# Expected globals:
#   I1_MODE (fixed|random|domain), optional (defaults fixed)
#   I1_DOMAIN (required for domain mode)
#   VARIANT (for variant=3 safety fallback)
#   AWG_I1 (preset payload)
awg_apply_i1_mode() {
    I1_MODE="${I1_MODE:-fixed}"
    I1_DOMAIN="${I1_DOMAIN:-}"
    I1_MODE="$(awg_normalize_i1_mode "$I1_MODE")"
    [ "$I1_MODE" = "fixed" ] && return 0

    if [ "${VARIANT:-}" = "3" ]; then
        warn "I1 mode '$I1_MODE' для variant=3 не поддержан (использую фиксированный preset I1/I2)"
        I1_MODE="fixed"
        return 0
    fi

    base_hex="$(awg_i1_hex_payload "${AWG_I1:-}")"
    target_len="${#base_hex}"
    [ "$target_len" -gt 0 ] 2>/dev/null || return 0

    case "$I1_MODE" in
        random)
            new_hex="$(awg_random_hex "$target_len" || true)"
            [ -n "$new_hex" ] || {
                warn "Не удалось сгенерировать random I1 — использую fixed"
                I1_MODE="fixed"
                return 0
            }
            AWG_I1="$(awg_i1_wrap_hex "$new_hex")"
            ;;
        domain)
            I1_DOMAIN="$(printf '%s' "$I1_DOMAIN" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
            [ -n "$I1_DOMAIN" ] || die "--i1-mode domain требует --i1-domain"
            new_hex="$(awg_seeded_hex "$I1_DOMAIN" "$target_len" || true)"
            [ -n "$new_hex" ] || {
                warn "Не удалось сгенерировать domain-seeded I1 — использую fixed"
                I1_MODE="fixed"
                return 0
            }
            AWG_I1="$(awg_i1_wrap_hex "$new_hex")"
            ;;
    esac
}
