#!/bin/sh
# shellcheck shell=sh

# Common mode helpers for VPN generators that produce an AWG config.
# Expected variables before apply_mode_overrides():
#   MODE
#   ORIGINAL_DNS
#   ORIGINAL_ALLOWED_IPS
#   ORIGINAL_PERSISTENT_KEEPALIVE
# Optional defaults:
#   RAW_DEFAULT_DNS
#   RAW_DEFAULT_ALLOWED_IPS
#   LOCAL_DEFAULT_DNS
#   LOCAL_DEFAULT_ALLOWED_IPS
#   LOCAL_DEFAULT_PERSISTENT_KEEPALIVE
# Optional user overrides:
#   DNS
#   ALLOWED_IPS
#   PERSISTENT_KEEPALIVE
# Outputs:
#   DNS
#   ALLOWED_IPS
#   PERSISTENT_KEEPALIVE

normalize_mode() {
    case "$1" in
        local|raw) printf '%s\n' "$1" ;;
        *) die "Неизвестный режим: $1" ;;
    esac
}

_mode_pick_keepalive() {
    mode="$1"
    original="$2"

    case "$mode" in
        raw)
            if [ -n "${PERSISTENT_KEEPALIVE:-}" ]; then
                printf '%s\n' "$PERSISTENT_KEEPALIVE"
            elif [ -n "$original" ]; then
                printf '%s\n' "$original"
            else
                printf '%s\n' "${RAW_DEFAULT_PERSISTENT_KEEPALIVE:-${DEFAULT_PERSISTENT_KEEPALIVE:-25}}"
            fi
            ;;
        local)
            if [ -n "${PERSISTENT_KEEPALIVE:-}" ]; then
                printf '%s\n' "$PERSISTENT_KEEPALIVE"
            elif [ -n "$original" ]; then
                printf '%s\n' "$original"
            else
                printf '%s\n' "${LOCAL_DEFAULT_PERSISTENT_KEEPALIVE:-${DEFAULT_PERSISTENT_KEEPALIVE:-25}}"
            fi
            ;;
        *)
            die "Неизвестный режим: $mode"
            ;;
    esac
}

apply_mode_overrides() {
    original_dns="${ORIGINAL_DNS:-}"
    original_allowed_ips="${ORIGINAL_ALLOWED_IPS:-}"
    original_keepalive="${ORIGINAL_PERSISTENT_KEEPALIVE:-}"

    case "$MODE" in
        raw)
            if [ -z "${DNS:-}" ]; then
                DNS="$original_dns"
                [ -n "$DNS" ] || DNS="${RAW_DEFAULT_DNS:-}"
            fi
            if [ -z "${ALLOWED_IPS:-}" ]; then
                ALLOWED_IPS="$original_allowed_ips"
                [ -n "$ALLOWED_IPS" ] || ALLOWED_IPS="${RAW_DEFAULT_ALLOWED_IPS:-}"
            fi
            PERSISTENT_KEEPALIVE="$(_mode_pick_keepalive raw "$original_keepalive")"
            ;;
        local)
            # DNS= is LOCAL_DEFAULT_DNS. Explicit --dns still wins.
            if [ -z "${DNS:-}" ]; then
                if [ -n "${LOCAL_DEFAULT_DNS:-}" ]; then
                    DNS="$LOCAL_DEFAULT_DNS"
                else
                    DNS="$original_dns"
                fi
            fi
            if [ -z "${ALLOWED_IPS:-}" ]; then
                if [ -n "${LOCAL_DEFAULT_ALLOWED_IPS:-}" ]; then
                    ALLOWED_IPS="$LOCAL_DEFAULT_ALLOWED_IPS"
                else
                    ALLOWED_IPS="$original_allowed_ips"
                fi
            fi
            PERSISTENT_KEEPALIVE="$(_mode_pick_keepalive local "$original_keepalive")"
            ;;
        *)
            die "Неизвестный режим: $MODE"
            ;;
    esac
}

comment_value() {
    value="$1"
    if [ -n "$value" ]; then
        printf '%s\n' "$value"
    else
        printf '<absent>\n'
    fi
}

write_common_local_comment_block() {
    outfile="$1"

    if [ "$MODE" != "local" ]; then
        return 0
    fi

    route_allowed_uci="${ROUTE_ALLOWED_IPS_UCI:-0}"
    case "$route_allowed_uci" in
        0|1) ;;
        *) route_allowed_uci="0" ;;
    esac
    default_route_uci="${DEFAULT_ROUTE_UCI:-0}"
    case "$default_route_uci" in
        0|1) ;;
        *) default_route_uci="0" ;;
    esac

    {
        printf '# --- xfree-toolbox ---\n'
        printf '# mode: local\n'
        printf '# original:\n'
        printf '#   DNS=%s\n' "$(comment_value "${ORIGINAL_DNS:-}")"
        printf '#   AllowedIPs=%s\n' "$(comment_value "${ORIGINAL_ALLOWED_IPS:-}")"
        printf '#   PersistentKeepalive=%s\n' "$(comment_value "${ORIGINAL_PERSISTENT_KEEPALIVE:-}")"
        printf '#   DefaultRoute=<uci-only>\n'
        printf '#   RouteAllowedIPs=<uci-only>\n'
        printf '# applied:\n'
        printf '#   DNS=%s\n' "$(comment_value "${DNS:-}")"
        printf '#   AllowedIPs=%s\n' "$(comment_value "${ALLOWED_IPS:-}")"
        printf '#   PersistentKeepalive=%s\n' "$(comment_value "${PERSISTENT_KEEPALIVE:-}")"
        printf '#   DefaultRoute=%s (replaced by UCI option defaultroute)\n' "$default_route_uci"
        printf '#   RouteAllowedIPs=%s (replaced by UCI option route_allowed_ips)\n' "$route_allowed_uci"
        printf '# uci-recommendation:\n'
        printf "#   option defaultroute '%s'\n" "$default_route_uci"
        printf "#   option route_allowed_ips '%s'\n" "$route_allowed_uci"
        printf '# ---\n\n'
    } >> "$outfile"
}

awg_hash_sha256() {
    value="$1"
    if command -v sha256sum >/dev/null 2>&1; then
        printf '%s' "$value" | sha256sum | awk '{print $1}'
        return 0
    fi
    if command -v openssl >/dev/null 2>&1; then
        printf '%s' "$value" | openssl dgst -sha256 2>/dev/null | awk '{print $NF}'
        return 0
    fi
    return 1
}

awg_i1_hex_payload() {
    printf '%s' "$1" | sed 's/^<b 0x//; s/>$//'
}

awg_i1_wrap_hex() {
    printf '<b 0x%s>\n' "$1"
}

awg_random_hex() {
    n="$1"
    [ "$n" -gt 0 ] 2>/dev/null || return 1
    bytes=$(( (n + 1) / 2 ))
    if command -v hexdump >/dev/null 2>&1; then
        hexdump -v -n "$bytes" -e '/1 "%02x"' /dev/urandom 2>/dev/null | cut -c1-"$n"
        return 0
    fi
    if command -v od >/dev/null 2>&1; then
        od -An -N "$bytes" -tx1 /dev/urandom 2>/dev/null | tr -d ' \n' | cut -c1-"$n"
        return 0
    fi
    return 1
}

awg_seeded_hex() {
    seed="$1"
    n="$2"
    out=""
    idx=0
    while [ "${#out}" -lt "$n" ]; do
        h="$(awg_hash_sha256 "${seed}:${idx}" || true)"
        [ -n "$h" ] || return 1
        out="${out}${h}"
        idx=$((idx + 1))
    done
    printf '%s\n' "$out" | cut -c1-"$n"
}

awg_normalize_i1_mode() {
    case "$1" in
        fixed|random|domain) printf '%s\n' "$1" ;;
        *) die "Неизвестный I1 mode: $1" ;;
    esac
}

# Shared I1 transformation for AWG presets.
# Expected globals:
#   I1_MODE (fixed|random|domain), optional (defaults fixed)
#   I1_DOMAIN (required for domain mode)
#   VARIANT (for variant=3 safety fallback)
#   AWG_I1 (preset payload)
awg_apply_i1_mode() {
    I1_MODE="${I1_MODE:-fixed}"
    I1_DOMAIN="${I1_DOMAIN:-}"
    I1_MODE="$(awg_normalize_i1_mode "$I1_MODE")"
    [ "$I1_MODE" = "fixed" ] && return 0

    if [ "${VARIANT:-}" = "3" ]; then
        warn "I1 mode '$I1_MODE' для variant=3 не поддержан (использую фиксированный preset I1/I2)"
        I1_MODE="fixed"
        return 0
    fi

    base_hex="$(awg_i1_hex_payload "${AWG_I1:-}")"
    target_len="${#base_hex}"
    [ "$target_len" -gt 0 ] 2>/dev/null || return 0

    case "$I1_MODE" in
        random)
            new_hex="$(awg_random_hex "$target_len" || true)"
            [ -n "$new_hex" ] || {
                warn "Не удалось сгенерировать random I1 — использую fixed"
                I1_MODE="fixed"
                return 0
            }
            AWG_I1="$(awg_i1_wrap_hex "$new_hex")"
            ;;
        domain)
            I1_DOMAIN="$(printf '%s' "$I1_DOMAIN" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
            [ -n "$I1_DOMAIN" ] || die "--i1-mode domain требует --i1-domain"
            new_hex="$(awg_seeded_hex "$I1_DOMAIN" "$target_len" || true)"
            [ -n "$new_hex" ] || {
                warn "Не удалось сгенерировать domain-seeded I1 — использую fixed"
                I1_MODE="fixed"
                return 0
            }
            AWG_I1="$(awg_i1_wrap_hex "$new_hex")"
            ;;
    esac
}

awg_normalize_noise_enabled() {
    _raw="${1:-}"
    _default="${2:-0}"
    case "$_raw" in
        1|yes|YES|true|TRUE|on|ON) printf '%s\n' "1" ;;
        0|no|NO|false|FALSE|off|OFF) printf '%s\n' "0" ;;
        "") printf '%s\n' "$_default" ;;
        *) printf '%s\n' "$_default" ;;
    esac
}

awg_apply_noise_mode() {
    case "$(awg_normalize_noise_enabled "${1:-0}" 0)" in
        1) ;;
        *)
            AWG_JC='0'
            AWG_JMIN='0'
            AWG_JMAX='0'
            ;;
    esac
}

awg_noise_label() {
    case "$(awg_normalize_noise_enabled "${1:-0}" 0)" in
        1) printf '%s\n' "с шумом (Jc=4, Jmin=40, Jmax=70)" ;;
        *) printf '%s\n' "без шума (Jc/Jmin/Jmax=0)" ;;
    esac
}

# Режимы энтропии I1: off | r32 | r64 | t | c | rc10 | rd6.
awg_normalize_i1_entropy() {
    _raw="${1:-}"
    _default="${2:-off}"
    case "$_raw" in
        0 | off | OFF | no | NO | false | FALSE | none | NONE) printf '%s\n' "off" ;;
        r32 | R32 | '<r 32>') printf '%s\n' "r32" ;;
        r64 | R64 | '<r 64>') printf '%s\n' "r64" ;;
        t | T | '<t>') printf '%s\n' "t" ;;
        c | C | '<c>') printf '%s\n' "c" ;;
        rc10 | RC10 | '<rc 10>') printf '%s\n' "rc10" ;;
        rd6 | RD6 | '<rd 6>') printf '%s\n' "rd6" ;;
        1 | on | ON | yes | YES | true | TRUE) printf '%s\n' "r32" ;;
        "") printf '%s\n' "$_default" ;;
        *) printf '%s\n' "$_default" ;;
    esac
}

awg_normalize_i1_entropy_enabled() {
    case "$(awg_normalize_i1_entropy "${1:-}" "${2:-off}")" in
        off) printf '%s\n' "0" ;;
        *) printf '%s\n' "1" ;;
    esac
}

awg_i1_entropy_tag() {
    case "$(awg_normalize_i1_entropy "${1:-off}" "off")" in
        off) ;;
        r64) printf '%s\n' '<r 64>' ;;
        t) printf '%s\n' '<t>' ;;
        c) printf '%s\n' '<c>' ;;
        rc10) printf '%s\n' '<rc 10>' ;;
        rd6) printf '%s\n' '<rd 6>' ;;
        r32) printf '%s\n' '<r 32>' ;;
        *) ;;
    esac
}

awg_i1_entropy_label() {
    case "$(awg_normalize_i1_entropy "${1:-off}" "off")" in
        off) printf '%s\n' "I1 без энтропии" ;;
        r64) printf '%s\n' "I1 + <r 64>" ;;
        t) printf '%s\n' "I1 + <t>" ;;
        c) printf '%s\n' "I1 + <c>" ;;
        rc10) printf '%s\n' "I1 + <rc 10>" ;;
        rd6) printf '%s\n' "I1 + <rd 6>" ;;
        r32) printf '%s\n' "I1 + <r 32>" ;;
        *) printf '%s\n' "I1 без энтропии" ;;
    esac
}

awg_i1_entropy_strip() {
    [ -n "${AWG_I1:-}" ] || return 0
    changed=1
    while [ "$changed" = 1 ]; do
        changed=0
        for _tag in '<r 32>' '<r 64>' '<rc 10>' '<rd 6>' '<t>' '<c>'; do
            case "$AWG_I1" in
                *"$_tag")
                    AWG_I1="${AWG_I1%$_tag}"
                    changed=1
                    ;;
            esac
        done
    done
}

awg_apply_i1_entropy() {
    [ -n "${AWG_I1:-}" ] || return 0
    awg_i1_entropy_strip
    _tag="$(awg_i1_entropy_tag "$1")"
    [ -n "$_tag" ] || return 0
    AWG_I1="${AWG_I1}${_tag}"
}

awg_normalize_variant() {
    case "$1" in
        auto|1|2|3) printf '%s\n' "$1" ;;
        "") printf '%s\n' "auto" ;;
        *) die "Неизвестный вариант AWG: $1" ;;
    esac
}

awg_reset_version_extensions() {
    AWG_HAS_S3=0
    AWG_HAS_S4=0
    AWG_S3=''
    AWG_S4=''
}

awg_set_variant_base_params() {
    case "$1" in
        1|auto|'')
            AWG_S1='0'; AWG_S2='0'; AWG_JC='4'; AWG_JMIN='40'; AWG_JMAX='70';
            AWG_H1='1'; AWG_H2='2'; AWG_H3='3'; AWG_H4='4';
            AWG_I1='<b 0xce000000010897a297ecc34cd6dd000044d0ec2e2e1ea2991f467ace4222129b5a098823784694b4897b9986ae0b7280135fa85e196d9ad980b150122129ce2a9379531b0fd3e871ca5fdb883c369832f730e272d7b8b74f393f9f0fa43f11e510ecb2219a52984410c204cf875585340c62238e14ad04dff382f2c200e0ee22fe743b9c6b8b043121c5710ec289f471c91ee414fca8b8be8419ae8ce7ffc53837f6ade262891895f3f4cecd31bc93ac5599e18e4f01b472362b8056c3172b513051f8322d1062997ef4a383b01706598d08d48c221d30e74c7ce000cdad36b706b1bf9b0607c32ec4b3203a4ee21ab64df336212b9758280803fcab14933b0e7ee1e04a7becce3e2633f4852585c567894a5f9efe9706a151b615856647e8b7dba69ab357b3982f554549bef9256111b2d67afde0b496f16962d4957ff654232aa9e845b61463908309cfd9de0a6abf5f425f577d7e5f6440652aa8da5f73588e82e9470f3b21b27b28c649506ae1a7f5f15b876f56abc4615f49911549b9bb39dd804fde182bd2dcec0c33bad9b138ca07d4a4a1650a2c2686acea05727e2a78962a840ae428f55627516e73c83dd8893b02358e81b524b4d99fda6df52b3a8d7a5291326e7ac9d773c5b43b8444554ef5aea104a738ed650aa979674bbed38da58ac29d87c29d387d80b526065baeb073ce65f075ccb56e47533aef357dceaa8293a523c5f6f790be90e4731123d3c6152a70576e90b4ab5bc5ead01576c68ab633ff7d36dcde2a0b2c68897e1acfc4d6483aaaeb635dd63c96b2b6a7a2bfe042f6aed82e5363aa850aace12ee3b1a93f30d8ab9537df483152a5527faca21efc9981b304f11fc95336f5b9637b174c5a0659e2b22e159a9fed4b8e93047371175b1d6d9cc8ab745f3b2281537d1c75fb9451871864efa5d184c38c185fd203de206751b92620f7c369e031d2041e152040920ac2c5ab5340bfc9d0561176abf10a147287ea90758575ac6a9f5ac9f390d0d5b23ee12af583383d994e22c0cf42383834bcd3ada1b3825a0664d8f3fb678261d57601ddf94a8a68a7c273a18c08aa99c7ad8c6c42eab67718843597ec9930457359dfdfbce024afc2dcf9348579a57d8d3490b2fa99f278f1c37d87dad9b221acd575192ffae1784f8e60ec7cee4068b6b988f0433d96d6a1b1865f4e155e9fe020279f434f3bf1bd117b717b92f6cd1cc9bea7d45978bcc3f24bda631a36910110a6ec06da35f8966c9279d130347594f13e9e07514fa370754d1424c0a1545c5070ef9fb2acd14233e8a50bfc5978b5bdf8bc1714731f798d21e2004117c61f2989dd44f0cf027b27d4019e81ed4b5c31db347c4a3a4d85048d7093cf16753d7b0d15e078f5c7a5205dc2f87e330a1f716738dce1c6180e9d02869b5546f1c4d2748f8c90d9693cba4e0079297d22fd61402dea32ff0eb69ebd65a5d0b687d87e3a8b2c42b648aa723c7c7daf37abcc4bb85caea2ee8f55bec20e913b3324ab8f5c3304f820d42ad1b9f2ffc1a3af9927136b4419e1e579ab4c2ae3c776d293d397d575df181e6cae0a4ada5d67ecea171cca3288d57c7bbdaee3befe745fb7d634f70386d873b90c4d6c6596bb65af68f9e5121e67ebf0d89d3c909ceedfb32ce9575a7758ff080724e1ab5d5f43074ecb53a479af21ed03d7b6899c36631c0166f9d47e5e1d4528a5d3d3f744029c4b1c190cbfbad06f5f83f7ad0429fa9a2719c56ffe3783460e166de2d8>'
            AWG_I2=''
            ;;
        2)
            AWG_S1='0'; AWG_S2='0'; AWG_JC='4'; AWG_JMIN='40'; AWG_JMAX='70';
            AWG_H1='1'; AWG_H2='2'; AWG_H3='3'; AWG_H4='4';
            AWG_I1='<b 0xc7000000010809a1ed4edbbe7615000044d017a61a0d774f04290f119e701ef0035df2b0ed571b0b575e6a07246b856eb6ec036fef07f1e07b861251ad737abeb67e64be714c1dcd865312b1b6c35c089c997aeb5c18f808696fe97289513945d84ca846467603e94e44224877f2c1d3261e4ac18740be4bd064369c94fc08978d99b54bf615250998639010c1284248e1d73004b81fcb20b559d8a17eced7eab3964b5b88ca7a3b8579fc8c1c934189e77143b4ac434138114b1048651b56545b87acbef0952763538f3ddeb37cfc6d58b4881c3b719d7ff78f6ee1324a2914a32381c05a64c700466d280be007253bb030d179c4f1b3dc221e1974e2ee6d6e2b9e8d709159b5ef22e1783dbba845c20ca1c83b066c73835920ad70b806df0aee0351e3fc9ab1e42e8b2a30fe235ff0612eee19744949cecee0463b76514ad90c1f7ceaa557c18586ab561d49482e73c85d0143785da14a441bf82f78783b61cccd44aecb1947516e79b5ca5a6b3a8aed6040fae0eeabdc55a88dc19ade832d99fca90c7a629cacc07192d7e47e3c6a271b95b0ea3392562a06a1cab79f40ea92916ebee197b7b5f14b251824e1ed20ff2ca80b1f03a43e45157589bc61b978e97851025b3b7ccc17d291e1cb60fe48a5c26829dce11dd23c2e73265a9ebf8617c985e4fee4681e863f990061f4dea465a7d2524bd0edcf4b48d4b8f25fc359b15babd2637284a4774077dca60091f1a781cfee1bef9713dd5943a579d7470bc5970542fbb27fdf77880a8d8751b1f642c7a3f019a05ab94bf63d3525ef34e9290b5c8d477f2714e6d6e3e4d35c1983f5e16fda57fcdf071b513f8f088dbe8d5a97577d17a5383a496c3f313adfdd47c962bbaebd6aa13b46439eb742622c29ca067db0ec1853064c3cbbffe0a215a19fce47d49703ed58ebbd89721172d256d1cf30188106fb2f863186511401fad54d087aa2fb3d1b85768db386bd7102e8060ac157bac011acdcdae2799b9aee1467c3424013455bd028fcaacdc3c77d28ea199967d617ea7d0d0815f3cc407934a76d1293dccba210d1709a13e5dd67c9ba47cd113f5bdd740358eff13164159fd09bc2f7ec6cfa64d9df7e2e2f88706b0ff3a92ccf6f078456cfe0bdd89292cfe2680badc1eac9f7d36efe8eb6912c7b164508d13e6c0911c15f73c233cbe4fc70ff2ade1e1be4bbb738e0939159e2078a9438f05b756a003371f4861481c38f1cdd2d7b06deb62869e9fe79a8abaa920646fa2e8fa28f0d80c136376c7b56046bae4c05c0cdf64efb8c47bbfc5a1a4c0b045061ef0d71618e0d206a1d7f245fd5c03191b152673ba8dff8e1b8de7c50234a93cba91e3888adb228cc02beded4b1c0946797d3ef02dec2edb6ad0ac21f89f4be364c317da7c22440e9f358d512203f4b7ab20388af68b8915d0152db2c8a0687bfaea870f7529bb92a22b35bd79bc6d490591406346ecd78342ee3563c4883a8251679691c2d4e963397e24653520795511b018915374c954bddb940a9d7a16d1c8bd798fc7dbfb0599a7074e13f87e14efa8d511bb2579ec029b1bda18fe971b30fbe19e986ff2686a69bf3f1bb929de93ae70345ebca998b11e0a2b41890cba628d8f6e7c4e94790735e5299b4ff07cd3080f7d53c9cbe1911d2cd5925b3213e033c272506a87886cf761a283a779564d3241e3c28f632e166b5d756e1786ce077614c4444e3f2aed5decb3613b925ea3e558c21d4faf8ba54edd0f3a5d4>'
            AWG_I2=''
            ;;
        3)
            AWG_S1='0'; AWG_S2='0'; AWG_JC='4'; AWG_JMIN='40'; AWG_JMAX='70';
            AWG_H1='1'; AWG_H2='2'; AWG_H3='3'; AWG_H4='4';
            AWG_I1='<b 0x494e56495445207369703a626f624062696c6f78692e636f6d205349502f322e300d0a5669613a205349502f322e302f55445020706333332e61746c616e74612e636f6d3b6272616e63683d7a39684734624b3737366173646864730d0a4d61782d466f7277617264733a2037300d0a546f3a20426f62203c7369703a626f624062696c6f78692e636f6d3e0d0a46726f6d3a20416c696365203c7369703a616c6963654061746c616e74612e636f6d3e3b7461673d313932383330313737340d0a43616c6c2d49443a20613834623463373665363637313040706333332e61746c616e74612e636f6d0d0a435365713a2033313431353920494e564954450d0a436f6e746163743a203c7369703a616c69636540706333332e61746c616e74612e636f6d3e0d0a436f6e74656e742d547970653a206170706c69636174696f6e2f7364700d0a436f6e74656e742d4c656e6774683a20300d0a0d0a>'
            AWG_I2='<b 0x5349502f322e302031303020547279696e670d0a5669613a205349502f322e302f55445020706333332e61746c616e74612e636f6d3b6272616e63683d7a39684734624b3737366173646864730d0a546f3a20426f62203c7369703a626f624062696c6f78692e636f6d3e0d0a46726f6d3a20416c696365203c7369703a616c6963654061746c616e74612e636f6d3e3b7461673d313932383330313737340d0a43616c6c2d49443a20613834623463373665363637313040706333332e61746c616e74612e636f6d0d0a435365713a2033313431353920494e564954450d0a436f6e746163743a203c7369703a616c69636540706333332e61746c616e74612e636f6d3e0d0a436f6e74656e742d547970653a206170706c69636174696f6e2f7364700d0a436f6e74656e742d4c656e6774683a20300d0a0d0a>'
            ;;
        *) die "Неизвестный вариант: $1" ;;
    esac
}

awg_apply_version_extensions() {
    case "$1" in
        1.5) ;;
        2.0)
            AWG_HAS_S3=1
            AWG_HAS_S4=1
            AWG_S3='0'
            AWG_S4='0'
            ;;
        *) die "Неизвестная версия AWG: $1" ;;
    esac
}

awg_version_variant_params() {
    _ver="$1"
    _var="$2"
    _noise="${3:-0}"
    _entropy="${4:-r32}"
    case "$_var" in
        auto|'') _var="1" ;;
    esac
    awg_reset_version_extensions
    awg_set_variant_base_params "$_var"
    awg_apply_version_extensions "$_ver"
    awg_apply_noise_mode "$_noise"
    awg_apply_i1_entropy "$_entropy"
}
