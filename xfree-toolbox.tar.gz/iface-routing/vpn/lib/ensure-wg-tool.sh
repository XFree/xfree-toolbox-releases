#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
VPN_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$VPN_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
AWG_ENSURE_SCRIPT="${AWG_ENSURE_SCRIPT:-$ROOT_DIR/awg-ingress/ensure-awg.sh}"
INSTALL_IF_MISSING=0

usage() {
    cat <<EOF
Usage: $0 [--install-if-missing]

Ensure VPN crypto tooling for xfree-toolbox: каноника — AmneziaWG (awg).
При наличии только wg используется как fallback для отдельных операций.

Options:
  --install-if-missing   Try to install awg when both tools are missing
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --install-if-missing)
            INSTALL_IF_MISSING=1
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "[-] Неизвестный аргумент: $1" >&2
            exit 1
            ;;
    esac
    shift
done

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

if command -v wg >/dev/null 2>&1; then
    wg_bin="$(command -v wg)"
    success "WG tool доступен: $wg_bin"
    exit 0
fi

if command -v awg >/dev/null 2>&1; then
    awg_bin="$(command -v awg)"
    success "WG tool доступен: $awg_bin"
    exit 0
fi

warn "Не найден ни wg, ни awg"

if [ "$INSTALL_IF_MISSING" != "1" ]; then
    exit 1
fi

[ -f "$AWG_ENSURE_SCRIPT" ] || die "Не найден AWG ensure script: $AWG_ENSURE_SCRIPT"
info "Пробую установить awg через ensure-awg"
sh "$AWG_ENSURE_SCRIPT" --install-if-missing
common_wait_network_after_restart "${XFREE_NETWORK_WAIT_SEC:-90}" || true

if command -v wg >/dev/null 2>&1 || command -v awg >/dev/null 2>&1; then
    tool_bin="$(command -v wg 2>/dev/null || command -v awg 2>/dev/null)"
    success "WG tool установлен/доступен: $tool_bin"
    exit 0
fi

die "Не удалось обеспечить наличие ни wg, ни awg"
