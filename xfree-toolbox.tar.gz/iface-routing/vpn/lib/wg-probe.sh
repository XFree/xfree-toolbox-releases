#!/bin/sh
# shellcheck shell=sh
# Universal WireGuard / AmneziaWG Handshake & Latency Probe.
# Used by VPN generators (WARP, Proton) for real-world server selection and auto-variant detection.
set -eu

if [ -z "${WG_MODE_LIB:-}" ]; then
    if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/iface-routing/vpn/lib/wg-mode.sh" ]; then
        WG_MODE_LIB="$ROOT_DIR/iface-routing/vpn/lib/wg-mode.sh"
    elif [ -f "./iface-routing/vpn/lib/wg-mode.sh" ]; then
        WG_MODE_LIB="./iface-routing/vpn/lib/wg-mode.sh"
    elif [ -f "./vpn/lib/wg-mode.sh" ]; then
        WG_MODE_LIB="./vpn/lib/wg-mode.sh"
    elif [ -f "./lib/wg-mode.sh" ]; then
        WG_MODE_LIB="./lib/wg-mode.sh"
    fi
fi
[ -n "${WG_MODE_LIB:-}" ] && [ -f "$WG_MODE_LIB" ] && . "$WG_MODE_LIB"

WG_PROBE_DEV_PREFIX="${WG_PROBE_DEV_PREFIX:-wgprb}"
WG_PROBE_DEFAULT_TIMEOUT_MS="${WG_PROBE_DEFAULT_TIMEOUT_MS:-800}"
WG_PROBE_DEFAULT_BATCH_SIZE="${WG_PROBE_DEFAULT_BATCH_SIZE:-3}"
WG_PROBE_DUMMY_PRIVKEY="${WG_PROBE_DUMMY_PRIVKEY:-2Au021Wm64IovnUeVVB/2UYlpG8afma57auopnn0iVE=}"
WG_PROBE_VIA_DEV="${WG_PROBE_VIA_DEV:-}"

_WG_PROBE_SUPPORTED_CACHE=""
_WG_PROBE_VIA_ROUTES=""

wg_probe_is_via_active() {
    [ -n "${WG_PROBE_VIA_DEV:-}" ] || return 1
    case "${WG_PROBE_VIA_DEV:-}" in
        none|direct|wan|'') return 1 ;;
    esac
    command -v ip >/dev/null 2>&1 || return 1
    ip link show "$WG_PROBE_VIA_DEV" >/dev/null 2>&1 || return 1
}

wg_probe_add_via_route() {
    _ip="$1"
    wg_probe_is_via_active || return 0
    [ -n "$_ip" ] || return 0
    case "$_ip" in
        *:*) return 0 ;; # skip ipv6 host routes for ipv4 pointopoint probe dev
    esac
    _via_src=""
    if command -v ip >/dev/null 2>&1; then
        _via_src="$(ip -4 addr show dev "$WG_PROBE_VIA_DEV" 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1)"
    fi
    if [ -n "$_via_src" ]; then
        ip route replace "$_ip" dev "$WG_PROBE_VIA_DEV" src "$_via_src" 2>/dev/null || \
            ip route replace "$_ip" dev "$WG_PROBE_VIA_DEV" 2>/dev/null || true
    else
        ip route replace "$_ip" dev "$WG_PROBE_VIA_DEV" 2>/dev/null || true
    fi
    _WG_PROBE_VIA_ROUTES="${_WG_PROBE_VIA_ROUTES:+$_WG_PROBE_VIA_ROUTES }$_ip"
}

wg_probe_del_via_route() {
    _ip="$1"
    wg_probe_is_via_active || return 0
    [ -n "$_ip" ] || return 0
    ip route del "$_ip" dev "$WG_PROBE_VIA_DEV" 2>/dev/null || true
}

wg_probe_cleanup_via_routes() {
    [ -n "${_WG_PROBE_VIA_ROUTES:-}" ] || return 0
    for _r_ip in $_WG_PROBE_VIA_ROUTES; do
        [ -n "$_r_ip" ] || continue
        ip route del "$_r_ip" dev "$WG_PROBE_VIA_DEV" 2>/dev/null || true
    done
    _WG_PROBE_VIA_ROUTES=""
}

wg_probe_is_supported() {
    [ -n "$_WG_PROBE_SUPPORTED_CACHE" ] && return "$_WG_PROBE_SUPPORTED_CACHE"

    if [ "${WG_PROBE_FORCE_UNSUPPORTED:-0}" = "1" ]; then
        _WG_PROBE_SUPPORTED_CACHE=1
        return 1
    fi

    if [ "$(id -u 2>/dev/null || printf '1')" != "0" ]; then
        _WG_PROBE_SUPPORTED_CACHE=1
        return 1
    fi

    if ! command -v ip >/dev/null 2>&1; then
        _WG_PROBE_SUPPORTED_CACHE=1
        return 1
    fi

    if ! command -v wg >/dev/null 2>&1 && ! command -v awg >/dev/null 2>&1; then
        _WG_PROBE_SUPPORTED_CACHE=1
        return 1
    fi

    _test_dev="${WG_PROBE_DEV_PREFIX}chk$$"
    if ! ip link add dev "$_test_dev" type amneziawg 2>/dev/null && \
       ! ip link add dev "$_test_dev" type wireguard 2>/dev/null; then
        _WG_PROBE_SUPPORTED_CACHE=1
        return 1
    fi

    ip link del dev "$_test_dev" 2>/dev/null || true
    _WG_PROBE_SUPPORTED_CACHE=0
    return 0
}

wg_probe_pick_tool() {
    if command -v awg >/dev/null 2>&1; then
        printf 'awg\n'
    else
        printf 'wg\n'
    fi
}

wg_probe_pick_link_type() {
    _chk="${WG_PROBE_DEV_PREFIX}t$$"
    if ip link add dev "$_chk" type amneziawg 2>/dev/null; then
        ip link del dev "$_chk" 2>/dev/null || true
        printf 'amneziawg\n'
    else
        printf 'wireguard\n'
    fi
}

# Apply AWG parameters for the given variant (1, 2, 3) to the interface.
wg_probe_apply_variant() {
    _tool="$1"
    _dev="$2"
    _variant="$3"
    _noise="${4:-0}"
    _entropy="${5:-r32}"

    [ "$_tool" = "awg" ] || return 0
    case "$_variant" in
        0|none|raw|plain) return 0 ;;
    esac

    if command -v awg_version_variant_params >/dev/null 2>&1; then
        awg_version_variant_params "2.0" "$_variant" "$_noise" "$_entropy"
    elif command -v proton_awg_version_variant_params >/dev/null 2>&1; then
        proton_awg_version_variant_params "2.0" "$_variant" "$_noise" "$_entropy"
    else
        return 0
    fi

    # shellcheck disable=SC2086
    "$_tool" set "$_dev" \
        jc "${AWG_JC:-0}" jmin "${AWG_JMIN:-0}" jmax "${AWG_JMAX:-0}" \
        s1 "${AWG_S1:-0}" s2 "${AWG_S2:-0}" s3 "${AWG_S3:-0}" s4 "${AWG_S4:-0}" \
        h1 "${AWG_H1:-1}" h2 "${AWG_H2:-2}" h3 "${AWG_H3:-3}" h4 "${AWG_H4:-4}" \
        ${AWG_I1:+i1 "$AWG_I1"} ${AWG_I2:+i2 "$AWG_I2"} 2>/dev/null || true
}

# Run a parallel multi-peer handshake probe against a batch of candidates.
# Input lines on stdin:
#   IP <TAB> PORT <TAB> PUBKEY <TAB> ID [ <TAB> EXTRA... ]
# Output lines:
#   STATUS (OK|FAIL) <TAB> RTT_MS <TAB> ID <TAB> IP <TAB> PORT <TAB> PUBKEY <TAB> VARIANT [ <TAB> EXTRA... ]
wg_probe_batch() {
    _privkey="${1:-$WG_PROBE_DUMMY_PRIVKEY}"
    _variant="${2:-1}"
    _noise="${3:-0}"
    _entropy="${4:-r32}"
    _timeout_ms="${5:-$WG_PROBE_DEFAULT_TIMEOUT_MS}"

    _tool="$(wg_probe_pick_tool)"
    _link_type="$(wg_probe_pick_link_type)"
    _probe_seq=$(( ${_probe_seq:-0} + 1 ))
    _dev="${WG_PROBE_DEV_PREFIX}$$-${_probe_seq}"

    _keyfile="${TMPDIR:-/tmp}/${_dev}.key"
    _candidates_tmp="${TMPDIR:-/tmp}/${_dev}.cands"
    _peers_args="${TMPDIR:-/tmp}/${_dev}.peers"

    cat > "$_candidates_tmp"
    if [ ! -s "$_candidates_tmp" ]; then
        rm -f "$_candidates_tmp"
        return 0
    fi

    # Check whether candidates share duplicate public keys (e.g. Cloudflare WARP endpoints).
    # In WireGuard/AmneziaWG, a peer is identified strictly by public key; multiple endpoints
    # with the same public key cannot coexist as separate peers on the same interface without
    # overwriting each other. If duplicate public keys are detected, probe each candidate
    # individually using wg_probe_single.
    _unique_pks="$(awk -F '\t' '{print $3}' "$_candidates_tmp" | sort -u | wc -l | tr -d ' ')"
    _total_cands="$(wc -l < "$_candidates_tmp" | tr -d ' ')"
    if [ "$_unique_pks" -lt "$_total_cands" ]; then
        while IFS="$(printf '\t')" read -r _ip _port _pubkey _id _extra || [ -n "$_ip" ]; do
            [ -n "$_ip" ] && [ -n "$_pubkey" ] || continue
            _res="$(wg_probe_single "$_privkey" "${_ip}:${_port}" "$_pubkey" "$_variant" "$_timeout_ms" "$_noise" "$_entropy" || true)"
            _st="$(printf '%s\n' "$_res" | awk -F '\t' '{print $1}')"
            _rtt="$(printf '%s\n' "$_res" | awk -F '\t' '{print $2}')"
            [ -n "$_st" ] || _st="FAIL"
            [ -n "$_rtt" ] || _rtt="timeout"
            if [ -n "${_extra:-}" ]; then
                printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
                    "$_st" "$_rtt" "$_id" "$_ip" "$_port" "$_pubkey" "$_variant" "$_extra"
            else
                printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
                    "$_st" "$_rtt" "$_id" "$_ip" "$_port" "$_pubkey" "$_variant"
            fi
        done < "$_candidates_tmp"
        rm -f "$_candidates_tmp"
        return 0
    fi

    ip link del dev "$_dev" 2>/dev/null || true
    if ! ip link add dev "$_dev" type "$_link_type" 2>/dev/null; then
        rm -f "$_candidates_tmp"
        return 1
    fi

    printf '%s\n' "$_privkey" > "$_keyfile"
    "$_tool" set "$_dev" listen-port 0 private-key "$_keyfile" 2>/dev/null || {
        ip link del dev "$_dev" 2>/dev/null || true
        rm -f "$_keyfile" "$_candidates_tmp"
        return 1
    }
    rm -f "$_keyfile"

    if [ "$_link_type" = "amneziawg" ]; then
        wg_probe_apply_variant "$_tool" "$_dev" "$_variant" "$_noise" "$_entropy"
    fi

    # Build multi-peer configuration
    : > "$_peers_args"
    _idx=1
    while IFS="$(printf '\t')" read -r _ip _port _pubkey _id _extra || [ -n "$_ip" ]; do
        [ -n "$_ip" ] && [ -n "$_pubkey" ] || continue
        _dummy_ip="10.255.$(( _idx / 256 )).$(( _idx % 256 ))"
        printf '%s set %s peer %s endpoint %s:%s allowed-ips %s/32 persistent-keepalive 25\n' \
            "$_tool" "$_dev" "$_pubkey" "$_ip" "$_port" "$_dummy_ip" >> "$_peers_args"
        _idx=$((_idx + 1))
    done < "$_candidates_tmp"

    # Apply peers
    while IFS= read -r _set_cmd || [ -n "$_set_cmd" ]; do
        [ -n "$_set_cmd" ] || continue
        eval "$_set_cmd" 2>/dev/null || true
    done < "$_peers_args"
    rm -f "$_peers_args"

    ip addr add 10.255.255.254/16 dev "$_dev" 2>/dev/null || true
    ip link set "$_dev" up 2>/dev/null || true

    # Add temporary host routes via parent tunnel if WG_PROBE_VIA_DEV is active
    if wg_probe_is_via_active; then
        while IFS="$(printf '\t')" read -r _ip _port _pubkey _id _extra || [ -n "$_ip" ]; do
            [ -n "$_ip" ] || continue
            wg_probe_add_via_route "$_ip"
        done < "$_candidates_tmp"
    fi

    # Trigger handshakes in parallel
    _idx=1
    while IFS="$(printf '\t')" read -r _ip _port _pubkey _id _extra || [ -n "$_ip" ]; do
        [ -n "$_ip" ] && [ -n "$_pubkey" ] || continue
        _dummy_ip="10.255.$(( _idx / 256 )).$(( _idx % 256 ))"
        ping -c 1 -W 1 -I "$_dev" "$_dummy_ip" >/dev/null 2>&1 &
        _idx=$((_idx + 1))
    done < "$_candidates_tmp"

    # Poll for handshake responses (up to _timeout_ms)
    _poll_interval_ms=50
    _max_polls=$(( _timeout_ms / _poll_interval_ms ))
    [ "$_max_polls" -gt 0 ] || _max_polls=1
    _poll_count=0

    _resp_tmp="${TMPDIR:-/tmp}/${_dev}.resp"
    : > "$_resp_tmp"

    while [ "$_poll_count" -lt "$_max_polls" ]; do
        _hs_dump="$("$_tool" show "$_dev" latest-handshakes 2>/dev/null || true)"
        if [ -n "$_hs_dump" ]; then
            _any_new=0
            while IFS="$(printf '\t')" read -r _pk _ts || [ -n "$_pk" ]; do
                [ -n "$_pk" ] || continue
                case "$_ts" in
                    ''|0) continue ;;
                esac
                if ! grep -q "^$_pk" "$_resp_tmp" 2>/dev/null; then
                    _rtt=$(( (_poll_count + 1) * _poll_interval_ms ))
                    printf '%s\t%s\n' "$_pk" "$_rtt" >> "$_resp_tmp"
                    _any_new=1
                fi
            done <<EOF_HS
$_hs_dump
EOF_HS
            # If all peers have responded, stop polling early
            _resp_count="$(wc -l < "$_resp_tmp" | tr -d ' ')"
            _total_cands="$(wc -l < "$_candidates_tmp" | tr -d ' ')"
            if [ "$_resp_count" -ge "$_total_cands" ] && [ "$_total_cands" -gt 0 ]; then
                break
            fi
        fi

        sleep 0.05 2>/dev/null || usleep 50000 2>/dev/null || sleep 1
        _poll_count=$((_poll_count + 1))
    done

    # Remove temporary host routes
    if wg_probe_is_via_active; then
        while IFS="$(printf '\t')" read -r _ip _port _pubkey _id _extra || [ -n "$_ip" ]; do
            [ -n "$_ip" ] || continue
            wg_probe_del_via_route "$_ip"
        done < "$_candidates_tmp"
    fi

    # Output ranked results
    while IFS="$(printf '\t')" read -r _ip _port _pubkey _id _extra || [ -n "$_ip" ]; do
        [ -n "$_ip" ] && [ -n "$_pubkey" ] || continue
        _hit="$(grep "^$_pubkey" "$_resp_tmp" 2>/dev/null | head -n1 || true)"
        if [ -n "$_hit" ]; then
            _rtt="$(printf '%s\n' "$_hit" | awk -F '\t' '{print $2}')"
            _status="OK"
        else
            _rtt="timeout"
            _status="FAIL"
        fi
        if [ -n "${_extra:-}" ]; then
            printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
                "$_status" "$_rtt" "$_id" "$_ip" "$_port" "$_pubkey" "$_variant" "$_extra"
        else
            printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
                "$_status" "$_rtt" "$_id" "$_ip" "$_port" "$_pubkey" "$_variant"
        fi
    done < "$_candidates_tmp"

    ip link del dev "$_dev" 2>/dev/null || true
    rm -f "$_candidates_tmp" "$_resp_tmp"
}

# Single endpoint WireGuard / AmneziaWG Handshake probe
# Parameters:
#   $1 - client_privkey
#   $2 - endpoint (IP:PORT)
#   $3 - peer_public_key
#   $4 - variant (1, 2, 3)
#   $5 - timeout_ms (default 1200)
#   $6 - noise_enabled (0 or 1)
#   $7 - entropy (off, r32, ...)
# Output on stdout:
#   STATUS (OK|FAIL) <TAB> RTT_MS
# Return code 0 on OK, 1 on FAIL.
wg_probe_single() {
    _privkey="$1"
    _endpoint="$2"
    _pubkey="$3"
    _variant="${4:-1}"
    _timeout_ms="${5:-1200}"
    _noise="${6:-0}"
    _entropy="${7:-off}"

    _tool="$(wg_probe_pick_tool)"
    _link_type="$(wg_probe_pick_link_type)"
    _probe_seq=$(( ${_probe_seq:-0} + 1 ))
    _dev="${WG_PROBE_DEV_PREFIX}$$-${_probe_seq}"
    _keyfile="${TMPDIR:-/tmp}/${_dev}.key"

    ip link del dev "$_dev" 2>/dev/null || true
    if ! ip link add dev "$_dev" type "$_link_type" 2>/dev/null; then
        printf 'FAIL\ttimeout\n'
        return 1
    fi

    printf '%s\n' "$_privkey" > "$_keyfile"
    "$_tool" set "$_dev" listen-port 0 private-key "$_keyfile" 2>/dev/null || {
        ip link del dev "$_dev" 2>/dev/null || true
        rm -f "$_keyfile"
        printf 'FAIL\ttimeout\n'
        return 1
    }
    rm -f "$_keyfile"

    if [ "$_link_type" = "amneziawg" ]; then
        wg_probe_apply_variant "$_tool" "$_dev" "$_variant" "$_noise" "$_entropy"
    fi

    "$_tool" set "$_dev" peer "$_pubkey" endpoint "$_endpoint" allowed-ips 0.0.0.0/0 persistent-keepalive 25 2>/dev/null || {
        ip link del dev "$_dev" 2>/dev/null || true
        printf 'FAIL\ttimeout\n'
        return 1
    }

    ip addr add 10.255.255.254/24 dev "$_dev" 2>/dev/null || true
    ip link set dev "$_dev" up 2>/dev/null || true

    _ep_host="${_endpoint%%:*}"
    _added_via_route=0
    if wg_probe_is_via_active && [ -n "$_ep_host" ]; then
        wg_probe_add_via_route "$_ep_host"
        _added_via_route=1
    fi

    ping -c 1 -W 1 -I "$_dev" 10.255.255.1 >/dev/null 2>&1 &

    _poll_interval_ms=50
    _max_polls=$(( _timeout_ms / _poll_interval_ms ))
    [ "$_max_polls" -gt 0 ] || _max_polls=10
    _poll_count=0
    _rtt="timeout"
    _status="FAIL"

    while [ "$_poll_count" -lt "$_max_polls" ]; do
        _hs="$("$_tool" show "$_dev" latest-handshakes 2>/dev/null | awk '{print $2}' || true)"
        if [ -n "$_hs" ] && [ "$_hs" != "0" ]; then
            _rtt=$(( (_poll_count + 1) * _poll_interval_ms ))
            _status="OK"
            break
        fi
        sleep 0.05 2>/dev/null || usleep 50000 2>/dev/null || sleep 1
        _poll_count=$((_poll_count + 1))
    done

    if [ "$_added_via_route" = "1" ]; then
        wg_probe_del_via_route "$_ep_host"
    fi

    ip link del dev "$_dev" 2>/dev/null || true
    printf '%s\t%s\n' "$_status" "$_rtt"
    [ "$_status" = "OK" ]
}

# Auto-select the best candidate and AWG variant.
# Parameters:
#   $1 - client_privkey (or empty for dummy/ephemeral)
#   $2 - variant_request ("auto", "1", "2", "3")
#   $3 - candidates_file (TSV: IP, PORT, PUBKEY, ID, LOAD...)
#   $4 - batch_size (default 3-5)
#   $5 - timeout_ms (default 800)
#
# Emits winning candidate line on stdout:
#   WINNER_LINE: <full original TSV candidate line with WINNER_VARIANT as penultimate column>
# Exit code 0 on success, 1 on complete failure.
wg_probe_auto_select() {
    _privkey="${1:-$WG_PROBE_DUMMY_PRIVKEY}"
    _req_variant="${2:-auto}"
    _cands_file="$3"
    _batch_size="${4:-$WG_PROBE_DEFAULT_BATCH_SIZE}"
    _timeout_ms="${5:-$WG_PROBE_DEFAULT_TIMEOUT_MS}"

    [ -s "$_cands_file" ] || return 1

    if ! wg_probe_is_supported; then
        # Environment does not support kernel wireguard probe (e.g. host-only unprivileged WSL build).
        # Return candidate #1 with default variant.
        _first="$(head -n1 "$_cands_file")"
        _var="${_req_variant}"
        case "$_var" in auto|'') _var="1" ;; esac
        printf '%s\t%s\n' "$_first" "$_var"
        return 0
    fi

    _variants_to_test=""
    case "$_req_variant" in
        auto|'') _variants_to_test="1 2 3" ;;
        1|2|3) _variants_to_test="$_req_variant" ;;
        *) _variants_to_test="1" ;;
    esac

    _total_lines="$(wc -l < "$_cands_file" | tr -d ' ')"
    _cursor=1

    for _v in $_variants_to_test; do
        _start_line="$_cursor"
        _end_line=$(( _start_line + _batch_size - 1 ))
        if [ "$_end_line" -gt "$_total_lines" ]; then
            _end_line="$_total_lines"
        fi

        _chunk="$(sed -n "${_start_line},${_end_line}p" "$_cands_file" 2>/dev/null || true)"
        if [ -z "$_chunk" ]; then
            # If candidates exhausted, wrap around to line 1
            _chunk="$(head -n "$_batch_size" "$_cands_file")"
        fi

        _noise="${AWG_NOISE_ENABLED:-0}"
        _entropy="${AWG_I1_ENTROPY:-r32}"
        _probe_out="$(printf '%s\n' "$_chunk" | wg_probe_batch "$_privkey" "$_v" "$_noise" "$_entropy" "$_timeout_ms")"

        # Check if any candidate succeeded (STATUS == OK)
        _ok_line="$(printf '%s\n' "$_probe_out" | awk -F '\t' '$1 == "OK" { print $0; exit }')"
        if [ -n "$_ok_line" ]; then
            _id="$(printf '%s\n' "$_ok_line" | awk -F '\t' '{print $3}')"
            _rtt="$(printf '%s\n' "$_ok_line" | awk -F '\t' '{print $2}')"
            _orig="$(grep -F "$_id" "$_cands_file" | head -n1 || true)"
            if [ -n "$_orig" ]; then
                # Append selected variant and RTT
                printf '%s\t%s\t%s\n' "$_orig" "$_v" "$_rtt"
                return 0
            fi
        fi

        _cursor=$(( _end_line + 1 ))
        if [ "$_cursor" -gt "$_total_lines" ]; then
            _cursor=1
        fi
    done

    # If all probed variants/batches failed, fallback to candidate #1 with variant 1
    _fallback="$(head -n1 "$_cands_file")"
    printf '%s\t1\ttimeout\n' "$_fallback"
    return 0
}

# Auto-tuning benchmark for AWG parameters (variant, I1 entropy, noise).
# Tests candidate endpoints across a combinatorial matrix:
# Phase 1 (No noise, Jc=0):
#   Levels: entropy=off -> r32 -> r64 -> t (variants 1, 2, 3 in parallel per batch)
# Phase 2 (With noise, Jc=4, engaged if no-noise yields no handshake):
#   Levels: entropy=off -> r32 -> r64 -> t (variants 1, 2, 3 in parallel per batch)
# Stops at the first working combination with the best RTT.
# Returns on stdout:
# TUNE_RESULT <TAB> STATUS <TAB> RTT_MS <TAB> VARIANT <TAB> ENTROPY <TAB> NOISE <TAB> ENDPOINT <TAB> EXTRA...
wg_probe_tune() {
    _privkey="${1:-$WG_PROBE_DUMMY_PRIVKEY}"
    _cands_file="$2"
    _timeout_ms="${3:-$WG_PROBE_DEFAULT_TIMEOUT_MS}"

    [ -f "$_cands_file" ] && [ -s "$_cands_file" ] || {
        echo "[-] wg_probe_tune: пустой файл кандидатов: $_cands_file" >&2
        return 1
    }

    _top_cands="${TMPDIR:-/tmp}/wg-tune-cands.$$"
    head -n 5 "$_cands_file" > "$_top_cands"
    _num_cands="$(wc -l < "$_top_cands" | tr -d ' ')"

    info_err "=== Запуск автоподбора оптимальных параметров AWG ==="
    info_err "Кандидатов для параллельного тестирования: $_num_cands"

    if ! wg_probe_is_supported; then
        info_err "[-] AmneziaWG/WireGuard probe не поддерживается ядром на этом хосте. Выставляются рекомендованные параметры."
        _first_cand="$(head -n 1 "$_top_cands")"
        _ep="$(printf '%s\n' "$_first_cand" | awk -F '\t' '{print $1 ":" $2}')"
        rm -f "$_top_cands"
        printf 'TUNE_RESULT\tFAIL\t999\t1\tr32\t1\t%s\n' "$_ep"
        return 0
    fi

    _matrix_step=0
    _total_matrix_steps=8
    _winner_found=0

    _best_var=""
    _best_var_rtt=99999
    _best_cand_line=""
    _best_noise="0"
    _best_entropy="off"

    # Phase 1: noise=0 (r32, t, r64, off)
    # Phase 2: noise=1 (r32, t, r64, off) engaged if Phase 1 had no handshake responses
    for _noise in 0 1; do
        if [ "$_noise" = "1" ] && [ "$_winner_found" = "0" ]; then
            info_err "[!] Без шума handshake не получен (блокировка пакетов провайдером). Подключаем шум AWG (Jc=4)..."
        fi

        for _ent in r32 t r64 off; do
            [ "$_winner_found" = "0" ] || break

            _matrix_step=$((_matrix_step + 1))
            _ent_label="$_ent"
            case "$_ent" in
                r32) _ent_label="энтропия <r 32>" ;;
                t)   _ent_label="энтропия <t>" ;;
                r64) _ent_label="энтропия <r 64>" ;;
                off) _ent_label="без энтропии (off)" ;;
            esac

            _noise_label="$([ "$_noise" = "1" ] && echo 'С шумом (Jc=4)' || echo 'Без шума')"
            info_err "[$_matrix_step/$_total_matrix_steps] $_noise_label | I1: $_ent_label..."

            _group_best_var=""
            _group_best_rtt=99999
            _group_best_cand=""

            for _v in 1 3 2; do
                _batch_res="$(wg_probe_batch "$_privkey" "$_v" "$_noise" "$_ent" "$_timeout_ms" < "$_top_cands" || true)"
                _ok_res="$(printf '%s\n' "$_batch_res" | awk -F '\t' '$1 == "OK"' | sort -t "$(printf '\t')" -k2,2n | head -n 1 || true)"
                if [ -n "$_ok_res" ]; then
                    _rtt="$(printf '%s\n' "$_ok_res" | awk -F '\t' '{print $2}')"
                    _ep="$(printf '%s\n' "$_ok_res" | awk -F '\t' '{print $4 ":" $5}')"
                    info_err "  • Вариант $_v: OK (${_rtt} мс) — endpoint: $_ep"
                    _group_best_var="$_v"
                    _group_best_rtt="$_rtt"
                    _group_best_cand="$_ok_res"
                    break
                else
                    info_err "  • Вариант $_v: нет ответа (timeout)"
                    usleep 100000 2>/dev/null || sleep 0.1 2>/dev/null || true
                fi
            done

            if [ -n "$_group_best_var" ]; then
                _best_var="$_group_best_var"
                _best_var_rtt="$_group_best_rtt"
                _best_cand_line="$_group_best_cand"
                _best_noise="$_noise"
                _best_entropy="$_ent"
                _winner_found=1
                break
            fi
        done
    done

    if [ "$_winner_found" = "0" ]; then
        info_err "[-] Ни один вариант не ответил на handshake. Будут выставлены рекомендованные настройки (AWG 2.0 вар. 1, r32, с шумом)."
        _best_var="1"
        _best_var_rtt=999
        _best_entropy="r32"
        _best_noise="1"
        _first_cand="$(head -n 1 "$_top_cands")"
        _ep="$(printf '%s\n' "$_first_cand" | awk -F '\t' '{print $1 ":" $2}')"
        rm -f "$_top_cands"
        printf 'TUNE_RESULT\tFAIL\t999\t1\tr32\t1\t%s\n' "$_ep"
        return 0
    fi

    _ip="$(printf '%s\n' "$_best_cand_line" | awk -F '\t' '{print $4}')"
    _port="$(printf '%s\n' "$_best_cand_line" | awk -F '\t' '{print $5}')"
    _pk="$(printf '%s\n' "$_best_cand_line" | awk -F '\t' '{print $6}')"
    _id="$(printf '%s\n' "$_best_cand_line" | awk -F '\t' '{print $3}')"
    _extra="$(printf '%s\n' "$_best_cand_line" | awk -F '\t' '{
        line = $8;
        for (i=9; i<=NF; i++) line = line "\t" $i;
        print line;
    }')"

    info_err "=================================================="
    info_err "[✓] Итог автоподбора: AWG 2.0 вар. $_best_var | Энтропия: $_best_entropy | Шум: $([ "$_best_noise" = "1" ] && echo 'Вкл (Jc=4)' || echo 'Выкл') | ${_best_var_rtt} мс"
    info_err "=================================================="

    rm -f "$_top_cands"
    printf 'TUNE_RESULT\tOK\t%s\t%s\t%s\t%s\t%s:%s\t%s\t%s\n' \
        "$_best_var_rtt" "$_best_var" "$_best_entropy" "$_best_noise" "$_ip" "$_port" "$_pk" "$_extra"
    return 0
}
