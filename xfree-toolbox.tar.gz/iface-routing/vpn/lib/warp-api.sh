#!/bin/sh
# shellcheck shell=sh

if [ -z "${VPN_JSON_LIB:-}" ]; then
    if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/iface-routing/vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="$ROOT_DIR/iface-routing/vpn/lib/vpn-json.sh"
    elif [ -f "./iface-routing/vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="./iface-routing/vpn/lib/vpn-json.sh"
    elif [ -f "./vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="./vpn/lib/vpn-json.sh"
    fi
fi
[ -n "${VPN_JSON_LIB:-}" ] && [ -f "$VPN_JSON_LIB" ] && . "$VPN_JSON_LIB"

WARP_API_BASE="${WARP_API_BASE:-https://api.cloudflareclient.com/v0i1909051800}"
WARP_USER_AGENT="${WARP_USER_AGENT:-okhttp/3.12.1}"
WARP_CURL_CONNECT_TIMEOUT="${WARP_CURL_CONNECT_TIMEOUT:-15}"
WARP_CURL_MAX_TIME="${WARP_CURL_MAX_TIME:-30}"
# Порты: telegra.ph/Gajd-kak-nastroit-obhod-blokirovok-Phone-ver-11-15 и warp-generator.github.io/script.js
WARP_PORTS="${WARP_PORTS:-500 854 859 864 878 880 890 891 894 903 908 928 934 939 942 943 945 946 955 968 987 988 1002 1010 1014 1018 1070 1074 1180 1387 1701 1843 2371 2408 2506 3138 3476 3581 3854 4177 4198 4233 4500 5279 5956 7103 7152 7156 7281 7559 8319 8742 8854 8886}"

# Сервер xfree — узкий пул 162.159.195.1–10 (toolbox).
# Сервер def — префиксы CF как warp-generation.github.io (без tribukvy).
# FL|NL|PL|DE|LV|RU — хосты tribukvy.ltd (на сайте: нужна рег. в боте llimonix).
# lteFL|ltePL|lteDE — tel.*.tribukvy.ltd (без бота; как на сайте, с фильтром портов).

# cloudflare: префиксы для случайного host (последний октет — см. WARP_CF_DEF_OCTET_*).
WARP_CF_DEF_PREFIXES="${WARP_CF_DEF_PREFIXES:-engage.cloudflareclient.com 162.159.192. 162.159.193. 162.159.195. 8.6.112. 8.34.70. 8.34.146. 8.35.211. 8.39.125. 8.39.204. 8.39.214. 8.47.69. 188.114.96. 188.114.97. 188.114.98. 188.114.99.}"
WARP_CF_DEF_OCTET_MIN="${WARP_CF_DEF_OCTET_MIN:-1}"
WARP_CF_DEF_OCTET_MAX="${WARP_CF_DEF_OCTET_MAX:-100}"

# xfree: расширенный пул проверенных префиксов Cloudflare (включая не-RU подсети ARN/HEL/FRA)
WARP_XFREE_DEF_PREFIXES="${WARP_XFREE_DEF_PREFIXES:-162.159.192. 162.159.195. 188.114.96. 188.114.97. 188.114.98. 188.114.99. 8.6.112. 8.39.125. 8.47.69. 8.34.70.}"
WARP_XFREE_DEF_HOST_OCTET_MIN="${WARP_XFREE_DEF_HOST_OCTET_MIN:-1}"
WARP_XFREE_DEF_HOST_OCTET_MAX="${WARP_XFREE_DEF_HOST_OCTET_MAX:-100}"

warp_json_get() {
    vpn_json_get_string "$2" "$1"
}

warp_entropy_mod_upper() {
    upper="$1"
    [ "${upper:-0}" -gt 0 ] || return 1

    rnd=""
    if [ -r /dev/urandom ]; then
        if command -v hexdump >/dev/null 2>&1; then
            rnd="$(hexdump -n 4 -v -e '1/4 "%u\n"' /dev/urandom 2>/dev/null | head -n1 | tr -d ' \t\r')"
        fi
        if [ -z "$rnd" ] && command -v od >/dev/null 2>&1; then
            rnd="$(od -An -N4 -tu4 /dev/urandom 2>/dev/null | head -n1 | tr -dc '0-9')"
        fi
        if [ -z "$rnd" ] && command -v od >/dev/null 2>&1; then
            rnd="$(od -An -N2 -tu2 /dev/urandom 2>/dev/null | tr -dc '0-9')"
        fi
    fi

    case "$rnd" in
        '' | *[!0-9]*)
            rnd=$(( ($$ ^ $(date +%s)) % upper ))
            ;;
    esac

    rnd=$((rnd % upper))
    printf '%u\n' "$rnd"
}

warp_rand_int_between() {
    lower="$1"
    upper="$2"
    span=$((upper - lower + 1))
    [ "$span" -gt 0 ] || die "warp_rand_int_between: нижний предел выше верхнего"
    rnd_mod="$(warp_entropy_mod_upper "$span")"
    rnd_mod=$((rnd_mod + lower))
    printf '%u\n' "$rnd_mod"
}

warp_rand_from_list() {
    # shellcheck disable=SC2086
    set -- $1
    count=$#
    [ "$count" -gt 0 ] || die "Пустой список"

    rnd_mod="$(warp_entropy_mod_upper "$count")"
    idx=$((rnd_mod + 1))

    n=1
    for item in "$@"; do
        if [ "$n" -eq "$idx" ]; then
            printf '%s\n' "$item"
            return 0
        fi
        n=$((n + 1))
    done

    die "Не удалось выбрать случайный элемент"
}

warp_pick_keygen_tool() {
    if command -v awg >/dev/null 2>&1; then
        printf 'awg\n'
        return 0
    fi
    if command -v wg >/dev/null 2>&1; then
        printf 'wg\n'
        return 0
    fi
    die "Не найден ни awg, ни wg"
}

warp_generate_keys() {
    tool="$(warp_pick_keygen_tool)"
    WARP_GEN_PRIV="$("$tool" genkey)"
    [ -n "$WARP_GEN_PRIV" ] || die "Не удалось сгенерировать private key"
    WARP_GEN_PUB="$(printf '%s' "$WARP_GEN_PRIV" | "$tool" pubkey)"
    [ -n "$WARP_GEN_PUB" ] || die "Не удалось сгенерировать public key"
}

warp_normalize_server() {
    case "$1" in
        xfree|def|FL|NL|PL|DE|LV|RU|lteFL|ltePL|lteDE)
            printf '%s\n' "$1"
            ;;
        LTEFL) printf 'lteFL\n' ;;
        LTEPL) printf 'ltePL\n' ;;
        LTEDE) printf 'lteDE\n' ;;
        PL1|PL2)
            printf 'PL\n'
            ;;
        EE)
            die "Сервер EE снят; используйте LV или def (как на warp-generation.github.io)"
            ;;
        US)
            die "Сервер US снят; используйте: xfree, def, FL, NL, PL, DE, LV, RU, lteFL, ltePL, lteDE"
            ;;
        *)
            die "Неизвестный сервер: $1"
            ;;
    esac
}

# Порты как на warp-generation.github.io: ltePL без 988, lteFL без 1010.
warp_ports_for_server() {
    server="$(warp_normalize_server "$1")"
    case "$server" in
        ltePL)
            printf '%s\n' "$WARP_PORTS" | tr ' ' '\n' | grep -vx '988' | tr '\n' ' ' | sed 's/[[:space:]]*$//'
            ;;
        lteFL)
            printf '%s\n' "$WARP_PORTS" | tr ' ' '\n' | grep -vx '1010' | tr '\n' ' ' | sed 's/[[:space:]]*$//'
            ;;
        *)
            printf '%s\n' "$WARP_PORTS"
            ;;
    esac
}

warp_server_host() {
    case "$1" in
        PL)  printf 'pl.tribukvy.ltd\n' ;;
        DE)  printf 'de.tribukvy.ltd\n' ;;
        RU)  printf 'ru0.tribukvy.ltd\n' ;;
        NL)  printf 'nl.tribukvy.ltd\n' ;;
        FL)  printf 'fi.tribukvy.ltd\n' ;;
        LV)  printf 'lv.tribukvy.ltd\n' ;;
        ltePL) printf 'tel.pl.tribukvy.ltd\n' ;;
        lteFL) printf 'tel.fi.tribukvy.ltd\n' ;;
        lteDE) printf 'tel.de.tribukvy.ltd\n' ;;
        xfree|def)
            die "warp_server_host: для $1 используйте warp_build_endpoint"
            ;;
        *)
            die "Неизвестный сервер: $1"
            ;;
    esac
}

warp_def_endpoint_policy() {
    case "$1" in
        xfree) printf 'xfree\n' ;;
        def)   printf 'cloudflare\n' ;;
        *)     printf '%s\n' "host:$1" ;;
    esac
}

warp_build_def_endpoint_xfree() {
    port="$1"
    prefix="${WARP_FORCE_PREFIX:-}"
    [ -n "$prefix" ] || prefix="$(warp_rand_from_list "$WARP_XFREE_DEF_PREFIXES")"
    n="$(warp_rand_int_between "$WARP_XFREE_DEF_HOST_OCTET_MIN" "$WARP_XFREE_DEF_HOST_OCTET_MAX")"
    printf '%s%s:%s\n' "$prefix" "$n" "$port"
}

warp_prefixes_for_server() {
    _srv="$(warp_normalize_server "$1")"
    case "$_srv" in
        xfree)
            printf '%s\n' "$WARP_XFREE_DEF_PREFIXES"
            ;;
        def)
            printf '%s\n' "$WARP_CF_DEF_PREFIXES" | tr ' ' '\n' | grep -v 'engage' | tr '\n' ' '
            ;;
        *)
            warp_server_host "$_srv"
            ;;
    esac
}

warp_build_def_endpoint_cloudflare() {
    port="$1"
    prefix="${WARP_FORCE_PREFIX:-}"
    [ -n "$prefix" ] || prefix="$(warp_rand_from_list "$WARP_CF_DEF_PREFIXES")"

    if [ "$prefix" = "engage.cloudflareclient.com" ]; then
        printf '%s:%s\n' "$prefix" "$port"
        return 0
    fi

    n="$(warp_rand_int_between "$WARP_CF_DEF_OCTET_MIN" "$WARP_CF_DEF_OCTET_MAX")"
    printf '%s%s:%s\n' "$prefix" "$n" "$port"
}

warp_build_endpoint() {
    server="$(warp_normalize_server "$1")"
    ports="$(warp_ports_for_server "$server")"
    [ -n "$ports" ] || die "WARP: пустой список портов для $server"
    port="$(warp_rand_from_list "$ports")"

    case "$server" in
        xfree)
            warp_build_def_endpoint_xfree "$port"
            ;;
        def)
            warp_build_def_endpoint_cloudflare "$port"
            ;;
        *)
            host="$(warp_server_host "$server")"
            printf '%s:%s\n' "$host" "$port"
            ;;
    esac
}

warp_register() {
    pubkey="$1"
    payload="$(printf '{"key":"%s","install_id":"","fcm_token":"","tos":"%s","type":"ios","locale":"en_US"}' \
        "$pubkey" "$(date -u +"%Y-%m-%dT%H:%M:%SZ")")"

    curl -fsS -X POST "${WARP_API_BASE}/reg" \
        --connect-timeout "$WARP_CURL_CONNECT_TIMEOUT" \
        --max-time "$WARP_CURL_MAX_TIME" \
        -H "Content-Type: application/json" \
        -H "User-Agent: ${WARP_USER_AGENT}" \
        --data "$payload"
}

warp_enable() {
    client_id="$1"
    token="$2"

    curl -fsS -X PATCH "${WARP_API_BASE}/reg/${client_id}" \
        --connect-timeout "$WARP_CURL_CONNECT_TIMEOUT" \
        --max-time "$WARP_CURL_MAX_TIME" \
        -H "Content-Type: application/json" \
        -H "User-Agent: ${WARP_USER_AGENT}" \
        -H "Authorization: Bearer ${token}" \
        --data '{"warp_enabled":true}'
}

# Колония точки входа: HTTPS /cdn-cgi/trace с --resolve на IP endpoint.
# colo= — узел Cloudflare (DME = Москва). loc= — гео клиента, для фильтра не используется.
WARP_TRACE_HOST="${WARP_TRACE_HOST:-www.cloudflare.com}"
WARP_TRACE_UA="${WARP_TRACE_UA:-Mozilla/5.0}"
WARP_PROBE_TOP_N="${WARP_PROBE_TOP_N:-5}"
WARP_PROBE_ATTEMPT_MAX="${WARP_PROBE_ATTEMPT_MAX:-50}"
WARP_PROBE_TIMEOUT_SEC="${WARP_PROBE_TIMEOUT_SEC:-4}"
WARP_RU_COLOS="${WARP_RU_COLOS:-DME LED KJA SVX}"
WARP_EXCLUDE_RU="${WARP_EXCLUDE_RU:-1}"

warp_is_ipv4() {
    case "$1" in
        *[!0-9.]*) return 1 ;;
        *.*.*.*) return 0 ;;
        *) return 1 ;;
    esac
}

warp_seconds_to_ms() {
    LC_ALL=C awk -v t="$1" 'BEGIN { t += 0; if (t < 0) t = 0; printf "%d", t * 1000 }'
}

warp_colo_is_ru() {
    colo="$(printf '%s' "$1" | tr '[:lower:]' '[:upper:]')"
    [ -n "$colo" ] || return 1
    case " ${WARP_RU_COLOS} " in
        *" ${colo} "*) return 0 ;;
    esac
    return 1
}

# Успех: WARP_PROBE_MS, WARP_PROBE_COLO, WARP_PROBE_LOC. Пустой colo — неуспех.
warp_probe_trace() {
    host="$1"
    WARP_PROBE_MS=""
    WARP_PROBE_COLO=""
    WARP_PROBE_LOC=""
    warp_is_ipv4 "$host" || return 1

    out="${TMPDIR:-/tmp}/warp-trace.$$"
    secs=""
    if ! secs="$(curl -fsS \
        --connect-timeout "${WARP_PROBE_TIMEOUT_SEC}" \
        --max-time "${WARP_PROBE_TIMEOUT_SEC}" \
        -A "${WARP_TRACE_UA}" \
        --resolve "${WARP_TRACE_HOST}:443:${host}" \
        -o "$out" \
        -w '%{time_connect}' \
        "https://${WARP_TRACE_HOST}/cdn-cgi/trace" 2>/dev/null)"; then
        rm -f "$out"
        return 1
    fi

    colo="$(sed -n 's/^colo=//p' "$out" | head -n1 | tr -d '\r')"
    loc="$(sed -n 's/^loc=//p' "$out" | head -n1 | tr -d '\r')"
    rm -f "$out"
    [ -n "$colo" ] || return 1

    WARP_PROBE_COLO="$(printf '%s' "$colo" | tr '[:lower:]' '[:upper:]')"
    WARP_PROBE_LOC="$(printf '%s' "$loc" | tr '[:lower:]' '[:upper:]')"
    WARP_PROBE_MS="$(warp_seconds_to_ms "$secs")"
    [ -n "$WARP_PROBE_MS" ] || return 1
    return 0
}

warp_subnet_of_ip() {
    printf '%s\n' "$1" | sed 's/\.[0-9]*$//'
}

# Пишет ENDPOINT и WARP_SELECTED_COLO / _LOC / _MS.
# Пул def|xfree: до WARP_PROBE_TOP_N разных IP из разных диапазонов, берётся минимальный time_connect.
# Именованный хост (страна): один endpoint, без trace.
warp_select_endpoint_best() {
    probe_server="$(warp_normalize_server "$1")"
    WARP_SELECTED_COLO=""
    WARP_SELECTED_LOC=""
    WARP_SELECTED_MS=""

    if [ "$probe_server" = "RU" ] && [ "$WARP_EXCLUDE_RU" = "1" ]; then
        die "Сервер RU исключён фильтром колоний (DME LED KJA SVX). Выключите фильтр или выберите другой сервер."
    fi

    case "$(warp_def_endpoint_policy "$probe_server")" in
        host:*)
            info_err "WARP probe: $probe_server — именованный хост, скан колоний только для def/xfree"
            ENDPOINT="$(warp_build_endpoint "$probe_server")"
            return 0
            ;;
    esac

    top_n="$WARP_PROBE_TOP_N"
    case "$top_n" in
        ''|*[!0-9]*) top_n=5 ;;
    esac
    [ "$top_n" -gt 0 ] 2>/dev/null || top_n=5

    attempt_max="$WARP_PROBE_ATTEMPT_MAX"
    case "$attempt_max" in
        ''|*[!0-9]*) attempt_max=50 ;;
    esac
    [ "$attempt_max" -ge "$top_n" ] 2>/dev/null || attempt_max="$top_n"

    board="${TMPDIR:-/tmp}/warp-probe-board.$$"
    board_subnets="${TMPDIR:-/tmp}/warp-probe-subnets.$$"
    seen="${TMPDIR:-/tmp}/warp-probe-seen.$$"
    : > "$board"
    : > "$board_subnets"
    : > "$seen"
    attempts=0
    ru_skips=0
    consecutive_empty=0

    prefixes_raw="$(warp_prefixes_for_server "$probe_server")"
    # shellcheck disable=SC2086
    set -- $prefixes_raw
    prefix_count=$#
    prefix_idx=0
    if [ "$prefix_count" -gt 0 ]; then
        prefix_idx="$(warp_rand_int_between 0 $((prefix_count - 1)))"
    fi

    info_err "WARP probe: ищу до $top_n не-RU точек (макс. $attempt_max серверов, перебор разных диапазонов)"
    while [ "$attempts" -lt "$attempt_max" ]; do
        board_n="$(wc -l < "$board" | tr -d ' \t')"
        [ "$board_n" -ge "$top_n" ] && break

        # Циклический перебор диапазонов со случайным смещением для максимальной энтропии
        WARP_FORCE_PREFIX=""
        if [ "$prefix_count" -gt 0 ]; then
            prefix_idx=$(( (prefix_idx + 1) % prefix_count ))
            p_num=$((prefix_idx + 1))
            WARP_FORCE_PREFIX="$(eval "printf '%s' \"\${$p_num}\"")"
        fi
        export WARP_FORCE_PREFIX

        ep=""
        host=""
        gen_tries=0
        while [ "$gen_tries" -lt 15 ]; do
            gen_tries=$((gen_tries + 1))
            cand_ep="$(warp_build_endpoint "$probe_server")"
            cand_host="${cand_ep%%:*}"
            case "$cand_host" in
                engage.cloudflareclient.com) continue ;;
            esac
            warp_is_ipv4 "$cand_host" || continue
            if ! grep -qxF "$cand_host" "$seen" 2>/dev/null; then
                ep="$cand_ep"
                host="$cand_host"
                break
            fi
        done
        unset WARP_FORCE_PREFIX

        if [ -z "$host" ]; then
            consecutive_empty=$((consecutive_empty + 1))
            limit_empty=$((prefix_count + 3))
            [ "$limit_empty" -ge 10 ] 2>/dev/null || limit_empty=10
            if [ "$consecutive_empty" -ge "$limit_empty" ]; then
                info_err "WARP probe: пул доступных уникальных IP исчерпан (проверено $attempts)"
                break
            fi
            continue
        fi
        consecutive_empty=0
        printf '%s\n' "$host" >> "$seen"
        attempts=$((attempts + 1))

        if ! warp_probe_trace "$host"; then
            info_err "WARP probe [$attempts/$attempt_max]: FAIL $ep (нет ответа /cdn-cgi/trace)"
            continue
        fi

        if [ "$WARP_EXCLUDE_RU" = "1" ] && warp_colo_is_ru "$WARP_PROBE_COLO"; then
            ru_skips=$((ru_skips + 1))
            info_err "WARP probe [$attempts/$attempt_max]: SKIP $ep colo=$WARP_PROBE_COLO (RU)"
            continue
        fi

        sub="$(warp_subnet_of_ip "$host")"
        if grep -qxF "$sub" "$board_subnets" 2>/dev/null; then
            # Диапазон уже представлен на доске: обновляем только если пинг лучше
            prev_ms="$(awk -F '\t' -v s="$sub" '$5 == s { print $1 }' "$board" | head -n1)"
            if [ -n "$prev_ms" ] && [ "$WARP_PROBE_MS" -lt "$prev_ms" ] 2>/dev/null; then
                info_err "WARP probe [$attempts/$attempt_max]: UPDATE $ep colo=$WARP_PROBE_COLO ${WARP_PROBE_MS}ms (диапазон $sub быстрее чем ${prev_ms}ms)"
                grep -vxF -e "$sub" "$board_subnets" > "${board_subnets}.tmp" 2>/dev/null || true
                mv -f "${board_subnets}.tmp" "$board_subnets"
                printf '%s\n' "$sub" >> "$board_subnets"
                awk -F '\t' -v s="$sub" '$5 != s' "$board" > "${board}.tmp"
                printf '%s\t%s\t%s\t%s\t%s\n' "$WARP_PROBE_MS" "$ep" "$WARP_PROBE_COLO" "$WARP_PROBE_LOC" "$sub" >> "${board}.tmp"
                mv -f "${board}.tmp" "$board"
            else
                info_err "WARP probe [$attempts/$attempt_max]: SKIP $ep colo=$WARP_PROBE_COLO ${WARP_PROBE_MS}ms (диапазон $sub уже представлен)"
            fi
            continue
        fi

        printf '%s\n' "$sub" >> "$board_subnets"
        printf '%s\t%s\t%s\t%s\t%s\n' "$WARP_PROBE_MS" "$ep" "$WARP_PROBE_COLO" "$WARP_PROBE_LOC" "$sub" >> "$board"
        info_err "WARP probe [$attempts/$attempt_max]: OK $ep colo=$WARP_PROBE_COLO ${WARP_PROBE_MS}ms (новый диапазон $sub)"
    done

    if [ ! -s "$board" ]; then
        rm -f "$board" "$board_subnets" "$seen"
        if [ "$ru_skips" -gt 0 ]; then
            die "WARP probe: перебрано $attempts точек, все ответившие в колониях RU ($WARP_RU_COLOS). Увеличьте лимит перебора или выберите другой сервер."
        fi
        die "WARP probe: ни одна точка не ответила на /cdn-cgi/trace за $attempts попыток"
    fi

    best_line="$(awk -F '\t' 'NR == 1 || $1 + 0 < min { min = $1 + 0; line = $0 } END { print line }' "$board")"
    board_total="$(wc -l < "$board" | tr -d ' \t')"
    rm -f "$board" "$board_subnets" "$seen"
    [ -n "$best_line" ] || die "WARP probe: пустой результат"

    ENDPOINT="$(printf '%s\n' "$best_line" | awk -F '\t' '{print $2}')"
    WARP_SELECTED_MS="$(printf '%s\n' "$best_line" | awk -F '\t' '{print $1}')"
    WARP_SELECTED_COLO="$(printf '%s\n' "$best_line" | awk -F '\t' '{print $3}')"
    WARP_SELECTED_LOC="$(printf '%s\n' "$best_line" | awk -F '\t' '{print $4}')"
    [ -n "$ENDPOINT" ] || die "WARP probe: не удалось выбрать endpoint"
    info_err "WARP probe: выбран лучший из $board_total подходящих диапазонов: $ENDPOINT colo=$WARP_SELECTED_COLO ${WARP_SELECTED_MS}ms"
}
