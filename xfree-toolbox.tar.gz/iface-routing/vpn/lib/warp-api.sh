#!/bin/sh
# shellcheck shell=sh

if [ -z "${VPN_JSON_LIB:-}" ]; then
    if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/iface-routing/vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="$ROOT_DIR/iface-routing/vpn/lib/vpn-json.sh"
    elif [ -f "./iface-routing/vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="./iface-routing/vpn/lib/vpn-json.sh"
    elif [ -f "./vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="./vpn/lib/vpn-json.sh"
    fi
fi
[ -n "${VPN_JSON_LIB:-}" ] && [ -f "$VPN_JSON_LIB" ] && . "$VPN_JSON_LIB"

WARP_API_BASE="${WARP_API_BASE:-https://api.cloudflareclient.com/v0i1909051800}"
WARP_USER_AGENT="${WARP_USER_AGENT:-okhttp/3.12.1}"
# Порты: telegra.ph/Gajd-kak-nastroit-obhod-blokirovok-Phone-ver-11-15 и warp-generator.github.io/script.js
WARP_PORTS="${WARP_PORTS:-500 854 859 864 878 880 890 891 894 903 908 928 934 939 942 943 945 946 955 968 987 988 1002 1010 1014 1018 1070 1074 1180 1387 1701 1843 2371 2408 2506 3138 3476 3581 3854 4177 4198 4233 4500 5279 5956 7103 7152 7156 7281 7559 8319 8742 8854 8886}"

# Сервер xfree — узкий пул 162.159.195.1–10 (toolbox).
# Сервер def — префиксы CF как warp-generator.github.io (без tribukvy).
# FL|NL|PL|DE|LV|RU — хосты tribukvy.ltd (как на сайте, без LTE).

# cloudflare: префиксы для случайного host (последний октет — см. WARP_CF_DEF_OCTET_*).
WARP_CF_DEF_PREFIXES="${WARP_CF_DEF_PREFIXES:-engage.cloudflareclient.com 162.159.192. 162.159.195. 8.6.112. 8.34.70. 8.34.146. 8.35.211. 8.39.125. 8.39.204. 8.39.214. 8.47.69. 188.114.96. 188.114.97. 188.114.98. 188.114.99.}"
# warp-generator.github.io берёт 1–10; в гайде допускается 0–255 (WARP_CF_DEF_OCTET_MAX=255).
WARP_CF_DEF_OCTET_MIN="${WARP_CF_DEF_OCTET_MIN:-1}"
WARP_CF_DEF_OCTET_MAX="${WARP_CF_DEF_OCTET_MAX:-10}"

WARP_XFREE_DEF_HOST_PREFIX="${WARP_XFREE_DEF_HOST_PREFIX:-${WARP_DEF_HOST_PREFIX:-162.159.195.}}"
WARP_XFREE_DEF_HOST_OCTET_MIN="${WARP_XFREE_DEF_HOST_OCTET_MIN:-1}"
WARP_XFREE_DEF_HOST_OCTET_MAX="${WARP_XFREE_DEF_HOST_OCTET_MAX:-${WARP_DEF_HOST_OCTET_MAX:-10}}"

warp_json_get() {
    vpn_json_get_string "$2" "$1"
}

warp_entropy_mod_upper() {
    upper="$1"
    [ "${upper:-0}" -gt 0 ] || return 1

    rnd=""
    if [ -r /dev/urandom ]; then
        if command -v hexdump >/dev/null 2>&1; then
            rnd="$(hexdump -n 4 -v -e '1/4 "%u\n"' /dev/urandom 2>/dev/null | head -n1 | tr -d ' \t\r')"
        fi
        if [ -z "$rnd" ] && command -v od >/dev/null 2>&1; then
            rnd="$(od -An -N4 -tu4 /dev/urandom 2>/dev/null | head -n1 | tr -dc '0-9')"
        fi
        if [ -z "$rnd" ] && command -v od >/dev/null 2>&1; then
            rnd="$(od -An -N2 -tu2 /dev/urandom 2>/dev/null | tr -dc '0-9')"
        fi
    fi

    case "$rnd" in
        '' | *[!0-9]*)
            rnd=$(( ($$ ^ $(date +%s)) % upper ))
            ;;
    esac

    rnd=$((rnd % upper))
    printf '%u\n' "$rnd"
}

warp_rand_int_between() {
    lower="$1"
    upper="$2"
    span=$((upper - lower + 1))
    [ "$span" -gt 0 ] || die "warp_rand_int_between: нижний предел выше верхнего"
    rnd_mod="$(warp_entropy_mod_upper "$span")"
    rnd_mod=$((rnd_mod + lower))
    printf '%u\n' "$rnd_mod"
}

warp_rand_from_list() {
    # shellcheck disable=SC2086
    set -- $1
    count=$#
    [ "$count" -gt 0 ] || die "Пустой список"

    rnd_mod="$(warp_entropy_mod_upper "$count")"
    idx=$((rnd_mod + 1))

    n=1
    for item in "$@"; do
        if [ "$n" -eq "$idx" ]; then
            printf '%s\n' "$item"
            return 0
        fi
        n=$((n + 1))
    done

    die "Не удалось выбрать случайный элемент"
}

warp_pick_keygen_tool() {
    if command -v awg >/dev/null 2>&1; then
        printf 'awg\n'
        return 0
    fi
    if command -v wg >/dev/null 2>&1; then
        printf 'wg\n'
        return 0
    fi
    die "Не найден ни awg, ни wg"
}

warp_generate_keys() {
    tool="$(warp_pick_keygen_tool)"
    WARP_GEN_PRIV="$("$tool" genkey)"
    [ -n "$WARP_GEN_PRIV" ] || die "Не удалось сгенерировать private key"
    WARP_GEN_PUB="$(printf '%s' "$WARP_GEN_PRIV" | "$tool" pubkey)"
    [ -n "$WARP_GEN_PUB" ] || die "Не удалось сгенерировать public key"
}

warp_normalize_server() {
    case "$1" in
        xfree|def|FL|NL|PL|DE|LV|RU)
            printf '%s\n' "$1"
            ;;
        PL1|PL2)
            printf 'PL\n'
            ;;
        EE)
            die "Сервер EE снят; используйте LV или def (как на warp-generator.github.io)"
            ;;
        US)
            die "Сервер US снят; используйте: xfree, def, FL, NL, PL, DE, LV, RU"
            ;;
        ltePL|lteFL|LTEPL|LTEFL)
            die "LTE-серверы не поддерживаются (исключены по политике xfree-toolbox)"
            ;;
        *)
            die "Неизвестный сервер: $1"
            ;;
    esac
}

warp_server_host() {
    case "$1" in
        PL)  printf 'pl.tribukvy.ltd\n' ;;
        DE)  printf 'de.tribukvy.ltd\n' ;;
        RU)  printf 'ru0.tribukvy.ltd\n' ;;
        NL)  printf 'nl.tribukvy.ltd\n' ;;
        FL)  printf 'fi.tribukvy.ltd\n' ;;
        LV)  printf 'lv.tribukvy.ltd\n' ;;
        xfree|def)
            die "warp_server_host: для $1 используйте warp_build_endpoint"
            ;;
        *)
            die "Неизвестный сервер: $1"
            ;;
    esac
}

warp_def_endpoint_policy() {
    case "$1" in
        xfree) printf 'xfree\n' ;;
        def)   printf 'cloudflare\n' ;;
        *)     printf '%s\n' "host:$1" ;;
    esac
}

warp_build_def_endpoint_xfree() {
    port="$1"
    n="$(warp_rand_int_between "$WARP_XFREE_DEF_HOST_OCTET_MIN" "$WARP_XFREE_DEF_HOST_OCTET_MAX")"
    printf '%s%s:%s\n' "$WARP_XFREE_DEF_HOST_PREFIX" "$n" "$port"
}

warp_build_def_endpoint_cloudflare() {
    port="$1"
    prefix="$(warp_rand_from_list "$WARP_CF_DEF_PREFIXES")"

    if [ "$prefix" = "engage.cloudflareclient.com" ]; then
        printf '%s:%s\n' "$prefix" "$port"
        return 0
    fi

    n="$(warp_rand_int_between "$WARP_CF_DEF_OCTET_MIN" "$WARP_CF_DEF_OCTET_MAX")"
    printf '%s%s:%s\n' "$prefix" "$n" "$port"
}

warp_build_endpoint() {
    server="$(warp_normalize_server "$1")"
    port="$(warp_rand_from_list "$WARP_PORTS")"

    case "$server" in
        xfree)
            warp_build_def_endpoint_xfree "$port"
            ;;
        def)
            warp_build_def_endpoint_cloudflare "$port"
            ;;
        *)
            host="$(warp_server_host "$server")"
            printf '%s:%s\n' "$host" "$port"
            ;;
    esac
}

warp_register() {
    pubkey="$1"
    payload="$(printf '{"key":"%s","install_id":"","fcm_token":"","tos":"%s","type":"ios","locale":"en_US"}' \
        "$pubkey" "$(date -u +"%Y-%m-%dT%H:%M:%SZ")")"

    curl -fsS -X POST "${WARP_API_BASE}/reg" \
        -H "Content-Type: application/json" \
        -H "User-Agent: ${WARP_USER_AGENT}" \
        --data "$payload"
}

warp_enable() {
    client_id="$1"
    token="$2"

    curl -fsS -X PATCH "${WARP_API_BASE}/reg/${client_id}" \
        -H "Content-Type: application/json" \
        -H "User-Agent: ${WARP_USER_AGENT}" \
        -H "Authorization: Bearer ${token}" \
        --data '{"warp_enabled":true}'
}
