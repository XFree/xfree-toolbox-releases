#!/bin/sh
# shellcheck shell=sh

if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/lib/proton-api-contract.env" ]; then
    # shellcheck disable=SC1090
    . "$ROOT_DIR/lib/proton-api-contract.env"
elif [ -f "./lib/proton-api-contract.env" ]; then
    # shellcheck disable=SC1091
    . "./lib/proton-api-contract.env"
fi

PROTON_BASE_URL="${PROTON_BASE_URL:-https://account.protonvpn.com}"
PROTON_WORKDIR="${PROTON_WORKDIR:-/tmp/proton-generator}"
mkdir -p "$PROTON_WORKDIR"
_VPN_LIB_DIR=""
if [ -n "${VPN_LIB_DIR:-}" ] && [ -d "$VPN_LIB_DIR" ]; then
    _VPN_LIB_DIR="$VPN_LIB_DIR"
elif [ -n "${SCRIPT_DIR:-}" ] && [ -d "$SCRIPT_DIR/vpn/lib" ]; then
    _VPN_LIB_DIR="$SCRIPT_DIR/vpn/lib"
elif [ -n "${ROOT_DIR:-}" ] && [ -d "$ROOT_DIR/iface-routing/vpn/lib" ]; then
    _VPN_LIB_DIR="$ROOT_DIR/iface-routing/vpn/lib"
elif [ -d "/root/xfree-toolbox/iface-routing/vpn/lib" ]; then
    _VPN_LIB_DIR="/root/xfree-toolbox/iface-routing/vpn/lib"
elif [ -d "/etc/xfree-toolbox/iface-routing/vpn/lib" ]; then
    _VPN_LIB_DIR="/etc/xfree-toolbox/iface-routing/vpn/lib"
elif [ -d "./iface-routing/vpn/lib" ]; then
    _VPN_LIB_DIR="./iface-routing/vpn/lib"
elif [ -d "./vpn/lib" ]; then
    _VPN_LIB_DIR="./vpn/lib"
elif [ -d "./lib" ]; then
    _VPN_LIB_DIR="./lib"
fi

if [ -z "${PROTON_CRYPTO_FALLBACK_LIB:-}" ]; then
    if [ -n "$_VPN_LIB_DIR" ] && [ -f "$_VPN_LIB_DIR/proton-crypto-fallback.sh" ]; then
        PROTON_CRYPTO_FALLBACK_LIB="$_VPN_LIB_DIR/proton-crypto-fallback.sh"
    elif [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/iface-routing/vpn/lib/proton-crypto-fallback.sh" ]; then
        PROTON_CRYPTO_FALLBACK_LIB="$ROOT_DIR/iface-routing/vpn/lib/proton-crypto-fallback.sh"
    elif [ -f "./iface-routing/vpn/lib/proton-crypto-fallback.sh" ]; then
        PROTON_CRYPTO_FALLBACK_LIB="./iface-routing/vpn/lib/proton-crypto-fallback.sh"
    elif [ -f "./vpn/lib/proton-crypto-fallback.sh" ]; then
        PROTON_CRYPTO_FALLBACK_LIB="./vpn/lib/proton-crypto-fallback.sh"
    fi
fi
[ -n "${PROTON_CRYPTO_FALLBACK_LIB:-}" ] && [ -f "$PROTON_CRYPTO_FALLBACK_LIB" ] && . "$PROTON_CRYPTO_FALLBACK_LIB"

if [ -z "${VPN_JSON_LIB:-}" ]; then
    if [ -n "$_VPN_LIB_DIR" ] && [ -f "$_VPN_LIB_DIR/vpn-json.sh" ]; then
        VPN_JSON_LIB="$_VPN_LIB_DIR/vpn-json.sh"
    elif [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/iface-routing/vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="$ROOT_DIR/iface-routing/vpn/lib/vpn-json.sh"
    elif [ -f "./iface-routing/vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="./iface-routing/vpn/lib/vpn-json.sh"
    elif [ -f "./vpn/lib/vpn-json.sh" ]; then
        VPN_JSON_LIB="./vpn/lib/vpn-json.sh"
    fi
fi
[ -n "${VPN_JSON_LIB:-}" ] && [ -f "$VPN_JSON_LIB" ] && . "$VPN_JSON_LIB"

if [ -z "${WG_MODE_LIB:-}" ]; then
    if [ -n "$_VPN_LIB_DIR" ] && [ -f "$_VPN_LIB_DIR/wg-mode.sh" ]; then
        WG_MODE_LIB="$_VPN_LIB_DIR/wg-mode.sh"
    elif [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/iface-routing/vpn/lib/wg-mode.sh" ]; then
        WG_MODE_LIB="$ROOT_DIR/iface-routing/vpn/lib/wg-mode.sh"
    elif [ -f "./iface-routing/vpn/lib/wg-mode.sh" ]; then
        WG_MODE_LIB="./iface-routing/vpn/lib/wg-mode.sh"
    elif [ -f "./vpn/lib/wg-mode.sh" ]; then
        WG_MODE_LIB="./vpn/lib/wg-mode.sh"
    elif [ -f "./lib/wg-mode.sh" ]; then
        WG_MODE_LIB="./lib/wg-mode.sh"
    fi
fi
[ -n "${WG_MODE_LIB:-}" ] && [ -f "$WG_MODE_LIB" ] && . "$WG_MODE_LIB"

if [ -z "${WG_PROBE_LIB:-}" ]; then
    if [ -n "$_VPN_LIB_DIR" ] && [ -f "$_VPN_LIB_DIR/wg-probe.sh" ]; then
        WG_PROBE_LIB="$_VPN_LIB_DIR/wg-probe.sh"
    elif [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/iface-routing/vpn/lib/wg-probe.sh" ]; then
        WG_PROBE_LIB="$ROOT_DIR/iface-routing/vpn/lib/wg-probe.sh"
    elif [ -f "./iface-routing/vpn/lib/wg-probe.sh" ]; then
        WG_PROBE_LIB="./iface-routing/vpn/lib/wg-probe.sh"
    elif [ -f "./vpn/lib/wg-probe.sh" ]; then
        WG_PROBE_LIB="./vpn/lib/wg-probe.sh"
    elif [ -f "./lib/wg-probe.sh" ]; then
        WG_PROBE_LIB="./lib/wg-probe.sh"
    fi
fi
[ -n "${WG_PROBE_LIB:-}" ] && [ -f "$WG_PROBE_LIB" ] && . "$WG_PROBE_LIB"

: "${XFREE_STATE_ROOT:=/etc/xfree-toolbox}"
: "${XFREE_VPN_ROOT:=$XFREE_STATE_ROOT/vpn}"

PROTON_LOGICALS_JSON="$PROTON_WORKDIR/logicals.json"
PROTON_LOGICALS_TABLE="$PROTON_WORKDIR/logicals.tsv"
PROTON_CERT_CREATE_REQ_JSON="$PROTON_WORKDIR/certificate.create.request.json"
PROTON_CERT_CREATE_JSON="$PROTON_WORKDIR/certificate.create.json"
PROTON_CERT_KEY_JSON="$PROTON_WORKDIR/certificate.key.ec.json"
PROTON_AUTH_REFRESH_JSON="$PROTON_WORKDIR/auth.refresh.json"

PROTON_BASE_URL="${PROTON_BASE_URL:-${PROTON_API_BASE_URL:-https://account.protonvpn.com}}"
PROTON_X_PM_APPVERSION="${PROTON_X_PM_APPVERSION:-${PROTON_API_APPVERSION:-web-vpn-settings@5.0.326.0}}"
PROTON_GUEST_APPVERSION="${PROTON_GUEST_APPVERSION:-${PROTON_API_GUEST_APPVERSION:-android-vpn@5.20.98.0}}"
PROTON_X_PM_LOCALE="${PROTON_X_PM_LOCALE:-${PROTON_API_LOCALE:-en_US}}"
PROTON_API_ACCEPT="${PROTON_API_ACCEPT:-application/vnd.protonmail.v1+json}"
PROTON_API_USER_AGENT="${PROTON_API_USER_AGENT:-Mozilla/5.0}"
PROTON_STATE_DIR="${PROTON_STATE_DIR:-$XFREE_VPN_ROOT/state/proton}"
PROTON_SESSIONS_DIR="${PROTON_SESSIONS_DIR:-$PROTON_STATE_DIR/sessions}"
PROTON_GENERATED_DIR="${PROTON_GENERATED_DIR:-$XFREE_VPN_ROOT/generated/proton}"
PROTON_LEGACY_SESSIONS_DIR="${PROTON_LEGACY_SESSIONS_DIR:-/root/proton/sessions}"
PROTON_PLATFORM="${PROTON_PLATFORM:-Router}"
PROTON_DEVICE_NAME_PREFIX="${PROTON_DEVICE_NAME_PREFIX:-xfree-toolbox}"
PROTON_CURL_CONNECT_TIMEOUT="${PROTON_CURL_CONNECT_TIMEOUT:-20}"
PROTON_CURL_MAX_TIME="${PROTON_CURL_MAX_TIME:-45}"
PROTON_CURL_CONNECT_RETRIES="${PROTON_CURL_CONNECT_RETRIES:-3}"
PROTON_CURL_IP_VERSION="${PROTON_CURL_IP_VERSION:-4}"
PROTON_REFRESH_BEFORE_AUTH="${PROTON_REFRESH_BEFORE_AUTH:-1}"
PROTON_REFRESH_FAIL_HARD="${PROTON_REFRESH_FAIL_HARD:-0}"
PROTON_PROBE_TOP_N="${PROTON_PROBE_TOP_N:-3}"
PROTON_PROBE_TIMEOUT_SEC="${PROTON_PROBE_TIMEOUT_SEC:-1}"
PROTON_USE_FREE_ONLY="${PROTON_USE_FREE_ONLY:-1}"
# 1 = только logicals с IPv6 (EntryIPv6/ExitIPv6 или Features bit 16); 0 = все (IPv4-only тоже).
PROTON_REQUIRE_IPV6="${PROTON_REQUIRE_IPV6:-0}"
# Клиентские адреса туннеля Proton WG (официальные приложения; не EntryIPv6 сервера).
PROTON_WG_CLIENT_IPV4="${PROTON_WG_CLIENT_IPV4:-10.2.0.2/32}"
PROTON_WG_CLIENT_IPV6="${PROTON_WG_CLIENT_IPV6:-2a07:b944::2:2/128}"
PROTON_WG_DNS="${PROTON_WG_DNS:-10.2.0.1}"
PROTON_WG_DNS_IPV6="${PROTON_WG_DNS_IPV6:-2a07:b944::2:1}"
PROTON_WG_PEER_PORT="${PROTON_WG_PEER_PORT:-auto}"
PROTON_AUTO_PROBE_PORTS="${PROTON_AUTO_PROBE_PORTS:-51820 443 500 4500 1194 5060}"
PROTON_PROBE_VIA="${PROTON_PROBE_VIA:-auto}"

proton_resolve_probe_via() {
    _via="${PROTON_PROBE_VIA:-}"
    if [ "$_via" = "auto" ] || [ -z "$_via" ]; then
        _via=""
        if [ -n "${IFACE_NAME:-}" ]; then
            _icfg="$XFREE_STATE_ROOT/iface-routing/state/interfaces/$IFACE_NAME/config/iface.conf"
            [ -f "$_icfg" ] || _icfg="/etc/xfree-toolbox/iface-routing/state/interfaces/$IFACE_NAME/config/iface.conf"
            if [ -f "$_icfg" ]; then
                _via="$(conf_value "$_icfg" "SELF_ROUTE_VIA" || true)"
            fi
        fi
    fi
    case "$_via" in
        none|direct|wan|'') _via="" ;;
    esac
    if [ -n "$_via" ] && command -v ip >/dev/null 2>&1 && ip link show "$_via" >/dev/null 2>&1; then
        PROTON_PROBE_VIA="$_via"
        WG_PROBE_VIA_DEV="$_via"
        export PROTON_PROBE_VIA WG_PROBE_VIA_DEV
        info "Маршрутизация подбора Proton: через туннель $_via"
    else
        PROTON_PROBE_VIA=""
        unset WG_PROBE_VIA_DEV 2>/dev/null || true
    fi
}

proton_curl_interface_arg() {
    [ -n "${PROTON_PROBE_VIA:-}" ] || return 0
    case "${PROTON_PROBE_VIA:-}" in
        none|direct|wan|'') return 0 ;;
    esac
    if command -v ip >/dev/null 2>&1 && ip link show "$PROTON_PROBE_VIA" >/dev/null 2>&1; then
        printf '%s %s\n' "--interface" "$PROTON_PROBE_VIA"
    fi
}
# После успешного auth refresh копировать cookies/uid в «зеркальные» каталоги с тем же именем сессии
# (state в XFREE_VPN_ROOT и копия в профиле), чтобы не расходились куки.
PROTON_SESSION_SYNC="${PROTON_SESSION_SYNC:-1}"
# Коллизия одного имени в state и в профиле: freshness = новее по mtime cookies/uid;
# при равной свежести приоритет: профиль→state→PROTON_SESSIONS_DIR.
PROTON_SESSION_PICK="${PROTON_SESSION_PICK:-freshness}"
# web = cookies.txt; guest = credentialless Bearer tokens (access_token.txt + refresh_token.txt).
PROTON_AUTH_MODE="${PROTON_AUTH_MODE:-web}"
PROTON_ACCESS_TOKEN="${PROTON_ACCESS_TOKEN:-}"
PROTON_REFRESH_TOKEN="${PROTON_REFRESH_TOKEN:-}"

if [ ! -d "$PROTON_SESSIONS_DIR" ] && [ -d "$PROTON_LEGACY_SESSIONS_DIR" ]; then
    PROTON_SESSIONS_DIR="$PROTON_LEGACY_SESSIONS_DIR"
fi

# Компактные имена .conf (как в меню Proton на роутере): короткая сессия + a<версия> без точек + короткий stamp.
proton_confname_compact_awg_version() {
    printf '%s\n' "${1:-2.0}" | tr -d '.'
}

# proton-YYYYMMDD-... -> pYYYYMMDD; иначе усечённый идентификатор.
proton_confname_short_session() {
    raw="${1:-session}"
    low="$(printf '%s' "$raw" | tr 'A-Z' 'a-z')"
    low="${low#proton-}"
    case "$low" in
        [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]-*)
            d="$(printf '%s' "$low" | awk '{ print substr($0, 1, 8) }')"
            printf 'p%s\n' "$d"
            ;;
        *)
            printf '%s\n' "$low" | awk '{ if (length($0) > 12) print substr($0, 1, 12); else print }'
            ;;
    esac
}

proton_conf_gen_stamp() {
    date -u +"%y%m%d%H%M%S"
}

# Подпись для меню/списков: CC · name (из XFREE_CONF_LIST_HINT) или усечённый basename.
proton_conf_basename_menu_desc() {
    path="$1"
    bn="$2"
    if [ ! -f "$path" ]; then
        printf '%s\n' "$bn"
        return 0
    fi
    line="$(grep -m1 '^# XFREE_CONF_LIST_HINT=' "$path" 2>/dev/null || true)"
    line="${line#*XFREE_CONF_LIST_HINT=}"
    line="$(printf '%s' "$line" | tr -d '\r')"
    n1="$(printf '%s' "$line" | awk -F'|' 'NF>=1 { gsub(/^[[:space:]]+|[[:space:]]+$/, "", $1); print $1; exit }')"
    n2="$(printf '%s' "$line" | awk -F'|' 'NF>=2 { gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2); print $2; exit }')"
    if [ -n "$n2" ]; then
        hint="$n2"
        if [ -n "$n1" ]; then
            short1="$(printf '%s' "$n1" | awk '{ if (length($0) > 22) print substr($0, 1, 22) ".."; else print }')"
            hint="$hint · $short1"
        fi
        printf '%s\n' "$hint"
        return 0
    fi
    base="${bn%.conf}"
    printf '%s\n' "$base" | awk '{ if (length($0) > 34) print substr($0, 1, 33) ".."; else print }'
}

# Каталог сессий в state (не зависит от PROTON_SESSIONS_DIR, если его переопределили).
proton_state_sessions_dir() {
    printf '%s/sessions\n' "$PROTON_STATE_DIR"
}

proton_profile_proton_sessions_dir() {
    [ -n "${PROFILE_DIR:-}" ] || return 1
    printf '%s/vpn/proton/sessions\n' "$PROFILE_DIR"
}

# Список имён подкаталогов-сессий из state, профиля и PROTON_SESSIONS_DIR (уникально).
proton_list_relative_session_names() {
    if proton_store_scoped_sessions_p; then
        proton_list_complete_session_names_in_dir "$PROTON_SESSIONS_DIR" | sort -u | sort -r
        return 0
    fi
    {
        if [ -d "$(proton_state_sessions_dir)" ]; then
            ssd="$(proton_state_sessions_dir)"
            find "$ssd" -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
                | sed "s#^$ssd/##" | sed '/^$/d'
        fi
        if [ -n "${PROFILE_DIR:-}" ] && [ -d "$(proton_profile_proton_sessions_dir)" ]; then
            psd="$(proton_profile_proton_sessions_dir)"
            find "$psd" -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
                | sed "s#^$psd/##" | sed '/^$/d'
        fi
        if [ -d "$PROTON_SESSIONS_DIR" ]; then
            find "$PROTON_SESSIONS_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
                | sed "s#^$PROTON_SESSIONS_DIR/##" | sed '/^$/d'
        fi
    } | sort -u | sort -r
}

proton_dir_realpath() {
    d="$1"
    [ -d "$d" ] || return 1
    CDPATH= cd -- "$d" && pwd -P
}

proton_same_dir_p() {
    a="$1"
    b="$2"
    ar="$(proton_dir_realpath "$a")" || return 1
    br="$(proton_dir_realpath "$b")" || return 1
    [ "$ar" = "$br" ]
}

proton_file_mtime_epoch() {
    f="$1"
    [ -f "$f" ] || {
        printf '%s\n' 0
        return 0
    }
    ts="$(stat -c '%Y' "$f" 2>/dev/null)"
    [ -n "$ts" ] || ts="$(stat -f '%m' "$f" 2>/dev/null)" || ts=""
    case "$ts" in
        ''|*[!0-9]*) ts=0 ;;
    esac
    printf '%s\n' "$ts"
}

# «Свежесть» бандла: max(mtime cookies|access_token, mtime uid) — после refresh обновится jar/tokens.
proton_session_dir_freshness_epoch() {
    d="$1"
    mc="$(proton_file_mtime_epoch "$d/cookies.txt")"
    ma="$(proton_file_mtime_epoch "$d/access_token.txt")"
    mu="$(proton_file_mtime_epoch "$d/x_pm_uid.txt")"
    best="$mc"
    [ "$ma" -gt "$best" ] 2>/dev/null && best="$ma"
    [ "$mu" -gt "$best" ] 2>/dev/null && best="$mu"
    printf '%s\n' "$best"
}

# Максимальный expires среди AUTH-/REFRESH- cookies (Netscape cookies.txt), 0 если не найдено.
proton_session_cookie_auth_expiry_epoch() {
    d="$1"
    f="$d/cookies.txt"
    [ -f "$f" ] || {
        printf '%s\n' 0
        return 0
    }
    awk -F '\t' '
        BEGIN { best = 0 }
        NF >= 7 {
            name = $6
            expts = $5 + 0
            if ((name ~ /^AUTH-/ || name ~ /^REFRESH-/) && expts > best) {
                best = expts
            }
        }
        END { printf "%d\n", best }
    ' "$f" 2>/dev/null
}

# При равной свежести: профиль (0) предпочтительнее state (1) и PROTON_SESSIONS_DIR (2).
proton_session_bundle_tie_rank() {
    d="$1"
    if [ -n "${PROFILE_DIR:-}" ]; then
        psd="$(proton_profile_proton_sessions_dir)" || true
        case "$d" in
            "$psd" | "$psd"/*)
                printf '%s\n' 0
                return 0
                ;;
        esac
    fi
    state_root="$(proton_state_sessions_dir)"
    case "$d" in
        "$state_root" | "$state_root"/*)
            printf '%s\n' 1
            return 0
            ;;
    esac
    case "$d" in
        "$PROTON_SESSIONS_DIR" | "$PROTON_SESSIONS_DIR"/*)
            printf '%s\n' 2
            return 0
            ;;
    esac
    printf '%s\n' 9
}

proton_session_auth_mode_from_dir() {
    d="$1"
    [ -d "$d" ] || {
        printf '%s\n' ""
        return 0
    }
    if [ -f "$d/auth_mode.txt" ]; then
        mode="$(head -n1 "$d/auth_mode.txt" | tr -d '\r\n' | tr 'A-Z' 'a-z')"
        case "$mode" in
            guest|web)
                printf '%s\n' "$mode"
                return 0
                ;;
        esac
    fi
    if [ -f "$d/access_token.txt" ] && [ -f "$d/refresh_token.txt" ] && [ -f "$d/x_pm_uid.txt" ]; then
        printf '%s\n' "guest"
        return 0
    fi
    if [ -f "$d/cookies.txt" ] && [ -f "$d/x_pm_uid.txt" ]; then
        printf '%s\n' "web"
        return 0
    fi
    printf '%s\n' ""
}

proton_session_bundle_complete_p() {
    d="$1"
    [ -d "$d" ] || return 1
    [ -f "$d/x_pm_uid.txt" ] || return 1
    if [ -f "$d/cookies.txt" ]; then
        return 0
    fi
    if [ -f "$d/access_token.txt" ] && [ -f "$d/refresh_token.txt" ]; then
        return 0
    fi
    return 1
}

# profile-generator / ci/store: сессии только из PROTON_SESSIONS_DIR (не state/профиль).
proton_store_scoped_sessions_p() {
    [ -n "${XFREE_VPN_STORE_ID:-}" ] && [ -d "${PROTON_SESSIONS_DIR:-}" ]
}

proton_list_complete_session_names_in_dir() {
    dir="$1"
    [ -d "$dir" ] || return 0
    for d in "$dir"/*; do
        [ -d "$d" ] || continue
        proton_session_bundle_complete_p "$d" || continue
        basename "$d"
    done
}

proton_newest_complete_session_name_in_dir() {
    dir="$1"
    best=""
    best_m=0
    name=""
    [ -d "$dir" ] || return 1
    for d in "$dir"/*; do
        [ -d "$d" ] || continue
        proton_session_bundle_complete_p "$d" || continue
        name="$(basename "$d")"
        m="$(proton_session_dir_freshness_epoch "$d")"
        case "$m" in
            '' | *[!0-9]*) m=0 ;;
        esac
        if [ "$m" -ge "$best_m" ] 2>/dev/null; then
            best_m=$m
            best=$name
        fi
    done
    [ -n "$best" ] || return 1
    printf '%s\n' "$best"
}

# Добавить path в candlist, если бандл полный и realpath ещё не в seenrp.
proton_try_add_session_candidate() {
    path="$1"
    candlist="$2"
    seenrp="$3"
    [ -n "$path" ] || return 0
    proton_session_bundle_complete_p "$path" || return 0
    rp="$(proton_dir_realpath "$path")" || return 0
    grep -qxF "$rp" "$seenrp" 2>/dev/null && return 0
    printf '%s\n' "$rp" >> "$seenrp"
    printf '%s\n' "$path" >> "$candlist"
}

# Собрать валидные каталоги с одним slug из разных корней (без дубликатов по realpath).
proton_apply_rel_session_pick() {
    slug="$1"
    slug="$(basename "$slug")"
    [ -n "$slug" ] || return 1
    case "$slug" in
        .|..|*[\\/]*) return 1 ;;
    esac

    if proton_store_scoped_sessions_p; then
        path="$PROTON_SESSIONS_DIR/$slug"
        if proton_session_bundle_complete_p "$path"; then
            PROTON_SESSION_DIR="$path"
            return 0
        fi
        return 1
    fi

    state_s="$(proton_state_sessions_dir)"
    profile_s=""
    [ -n "${PROFILE_DIR:-}" ] && profile_s="$(proton_profile_proton_sessions_dir)"

    candlist="$PROTON_WORKDIR/.proton-sess-cand.$$"
    seenrp="$PROTON_WORKDIR/.proton-sess-seen.$$"
    : > "$candlist"
    : > "$seenrp"

    proton_try_add_session_candidate "$state_s/$slug" "$candlist" "$seenrp"
    if [ -n "$profile_s" ]; then
        proton_try_add_session_candidate "$profile_s/$slug" "$candlist" "$seenrp"
    fi
    proton_try_add_session_candidate "$PROTON_SESSIONS_DIR/$slug" "$candlist" "$seenrp"

    rm -f "$seenrp"

    nlines=0
    if [ -s "$candlist" ]; then
        nlines="$(wc -l < "$candlist" | tr -d ' \n\r\t')"
    fi
    case "$nlines" in
        '' | *[!0-9]*) nlines=0 ;;
    esac

    if [ "$nlines" -eq 0 ] 2>/dev/null; then
        rm -f "$candlist"
        return 1
    fi

    case "${PROTON_SESSION_PICK:-freshness}" in
        priority | PRIORITY | fixed | FIXED | legacy | LEGACY)
            chosen="$(head -n 1 "$candlist")"
            ;;
        freshness | FRESHNESS | *)
            chosen=""
            best_e=-1
            best_s=-1
            best_r=999
            while IFS= read -r d || [ -n "$d" ]; do
                [ -n "$d" ] || continue
                e="$(proton_session_cookie_auth_expiry_epoch "$d")"
                s="$(proton_session_dir_freshness_epoch "$d")"
                r="$(proton_session_bundle_tie_rank "$d")"
                case "$e" in
                    '' | *[!0-9]*) e=0 ;;
                esac
                case "$s" in
                    '' | *[!0-9]*) s=0 ;;
                esac
                case "$r" in
                    '' | *[!0-9]*) r=9 ;;
                esac
                if [ "$e" -gt "$best_e" ] 2>/dev/null; then
                    best_e=$e
                    best_s=$s
                    best_r=$r
                    chosen=$d
                elif [ "$e" -eq "$best_e" ] 2>/dev/null && [ "$s" -gt "$best_s" ] 2>/dev/null; then
                    best_s=$s
                    best_r=$r
                    chosen=$d
                elif [ "$e" -eq "$best_e" ] 2>/dev/null && [ "$s" -eq "$best_s" ] 2>/dev/null && [ "$r" -lt "$best_r" ] 2>/dev/null; then
                    best_r=$r
                    chosen=$d
                fi
            done < "$candlist"
            if [ "$nlines" -gt 1 ] 2>/dev/null && [ -n "$chosen" ]; then
                debug "Proton session pick=freshness: $chosen (best auth-cookie expires -> mtime -> tie-rank among $nlines dirs)"
            fi
            ;;
    esac

    rm -f "$candlist"

    [ -n "${chosen:-}" ] || return 1
    PROTON_SESSION_DIR="$chosen"
    return 0
}

# Относительное имя сессии: см. PROTON_SESSION_PICK (freshness | priority).
proton_resolve_rel_session_dir() {
    slug="$1"
    slug="$(basename "$slug")"
    [ -n "$slug" ] || die "Пустое имя сессии Proton"
    case "$slug" in
        .|..|*[\\/]*) die "Некорректное имя сессии Proton: $slug" ;;
    esac

    state_s="$(proton_state_sessions_dir)"
    profile_s=""
    [ -n "${PROFILE_DIR:-}" ] && profile_s="$(proton_profile_proton_sessions_dir)"

    if ! proton_apply_rel_session_pick "$slug"; then
        if proton_store_scoped_sessions_p; then
            tried="$PROTON_SESSIONS_DIR/$slug (store=$XFREE_VPN_STORE_ID)"
        else
            tried="$state_s/$slug"
            if [ -n "$profile_s" ]; then
                tried="$tried; $profile_s/$slug"
            fi
            tried="$tried; $PROTON_SESSIONS_DIR/$slug"
        fi
        die "Не найден полный бандл сессии Proton (имя=$slug, нужны cookies.txt+x_pm_uid.txt или access_token.txt+refresh_token.txt+x_pm_uid.txt). Проверьте: $tried"
    fi
}

proton_sync_session_mirrors_after_refresh() {
    case "${PROTON_SESSION_SYNC:-1}" in
        0|no|NO|false|FALSE) return 0 ;;
    esac

    src="$PROTON_SESSION_DIR"
    name="$PROTON_SELECTED_SESSION_NAME"
    [ -n "$src" ] && [ -n "$name" ] || return 0
    if [ ! -f "$src/cookies.txt" ] && [ ! -f "$src/access_token.txt" ]; then
        return 0
    fi

    state_dst="$(proton_state_sessions_dir)/$name"
    profile_dst=""
    [ -n "${PROFILE_DIR:-}" ] && profile_dst="$(proton_profile_proton_sessions_dir)/$name"
    config_dst="$PROTON_SESSIONS_DIR/$name"

    for dst in "$state_dst" "$profile_dst" "$config_dst"; do
        [ -n "$dst" ] || continue
        [ -d "$dst" ] || continue
        if proton_same_dir_p "$dst" "$src"; then
            continue
        fi

        ok=1
        for f in cookies.txt x_pm_uid.txt access_token.txt refresh_token.txt auth_mode.txt x_pm_appversion.txt; do
            if [ -f "$src/$f" ]; then
                if ! cp -f "$src/$f" "$dst/$f" 2>/dev/null; then
                    warn "Proton session sync: не удалось скопировать $f -> $dst"
                    ok=0
                fi
            fi
        done
        if [ "$ok" = "1" ]; then
            info "Proton session синхронизирована (auth-файлы) -> $dst"
        fi
    done
}

proton_resolve_session_dir() {
    session="${PROTON_SELECTED_SESSION:-}"
    [ -n "$session" ] || die "Не задана сессия Proton"

    case "$session" in
        /*)
            PROTON_SESSION_DIR="$session"
            ;;
        *)
            proton_resolve_rel_session_dir "$session"
            ;;
    esac

    PROTON_SELECTED_SESSION_NAME="$(basename "$PROTON_SESSION_DIR")"
}

proton_session_cookie_file() {
    printf '%s/cookies.txt\n' "$PROTON_SESSION_DIR"
}

proton_session_uid_file() {
    printf '%s/x_pm_uid.txt\n' "$PROTON_SESSION_DIR"
}

proton_session_appversion_file() {
    printf '%s/x_pm_appversion.txt\n' "$PROTON_SESSION_DIR"
}

proton_session_access_token_file() {
    printf '%s/access_token.txt\n' "$PROTON_SESSION_DIR"
}

proton_session_refresh_token_file() {
    printf '%s/refresh_token.txt\n' "$PROTON_SESSION_DIR"
}

proton_session_auth_mode_file() {
    printf '%s/auth_mode.txt\n' "$PROTON_SESSION_DIR"
}

# Empty / "guest" = credentialless (default). Any other ref is a named bundle (--session).
proton_session_ref_is_guest() {
    _ref="$(printf '%s' "${1:-}" | tr -d '\r\n')"
    case "$(printf '%s' "$_ref" | tr 'A-Z' 'a-z')" in
        ''|guest) return 0 ;;
        *) return 1 ;;
    esac
}

# Guest mint vs named bundle (generate.sh / proton menu). update-lists always guests.
# $1 session_mode (guest|named|empty), $2 session ref, $3 acquire-guest 1/0, $4 --session on CLI 1/0.
# Default (no mode, empty/guest/guest-* leftover): guest. Explicit --session name wins over mode=guest.
proton_session_wants_guest() {
    _mode="$(printf '%s' "${1:-}" | tr -d '\r\n' | tr 'A-Z' 'a-z')"
    _ref="$(printf '%s' "${2:-}" | tr -d '\r\n')"
    _acq="$(printf '%s' "${3:-0}" | tr -d '\r\n')"
    _cli="$(printf '%s' "${4:-0}" | tr -d '\r\n')"

    [ "$_acq" = "1" ] && return 0

    if [ "$_cli" = "1" ]; then
        proton_session_ref_is_guest "$_ref"
        return $?
    fi

    case "$_mode" in
        guest) return 0 ;;
        named) return 1 ;;
    esac

    proton_session_ref_is_guest "$_ref" && return 0
    case "$_ref" in
        guest-*) return 0 ;;
    esac
    return 1
}

proton_load_session() {
    proton_resolve_session_dir

    PROTON_UID_FILE="$(proton_session_uid_file)"
    PROTON_COOKIE_JAR="$(proton_session_cookie_file)"
    PROTON_ACCESS_TOKEN_FILE="$(proton_session_access_token_file)"
    PROTON_REFRESH_TOKEN_FILE="$(proton_session_refresh_token_file)"
    PROTON_AUTH_MODE_FILE="$(proton_session_auth_mode_file)"

    [ -d "$PROTON_SESSION_DIR" ] || die "Не найден каталог Proton session: $PROTON_SESSION_DIR"
    [ -f "$PROTON_UID_FILE" ] || die "Не найден x_pm_uid.txt: $PROTON_UID_FILE"

    PROTON_X_PM_UID="$(head -n1 "$PROTON_UID_FILE" | tr -d '\r\n')"
    [ -n "$PROTON_X_PM_UID" ] || die "x_pm_uid.txt пустой: $PROTON_UID_FILE"

    PROTON_AUTH_MODE="$(proton_session_auth_mode_from_dir "$PROTON_SESSION_DIR")"
    [ -n "$PROTON_AUTH_MODE" ] || die "Не удалось определить auth mode сессии: $PROTON_SESSION_DIR"

    PROTON_APPVERSION_FILE="$(proton_session_appversion_file)"
    if [ -f "$PROTON_APPVERSION_FILE" ]; then
        session_appversion="$(head -n1 "$PROTON_APPVERSION_FILE" | tr -d '\r\n')"
        [ -n "$session_appversion" ] && PROTON_X_PM_APPVERSION="$session_appversion"
    fi

    PROTON_ACCESS_TOKEN=""
    PROTON_REFRESH_TOKEN=""
    case "$PROTON_AUTH_MODE" in
        guest)
            [ -f "$PROTON_ACCESS_TOKEN_FILE" ] || die "Не найден access_token.txt: $PROTON_ACCESS_TOKEN_FILE"
            [ -f "$PROTON_REFRESH_TOKEN_FILE" ] || die "Не найден refresh_token.txt: $PROTON_REFRESH_TOKEN_FILE"
            PROTON_ACCESS_TOKEN="$(head -n1 "$PROTON_ACCESS_TOKEN_FILE" | tr -d '\r\n')"
            PROTON_REFRESH_TOKEN="$(head -n1 "$PROTON_REFRESH_TOKEN_FILE" | tr -d '\r\n')"
            [ -n "$PROTON_ACCESS_TOKEN" ] || die "access_token.txt пустой: $PROTON_ACCESS_TOKEN_FILE"
            [ -n "$PROTON_REFRESH_TOKEN" ] || die "refresh_token.txt пустой: $PROTON_REFRESH_TOKEN_FILE"
            [ -n "${PROTON_X_PM_APPVERSION:-}" ] || PROTON_X_PM_APPVERSION="$PROTON_GUEST_APPVERSION"
            ;;
        web)
            [ -f "$PROTON_COOKIE_JAR" ] || die "Не найден cookies.txt: $PROTON_COOKIE_JAR"
            ;;
        *)
            die "Неизвестный Proton auth mode: $PROTON_AUTH_MODE"
            ;;
    esac
}

proton_show_loaded_session() {
    info "Proton session: $PROTON_SESSION_DIR (auth=$PROTON_AUTH_MODE)"
    debug "Cookie jar: $PROTON_COOKIE_JAR"
    debug "x-pm-uid file: $PROTON_UID_FILE"
    debug "access token file: ${PROTON_ACCESS_TOKEN_FILE:-}"
}

proton_debug_block() {
    title="$1"
    file="$2"
    [ -f "$file" ] || return 0
    debug "=== $title ==="
    while IFS= read -r line || [ -n "$line" ]; do
        debug "$line"
    done < "$file"
}

proton_curl_ip_arg() {
    case "${PROTON_CURL_IP_VERSION:-}" in
        4) printf '%s\n' "-4" ;;
        6) printf '%s\n' "-6" ;;
        *) return 0 ;;
    esac
}

proton_http_get_json() {
    url="$1"
    referer="$2"
    out="$3"
    label="${4:-request}"

    hdr="${out}.headers"
    code_file="${out}.http_code"
    rm -f "$hdr" "$code_file"

    debug "=== Proton ${label} request ==="
    debug "GET $url"
    info "Proton ${label}: GET $url"
    curl_ip_arg="$(proton_curl_ip_arg || true)"
    curl_iface_arg="$(proton_curl_interface_arg || true)"

    if [ "${PROTON_AUTH_MODE:-web}" = "guest" ]; then
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "x-pm-appversion: $PROTON_X_PM_APPVERSION" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                -H "x-pm-uid: $PROTON_X_PM_UID" \
                -H "Authorization: Bearer $PROTON_ACCESS_TOKEN" \
                -H "referer: $referer" \
                -H "origin: $PROTON_BASE_URL" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )" || {
            rc=$?
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        }
    else
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "x-pm-appversion: $PROTON_X_PM_APPVERSION" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                -H "x-pm-uid: $PROTON_X_PM_UID" \
                -H "referer: $referer" \
                -H "origin: $PROTON_BASE_URL" \
                -b "$PROTON_COOKIE_JAR" \
                -c "$PROTON_COOKIE_JAR" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )" || {
            rc=$?
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        }
    fi

    printf '%s\n' "$http_code" > "$code_file"
    info "Proton ${label}: HTTP $http_code"

    proton_debug_block "Proton ${label} response headers" "$hdr"
    proton_debug_block "Proton ${label} response body" "$out"

    case "$http_code" in
        2??) return 0 ;;
    esac

    debug "HTTP code: $http_code"
    warn "Proton ${label}: неожиданный HTTP code $http_code"
    return 22
}

# Authenticated JSON DELETE (e.g. certificate revocation).
proton_http_delete_json() {
    url="$1"
    referer="$2"
    body_file="$3"
    out="$4"
    label="${5:-delete}"

    hdr="${out}.headers"
    code_file="${out}.http_code"
    rm -f "$hdr" "$code_file"

    debug "=== Proton ${label} request ==="
    debug "DELETE $url"
    proton_debug_block "Proton ${label} request body" "$body_file"
    info "Proton ${label}: DELETE $url"
    curl_ip_arg="$(proton_curl_ip_arg || true)"
    curl_iface_arg="$(proton_curl_interface_arg || true)"

    if [ "${PROTON_AUTH_MODE:-web}" = "guest" ]; then
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                -X DELETE \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "content-type: application/json" \
                -H "x-pm-appversion: $PROTON_X_PM_APPVERSION" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                -H "x-pm-uid: $PROTON_X_PM_UID" \
                -H "Authorization: Bearer $PROTON_ACCESS_TOKEN" \
                -H "referer: $referer" \
                -H "origin: $PROTON_BASE_URL" \
                --data @"$body_file" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )" || {
            rc=$?
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        }
    else
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                -X DELETE \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "content-type: application/json" \
                -H "x-pm-appversion: $PROTON_X_PM_APPVERSION" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                -H "x-pm-uid: $PROTON_X_PM_UID" \
                -H "referer: $referer" \
                -H "origin: $PROTON_BASE_URL" \
                -b "$PROTON_COOKIE_JAR" \
                -c "$PROTON_COOKIE_JAR" \
                --data @"$body_file" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )" || {
            rc=$?
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        }
    fi

    printf '%s\n' "$http_code" > "$code_file"
    info "Proton ${label}: HTTP $http_code"

    case "$http_code" in
        2??) return 0 ;;
    esac

    debug "HTTP code: $http_code"
    warn "Proton ${label}: неожиданный HTTP code $http_code"
    return 22
}

proton_http_post_json() {
    url="$1"
    referer="$2"
    body_file="$3"
    out="$4"
    label="${5:-request}"

    hdr="${out}.headers"
    code_file="${out}.http_code"
    rm -f "$hdr" "$code_file"

    debug "=== Proton ${label} request ==="
    debug "POST $url"
    proton_debug_block "Proton ${label} request body" "$body_file"
    info "Proton ${label}: POST $url"
    curl_ip_arg="$(proton_curl_ip_arg || true)"
    curl_iface_arg="$(proton_curl_interface_arg || true)"

    if [ "${PROTON_AUTH_MODE:-web}" = "guest" ]; then
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "content-type: application/json" \
                -H "x-pm-appversion: $PROTON_X_PM_APPVERSION" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                -H "x-pm-uid: $PROTON_X_PM_UID" \
                -H "Authorization: Bearer $PROTON_ACCESS_TOKEN" \
                -H "referer: $referer" \
                -H "origin: $PROTON_BASE_URL" \
                --data @"$body_file" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )" || {
            rc=$?
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        }
    else
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "content-type: application/json" \
                -H "x-pm-appversion: $PROTON_X_PM_APPVERSION" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                -H "x-pm-uid: $PROTON_X_PM_UID" \
                -H "referer: $referer" \
                -H "origin: $PROTON_BASE_URL" \
                -b "$PROTON_COOKIE_JAR" \
                -c "$PROTON_COOKIE_JAR" \
                --data @"$body_file" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )" || {
            rc=$?
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        }
    fi

    printf '%s\n' "$http_code" > "$code_file"
    info "Proton ${label}: HTTP $http_code"

    proton_debug_block "Proton ${label} response headers" "$hdr"
    proton_debug_block "Proton ${label} response body" "$out"

    case "$http_code" in
        2??) return 0 ;;
    esac

    debug "HTTP code: $http_code"
    warn "Proton ${label}: неожиданный HTTP code $http_code"
    return 22
}

# Authenticated JSON DELETE (e.g. certificate revocation).
proton_http_delete_json() {
    url="$1"
    referer="$2"
    body_file="$3"
    out="$4"
    label="${5:-delete}"

    hdr="${out}.headers"
    code_file="${out}.http_code"
    rm -f "$hdr" "$code_file"

    debug "=== Proton ${label} request ==="
    debug "DELETE $url"
    proton_debug_block "Proton ${label} request body" "$body_file"
    info "Proton ${label}: DELETE $url"
    curl_ip_arg="$(proton_curl_ip_arg || true)"
    curl_iface_arg="$(proton_curl_interface_arg || true)"

    if [ "${PROTON_AUTH_MODE:-web}" = "guest" ]; then
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                -X DELETE \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "content-type: application/json" \
                -H "x-pm-appversion: $PROTON_X_PM_APPVERSION" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                -H "x-pm-uid: $PROTON_X_PM_UID" \
                -H "Authorization: Bearer $PROTON_ACCESS_TOKEN" \
                -H "referer: $referer" \
                -H "origin: $PROTON_BASE_URL" \
                --data @"$body_file" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )" || {
            rc=$?
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        }
    else
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                -X DELETE \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "content-type: application/json" \
                -H "x-pm-appversion: $PROTON_X_PM_APPVERSION" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                -H "x-pm-uid: $PROTON_X_PM_UID" \
                -H "referer: $referer" \
                -H "origin: $PROTON_BASE_URL" \
                -b "$PROTON_COOKIE_JAR" \
                -c "$PROTON_COOKIE_JAR" \
                --data @"$body_file" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )" || {
            rc=$?
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        }
    fi

    printf '%s\n' "$http_code" > "$code_file"
    info "Proton ${label}: HTTP $http_code"

    case "$http_code" in
        2??) return 0 ;;
    esac

    debug "HTTP code: $http_code"
    warn "Proton ${label}: неожиданный HTTP code $http_code"
    return 22
}

# Unauthenticated JSON POST (guest bootstrap: /auth/v4/sessions).
proton_http_post_json_unauth() {
    url="$1"
    body_file="$2"
    out="$3"
    label="${4:-request}"
    appversion="${5:-$PROTON_X_PM_APPVERSION}"

    hdr="${out}.headers"
    code_file="${out}.http_code"
    rm -f "$hdr" "$code_file"

    debug "=== Proton ${label} request (unauth) ==="
    debug "POST $url"
    proton_debug_block "Proton ${label} request body" "$body_file"
    info "Proton ${label}: POST $url"
    curl_ip_arg="$(proton_curl_ip_arg || true)"
    curl_iface_arg="$(proton_curl_interface_arg || true)"

    attempt=0
    max_attempts="${PROTON_CURL_CONNECT_RETRIES:-3}"
    rc=0
    http_code=""
    while [ "$attempt" -lt "$max_attempts" ]; do
        attempt=$((attempt + 1))
        set +e
        http_code="$(
            curl -sS -L \
                $curl_ip_arg \
                $curl_iface_arg \
                --connect-timeout "$PROTON_CURL_CONNECT_TIMEOUT" \
                --max-time "$PROTON_CURL_MAX_TIME" \
                -A "$PROTON_API_USER_AGENT" \
                -H "accept: $PROTON_API_ACCEPT" \
                -H "content-type: application/json" \
                -H "x-pm-appversion: $appversion" \
                -H "x-pm-locale: $PROTON_X_PM_LOCALE" \
                --data @"$body_file" \
                -D "$hdr" \
                -o "$out" \
                -w '%{http_code}' \
                "$url"
        )"
        rc=$?
        set -e
        [ "$rc" -eq 0 ] && break
        if [ "$rc" -ne 28 ] || [ "$attempt" -ge "$max_attempts" ]; then
            warn "Proton ${label}: curl завершился с ошибкой rc=$rc"
            return 1
        fi
        warn "Proton ${label}: timeout (rc=28), повтор ${attempt}/${max_attempts}…"
        sleep 2
    done

    printf '%s\n' "$http_code" > "$code_file"
    info "Proton ${label}: HTTP $http_code"
    proton_debug_block "Proton ${label} response headers" "$hdr"
    proton_debug_block "Proton ${label} response body" "$out"

    case "$http_code" in
        2??) return 0 ;;
    esac
    warn "Proton ${label}: неожиданный HTTP code $http_code"
    return 22
}

proton_http_post_empty_json() {
    url="$1"
    referer="$2"
    out="$3"
    label="${4:-request}"

    hdr="${out}.headers"
    code_file="${out}.http_code"
    body_file="${out}.request.json"
    rm -f "$hdr" "$code_file" "$body_file"
    printf '{}\n' > "$body_file"

    proton_http_post_json "$url" "$referer" "$body_file" "$out" "$label"
}

proton_guest_write_bundle() {
    dir="$1"
    uid="$2"
    access="$3"
    refresh="$4"
    appversion="${5:-$PROTON_GUEST_APPVERSION}"

    mkdir -p "$dir" || die "Не удалось создать каталог гостевой сессии: $dir"
    printf '%s\n' "guest" > "$dir/auth_mode.txt"
    printf '%s\n' "$uid" > "$dir/x_pm_uid.txt"
    printf '%s\n' "$access" > "$dir/access_token.txt"
    printf '%s\n' "$refresh" > "$dir/refresh_token.txt"
    printf '%s\n' "$appversion" > "$dir/x_pm_appversion.txt"
}

# Create credentialless (guest) session under PROTON_SESSIONS_DIR (or $1).
# Prints session name on success. Shared by router and profile-generator.
proton_guest_acquire_session() {
    dest_root="${1:-$PROTON_SESSIONS_DIR}"
    name_override="${2:-}"

    vpn_json_require_parser
    mkdir -p "$dest_root" || die "Не удалось создать каталог сессий: $dest_root"

    guest_app="${PROTON_GUEST_APPVERSION:-android-vpn@5.20.98.0}"
    body="$PROTON_WORKDIR/guest.sessions.req.json"
    sess_out="$PROTON_WORKDIR/guest.sessions.json"
    cred_out="$PROTON_WORKDIR/guest.credentialless.json"
    printf '{}\n' > "$body"

    info "Proton: регистрация гостевой сессии..."
    proton_http_post_json_unauth \
        "$PROTON_BASE_URL/api/auth/v4/sessions" \
        "$body" \
        "$sess_out" \
        "guest-sessions" \
        "$guest_app" || die "Не удалось создать анонимную Proton-сессию"

    PROTON_JSON_SOURCE="$sess_out"
    code="$(proton_json_get '@.Code')"
    case "$code" in
        1000|0) ;;
        *) die "Proton guest sessions: Code=${code:-unknown}" ;;
    esac

    anon_access="$(proton_json_get '@.AccessToken')"
    anon_uid="$(proton_json_get '@.UID')"
    [ -n "$anon_access" ] && [ -n "$anon_uid" ] || die "Proton guest sessions: пустой AccessToken/UID"

    PROTON_AUTH_MODE=guest
    PROTON_ACCESS_TOKEN="$anon_access"
    PROTON_X_PM_UID="$anon_uid"
    PROTON_X_PM_APPVERSION="$guest_app"

    info "Proton: авторизация гостевой сессии..."
    proton_http_post_empty_json \
        "$PROTON_BASE_URL/api/auth/v4/credentialless" \
        "$PROTON_BASE_URL/" \
        "$cred_out" \
        "guest-credentialless" || die "Не удалось выполнить credentialless upgrade"

    PROTON_JSON_SOURCE="$cred_out"
    code="$(proton_json_get '@.Code')"
    case "$code" in
        1000|0) ;;
        *) die "Proton guest credentialless: Code=${code:-unknown}" ;;
    esac

    access="$(proton_json_get '@.AccessToken')"
    refresh="$(proton_json_get '@.RefreshToken')"
    uid="$(proton_json_get '@.UID')"
    [ -n "$access" ] && [ -n "$refresh" ] && [ -n "$uid" ] || die "Proton guest credentialless: пустые токены"

    if [ -n "$name_override" ]; then
        name="$name_override"
    else
        name="guest-$(date -u +%Y%m%d-%H%M%S)"
    fi
    case "$name" in
        .|..|*[\\/]*) die "Некорректное имя гостевой сессии: $name" ;;
    esac

    dest="$dest_root/$name"
    proton_guest_write_bundle "$dest" "$uid" "$access" "$refresh" "$guest_app"

    PROTON_SESSION_DIR="$dest"
    PROTON_SELECTED_SESSION_NAME="$name"
    PROTON_ACCESS_TOKEN="$access"
    PROTON_REFRESH_TOKEN="$refresh"
    PROTON_X_PM_UID="$uid"
    PROTON_AUTH_MODE=guest

    if [ -n "${PROTON_GUEST_NAME_FILE:-}" ]; then
        printf '%s\n' "$name" > "$PROTON_GUEST_NAME_FILE"
    fi

    info "Proton guest session сохранена: $dest"
    printf '%s\n' "$name"
}

proton_guest_refresh_session() {
    vpn_json_require_parser
    [ "${PROTON_AUTH_MODE:-}" = "guest" ] || die "proton_guest_refresh_session: ожидался auth_mode=guest"
    [ -n "${PROTON_REFRESH_TOKEN:-}" ] && [ -n "${PROTON_X_PM_UID:-}" ] || die "Нет refresh token/uid для guest refresh"

    body="$PROTON_WORKDIR/guest.refresh.req.json"
    out="$PROTON_AUTH_REFRESH_JSON"
    # Minimal body that Proton accepts for token refresh.
    printf '{"UID":"%s","RefreshToken":"%s","ResponseType":"token","GrantType":"refresh_token"}\n' \
        "$PROTON_X_PM_UID" "$PROTON_REFRESH_TOKEN" > "$body"

    info "Обновление Proton guest tokens (auth/v4/refresh)"
    # Refresh accepts Bearer of current access token; also works with x-pm-uid only in some paths —
    # keep guest mode so Authorization is sent.
    if ! proton_http_post_json \
        "$PROTON_BASE_URL/api/auth/v4/refresh" \
        "$PROTON_BASE_URL/" \
        "$body" \
        "$out" \
        "guest-auth-refresh"; then
        return 1
    fi

    PROTON_JSON_SOURCE="$out"
    code="$(proton_json_get '@.Code')"
    case "$code" in
        1000|0) ;;
        *)
            warn "Proton guest refresh: Code=${code:-unknown}"
            return 1
            ;;
    esac

    new_access="$(proton_json_get '@.AccessToken')"
    new_refresh="$(proton_json_get '@.RefreshToken')"
    [ -n "$new_access" ] || {
        warn "Proton guest refresh: пустой AccessToken"
        return 1
    }
    [ -n "$new_refresh" ] || new_refresh="$PROTON_REFRESH_TOKEN"

    PROTON_ACCESS_TOKEN="$new_access"
    PROTON_REFRESH_TOKEN="$new_refresh"
    printf '%s\n' "$PROTON_ACCESS_TOKEN" > "$(proton_session_access_token_file)"
    printf '%s\n' "$PROTON_REFRESH_TOKEN" > "$(proton_session_refresh_token_file)"
    printf '%s\n' "guest" > "$(proton_session_auth_mode_file)"
    printf '%s\n' "$PROTON_X_PM_UID" > "$(proton_session_uid_file)"
    printf '%s\n' "$PROTON_X_PM_APPVERSION" > "$(proton_session_appversion_file)"

    info "Proton guest tokens обновлены"
    proton_sync_session_mirrors_after_refresh
    return 0
}

proton_refresh_session() {
    case "$PROTON_REFRESH_BEFORE_AUTH" in
        1|yes|YES|true|TRUE) ;;
        *) return 0 ;;
    esac

    if [ "${PROTON_AUTH_MODE:-web}" = "guest" ]; then
        if proton_guest_refresh_session; then
            return 0
        fi
        case "$PROTON_REFRESH_FAIL_HARD" in
            1|yes|YES|true|TRUE)
                die "Не удалось обновить Proton guest tokens"
                ;;
            *)
                warn "Не удалось обновить Proton guest tokens; пробую текущую сессию"
                return 0
                ;;
        esac
    fi

    info "Обновление Proton auth cookies"
    if proton_http_post_empty_json \
        "$PROTON_BASE_URL/api/auth/refresh" \
        "$PROTON_BASE_URL/dashboard" \
        "$PROTON_AUTH_REFRESH_JSON" \
        "auth-refresh"; then
        info "Proton auth cookies обновлены"
        proton_sync_session_mirrors_after_refresh
        return 0
    fi

    case "$PROTON_REFRESH_FAIL_HARD" in
        1|yes|YES|true|TRUE)
            die "Не удалось обновить Proton auth cookies"
            ;;
        *)
            warn "Не удалось обновить Proton auth cookies; пробую текущую сессию"
            return 0
            ;;
    esac
}

proton_json_get() {
    vpn_json_get_file "$1" "$PROTON_JSON_SOURCE"
}

proton_require_auth() {
    proton_load_session
    proton_show_loaded_session
    proton_refresh_session
    proton_verify_auth
}

# После proton_load_session (и при необходимости proton_refresh_session).
# web: GET /users; guest: GET certificate/key/EC (у guest нет scope settings для /users).
proton_verify_auth() {
    if [ "${PROTON_AUTH_MODE:-web}" = "guest" ]; then
        tmp="$PROTON_WORKDIR/guest.authcheck.json"
        proton_http_get_json \
            "$PROTON_BASE_URL/api/vpn/v1/certificate/key/EC" \
            "$PROTON_BASE_URL/" \
            "$tmp" \
            "guest-auth" || die "Не удалось проверить гостевую авторизацию Proton"

        PROTON_JSON_SOURCE="$tmp"
        code="$(proton_json_get '@.Code')"
        [ -n "$code" ] || code="0"
        case "$code" in
            1000|0)
                debug "Proton guest auth code: $code"
                ;;
            *)
                die "Проверка гостевой авторизации Proton неуспешна (Code=$code)"
                ;;
        esac
        return 0
    fi

    tmp="$PROTON_WORKDIR/users.json"
    proton_http_get_json \
        "$PROTON_BASE_URL/api/core/v4/users" \
        "$PROTON_BASE_URL/dashboard" \
        "$tmp" \
        "auth" || die "Не удалось проверить авторизацию Proton"

    PROTON_JSON_SOURCE="$tmp"
    code="$(proton_json_get '@.Code')"
    [ -n "$code" ] || code="0"

    case "$code" in
        1000|0)
            debug "Proton auth code: $code"
            ;;
        *)
            die "Проверка авторизации Proton неуспешна (Code=$code)"
            ;;
    esac
}

proton_fetch_logicals() {
    proton_http_get_json \
        "$PROTON_BASE_URL/api/vpn/v1/logicals?WithIpV6=1" \
        "$PROTON_BASE_URL/downloads" \
        "$PROTON_LOGICALS_JSON" \
        "logicals" || die "Не удалось получить список серверов Proton"

    [ -s "$PROTON_LOGICALS_JSON" ] || die "logicals.json пустой"
}

# Endpoint handshake stays IPv4; bracket IPv6 only if peer_ip itself is v6.
proton_format_wg_endpoint() {
    host="$1"
    port="${2:-$PROTON_WG_PEER_PORT}"
    case "$port" in
        auto|probe|''|*[!0-9]*) port="${PROTON_DEFAULT_PORT:-51820}" ;;
    esac
    [ -n "$host" ] || return 1
    case "$host" in
        *:*) printf '[%s]:%s\n' "$host" "$port" ;;
        *) printf '%s:%s\n' "$host" "$port" ;;
    esac
}

# Fill WG_ADDRESS / WG_DNS / WG_ALLOWED_IPS / WG_ENDPOINT from the selected logical.
# IPv6 in Address/AllowedIPs when the server has IPv6; Endpoint remains the IPv4 EntryIP.
proton_awg_apply_tunnel_addrs() {
    peer_ip="${PROTON_SELECTED_PEER_IP:-}"
    has_v6="${PROTON_SELECTED_HAS_IPV6:-0}"
    case "$has_v6" in
        1|yes|YES|true|TRUE) has_v6=1 ;;
        *) has_v6=0 ;;
    esac
    [ -n "${PROTON_SELECTED_PEER_IPV6:-}" ] && has_v6=1

    WG_ENDPOINT="$(proton_format_wg_endpoint "$peer_ip" "$PROTON_WG_PEER_PORT")"
    if [ "$has_v6" = "1" ]; then
        WG_ADDRESS="${PROTON_WG_CLIENT_IPV4}, ${PROTON_WG_CLIENT_IPV6}"
        WG_ALLOWED_IPS="0.0.0.0/0, ::/0"
        WG_DNS="${PROTON_WG_DNS}, ${PROTON_WG_DNS_IPV6}"
    else
        WG_ADDRESS="$PROTON_WG_CLIENT_IPV4"
        WG_ALLOWED_IPS="0.0.0.0/0"
        WG_DNS="$PROTON_WG_DNS"
    fi
}

proton_build_server_table() {
    : > "$PROTON_LOGICALS_TABLE"
    use_free_only="$PROTON_USE_FREE_ONLY"
    case "$use_free_only" in
        1|yes|YES|true|TRUE) use_free_only=1 ;;
        0|no|NO|false|FALSE) use_free_only=0 ;;
        *) use_free_only=1 ;;
    esac
    require_ipv6="$PROTON_REQUIRE_IPV6"
    case "$require_ipv6" in
        1|yes|YES|true|TRUE) require_ipv6=1 ;;
        0|no|NO|false|FALSE) require_ipv6=0 ;;
        *) require_ipv6=0 ;;
    esac

    jq -r '
        def nonempty: . != null and . != "";
        def is_v6_str: type == "string" and contains(":");
        def is_v4_str: type == "string" and (. != "") and (contains(":") | not);
        def first_ipv4:
            if is_v4_str then .
            elif type == "array" then ([.[]? | select(is_v4_str)][0] // empty)
            else empty end;
        def first_ipv6:
            if is_v6_str then .
            elif type == "array" then ([.[]? | select(is_v6_str)][0] // empty)
            else empty end;
        def server_has_v6:
            (.EntryIPv6 | is_v6_str)
            or (.ExitIPv6 | is_v6_str)
            or ((.EntryIP | first_ipv6) | nonempty)
            or ((.ExitIP | first_ipv6) | nonempty);
        .LogicalServers[]
        | . as $ls
        | ($ls.Servers[0] // {}) as $peer
        | (
            if ($ls | has("Tier")) and ($ls.Tier != null) then $ls.Tier
            else -1
            end
          ) as $tier
        | (
            ([ $ls.Servers[]? | select(server_has_v6) ] | length) > 0
            or ((($ls.Features // 0) / 16 | floor) % 2 == 1)
          ) as $has_v6
        | [
            ($ls.ID // ""),
            ($ls.Name // ""),
            ($ls.ExitCountry // ""),
            ($ls.City // ""),
            (($ls.Load // 99999) | tostring),
            (($ls.Score // 0) | tostring),
            ($peer.Name // $peer.ServerName // $peer.Domain // $ls.Name // ""),
            (($peer.EntryIP | first_ipv4) // ($peer.ExitIP | first_ipv4) // ""),
            ($peer.X25519PublicKey // ""),
            ($tier | tostring),
            (if $has_v6 then "1" else "0" end),
            (
              (if ($peer.EntryIPv6 | is_v6_str) then $peer.EntryIPv6 else empty end)
              // ($peer.EntryIP | first_ipv6)
              // (if ($peer.ExitIPv6 | is_v6_str) then $peer.ExitIPv6 else empty end)
              // ($peer.ExitIP | first_ipv6)
              // ""
            )
          ]
        | @tsv
    ' "$PROTON_LOGICALS_JSON" \
    | awk -F '\t' -v country="$PROTON_COUNTRY_FILTER" -v free_only="$use_free_only" -v require_ipv6="$require_ipv6" '
        country != "" && country != "AUTO" && toupper($3) != country { next }
        free_only == 1 && $10 != "0" { next }
        require_ipv6 == 1 && $11 != "1" { next }
        { print }
    ' > "$PROTON_LOGICALS_TABLE"

    _disp_country="$PROTON_COUNTRY_FILTER"
    [ -n "$_disp_country" ] || _disp_country="AUTO"
    if [ "$use_free_only" = "1" ]; then
        info "Фильтр Proton: страна=$_disp_country, только бесплатные (явный Tier=0)"
    else
        info "Фильтр Proton: страна=$_disp_country, все tier"
    fi
    if [ "$require_ipv6" = "1" ]; then
        info "Фильтр Proton: только серверы с IPv6 (EntryIPv6/ExitIPv6 или Features)"
    else
        info "Фильтр Proton: все адреса (IPv4 и IPv6)"
    fi

    if [ ! -s "$PROTON_LOGICALS_TABLE" ]; then
        if [ "$require_ipv6" = "1" ]; then
            die "Серверы Proton с IPv6 для страны $PROTON_COUNTRY_FILTER не найдены"
        fi
        if [ "$use_free_only" = "1" ]; then
            die "Free-серверы Proton для страны $PROTON_COUNTRY_FILTER не найдены (нужен явный Tier=0)"
        fi
        die "Серверы Proton для страны $PROTON_COUNTRY_FILTER не найдены"
    fi
    sort -t "$(printf '\t')" -k5,5n -k6,6nr "$PROTON_LOGICALS_TABLE" -o "$PROTON_LOGICALS_TABLE"
}

# Страны logicals с теми же фильтрами, что proton_build_server_table (без country).
proton_list_country_codes_from_logicals() {
    use_free_only="$PROTON_USE_FREE_ONLY"
    case "$use_free_only" in
        1|yes|YES|true|TRUE) use_free_only=1 ;;
        0|no|NO|false|FALSE) use_free_only=0 ;;
        *) use_free_only=1 ;;
    esac
    require_ipv6="$PROTON_REQUIRE_IPV6"
    case "$require_ipv6" in
        1|yes|YES|true|TRUE) require_ipv6=1 ;;
        0|no|NO|false|FALSE) require_ipv6=0 ;;
        *) require_ipv6=0 ;;
    esac

    jq -r --argjson free_only "$use_free_only" --argjson require_ipv6 "$require_ipv6" '
        def nonempty: . != null and . != "";
        def is_v6_str: type == "string" and contains(":");
        def first_ipv6:
            if is_v6_str then .
            elif type == "array" then ([.[]? | select(is_v6_str)][0] // empty)
            else empty end;
        def server_has_v6:
            (.EntryIPv6 | is_v6_str)
            or (.ExitIPv6 | is_v6_str)
            or ((.EntryIP | first_ipv6) | nonempty)
            or ((.ExitIP | first_ipv6) | nonempty);
        .LogicalServers[]
        | select((($free_only == 0) or ((has("Tier")) and (.Tier == 0))))
        | select(
            ($require_ipv6 == 0)
            or (([.Servers[]? | select(server_has_v6)] | length) > 0)
            or (((.Features // 0) / 16 | floor) % 2 == 1)
          )
        | (.ExitCountry // "")
    ' "$PROTON_LOGICALS_JSON"
}

proton_select_server_interactive() {
    awk -F '\t' '
        {
            printf "%3d) id=%s  name=%-22s country=%-2s city=%-16s load=%-6s ipv6=%s score=%s\n",
                NR, $1, $2, $3, $4, $5, ($11 == "1" ? "yes" : "no"), $6
        }
    ' "$PROTON_LOGICALS_TABLE"

    printf "Выберите сервер [1-%s]: " "$(wc -l < "$PROTON_LOGICALS_TABLE")" >&2
    read -r choice

    case "$choice" in
        ''|*[!0-9]*) die "Некорректный выбор сервера" ;;
    esac

    line="$(sed -n "${choice}p" "$PROTON_LOGICALS_TABLE")"
    [ -n "$line" ] || die "Выбор сервера вне диапазона"
    printf '%s\n' "$line"
}

proton_apply_selected_tsv() {
    selected="$1"
    [ -n "$selected" ] || return 1

    PROTON_SELECTED_ID="$(printf '%s\n' "$selected" | awk -F '\t' '{print $1}')"
    PROTON_SELECTED_NAME="$(printf '%s\n' "$selected" | awk -F '\t' '{print $2}')"
    PROTON_SELECTED_COUNTRY="$(printf '%s\n' "$selected" | awk -F '\t' '{print $3}')"
    PROTON_SELECTED_CITY="$(printf '%s\n' "$selected" | awk -F '\t' '{print $4}')"
    PROTON_SELECTED_LOAD="$(printf '%s\n' "$selected" | awk -F '\t' '{print $5}')"
    PROTON_SELECTED_SCORE="$(printf '%s\n' "$selected" | awk -F '\t' '{print $6}')"
    PROTON_SELECTED_PEER_NAME="$(printf '%s\n' "$selected" | awk -F '\t' '{print $7}')"
    PROTON_SELECTED_PEER_IP="$(printf '%s\n' "$selected" | awk -F '\t' '{print $8}')"
    PROTON_SELECTED_PEER_PUBLIC_KEY="$(printf '%s\n' "$selected" | awk -F '\t' '{print $9}')"
    PROTON_SELECTED_HAS_IPV6="$(printf '%s\n' "$selected" | awk -F '\t' '{print $11}')"
    PROTON_SELECTED_PEER_IPV6="$(printf '%s\n' "$selected" | awk -F '\t' '{print $12}')"
    case "$PROTON_SELECTED_HAS_IPV6" in
        1|yes|YES|true|TRUE) PROTON_SELECTED_HAS_IPV6=1 ;;
        *) PROTON_SELECTED_HAS_IPV6=0 ;;
    esac
    [ -n "$PROTON_SELECTED_PEER_IPV6" ] && PROTON_SELECTED_HAS_IPV6=1

    [ -n "$PROTON_SELECTED_NAME" ] || PROTON_SELECTED_NAME="$PROTON_SELECTED_PEER_NAME"
    [ -n "$PROTON_SELECTED_NAME" ] || PROTON_SELECTED_NAME="id-${PROTON_SELECTED_ID:-unknown}"
    [ -n "$PROTON_SELECTED_COUNTRY" ] || PROTON_SELECTED_COUNTRY="$PROTON_COUNTRY_FILTER"

    export PROTON_SELECTED_ID PROTON_SELECTED_NAME PROTON_SELECTED_COUNTRY PROTON_SELECTED_CITY \
           PROTON_SELECTED_LOAD PROTON_SELECTED_SCORE PROTON_SELECTED_PEER_NAME PROTON_SELECTED_PEER_IP \
           PROTON_SELECTED_PEER_PUBLIC_KEY PROTON_SELECTED_HAS_IPV6 PROTON_SELECTED_PEER_IPV6
}

proton_probe_candidates_and_select() {
    if ! command -v wg_probe_is_supported >/dev/null 2>&1 || ! wg_probe_is_supported; then
        info_err "[-] Проверка рукопожатия WireGuard не поддерживается ядром на этом хосте, выбран сервер по умолчанию."
        _first_cand="$(head -n 1 "$PROTON_LOGICALS_TABLE")"
        proton_apply_selected_tsv "$_first_cand"
        return 0
    fi

    _top_n="${PROTON_PROBE_TOP_N:-3}"
    case "$_top_n" in ''|*[!0-9]*) _top_n=3 ;; esac
    [ "$_top_n" -gt 0 ] || _top_n=3

    _rounds="${PROTON_PROBE_ROUNDS:-5}"
    case "$_rounds" in ''|*[!0-9]*) _rounds=5 ;; esac

    if [ "$_rounds" -eq 0 ]; then
        _max_cands=9999
    else
        _max_cands=$(( _top_n * _rounds ))
    fi

    _req_v6="${PROTON_REQUIRE_IPV6:-0}"
    case "$_req_v6" in
        1|yes|YES|true|TRUE) _req_v6=1 ;;
        *) _req_v6=0 ;;
    esac

    _cand_lines="$(awk -F '\t' -v max="$_max_cands" -v req_v6="$_req_v6" '
        NF >= 9 {
            ip = $8
            split(ip, oct, ".")
            subnet = oct[1] "." oct[2] "." oct[3]
            if (ip == "" || ip in seen_ip) next
            seen_ip[ip] = 1

            is_v6 = ($11 == "1" || $11 == "true" || $11 == "yes") ? 1 : 0
            if (req_v6 == 1 && is_v6 != 1) next

            if (is_v6 == 1) {
                if (!(subnet in seen_sub_v6)) {
                    seen_sub_v6[subnet] = 1
                    v6_p1[v6_p1_cnt++] = $0
                } else {
                    v6_p2[v6_p2_cnt++] = $0
                }
            } else {
                if (!(subnet in seen_sub_v4)) {
                    seen_sub_v4[subnet] = 1
                    v4_p1[v4_p1_cnt++] = $0
                } else {
                    v4_p2[v4_p2_cnt++] = $0
                }
            }
        }
        END {
            if (max <= 0) max = 9999

            v6_total = 0
            for (i = 0; i < v6_p1_cnt; i++) v6_all[v6_total++] = v6_p1[i]
            for (i = 0; i < v6_p2_cnt; i++) v6_all[v6_total++] = v6_p2[i]

            v4_total = 0
            for (i = 0; i < v4_p1_cnt; i++) v4_all[v4_total++] = v4_p1[i]
            for (i = 0; i < v4_p2_cnt; i++) v4_all[v4_total++] = v4_p2[i]

            total = 0
            i6 = 0; i4 = 0

            if (req_v6 == 1) {
                while (total < max && i6 < v6_total) {
                    print v6_all[i6++]
                    total++
                }
            } else if (v6_total > 0 && v4_total > 0) {
                # При фильтре "все" (req_v6 == 0): выборка для проверки ОБЯЗАТЕЛЬНО
                # чередует серверы IPv6 и IPv4, чтобы в каждом раунде (топ-3 и др.)
                # присутствовали серверы обоих типов адресации!
                while (total < max && (i6 < v6_total || i4 < v4_total)) {
                    if (i6 < v6_total && (total % 2 == 0 || i4 >= v4_total)) {
                        print v6_all[i6++]
                        total++
                    } else if (i4 < v4_total) {
                        print v4_all[i4++]
                        total++
                    }
                }
            } else {
                while (total < max && i6 < v6_total) {
                    print v6_all[i6++]
                    total++
                }
                while (total < max && i4 < v4_total) {
                    print v4_all[i4++]
                    total++
                }
            }
        }
    ' "$PROTON_LOGICALS_TABLE")"
    [ -n "$_cand_lines" ] || _cand_lines="$(head -n "$_max_cands" "$PROTON_LOGICALS_TABLE")"

    _tune_found=0
    _srv_idx=0
    _srv_total="$(printf '%s\n' "$_cand_lines" | grep -c . || printf '1')"
    _total_rounds=$(( (_srv_total + _top_n - 1) / _top_n ))
    [ "$_total_rounds" -gt 0 ] || _total_rounds=1
    _cur_round=1
    _srv_in_round=0

    _win_var="${VARIANT:-auto}"
    [ "$_win_var" = "auto" ] && _win_var="1"
    _win_entropy="${AWG_I1_ENTROPY:-r32}"
    _win_noise="${AWG_NOISE_ENABLED:-0}"
    _win_status="FAIL"
    _win_rtt="999"
    _win_ep=""
    _win_name=""
    _win_id=""
    _chosen_tsv=""

    _req_port="${PROTON_WG_PEER_PORT:-auto}"
    case "$_req_port" in
        auto|probe|''|'*'*|*[!0-9]*)
            _test_ports="$PROTON_AUTO_PROBE_PORTS"
            ;;
        *)
            _test_ports="$_req_port"
            ;;
    esac

    while IFS="$(printf '\t')" read -r _id _name _c _city _tier _score _peer_name _peer_ip _peer_pk _tier_num _has_v6 _peer_v6 || [ -n "$_id" ]; do
        [ -n "$_peer_ip" ] && [ -n "$_peer_pk" ] || continue
        _srv_in_round=$(( _srv_in_round + 1 ))
        if [ "$_srv_in_round" -eq 1 ]; then
            _round_cands_left=$(( _srv_total - _srv_idx ))
            [ "$_round_cands_left" -gt "$_top_n" ] && _round_cands_left="$_top_n"
            info_err "=== Раунд $_cur_round/$_total_rounds: тестирование группы из $_round_cands_left серверов ==="
        fi

        _srv_idx=$((_srv_idx + 1))
        _v6_tag="$([ "$_has_v6" = "1" ] && echo " [IPv6]" || echo " [IPv4]")"
        info_err "--- Сервер [$_srv_idx/$_srv_total] (раунд $_cur_round): $_name ($_peer_ip)$_v6_tag ---"
        proton_apply_selected_tsv "$_id	$_name	$_c	$_city	$_tier	$_score	$_peer_name	$_peer_ip	$_peer_pk	$_tier_num	$_has_v6	$_peer_v6"

        info_err "Запрос клиентского сертификата для сервера $_name..."
        proton_get_keypair
        if ! proton_create_certificate "$WG_GEN_PUB"; then
            info_err "[-] Ошибка выпуска сертификата для $_name, переход к следующему серверу..."
            continue
        fi

        # Пауза для синхронизации контроллера Proton с удалённой нодой
        sleep 1 2>/dev/null || usleep 1000000 2>/dev/null || true

        case "$(common_lower_ascii "${WG_GEN_KEY_KIND:-ed25519}")" in
            x25519) WG_PRIV="$(proton_b64_pad "$WG_GEN_PRIV")" ;;
            *) WG_PRIV="$(x25519_private_from_ed25519_seed_b64 "$WG_GEN_PRIV")" ;;
        esac

        _chosen_port=""
        for _cur_test_port in $_test_ports; do
            if [ "$_cur_test_port" != "51820" ]; then
                sleep 0.3 2>/dev/null || usleep 300000 2>/dev/null || true
                info_err "  -> Проверка порта $_cur_test_port для $_name ($_peer_ip:$_cur_test_port)..."
            fi

            if [ "${VARIANT:-auto}" = "auto" ] || [ "${PROTON_AUTOTUNE:-0}" = "1" ]; then
                _cand_probe_file="${TMPDIR:-/tmp}/proton-tune-cands.$$"
                printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
                    "$_peer_ip" \
                    "$_cur_test_port" \
                    "$_peer_pk" \
                    "$_id" \
                    "$_name" \
                    "$_peer_name" > "$_cand_probe_file"

                _tune_out="$(wg_probe_tune "$WG_PRIV" "$_cand_probe_file" 1000)"
                rm -f "$_cand_probe_file"

                _status="$(printf '%s\n' "$_tune_out" | awk -F '\t' '{print $2}')"
                _rtt="$(printf '%s\n' "$_tune_out" | awk -F '\t' '{print $3}')"
                _var="$(printf '%s\n' "$_tune_out" | awk -F '\t' '{print $4}')"
                _entropy="$(printf '%s\n' "$_tune_out" | awk -F '\t' '{print $5}')"
                _noise="$(printf '%s\n' "$_tune_out" | awk -F '\t' '{print $6}')"
                _ep="$(printf '%s\n' "$_tune_out" | awk -F '\t' '{print $7}')"

                if [ "$_status" = "OK" ]; then
                    _tune_found=1
                    _chosen_port="$_cur_test_port"
                    _win_var="$_var"
                    _win_entropy="$_entropy"
                    _win_noise="$_noise"
                    _win_status="OK"
                    _win_rtt="$_rtt"
                    _win_ep="$_ep"
                    _win_name="$_name"
                    _win_id="$_id"
                    _chosen_tsv="$_id	$_name	$_c	$_city	$_tier	$_score	$_peer_name	$_peer_ip	$_peer_pk	$_tier_num	$_has_v6	$_peer_v6"
                    if [ "$_cur_test_port" != "51820" ]; then
                        info_err "[✓] Сервер $_name ответил на рукопожатие на альтернативном порту $_cur_test_port (${_rtt} мс)!"
                    else
                        info_err "[✓] Сервер $_name ответил на рукопожатие WireGuard (${_rtt} мс) в раунде $_cur_round! Подбор параметров завершён."
                    fi
                    break
                fi
            else
                _single_ep="${_peer_ip}:${_cur_test_port}"
                _single_res="$(wg_probe_single "$WG_PRIV" "$_single_ep" "$_peer_pk" "$VARIANT" 1200 "${AWG_NOISE_ENABLED:-0}" "${AWG_I1_ENTROPY:-r32}" || true)"
                _status="$(printf '%s\n' "$_single_res" | awk -F '\t' '{print $1}')"
                _rtt="$(printf '%s\n' "$_single_res" | awk -F '\t' '{print $2}')"

                if [ "$_status" = "OK" ]; then
                    _tune_found=1
                    _chosen_port="$_cur_test_port"
                    _win_status="OK"
                    _win_rtt="$_rtt"
                    _win_ep="$_single_ep"
                    _win_name="$_name"
                    _win_id="$_id"
                    _chosen_tsv="$_id	$_name	$_c	$_city	$_tier	$_score	$_peer_name	$_peer_ip	$_peer_pk	$_tier_num	$_has_v6	$_peer_v6"
                    if [ "$_cur_test_port" != "51820" ]; then
                        info_err "[✓] Сервер $_name ответил на рукопожатие на альтернативном порту $_cur_test_port (${_rtt} мс)!"
                    else
                        info_err "[✓] Сервер $_name ответил на рукопожатие WireGuard (${_rtt} мс) в раунде $_cur_round! Выбор завершён."
                    fi
                    break
                fi
            fi
        done

        if [ "$_tune_found" = "1" ]; then
            break
        fi

        info_err "[!] Сервер $_name не ответил на рукопожатие WireGuard (таймаут ответа на портах: $_test_ports)."
        if [ -n "${PROTON_LAST_CERT_SERIAL:-}" ]; then
            proton_revoke_certificate "$PROTON_LAST_CERT_SERIAL"
            unset PROTON_LAST_CERT_SERIAL || true
        fi
        sleep 0.5 2>/dev/null || usleep 500000 2>/dev/null || true
        if [ "$_srv_in_round" -ge "$_top_n" ] && [ "$_srv_idx" -lt "$_srv_total" ]; then
            info_err "[!] Все $_top_n серверов в раунде $_cur_round не ответили на рукопожатие. Переход к следующей группе серверов (раунд $((_cur_round + 1)))..."
            _cur_round=$(( _cur_round + 1 ))
            _srv_in_round=0
        fi
    done <<EOF_CANDS
$_cand_lines
EOF_CANDS

    if [ "$_tune_found" = "1" ]; then
        PROTON_SERVER_PROBE_SUCCEEDED=1
        PROTON_PROBE_RTT="$_win_rtt"
        VARIANT="$_win_var"
        AWG_I1_ENTROPY="$_win_entropy"
        AWG_NOISE_ENABLED="$_win_noise"
        PROTON_SELECTED_PORT="${_chosen_port:-51820}"
        PROTON_WG_PEER_PORT="$PROTON_SELECTED_PORT"
        WG_PEER_ENDPOINT="$(proton_format_wg_endpoint "$PROTON_SELECTED_PEER_IP" "$PROTON_SELECTED_PORT")"
        export PROTON_SERVER_PROBE_SUCCEEDED PROTON_PROBE_RTT VARIANT AWG_I1_ENTROPY AWG_NOISE_ENABLED PROTON_SELECTED_PORT PROTON_WG_PEER_PORT WG_PEER_ENDPOINT
        proton_apply_selected_tsv "$_chosen_tsv"
    else
        warn "Proton: проверено $_srv_total серверов ($_cur_round раундов), ни один не ответил на рукопожатие WireGuard, выбран сервер по умолчанию"
        _first_cand="$(printf '%s\n' "$_cand_lines" | head -n 1)"
        [ -n "$_first_cand" ] || _first_cand="$(head -n 1 "$PROTON_LOGICALS_TABLE")"
        PROTON_SELECTED_PORT="${_req_port:-51820}"
        [ "$PROTON_SELECTED_PORT" = "auto" ] && PROTON_SELECTED_PORT="51820"
        PROTON_WG_PEER_PORT="$PROTON_SELECTED_PORT"
        export PROTON_SELECTED_PORT PROTON_WG_PEER_PORT
        proton_apply_selected_tsv "$_first_cand"
    fi
}

proton_select_server() {
    if [ -n "${PROTON_TARGET_SERVER:-}" ] && [ -s "$PROTON_LOGICALS_TABLE" ]; then
        _target_line="$(grep -F "$PROTON_TARGET_SERVER" "$PROTON_LOGICALS_TABLE" | head -n 1 || true)"
        if [ -n "$_target_line" ]; then
            info "Proton: выбран целевой сервер $PROTON_TARGET_SERVER"
            PROTON_SELECTED_PORT="${PROTON_WG_PEER_PORT:-51820}"
            case "$PROTON_SELECTED_PORT" in
                auto|probe|'') PROTON_SELECTED_PORT="51820" ;;
            esac
            PROTON_WG_PEER_PORT="$PROTON_SELECTED_PORT"
            export PROTON_SELECTED_PORT PROTON_WG_PEER_PORT
            proton_apply_selected_tsv "$_target_line"
            WG_PEER_ENDPOINT="$(proton_format_wg_endpoint "$PROTON_SELECTED_PEER_IP" "$PROTON_SELECTED_PORT")"
            export WG_PEER_ENDPOINT
            return 0
        else
            warn "Proton: целевой сервер «$PROTON_TARGET_SERVER» не найден в актуальном списке нод, переход к подбору"
        fi
    fi

    case "$PROTON_SELECTION_MODE" in
        best)
            proton_probe_candidates_and_select
            ;;
        interactive)
            _sel_line="$(proton_select_server_interactive)"
            _sel_line="$(proton_normalize_selected_tsv "$_sel_line")"
            proton_apply_selected_tsv "$_sel_line"
            ;;
        *) die "Неизвестный режим выбора сервера: $PROTON_SELECTION_MODE" ;;
    esac

    [ -n "$PROTON_SELECTED_PEER_NAME" ] || die "Не удалось определить peer name"
    [ -n "$PROTON_SELECTED_PEER_IP" ] || die "Не удалось определить peer IP"
    [ -n "$PROTON_SELECTED_PEER_PUBLIC_KEY" ] || die "Не удалось определить peer public key"
}

proton_show_selected_server() {
    info "Выбран сервер Proton: $PROTON_SELECTED_NAME (ID: $PROTON_SELECTED_ID, страна: $PROTON_SELECTED_COUNTRY, город: $PROTON_SELECTED_CITY, загрузка: ${PROTON_SELECTED_LOAD}%)"
    debug "Selected score: $PROTON_SELECTED_SCORE"
    debug "Selected peer name: $PROTON_SELECTED_PEER_NAME"
    debug "Selected peer IP: $PROTON_SELECTED_PEER_IP"
    debug "Selected peer IPv6: ${PROTON_SELECTED_PEER_IPV6:-}"
    debug "Selected has IPv6: ${PROTON_SELECTED_HAS_IPV6:-0}"
    debug "Selected peer public key: $PROTON_SELECTED_PEER_PUBLIC_KEY"
}

proton_auto_device_name() {
    prefix="${PROTON_DEVICE_NAME_PREFIX:-xfree-toolbox}"
    timestamp="$(date -u +"%Y%m%d-%H%M%SZ")"
    printf '%s-%s\n' "$prefix" "$timestamp"
}

proton_resolve_device_name() {
    if [ -n "${PROTON_DEVICE_NAME:-}" ]; then
        printf '%s\n' "$PROTON_DEVICE_NAME"
        return 0
    fi
    proton_auto_device_name
}

proton_extract_keypair_with_python() {
    [ -f "$PROTON_CERT_KEY_JSON" ] || return 1
    command -v python3 >/dev/null 2>&1 || return 1
    python3 - "$PROTON_CERT_KEY_JSON" <<'PY'
import base64
import json
import sys
from pathlib import Path

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519, x25519
except Exception:
    sys.exit(2)

def normalize_pem(value: str) -> bytes:
    text = (value or "").strip()
    if "\\n" in text and "\n" not in text:
        text = text.replace("\\n", "\n")
    return text.encode("utf-8")

path = Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
priv = str(payload.get("PrivateKey") or "")
pub = str(payload.get("PublicKey") or "")
if not priv or not pub:
    sys.exit(3)

priv_key = serialization.load_pem_private_key(normalize_pem(priv), password=None)
pub_key = serialization.load_pem_public_key(normalize_pem(pub))

if not isinstance(priv_key, (ed25519.Ed25519PrivateKey, x25519.X25519PrivateKey)):
    sys.exit(4)
if not isinstance(pub_key, (ed25519.Ed25519PublicKey, x25519.X25519PublicKey)):
    sys.exit(5)

priv_raw = priv_key.private_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PrivateFormat.Raw,
    encryption_algorithm=serialization.NoEncryption(),
)
pub_raw = pub_key.public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw,
)

# WireGuard/Proton path in generate.sh expects either:
# - 32-byte Ed25519 seed -> x25519_private_from_ed25519_seed_b64
# - 32-byte X25519 scalar -> use as WG PrivateKey directly (kind=x25519)
# cryptography / OpenSSL may expose 64-byte "expanded" Ed25519 material; use seed = first 32 bytes.
if isinstance(priv_key, x25519.X25519PrivateKey):
    kind = "x25519"
    if len(priv_raw) != 32:
        sys.stderr.write(f"proton: unexpected X25519 raw private length {len(priv_raw)} (expected 32)\n")
        sys.exit(6)
else:
    kind = "ed25519"
    plen = len(priv_raw)
    if plen == 64:
        sys.stderr.write("proton: Ed25519 raw private length 64 (expanded) — using first 32 bytes as seed.\n")
        priv_raw = priv_raw[:32]
    elif plen == 128:
        sys.stderr.write("proton: Ed25519 raw private length 128 — using first 32 bytes as seed (compat).\n")
        priv_raw = priv_raw[:32]
    elif plen != 32:
        sys.stderr.write(f"proton: unexpected Ed25519 raw private length {plen}\n")
        sys.exit(6)

out_priv = base64.b64encode(priv_raw).decode("ascii")
out_pub = base64.b64encode(pub_raw).decode("ascii")
print(out_priv + "\t" + out_pub + "\t" + kind)
PY
}

# После base64 -d материал для generate.sh должен быть ровно 32 байта:
# - x25519: только 32 байта скаляра;
# - ed25519: seed 32 байта; если OpenSSL/cryptography отдали 64/128 байт — первые 32 (seed).
proton_normalize_wg_gen_priv_b64() {
    WG_GEN_PRIV="$(printf '%s' "$WG_GEN_PRIV" | tr -d '\r\n\t ')"
    [ -n "$WG_GEN_PRIV" ] || die "WG_GEN_PRIV пуст перед нормализацией"

    kind="$(common_lower_ascii "${WG_GEN_KEY_KIND:-ed25519}")"
    tmp_dec="${PROTON_WORKDIR}/wg-gen-priv-dec.$$"
    tmp32="${PROTON_WORKDIR}/wg-gen-priv-32.$$"

    pad_b64="$(proton_b64_pad "$WG_GEN_PRIV")"
    if ! printf '%s' "$pad_b64" | base64 -d > "$tmp_dec" 2>/dev/null; then
        rm -f "$tmp_dec" "$tmp32"
        die "Не удалось декодировать WG_GEN_PRIV (base64)"
    fi
    n="$(wc -c < "$tmp_dec" | awk '{print $1}' | tr -d ' ')"

    case "$kind" in
        x25519)
            [ "$n" = "32" ] || {
                rm -f "$tmp_dec" "$tmp32"
                die "X25519 private: после base64 -d ожидалось 32 байта, получено $n"
            }
            ;;
        *)
            case "$n" in
                32) ;;
                64|128)
                    warn "WG_GEN_PRIV после decode: $n байт — для Ed25519→X25519 беру первые 32 байта (seed)"
                    if ! head -c 32 "$tmp_dec" > "$tmp32" 2>/dev/null; then
                        rm -f "$tmp_dec" "$tmp32"
                        die "Не удалось усечь WG_GEN_PRIV до 32 байт (head -c 32)"
                    fi
                    mv -f "$tmp32" "$tmp_dec"
                    ;;
                *)
                    rm -f "$tmp_dec" "$tmp32"
                    die "Ed25519 seed: после base64 -d ожидалось 32 (или 64/128 для нормализации), получено $n"
                    ;;
            esac
            ;;
    esac

    WG_GEN_PRIV="$(base64 < "$tmp_dec" | tr -d '\r\n')"
    rm -f "$tmp_dec" "$tmp32"
}

proton_get_keypair() {
    command -v proton_pem_body >/dev/null 2>&1 || die "Не загружена crypto fallback library (proton-crypto-fallback.sh)"

    WG_GEN_KEY_KIND=ed25519

    proton_http_get_json \
        "$PROTON_BASE_URL/api/vpn/v1/certificate/key/EC" \
        "$PROTON_BASE_URL/downloads" \
        "$PROTON_CERT_KEY_JSON" \
        "keypair" || die "Не удалось получить Proton keypair"

    raw_priv_pem="$(jq -r '.PrivateKey // empty' "$PROTON_CERT_KEY_JSON")"
    raw_pub_pem="$(jq -r '.PublicKey // empty' "$PROTON_CERT_KEY_JSON")"

    [ -n "$raw_priv_pem" ] || die "В ответе key/EC отсутствует PrivateKey"
    [ -n "$raw_pub_pem" ] || die "В ответе key/EC отсутствует PublicKey"

    py_line="$(proton_extract_keypair_with_python || true)"
    if [ -n "$py_line" ]; then
        WG_GEN_PRIV="$(printf '%s' "$py_line" | awk -F '\t' '{print $1}' | tr -d '\r\n\t ')"
        WG_GEN_PUB="$(printf '%s' "$py_line" | awk -F '\t' '{print $2}' | tr -d '\r\n\t ')"
        WG_GEN_KEY_KIND="$(printf '%s' "$py_line" | awk -F '\t' '{print $3}' | tr -d '\r\n\t ')"
        [ -n "$WG_GEN_KEY_KIND" ] || WG_GEN_KEY_KIND=ed25519
        debug "Keypair parsed via python3+cryptography (kind=$WG_GEN_KEY_KIND)"
    else
        priv_body="$(printf '%s' "$raw_priv_pem" | proton_pem_body)"
        pub_body="$(printf '%s' "$raw_pub_pem" | proton_pem_body)"
        WG_GEN_PRIV="$(proton_extract_private_raw_b64 "$priv_body")"
        WG_GEN_PUB="$(proton_extract_public_raw_b64 "$pub_body")"
    fi

    proton_normalize_wg_gen_priv_b64

    WG_GEN_PRIV="$(proton_b64_pad "$WG_GEN_PRIV")"
    WG_GEN_PUB="$(proton_b64_pad "$WG_GEN_PUB")"

    [ -n "$WG_GEN_PRIV" ] || die "PrivateKey(raw b64) пуст"
    [ -n "$WG_GEN_PUB" ] || die "PublicKey(raw b64) пуст"

    debug "Keypair готов (ответ key/EC + нормализация при необходимости)"
    debug "PrivateKey(raw b64 padded) length: $(printf '%s' "$WG_GEN_PRIV" | wc -c | awk '{print $1}')"
    debug "PublicKey(raw b64 padded) length: $(printf '%s' "$WG_GEN_PUB" | wc -c | awk '{print $1}')"
}

proton_create_certificate() {
    client_public_key="$1"

    peer_name="$PROTON_SELECTED_PEER_NAME"
    peer_ip="$PROTON_SELECTED_PEER_IP"
    peer_public_key="$PROTON_SELECTED_PEER_PUBLIC_KEY"
    device_name="$(proton_resolve_device_name)"
    platform="${PROTON_PLATFORM:-Router}"

    [ -n "$peer_name" ] || die "peer_name пуст"
    [ -n "$peer_ip" ] || die "peer_ip пуст"
    [ -n "$peer_public_key" ] || die "peer_public_key пуст"
    [ -n "$device_name" ] || die "DeviceName пуст"
    [ -n "$platform" ] || die "platform пуст"
    [ -n "$client_public_key" ] || die "ClientPublicKey пуст"

    # Mode=persistent: for a full account this can last up to ~365d.
    # Credentialless/guest has no dashboard registration; Proton may still
    # accept the flag but ExpirationTime is what the .conf actually lives by
    # (session-mode caps at 7d; guest users can be GC'd earlier).
    jq -n \
        --arg cpk "$client_public_key" \
        --arg mode "persistent" \
        --arg dev "$device_name" \
        --argjson bouncing 2 \
        --arg peerName "$peer_name" \
        --arg peerIp "$peer_ip" \
        --arg peerPublicKey "$peer_public_key" \
        --arg platform "$platform" \
        '{
            ClientPublicKey: $cpk,
            Mode: $mode,
            DeviceName: $dev,
            Features: {
                Bouncing: $bouncing,
                SplitTCP: true,
                PortForwarding: false,
                peerName: $peerName,
                peerIp: $peerIp,
                peerPublicKey: $peerPublicKey,
                platform: $platform
            }
        }' > "$PROTON_CERT_CREATE_REQ_JSON"

    proton_http_post_json \
        "$PROTON_BASE_URL/api/vpn/v1/certificate" \
        "$PROTON_BASE_URL/downloads" \
        "$PROTON_CERT_CREATE_REQ_JSON" \
        "$PROTON_CERT_CREATE_JSON" \
        "certificate" || die "Не удалось создать Proton certificate"

    PROTON_LAST_CERT_SERIAL="$(proton_cert_json_field "SerialNumber" || true)"
    export PROTON_LAST_CERT_SERIAL
}

proton_revoke_certificate() {
    serial="$1"
    [ -n "$serial" ] || return 0
    _req="${TMPDIR:-/tmp}/proton-cert-del.$$.json"
    _out="${TMPDIR:-/tmp}/proton-cert-del-resp.$$.json"
    printf '{"SerialNumber":"%s"}\n' "$serial" > "$_req"
    info_err "Освобождение сессии: отзыв неактивного сертификата Proton ($serial)..."
    proton_http_delete_json \
        "$PROTON_BASE_URL/api/vpn/v1/certificate" \
        "$PROTON_BASE_URL/downloads" \
        "$_req" \
        "$_out" \
        "certificate-revoke" >/dev/null 2>&1 || true
    rm -f "$_req" "$_out" "${_out}.headers" "${_out}.http_code"
}

proton_cert_json_field() {
    field="$1"
    PROTON_JSON_SOURCE="$PROTON_CERT_CREATE_JSON"
    proton_json_get "@.$field"
}

proton_unix_to_utc() {
    ts="$1"
    case "$ts" in
        ''|*[!0-9]*) return 0 ;;
    esac
    date -u -d "@$ts" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null \
        || date -u -r "$ts" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null \
        || true
}

proton_show_certificate_summary() {
    info "Certificate response summary:"
    if command -v jq >/dev/null 2>&1; then
        jq -r '
            [
              "Code=" + ((.Code // "")|tostring),
              "SerialNumber=" + ((.SerialNumber // "")|tostring),
              "Mode=" + ((.Mode // "")|tostring),
              "DeviceName=" + ((.DeviceName // "")|tostring),
              "ExpirationTime=" + ((.ExpirationTime // "")|tostring),
              "RefreshTime=" + ((.RefreshTime // "")|tostring),
              "HasCertificate=" + (has("Certificate")|tostring),
              "HasServerPublicKey=" + (has("ServerPublicKey")|tostring)
            ] | .[]
        ' "$PROTON_CERT_CREATE_JSON" 2>/dev/null || true
        exp="$(proton_cert_json_field ExpirationTime)"
        exp_utc="$(proton_unix_to_utc "$exp")"
        [ -n "$exp_utc" ] && info "Certificate ExpirationTime UTC: $exp_utc"
    else
        exp="$(proton_cert_json_field ExpirationTime)"
        [ -n "$exp" ] && info "Certificate ExpirationTime unix: $exp"
        head -c 1200 "$PROTON_CERT_CREATE_JSON" 2>/dev/null || true
        printf '\n' >&2
    fi
}

# Shared AWG profile helpers for Proton generators/importers.
proton_awg_reset_version_extensions() {
    AWG_HAS_S3=0
    AWG_HAS_S4=0
    AWG_S3=''
    AWG_S4=''
}

proton_awg_set_variant_base_params() {
    case "$1" in
        1|auto|'')
            AWG_S1='0'; AWG_S2='0'; AWG_JC='4'; AWG_JMIN='40'; AWG_JMAX='70';
            AWG_H1='1'; AWG_H2='2'; AWG_H3='3'; AWG_H4='4';
            AWG_I1='<b 0xce000000010897a297ecc34cd6dd000044d0ec2e2e1ea2991f467ace4222129b5a098823784694b4897b9986ae0b7280135fa85e196d9ad980b150122129ce2a9379531b0fd3e871ca5fdb883c369832f730e272d7b8b74f393f9f0fa43f11e510ecb2219a52984410c204cf875585340c62238e14ad04dff382f2c200e0ee22fe743b9c6b8b043121c5710ec289f471c91ee414fca8b8be8419ae8ce7ffc53837f6ade262891895f3f4cecd31bc93ac5599e18e4f01b472362b8056c3172b513051f8322d1062997ef4a383b01706598d08d48c221d30e74c7ce000cdad36b706b1bf9b0607c32ec4b3203a4ee21ab64df336212b9758280803fcab14933b0e7ee1e04a7becce3e2633f4852585c567894a5f9efe9706a151b615856647e8b7dba69ab357b3982f554549bef9256111b2d67afde0b496f16962d4957ff654232aa9e845b61463908309cfd9de0a6abf5f425f577d7e5f6440652aa8da5f73588e82e9470f3b21b27b28c649506ae1a7f5f15b876f56abc4615f49911549b9bb39dd804fde182bd2dcec0c33bad9b138ca07d4a4a1650a2c2686acea05727e2a78962a840ae428f55627516e73c83dd8893b02358e81b524b4d99fda6df52b3a8d7a5291326e7ac9d773c5b43b8444554ef5aea104a738ed650aa979674bbed38da58ac29d87c29d387d80b526065baeb073ce65f075ccb56e47533aef357dceaa8293a523c5f6f790be90e4731123d3c6152a70576e90b4ab5bc5ead01576c68ab633ff7d36dcde2a0b2c68897e1acfc4d6483aaaeb635dd63c96b2b6a7a2bfe042f6aed82e5363aa850aace12ee3b1a93f30d8ab9537df483152a5527faca21efc9981b304f11fc95336f5b9637b174c5a0659e2b22e159a9fed4b8e93047371175b1d6d9cc8ab745f3b2281537d1c75fb9451871864efa5d184c38c185fd203de206751b92620f7c369e031d2041e152040920ac2c5ab5340bfc9d0561176abf10a147287ea90758575ac6a9f5ac9f390d0d5b23ee12af583383d994e22c0cf42383834bcd3ada1b3825a0664d8f3fb678261d57601ddf94a8a68a7c273a18c08aa99c7ad8c6c42eab67718843597ec9930457359dfdfbce024afc2dcf9348579a57d8d3490b2fa99f278f1c37d87dad9b221acd575192ffae1784f8e60ec7cee4068b6b988f0433d96d6a1b1865f4e155e9fe020279f434f3bf1bd117b717b92f6cd1cc9bea7d45978bcc3f24bda631a36910110a6ec06da35f8966c9279d130347594f13e9e07514fa370754d1424c0a1545c5070ef9fb2acd14233e8a50bfc5978b5bdf8bc1714731f798d21e2004117c61f2989dd44f0cf027b27d4019e81ed4b5c31db347c4a3a4d85048d7093cf16753d7b0d15e078f5c7a5205dc2f87e330a1f716738dce1c6180e9d02869b5546f1c4d2748f8c90d9693cba4e0079297d22fd61402dea32ff0eb69ebd65a5d0b687d87e3a8b2c42b648aa723c7c7daf37abcc4bb85caea2ee8f55bec20e913b3324ab8f5c3304f820d42ad1b9f2ffc1a3af9927136b4419e1e579ab4c2ae3c776d293d397d575df181e6cae0a4ada5d67ecea171cca3288d57c7bbdaee3befe745fb7d634f70386d873b90c4d6c6596bb65af68f9e5121e67ebf0d89d3c909ceedfb32ce9575a7758ff080724e1ab5d5f43074ecb53a479af21ed03d7b6899c36631c0166f9d47e5e1d4528a5d3d3f744029c4b1c190cbfbad06f5f83f7ad0429fa9a2719c56ffe3783460e166de2d8>'
            AWG_I2=''
            ;;
        2)
            AWG_S1='0'; AWG_S2='0'; AWG_JC='4'; AWG_JMIN='40'; AWG_JMAX='70';
            AWG_H1='1'; AWG_H2='2'; AWG_H3='3'; AWG_H4='4';
            AWG_I1='<b 0xc7000000010809a1ed4edbbe7615000044d017a61a0d774f04290f119e701ef0035df2b0ed571b0b575e6a07246b856eb6ec036fef07f1e07b861251ad737abeb67e64be714c1dcd865312b1b6c35c089c997aeb5c18f808696fe97289513945d84ca846467603e94e44224877f2c1d3261e4ac18740be4bd064369c94fc08978d99b54bf615250998639010c1284248e1d73004b81fcb20b559d8a17eced7eab3964b5b88ca7a3b8579fc8c1c934189e77143b4ac434138114b1048651b56545b87acbef0952763538f3ddeb37cfc6d58b4881c3b719d7ff78f6ee1324a2914a32381c05a64c700466d280be007253bb030d179c4f1b3dc221e1974e2ee6d6e2b9e8d709159b5ef22e1783dbba845c20ca1c83b066c73835920ad70b806df0aee0351e3fc9ab1e42e8b2a30fe235ff0612eee19744949cecee0463b76514ad90c1f7ceaa557c18586ab561d49482e73c85d0143785da14a441bf82f78783b61cccd44aecb1947516e79b5ca5a6b3a8aed6040fae0eeabdc55a88dc19ade832d99fca90c7a629cacc07192d7e47e3c6a271b95b0ea3392562a06a1cab79f40ea92916ebee197b7b5f14b251824e1ed20ff2ca80b1f03a43e45157589bc61b978e97851025b3b7ccc17d291e1cb60fe48a5c26829dce11dd23c2e73265a9ebf8617c985e4fee4681e863f990061f4dea465a7d2524bd0edcf4b48d4b8f25fc359b15babd2637284a4774077dca60091f1a781cfee1bef9713dd5943a579d7470bc5970542fbb27fdf77880a8d8751b1f642c7a3f019a05ab94bf63d3525ef34e9290b5c8d477f2714e6d6e3e4d35c1983f5e16fda57fcdf071b513f8f088dbe8d5a97577d17a5383a496c3f313adfdd47c962bbaebd6aa13b46439eb742622c29ca067db0ec1853064c3cbbffe0a215a19fce47d49703ed58ebbd89721172d256d1cf30188106fb2f863186511401fad54d087aa2fb3d1b85768db386bd7102e8060ac157bac011acdcdae2799b9aee1467c3424013455bd028fcaacdc3c77d28ea199967d617ea7d0d0815f3cc407934a76d1293dccba210d1709a13e5dd67c9ba47cd113f5bdd740358eff13164159fd09bc2f7ec6cfa64d9df7e2e2f88706b0ff3a92ccf6f078456cfe0bdd89292cfe2680badc1eac9f7d36efe8eb6912c7b164508d13e6c0911c15f73c233cbe4fc70ff2ade1e1be4bbb738e0939159e2078a9438f05b756a003371f4861481c38f1cdd2d7b06deb62869e9fe79a8abaa920646fa2e8fa28f0d80c136376c7b56046bae4c05c0cdf64efb8c47bbfc5a1a4c0b045061ef0d71618e0d206a1d7f245fd5c03191b152673ba8dff8e1b8de7c50234a93cba91e3888adb228cc02beded4b1c0946797d3ef02dec2edb6ad0ac21f89f4be364c317da7c22440e9f358d512203f4b7ab20388af68b8915d0152db2c8a0687bfaea870f7529bb92a22b35bd79bc6d490591406346ecd78342ee3563c4883a8251679691c2d4e963397e24653520795511b018915374c954bddb940a9d7a16d1c8bd798fc7dbfb0599a7074e13f87e14efa8d511bb2579ec029b1bda18fe971b30fbe19e986ff2686a69bf3f1bb929de93ae70345ebca998b11e0a2b41890cba628d8f6e7c4e94790735e5299b4ff07cd3080f7d53c9cbe1911d2cd5925b3213e033c272506a87886cf761a283a779564d3241e3c28f632e166b5d756e1786ce077614c4444e3f2aed5decb3613b925ea3e558c21d4faf8ba54edd0f3a5d4>'
            AWG_I2=''
            ;;
        3)
            AWG_S1='0'; AWG_S2='0'; AWG_JC='4'; AWG_JMIN='40'; AWG_JMAX='70';
            AWG_H1='1'; AWG_H2='2'; AWG_H3='3'; AWG_H4='4';
            AWG_I1='<b 0x494e56495445207369703a626f624062696c6f78692e636f6d205349502f322e300d0a5669613a205349502f322e302f55445020706333332e61746c616e74612e636f6d3b6272616e63683d7a39684734624b3737366173646864730d0a4d61782d466f7277617264733a2037300d0a546f3a20426f62203c7369703a626f624062696c6f78692e636f6d3e0d0a46726f6d3a20416c696365203c7369703a616c6963654061746c616e74612e636f6d3e3b7461673d313932383330313737340d0a43616c6c2d49443a20613834623463373665363637313040706333332e61746c616e74612e636f6d0d0a435365713a2033313431353920494e564954450d0a436f6e746163743a203c7369703a616c69636540706333332e61746c616e74612e636f6d3e0d0a436f6e74656e742d547970653a206170706c69636174696f6e2f7364700d0a436f6e74656e742d4c656e6774683a20300d0a0d0a>'
            AWG_I2='<b 0x5349502f322e302031303020547279696e670d0a5669613a205349502f322e302f55445020706333332e61746c616e74612e636f6d3b6272616e63683d7a39684734624b3737366173646864730d0a546f3a20426f62203c7369703a626f624062696c6f78692e636f6d3e0d0a46726f6d3a20416c696365203c7369703a616c6963654061746c616e74612e636f6d3e3b7461673d313932383330313737340d0a43616c6c2d49443a20613834623463373665363637313040706333332e61746c616e74612e636f6d0d0a435365713a2033313431353920494e564954450d0a436f6e74656e742d4c656e6774683a20300d0a0d0a>'
            ;;
        *) die "Неизвестный вариант: $1" ;;
    esac
}

proton_awg_apply_version_extensions() {
    case "$1" in
        1.5) ;;
        2.0)
            AWG_HAS_S3=1
            AWG_HAS_S4=1
            AWG_S3='0'
            AWG_S4='0'
            ;;
        *) die "Неизвестная версия AWG: $1" ;;
    esac
}

proton_awg_normalize_version() {
    case "$1" in
        1.5|2.0) printf '%s\n' "$1" ;;
        *) die "Неизвестная версия AWG: $1" ;;
    esac
}

proton_awg_normalize_variant() {
    case "$1" in
        auto|1|2|3) printf '%s\n' "$1" ;;
        "") printf '%s\n' "auto" ;;
        *) die "Неизвестный вариант AWG: $1" ;;
    esac
}

proton_awg_normalize_noise_enabled() {
    case "${1:-0}" in
        1|yes|YES|true|TRUE|on|ON) printf '%s\n' "1" ;;
        *) printf '%s\n' "0" ;;
    esac
}

proton_awg_apply_noise_mode() {
    case "$(proton_awg_normalize_noise_enabled "${1:-0}")" in
        1) ;;
        *)
            AWG_JC='0'
            AWG_JMIN='0'
            AWG_JMAX='0'
            ;;
    esac
}

# Режимы энтропии I1: off | r32 (default) | r64 | t | c | rc10 | rd6.
# Совместимость: 0/off → off; пусто/1/on → r32.
proton_awg_normalize_i1_entropy() {
    case "${1:-}" in
        0 | off | OFF | no | NO | false | FALSE | none | NONE) printf '%s\n' "off" ;;
        r64 | R64 | '<r 64>') printf '%s\n' "r64" ;;
        t | T | '<t>') printf '%s\n' "t" ;;
        c | C | '<c>') printf '%s\n' "c" ;;
        rc10 | RC10 | '<rc 10>') printf '%s\n' "rc10" ;;
        rd6 | RD6 | '<rd 6>') printf '%s\n' "rd6" ;;
        *) printf '%s\n' "r32" ;;
    esac
}

proton_awg_normalize_i1_entropy_enabled() {
    case "$(proton_awg_normalize_i1_entropy "${1:-}")" in
        off) printf '%s\n' "0" ;;
        *) printf '%s\n' "1" ;;
    esac
}

proton_awg_i1_entropy_tag() {
    case "$(proton_awg_normalize_i1_entropy "${1:-}")" in
        off) ;;
        r64) printf '%s\n' '<r 64>' ;;
        t) printf '%s\n' '<t>' ;;
        c) printf '%s\n' '<c>' ;;
        rc10) printf '%s\n' '<rc 10>' ;;
        rd6) printf '%s\n' '<rd 6>' ;;
        *) printf '%s\n' '<r 32>' ;;
    esac
}

proton_awg_i1_entropy_label() {
    case "$(proton_awg_normalize_i1_entropy "${1:-}")" in
        off) printf '%s\n' "I1 без энтропии" ;;
        r64) printf '%s\n' "I1 + <r 64>" ;;
        t) printf '%s\n' "I1 + <t>" ;;
        c) printf '%s\n' "I1 + <c>" ;;
        rc10) printf '%s\n' "I1 + <rc 10>" ;;
        rd6) printf '%s\n' "I1 + <rd 6>" ;;
        *) printf '%s\n' "I1 + <r 32>" ;;
    esac
}

proton_awg_i1_entropy_strip() {
    [ -n "${AWG_I1:-}" ] || return 0
    changed=1
    while [ "$changed" = 1 ]; do
        changed=0
        for _tag in '<r 32>' '<r 64>' '<rc 10>' '<rd 6>' '<t>' '<c>'; do
            case "$AWG_I1" in
                *"$_tag")
                    AWG_I1="${AWG_I1%"$_tag"}"
                    changed=1
                    ;;
            esac
        done
    done
}

# AmneziaWG: к фиксированному I1 (`<b 0x…>`) дописать выбранный тег энтропии.
proton_awg_apply_i1_entropy() {
    [ -n "${AWG_I1:-}" ] || return 0
    proton_awg_i1_entropy_strip
    _tag="$(proton_awg_i1_entropy_tag "$1")"
    [ -n "$_tag" ] || return 0
    AWG_I1="${AWG_I1}${_tag}"
}

proton_awg_version_variant_params() {
    version="$1"
    variant="$2"
    noise_enabled="${3:-0}"
    case "$variant" in
        auto|'') variant="1" ;;
    esac
    proton_awg_reset_version_extensions
    proton_awg_set_variant_base_params "$variant"
    proton_awg_apply_version_extensions "$version"
    proton_awg_apply_noise_mode "$noise_enabled"
    proton_awg_apply_i1_entropy "${4:-r32}"
}

# Автоподбор идеальных параметров для Proton (AWG 2.0 вар 1,2,3, энтропия I1, шум)
# Использует комбинаторную матрицу и пул серверов из разных подсетей.
# Сохраняет подобранные параметры в /tmp/domain-routing-proton/
proton_tune() {
    info_err "=== Запуск автоподбора параметров Proton ==="

    _state="/tmp/domain-routing-proton"
    [ -n "${PROTON_COUNTRY_FILTER:-}" ] || PROTON_COUNTRY_FILTER="$([ -f "$_state/country" ] && tr -d '\r\n' <"$_state/country" || printf 'NL')"
    [ -n "$PROTON_COUNTRY_FILTER" ] || PROTON_COUNTRY_FILTER="NL"
    [ -n "${PROTON_FREE_ONLY:-}" ] || PROTON_FREE_ONLY="$([ -f "$_state/free_only" ] && tr -d '\r\n' <"$_state/free_only" || printf '1')"
    [ -n "$PROTON_FREE_ONLY" ] || PROTON_FREE_ONLY="1"
    [ -n "${PROTON_REQUIRE_IPV6:-}" ] || PROTON_REQUIRE_IPV6="$([ -f "$_state/require_ipv6" ] && tr -d '\r\n' <"$_state/require_ipv6" || printf '0')"
    [ -n "$PROTON_REQUIRE_IPV6" ] || PROTON_REQUIRE_IPV6="0"
    export PROTON_COUNTRY_FILTER PROTON_FREE_ONLY PROTON_REQUIRE_IPV6

    if [ -z "${PROTON_SESSION_NAME:-}" ]; then
        info_err "Проверка гостевой сессии Proton..."
        proton_guest_acquire_session >/dev/null 2>&1 || true
    fi
    proton_verify_auth || die "Авторизация Proton недоступна"

    info_err "Запрос актуального списка серверов..."
    proton_fetch_logicals
    proton_build_server_table

    PROTON_AUTOTUNE=1
    export PROTON_AUTOTUNE
    VARIANT="auto"
    export VARIANT

    proton_probe_candidates_and_select

    _state="/tmp/domain-routing-proton"
    mkdir -p "$_state"
    printf '%s\n' "2.0:$VARIANT" > "$_state/profile"
    printf '%s\n' "$AWG_I1_ENTROPY" > "$_state/i1_entropy"
    printf '%s\n' "$AWG_NOISE_ENABLED" > "$_state/awg_noise"
    printf '%s\n' "${WG_PEER_ENDPOINT:-$PROTON_SELECTED_PEER_IP:${PROTON_WG_PEER_PORT:-51820}}" > "$_state/endpoint"
    printf '%s\n' "$PROTON_SELECTED_NAME" > "$_state/server"
    printf '%s\n' "$PROTON_SELECTED_ID" > "$_state/logical_id"
    [ -n "$PROTON_WG_PEER_PORT" ] && printf '%s\n' "$PROTON_WG_PEER_PORT" > "$_state/port"

    cat <<EOF > "$_state/tune_result.json"
{
  "status": "$([ "${PROTON_SERVER_PROBE_SUCCEEDED:-0}" = "1" ] && echo "OK" || echo "FAIL")",
  "profile": "2.0:$VARIANT",
  "variant": "$VARIANT",
  "entropy": "$AWG_I1_ENTROPY",
  "noise": "$AWG_NOISE_ENABLED",
  "endpoint": "${WG_PEER_ENDPOINT:-$PROTON_SELECTED_PEER_IP:${PROTON_WG_PEER_PORT:-51820}}",
  "server_name": "$PROTON_SELECTED_NAME",
  "port": "${PROTON_WG_PEER_PORT:-51820}",
  "rtt_ms": ${PROTON_PROBE_RTT:-999}
}
EOF

    echo "=== Результаты автоподбора параметров ==="
    echo "Профиль AWG: AWG 2.0 · вариант $VARIANT"
    echo "Энтропия I1: $AWG_I1_ENTROPY"
    echo "Шум AWG: $([ "$AWG_NOISE_ENABLED" = "1" ] && echo 'Включен (Jc=4)' || echo 'Выключен (Jc=0)')"
    echo "Сервер: $PROTON_SELECTED_NAME (${WG_PEER_ENDPOINT:-$PROTON_SELECTED_PEER_IP:${PROTON_WG_PEER_PORT:-51820}}, ${PROTON_PROBE_RTT:-999} мс)"
    echo "Параметры сохранены. Запустите генерацию конфигурации для создания .conf"
}
