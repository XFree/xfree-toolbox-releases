#!/bin/sh
# shellcheck shell=sh
# Shared JSON extraction for VPN generators: OpenWrt jsonfilter or jq on dev hosts.

vpn_json_expr_to_jq() {
    expr="$1"
    case "$expr" in
        @.*)
            printf '%s' "$expr" | sed 's/^@\././'
            ;;
        *)
            printf '%s' "$expr"
            ;;
    esac
}

vpn_json_get_file() {
    expr="$1"
    file="$2"
    [ -n "${file:-}" ] && [ -f "$file" ] || {
        printf '%s\n' ""
        return 0
    }

    if command -v jsonfilter >/dev/null 2>&1; then
        jsonfilter -e "$expr" < "$file" 2>/dev/null || true
        return 0
    fi

    if ! command -v jq >/dev/null 2>&1; then
        printf '%s\n' ""
        return 0
    fi

    jpath="$(vpn_json_expr_to_jq "$expr")"
    jq -r "${jpath} // empty" < "$file" 2>/dev/null || true
}

vpn_json_get_string() {
    expr="$1"
    json="$2"

    if command -v jsonfilter >/dev/null 2>&1; then
        jsonfilter -s "$json" -e "$expr" 2>/dev/null || true
        return 0
    fi

    if ! command -v jq >/dev/null 2>&1; then
        printf '%s\n' ""
        return 0
    fi

    jpath="$(vpn_json_expr_to_jq "$expr")"
    printf '%s' "$json" | jq -r "${jpath} // empty" 2>/dev/null || true
}

vpn_json_require_parser() {
    if command -v jsonfilter >/dev/null 2>&1; then
        return 0
    fi
    command -v jq >/dev/null 2>&1 || die "Нужен jq или jsonfilter для разбора JSON ответов API"
    if command -v info >/dev/null 2>&1; then
        info "jsonfilter не найден (типично для ПК без OpenWrt) — JSON разбирается через jq"
    fi
}
