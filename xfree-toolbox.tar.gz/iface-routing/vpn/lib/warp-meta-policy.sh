#!/bin/sh
# shellcheck shell=sh
# WARP source.conf.meta: канон параметров генерации + идемпотентная миграция.
#
# GENERATOR_POLICY_VERSION:
#   отсутствует / 0 — legacy meta (до явных SELECTION_MODE/EXCLUDE_RU/SERVER_ID=def)
#   1 — политика «полный gen-набор»; one-shot xfree→def уже применена (если была)
#
# После version>=1 пользовательский SERVER_ID=xfree сохраняется (явный выбор).

WARP_GENERATOR_POLICY_VERSION="${WARP_GENERATOR_POLICY_VERSION:-1}"

warp_meta_policy_get() {
	_wmp_file="$1"
	_wmp_key="$2"
	[ -f "$_wmp_file" ] || return 0
	awk -F= -v want="$_wmp_key" '
		{
			gsub(/\r/, "")
		}
		$1 == want {
			v = substr($0, index($0, "=") + 1)
			sub(/^[[:space:]]+/, "", v)
			sub(/[[:space:]]+$/, "", v)
			gsub(/^\047|\047$/, "", v)
			print v
			exit
		}
	' "$_wmp_file"
}

warp_meta_policy_set() {
	_wmp_file="$1"
	_wmp_key="$2"
	_wmp_val="$3"
	_wmp_tmp="${_wmp_file}.tmp.$$"
	_wmp_found=0
	[ -f "$_wmp_file" ] || return 1
	while IFS= read -r _wmp_line || [ -n "$_wmp_line" ]; do
		_wmp_line="$(printf '%s' "$_wmp_line" | tr -d '\r')"
		case "$_wmp_line" in
		"${_wmp_key}="*)
			printf "%s='%s'\n" "$_wmp_key" "$_wmp_val"
			_wmp_found=1
			;;
		*)
			printf '%s\n' "$_wmp_line"
			;;
		esac
	done <"$_wmp_file" >"$_wmp_tmp"
	[ "$_wmp_found" = "1" ] || printf "%s='%s'\n" "$_wmp_key" "$_wmp_val" >>"$_wmp_tmp"
	mv -f "$_wmp_tmp" "$_wmp_file"
}

# Маркер шаблона / пусто — не пользовательский диапазон.
warp_meta_policy_is_server_token() {
	case "$1" in
	''|'***RECREATE***'|'***GENERATE***'|'***PROMPT***') return 0 ;;
	*) return 1 ;;
	esac
}

# Нормализует meta на месте. Печатает "1" в stdout если файл изменён, иначе "0".
# Не трогает runtime — только profile/state meta (следующий regenerate подхватит).
warp_meta_policy_migrate_file() {
	_wmp_meta="$1"
	_wmp_changed=0
	_wmp_kind=""
	_wmp_ver=""
	_wmp_sid=""
	_wmp_sel=""
	_wmp_excl=""
	_wmp_mode=""
	_wmp_var=""
	_wmp_i1=""
	_wmp_target="${WARP_GENERATOR_POLICY_VERSION}"

	[ -f "$_wmp_meta" ] || {
		printf '0\n'
		return 0
	}

	_wmp_kind="$(warp_meta_policy_get "$_wmp_meta" GENERATOR_KIND)"
	case "$_wmp_kind" in
	warp) ;;
	*)
		printf '0\n'
		return 0
		;;
	esac

	_wmp_ver="$(warp_meta_policy_get "$_wmp_meta" GENERATOR_POLICY_VERSION)"
	case "$_wmp_ver" in
	''|*[!0-9]*) _wmp_ver=0 ;;
	esac

	_wmp_sid="$(warp_meta_policy_get "$_wmp_meta" SERVER_ID)"
	_wmp_sel="$(warp_meta_policy_get "$_wmp_meta" SELECTION_MODE)"
	_wmp_excl="$(warp_meta_policy_get "$_wmp_meta" EXCLUDE_RU)"
	_wmp_mode="$(warp_meta_policy_get "$_wmp_meta" PROFILE_MODE)"
	_wmp_var="$(warp_meta_policy_get "$_wmp_meta" VARIANT_ID)"
	_wmp_i1="$(warp_meta_policy_get "$_wmp_meta" I1_MODE)"

	# Маркер диапазона → канон def (не пользовательский выбор).
	if warp_meta_policy_is_server_token "$_wmp_sid"; then
		warp_meta_policy_set "$_wmp_meta" SERVER_ID "def"
		warp_meta_policy_set "$_wmp_meta" SERVER_NAME "DEF"
		warp_meta_policy_set "$_wmp_meta" COUNTRY_FILTER "DEF"
		_wmp_changed=1
		_wmp_sid="def"
	fi

	# One-shot: legacy default range xfree → def, только до POLICY_VERSION>=1.
	if [ "$_wmp_ver" -lt "$_wmp_target" ]; then
		case "$(printf '%s' "$_wmp_sid" | tr 'A-Z' 'a-z')" in
		xfree)
			warp_meta_policy_set "$_wmp_meta" SERVER_ID "def"
			warp_meta_policy_set "$_wmp_meta" SERVER_NAME "DEF"
			warp_meta_policy_set "$_wmp_meta" COUNTRY_FILTER "DEF"
			_wmp_changed=1
			_wmp_sid="def"
			;;
		esac
	fi

	case "$_wmp_sel" in
	best|random) ;;
	*)
		warp_meta_policy_set "$_wmp_meta" SELECTION_MODE "best"
		_wmp_changed=1
		;;
	esac

	case "$_wmp_excl" in
	0|1) ;;
	*)
		warp_meta_policy_set "$_wmp_meta" EXCLUDE_RU "1"
		_wmp_changed=1
		;;
	esac

	case "$_wmp_mode" in
	local|raw) ;;
	*)
		warp_meta_policy_set "$_wmp_meta" PROFILE_MODE "local"
		_wmp_changed=1
		;;
	esac

	case "$_wmp_var" in
	1|2|3) ;;
	*)
		warp_meta_policy_set "$_wmp_meta" VARIANT_ID "1"
		_wmp_changed=1
		;;
	esac

	case "$_wmp_i1" in
	fixed|random|domain) ;;
	*)
		warp_meta_policy_set "$_wmp_meta" I1_MODE "fixed"
		_wmp_changed=1
		;;
	esac

	if [ "$_wmp_ver" -lt "$_wmp_target" ]; then
		warp_meta_policy_set "$_wmp_meta" GENERATOR_POLICY_VERSION "$_wmp_target"
		_wmp_changed=1
	fi

	printf '%s\n' "$_wmp_changed"
}
