#!/bin/sh
# shellcheck shell=sh
# Proton renew: метка конфига (session/auth/cert) и пересборка source.conf по meta.
# Guest: mint новой credentialless-сессии + .conf (как WARP).
# Web: полный bundle И непросроченные AUTH-/REFRESH- cookies (иначе skip; API не дергаем на каждом тике).
# Импорт .conf без сессии — skip.
# Не ходит в Proton API сама — regenerate-interface-config.sh --force + apply -i.

proton_guest_renew_meta_get() {
    _file="$1"
    _key="$2"
    [ -f "$_file" ] || return 0
    awk -F= -v want="$_key" '
        { gsub(/\r/, "") }
        $1 == want {
            v = substr($0, index($0, "=") + 1)
            sub(/^[[:space:]]+/, "", v)
            sub(/[[:space:]]+$/, "", v)
            gsub(/^\047|\047$/, "", v)
            print v
            exit
        }
    ' "$_file"
}

proton_guest_renew_mode_norm() {
    _m="$(printf '%s' "${1:-off}" | tr '[:upper:]' '[:lower:]' | tr -d '\r')"
    case "$_m" in
        expiry|on-expiry|cert|ttl|expired) printf 'expiry\n' ;;
        tunnel-fail|fail|probe-fail|on-fail) printf 'tunnel-fail\n' ;;
        both|all|on) printf 'both\n' ;;
        *) printf 'off\n' ;;
    esac
}

proton_guest_renew_mode_has_expiry() {
    case "$(proton_guest_renew_mode_norm "${1:-}")" in
        expiry|both) return 0 ;;
    esac
    return 1
}

proton_guest_renew_mode_has_tunnel_fail() {
    case "$(proton_guest_renew_mode_norm "${1:-}")" in
        tunnel-fail|both) return 0 ;;
    esac
    return 1
}

proton_guest_renew_interfaces_dir() {
    if [ -n "${PROTON_GUEST_RENEW_INTERFACES_DIR:-}" ]; then
        printf '%s\n' "$PROTON_GUEST_RENEW_INTERFACES_DIR"
        return 0
    fi
    if [ -n "${USB_WATCH_TUNNEL_INTERFACES_DIR:-}" ]; then
        printf '%s\n' "$USB_WATCH_TUNNEL_INTERFACES_DIR"
        return 0
    fi
    if command -v usb_watch_tunnel_interfaces_dir >/dev/null 2>&1; then
        usb_watch_tunnel_interfaces_dir
        return 0
    fi
    return 1
}

proton_guest_renew_iface_meta_path() {
    _iface="$1"
    _dir="$(proton_guest_renew_interfaces_dir 2>/dev/null || true)"
    [ -n "$_dir" ] && [ -n "$_iface" ] || return 1
    printf '%s/%s/config/source.conf.meta\n' "$_dir" "$_iface"
}

proton_guest_renew_infer_auth_mode() {
    _meta="$1"
    _mode="$(proton_guest_renew_meta_get "$_meta" "SESSION_AUTH_MODE")"
    if [ -n "$_mode" ]; then
        printf '%s\n' "$_mode"
        return 0
    fi
    _sdir="$(proton_guest_renew_meta_get "$_meta" "SESSION_DIR")"
    if [ -n "$_sdir" ] && [ -f "$_sdir/auth_mode.txt" ]; then
        _mode="$(head -n1 "$_sdir/auth_mode.txt" | tr -d '\r\n' | tr 'A-Z' 'a-z')"
        case "$_mode" in
            guest|web)
                printf '%s\n' "$_mode"
                return 0
                ;;
        esac
    fi
    if [ -n "$_sdir" ] && [ -f "$_sdir/access_token.txt" ] && [ -f "$_sdir/refresh_token.txt" ]; then
        printf 'guest\n'
        return 0
    fi
    if [ -n "$_sdir" ] && [ -f "$_sdir/cookies.txt" ] && [ -f "$_sdir/x_pm_uid.txt" ]; then
        printf 'web\n'
        return 0
    fi
    _sname="$(proton_guest_renew_meta_get "$_meta" "SESSION_NAME")"
    case "$_sname" in
        guest-*)
            printf 'guest\n'
            return 0
            ;;
    esac
    printf '\n'
}

# Живая сессия = полный bundle на диске (как proton_session_bundle_complete_p).
proton_guest_renew_bundle_complete() {
    _d="$1"
    [ -d "$_d" ] || return 1
    [ -f "$_d/x_pm_uid.txt" ] || return 1
    if [ -f "$_d/cookies.txt" ]; then
        return 0
    fi
    [ -f "$_d/access_token.txt" ] && [ -f "$_d/refresh_token.txt" ]
}

proton_guest_renew_profile_sessions_dir() {
    _ifdir="$(proton_guest_renew_interfaces_dir 2>/dev/null || true)"
    case "$_ifdir" in
        */iface-routing/interfaces)
            printf '%s/vpn/proton/sessions\n' "${_ifdir%/iface-routing/interfaces}"
            return 0
            ;;
    esac
    return 1
}

proton_guest_renew_resolve_session_dir() {
    _meta="$1"
    [ -f "$_meta" ] || return 1
    _sdir="$(proton_guest_renew_meta_get "$_meta" "SESSION_DIR")"
    _sname="$(proton_guest_renew_meta_get "$_meta" "SESSION_NAME")"
    if proton_guest_renew_bundle_complete "$_sdir"; then
        printf '%s\n' "$_sdir"
        return 0
    fi
    _psess="$(proton_guest_renew_profile_sessions_dir 2>/dev/null || true)"
    if [ -n "$_sname" ] && [ -n "$_psess" ] && proton_guest_renew_bundle_complete "$_psess/$_sname"; then
        printf '%s\n' "$_psess/$_sname"
        return 0
    fi
    if [ -n "$_sname" ] && [ -n "${PROTON_SESSIONS_DIR:-}" ] && \
        proton_guest_renew_bundle_complete "$PROTON_SESSIONS_DIR/$_sname"; then
        printf '%s\n' "$PROTON_SESSIONS_DIR/$_sname"
        return 0
    fi
    return 1
}

proton_guest_renew_is_guest_meta() {
    _meta="$1"
    [ -f "$_meta" ] || return 1
    _kind="$(proton_guest_renew_meta_get "$_meta" "GENERATOR_KIND")"
    [ "$_kind" = "proton" ] || return 1
    _mode="$(proton_guest_renew_infer_auth_mode "$_meta")"
    [ "$_mode" = "guest" ]
}

proton_guest_renew_is_guest_iface() {
    _meta="$(proton_guest_renew_iface_meta_path "$1" 2>/dev/null || true)"
    [ -n "$_meta" ] || return 1
    proton_guest_renew_is_guest_meta "$_meta"
}

# Как proton_session_cookie_auth_expiry_epoch в proton-api.sh (без source всего API).
proton_guest_renew_web_cookie_expiry_unix() {
    _f="$1/cookies.txt"
    [ -f "$_f" ] || {
        printf '0\n'
        return 0
    }
    awk -F '\t' '
        BEGIN { best = 0 }
        NF >= 7 {
            name = $6
            expts = $5 + 0
            if ((name ~ /^AUTH-/ || name ~ /^REFRESH-/) && expts > best) {
                best = expts
            }
        }
        END { printf "%d\n", best }
    ' "$_f" 2>/dev/null || printf '0\n'
}

# 0 = AUTH/REFRESH cookie ещё не истекла (локальный признак валидной web-сессии).
proton_guest_renew_web_session_unexpired() {
    _d="$1"
    _exp="$(proton_guest_renew_web_cookie_expiry_unix "$_d")"
    _now="$(proton_guest_renew_now)"
    case "$_exp" in
        ''|*[!0-9]*) return 1 ;;
    esac
    case "$_now" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$_exp" -gt 0 ] && [ "$_exp" -gt "$_now" ]
}

# Guest: новая credentialless-сессия + .conf (как WARP). Web: bundle + непросроченные cookies.
proton_guest_renew_can_renew_meta() {
    _meta="$1"
    [ -f "$_meta" ] || return 1
    _kind="$(proton_guest_renew_meta_get "$_meta" "GENERATOR_KIND")"
    [ "$_kind" = "proton" ] || return 1
    if proton_guest_renew_is_guest_meta "$_meta"; then
        return 0
    fi
    _dir="$(proton_guest_renew_resolve_session_dir "$_meta" 2>/dev/null || true)"
    [ -n "$_dir" ] || return 1
    proton_guest_renew_bundle_complete "$_dir" || return 1
    proton_guest_renew_web_session_unexpired "$_dir"
}

proton_guest_renew_can_renew_iface() {
    _meta="$(proton_guest_renew_iface_meta_path "$1" 2>/dev/null || true)"
    [ -n "$_meta" ] || return 1
    proton_guest_renew_can_renew_meta "$_meta"
}

proton_guest_renew_cert_unix() {
    _meta="$1"
    [ -f "$_meta" ] || return 0
    proton_guest_renew_meta_get "$_meta" "CERT_EXPIRATION_UNIX"
}

proton_guest_renew_now() {
    date +%s 2>/dev/null || echo 0
}

# 0 = due (expired or within skew). Missing/invalid unix → not due (expiry mode skips).
proton_guest_renew_cert_due() {
    _unix="$1"
    _now="${2:-}"
    _skew="${3:-}"
    [ -n "$_now" ] || _now="$(proton_guest_renew_now)"
    [ -n "$_skew" ] || _skew="${PROTON_GUEST_RENEW_SKEW_SEC:-600}"
    case "$_unix" in
        ''|*[!0-9]*) return 1 ;;
    esac
    case "$_now" in
        ''|*[!0-9]*) return 1 ;;
    esac
    case "$_skew" in
        ''|*[!0-9]*) _skew=600 ;;
    esac
    [ "$_unix" -le $((_now + _skew)) ]
}

proton_guest_renew_cert_due_iface() {
    _meta="$(proton_guest_renew_iface_meta_path "$1" 2>/dev/null || true)"
    [ -n "$_meta" ] || return 1
    proton_guest_renew_cert_due \
        "$(proton_guest_renew_cert_unix "$_meta")" \
        "$(proton_guest_renew_now)" \
        "${2:-${PROTON_GUEST_RENEW_SKEW_SEC:-600}}"
}

proton_guest_renew_marker_line() {
    _iface="$1"
    _meta="$(proton_guest_renew_iface_meta_path "$_iface" 2>/dev/null || true)"
    [ -f "$_meta" ] || {
        printf '\n'
        return 0
    }
    _kind="$(proton_guest_renew_meta_get "$_meta" "GENERATOR_KIND")"
    [ "$_kind" = "proton" ] || {
        printf '\n'
        return 0
    }
    _mode="$(proton_guest_renew_infer_auth_mode "$_meta")"
    [ -n "$_mode" ] || _mode='?'
    _sess="$(proton_guest_renew_meta_get "$_meta" "SESSION_NAME")"
    [ -n "$_sess" ] || _sess='?'
    _utc="$(proton_guest_renew_meta_get "$_meta" "CERT_EXPIRATION_UTC")"
    [ -n "$_utc" ] || _utc='?'
    printf 'proton=%s sess=%s cert=%s\n' "$_mode" "$_sess" "$_utc"
}

proton_guest_renew_list_guest_ifaces() {
    proton_guest_renew_list_renewable_ifaces
}

proton_guest_renew_list_renewable_ifaces() {
    _dir="$(proton_guest_renew_interfaces_dir 2>/dev/null || true)"
    [ -n "$_dir" ] && [ -d "$_dir" ] || return 0
    for _d in "$_dir"/*/config/source.conf.meta; do
        [ -f "$_d" ] || continue
        _iface="$(basename "$(dirname "$(dirname "$_d")")")"
        proton_guest_renew_can_renew_meta "$_d" || continue
        printf '%s\n' "$_iface"
    done
}

proton_guest_renew_toolbox_root() {
    if [ -n "${USB_WATCH_ROOT_DIR:-}" ]; then
        printf '%s\n' "$USB_WATCH_ROOT_DIR"
        return 0
    fi
    if command -v usb_watch_toolbox_root_dir >/dev/null 2>&1; then
        usb_watch_toolbox_root_dir
        return 0
    fi
    _here="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P 2>/dev/null || true)"
    if [ -n "$_here" ] && [ -f "$_here/../../../regenerate-interface-config.sh" ]; then
        CDPATH= cd -- "$_here/../../.." && pwd -P
        return 0
    fi
    return 1
}

# Пересобрать Proton .conf (guest: новая сессия; web: refresh+auth, иначе skip).
proton_guest_renew_execute() {
    _iface="$1"
    [ -n "$_iface" ] || return 1
    proton_guest_renew_can_renew_iface "$_iface" || return 1
    _root="$(proton_guest_renew_toolbox_root 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _regen="$_root/iface-routing/regenerate-interface-config.sh"
    _apply="$_root/iface-routing/apply-interfaces.sh"
    [ -f "$_regen" ] || return 1
    [ -f "$_apply" ] || return 1
    PROTON_REFRESH_BEFORE_AUTH=1 PROTON_REFRESH_FAIL_HARD=1 \
        sh "$_regen" --iface "$_iface" --force || return 1
    sh "$_apply" --iface "$_iface"
}
