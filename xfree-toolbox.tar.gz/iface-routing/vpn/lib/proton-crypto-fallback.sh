#!/bin/sh
# shellcheck shell=sh

proton_b64_pad() {
    value="$(printf '%s' "$1" | tr '_-' '/+' | tr -d '\r\n\t ')"
    mod=$(( ${#value} % 4 ))

    case "$mod" in
        0) ;;
        2) value="${value}==" ;;
        3) value="${value}=" ;;
        1) die "Некорректная длина base64-строки" ;;
    esac

    printf '%s\n' "$value"
}

# Один сырой байт из двух hex-символов в файл.
# В dash (WSL /bin/sh) printf %b не раскрывает \\xHH — только восьмеричные \\ooo (POSIX).
xfree_hex_byte_append() {
    byte_hex="$1"
    out="$2"
    case "$byte_hex" in
        *[!0-9a-fA-F]*) die "Некорректный hex октет: $byte_hex" ;;
        ??) ;;
        *) die "Некорректный hex октет: $byte_hex" ;;
    esac
    dec=$((0x$byte_hex))
    [ "$dec" -ge 0 ] 2>/dev/null && [ "$dec" -le 255 ] 2>/dev/null || die "Hex вне диапазона: $byte_hex"
    oct="$(printf '%03o' "$dec")"
    printf '%b' "\\$oct" >> "$out"
}

proton_pem_body() {
    tr -d '\r\n\t ' \
        | sed 's/\\n//g; s/-----BEGIN[^-]*-----//g; s/-----END[^-]*-----//g'
}

proton_b64_decode_to_file() {
    value="$(proton_b64_pad "$1")"
    out="$2"

    printf '%s' "$value" | base64 -d > "$out" 2>/dev/null
}

proton_hex_to_b64() {
    hex="$1"
    tmp="$2"

    : > "$tmp"
    i=1
    while [ "$i" -le 64 ]; do
        byte_hex="$(printf '%s' "$hex" | cut -c"$i"-"$((i + 1))")"
        [ -n "$byte_hex" ] || die "Некорректный hex ключ Proton"
        xfree_hex_byte_append "$byte_hex" "$tmp"
        i=$((i + 2))
    done

    base64 < "$tmp" | tr -d '\r\n'
}

proton_file_to_hex() {
    file="$1"
    [ -f "$file" ] || die "Файл не найден: $file"

    if command -v hexdump >/dev/null 2>&1; then
        hexdump -v -e '/1 "%02x"' "$file"
        return 0
    fi

    if command -v od >/dev/null 2>&1; then
        od -An -tx1 -v "$file" | tr -d ' \n'
        return 0
    fi

    die "Не найден ни hexdump, ни od для извлечения Proton key material"
}

proton_extract_private_raw_b64() {
    body="$1"
    der_file="$PROTON_WORKDIR/proton-private-key-der.$$"
    raw_file="$PROTON_WORKDIR/proton-private-key-raw.$$"

    if ! proton_b64_decode_to_file "$body" "$der_file"; then
        rm -f "$der_file" "$raw_file"
        die "Не удалось декодировать PEM private key Proton"
    fi

    der_size="$(wc -c < "$der_file" | awk '{print $1}')"
    [ "$der_size" -ge 32 ] || {
        rm -f "$der_file" "$raw_file"
        die "PEM private key Proton короче 32 байт"
    }

    der_hex="$(proton_file_to_hex "$der_file")"
    marker="04220420"
    case "$der_hex" in
        *"$marker"*)
            after_marker="${der_hex#*$marker}"
            seed_hex="$(printf '%s' "$after_marker" | cut -c1-64)"
            ;;
        *)
            tail_file="$PROTON_WORKDIR/proton-private-key-tail.$$"
            tail -c 32 "$der_file" > "$tail_file"
            seed_hex="$(proton_file_to_hex "$tail_file")"
            rm -f "$tail_file"
            ;;
    esac

    [ "$(printf '%s' "$seed_hex" | wc -c | awk '{print $1}')" = "64" ] || {
        rm -f "$der_file" "$raw_file"
        die "Не удалось извлечь ED25519 seed из private key Proton"
    }

    proton_hex_to_b64 "$seed_hex" "$raw_file"
    rm -f "$der_file" "$raw_file"
}

proton_extract_public_raw_b64() {
    body="$1"
    der_file="$PROTON_WORKDIR/proton-public-key-der.$$"

    if ! proton_b64_decode_to_file "$body" "$der_file"; then
        rm -f "$der_file"
        die "Не удалось декодировать PEM public key Proton"
    fi

    der_size="$(wc -c < "$der_file" | awk '{print $1}')"
    [ "$der_size" -ge 32 ] || {
        rm -f "$der_file"
        die "PEM public key Proton короче 32 байт"
    }

    tail -c 32 "$der_file" | base64 | tr -d '\r\n'
    rm -f "$der_file"
}
