#!/bin/sh
# shellcheck shell=sh

proton_b64_pad() {
    value="$(printf '%s' "$1" | tr '_-' '/+' | tr -d '\r\n\t ')"
    mod=$(( ${#value} % 4 ))

    case "$mod" in
        0) ;;
        2) value="${value}==" ;;
        3) value="${value}=" ;;
        1) die "Некорректная длина base64-строки" ;;
    esac

    printf '%s\n' "$value"
}

# Один сырой байт из двух hex-символов в файл.
# В dash (WSL /bin/sh) printf %b не раскрывает \\xHH — только восьмеричные \\ooo (POSIX).
xfree_hex_byte_append() {
    byte_hex="$1"
    out="$2"
    case "$byte_hex" in
        *[!0-9a-fA-F]*) die "Некорректный hex октет: $byte_hex" ;;
        ??) ;;
        *) die "Некорректный hex октет: $byte_hex" ;;
    esac
    dec=$((0x$byte_hex))
    [ "$dec" -ge 0 ] 2>/dev/null && [ "$dec" -le 255 ] 2>/dev/null || die "Hex вне диапазона: $byte_hex"
    oct="$(printf '%03o' "$dec")"
    printf '%b' "\\$oct" >> "$out"
}

proton_pem_body() {
    tr -d '\r\n\t ' \
        | sed 's/\\n//g; s/-----BEGIN[^-]*-----//g; s/-----END[^-]*-----//g'
}

proton_b64_decode_to_file() {
    value="$(proton_b64_pad "$1")"
    out="$2"

    printf '%s' "$value" | base64 -d > "$out" 2>/dev/null
}

proton_hex_to_b64() {
    hex="$1"
    tmp="$2"

    : > "$tmp"
    i=1
    while [ "$i" -le 64 ]; do
        byte_hex="$(printf '%s' "$hex" | cut -c"$i"-"$((i + 1))")"
        [ -n "$byte_hex" ] || die "Некорректный hex ключ Proton"
        xfree_hex_byte_append "$byte_hex" "$tmp"
        i=$((i + 2))
    done

    base64 < "$tmp" | tr -d '\r\n'
}

proton_file_to_hex() {
    file="$1"
    [ -f "$file" ] || die "Файл не найден: $file"

    if command -v hexdump >/dev/null 2>&1; then
        hexdump -v -e '/1 "%02x"' "$file"
        return 0
    fi

    if command -v od >/dev/null 2>&1; then
        od -An -tx1 -v "$file" | tr -d ' \n'
        return 0
    fi

    die "Не найден ни hexdump, ни od для извлечения Proton key material"
}

proton_extract_private_raw_b64() {
    body="$1"
    der_file="$PROTON_WORKDIR/proton-private-key-der.$$"
    raw_file="$PROTON_WORKDIR/proton-private-key-raw.$$"

    if ! proton_b64_decode_to_file "$body" "$der_file"; then
        rm -f "$der_file" "$raw_file"
        die "Не удалось декодировать PEM private key Proton"
    fi

    der_size="$(wc -c < "$der_file" | awk '{print $1}')"
    [ "$der_size" -ge 32 ] || {
        rm -f "$der_file" "$raw_file"
        die "PEM private key Proton короче 32 байт"
    }

    der_hex="$(proton_file_to_hex "$der_file")"
    marker="04220420"
    case "$der_hex" in
        *"$marker"*)
            after_marker="${der_hex#*$marker}"
            seed_hex="$(printf '%s' "$after_marker" | cut -c1-64)"
            ;;
        *)
            tail_file="$PROTON_WORKDIR/proton-private-key-tail.$$"
            tail -c 32 "$der_file" > "$tail_file"
            seed_hex="$(proton_file_to_hex "$tail_file")"
            rm -f "$tail_file"
            ;;
    esac

    [ "$(printf '%s' "$seed_hex" | wc -c | awk '{print $1}')" = "64" ] || {
        rm -f "$der_file" "$raw_file"
        die "Не удалось извлечь ED25519 seed из private key Proton"
    }

    proton_hex_to_b64 "$seed_hex" "$raw_file"
    rm -f "$der_file" "$raw_file"
}

proton_extract_public_raw_b64() {
    body="$1"
    der_file="$PROTON_WORKDIR/proton-public-key-der.$$"

    if ! proton_b64_decode_to_file "$body" "$der_file"; then
        rm -f "$der_file"
        die "Не удалось декодировать PEM public key Proton"
    fi

    der_size="$(wc -c < "$der_file" | awk '{print $1}')"
    [ "$der_size" -ge 32 ] || {
        rm -f "$der_file"
        die "PEM public key Proton короче 32 байт"
    }

    tail -c 32 "$der_file" | base64 | tr -d '\r\n'
    rm -f "$der_file"
}

# Вычисление X25519 Private Key из Ed25519 Seed (RFC 7748 / RFC 8032):
# SHA-512(seed)[0..32] с применением curve25519 clamping:
#   first_byte &= 248 (очистка нижних 3 бит)
#   last_byte = (last_byte & 127) | 64 (очистка бита 255, установка бита 254)
x25519_private_from_ed25519_seed_b64() {
    seed_b64="$1"
    [ -n "$seed_b64" ] || die "Пустой ED25519 seed"

    tmp_dir="${TMPDIR:-/tmp}"
    tmp_seed="$tmp_dir/proton-ed25519-seed.$$"
    tmp_bin="$tmp_dir/proton-x25519-bin.$$"

    seed_b64="$(proton_b64_pad "$seed_b64")"
    if ! printf '%s' "$seed_b64" | base64 -d > "$tmp_seed" 2>/dev/null; then
        rm -f "$tmp_seed" "$tmp_bin"
        die "Не удалось декодировать ED25519 seed из base64"
    fi

    seed_size="$(wc -c < "$tmp_seed" | awk '{print $1}')"
    [ "$seed_size" = "32" ] || {
        rm -f "$tmp_seed" "$tmp_bin"
        die "Ожидался ED25519 seed длиной 32 байта, получено: $seed_size"
    }

    hash_hex="$(sha512sum "$tmp_seed" | awk '{print $1}')"
    [ -n "$hash_hex" ] || {
        rm -f "$tmp_seed" "$tmp_bin"
        die "Не удалось вычислить SHA-512 для ED25519 seed"
    }

    key_hex="$(printf '%s' "$hash_hex" | cut -c1-64)"

    first_dec=$(( 0x$(printf '%s' "$key_hex" | cut -c1-2) ))
    last_dec=$(( 0x$(printf '%s' "$key_hex" | cut -c63-64) ))

    first_dec=$(( first_dec & 248 ))
    last_dec=$(( (last_dec & 127) | 64 ))

    key_hex="$(printf '%02x' "$first_dec")$(printf '%s' "$key_hex" | cut -c3-62)$(printf '%02x' "$last_dec")"

    command -v proton_hex_to_b64 >/dev/null 2>&1 \
        || die "proton_hex_to_b64 недоступен (загрузите proton-crypto-fallback.sh через proton-api.sh)"
    result="$(proton_hex_to_b64 "$key_hex" "$tmp_bin")"
    [ -n "$result" ] || {
        rm -f "$tmp_seed" "$tmp_bin"
        die "Не удалось закодировать X25519 private key в base64"
    }

    rm -f "$tmp_seed" "$tmp_bin"
    printf '%s\n' "$result"
}
