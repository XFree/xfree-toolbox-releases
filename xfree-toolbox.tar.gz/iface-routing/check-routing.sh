#!/bin/sh
set -u

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
UI_SH="$ROOT_DIR/lib/ui.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/iface-runtime.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 2
}
. "$COMMON_SH"

[ -f "$UI_SH" ] && . "$UI_SH"

FAIL_COUNT=0
WARN_COUNT=0

check_ok() {
    success "$*"
}

warn_check() {
    warn "$*"
    WARN_COUNT=$((WARN_COUNT + 1))
}

fail_check() {
    error "$*"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

section() {
    echo
    echo "==== $* ===="
}

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

trim_local() {
    printf '%s' "$1" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//'
}

# AmneziaWG: peer lines в `awg show|wg show IFACE dump` — tab, поле 5 = latest_handshake epoch (0 = never).
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/vpn-handshake.sh"

wg_dump_max_handshake_ts() {
    vpn_handshake_dump_max_ts "$1"
}

check_vpn_handshake() {
    vpn_dev="$1"
    if ! ip link show "$vpn_dev" >/dev/null 2>&1; then
        return 0
    fi
    dump_out="$(vpn_handshake_dump_for_dev "$vpn_dev" 2>/dev/null || true)"
    if [ -z "$dump_out" ]; then
        warn_check "Handshake: нет dump (не AmneziaWG на $vpn_dev или недоступны awg/wg)"
        return
    fi
    max_ts="$(wg_dump_max_handshake_ts "$dump_out")"
    if [ -z "$max_ts" ] || [ "$max_ts" = "0" ]; then
        fail_check "Handshake: не выполнялся (latest_handshake=0) или peer не найден в dump"
        return
    fi
    now="$(date +%s 2>/dev/null || echo 0)"
    age=$((now - max_ts))
    if [ "$now" -eq 0 ] || [ "$age" -lt 0 ]; then
        warn_check "Handshake: некорректный возраст (date/ts), latest_ts=$max_ts"
        return
    fi
    if [ "$age" -gt 600 ]; then
        warn_check "Handshake устарел: ${age}s назад (порог 600s)"
    elif [ "$age" -gt 180 ]; then
        warn_check "Handshake давний: ${age}s назад (порог 180s для активного туннеля)"
    else
        check_ok "Handshake свежий: ${age}s назад (AmneziaWG: awg|wg dump)"
    fi
}

run_https_vpn_probe() {
    vpn_dev="$1"
    url="$2"
    if [ "${HTTPS_PROBE_DISABLE:-0}" = "1" ]; then
        check_ok "HTTPS-проверка отключена (HTTPS_PROBE_DISABLE=1)"
        return
    fi
    if ! command -v curl >/dev/null 2>&1; then
        warn_check "curl не найден: HTTPS-проверка через $vpn_dev пропущена"
        return
    fi
    if curl -fsS --connect-timeout "${HTTPS_PROBE_CONNECT_TIMEOUT:-10}" --max-time "${HTTPS_PROBE_MAX_TIME:-15}" \
        --interface "$vpn_dev" -o /dev/null "$url" 2>/dev/null; then
        check_ok "HTTPS через $vpn_dev OK: $url"
    else
        warn_check "HTTPS через $vpn_dev не удался: $url (см. curl с теми же флагами вручную)"
    fi
}

INTERFACES_DIR=""
QUIET=0
IFACE_ARG=""
CHECK_ALL=0
# Маркер пункта «Все интерфейсы» в интерактивном меню выбора (не имя интерфейса).
XFREE_CHECK_ROUTING_ALL_MARKER='__xfree_check_routing_all__'

usage() {
    cat <<EOF2
Usage:
  $(basename "$0") [options] [iface]

Options:
  -i, --iface NAME   Проверить конкретный интерфейс
  -a, --all          Проверить все интерфейсы (без меню выбора)
  --quiet            Меньше вывода при выборе интерфейса в TTY-режиме
  -h, --help         Показать справку
Интерактивное меню: первый пункт — «Все интерфейсы», далее — по одному профилю.

Стек диагностики: outbound интерфейсы материализуются как AmneziaWG
 (UCI network proto amneziawg_<iface>, утилиты awg и при необходимости wg).
 Пробы выполняются в контексте выбранного VPN_DEV этого интерфейса.

 iface.conf (фрагменты):
  PROTOCOL_LABEL — подпись в отчёте (по умолчанию AmneziaWG)
  SOURCE_META рядом с профильным iface.conf может содержать GENERATOR_KIND (шапка отчёта)
  TEST_IP — цель ICMP (по умолчанию 1.1.1.1); PING_TARGET_IP — явная замена адреса для ping (иначе берётся TEST_IP)
  HTTPS_PROBE_* — см. код / дефолтный URL любой связности
EOF2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        -i|--iface)
            shift
            [ "$#" -gt 0 ] || {
                echo "[-] --iface требует значение" >&2
                exit 2
            }
            IFACE_ARG="$1"
            ;;
        -a|--all)
            CHECK_ALL=1
            ;;
        --quiet)
            QUIET=1
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            if [ -z "$IFACE_ARG" ]; then
                IFACE_ARG="$1"
            else
                echo "[-] Неожиданный аргумент: $1" >&2
                exit 2
            fi
            ;;
    esac
    shift || true
done

for cmd in ip nft ping grep awk uci sed wc find cat basename dirname; do
    require_cmd "$cmd"
done

get_base_dir() {
    if [ -f "$CONFIG_FILE" ]; then
        cfg_dir="$(CDPATH= cd -- "$(dirname -- "$CONFIG_FILE")" && pwd -P)"
        printf '%s\n' "$cfg_dir"
        return 0
    fi
    printf '%s\n' "$SCRIPT_DIR"
}

BASE_DIR="$(get_base_dir)"
common_load_project_config "$ROOT_DIR"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
SYSTEM_DOMAIN_ROUTING_DIR="${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}"
SYSTEM_INTERFACES_DIR="${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}"
DNSMASQ_DIR="${DNSMASQ_DIR:-/etc/dnsmasq.d/xfree-toolbox-routing}"
DNSMASQ_FILE="${DNSMASQ_FILE:-$DNSMASQ_DIR/90-xfree-toolbox-fqdn-routing.conf}"
NFT_FILE="${NFT_FILE:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/90-xfree-toolbox-fqdn-routing.nft}"
SYSTEM_GENERATED_DIR="${SYSTEM_GENERATED_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/interfaces}"

# Содержательные строки в fqdn.d / prefixes.d каталога (state или профиль — передаётся путём).
_upstream_dir_collect_useful_lines() {
    d="$1"
    [ -d "$d" ] || return 0
    find "$d" -maxdepth 1 -type f ! -name '.*' -print 2>/dev/null | LC_ALL=C sort | while IFS= read -r fp; do
        [ -f "$fp" ] || continue
        grep -vE '^[[:space:]]*(#|$)' "$fp" 2>/dev/null
    done
}

upstream_dir_useful_line_count() {
    _upstream_dir_collect_useful_lines "$1" | wc -l | tr -cd '0-9'
}

# Выход: три числа: всего, «IPv4-подобные» (нет «:»), «IPv6-подобные» (есть «:»).
# Эвристика простая — для смешанных экзотических форматов возможны ложные WARN.
upstream_prefix_classify_counts() {
    d="$1"
    [ -d "$d" ] || {
        printf '0 0 0\n'
        return 0
    }
    _upstream_dir_collect_useful_lines "$d" | awk '
        NF {
            total++
            if ($0 ~ /:/) has6++; else has4++
        }
        END { printf "%d %d %d\n", total + 0, has4 + 0, has6 + 0 }
    '
}

list_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    find "$INTERFACES_DIR" -type f -path '*/config/iface.conf' 2>/dev/null \
        | sed "s|$INTERFACES_DIR/||" \
        | sed 's|/config/iface.conf$||' \
        | sed '/^$/d' \
        | sort -u
}

choose_interface_interactive() {
    tmp="$(mktemp)"
    trap 'rm -f "$tmp"' EXIT INT TERM

    list_interfaces > "$tmp"

    if [ ! -s "$tmp" ]; then
        echo "[-] Не найдены интерфейсы в каталоге: $INTERFACES_DIR" >&2
        return 1
    fi

    if command -v ui_menu >/dev/null 2>&1; then
        # whiptail возвращает tag: 1=все, 2..=интерфейсы (подпись — только имя).
        set -- "1" "Все"
        mi=2
        while IFS= read -r iface; do
            [ -n "${iface:-}" ] || continue
            set -- "$@" "$mi" "$iface"
            mi=$((mi + 1))
        done < "$tmp"

        choice="$(ui_menu "Проверка маршрутизации" "Интерфейс" 20 90 14 "$@" || true)"
        [ -n "${choice:-}" ] || return 1
        case "$choice" in
            ''|*[!0-9]*) return 1 ;;
            1) printf '%s\n' "$XFREE_CHECK_ROUTING_ALL_MARKER" ;;
            *)
                max_tag=$((mi - 1))
                if ! [ "$choice" -ge 2 ] 2>/dev/null || ! [ "$choice" -le "$max_tag" ] 2>/dev/null; then
                    return 1
                fi
                pick="$(sed -n "$((choice - 1))p" "$tmp")"
                [ -n "$pick" ] || return 1
                printf '%s\n' "$pick"
                ;;
        esac
    else
        if [ "$QUIET" != "1" ]; then
            echo " 1) Все" >&2
            i=2
            while IFS= read -r iface_ln; do
                [ -n "${iface_ln:-}" ] || continue
                echo " $i) $iface_ln" >&2
                i=$((i + 1))
            done < "$tmp"
            printf 'Выберите номер: ' >&2
        fi
        IFS= read -r num || return 1
        case "$num" in
            ''|*[!0-9]*) return 1 ;;
            1) printf '%s\n' "$XFREE_CHECK_ROUTING_ALL_MARKER" ;;
            *)
                idx=$((num - 1))
                pick="$(sed -n "${idx}p" "$tmp")"
                [ -n "$pick" ] || return 1
                printf '%s\n' "$pick"
                ;;
        esac
    fi

    trap - EXIT INT TERM
    rm -f "$tmp"
}

load_iface_context() {
    iface="$1"
    iface="$(sanitize_name "$iface")"
    [ -n "$iface" ] || {
        echo "[-] Имя интерфейса пустое" >&2
        exit 2
    }

    conf_file="$INTERFACES_DIR/$iface/config/iface.conf"
    [ -f "$conf_file" ] || {
        echo "[-] Не найден конфиг интерфейса: $conf_file" >&2
        exit 2
    }

    INTERFACE_NAME=''
    VPN_DEV=''
    MARK_HEX=''
    ROUTE_TABLE_ID=''
    ROUTE_TABLE_NAME=''
    IP_RULE_PREF=''
    TEST_IP=''
    PING_TARGET_IP=''
    HTTPS_PROBE_URL=''
    HTTPS_PROBE_DISABLE=''
    HTTPS_PROBE_CONNECT_TIMEOUT=''
    HTTPS_PROBE_MAX_TIME=''

    NFT_FQDN_SET_NAME=''
    NFT_PREFIX_SET_NAME=''
    NFT_FQDN4_SET_NAME=''
    NFT_FQDN6_SET_NAME=''
    NFT_PREFIX4_SET_NAME=''
    NFT_PREFIX6_SET_NAME=''
    NFT_CHAIN_NAME=''
    NFT_OUTPUT_CHAIN_NAME=''
    PERSISTENT_KEEPALIVE_DEFAULT=''
    AMNEZIAWG_PEER_SECTION=''
    SOURCE_META=''
    PROTOCOL_LABEL=''

    # shellcheck disable=SC1090
    . "$conf_file"

    INTERFACE_NAME="$(trim_local "${INTERFACE_NAME:-$iface}")"
    VPN_DEV="$(trim_local "${VPN_DEV:-$INTERFACE_NAME}")"
    MARK_HEX="$(trim_local "${MARK_HEX:-}")"
    ROUTE_TABLE_NAME="$(trim_local "${ROUTE_TABLE_NAME:-$INTERFACE_NAME}")"
    IP_RULE_PREF="$(trim_local "${IP_RULE_PREF:-10000}")"
    # ICMP через VPN_DEV: по умолчанию 1.1.1.1; при странных ответах ICMP можно задать TEST_IP / PING_TARGET_IP в iface.conf.
    TEST_IP="$(trim_local "${TEST_IP:-1.1.1.1}")"
    PING_TARGET_IP="$(trim_local "${PING_TARGET_IP:-$TEST_IP}")"
    HTTPS_PROBE_URL="$(trim_local "${HTTPS_PROBE_URL:-https://connectivitycheck.gstatic.com/generate_204}")"
    HTTPS_PROBE_DISABLE="$(trim_local "${HTTPS_PROBE_DISABLE:-0}")"
    HTTPS_PROBE_CONNECT_TIMEOUT="$(trim_local "${HTTPS_PROBE_CONNECT_TIMEOUT:-10}")"
    HTTPS_PROBE_MAX_TIME="$(trim_local "${HTTPS_PROBE_MAX_TIME:-15}")"
    export HTTPS_PROBE_DISABLE HTTPS_PROBE_CONNECT_TIMEOUT HTTPS_PROBE_MAX_TIME

    PROTOCOL_LABEL="$(trim_local "${PROTOCOL_LABEL:-AmneziaWG}")"
    SOURCE_META="$(trim_local "${SOURCE_META:-source.conf.meta}")"
    SOURCE_META_FILE="$(dirname "$conf_file")/$SOURCE_META"
    GENERATOR_KIND_FROM_META=""
    if [ -f "$SOURCE_META_FILE" ]; then
        GENERATOR_KIND_FROM_META="$(sed -n "s/^GENERATOR_KIND='\([^']*\)'.*/\1/p" "$SOURCE_META_FILE" | head -n 1)"
        GENERATOR_KIND_FROM_META="$(trim_local "$GENERATOR_KIND_FROM_META")"
    fi

    NFT_FQDN4_SET_NAME="$(trim_local "${NFT_FQDN4_SET_NAME:-}")"
    NFT_FQDN6_SET_NAME="$(trim_local "${NFT_FQDN6_SET_NAME:-}")"
    NFT_PREFIX4_SET_NAME="$(trim_local "${NFT_PREFIX4_SET_NAME:-}")"
    NFT_PREFIX6_SET_NAME="$(trim_local "${NFT_PREFIX6_SET_NAME:-}")"
    NFT_CHAIN_NAME="$(trim_local "${NFT_CHAIN_NAME:-mangle_prerouting_${INTERFACE_NAME}}")"
    NFT_OUTPUT_CHAIN_NAME="$(trim_local "${NFT_OUTPUT_CHAIN_NAME:-mangle_output_${INTERFACE_NAME}}")"

    if [ -z "$NFT_FQDN4_SET_NAME" ] && [ -n "${NFT_FQDN_SET_NAME:-}" ]; then
        NFT_FQDN4_SET_NAME="$(trim_local "$NFT_FQDN_SET_NAME")"
    fi
    if [ -z "$NFT_PREFIX4_SET_NAME" ] && [ -n "${NFT_PREFIX_SET_NAME:-}" ]; then
        NFT_PREFIX4_SET_NAME="$(trim_local "$NFT_PREFIX_SET_NAME")"
    fi

    GENERATED_DIR="$SYSTEM_GENERATED_DIR/$iface"
    GENERATED_FQDN_FILE="$GENERATED_DIR/fqdn.generated.lst"
    GENERATED_PREFIXES4_FILE="$GENERATED_DIR/prefixes4.generated.lst"
    GENERATED_PREFIXES6_FILE="$GENERATED_DIR/prefixes6.generated.lst"
    GENERATED_PREFIXES_FILE="$GENERATED_DIR/prefixes.generated.lst"

    STATE_IFACE_ROOT="$SYSTEM_INTERFACES_DIR/$iface"
    STATE_FQDN_DIR="$STATE_IFACE_ROOT/fqdn.d"
    STATE_PREFIX_DIR="$STATE_IFACE_ROOT/prefixes.d"
}

list_awg_peer_sections_for_type() {
    peer_type="$1"
    uci show network 2>/dev/null | sed -n "s/^\(network\.[^.]*\)=${peer_type}$/\1/p"
}

find_awg_peer_section() {
    peer_type="amneziawg_${VPN_DEV}"

    if [ -n "${AMNEZIAWG_PEER_SECTION:-}" ] \
        && uci -q get "${AMNEZIAWG_PEER_SECTION}.public_key" >/dev/null 2>&1; then
        echo "$AMNEZIAWG_PEER_SECTION"
        return 0
    fi

    for s in $(list_awg_peer_sections_for_type "$peer_type"); do
        pk="$(uci -q get "$s.persistent_keepalive" || true)"
        rai="$(uci -q get "$s.route_allowed_ips" || true)"
        if [ "$pk" = "${PERSISTENT_KEEPALIVE_DEFAULT:-20}" ] && [ "$rai" = "0" ]; then
            echo "$s"
            return 0
        fi
    done

    for s in $(list_awg_peer_sections_for_type "$peer_type"); do
        echo "$s"
        return 0
    done

    return 1
}

resolve_peer_route_allowed_ips() {
    peer_section="$1"
    val="$(uci -q get "${peer_section}.route_allowed_ips" || true)"
    case "$val" in
        0|1) printf '%s\n' "$val" ;;
        *) printf 'unknown\n' ;;
    esac
}

# UCI list allowed_ips у peer: есть ли ::/… (справочно; не то же, что «IP-адреса» интерфейса).
uci_peer_allowed_ips_has_ipv6() {
    peer_section="$1"
    [ -n "$peer_section" ] || return 1
    uci show "$peer_section" 2>/dev/null | grep -F '.allowed_ips=' | grep -qF '::/'
}

# network.<dev>: в UCI задан ли IPv6 на интерфейсе (LuCI «IP-адреса» → list addresses / ipaddr / ip6addr).
uci_network_iface_declares_ipv6() {
    ndev="$1"
    [ -n "$ndev" ] || return 1
    pkg="network"
    i6="$(uci -q get "${pkg}.${ndev}.ip6addr" 2>/dev/null || true)"
    case "$i6" in
        *:*)
            return 0
            ;;
    esac
    uci show "${pkg}.${ndev}" 2>/dev/null | grep -E '\.(ipaddr|addresses)=' | grep -qE "'[^']*:[^']*'" && return 0
    return 1
}

show_peer_details() {
    peer_section="$1"
    echo "      peer_section=$peer_section"
    echo "      description=$(uci -q get "$peer_section.description" || echo '<empty>')"
    echo "      endpoint_host=$(uci -q get "$peer_section.endpoint_host" || echo '<empty>')"
    echo "      endpoint_port=$(uci -q get "$peer_section.endpoint_port" || echo '<empty>')"
    echo "      route_allowed_ips=$(uci -q get "$peer_section.route_allowed_ips" || echo '<empty>')"
    echo "      persistent_keepalive=$(uci -q get "$peer_section.persistent_keepalive" || echo '<empty>')"
    ai_dump="$(uci show "$peer_section" 2>/dev/null | grep -F '.allowed_ips=' || true)"
    if [ -n "$ai_dump" ]; then
        echo "$ai_dump" | sed 's/^/      /'
    else
        echo "      allowed_ips=<нет строк .allowed_ips= в uci show>"
    fi
}

check_one_iface() {
    iface="$1"
    load_iface_context "$iface"

    local_fail_start="$FAIL_COUNT"
    local_warn_start="$WARN_COUNT"
    ACTIVE_AMNEZIAWG_PEER_SECTION="$(find_awg_peer_section || true)"
    ROUTE_ALLOWED_IPS_EFFECTIVE="unknown"
    EXPECT_DEFAULT_VPN_ROUTE="unknown"

    VPN_UCI_ADDRESSES_HAVE_IPV6=0
    if [ -n "${VPN_DEV:-}" ] && uci_network_iface_declares_ipv6 "$VPN_DEV"; then
        VPN_UCI_ADDRESSES_HAVE_IPV6=1
    fi

    PEER_ALLOWED_IPS_HAS_V6=0
    if [ -n "$ACTIVE_AMNEZIAWG_PEER_SECTION" ]; then
        ROUTE_ALLOWED_IPS_EFFECTIVE="$(resolve_peer_route_allowed_ips "$ACTIVE_AMNEZIAWG_PEER_SECTION")"
        case "$ROUTE_ALLOWED_IPS_EFFECTIVE" in
            1) EXPECT_DEFAULT_VPN_ROUTE="yes" ;;
            0) EXPECT_DEFAULT_VPN_ROUTE="no" ;;
            *) EXPECT_DEFAULT_VPN_ROUTE="unknown" ;;
        esac
        if uci_peer_allowed_ips_has_ipv6 "$ACTIVE_AMNEZIAWG_PEER_SECTION"; then
            PEER_ALLOWED_IPS_HAS_V6=1
        fi
    fi

    # Policy-table / fwmark IPv6: только если на туннеле есть глобальный IPv6 (иначе типичен IPv4-only fwmark).
    EXPECT_V6_POLICY_CHECKS=0
    VPN_DEV_LINK_OK=0

    echo
    echo "======================================="
    echo " Domain Routing Check: $iface"
    echo "======================================="
    echo "VPN_STACK=$PROTOCOL_LABEL (UCI proto amneziawg_* ; awg|wg + привязка к VPN_DEV)"
    if [ -n "$GENERATOR_KIND_FROM_META" ]; then
        echo "SOURCE_META=$SOURCE_META  GENERATOR_KIND=$GENERATOR_KIND_FROM_META"
    else
        echo "SOURCE_META=$SOURCE_META  GENERATOR_KIND=<нет или нет файла: $SOURCE_META_FILE>"
    fi
    echo "VPN_DEV=${VPN_DEV:-<empty>}"
    echo "ROUTE_TABLE_NAME=${ROUTE_TABLE_NAME:-<empty>}"
    echo "MARK_HEX=${MARK_HEX:-<empty>}"
    echo "PING_TARGET_IP=$PING_TARGET_IP"
    echo "HTTPS_PROBE_URL=$HTTPS_PROBE_URL (HTTPS_PROBE_DISABLE=$HTTPS_PROBE_DISABLE)"
    if [ -n "$ACTIVE_AMNEZIAWG_PEER_SECTION" ]; then
        echo "PEER_SECTION=$ACTIVE_AMNEZIAWG_PEER_SECTION"
        echo "ROUTE_ALLOWED_IPS=${ROUTE_ALLOWED_IPS_EFFECTIVE}"
        echo "VPN_UCI_ADDRESSES_IPV6=${VPN_UCI_ADDRESSES_HAVE_IPV6} (network.${VPN_DEV:-?}: list addresses / ipaddr / ip6addr — задан ли IPv6, как в LuCI «IP-адреса»)"
        echo "PEER_allowed_ips_::=${PEER_ALLOWED_IPS_HAS_V6} (справочно: peer list allowed_ips; conf-to-interface часто добавляет ::/0)"
    else
        echo "PEER_SECTION=<not found>"
        echo "ROUTE_ALLOWED_IPS=<unknown>"
        echo "VPN_UCI_ADDRESSES_IPV6=${VPN_UCI_ADDRESSES_HAVE_IPV6} (network.${VPN_DEV:-?}: list addresses / ipaddr / ip6addr)"
        echo "PEER_allowed_ips_::=0"
    fi
    if [ "${PEER_ALLOWED_IPS_HAS_V6:-0}" -eq 1 ] && [ "${VPN_UCI_ADDRESSES_HAVE_IPV6:-0}" -eq 0 ] && [ -n "${VPN_DEV:-}" ]; then
        echo "NOTE: в peer allowed_ips есть ::/, в network.$VPN_DEV в IP-адресах (addresses) IPv6 не задан — ниже ориентируемся на адреса интерфейса, не на allowed_ips."
    fi
    echo "======================================="

    section "Интерфейс VPN"

    if ip link show "$VPN_DEV" >/dev/null 2>&1; then
        VPN_DEV_LINK_OK=1
        LINK_LINE="$(ip link show "$VPN_DEV" | awk 'NR==1{print}')"
        STATE="$(ip link show "$VPN_DEV" | awk '/state/ {for (i=1; i<=NF; i++) if ($i=="state") {print $(i+1); exit}}')"
        IFSTATUS_JSON="$(ifstatus "$VPN_DEV" 2>/dev/null || true)"

        check_ok "Интерфейс $VPN_DEV существует"
        echo "      $LINK_LINE"

        if echo "$IFSTATUS_JSON" | grep -q '"up": true'; then
        check_ok "Интерфейс $VPN_DEV поднят по данным ifstatus"
        elif [ "${STATE:-UNKNOWN}" = "UP" ]; then
        check_ok "Интерфейс $VPN_DEV находится в состоянии UP"
        elif echo "$LINK_LINE" | grep -q 'POINTOPOINT' && echo "$LINK_LINE" | grep -q 'LOWER_UP'; then
        check_ok "Для POINTOPOINT-интерфейса состояние state=${STATE:-UNKNOWN} допустимо, link=LOWER_UP"
        else
            warn_check "Интерфейс $VPN_DEV не подтверждён как поднятый (state=${STATE:-UNKNOWN})"
        fi

        IPV4_LINE="$(ip -4 addr show dev "$VPN_DEV" 2>/dev/null | awk '/inet / {print $2; exit}')"
        if [ -n "${IPV4_LINE:-}" ]; then
        check_ok "На интерфейсе $VPN_DEV есть IPv4-адрес: $IPV4_LINE"
        else
            warn_check "На интерфейсе $VPN_DEV нет IPv4-адреса"
        fi

        IPV6_LINE="$(ip -6 addr show dev "$VPN_DEV" scope global 2>/dev/null | awk '/inet6 / {print $2; exit}')"
        if [ -n "${IPV6_LINE:-}" ]; then
        check_ok "На интерфейсе $VPN_DEV есть IPv6-адрес: $IPV6_LINE"
        EXPECT_V6_POLICY_CHECKS=1
        else
            if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "no" ]; then
                if [ "$VPN_UCI_ADDRESSES_HAVE_IPV6" -eq 1 ]; then
                    warn_check "Нет глобального IPv6 на $VPN_DEV, но в UCI (network.$VPN_DEV addresses) IPv6 задан — ожидался GUA на интерфейсе; проверьте применение конфига / peer"
                else
                    check_ok "Нет глобального IPv6 на $VPN_DEV — в network.$VPN_DEV в IP-адресах (addresses) нет IPv6; при route_allowed_ips=0 policy обычно IPv4-only (норма)"
                fi
            elif [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
                if [ "$VPN_UCI_ADDRESSES_HAVE_IPV6" -eq 1 ]; then
                    warn_check "Нет глобального IPv6 на $VPN_DEV при route_allowed_ips=1 и IPv6 в UCI addresses — peer не выдал адрес на интерфейс или сбой"
                else
                    check_ok "Нет глобального IPv6 на $VPN_DEV — в network.$VPN_DEV в addresses нет IPv6; туннель по UCI IPv4-only (это норма)"
                fi
            else
                if [ "$VPN_UCI_ADDRESSES_HAVE_IPV6" -eq 1 ]; then
                    warn_check "Нет глобального IPv6 на $VPN_DEV (route_allowed_ips не 0/1); в UCI addresses задан IPv6 — проверьте применение и peer"
                else
                    warn_check "Нет глобального IPv6 на $VPN_DEV (route_allowed_ips неизвестен; в network.$VPN_DEV addresses IPv6 не задан)"
                fi
            fi
        fi
    else
        fail_check "Интерфейс $VPN_DEV не найден"
    fi

    section "Проверка handshake (AmneziaWG → awg|wg dump)"
    check_vpn_handshake "$VPN_DEV"

    section "Таблица маршрутизации"

    ROUTE_TABLE_OUTPUT4="$(ip route show table "$ROUTE_TABLE_NAME" 2>/dev/null || true)"
    ROUTE_TABLE_OUTPUT6="$(ip -6 route show table "$ROUTE_TABLE_NAME" 2>/dev/null || true)"

    if [ -n "$ROUTE_TABLE_OUTPUT4" ]; then
        check_ok "Таблица $ROUTE_TABLE_NAME для IPv4 существует и не пуста"
        echo "$ROUTE_TABLE_OUTPUT4" | sed 's/^/      /'
    else
        warn_check "Таблица маршрутизации IPv4 $ROUTE_TABLE_NAME пуста или недоступна"
    fi

    has_default_route4=0
    if echo "$ROUTE_TABLE_OUTPUT4" | grep -q "^default dev $VPN_DEV"; then
        has_default_route4=1
    fi
    if [ "$has_default_route4" -eq 1 ]; then
        check_ok "В таблице $ROUTE_TABLE_NAME есть default route IPv4 через $VPN_DEV"
        if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "no" ]; then
            check_ok "route_allowed_ips=0: default route IPv4 в $ROUTE_TABLE_NAME ожидаем для policy-routing по fwmark"
        fi
    else
        if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
            fail_check "route_allowed_ips=1, но в таблице $ROUTE_TABLE_NAME нет default route IPv4 через $VPN_DEV"
        else
            warn_check "В таблице $ROUTE_TABLE_NAME нет default route IPv4 через $VPN_DEV"
        fi
    fi

    if [ "$EXPECT_V6_POLICY_CHECKS" -eq 1 ]; then
        if [ -n "$ROUTE_TABLE_OUTPUT6" ]; then
            check_ok "Таблица $ROUTE_TABLE_NAME для IPv6 существует и не пуста"
            echo "$ROUTE_TABLE_OUTPUT6" | sed 's/^/      /'
        else
            warn_check "Таблица маршрутизации IPv6 $ROUTE_TABLE_NAME пуста или недоступна"
        fi

        has_default_route6=0
        if echo "$ROUTE_TABLE_OUTPUT6" | grep -q "^default dev $VPN_DEV"; then
            has_default_route6=1
        fi
        if [ "$has_default_route6" -eq 1 ]; then
            check_ok "В таблице $ROUTE_TABLE_NAME есть default route IPv6 через $VPN_DEV"
            if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "no" ]; then
                check_ok "route_allowed_ips=0: default route IPv6 в $ROUTE_TABLE_NAME ожидаем для policy-routing по fwmark"
            fi
        else
            if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
                warn_check "route_allowed_ips=1, но в таблице $ROUTE_TABLE_NAME нет default route IPv6 через $VPN_DEV"
            else
                warn_check "В таблице $ROUTE_TABLE_NAME нет default route IPv6 через $VPN_DEV"
            fi
        fi
    else
        if [ "$VPN_DEV_LINK_OK" -eq 1 ]; then
            if [ -n "$ROUTE_TABLE_OUTPUT6" ]; then
                check_ok "Таблица $ROUTE_TABLE_NAME для IPv6 не пуста (дополнительно к IPv4-only policy)"
                echo "$ROUTE_TABLE_OUTPUT6" | sed 's/^/      /'
            else
                check_ok "Таблица $ROUTE_TABLE_NAME для IPv6 пуста — на $VPN_DEV нет глобального IPv6 (policy routing IPv4-only, норма)"
            fi
            if echo "$ROUTE_TABLE_OUTPUT6" | grep -q "^default dev $VPN_DEV"; then
                check_ok "В таблице $ROUTE_TABLE_NAME есть default route IPv6 через $VPN_DEV"
            elif [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
                check_ok "Нет default route IPv6 в $ROUTE_TABLE_NAME — без глобального IPv6 на $VPN_DEV для policy по fwmark не требуется"
            else
                check_ok "Нет default route IPv6 в $ROUTE_TABLE_NAME — при отсутствии глобального IPv6 на $VPN_DEV не требуется для fwmark-policy"
            fi
        else
            if [ -n "$ROUTE_TABLE_OUTPUT6" ]; then
                check_ok "Таблица $ROUTE_TABLE_NAME для IPv6 существует и не пуста"
                echo "$ROUTE_TABLE_OUTPUT6" | sed 's/^/      /'
            else
                warn_check "Таблица маршрутизации IPv6 $ROUTE_TABLE_NAME пуста или недоступна"
            fi
            has_default_route6=0
            if echo "$ROUTE_TABLE_OUTPUT6" | grep -q "^default dev $VPN_DEV"; then
                has_default_route6=1
            fi
            if [ "$has_default_route6" -eq 1 ]; then
                check_ok "В таблице $ROUTE_TABLE_NAME есть default route IPv6 через $VPN_DEV"
            elif [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
                warn_check "route_allowed_ips=1, но в таблице $ROUTE_TABLE_NAME нет default route IPv6 через $VPN_DEV"
            else
                warn_check "В таблице $ROUTE_TABLE_NAME нет default route IPv6 через $VPN_DEV"
            fi
        fi
    fi

    section "Policy routing"

    RULE_OUTPUT4="$(ip rule show 2>/dev/null | grep "$ROUTE_TABLE_NAME" || true)"
    RULE_OUTPUT6="$(ip -6 rule show 2>/dev/null | grep "$ROUTE_TABLE_NAME" || true)"

    if [ -n "$RULE_OUTPUT4" ]; then
        check_ok "Найдены ip rule для таблицы $ROUTE_TABLE_NAME"
        echo "$RULE_OUTPUT4" | sed 's/^/      /'
    else
        fail_check "Не найдены ip rule для таблицы $ROUTE_TABLE_NAME"
    fi

    if ip rule show 2>/dev/null | grep -F "fwmark $MARK_HEX" | grep -q "$ROUTE_TABLE_NAME"; then
        check_ok "Есть правило fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv4)"
    else
        fail_check "Нет правила fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv4)"
    fi

    if [ "$EXPECT_V6_POLICY_CHECKS" -eq 1 ]; then
        if [ -n "$RULE_OUTPUT6" ]; then
            check_ok "Найдены ip -6 rule для таблицы $ROUTE_TABLE_NAME"
            echo "$RULE_OUTPUT6" | sed 's/^/      /'
        else
            warn_check "Не найдены ip -6 rule для таблицы $ROUTE_TABLE_NAME"
        fi

        if ip -6 rule show 2>/dev/null | grep -F "fwmark $MARK_HEX" | grep -q "$ROUTE_TABLE_NAME"; then
            check_ok "Есть правило fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
        else
            warn_check "Нет правила fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
        fi
    else
        if [ "$VPN_DEV_LINK_OK" -eq 1 ]; then
            if [ -n "$RULE_OUTPUT6" ] || ip -6 rule show 2>/dev/null | grep -F "fwmark $MARK_HEX" | grep -q "$ROUTE_TABLE_NAME"; then
                check_ok "IPv6 policy (ip -6 rule / fwmark) настроен для $ROUTE_TABLE_NAME"
                [ -n "$RULE_OUTPUT6" ] && echo "$RULE_OUTPUT6" | sed 's/^/      /'
            else
                check_ok "ip -6 rule/fwmark для $ROUTE_TABLE_NAME отсутствуют — нет глобального IPv6 на $VPN_DEV (IPv4-only policy, норма)"
            fi
        else
            if [ -n "$RULE_OUTPUT6" ]; then
                check_ok "Найдены ip -6 rule для таблицы $ROUTE_TABLE_NAME"
                echo "$RULE_OUTPUT6" | sed 's/^/      /'
            else
                warn_check "Не найдены ip -6 rule для таблицы $ROUTE_TABLE_NAME"
            fi
            if ip -6 rule show 2>/dev/null | grep -F "fwmark $MARK_HEX" | grep -q "$ROUTE_TABLE_NAME"; then
                check_ok "Есть правило fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
            else
                warn_check "Нет правила fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
            fi
        fi
    fi

    section "dnsmasq и generated files"

    if [ -f "$DNSMASQ_FILE" ]; then
        check_ok "Файл dnsmasq-конфига существует: $DNSMASQ_FILE"
        if [ -n "$NFT_FQDN4_SET_NAME" ] && grep -Fq "$NFT_FQDN4_SET_NAME" "$DNSMASQ_FILE"; then
            check_ok "dnsmasq-конфиг содержит IPv4 nftset для FQDN"
        else
            warn_check "dnsmasq-конфиг не содержит IPv4 nftset для FQDN"
        fi
        if [ -n "$NFT_FQDN6_SET_NAME" ] && grep -Fq "$NFT_FQDN6_SET_NAME" "$DNSMASQ_FILE"; then
            check_ok "dnsmasq-конфиг содержит IPv6 nftset для FQDN"
        else
            warn_check "dnsmasq-конфиг не содержит IPv6 nftset для FQDN"
        fi
    else
        fail_check "Файл dnsmasq-конфига отсутствует: $DNSMASQ_FILE"
    fi

    STATE_FQDN_EXPECT="$(upstream_dir_useful_line_count "$STATE_FQDN_DIR")"

    set -- $(upstream_prefix_classify_counts "$STATE_PREFIX_DIR")
    PREFIX_EXPECT_TOTAL="${1:-0}"
    PREFIX_EXPECT_V4_HINT="${2:-0}"
    PREFIX_EXPECT_V6_HINT="${3:-0}"

    if [ -f "$GENERATED_FQDN_FILE" ]; then
        if [ -s "$GENERATED_FQDN_FILE" ]; then
            FQDN_COUNT="$(wc -l < "$GENERATED_FQDN_FILE" 2>/dev/null || echo 0)"
        check_ok "Сгенерированный список FQDN существует, строк: $FQDN_COUNT"
        else
            if [ "${STATE_FQDN_EXPECT:-0}" -eq 0 ]; then
                check_ok "Сгенерированный список FQDN пуст — в state fqdn.d нет содержательных строк (норма для применённого state)"
            else
                warn_check "Сгенерированный список FQDN пуст, а в state (~$STATE_IFACE_ROOT) fqdn.d есть ~${STATE_FQDN_EXPECT} содержательных строк"
            fi
        fi
    else
        fail_check "Сгенерированный список FQDN отсутствует: $GENERATED_FQDN_FILE"
    fi

    if [ -f "$GENERATED_PREFIXES4_FILE" ]; then
        if [ -s "$GENERATED_PREFIXES4_FILE" ]; then
            PREFIX4_COUNT="$(wc -l < "$GENERATED_PREFIXES4_FILE" 2>/dev/null || echo 0)"
        check_ok "Сгенерированный список префиксов IPv4 существует, строк: $PREFIX4_COUNT"
        else
            if [ "${PREFIX_EXPECT_V4_HINT:-0}" -eq 0 ]; then
                check_ok "Префиксы IPv4 в generated пусты — в state prefixes.d нет IPv4-подобных строк (норма)"
            else
                warn_check "Префиксы IPv4 в generated пусты при ~${PREFIX_EXPECT_V4_HINT} IPv4-подобных строках в state prefixes.d (~$STATE_IFACE_ROOT)"
            fi
        fi
    elif [ -f "$GENERATED_PREFIXES_FILE" ]; then
        if [ -s "$GENERATED_PREFIXES_FILE" ]; then
            PREFIX_COUNT="$(wc -l < "$GENERATED_PREFIXES_FILE" 2>/dev/null || echo 0)"
            check_ok "Сгенерированный legacy-список префиксов существует, строк: $PREFIX_COUNT"
        else
            if [ "${PREFIX_EXPECT_TOTAL:-0}" -eq 0 ]; then
                check_ok "Legacy-префиксы в generated пусты — state prefixes.d без содержательных строк (норма)"
            else
                warn_check "Legacy-префиксы в generated пусты при ~${PREFIX_EXPECT_TOTAL} содержательных строках в state prefixes.d (~$STATE_IFACE_ROOT)"
            fi
        fi
    else
        if [ "${PREFIX_EXPECT_V4_HINT:-0}" -eq 0 ]; then
            check_ok "Файл префиксов IPv4 generated отсутствует — в state нет ожидания IPv4 (prefixes.d): $GENERATED_PREFIXES4_FILE"
        else
            warn_check "Сгенерированный список префиксов IPv4 отсутствует: $GENERATED_PREFIXES4_FILE"
        fi
    fi

    if [ -f "$GENERATED_PREFIXES6_FILE" ]; then
        if [ -s "$GENERATED_PREFIXES6_FILE" ]; then
            PREFIX6_COUNT="$(wc -l < "$GENERATED_PREFIXES6_FILE" 2>/dev/null || echo 0)"
        check_ok "Сгенерированный список префиксов IPv6 существует, строк: $PREFIX6_COUNT"
        else
            if [ "${PREFIX_EXPECT_V6_HINT:-0}" -eq 0 ]; then
                check_ok "Префиксы IPv6 в generated пусты — в state prefixes.d нет строк с «:» (норма для только IPv4)"
            else
                warn_check "Префиксы IPv6 в generated пусты при ~${PREFIX_EXPECT_V6_HINT} IPv6-подобных строках в state prefixes.d (~$STATE_IFACE_ROOT)"
            fi
        fi
    else
        if [ "${PREFIX_EXPECT_V6_HINT:-0}" -eq 0 ]; then
            check_ok "Файл префиксов IPv6 generated отсутствует — по state prefixes.d ожидания IPv6 по эвристике нет: $GENERATED_PREFIXES6_FILE"
        else
            warn_check "Сгенерированный список префиксов IPv6 отсутствует: $GENERATED_PREFIXES6_FILE"
        fi
    fi

    section "nftables"

    if [ -n "$NFT_FQDN4_SET_NAME" ]; then
        if nft list set inet fw4 "$NFT_FQDN4_SET_NAME" >/dev/null 2>&1; then
        check_ok "nft set существует: inet fw4 $NFT_FQDN4_SET_NAME"
        else
            fail_check "nft set отсутствует: inet fw4 $NFT_FQDN4_SET_NAME"
        fi
    else
        warn_check "NFT_FQDN4_SET_NAME не задан"
    fi

    if [ -n "$NFT_FQDN6_SET_NAME" ]; then
        if nft list set inet fw4 "$NFT_FQDN6_SET_NAME" >/dev/null 2>&1; then
        check_ok "nft set существует: inet fw4 $NFT_FQDN6_SET_NAME"
        else
            warn_check "nft set отсутствует: inet fw4 $NFT_FQDN6_SET_NAME"
        fi
    else
        warn_check "NFT_FQDN6_SET_NAME не задан"
    fi

    if [ -n "$NFT_PREFIX4_SET_NAME" ]; then
        if nft list set inet fw4 "$NFT_PREFIX4_SET_NAME" >/dev/null 2>&1; then
        check_ok "nft set существует: inet fw4 $NFT_PREFIX4_SET_NAME"
        else
            warn_check "nft set отсутствует: inet fw4 $NFT_PREFIX4_SET_NAME"
        fi
    else
        warn_check "NFT_PREFIX4_SET_NAME не задан"
    fi

    if [ -n "$NFT_PREFIX6_SET_NAME" ]; then
        if nft list set inet fw4 "$NFT_PREFIX6_SET_NAME" >/dev/null 2>&1; then
        check_ok "nft set существует: inet fw4 $NFT_PREFIX6_SET_NAME"
        else
            warn_check "nft set отсутствует: inet fw4 $NFT_PREFIX6_SET_NAME"
        fi
    else
        warn_check "NFT_PREFIX6_SET_NAME не задан"
    fi

    if [ -n "$NFT_CHAIN_NAME" ]; then
        if nft list chain inet fw4 "$NFT_CHAIN_NAME" >/dev/null 2>&1; then
        check_ok "nft chain существует: inet fw4 $NFT_CHAIN_NAME"
        else
            fail_check "nft chain отсутствует: inet fw4 $NFT_CHAIN_NAME"
        fi
    else
        fail_check "NFT_CHAIN_NAME не задан"
    fi

    if [ -n "$NFT_OUTPUT_CHAIN_NAME" ]; then
        if nft list chain inet fw4 "$NFT_OUTPUT_CHAIN_NAME" >/dev/null 2>&1; then
            check_ok "nft output chain существует: inet fw4 $NFT_OUTPUT_CHAIN_NAME"
            output_chain_type="$(nft -a list chain inet fw4 "$NFT_OUTPUT_CHAIN_NAME" 2>/dev/null | sed -n 's/.*type \([a-z]*\) hook output.*/\1/p' | head -n1)"
            if [ "$output_chain_type" = "route" ]; then
                check_ok "nft output chain type=route (reroute после mark для local traffic)"
            else
                fail_check "nft output chain type=${output_chain_type:-unknown}; нужен type route hook output (filter не делает reroute)"
            fi
        else
            fail_check "nft output chain отсутствует: inet fw4 $NFT_OUTPUT_CHAIN_NAME"
        fi
    else
        warn_check "NFT_OUTPUT_CHAIN_NAME не задан"
    fi

    if [ -f "$NFT_FILE" ]; then
        check_ok "Файл nft include существует: $NFT_FILE"
    else
        fail_check "Файл nft include отсутствует: $NFT_FILE"
    fi

    section "firewall include"

    FOUND_INCLUDE=""
    for s in $(uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=include$/\1/p"); do
        path="$(uci -q get "$s.path" || true)"
        if [ "$path" = "$NFT_FILE" ]; then
            FOUND_INCLUDE="$s"
            break
        fi
    done

    if [ -n "$FOUND_INCLUDE" ]; then
        check_ok "Найден firewall include: $FOUND_INCLUDE"
        echo "      path=$(uci -q get "$FOUND_INCLUDE.path" || true)"
        echo "      enabled=$(uci -q get "$FOUND_INCLUDE.enabled" || true)"
        echo "      type=$(uci -q get "$FOUND_INCLUDE.type" || true)"
        echo "      fw4_compatible=$(uci -q get "$FOUND_INCLUDE.fw4_compatible" || true)"
    else
        fail_check "Firewall include для domain-routing не найден"
    fi

    section "Проверка ping через VPN"

    if ip link show "$VPN_DEV" >/dev/null 2>&1; then
        if ping -I "$VPN_DEV" -c 3 -W 2 "$PING_TARGET_IP" >/dev/null 2>&1; then
        check_ok "Ping через интерфейс $VPN_DEV до $PING_TARGET_IP успешен"
        else
            warn_check "Ping через интерфейс $VPN_DEV до $PING_TARGET_IP не прошёл"
        fi
    else
        fail_check "Проверка ping через VPN невозможна: интерфейс $VPN_DEV отсутствует"
    fi

    section "Проверка HTTPS (curl --interface VPN_DEV; транспорт AmneziaWG)"
    run_https_vpn_probe "$VPN_DEV" "$HTTPS_PROBE_URL"

    section "Проверка маршрута по fwmark"

    RULE_BY_MARK4="$(ip rule show 2>/dev/null | grep -F "fwmark $MARK_HEX" | grep "$ROUTE_TABLE_NAME" || true)"
    ROUTE_IN_TABLE4="$(ip route show table "$ROUTE_TABLE_NAME" 2>/dev/null || true)"
    DEFAULT_ROUTE_LINE4="$(printf '%s\n' "$ROUTE_IN_TABLE4" | grep '^default ' | head -n 1 || true)"

    if [ -n "$RULE_BY_MARK4" ]; then
        check_ok "Есть правило fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv4)"
        echo "$RULE_BY_MARK4" | sed 's/^/      /'
    else
        fail_check "Нет правила fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv4)"
    fi

    if [ -n "$DEFAULT_ROUTE_LINE4" ]; then
        echo "$DEFAULT_ROUTE_LINE4" | sed 's/^/      /'
        if echo "$DEFAULT_ROUTE_LINE4" | grep -q "dev $VPN_DEV"; then
        check_ok "В таблице $ROUTE_TABLE_NAME default route IPv4 идёт через $VPN_DEV"
            if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "no" ]; then
                check_ok "route_allowed_ips=0: default route IPv4 в $ROUTE_TABLE_NAME ожидаем для policy-routing по fwmark"
            fi
        else
            warn_check "В таблице $ROUTE_TABLE_NAME default route IPv4 не идёт через $VPN_DEV"
        fi
    else
        if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
            fail_check "route_allowed_ips=1, но в таблице $ROUTE_TABLE_NAME отсутствует default route IPv4"
        else
            warn_check "В таблице $ROUTE_TABLE_NAME отсутствует default route IPv4"
        fi
    fi

    RULE_BY_MARK6="$(ip -6 rule show 2>/dev/null | grep -F "fwmark $MARK_HEX" | grep "$ROUTE_TABLE_NAME" || true)"
    ROUTE_IN_TABLE6="$(ip -6 route show table "$ROUTE_TABLE_NAME" 2>/dev/null || true)"
    DEFAULT_ROUTE_LINE6="$(printf '%s\n' "$ROUTE_IN_TABLE6" | grep '^default ' | head -n 1 || true)"

    if [ "$EXPECT_V6_POLICY_CHECKS" -eq 1 ]; then
        if [ -n "$RULE_BY_MARK6" ]; then
            check_ok "Есть правило fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
            echo "$RULE_BY_MARK6" | sed 's/^/      /'
        else
            warn_check "Нет правила fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
        fi

        if [ -n "$DEFAULT_ROUTE_LINE6" ]; then
            echo "$DEFAULT_ROUTE_LINE6" | sed 's/^/      /'
            if echo "$DEFAULT_ROUTE_LINE6" | grep -q "dev $VPN_DEV"; then
            check_ok "В таблице $ROUTE_TABLE_NAME default route IPv6 идёт через $VPN_DEV"
                if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "no" ]; then
                    check_ok "route_allowed_ips=0: default route IPv6 в $ROUTE_TABLE_NAME ожидаем для policy-routing по fwmark"
                fi
            else
                warn_check "В таблице $ROUTE_TABLE_NAME default route IPv6 не идёт через $VPN_DEV"
            fi
        else
            if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
                warn_check "route_allowed_ips=1, но в таблице $ROUTE_TABLE_NAME отсутствует default route IPv6"
            else
                warn_check "В таблице $ROUTE_TABLE_NAME отсутствует default route IPv6"
            fi
        fi
    else
        if [ "$VPN_DEV_LINK_OK" -eq 1 ]; then
            if [ -n "$RULE_BY_MARK6" ]; then
                check_ok "Есть правило fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
                echo "$RULE_BY_MARK6" | sed 's/^/      /'
            else
                check_ok "Нет правила fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6) — нет глобального IPv6 на $VPN_DEV (норма)"
            fi

            if [ -n "$DEFAULT_ROUTE_LINE6" ]; then
                echo "$DEFAULT_ROUTE_LINE6" | sed 's/^/      /'
                if echo "$DEFAULT_ROUTE_LINE6" | grep -q "dev $VPN_DEV"; then
                    check_ok "В таблице $ROUTE_TABLE_NAME default route IPv6 идёт через $VPN_DEV"
                else
                    warn_check "В таблице $ROUTE_TABLE_NAME default route IPv6 не идёт через $VPN_DEV"
                fi
            else
                if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
                    check_ok "В таблице $ROUTE_TABLE_NAME нет default route IPv6 — без глобального IPv6 на $VPN_DEV для policy не требуется"
                else
                    check_ok "В таблице $ROUTE_TABLE_NAME нет default route IPv6 — при отсутствии глобального IPv6 на $VPN_DEV не требуется"
                fi
            fi
        else
            if [ -n "$RULE_BY_MARK6" ]; then
                check_ok "Есть правило fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
                echo "$RULE_BY_MARK6" | sed 's/^/      /'
            else
                warn_check "Нет правила fwmark $MARK_HEX -> lookup $ROUTE_TABLE_NAME (IPv6)"
            fi

            if [ -n "$DEFAULT_ROUTE_LINE6" ]; then
                echo "$DEFAULT_ROUTE_LINE6" | sed 's/^/      /'
                if echo "$DEFAULT_ROUTE_LINE6" | grep -q "dev $VPN_DEV"; then
                    check_ok "В таблице $ROUTE_TABLE_NAME default route IPv6 идёт через $VPN_DEV"
                    if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "no" ]; then
                        check_ok "route_allowed_ips=0: default route IPv6 в $ROUTE_TABLE_NAME ожидаем для policy-routing по fwmark"
                    fi
                else
                    warn_check "В таблице $ROUTE_TABLE_NAME default route IPv6 не идёт через $VPN_DEV"
                fi
            else
                if [ "$EXPECT_DEFAULT_VPN_ROUTE" = "yes" ]; then
                    warn_check "route_allowed_ips=1, но в таблице $ROUTE_TABLE_NAME отсутствует default route IPv6"
                else
                    warn_check "В таблице $ROUTE_TABLE_NAME отсутствует default route IPv6"
                fi
            fi
        fi
    fi

    section "Peer options"

    if [ -n "$ACTIVE_AMNEZIAWG_PEER_SECTION" ]; then
        check_ok "Найдена секция peer: $ACTIVE_AMNEZIAWG_PEER_SECTION"
        show_peer_details "$ACTIVE_AMNEZIAWG_PEER_SECTION"

        CURRENT_ROUTE_ALLOWED_IPS="$(uci -q get "${ACTIVE_AMNEZIAWG_PEER_SECTION}.route_allowed_ips" || true)"
        if [ "$CURRENT_ROUTE_ALLOWED_IPS" = "0" ] || [ "$CURRENT_ROUTE_ALLOWED_IPS" = "1" ]; then
            check_ok "route_allowed_ips у $ACTIVE_AMNEZIAWG_PEER_SECTION установлен в $CURRENT_ROUTE_ALLOWED_IPS"
        else
            warn_check "route_allowed_ips у $ACTIVE_AMNEZIAWG_PEER_SECTION имеет значение '${CURRENT_ROUTE_ALLOWED_IPS:-<empty>}'"
        fi

        CURRENT_PERSISTENT_KEEPALIVE="$(uci -q get "${ACTIVE_AMNEZIAWG_PEER_SECTION}.persistent_keepalive" || true)"
        if [ "$CURRENT_PERSISTENT_KEEPALIVE" = "${PERSISTENT_KEEPALIVE_DEFAULT:-20}" ]; then
        check_ok "persistent_keepalive у $ACTIVE_AMNEZIAWG_PEER_SECTION установлен в ${PERSISTENT_KEEPALIVE_DEFAULT:-20}"
        else
            warn_check "persistent_keepalive у $ACTIVE_AMNEZIAWG_PEER_SECTION имеет значение '${CURRENT_PERSISTENT_KEEPALIVE:-<empty>}'"
        fi
    else
        warn_check "Секция amneziawg peer не найдена"
    fi

    local_fail=$((FAIL_COUNT - local_fail_start))
    local_warn=$((WARN_COUNT - local_warn_start))

    echo
    echo "---------------------------------------"
    echo " Итого по интерфейсу $iface"
    echo "---------------------------------------"
    echo "FAIL: $local_fail"
    echo "WARN: $local_warn"
    echo
}

perform_check_all_interfaces() {
    ifaces="$(list_interfaces || true)"
    [ -n "${ifaces:-}" ] || {
        echo "[-] Не найдены интерфейсы в каталоге: $INTERFACES_DIR" >&2
        exit 2
    }

    total_fail_ifaces=0
    total_warn_ifaces=0
    total_fail_count=0
    total_warn_count=0
    tmp_results="$(mktemp)"
    trap 'rm -f "$tmp_results"' EXIT INT TERM

    printf '%s\n' "$ifaces" | while IFS= read -r iface_run; do
        [ -n "${iface_run:-}" ] || continue
        FAIL_COUNT=0
        WARN_COUNT=0
        check_one_iface "$iface_run"
        printf '%s|%s|%s\n' "$iface_run" "$FAIL_COUNT" "$WARN_COUNT" >> "$tmp_results"
    done

    while IFS='|' read -r _iface_run failc warnc; do
        failc="${failc:-0}"
        warnc="${warnc:-0}"
        [ "$failc" -gt 0 ] && total_fail_ifaces=$((total_fail_ifaces + 1))
        [ "$warnc" -gt 0 ] && total_warn_ifaces=$((total_warn_ifaces + 1))
        total_fail_count=$((total_fail_count + failc))
        total_warn_count=$((total_warn_count + warnc))
    done < "$tmp_results"

    echo "======================================="
    echo " Общий результат"
    echo "======================================="
    echo "Интерфейсов с FAIL: $total_fail_ifaces"
    echo "Интерфейсов с WARN: $total_warn_ifaces"
    echo "Всего FAIL: $total_fail_count"
    echo "Всего WARN: $total_warn_count"

    if [ "$total_fail_ifaces" -gt 0 ]; then
        echo "ИТОГ: ОБНАРУЖЕНЫ КРИТИЧЕСКИЕ ПРОБЛЕМЫ"
        exit 2
    fi

    if [ "$total_warn_ifaces" -gt 0 ]; then
        echo "ИТОГ: РАБОТАЕТ, НО ЕСТЬ ПРЕДУПРЕЖДЕНИЯ"
        exit 1
    fi

    echo "ИТОГ: ВСЁ РАБОТАЕТ КОРРЕКТНО"
    exit 0
}

main() {
    if [ "$CHECK_ALL" = "1" ]; then
        perform_check_all_interfaces
    fi

    iface="${IFACE_ARG:-}"
    if [ -z "$iface" ]; then
        iface="$(choose_interface_interactive || true)"
        [ -n "${iface:-}" ] || exit 0
    fi

    if [ "$iface" = "$XFREE_CHECK_ROUTING_ALL_MARKER" ]; then
        perform_check_all_interfaces
    fi

    FAIL_COUNT=0
    WARN_COUNT=0
    check_one_iface "$iface"

    echo "======================================="
    echo " Результат проверки"
    echo "======================================="
    echo "FAIL: $FAIL_COUNT"
    echo "WARN: $WARN_COUNT"

    if [ "$FAIL_COUNT" -gt 0 ]; then
        echo "ИТОГ: ОБНАРУЖЕНЫ КРИТИЧЕСКИЕ ПРОБЛЕМЫ"
        exit 2
    fi

    if [ "$WARN_COUNT" -gt 0 ]; then
        echo "ИТОГ: РАБОТАЕТ, НО ЕСТЬ ПРЕДУПРЕЖДЕНИЯ"
        exit 1
    fi

    echo "ИТОГ: ВСЁ РАБОТАЕТ КОРРЕКТНО"
    exit 0
}

main "$@"
