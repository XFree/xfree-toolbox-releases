#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/ui.sh"
. "$ROOT_DIR/lib/upstreams.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/selection/upstream-selection.sh"

CONFIG_FILE="$SCRIPT_DIR/ui.conf"
[ -f "$CONFIG_FILE" ] || die "Не найден ui.conf: $CONFIG_FILE"

# Absolute PROFILE_DIR from caller (profile-generator host materialize / apply) wins.
# Do NOT snapshot relative XFREE_PROFILE_DIR before load — menu shells often keep
# stale profiles/default from early config.sh `:=` and then ui.conf builds
# ../profiles/default/iface-routing/interfaces.
_override_profile_dir=""
if [ -n "${XFREE_APPLY_PROFILE_DIR:-}" ] && [ -d "$XFREE_APPLY_PROFILE_DIR" ]; then
    _override_profile_dir="$XFREE_APPLY_PROFILE_DIR"
elif [ -n "${PROFILE_DIR:-}" ]; then
    case "$PROFILE_DIR" in
        /*)
            [ -d "$PROFILE_DIR" ] && _override_profile_dir="$PROFILE_DIR"
            ;;
    esac
fi

common_load_project_config "$ROOT_DIR"
# shellcheck disable=SC1091
. "$CONFIG_FILE"

if [ -n "$_override_profile_dir" ]; then
    PROFILE_DIR="$_override_profile_dir"
else
    PROFILE_DIR="$(common_profile_dir "$ROOT_DIR")"
fi
INTERFACES_DIR="$PROFILE_DIR/iface-routing/interfaces"
export PROFILE_DIR INTERFACES_DIR
unset _override_profile_dir

RUNTIME_FILE="${DOMAIN_ROUTING_RUNTIME:-$SCRIPT_DIR/iface-runtime.sh}"

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

BASE_DIR="$(common_resolve_path "$SCRIPT_DIR" "${BASE_DIR:-.}")"
# INTERFACES_DIR is absolute after resolve above; keep absolute (do not re-root under iface-routing/).
case "$INTERFACES_DIR" in
    /*) ;;
    *) INTERFACES_DIR="$(common_resolve_path "$BASE_DIR" "${INTERFACES_DIR:-interfaces}")" ;;
esac
UPSTREAMS_DIR="$(common_resolve_path "$BASE_DIR" "${UPSTREAMS_DIR:-upstreams}")"

WORK_FQDN_DIR=""
WORK_PREFIX_DIR=""
ACTIVE_FQDN_DIR=""
ACTIVE_PREFIX_DIR=""
GENERATED_DIR=""

load_iface_context() {
    iface="$1"
    iface="$(sanitize_name "$iface")"
    [ -n "$iface" ] || die "Имя интерфейса пустое"

    export INTERFACE_NAME="$iface"

    [ -f "$RUNTIME_FILE" ] || die "Не найден runtime-файл: $RUNTIME_FILE"

    # shellcheck disable=SC1090
    . "$RUNTIME_FILE"
}

show_debug_dump() {
    tmpfile="$1"
    ui_show_textbox "Диагностика выбора" "$tmpfile" 30 120
}

select_lists_for_iface() {
    iface="$1"
    TMP="$(mktemp -d)"
    trap 'rm -rf "$TMP"' EXIT INT TERM

    load_iface_context "$iface"

    cat_dir="$(selection_catalog_prepare "$ROOT_DIR")" || true
    if [ -z "${cat_dir:-}" ] || [ ! -s "$cat_dir/entities.tsv" ]; then
        if [ "${XFREE_SELECTION_DEBUG:-0}" = "1" ]; then
            {
                echo "=== Интерфейс ==="
                echo "INTERFACE_NAME=$iface"
                echo
                echo "=== Пути ==="
                echo "WORK_FQDN_DIR=$WORK_FQDN_DIR"
                echo "WORK_PREFIX_DIR=$WORK_PREFIX_DIR"
                echo "=== entities.tsv ==="
                sed -n '1,120p' "$cat_dir/entities.tsv" 2>/dev/null || true
                echo
                echo "=== files.tsv ==="
                sed -n '1,200p' "$cat_dir/files.tsv" 2>/dev/null || true
            } > "$TMP/debug.txt"
            show_debug_dump "$TMP/debug.txt"
        fi
        return 1
    fi

    map_tmp="$TMP/map.tsv"
    ui_upstreams_build_label_map "$cat_dir/entities.tsv" "$map_tmp" "all"
    [ -s "$map_tmp" ] || {
        ui_msgbox "Выбор списков" "Не найдены списки для выбора (пустая карта меток)."
        return 1
    }

    enabled_tags_tsv="$TMP/enabled-tags.tsv"
    upstreams_build_enabled_tags_tsv \
        "iface" \
        "$cat_dir/files.tsv" \
        "$WORK_FQDN_DIR" \
        "$WORK_PREFIX_DIR" \
        "all" > "$enabled_tags_tsv"

    # Keep EXIT/INT/TERM trap across checklist (slang SIGINT on Ok; ui-ux-contract).
    if ! CHOICES="$(ui_upstreams_select_tags_from_model \
        "Выбор списков: $iface" \
        "Выберите списки для интерфейса $iface" \
        "$cat_dir/entities.tsv" \
        "$cat_dir/files.tsv" \
        "all" \
        "" \
        "$enabled_tags_tsv")"; then
        # Отмена чеклиста: не трогаем target; 2 — снова выбор интерфейса (select_lists).
        return 2
    fi

    selection_iface_init_module "$SCRIPT_DIR" || die "selection: не удалось инициализировать iface-routing"
    if ! printf '%s\n' "${CHOICES:-}" | selection_iface_materialize_tags_lines "$iface" all; then
        rc=$?
        if [ "$rc" -eq 2 ]; then
            _choices_file="$(mktemp)"
            printf '%s\n' "${CHOICES:-}" > "$_choices_file"
            ui_msgbox "Iface-routing: ошибка материализации" "$(upstreams_staging_mismatch_message "$_choices_file")"
            rm -f "$_choices_file"
            return 0
        fi
        return "$rc"
    fi
}

select_lists() {
    iface="${1:-}"
    fixed_iface="${iface:-}"

    while true; do
        if [ -z "${iface:-}" ]; then
            iface="$(common_select_domain_interface "Выбор интерфейса" "$INTERFACES_DIR" || true)"
            [ -n "${iface:-}" ] || return 0
        fi

        select_lists_for_iface "$iface"
        rc=$?
        if [ -n "$fixed_iface" ]; then
            return "$rc"
        fi
        iface=""
        case "$rc" in
            2) continue ;;
            *) return "$rc" ;;
        esac
    done
}

case "${1:-}" in
    ui)
        select_lists "${2:-}"
        ;;
    *)
        echo "Usage: $0 ui [iface]"
        exit 1
        ;;
esac
