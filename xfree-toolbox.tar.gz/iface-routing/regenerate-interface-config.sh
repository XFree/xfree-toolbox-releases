#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib/proton-template-session.sh"
[ -f "$SCRIPT_DIR/config.sh" ] && . "$SCRIPT_DIR/config.sh"
WARP_META_POLICY_SH="${WARP_META_POLICY_SH:-$SCRIPT_DIR/vpn/lib/warp-meta-policy.sh}"
[ -f "$WARP_META_POLICY_SH" ] && . "$WARP_META_POLICY_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
UPDATE_INTERFACE_CONFIG_SCRIPT="${UPDATE_INTERFACE_CONFIG_SCRIPT:-$SCRIPT_DIR/update-interface-config.sh}"
WARP_GENERATE_SCRIPT="${WARP_GENERATE_SCRIPT:-$SCRIPT_DIR/vpn/warp/generate.sh}"
PROTON_GENERATE_SCRIPT="${PROTON_GENERATE_SCRIPT:-$SCRIPT_DIR/vpn/proton/generate.sh}"

IFACE_NAME=""
FORCE=0

usage() {
    cat <<EOF
Usage: $(basename "$0") --iface <name> [--force]

Rebuilds source.conf and network.uci for an iface-routing interface from
source.conf.meta. Intended for anonymized/template profiles where source.conf
and network.uci were intentionally removed.
EOF
}

meta_get() {
    file="$1"
    key="$2"
    [ -f "$file" ] || return 0
    awk -F= -v want="$key" '
        {
            gsub(/\r/, "")
        }
        $1 == want {
            v = substr($0, index($0, "=") + 1)
            sub(/^[[:space:]]+/, "", v)
            sub(/[[:space:]]+$/, "", v)
            gsub(/^\047|\047$/, "", v)
            print v
            exit
        }
    ' "$file"
}

source_has_private_key() {
    file="$1"
    [ -f "$file" ] || return 1
    grep -q '^PrivateKey=' "$file" 2>/dev/null
}

conf_value() {
    file="$1"
    key="$2"
    [ -f "$file" ] || return 0
    awk -F '=' -v want="$key" '
        $1 ~ "^[[:space:]]*" want "[[:space:]]*$" {
            v = substr($0, index($0, "=") + 1)
            sub(/^[[:space:]]+/, "", v)
            sub(/[[:space:]]+$/, "", v)
            print v
            exit
        }
    ' "$file"
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --iface)
            shift
            [ "$#" -gt 0 ] || die "--iface требует имя"
            IFACE_NAME="$1"
            ;;
        --force)
            FORCE=1
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift || true
done

[ -n "$IFACE_NAME" ] || die "Требуется --iface"
IFACE_NAME="$(printf '%s\n' "$IFACE_NAME" | tr -cd 'A-Za-z0-9._-')"
[ -n "$IFACE_NAME" ] || die "Имя интерфейса после очистки пустое"

iface_dir="$INTERFACES_DIR/$IFACE_NAME"
config_dir="$iface_dir/config"
iface_conf="$config_dir/iface.conf"
source_conf="$config_dir/source.conf"
source_meta="$config_dir/source.conf.meta"
network_uci="$config_dir/network.uci"

[ -f "$iface_conf" ] || die "Не найден iface.conf: $iface_conf"
[ -f "$source_meta" ] || die "Не найден source.conf.meta: $source_meta"
[ -f "$UPDATE_INTERFACE_CONFIG_SCRIPT" ] || die "Не найден update helper: $UPDATE_INTERFACE_CONFIG_SCRIPT"

if [ "$FORCE" != "1" ] && [ -f "$network_uci" ] && source_has_private_key "$source_conf"; then
    info "Конфиг интерфейса уже содержит source.conf и network.uci с PrivateKey: $IFACE_NAME"
    exit 0
fi

generator_kind="$(meta_get "$source_meta" "GENERATOR_KIND")"
[ -n "$generator_kind" ] || die "В source.conf.meta отсутствует GENERATOR_KIND: $source_meta"

# Legacy meta: заполнить SELECTION_MODE/EXCLUDE_RU/SERVER_ID=def; one-shot xfree→def.
if [ "$generator_kind" = "warp" ] && command -v warp_meta_policy_migrate_file >/dev/null 2>&1; then
	_wmp_rc="$(warp_meta_policy_migrate_file "$source_meta" || printf '0')"
	[ "$_wmp_rc" = "1" ] && info "WARP meta policy: нормализован source.conf.meta ($IFACE_NAME)"
fi

profile_mode="$(meta_get "$source_meta" "PROFILE_MODE")"
variant_id="$(meta_get "$source_meta" "VARIANT_ID")"
awg_version="$(meta_get "$source_meta" "AWG_VERSION")"
server_id="$(meta_get "$source_meta" "SERVER_ID")"
session_name="$(meta_get "$source_meta" "SESSION_NAME")"
session_dir="$(meta_get "$source_meta" "SESSION_DIR")"
server_country="$(meta_get "$source_meta" "SERVER_COUNTRY")"
endpoint="$(meta_get "$source_meta" "ENDPOINT")"

tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT HUP INT TERM
tmp_conf_dir="$tmp_dir/conf"
mkdir -p "$tmp_conf_dir"

if [ "$FORCE" = "1" ] && command -v nft >/dev/null 2>&1 && nft list table inet fw4 >/dev/null 2>&1; then
    nft_set_fqdn4="$(conf_value "$iface_conf" "NFT_FQDN4_SET_NAME")"
    [ -z "$nft_set_fqdn4" ] && nft_set_fqdn4="${IFACE_NAME}_fqdn4"
    nft_set_fqdn6="$(conf_value "$iface_conf" "NFT_FQDN6_SET_NAME")"
    [ -z "$nft_set_fqdn6" ] && nft_set_fqdn6="${IFACE_NAME}_fqdn6"
    nft_chain_out="$(conf_value "$iface_conf" "NFT_OUTPUT_CHAIN_NAME")"
    [ -z "$nft_chain_out" ] && nft_chain_out="mangle_output_${IFACE_NAME}"
    nft flush set inet fw4 "$nft_set_fqdn4" 2>/dev/null || true
    nft flush set inet fw4 "$nft_set_fqdn6" 2>/dev/null || true
    nft flush chain inet fw4 "$nft_chain_out" 2>/dev/null || true
fi

case "$generator_kind" in
    warp)
        [ -f "$WARP_GENERATE_SCRIPT" ] || die "Не найден генератор WARP: $WARP_GENERATE_SCRIPT"
        mode_flag="--local"
        [ "$profile_mode" = "raw" ] && mode_flag="--raw"
        variant_flag="${variant_id:-auto}"
        server_flag="${server_id:-def}"
        if is_template_meta_token "$server_flag"; then
            server_flag="def"
            info "WARP restore: SERVER_ID в meta — маркер шаблона, использую --server def"
        fi

        warp_endpoint="$endpoint"
        if is_template_meta_token "$warp_endpoint"; then
            warp_endpoint=""
            info "WARP restore: ENDPOINT в meta — маркер шаблона, endpoint из регистрации/сервера (без --endpoint)"
        fi

        info "Пересборка параметров WARP ($IFACE_NAME)..."
        selection_mode="$(meta_get "$source_meta" "SELECTION_MODE")"
        exclude_ru="$(meta_get "$source_meta" "EXCLUDE_RU")"
        max_servers="$(meta_get "$source_meta" "MAX_SERVERS")"
        warp_rounds="$(meta_get "$source_meta" "PROBE_ROUNDS")"
        i1_mode="$(meta_get "$source_meta" "I1_MODE")"
        i1_domain="$(meta_get "$source_meta" "I1_DOMAIN")"
        awg_noise="$(meta_get "$source_meta" "AWG_NOISE_ENABLED")"
        awg_entropy="$(meta_get "$source_meta" "AWG_I1_ENTROPY")"
        case "$selection_mode" in
            best|random) ;;
            *) selection_mode="best" ;;
        esac
        case "$exclude_ru" in
            0|no|off|false) exclude_ru="0" ;;
            *) exclude_ru="1" ;;
        esac
        set -- "$mode_flag" --server "$server_flag" --variant "$variant_flag"
        if [ -n "$awg_noise" ]; then
            case "$awg_noise" in
                0|no|off|false) set -- "$@" --no-noise ;;
                *) set -- "$@" --with-noise ;;
            esac
        fi
        if [ -n "$awg_entropy" ]; then
            set -- "$@" --i1-entropy "$awg_entropy"
        fi
        case "$selection_mode" in
            random) set -- "$@" --random ;;
            *) set -- "$@" --best ;;
        esac
        if [ "$exclude_ru" = "1" ]; then
            set -- "$@" --exclude-ru
        else
            set -- "$@" --allow-ru
        fi
        [ -n "$max_servers" ] && set -- "$@" --max-servers "$max_servers"
        [ -n "$warp_rounds" ] && set -- "$@" --rounds "$warp_rounds"
        [ -n "$i1_mode" ] && set -- "$@" --i1-mode "$i1_mode"
        [ -n "$i1_domain" ] && set -- "$@" --i1-domain "$i1_domain"
        set -- "$@" --name "restore-$IFACE_NAME"
        # --force: заново выбрать endpoint по SELECTION_MODE; без --force — ENDPOINT из meta.
        if [ "$FORCE" != "1" ] && [ -n "$warp_endpoint" ]; then
            set -- "$@" --endpoint "$warp_endpoint"
        fi
        env CONF_DIR="$tmp_conf_dir" "$WARP_GENERATE_SCRIPT" "$@" >/dev/null
        ;;
    proton)
        [ -f "$PROTON_GENERATE_SCRIPT" ] || die "Не найден генератор Proton: $PROTON_GENERATE_SCRIPT"
        proton_country="${server_country:-NL}"
        is_template_meta_token "$proton_country" && proton_country="NL"
        proton_version="${awg_version:-2.0}"
        is_template_meta_token "$proton_version" && proton_version="2.0"
        proton_variant="${variant_id:-auto}"
        is_template_meta_token "$proton_variant" && proton_variant="auto"
        proton_mode_flag="--local"
        [ "$profile_mode" = "raw" ] && proton_mode_flag="--raw"
        proton_server_name="$(meta_get "$source_meta" "SERVER_NAME")"
        proton_target_server=""
        if is_template_meta_token "$server_id"; then
            server_id=""
        fi
        if is_template_meta_token "$proton_server_name"; then
            proton_server_name=""
        fi
        case "$proton_server_name" in
            "Imported"*"config"|"imported"*"config"|*"import"*) proton_server_name="" ;;
        esac
        if [ -n "$proton_server_name" ]; then
            proton_target_server="$proton_server_name"
        elif [ -n "$server_id" ]; then
            proton_target_server="$server_id"
        fi
        proton_mtu="$(meta_get "$source_meta" "MTU")"
        is_template_meta_token "$proton_mtu" && proton_mtu=""
        proton_free_only="$(meta_get "$source_meta" "FREE_ONLY")"
        is_template_meta_token "$proton_free_only" && proton_free_only=""
        proton_req_ipv6="$(meta_get "$source_meta" "REQUIRE_IPV6")"
        is_template_meta_token "$proton_req_ipv6" && proton_req_ipv6=""
        proton_selection="$(meta_get "$source_meta" "SELECTION_MODE")"
        is_template_meta_token "$proton_selection" && proton_selection=""
        proton_noise="$(meta_get "$source_meta" "AWG_NOISE_ENABLED")"
        is_template_meta_token "$proton_noise" && proton_noise=""
        proton_entropy="$(meta_get "$source_meta" "AWG_I1_ENTROPY")"
        is_template_meta_token "$proton_entropy" && proton_entropy=""
        proton_rounds="$(meta_get "$source_meta" "PROBE_ROUNDS")"
        is_template_meta_token "$proton_rounds" && proton_rounds=""
        proton_port="$(meta_get "$source_meta" "ENDPOINT_PORT")"
        is_template_meta_token "$proton_port" && proton_port=""
        case "$proton_port" in
            *[!0-9]*) proton_port="" ;;
        esac
        proton_probe_via="$(meta_get "$source_meta" "PROBE_VIA")"
        is_template_meta_token "$proton_probe_via" && proton_probe_via=""
        [ -n "$proton_probe_via" ] || proton_probe_via="$(conf_value "$iface_conf" "SELF_ROUTE_VIA")"
        is_template_meta_token "$proton_probe_via" && proton_probe_via=""
        case "$proton_selection" in
            best|interactive) ;;
            *) proton_selection="best" ;;
        esac
        profile_proton_sessions_dir="$PROFILE_DIR/vpn/proton/sessions"
        operator_proton_sessions_dir="${PROTON_SESSIONS_DIR:-}"
        proton_sessions_root=""
        proton_session=""
        proton_generate_env_prefix=""

        resolve_out="$(mktemp "${TMPDIR:-/tmp}/xfree-proton-resolve.XXXXXX")"
        if proton_resolve_session_for_template_restore \
            "$profile_proton_sessions_dir" \
            "$operator_proton_sessions_dir" \
            "${session_name:-}" \
            "${session_dir:-}" >"$resolve_out" 2>/dev/null; then
            proton_sessions_root="$(sed -n '1p' "$resolve_out")"
            proton_session="$(sed -n '2p' "$resolve_out")"
        fi
        rm -f "$resolve_out"

        session_auth_mode="$(meta_get "$source_meta" "SESSION_AUTH_MODE")"
        proton_acquire_guest=0
        if proton_restore_should_acquire_guest \
            "$session_auth_mode" "$session_name" \
            "$proton_sessions_root" "$proton_session"; then
            proton_acquire_guest=1
        fi

        if [ "$proton_acquire_guest" = "1" ]; then
            proton_sessions_root="$profile_proton_sessions_dir"
            mkdir -p "$proton_sessions_root"
            proton_generate_env_prefix="PROTON_SESSIONS_DIR=$proton_sessions_root"
            guest_name_env=""
            if ! is_template_meta_token "$session_name"; then
                case "$session_name" in
                    guest-*) guest_name_env="PROTON_GUEST_SESSION_NAME=$session_name" ;;
                esac
            fi
            info "Proton: получение гостевой сессии и генерация конфигурации..."
            set -- "$proton_mode_flag" --acquire-guest \
                --country "$proton_country" \
                --version "$proton_version" --variant "$proton_variant" \
                --name "restore-$IFACE_NAME"
            case "$proton_selection" in
                interactive) set -- "$@" --interactive ;;
                *) set -- "$@" --best ;;
            esac
            [ -n "$proton_mtu" ] && set -- "$@" --mtu "$proton_mtu"
            case "$proton_free_only" in
                1|yes|YES|true|TRUE) set -- "$@" --free-only ;;
                0|no|NO|false|FALSE) set -- "$@" --all-tiers ;;
            esac
            case "$proton_req_ipv6" in
                1|yes|YES|true|TRUE) set -- "$@" --ipv6-only ;;
                0|no|NO|false|FALSE) set -- "$@" --all-ip ;;
            esac
            case "$proton_noise" in
                1|yes|YES|true|TRUE) set -- "$@" --with-noise ;;
            esac
            [ -n "$proton_entropy" ] && set -- "$@" --i1-entropy "$proton_entropy"
            [ -n "$proton_rounds" ] && set -- "$@" --rounds "$proton_rounds"
            [ -n "$proton_port" ] && set -- "$@" --port "$proton_port"
            [ -n "$proton_probe_via" ] && set -- "$@" --probe-via "$proton_probe_via"
            [ -n "$proton_target_server" ] && set -- "$@" --server "$proton_target_server"
            # shellcheck disable=SC2086
            env CONF_DIR="$tmp_conf_dir" $proton_generate_env_prefix $guest_name_env \
                "$PROTON_GENERATE_SCRIPT" "$@" >/dev/null
        else
            [ -n "$proton_session" ] && [ -n "$proton_sessions_root" ] || die "Не задана сессия Proton (нет bundle в profile/vpn/proton/sessions и в PROTON_SESSIONS_DIR=${operator_proton_sessions_dir:-<не задан>}; для store-конструктора задайте PROTON_SESSIONS_DIR=ci/store/<id>/vpn/proton/sessions)"

            proton_generate_env_prefix="PROTON_SESSIONS_DIR=$proton_sessions_root"
            case "$proton_sessions_root" in
                "$profile_proton_sessions_dir")
                    info "Proton template: session из profile: $proton_sessions_root/$proton_session"
                    ;;
                "$operator_proton_sessions_dir")
                    info "Proton template: session из operator store (PROTON_SESSIONS_DIR): $proton_sessions_root/$proton_session"
                    ;;
                *)
                    info "Proton template: session: $proton_sessions_root/$proton_session"
                    ;;
            esac

            proton_generate_env_prefix="${proton_generate_env_prefix:+$proton_generate_env_prefix }PROTON_REFRESH_BEFORE_AUTH=1 PROTON_REFRESH_FAIL_HARD=1"
            info "Proton: обновление сессии (${session_auth_mode:-web}) и запрос сертификата..."

            info "Сборка конфигурации $IFACE_NAME по метаданным..."
            set -- "$proton_mode_flag" --session "$proton_session" \
                --country "$proton_country" \
                --version "$proton_version" --variant "$proton_variant" \
                --name "restore-$IFACE_NAME"
            case "$proton_selection" in
                interactive) set -- "$@" --interactive ;;
                *) set -- "$@" --best ;;
            esac
            [ -n "$proton_mtu" ] && set -- "$@" --mtu "$proton_mtu"
            case "$proton_free_only" in
                1|yes|YES|true|TRUE) set -- "$@" --free-only ;;
                0|no|NO|false|FALSE) set -- "$@" --all-tiers ;;
            esac
            case "$proton_req_ipv6" in
                1|yes|YES|true|TRUE) set -- "$@" --ipv6-only ;;
                0|no|NO|false|FALSE) set -- "$@" --all-ip ;;
            esac
            case "$proton_noise" in
                1|yes|YES|true|TRUE) set -- "$@" --with-noise ;;
            esac
            [ -n "$proton_entropy" ] && set -- "$@" --i1-entropy "$proton_entropy"
            [ -n "$proton_rounds" ] && set -- "$@" --rounds "$proton_rounds"
            [ -n "$proton_port" ] && set -- "$@" --port "$proton_port"
            [ -n "$proton_probe_via" ] && set -- "$@" --probe-via "$proton_probe_via"
            [ -n "$proton_target_server" ] && set -- "$@" --server "$proton_target_server"
            # shellcheck disable=SC2086
            env CONF_DIR="$tmp_conf_dir" $proton_generate_env_prefix \
                "$PROTON_GENERATE_SCRIPT" "$@" >/dev/null
        fi
        ;;
    *)
        die "Автовосстановление не поддерживает GENERATOR_KIND=$generator_kind"
        ;;
esac

generated_conf="$(find "$tmp_conf_dir" -mindepth 1 -maxdepth 1 -type f -name '*.conf' | sort | head -n 1)"
[ -n "${generated_conf:-}" ] || die "Генератор не создал .conf во временном каталоге"

old_private_key="$(conf_value "$source_conf" "PrivateKey" 2>/dev/null || true)"
generated_private_key="$(conf_value "$generated_conf" "PrivateKey" 2>/dev/null || true)"
[ -n "$generated_private_key" ] || die "Сгенерированный .conf не содержит PrivateKey: $generated_conf"

info "Обновление рабочей конфигурации интерфейса $IFACE_NAME..."
"$UPDATE_INTERFACE_CONFIG_SCRIPT" --iface "$IFACE_NAME" --source "$generated_conf" >/dev/null

[ -f "$network_uci" ] || die "После регенерации не создан network.uci: $network_uci"
source_has_private_key "$source_conf" || die "После регенерации source.conf не содержит PrivateKey: $source_conf"
applied_private_key="$(conf_value "$source_conf" "PrivateKey" 2>/dev/null || true)"
[ -n "$applied_private_key" ] || die "После регенерации не удалось прочитать PrivateKey из source.conf: $source_conf"
[ "$applied_private_key" = "$generated_private_key" ] || die "Пересобранный конфиг не применился: PrivateKey в source.conf отличается от сгенерированного"

if [ "$generator_kind" = "warp" ] && [ -n "${old_private_key:-}" ] && [ "$old_private_key" = "$applied_private_key" ]; then
    warn "WARP-конфиг пересобран, но PrivateKey не изменился (возможен повторный импорт старого конфига)"
fi

success "Конфигурация интерфейса восстановлена: $IFACE_NAME"
