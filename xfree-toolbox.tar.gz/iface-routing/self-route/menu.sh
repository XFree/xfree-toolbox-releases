#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"
COMMON_SH="${ROOT_DIR}/lib/common.sh"
UI_SH="${ROOT_DIR}/lib/ui.sh"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"
[ -f "$UI_SH" ] && . "$UI_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
APPLY_SH="${SCRIPT_DIR}/apply.sh"
HOTPLUG_FILE="/etc/hotplug.d/iface/95-xfree-toolbox-self-route"
SELF_ROUTE_METRIC="${SELF_ROUTE_METRIC:-5}"

have_cmd() {
    command -v "$1" >/dev/null 2>&1
}

run_log() { ui_menu_invoke_with_output "$@"; }

list_ifaces() {
    for d in "$INTERFACES_DIR"/*; do
        [ -d "$d" ] || continue
        basename "$d"
    done
}

list_uci_network_ifaces() {
    command -v uci >/dev/null 2>&1 || return 1
    uci show network 2>/dev/null | sed -n 's/^network\.\([^.]*\)=interface$/\1/p' | sort -u
}

list_via_iface_candidates() {
    {
        list_ifaces
        list_uci_network_ifaces
    } | sed '/^$/d' | sort -u
}

select_profile_iface() {
    title="$1"
    prompt="$2"
    exclude="${3:-}"

    lines=''

    for iface in $(list_ifaces); do
        [ -n "$iface" ] || continue
        [ "$iface" = "$exclude" ] && continue
        lines="${lines}${iface}\n"
    done

    [ -n "$lines" ] || return 1
    ui_select_from_lines "$title" "$prompt" "$(printf '%b' "$lines")" 20 78 10
}

select_via_iface() {
    title="$1"
    prompt="$2"
    exclude="${3:-}"

    lines=''

    for iface in $(list_via_iface_candidates); do
        [ -n "$iface" ] || continue
        [ "$iface" = "$exclude" ] && continue
        lines="${lines}${iface}\n"
    done

    [ -n "$lines" ] || {
        ui_msgbox "$title" "Нет кандидатов via: ни VPN в профиле, ни network.*=interface в UCI."
        return 1
    }
    ui_select_from_lines "$title" "$prompt" "$(printf '%b' "$lines")" 20 78 12
}

select_iface() {
    select_profile_iface "$@"
}

conf_get_value() {
    cfg="$1"
    key="$2"

    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$cfg"
}

get_runtime_peer_ip() {
    iface="$1"

    if command -v awg >/dev/null 2>&1; then
        out="$(awg show "$iface" endpoints 2>/dev/null || true)"
        ip="$(printf '%s\n' "$out" | awk 'NF >= 2 { print $2; exit }' | sed 's/:.*$//' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -n1 || true)"
        if [ -n "$ip" ]; then
            printf '%s\n' "$ip"
            return 0
        fi
    fi

    if command -v wg >/dev/null 2>&1; then
        out="$(wg show "$iface" endpoints 2>/dev/null || true)"
        ip="$(printf '%s\n' "$out" | awk 'NF >= 2 { print $2; exit }' | sed 's/:.*$//' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -n1 || true)"
        if [ -n "$ip" ]; then
            printf '%s\n' "$ip"
            return 0
        fi
    fi

    return 1
}

has_hotplug() {
    [ -f "$HOTPLUG_FILE" ]
}

show_status() {
    routes=''
    count=0

    for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
        [ -f "$cfg" ] || continue

        target_name="$(conf_get_value "$cfg" 'INTERFACE_NAME' || true)"
        via_iface="$(conf_get_value "$cfg" 'SELF_ROUTE_VIA' || true)"

        [ -n "$target_name" ] || continue
        [ -n "$via_iface" ] || continue

        peer_ip="$(get_runtime_peer_ip "$target_name" || true)"
        runtime=''
        if [ -n "$peer_ip" ]; then
            runtime="$(ip route show table main 2>/dev/null | awk -v ip="$peer_ip" -v metric="$SELF_ROUTE_METRIC" '
                $1 == ip && index($0, " metric " metric) > 0 { print; exit }
            ')"
        fi

        routes="${routes}${target_name} -> ${via_iface}"
        if [ -n "$peer_ip" ]; then
            routes="${routes} (peer ${peer_ip})"
        else
            routes="${routes} (peer не определён)"
        fi
        if [ -n "$runtime" ]; then
            routes="${routes}\n  route: ${runtime}"
        fi
        routes="${routes}\n"
        count=$((count + 1))
    done

    if [ "$count" -eq 0 ]; then
        routes='Нет активных self-route\n'
    fi

    if has_hotplug; then
        hp='установлен'
    else
        hp='отсутствует'
    fi

    ui_msgbox "Self-route статус" "${routes}\nHotplug: ${hp}\nMetric: ${SELF_ROUTE_METRIC}"
}

run_apply() {
    target="$(select_profile_iface 'Self-route' 'Выберите target (VPN из профиля)' '')" || return 0
    via="$(select_via_iface 'Self-route' "Через какой интерфейс направлять ${target} (VPN или UCI WAN)" "$target")" || return 0

    run_log "Self-route: применить ${target} -> ${via}" "$APPLY_SH" --iface "$target" --via "$via"
}

run_remove() {
    target="$(select_profile_iface 'Self-route' 'Выберите интерфейс, для которого удалить self-route' '')" || return 0

    run_log "Self-route: удалить для ${target}" "$APPLY_SH" --iface "$target" --remove
}

run_rebuild_hotplug() {
    run_log "Self-route: пересобрать hotplug hook" "$APPLY_SH" --rebuild-hotplug
}

run_refresh() {
    run_log "Self-route: обновить runtime host-routes" "$APPLY_SH" --run-hotplug
}

run_cleanup() {
    run_log "Self-route: полная пересборка (cleanup)" "$APPLY_SH" --cleanup
}

main_loop() {
    while :; do
        choice="$(ui_menu "Self-route" "Выберите действие" 18 84 8 \
            "1" "Показать статус" \
            "2" "Применить / обновить" \
            "3" "Удалить" \
            "4" "Пересобрать hotplug hook" \
            "5" "Обновить runtime host-routes" \
            "6" "Полная пересборка (cleanup)" \
            "0" "Назад" || true)"
        [ -n "${choice:-}" ] || break

        case "$choice" in
            1) show_status ;;
            2) run_apply ;;
            3) run_remove ;;
            4) run_rebuild_hotplug ;;
            5) run_refresh ;;
            6) run_cleanup ;;
            0) break ;;
        esac
    done
}

[ -x "$APPLY_SH" ] || die "Не найден apply.sh: $APPLY_SH"

main_loop
