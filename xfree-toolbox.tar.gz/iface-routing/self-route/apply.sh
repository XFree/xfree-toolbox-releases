#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"
COMMON_SH="${ROOT_DIR}/lib/common.sh"
[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
HOTPLUG_FILE="/etc/hotplug.d/iface/95-xfree-toolbox-self-route"
SELF_ROUTE_METRIC="${SELF_ROUTE_METRIC:-5}"

usage() {
    cat <<USAGE
Usage:
  $0 --iface <target-iface> --via <via-iface>
  $0 --iface <target-iface> --remove
  $0 --rebuild-hotplug
  $0 --run-hotplug
  $0 --cleanup
USAGE
}

validate_iface_name() {
    case "$1" in
        ''|*[!A-Za-z0-9_-]*) return 1 ;;
        *) return 0 ;;
    esac
}

iface_conf_path() {
    printf '%s/%s/config/iface.conf\n' "$INTERFACES_DIR" "$1"
}

conf_get_value() {
    cfg="$1"
    key="$2"

    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$cfg"
}

set_conf_value() {
    cfg="$1"
    key="$2"
    value="$3"

    tmp="${cfg}.tmp.$$"
    awk -v key="$key" -v value="$value" '
        BEGIN { done = 0 }
        $0 ~ "^" key "=" {
            print key "=\047" value "\047"
            done = 1
            next
        }
        { print }
        END {
            if (!done) {
                print key "=\047" value "\047"
            }
        }
    ' "$cfg" > "$tmp"
    mv "$tmp" "$cfg"
}

clear_conf_value() {
    cfg="$1"
    key="$2"
    set_conf_value "$cfg" "$key" ""
}

# Поле peer из `awg|wg show IFACE endpoints` (до двоеточия порта для IPv4/FQDN; IPv6 в скобках — не поддерживаем).
wg_endpoints_raw_peer_field() {
    iface="$1"
    raw=""
    if command -v awg >/dev/null 2>&1; then
        raw="$(awg show "$iface" endpoints 2>/dev/null | awk 'NF >= 2 { print $2; exit }' || true)"
    fi
    if [ -z "$raw" ] && command -v wg >/dev/null 2>&1; then
        raw="$(wg show "$iface" endpoints 2>/dev/null | awk 'NF >= 2 { print $2; exit }' || true)"
    fi
    printf '%s\n' "$raw"
}

strip_trailing_wg_port() {
    raw="$1"
    case "$raw" in
        \[*) printf '%s\n' "$raw"; return 0 ;;
    esac
    printf '%s\n' "$raw" | sed 's/:[0-9][0-9]*$//'
}

# Первый не-loopback A-запись (getent приоритетно, иначе разбор nslookup).
resolve_hostname_ipv4() {
    host="$1"
    [ -n "$host" ] || return 1
    ip=""
    if command -v getent >/dev/null 2>&1; then
        ip="$(getent ahosts "$host" 2>/dev/null | awk '$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && $1 !~ /^127\./ { print $1; exit }' || true)"
    fi
    if [ -z "$ip" ] && command -v nslookup >/dev/null 2>&1; then
        ip="$(nslookup "$host" 2>/dev/null | tr -d '\r' | grep -oE '[0-9]{1,3}(\.[0-9]{1,3}){3}' | awk '!/^127\./ && $0 != "0.0.0.0" { print; exit }' || true)"
    fi
    printf '%s\n' "$ip" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || return 1
    printf '%s\n' "$ip"
}

peer_ipv4_from_wg_endpoints() {
    iface="$1"
    raw="$(wg_endpoints_raw_peer_field "$iface")"
    [ -n "$raw" ] || return 1
    case "$raw" in
        \(none\)) return 1 ;;
    esac
    case "$raw" in
        \[*) return 1 ;;
    esac
    addr="$(strip_trailing_wg_port "$raw")"
    [ -n "$addr" ] || return 1
    if printf '%s\n' "$addr" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'; then
        printf '%s\n' "$addr"
        return 0
    fi
    if printf '%s\n' "$addr" | grep -q ':'; then
        return 1
    fi
    resolve_hostname_ipv4 "$addr"
}

uci_network_iface_exists() {
    iface="$1"
    validate_iface_name "$iface" || return 1
    command -v uci >/dev/null 2>&1 || return 1
    uci -q get "network.${iface}" >/dev/null 2>&1
}

via_dev_from_uci_iface() {
    iface="$1"
    dev=""

    if command -v ubus >/dev/null 2>&1; then
        _st="$(ubus call network.interface."$iface" status 2>/dev/null || true)"
        dev="$(printf '%s\n' "$_st" | sed -n 's/.*"l3_device": "\([^"]*\)".*/\1/p' | head -n1)"
        [ -n "$dev" ] || dev="$(printf '%s\n' "$_st" | sed -n 's/.*"device": "\([^"]*\)".*/\1/p' | head -n1)"
    fi
    if [ -z "$dev" ] && command -v uci >/dev/null 2>&1; then
        dev="$(uci -q get "network.${iface}.device" 2>/dev/null || true)"
        [ -n "$dev" ] || dev="$(uci -q get "network.${iface}.ifname" 2>/dev/null || true)"
    fi
    [ -n "$dev" ] || dev="$iface"
    printf '%s\n' "$dev"
}

via_dev_from_cfg() {
    cfg="$1"
    vpn_dev="$(conf_get_value "$cfg" 'VPN_DEV' || true)"
    iface_name="$(conf_get_value "$cfg" 'INTERFACE_NAME' || true)"

    if [ -n "$vpn_dev" ]; then
        printf '%s\n' "$vpn_dev"
        return 0
    fi
    if [ -n "$iface_name" ]; then
        printf '%s\n' "$iface_name"
        return 0
    fi
    return 1
}

via_dev_from_iface_name() {
    via_iface="$1"
    via_cfg="$(iface_conf_path "$via_iface")"

    if [ -f "$via_cfg" ]; then
        via_dev_from_cfg "$via_cfg" && return 0
    fi
    uci_network_iface_exists "$via_iface" || return 1
    via_dev_from_uci_iface "$via_iface"
}

self_route_via_exists() {
    via_iface="$1"
    via_cfg="$(iface_conf_path "$via_iface")"
    [ -f "$via_cfg" ] && return 0
    uci_network_iface_exists "$via_iface"
}

has_any_enabled_self_route() {
    for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
        [ -f "$cfg" ] || continue
        if grep -Eq "^SELF_ROUTE_VIA='[^']+'" "$cfg"; then
            return 0
        fi
    done
    return 1
}

is_route_table_available() {
    table_name="$1"
    [ -n "$table_name" ] || return 1
    [ "$table_name" = "main" ] && return 0
    case "$table_name" in
        ''|*[!0-9]*) ;;
        *) return 0 ;;
    esac
    ip route show table "$table_name" >/dev/null 2>&1
}

route_key() {
    printf '%s|%s|%s\n' "$1" "$2" "$3"
}

route_table_from_cfg() {
    cfg="$1"
    table_id="$(conf_get_value "$cfg" 'ROUTE_TABLE_ID' || true)"
    table_name="$(conf_get_value "$cfg" 'ROUTE_TABLE_NAME' || true)"
    case "$table_id" in
        ''|*[!0-9]*) ;;
        *) printf '%s\n' "$table_id"; return 0 ;;
    esac
    if [ -n "$table_name" ]; then
        printf '%s\n' "$table_name"
        return 0
    fi
    printf 'main\n'
}

is_route_table_available() {
    table_name="$1"
    [ -n "$table_name" ] || return 1
    [ "$table_name" = "main" ] && return 0
    case "$table_name" in
        ''|*[!0-9]*) ;;
        *) return 0 ;;
    esac
    ip route show table "$table_name" >/dev/null 2>&1
}

collect_desired_routes() {
    for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
        [ -f "$cfg" ] || continue

        target_name="$(conf_get_value "$cfg" 'INTERFACE_NAME' || true)"
        via_iface="$(conf_get_value "$cfg" 'SELF_ROUTE_VIA' || true)"

        [ -n "$target_name" ] || continue
        [ -n "$via_iface" ] || continue
        validate_iface_name "$via_iface" || continue

        via_dev="$(via_dev_from_iface_name "$via_iface" || true)"
        [ -n "$via_dev" ] || continue

        peer_ip="$(peer_ipv4_from_wg_endpoints "$target_name" || true)"
        printf '%s\n' "$peer_ip" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || continue

        target_table="$(route_table_from_cfg "$cfg" || true)"
        [ -n "$target_table" ] || target_table="main"

        route_key "main" "$peer_ip" "$via_dev"
        if is_route_table_available "$target_table"; then
            route_key "$target_table" "$peer_ip" "$via_dev"
        fi
    done | sort -u
}

collect_actual_routes_from_table() {
    table_name="$1"
    ip route show table "$table_name" 2>/dev/null \
    | awk -v metric="$SELF_ROUTE_METRIC" -v table="$table_name" '
        index($0, " metric " metric) > 0 {
            dest=$1
            dev=""
            for (i = 1; i <= NF; i++) {
                if ($i == "dev" && i < NF) {
                    dev=$(i + 1)
                    break
                }
            }
            if (dest ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && dev != "") {
                print table "|" dest "|" dev
            }
        }
    ' | sort -u
}

collect_known_route_tables() {
    printf '%s\n' "main"
    for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
        [ -f "$cfg" ] || continue
        table_name="$(route_table_from_cfg "$cfg" || true)"
        [ -n "$table_name" ] || continue
        is_route_table_available "$table_name" || continue
        printf '%s\n' "$table_name"
    done | sort -u
}

collect_actual_routes() {
    collect_known_route_tables | while IFS= read -r table_name; do
        [ -n "$table_name" ] || continue
        collect_actual_routes_from_table "$table_name"
    done | sort -u
}

delete_route_key() {
    key="$1"
    table_name="${key%%|*}"
    rest="${key#*|}"
    dest="${rest%%|*}"
    dev="${rest#*|}"

    while ip route del table "$table_name" "$dest" dev "$dev" metric "$SELF_ROUTE_METRIC" >/dev/null 2>&1; do :; done
}

delete_route_destination() {
    table_name="$1"
    dest="$2"
    while ip route del table "$table_name" "$dest" >/dev/null 2>&1; do :; done
}

build_hotplug_script() {
    tmp="${HOTPLUG_FILE}.tmp.$$"

    cat > "$tmp" <<'HOTPLUG_EOF'
#!/bin/sh
# Auto-generated by xfree self-route apply.sh
# shellcheck shell=sh

set -eu

INTERFACES_DIR='__INTERFACES_DIR__'
SELF_ROUTE_METRIC='__SELF_ROUTE_METRIC__'

hotplug_log() {
    logger -t 'xfree-self-route' "$*"
    echo "[*] $*"
}

validate_iface_name() {
    case "$1" in
        ''|*[!A-Za-z0-9_-]*) return 1 ;;
        *) return 0 ;;
    esac
}

iface_conf_path() {
    printf '%s/%s/config/iface.conf\n' "$INTERFACES_DIR" "$1"
}

conf_get_value() {
    cfg="$1"
    key="$2"

    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$cfg"
}

is_ipv4_literal() {
    printf '%s\n' "$1" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'
}

wg_endpoints_raw_peer_field() {
    iface="$1"
    raw=""
    if command -v awg >/dev/null 2>&1; then
        raw="$(awg show "$iface" endpoints 2>/dev/null | awk 'NF >= 2 { print $2; exit }' || true)"
    fi
    if [ -z "$raw" ] && command -v wg >/dev/null 2>&1; then
        raw="$(wg show "$iface" endpoints 2>/dev/null | awk 'NF >= 2 { print $2; exit }' || true)"
    fi
    printf '%s\n' "$raw"
}

strip_trailing_wg_port() {
    raw="$1"
    case "$raw" in
        \[*) printf '%s\n' "$raw"; return 0 ;;
    esac
    printf '%s\n' "$raw" | sed 's/:[0-9][0-9]*$//'
}

resolve_hostname_ipv4() {
    host="$1"
    [ -n "$host" ] || return 1
    ip=""
    if command -v getent >/dev/null 2>&1; then
        ip="$(getent ahosts "$host" 2>/dev/null | awk '$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && $1 !~ /^127\./ { print $1; exit }' || true)"
    fi
    if [ -z "$ip" ] && command -v nslookup >/dev/null 2>&1; then
        ip="$(nslookup "$host" 2>/dev/null | tr -d '\r' | grep -oE '[0-9]{1,3}(\.[0-9]{1,3}){3}' | awk '!/^127\./ && $0 != "0.0.0.0" { print; exit }' || true)"
    fi
    printf '%s\n' "$ip" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' || return 1
    printf '%s\n' "$ip"
}

peer_ipv4_from_wg_endpoints() {
    iface="$1"
    raw="$(wg_endpoints_raw_peer_field "$iface")"
    [ -n "$raw" ] || return 1
    case "$raw" in
        \(none\)) return 1 ;;
    esac
    case "$raw" in
        \[*) return 1 ;;
    esac
    addr="$(strip_trailing_wg_port "$raw")"
    [ -n "$addr" ] || return 1
    if printf '%s\n' "$addr" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'; then
        printf '%s\n' "$addr"
        return 0
    fi
    if printf '%s\n' "$addr" | grep -q ':'; then
        return 1
    fi
    resolve_hostname_ipv4 "$addr"
}

via_dev_from_cfg() {
    cfg="$1"
    vpn_dev="$(conf_get_value "$cfg" 'VPN_DEV' || true)"
    iface_name="$(conf_get_value "$cfg" 'INTERFACE_NAME' || true)"

    if [ -n "$vpn_dev" ]; then
        printf '%s\n' "$vpn_dev"
        return 0
    fi

    if [ -n "$iface_name" ]; then
        printf '%s\n' "$iface_name"
        return 0
    fi

    return 1
}

uci_network_iface_exists() {
    iface="$1"
    validate_iface_name "$iface" || return 1
    command -v uci >/dev/null 2>&1 || return 1
    uci -q get "network.${iface}" >/dev/null 2>&1
}

via_dev_from_uci_iface() {
    iface="$1"
    dev=""

    if command -v ubus >/dev/null 2>&1; then
        _st="$(ubus call network.interface."$iface" status 2>/dev/null || true)"
        dev="$(printf '%s\n' "$_st" | sed -n 's/.*"l3_device": "\([^"]*\)".*/\1/p' | head -n1)"
        [ -n "$dev" ] || dev="$(printf '%s\n' "$_st" | sed -n 's/.*"device": "\([^"]*\)".*/\1/p' | head -n1)"
    fi
    if [ -z "$dev" ] && command -v uci >/dev/null 2>&1; then
        dev="$(uci -q get "network.${iface}.device" 2>/dev/null || true)"
        [ -n "$dev" ] || dev="$(uci -q get "network.${iface}.ifname" 2>/dev/null || true)"
    fi
    [ -n "$dev" ] || dev="$iface"
    printf '%s\n' "$dev"
}

via_dev_from_iface_name() {
    via_iface="$1"
    via_cfg="$(iface_conf_path "$via_iface")"

    if [ -f "$via_cfg" ]; then
        via_dev_from_cfg "$via_cfg" && return 0
    fi
    uci_network_iface_exists "$via_iface" || return 1
    via_dev_from_uci_iface "$via_iface"
}

get_runtime_peer_ip() {
    peer_ipv4_from_wg_endpoints "$1"
}

route_key() {
    printf '%s|%s|%s\n' "$1" "$2" "$3"
}

route_table_from_cfg() {
    cfg="$1"
    table_id="$(conf_get_value "$cfg" 'ROUTE_TABLE_ID' || true)"
    table_name="$(conf_get_value "$cfg" 'ROUTE_TABLE_NAME' || true)"
    case "$table_id" in
        ''|*[!0-9]*) ;;
        *) printf '%s\n' "$table_id"; return 0 ;;
    esac
    if [ -n "$table_name" ]; then
        printf '%s\n' "$table_name"
        return 0
    fi
    printf 'main\n'
}

is_route_table_available() {
    table_name="$1"
    [ -n "$table_name" ] || return 1
    [ "$table_name" = "main" ] && return 0
    case "$table_name" in
        ''|*[!0-9]*) ;;
        *) return 0 ;;
    esac
    ip route show table "$table_name" >/dev/null 2>&1
}

collect_desired_routes() {
    for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
        [ -f "$cfg" ] || continue

        target_name="$(conf_get_value "$cfg" 'INTERFACE_NAME' || true)"
        via_iface="$(conf_get_value "$cfg" 'SELF_ROUTE_VIA' || true)"

        [ -n "$target_name" ] || continue
        [ -n "$via_iface" ] || continue
        validate_iface_name "$via_iface" || continue

        via_dev="$(via_dev_from_iface_name "$via_iface" || true)"
        [ -n "$via_dev" ] || continue

        peer_ip="$(get_runtime_peer_ip "$target_name" || true)"
        is_ipv4_literal "$peer_ip" || continue

        target_table="$(route_table_from_cfg "$cfg" || true)"
        [ -n "$target_table" ] || target_table="main"

        route_key "main" "$peer_ip" "$via_dev"
        if is_route_table_available "$target_table"; then
            route_key "$target_table" "$peer_ip" "$via_dev"
        fi
    done | sort -u
}

collect_actual_routes_from_table() {
    table_name="$1"
    ip route show table "$table_name" 2>/dev/null \
    | awk -v metric="$SELF_ROUTE_METRIC" -v table="$table_name" '
        index($0, " metric " metric) > 0 {
            dest=$1
            dev=""
            for (i = 1; i <= NF; i++) {
                if ($i == "dev" && i < NF) {
                    dev=$(i + 1)
                    break
                }
            }
            if (dest ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && dev != "") {
                print table "|" dest "|" dev
            }
        }
    ' | sort -u
}

collect_known_route_tables() {
    printf '%s\n' "main"
    for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
        [ -f "$cfg" ] || continue
        table_name="$(route_table_from_cfg "$cfg" || true)"
        [ -n "$table_name" ] || continue
        is_route_table_available "$table_name" || continue
        printf '%s\n' "$table_name"
    done | sort -u
}

collect_actual_routes() {
    collect_known_route_tables | while IFS= read -r table_name; do
        [ -n "$table_name" ] || continue
        collect_actual_routes_from_table "$table_name"
    done | sort -u
}

has_in_list() {
    needle="$1"
    list="$2"
    printf '%s\n' "$list" | grep -Fqx "$needle"
}

delete_route_key() {
    key="$1"
    table_name="${key%%|*}"
    rest="${key#*|}"
    dest="${rest%%|*}"
    dev="${rest#*|}"

    while ip route del table "$table_name" "$dest" dev "$dev" metric "$SELF_ROUTE_METRIC" >/dev/null 2>&1; do :; done
}

delete_route_destination() {
    table_name="$1"
    dest="$2"
    while ip route del table "$table_name" "$dest" >/dev/null 2>&1; do :; done
}

replace_route_key() {
    key="$1"
    table_name="${key%%|*}"
    rest="${key#*|}"
    dest="${rest%%|*}"
    dev="${rest#*|}"

    delete_route_destination "$table_name" "$dest"
    ip route replace table "$table_name" "$dest" dev "$dev" metric "$SELF_ROUTE_METRIC"
}

reconcile_routes() {
    desired="$(collect_desired_routes || true)"
    actual="$(collect_actual_routes || true)"

    if [ -n "$actual" ]; then
        printf '%s\n' "$actual" | while IFS= read -r key; do
            [ -n "$key" ] || continue
            if ! has_in_list "$key" "$desired"; then
                delete_route_key "$key"
                table_name="${key%%|*}"
                rest="${key#*|}"
                dest="${rest%%|*}"
                dev="${rest#*|}"
                hotplug_log "Удалён осиротевший route: table=$table_name $dest dev $dev metric=$SELF_ROUTE_METRIC"
            fi
        done
    fi

    if [ -n "$desired" ]; then
        printf '%s\n' "$desired" | while IFS= read -r key; do
            [ -n "$key" ] || continue
            replace_route_key "$key"
            table_name="${key%%|*}"
            rest="${key#*|}"
            dest="${rest%%|*}"
            dev="${rest#*|}"
            hotplug_log "Обновлён route: table=$table_name $dest dev $dev metric=$SELF_ROUTE_METRIC"
        done
    fi
}

ACTION="${ACTION:-}"
INTERFACE="${INTERFACE:-}"
DEVICE="${DEVICE:-}"
SELF_ROUTE_FORCE_REFRESH="${SELF_ROUTE_FORCE_REFRESH:-0}"

if [ "$SELF_ROUTE_FORCE_REFRESH" = '1' ]; then
    reconcile_routes
    exit 0
fi

case "$ACTION" in
    ifup|ifupdate)
        ;;
    *)
        exit 0
        ;;
esac

HOTPLUG_IFACE=''
if [ -n "$INTERFACE" ]; then
    HOTPLUG_IFACE="$INTERFACE"
elif [ -n "$DEVICE" ]; then
    HOTPLUG_IFACE="$DEVICE"
else
    exit 0
fi

validate_iface_name "$HOTPLUG_IFACE" || exit 0

for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
    [ -f "$cfg" ] || continue

    target_name="$(conf_get_value "$cfg" 'INTERFACE_NAME' || true)"
    via_iface="$(conf_get_value "$cfg" 'SELF_ROUTE_VIA' || true)"

    [ -n "$target_name" ] || continue
    [ -n "$via_iface" ] || continue

    if [ "$target_name" = "$HOTPLUG_IFACE" ] || [ "$via_iface" = "$HOTPLUG_IFACE" ]; then
        reconcile_routes
        exit 0
    fi
done

exit 0
HOTPLUG_EOF

    sed -i \
        -e "s|__INTERFACES_DIR__|$INTERFACES_DIR|g" \
        -e "s|__SELF_ROUTE_METRIC__|$SELF_ROUTE_METRIC|g" \
        "$tmp"

    chmod +x "$tmp"
    mv "$tmp" "$HOTPLUG_FILE"
}

remove_hotplug_if_unused() {
    has_any_enabled_self_route && return 0
    [ -f "$HOTPLUG_FILE" ] && rm -f "$HOTPLUG_FILE"
}

run_hotplug_refresh() {
    [ -x "$HOTPLUG_FILE" ] || {
        info "Hotplug не установлен: $HOTPLUG_FILE"
        return 0
    }
    SELF_ROUTE_FORCE_REFRESH=1 "$HOTPLUG_FILE"
}

apply_self_route() {
    target_iface="$1"
    via_iface="$2"

    validate_iface_name "$target_iface" || die "Недопустимое имя target interface: $target_iface"
    validate_iface_name "$via_iface" || die "Недопустимое имя via interface: $via_iface"
    [ "$target_iface" != "$via_iface" ] || die "target и via не должны совпадать"

    target_cfg="$(iface_conf_path "$target_iface")"

    [ -f "$target_cfg" ] || die "Не найден конфиг target interface: $target_cfg"
    self_route_via_exists "$via_iface" || die "Via interface не найден: $via_iface (профиль iface-routing или UCI network)"

    set_conf_value "$target_cfg" 'SELF_ROUTE_VIA' "$via_iface"
    build_hotplug_script
    run_hotplug_refresh

    success "Self-route применён: target=$target_iface via=$via_iface"
}

remove_self_route() {
    target_iface="$1"

    validate_iface_name "$target_iface" || die "Недопустимое имя interface: $target_iface"

    target_cfg="$(iface_conf_path "$target_iface")"
    [ -f "$target_cfg" ] || die "Не найден конфиг interface: $target_cfg"

    clear_conf_value "$target_cfg" 'SELF_ROUTE_VIA'

    if has_any_enabled_self_route; then
        build_hotplug_script
        run_hotplug_refresh
    else
        run_cleanup
    fi

    success "Self-route удалён: target=$target_iface"
}

run_cleanup() {
    routes="$(collect_actual_routes || true)"

    if [ -n "$routes" ]; then
        printf '%s\n' "$routes" | while IFS= read -r key; do
            [ -n "$key" ] || continue
            delete_route_key "$key"
        done
    fi

    if has_any_enabled_self_route; then
        build_hotplug_script
        run_hotplug_refresh
    else
        [ -f "$HOTPLUG_FILE" ] && rm -f "$HOTPLUG_FILE"
    fi

    success "Cleanup завершён"
}

TARGET_IFACE=''
VIA_IFACE=''
MODE=''

while [ "$#" -gt 0 ]; do
    case "$1" in
        --iface)
            [ "$#" -ge 2 ] || die "Не указано значение для --iface"
            TARGET_IFACE="$2"
            shift 2
            ;;
        --via)
            [ "$#" -ge 2 ] || die "Не указано значение для --via"
            VIA_IFACE="$2"
            shift 2
            ;;
        --remove)
            MODE='remove'
            shift
            ;;
        --rebuild-hotplug)
            MODE='rebuild-hotplug'
            shift
            ;;
        --run-hotplug)
            MODE='run-hotplug'
            shift
            ;;
        --cleanup)
            MODE='cleanup'
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
done

case "$MODE" in
    cleanup)
        run_cleanup
        exit 0
        ;;
    rebuild-hotplug)
        if has_any_enabled_self_route; then
            build_hotplug_script
        success "Hotplug пересобран: $HOTPLUG_FILE"
        else
            remove_hotplug_if_unused
        success "Активных self-route нет; hotplug удалён"
        fi
        exit 0
        ;;
    run-hotplug)
        run_hotplug_refresh
        exit 0
        ;;
esac

[ -n "$TARGET_IFACE" ] || die "Не указан --iface"

if [ "$MODE" = 'remove' ]; then
    remove_self_route "$TARGET_IFACE"
    exit 0
fi

[ -n "$VIA_IFACE" ] || die "Не указан --via"
apply_self_route "$TARGET_IFACE" "$VIA_IFACE"
