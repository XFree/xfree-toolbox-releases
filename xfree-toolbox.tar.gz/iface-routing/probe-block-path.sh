#!/bin/sh
# shellcheck shell=sh
# Sequential block-path probe:
#   1) raw WAN  = curl --interface pppoe-wan|wan  (ISP egress; no nfq bind)
#      GEOBLOCK → try proton
#      OK       → stay on WAN
#   2) if raw FAIL/UNKNOWN:
#      default  = curl without --interface (router OUTPUT → zapret nfq)
#      OK       → recommend wan (zapret already covers / WAN works)
#      else     → recommend zapret; optional alt=warp
#
# Offline tests source this file (functions only).
# Live on router: sh iface-routing/probe-block-path.sh [--url URL]...

: "${XFREE_BLOCK_PATH_CONNECT_TIMEOUT:=8}"
: "${XFREE_BLOCK_PATH_MAX_TIME:=20}"
: "${XFREE_BLOCK_PATH_UA:=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36}"

# Prints "VERDICT detail". Return 0 only for OK.
block_path_classify_file() {
	body_file="$1"
	if [ ! -f "$body_file" ] || [ ! -s "$body_file" ]; then
		printf 'FAIL empty-body\n'
		return 1
	fi
	norm="$(mktemp)"
	tr 'A-Z' 'a-z' <"$body_file" | tr -d '\r' >"$norm" || true

	if grep -Eqi 'not available from your current location|unfortunately, we have to inform you that access to the .+ website is not available' "$norm"; then
		rm -f "$norm"
		printf 'GEOBLOCK location-denied\n'
		return 1
	fi
	if grep -Eqi 'zugriff verweigert|access denied' "$norm" &&
		grep -Eqi 'proxy/vpn|aus sicherheitsgründen|for security reasons|error reference' "$norm"; then
		rm -f "$norm"
		printf 'ANTI_ABUSE vpn-or-bot\n'
		return 1
	fi
	if grep -Eqi 'fahrzeugmarkt|angebote|detailsuche|auto verkaufen' "$norm"; then
		rm -f "$norm"
		printf 'OK site-markers\n'
		return 0
	fi
	# Non-empty HTML without deny markers — treat as OK for path choice.
	if grep -Eqi '<!doctype html|<html' "$norm"; then
		size="$(wc -c <"$norm" | awk '{print $1}')"
		if [ "$size" -ge 800 ]; then
			rm -f "$norm"
			printf 'OK html\n'
			return 0
		fi
	fi
	rm -f "$norm"
	printf 'UNKNOWN no-markers\n'
	return 1
}

# After raw-WAN verdict: which path to try next.
# stdout: proton | default | none
# "default" = retry without --interface (zapret OUTPUT path).
block_path_next_after_wan() {
	wan_verdict="$1"
	case "$wan_verdict" in
		OK) printf 'none\n' ;;
		GEOBLOCK) printf 'proton\n' ;;
		ANTI_ABUSE) printf 'proton\n' ;;
		FAIL|UNKNOWN) printf 'default\n' ;;
		*) printf 'default\n' ;;
	esac
}

# Recommend after raw WAN (+ optional second hop).
# second_hop: proton | default | warp
block_path_recommend() {
	wan_verdict="$1"
	second_hop="${2:-}"
	second_verdict="${3:-}"

	case "$wan_verdict" in
		OK)
			printf 'wan\n'
			return 0
			;;
	esac

	case "$second_hop" in
		proton)
			case "$second_verdict" in
				OK) printf 'proton\n' ;;
				ANTI_ABUSE) printf 'proton-check-browser\n' ;;
				*) printf 'proton-fail\n' ;;
			esac
			;;
		default)
			# raw WAN failed; default route (zapret OUTPUT) result:
			case "$second_verdict" in
				OK) printf 'wan\n' ;;
				GEOBLOCK) printf 'proton\n' ;;
				*) printf 'zapret\n' ;;
			esac
			;;
		*)
			block_path_next_after_wan "$wan_verdict"
			;;
	esac
}

block_path_resolve_wan_dev() {
	if [ -e /sys/class/net/pppoe-wan ]; then
		printf '%s\n' 'pppoe-wan'
		return 0
	fi
	d="$(uci -q get network.wan.device 2>/dev/null || true)"
	[ -n "$d" ] || d="$(uci -q get network.wan.ifname 2>/dev/null || true)"
	[ -n "$d" ] || d="$(ip -4 route show default 2>/dev/null | awk '{print $5; exit}')"
	printf '%s\n' "${d:-}"
}

# Fetch URL. iface_dev empty → default route (zapret OUTPUT). Else --interface.
# Prints "http=CODE". Returns curl rc.
block_path_fetch() {
	url="$1"
	out_file="$2"
	iface_dev="${3:-}"
	rc=0
	http_code='000'
	if [ -n "$iface_dev" ]; then
		http_code="$(curl -4 -sS -L \
			--connect-timeout "$XFREE_BLOCK_PATH_CONNECT_TIMEOUT" \
			--max-time "$XFREE_BLOCK_PATH_MAX_TIME" \
			--interface "$iface_dev" \
			-A "$XFREE_BLOCK_PATH_UA" \
			-H 'Accept-Language: de-DE,de;q=0.9,en;q=0.8' \
			-o "$out_file" -w '%{http_code}' \
			"$url" 2>/dev/null)" || rc=$?
	else
		http_code="$(curl -4 -sS -L \
			--connect-timeout "$XFREE_BLOCK_PATH_CONNECT_TIMEOUT" \
			--max-time "$XFREE_BLOCK_PATH_MAX_TIME" \
			-A "$XFREE_BLOCK_PATH_UA" \
			-H 'Accept-Language: de-DE,de;q=0.9,en;q=0.8' \
			-o "$out_file" -w '%{http_code}' \
			"$url" 2>/dev/null)" || rc=$?
	fi
	http_code="$(printf '%s' "$http_code" | tr -d '\r')"
	[ -n "$http_code" ] || http_code='000'
	printf 'http=%s\n' "$http_code"
	return "$rc"
}

block_path_probe_one_url() {
	url="$1"
	wan_dev="$(block_path_resolve_wan_dev)"
	body="$(mktemp)"
	printf 'URL %s\n' "$url"
	printf '  step1 raw-WAN via %s (--interface; geoblock check)\n' "${wan_dev:-?}"

	if [ -z "$wan_dev" ] || [ ! -e "/sys/class/net/$wan_dev" ]; then
		printf '  raw-WAN SKIP no-dev\n'
		wan_verdict='FAIL'
	else
		fetch_line="$(block_path_fetch "$url" "$body" "$wan_dev")" || true
		cls="$(block_path_classify_file "$body")" || true
		wan_verdict="${cls%% *}"
		size="$(wc -c <"$body" 2>/dev/null | awk '{print $1}')"
		printf '  raw-WAN %s content=%s size=%s\n' "$fetch_line" "$cls" "${size:-0}"
	fi

	next="$(block_path_next_after_wan "$wan_verdict")"
	if [ "$next" = 'none' ]; then
		printf '  RESULT recommend=wan (raw-WAN OK)\n'
		rm -f "$body"
		return 0
	fi

	if [ "$next" = 'default' ]; then
		printf '  step2 default-route (no --interface; zapret OUTPUT)\n'
		: >"$body"
		fetch_line="$(block_path_fetch "$url" "$body" "")" || true
		cls="$(block_path_classify_file "$body")" || true
		def_verdict="${cls%% *}"
		size="$(wc -c <"$body" 2>/dev/null | awk '{print $1}')"
		printf '  default %s content=%s size=%s\n' "$fetch_line" "$cls" "${size:-0}"
		rec="$(block_path_recommend "$wan_verdict" default "$def_verdict")"
		if [ "$rec" = 'zapret' ] && [ -e /sys/class/net/warp ]; then
			: >"$body"
			wfetch="$(block_path_fetch "$url" "$body" warp)" || true
			wcls="$(block_path_classify_file "$body")" || true
			wsize="$(wc -c <"$body" 2>/dev/null | awk '{print $1}')"
			printf '  alt warp %s content=%s size=%s\n' "$wfetch" "$wcls" "${wsize:-0}"
			case "${wcls%% *}" in
				OK) printf '  RESULT recommend=zapret (alt=warp works)\n' ;;
				*) printf '  RESULT recommend=zapret\n' ;;
			esac
		else
			printf '  RESULT recommend=%s\n' "$rec"
		fi
		rm -f "$body"
		case "$rec" in
			wan|proton|zapret) return 0 ;;
			*) return 1 ;;
		esac
	fi

	printf '  step2 try %s (because raw-WAN=%s)\n' "$next" "$wan_verdict"
	second_dev="$next"
	if [ ! -e "/sys/class/net/$second_dev" ]; then
		printf '  %s SKIP no-iface\n' "$next"
		printf '  RESULT recommend=proton-fail\n'
		rm -f "$body"
		return 1
	fi

	: >"$body"
	fetch_line="$(block_path_fetch "$url" "$body" "$second_dev")" || true
	cls="$(block_path_classify_file "$body")" || true
	second_verdict="${cls%% *}"
	size="$(wc -c <"$body" 2>/dev/null | awk '{print $1}')"
	printf '  %s %s content=%s size=%s\n' "$next" "$fetch_line" "$cls" "${size:-0}"
	rec="$(block_path_recommend "$wan_verdict" "$next" "$second_verdict")"
	printf '  RESULT recommend=%s\n' "$rec"
	rm -f "$body"
	case "$rec" in
		wan|proton|zapret|proton-check-browser) return 0 ;;
		*) return 1 ;;
	esac
}

# --- live entrypoint (skip when sourced) ---
block_path_is_sourced() {
	# shellcheck disable=SC3028
	case "${0##*/}" in
		probe-block-path.sh) return 1 ;;
		*) return 0 ;;
	esac
}

if ! block_path_is_sourced; then
	set -eu
	URLS=''
	while [ "$#" -gt 0 ]; do
		case "$1" in
			--url)
				shift
				URLS="${URLS} ${1:-}"
				;;
			--url=*)
				URLS="${URLS} ${1#*=}"
				;;
			-h|--help)
				printf 'Usage: %s [--url URL]...\n' "$(basename "$0")"
				exit 0
				;;
			*)
				printf 'Unknown: %s\n' "$1" >&2
				exit 1
				;;
		esac
		shift
	done
	URLS="$(printf '%s' "$URLS" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
	[ -n "$URLS" ] || URLS='https://www.mobile.de/'
	ec=0
	for u in $URLS; do
		block_path_probe_one_url "$u" || ec=1
		printf '\n'
	done
	exit "$ec"
fi
