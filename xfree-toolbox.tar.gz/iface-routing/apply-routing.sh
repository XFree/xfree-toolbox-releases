#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
COMMON_SH="${ROOT_DIR}/lib/common.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"
IFACE_ORDER_SH="${SCRIPT_DIR}/lib/iface-order.sh"
PBR_BYPASS_ZONES_SH="${SCRIPT_DIR}/lib/pbr-bypass-zones.sh"
POLICY_ROUTING_SH="${SCRIPT_DIR}/lib/policy-routing.sh"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

IFACE_VPN_DNS_COVER_SH="${ROOT_DIR}/lib/iface-vpn-dns-cover.sh"
[ -f "$IFACE_VPN_DNS_COVER_SH" ] || {
    echo "[-] Не найден iface-vpn-dns-cover: $IFACE_VPN_DNS_COVER_SH" >&2
    exit 1
}
# shellcheck disable=SC1090
. "$IFACE_VPN_DNS_COVER_SH"

[ -f "$CONFIG_FILE" ] || {
    echo "[-] Не найден конфиг: $CONFIG_FILE" >&2
    exit 1
}
. "$CONFIG_FILE"
[ -f "$IFACE_ORDER_SH" ] || {
    echo "[-] Не найден iface-order lib: $IFACE_ORDER_SH" >&2
    exit 1
}
. "$IFACE_ORDER_SH"
[ -f "$PBR_BYPASS_ZONES_SH" ] || {
    echo "[-] Не найден pbr-bypass-zones lib: $PBR_BYPASS_ZONES_SH" >&2
    exit 1
}
. "$PBR_BYPASS_ZONES_SH"
[ -f "$POLICY_ROUTING_SH" ] || {
    echo "[-] Не найден policy-routing lib: $POLICY_ROUTING_SH" >&2
    exit 1
}
. "$POLICY_ROUTING_SH"

trim_var_local() {
    printf '%s' "$1" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//'
}

conf_value_from_file() {
    cfg="$1"
    key="$2"
    [ -f "$cfg" ] || return 0
    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$cfg"
}

BASE_DIR="$(trim_var_local "${BASE_DIR:-$SCRIPT_DIR}")"
BASE_DIR="$(resolve_path_from "$(pwd -P)" "$BASE_DIR")"
PROFILE_DIR_ARG="${PROFILE_DIR:-}"
while [ "$#" -gt 0 ]; do
    case "$1" in
        --profile-dir)
            shift
            [ "$#" -gt 0 ] || die "Не указано значение для --profile-dir"
            PROFILE_DIR_ARG="$1"
            ;;
        -h|--help)
            cat <<EOF2
Usage:
  $(basename "$0") [--profile-dir DIR]
EOF2
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift
done

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "$PROFILE_DIR_ARG")"

SYSTEM_DOMAIN_ROUTING_DIR="$(resolve_path_from "$BASE_DIR" "${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}")"
INTERFACES_DIR="$(resolve_path_from "$BASE_DIR" "${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}")"
SYSTEM_INTERFACES_DIR="$(resolve_path_from "$BASE_DIR" "${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}")"
SYSTEM_GENERATED_DIR="$(resolve_path_from "$BASE_DIR" "${SYSTEM_GENERATED_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/interfaces}")"
DNSMASQ_DIR="$(resolve_path_from "$BASE_DIR" "${DNSMASQ_DIR:-/etc/dnsmasq.d/xfree-toolbox-routing}")"
DNSMASQ_FILE="$(resolve_path_from "$BASE_DIR" "${DNSMASQ_FILE:-$DNSMASQ_DIR/90-xfree-toolbox-fqdn-routing.conf}")"
NFT_FILE="$(resolve_path_from "$BASE_DIR" "${NFT_FILE:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/90-xfree-toolbox-fqdn-routing.nft}")"
HOTPLUG_FILE="$(resolve_path_from "$BASE_DIR" "${HOTPLUG_FILE:-/etc/hotplug.d/iface/90-xfree-toolbox-routing}")"
BACKUP_ROOT="$(resolve_path_from "$BASE_DIR" "${BACKUP_ROOT:-$(common_backup_root)/iface-routing}")"
BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"
ROUTE_TABLE_PREFIX="${ROUTE_TABLE_PREFIX:-xfree-routing-rt-}"
ENABLE_LEGACY_CLEANUP="${ENABLE_LEGACY_CLEANUP:-1}"
SELF_ROUTE_APPLY_SCRIPT="$(resolve_path_from "$BASE_DIR" "${SELF_ROUTE_APPLY_SCRIPT:-$SCRIPT_DIR/self-route/apply.sh}")"
RECOVERY_UPLINK_HOTPLUG_SCRIPT="$(resolve_path_from "$BASE_DIR" "${RECOVERY_UPLINK_HOTPLUG_SCRIPT:-$SCRIPT_DIR/recovery-scheduler/install-uplink-hotplug.sh}")"

TMP_ROOT=""
COMBINED_DNSMASQ_TMP=""
COMBINED_NFT_TMP=""
COMBINED_HOTPLUG_TMP=""
ALL_WORK_IFACES=""
ACTIVE_IFACES=""
ACTIVE_IFACES_REFRESH_ORDER=""

cleanup_tmp() {
    [ -n "${TMP_ROOT:-}" ] && rm -rf "$TMP_ROOT" 2>/dev/null || true
}
trap cleanup_tmp EXIT INT TERM

for cmd in awk cat chmod cp date dnsmasq find grep ip logger mkdir mktemp mv nft rm sed sort uci uname wc; do
    require_cmd "$cmd"
done

work_iface_dir_of() { printf '%s/%s\n' "$INTERFACES_DIR" "$1"; }
work_iface_config_dir_of() { printf '%s/config\n' "$(work_iface_dir_of "$1")"; }
work_iface_conf_of() { printf '%s/iface.conf\n' "$(work_iface_config_dir_of "$1")"; }
work_iface_fqdn_dir_of() { printf '%s/fqdn.d\n' "$(work_iface_dir_of "$1")"; }
work_iface_fqdn_exclude_dir_of() { printf '%s/fqdn.exclude.d\n' "$(work_iface_dir_of "$1")"; }
work_iface_prefix_dir_of() { printf '%s/prefixes.d\n' "$(work_iface_dir_of "$1")"; }

system_iface_dir_of() { printf '%s/%s\n' "$SYSTEM_INTERFACES_DIR" "$1"; }
system_iface_config_dir_of() { printf '%s/config\n' "$(system_iface_dir_of "$1")"; }
system_iface_active_fqdn_dir_of() { printf '%s/fqdn.d\n' "$(system_iface_dir_of "$1")"; }
system_iface_active_fqdn_exclude_dir_of() { printf '%s/fqdn.exclude.d\n' "$(system_iface_dir_of "$1")"; }
system_iface_active_prefix_dir_of() { printf '%s/prefixes.d\n' "$(system_iface_dir_of "$1")"; }

iface_generated_dir_of() { printf '%s/%s\n' "$SYSTEM_GENERATED_DIR" "$1"; }
iface_generated_fqdn_file_of() { printf '%s/fqdn.generated.lst\n' "$(iface_generated_dir_of "$1")"; }
iface_generated_prefixes4_file_of() { printf '%s/prefixes4.generated.lst\n' "$(iface_generated_dir_of "$1")"; }
iface_generated_prefixes6_file_of() { printf '%s/prefixes6.generated.lst\n' "$(iface_generated_dir_of "$1")"; }
iface_generated_fqdn_map_file_of() { printf '%s/fqdn.sources.map\n' "$(iface_generated_dir_of "$1")"; }
iface_generated_prefixes4_map_file_of() { printf '%s/prefixes4.sources.map\n' "$(iface_generated_dir_of "$1")"; }
iface_generated_prefixes6_map_file_of() { printf '%s/prefixes6.sources.map\n' "$(iface_generated_dir_of "$1")"; }
iface_generated_build_info_file_of() { printf '%s/build.info\n' "$(iface_generated_dir_of "$1")"; }

list_work_interfaces() {
    common_list_domain_interfaces "$INTERFACES_DIR"
}

is_iface_ready4() {
    iface="$1"
    ip link show "$iface" >/dev/null 2>&1 || return 1
    ip -4 addr show dev "$iface" 2>/dev/null | grep -q 'inet ' || return 1
    return 0
}

is_iface_ready6() {
    iface="$1"
    ip link show "$iface" >/dev/null 2>&1 || return 1
    ip -6 addr show dev "$iface" scope global 2>/dev/null | grep -q 'inet6 ' || return 1
    return 0
}

ensure_dnsmasq_confdir() {
    conf_exists=0
    current="$(uci -q get dhcp.@dnsmasq[0].confdir 2>/dev/null || true)"
    for d in $current; do
        [ "$(trim_var_local "$d")" = "$DNSMASQ_DIR" ] && conf_exists=1
    done
    if [ "$conf_exists" -eq 0 ]; then
        info "Добавляю confdir dnsmasq: $DNSMASQ_DIR"
        uci add_list dhcp.@dnsmasq[0].confdir="$DNSMASQ_DIR"
    fi
}

sync_dir_mirror() {
    src="$1"
    dst="$2"
    mkdir -p "$src" "$dst"
    find "$dst" -mindepth 1 -maxdepth 1 -exec rm -rf {} \; 2>/dev/null || true
    while IFS= read -r f; do
        [ -f "$f" ] || continue
        cp -f "$f" "$dst/"
    done <<EOF2
$(find "$src" -maxdepth 1 -type f 2>/dev/null | sort)
EOF2
}

rotate_backups() {
    # Backup policy: domain-routing runtime snapshots use common retention.
    common_backup_rotate "$BACKUP_ROOT" runtime "$BACKUP_KEEP"
}

create_backup() {
    ts="$(backup_stamp_now)"

    # Backup policy: pre-apply runtime snapshot directory used for rollback; rotated by common_backup_rotate.
    mkdir -p "$BACKUP_ROOT"
    tmp_dir="$BACKUP_ROOT/.runtime.$ts.tmp.$$"
    final_dir="$BACKUP_ROOT/runtime.$ts"
    mkdir -p "$tmp_dir/interfaces" "$tmp_dir/generated" "$tmp_dir/runtime"
    info "Создаю backup: $ts"
    if [ -d "$SYSTEM_INTERFACES_DIR" ]; then cp -a "$SYSTEM_INTERFACES_DIR/." "$tmp_dir/interfaces/" 2>/dev/null || true; fi
    if [ -d "$SYSTEM_GENERATED_DIR" ]; then cp -a "$SYSTEM_GENERATED_DIR/." "$tmp_dir/generated/" 2>/dev/null || true; fi
    [ -f "$NFT_FILE" ] && cp -a "$NFT_FILE" "$tmp_dir/runtime/90-xfree-toolbox-fqdn-routing.nft" || true
    [ -f "$DNSMASQ_FILE" ] && cp -a "$DNSMASQ_FILE" "$tmp_dir/runtime/90-xfree-toolbox-fqdn-routing.conf" || true
    [ -f "$HOTPLUG_FILE" ] && cp -a "$HOTPLUG_FILE" "$tmp_dir/runtime/90-xfree-toolbox-routing.hotplug" || true
    cat > "$tmp_dir/meta.info" <<EOF2
BACKUP_TIME=$(date -Iseconds)
HOSTNAME=$(uname -n)
REASON=pre-apply
BASE_DIR=$BASE_DIR
EOF2
    mv "$tmp_dir" "$final_dir"
    info "Backup создан: $final_dir"
    rotate_backups
}

restore_latest_backup() {
    last="$(find "$BACKUP_ROOT" -mindepth 1 -maxdepth 1 -type d -name 'runtime.*' 2>/dev/null | sort | tail -n 1 || true)"
    [ -n "$last" ] || die "Не найден backup для восстановления"
    src="$last"
    info "Восстанавливаю backup: $(basename "$last")"
    rm -rf "$SYSTEM_INTERFACES_DIR" "$SYSTEM_GENERATED_DIR"
    mkdir -p "$SYSTEM_INTERFACES_DIR" "$SYSTEM_GENERATED_DIR" "$DNSMASQ_DIR" /etc/hotplug.d/iface
    [ -d "$src/interfaces" ] && cp -a "$src/interfaces/." "$SYSTEM_INTERFACES_DIR/" || true
    [ -d "$src/generated" ] && cp -a "$src/generated/." "$SYSTEM_GENERATED_DIR/" || true
    [ -f "$src/runtime/90-domain-routing.nft" ] && cp -f "$src/runtime/90-domain-routing.nft" "$NFT_FILE" || true
    [ -f "$src/runtime/90-xfree-toolbox-fqdn-routing.nft" ] && cp -f "$src/runtime/90-xfree-toolbox-fqdn-routing.nft" "$NFT_FILE" || true
    [ -f "$src/runtime/90-domain-routing.conf" ] && cp -f "$src/runtime/90-domain-routing.conf" "$DNSMASQ_FILE" || true
    [ -f "$src/runtime/90-xfree-toolbox-routing.conf" ] && cp -f "$src/runtime/90-xfree-toolbox-routing.conf" "$DNSMASQ_FILE" || true
    [ -f "$src/runtime/90-xfree-toolbox-fqdn-routing.conf" ] && cp -f "$src/runtime/90-xfree-toolbox-fqdn-routing.conf" "$DNSMASQ_FILE" || true
    [ -f "$src/runtime/90-domain-routing.hotplug" ] && cp -f "$src/runtime/90-domain-routing.hotplug" "$HOTPLUG_FILE" || true
    [ -f "$src/runtime/90-xfree-toolbox-routing.hotplug" ] && cp -f "$src/runtime/90-xfree-toolbox-routing.hotplug" "$HOTPLUG_FILE" || true
    chmod +x "$HOTPLUG_FILE" 2>/dev/null || true
    uci commit dhcp 2>/dev/null || true
    uci commit firewall 2>/dev/null || true
    uci commit network 2>/dev/null || true
    /etc/init.d/dnsmasq restart 2>/dev/null || true
    /etc/init.d/firewall restart 2>/dev/null || true
    /etc/init.d/network reload 2>/dev/null || true
}

on_error() {
    code="$?"
    warn "apply завершился с ошибкой (code=$code), выполняю rollback"
    restore_latest_backup || true
    exit "$code"
}
trap on_error HUP QUIT PIPE

normalize_fqdn_stream() {
    awk '{
        line=$0
        sub(/\r$/, "", line)
        sub(/[[:space:]]*#.*/, "", line)
        gsub(/^[ \t]+|[ \t]+$/, "", line)
        if (line == "") next
        if (line ~ /^;/) next
        if (line ~ /^\[/) next
        split(line, a, /[ \t]+/)
        d=a[1]
        gsub(/^\*\./, "", d)
        gsub(/^\./, "", d)
        d=tolower(d)
        if (d ~ /^[a-z0-9._-]+$/ && d ~ /\./) print d
    }'
}

normalize_prefix4_stream() {
    awk '{
        line=$0
        sub(/\r$/, "", line)
        sub(/[[:space:]]*#.*/, "", line)
        gsub(/^[ \t]+|[ \t]+$/, "", line)
        if (line == "") next
        if (line ~ /^;/) next
        if (line ~ /^\[/) next
        split(line, a, /[ \t]+/)
        p=a[1]
        if (p ~ /^([0-9]{1,3}\.){3}[0-9]{1,3}\/[0-9]{1,2}$/) print p
    }'
}

normalize_prefix6_stream() {
    awk '{
        line=$0
        sub(/\r$/, "", line)
        sub(/[[:space:]]*#.*/, "", line)
        gsub(/^[ \t]+|[ \t]+$/, "", line)
        if (line == "") next
        if (line ~ /^;/) next
        if (line ~ /^\[/) next
        split(line, a, /[ \t]+/)
        p=a[1]
        if (p ~ /:/ && p ~ /\/[0-9]{1,3}$/) print tolower(p)
    }'
}

load_iface_conf_from_file() {
    conf_file="$1"
    iface_fallback="$2"

    INTERFACE_NAME=''
    VPN_DEV=''
    MARK_HEX=''
    ROUTE_TABLE_ID=''
    ROUTE_TABLE_NAME=''
    IP_RULE_PREF=''
    SELF_ROUTE_VIA=''
    SOURCE_META=''
    AMNEZIAWG_PEER_SECTION=''
    PERSISTENT_KEEPALIVE_DEFAULT=''
    ROUTE_ALLOWED_IPS_DEFAULT=''
    PBR_BYPASS_NETWORKS=''

    NFT_FQDN_SET_NAME=''
    NFT_PREFIX_SET_NAME=''

    NFT_FQDN4_SET_NAME=''
    NFT_FQDN6_SET_NAME=''
    NFT_PREFIX4_SET_NAME=''
    NFT_PREFIX6_SET_NAME=''
    NFT_CHAIN_NAME=''
    NFT_OUTPUT_CHAIN_NAME=''

    . "$conf_file"

    INTERFACE_NAME="$(trim_var_local "${INTERFACE_NAME:-$iface_fallback}")"
    VPN_DEV="$(trim_var_local "${VPN_DEV:-$INTERFACE_NAME}")"
    MARK_HEX="$(trim_var_local "${MARK_HEX:-}")"
    ROUTE_TABLE_ID="$(trim_var_local "${ROUTE_TABLE_ID:-}")"
    ROUTE_TABLE_NAME="$(trim_var_local "${ROUTE_TABLE_NAME:-$INTERFACE_NAME}")"
    IP_RULE_PREF="$(trim_var_local "${IP_RULE_PREF:-10000}")"
    SELF_ROUTE_VIA="$(trim_var_local "${SELF_ROUTE_VIA:-}")"
    PBR_BYPASS_NETWORKS="$(trim_var_local "${PBR_BYPASS_NETWORKS:-}")"
    SOURCE_META="$(trim_var_local "${SOURCE_META:-source.conf.meta}")"
    AMNEZIAWG_PEER_SECTION="$(trim_var_local "${AMNEZIAWG_PEER_SECTION:-}")"
    PERSISTENT_KEEPALIVE_DEFAULT="$(trim_var_local "${PERSISTENT_KEEPALIVE_DEFAULT:-20}")"
    ROUTE_ALLOWED_IPS_DEFAULT="$(trim_var_local "${ROUTE_ALLOWED_IPS_DEFAULT:-0}")"

    source_meta_file="$(dirname "$conf_file")/$SOURCE_META"
    meta_keepalive="$(conf_value_from_file "$source_meta_file" "PERSISTENT_KEEPALIVE_DEFAULT" || true)"
    meta_route_allowed="$(conf_value_from_file "$source_meta_file" "ROUTE_ALLOWED_IPS_DEFAULT" || true)"
    case "$meta_keepalive" in
        ''|*[!0-9]*) ;;
        *) PERSISTENT_KEEPALIVE_DEFAULT="$meta_keepalive" ;;
    esac
    case "$meta_route_allowed" in
        0|1) ROUTE_ALLOWED_IPS_DEFAULT="$meta_route_allowed" ;;
    esac

    if { [ -n "${NFT_FQDN_SET_NAME:-}" ] || [ -n "${NFT_PREFIX_SET_NAME:-}" ]; } && \
       { [ -z "${NFT_FQDN4_SET_NAME:-}" ] || [ -z "${NFT_PREFIX4_SET_NAME:-}" ]; }; then
        die "Интерфейс '$INTERFACE_NAME' использует legacy-схему nft-имен. Выполните: Интерфейсы / WARP -> Обновить интерфейс из conf"
    fi

    NFT_FQDN4_SET_NAME="$(trim_var_local "${NFT_FQDN4_SET_NAME:-}")"
    NFT_FQDN6_SET_NAME="$(trim_var_local "${NFT_FQDN6_SET_NAME:-}")"
    NFT_PREFIX4_SET_NAME="$(trim_var_local "${NFT_PREFIX4_SET_NAME:-}")"
    NFT_PREFIX6_SET_NAME="$(trim_var_local "${NFT_PREFIX6_SET_NAME:-}")"
    NFT_CHAIN_NAME="$(trim_var_local "${NFT_CHAIN_NAME:-mangle_prerouting_${INTERFACE_NAME}}")"
    NFT_OUTPUT_CHAIN_NAME="$(trim_var_local "${NFT_OUTPUT_CHAIN_NAME:-mangle_output_${INTERFACE_NAME}}")"

    [ -n "$INTERFACE_NAME" ] || die "INTERFACE_NAME пустой в $conf_file"
    [ -n "$VPN_DEV" ] || die "VPN_DEV пустой в $conf_file"
    [ -n "$MARK_HEX" ] || die "MARK_HEX не задан в $conf_file"
    [ -n "$ROUTE_TABLE_ID" ] || die "ROUTE_TABLE_ID не задан в $conf_file"
    [ -n "$ROUTE_TABLE_NAME" ] || die "ROUTE_TABLE_NAME не задан в $conf_file"
    [ -n "$NFT_FQDN4_SET_NAME" ] || die "NFT_FQDN4_SET_NAME не задан в $conf_file"
    [ -n "$NFT_FQDN6_SET_NAME" ] || die "NFT_FQDN6_SET_NAME не задан в $conf_file"
    [ -n "$NFT_PREFIX4_SET_NAME" ] || die "NFT_PREFIX4_SET_NAME не задан в $conf_file"
    [ -n "$NFT_PREFIX6_SET_NAME" ] || die "NFT_PREFIX6_SET_NAME не задан в $conf_file"
    [ -n "$NFT_CHAIN_NAME" ] || die "NFT_CHAIN_NAME не задан в $conf_file"
    [ -n "$NFT_OUTPUT_CHAIN_NAME" ] || die "NFT_OUTPUT_CHAIN_NAME не задан в $conf_file"
    case "$ROUTE_ALLOWED_IPS_DEFAULT" in
        0|1) ;;
        *) ROUTE_ALLOWED_IPS_DEFAULT="0" ;;
    esac
}

list_has_value() {
    list="$1"
    needle="$2"
    [ -n "$needle" ] || return 1
    printf '%s\n' "$list" | sed '/^$/d' | grep -Fxq "$needle"
}

load_work_iface_conf() {
    iface="$1"
    conf_file="$(work_iface_conf_of "$iface")"
    [ -f "$conf_file" ] || die "Не найден конфиг интерфейса: $conf_file"
    load_iface_conf_from_file "$conf_file" "$iface"
}

validate_all_iface_configs() {
    info "Проверяю конфигурации интерфейсов (preflight)"
    printf '%s\n' "$ALL_WORK_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        load_work_iface_conf "$iface"
    done
}

assert_unique_iface_values() {
    tmp_seen_marks="$TMP_ROOT/seen_marks.txt"
    tmp_seen_tables="$TMP_ROOT/seen_tables.txt"
    tmp_seen_names="$TMP_ROOT/seen_table_names.txt"
    tmp_seen_prefs="$TMP_ROOT/seen_prefs.txt"
    tmp_seen_sets="$TMP_ROOT/seen_sets.txt"
    : > "$tmp_seen_marks"
    : > "$tmp_seen_tables"
    : > "$tmp_seen_names"
    : > "$tmp_seen_prefs"
    : > "$tmp_seen_sets"

    printf '%s\n' "$ALL_WORK_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        load_work_iface_conf "$iface"
        grep -Fx "$MARK_HEX" "$tmp_seen_marks" >/dev/null 2>&1 && die "Дублируется MARK_HEX=$MARK_HEX (iface=$iface)"
        grep -Fx "$ROUTE_TABLE_ID" "$tmp_seen_tables" >/dev/null 2>&1 && die "Дублируется ROUTE_TABLE_ID=$ROUTE_TABLE_ID (iface=$iface)"
        grep -Fx "$ROUTE_TABLE_NAME" "$tmp_seen_names" >/dev/null 2>&1 && die "Дублируется ROUTE_TABLE_NAME=$ROUTE_TABLE_NAME (iface=$iface)"
        grep -Fx "$IP_RULE_PREF" "$tmp_seen_prefs" >/dev/null 2>&1 && die "Дублируется IP_RULE_PREF=$IP_RULE_PREF (iface=$iface)"
        for nft_name in "$NFT_FQDN4_SET_NAME" "$NFT_FQDN6_SET_NAME" "$NFT_PREFIX4_SET_NAME" "$NFT_PREFIX6_SET_NAME" "$NFT_CHAIN_NAME" "$NFT_OUTPUT_CHAIN_NAME"; do
            grep -Fx "$nft_name" "$tmp_seen_sets" >/dev/null 2>&1 && die "Дублируется nft-имя=$nft_name (iface=$iface)"
            printf '%s\n' "$nft_name" >> "$tmp_seen_sets"
        done
        printf '%s\n' "$MARK_HEX" >> "$tmp_seen_marks"
        printf '%s\n' "$ROUTE_TABLE_ID" >> "$tmp_seen_tables"
        printf '%s\n' "$ROUTE_TABLE_NAME" >> "$tmp_seen_names"
        printf '%s\n' "$IP_RULE_PREF" >> "$tmp_seen_prefs"
    done
}

sync_rt_tables_to_active_state() {
    tmp_rt="$TMP_ROOT/rt_tables.new"
    cp -f /etc/iproute2/rt_tables "$tmp_rt"
    sed -i "\\|[[:space:]]$ROUTE_TABLE_PREFIX|d" "$tmp_rt"
    [ "$ENABLE_LEGACY_CLEANUP" = "1" ] && sed -i '/[[:space:]]vpnmark\([[:space:]]\+\|$\)/d' "$tmp_rt"

    printf '%s\n' "$ACTIVE_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        load_work_iface_conf "$iface"
        grep -Eq "^[[:space:]]*${ROUTE_TABLE_ID}[[:space:]]+${ROUTE_TABLE_NAME}[[:space:]]*$" "$tmp_rt" || printf '%s %s\n' "$ROUTE_TABLE_ID" "$ROUTE_TABLE_NAME" >> "$tmp_rt"
    done

    cp -f "$tmp_rt" /etc/iproute2/rt_tables
}

rebuild_generated_for_iface() {
    iface="$1"
    load_work_iface_conf "$iface"

    work_fqdn_dir="$(work_iface_fqdn_dir_of "$iface")"
    work_fqdn_exclude_dir="$(work_iface_fqdn_exclude_dir_of "$iface")"
    work_prefix_dir="$(work_iface_prefix_dir_of "$iface")"
    active_iface_dir="$(system_iface_dir_of "$iface")"
    active_config_dir="$(system_iface_config_dir_of "$iface")"
    active_fqdn_dir="$(system_iface_active_fqdn_dir_of "$iface")"
    active_fqdn_exclude_dir="$(system_iface_active_fqdn_exclude_dir_of "$iface")"
    active_prefix_dir="$(system_iface_active_prefix_dir_of "$iface")"
    generated_dir="$(iface_generated_dir_of "$iface")"
    generated_fqdn_file="$(iface_generated_fqdn_file_of "$iface")"
    generated_prefixes4_file="$(iface_generated_prefixes4_file_of "$iface")"
    generated_prefixes6_file="$(iface_generated_prefixes6_file_of "$iface")"
    generated_fqdn_map_file="$(iface_generated_fqdn_map_file_of "$iface")"
    generated_prefixes4_map_file="$(iface_generated_prefixes4_map_file_of "$iface")"
    generated_prefixes6_map_file="$(iface_generated_prefixes6_map_file_of "$iface")"
    generated_build_info_file="$(iface_generated_build_info_file_of "$iface")"

    mkdir -p "$work_fqdn_dir" "$work_fqdn_exclude_dir" "$work_prefix_dir" "$active_config_dir" "$active_fqdn_dir" "$active_fqdn_exclude_dir" "$active_prefix_dir" "$generated_dir"

    cp -f "$(work_iface_conf_of "$iface")" "$active_config_dir/iface.conf"
    [ -f "$(work_iface_config_dir_of "$iface")/network.uci" ] && cp -f "$(work_iface_config_dir_of "$iface")/network.uci" "$active_config_dir/network.uci"
    [ -f "$(work_iface_config_dir_of "$iface")/firewall.uci" ] && cp -f "$(work_iface_config_dir_of "$iface")/firewall.uci" "$active_config_dir/firewall.uci"
    [ -f "$(work_iface_config_dir_of "$iface")/source.conf" ] && cp -f "$(work_iface_config_dir_of "$iface")/source.conf" "$active_config_dir/source.conf"
    [ -f "$(work_iface_config_dir_of "$iface")/source.conf.meta" ] && cp -f "$(work_iface_config_dir_of "$iface")/source.conf.meta" "$active_config_dir/source.conf.meta"

    info "Синхронизирую списки iface=$iface: work -> active"
    sync_dir_mirror "$work_fqdn_dir" "$active_fqdn_dir"
    sync_dir_mirror "$work_fqdn_exclude_dir" "$active_fqdn_exclude_dir"
    sync_dir_mirror "$work_prefix_dir" "$active_prefix_dir"

    tmp_fqdn_raw="$TMP_ROOT/${iface}.fqdn.raw"
    tmp_prefix4_raw="$TMP_ROOT/${iface}.prefix4.raw"
    tmp_prefix6_raw="$TMP_ROOT/${iface}.prefix6.raw"
    tmp_prefix4_sorted="$TMP_ROOT/${iface}.prefix4.sorted"
    tmp_prefix6_sorted="$TMP_ROOT/${iface}.prefix6.sorted"
    tmp_exclude="$TMP_ROOT/${iface}.fqdn.exclude"

    : > "$tmp_fqdn_raw"
    : > "$tmp_prefix4_raw"
    : > "$tmp_prefix6_raw"
    : > "$generated_fqdn_map_file"
    : > "$generated_prefixes4_map_file"
    : > "$generated_prefixes6_map_file"

    # fqdn.exclude.d вычитается до записи списка. Дальше nftset и server= туннеля
    # читают только то, что осталось.
    iface_vpn_dns_collect_exclude_fqdns "$INTERFACES_DIR" > "$tmp_exclude" || true

    while IFS= read -r f; do
        [ -f "$f" ] || continue
        name="$(basename "$f")"
        while IFS= read -r raw_line || [ -n "$raw_line" ]; do
            line="$(printf '%s' "$raw_line" | sed 's/\r$//; s/[[:space:]]*#.*$//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
            [ -n "$line" ] || continue
            normalized="$(printf '%s\n' "$line" | normalize_fqdn_stream || true)"
            [ -n "$normalized" ] || continue
            if iface_vpn_dns_domain_excluded "$normalized" "$tmp_exclude"; then
                continue
            fi
            printf '%s\n' "$normalized" >> "$tmp_fqdn_raw"
            printf '%s:%s\n' "$name" "$normalized" >> "$generated_fqdn_map_file"
        done < "$f"
    done <<EOF2
$(find "$active_fqdn_dir" -maxdepth 1 -type f 2>/dev/null | sort)
EOF2

    if [ -s "$tmp_fqdn_raw" ]; then
        sort -u "$tmp_fqdn_raw" > "$generated_fqdn_file"
    else
        : > "$generated_fqdn_file"
    fi

    while IFS= read -r f; do
        [ -f "$f" ] || continue
        name="$(basename "$f")"
        while IFS= read -r raw_line || [ -n "$raw_line" ]; do
            line="$(printf '%s' "$raw_line" | sed 's/\r$//; s/[[:space:]]*#.*$//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
            [ -n "$line" ] || continue

            normalized4="$(printf '%s\n' "$line" | normalize_prefix4_stream || true)"
            if [ -n "$normalized4" ] && ! iface_vpn_dns_is_protected_public_dns "$normalized4"; then
                printf '%s\n' "$normalized4" >> "$tmp_prefix4_raw"
                printf '%s:%s\n' "$name" "$normalized4" >> "$generated_prefixes4_map_file"
            fi

            normalized6="$(printf '%s\n' "$line" | normalize_prefix6_stream || true)"
            if [ -n "$normalized6" ] && ! iface_vpn_dns_is_protected_public_dns "$normalized6"; then
                printf '%s\n' "$normalized6" >> "$tmp_prefix6_raw"
                printf '%s:%s\n' "$name" "$normalized6" >> "$generated_prefixes6_map_file"
            fi
        done < "$f"
    done <<EOF2
$(find "$active_prefix_dir" -maxdepth 1 -type f 2>/dev/null | sort)
EOF2

    if [ -s "$tmp_prefix4_raw" ]; then
        sort -u "$tmp_prefix4_raw" > "$tmp_prefix4_sorted"
        cp -f "$tmp_prefix4_sorted" "$generated_prefixes4_file"
    else
        : > "$generated_prefixes4_file"
    fi

    if [ -s "$tmp_prefix6_raw" ]; then
        sort -u "$tmp_prefix6_raw" > "$tmp_prefix6_sorted"
        cp -f "$tmp_prefix6_sorted" "$generated_prefixes6_file"
    else
        : > "$generated_prefixes6_file"
    fi

    fqdn_files="$(find "$active_fqdn_dir" -maxdepth 1 -type f 2>/dev/null | wc -l | tr -d ' ')"
    prefix_files="$(find "$active_prefix_dir" -maxdepth 1 -type f 2>/dev/null | wc -l | tr -d ' ')"
    fqdn_lines=0
    prefix4_lines=0
    prefix6_lines=0
    [ -f "$generated_fqdn_file" ] && fqdn_lines="$(wc -l < "$generated_fqdn_file" | tr -d ' ')"
    [ -f "$generated_prefixes4_file" ] && prefix4_lines="$(wc -l < "$generated_prefixes4_file" | tr -d ' ')"
    [ -f "$generated_prefixes6_file" ] && prefix6_lines="$(wc -l < "$generated_prefixes6_file" | tr -d ' ')"

    cat > "$generated_build_info_file" <<EOF2
BUILD_TIME=$(date -Iseconds)
HOSTNAME=$(uname -n)
BASE_DIR=$BASE_DIR
INTERFACE_NAME=$INTERFACE_NAME
VPN_DEV=$VPN_DEV
MARK_HEX=$MARK_HEX
ROUTE_TABLE_ID=$ROUTE_TABLE_ID
ROUTE_TABLE_NAME=$ROUTE_TABLE_NAME
WORK_FQDN_DIR=$work_fqdn_dir
WORK_PREFIX_DIR=$work_prefix_dir
ACTIVE_FQDN_DIR=$active_fqdn_dir
ACTIVE_PREFIX_DIR=$active_prefix_dir
FQDN_FILES=$fqdn_files
PREFIX_FILES=$prefix_files
FQDN_LINES=$fqdn_lines
PREFIX4_LINES=$prefix4_lines
PREFIX6_LINES=$prefix6_lines
EOF2
}

detect_active_ifaces() {
    : > "$TMP_ROOT/active_ifaces.lst"
    printf '%s\n' "$ALL_WORK_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        generated_fqdn_file="$(iface_generated_fqdn_file_of "$iface")"
        generated_prefixes4_file="$(iface_generated_prefixes4_file_of "$iface")"
        generated_prefixes6_file="$(iface_generated_prefixes6_file_of "$iface")"
        if [ -s "$generated_fqdn_file" ] || [ -s "$generated_prefixes4_file" ] || [ -s "$generated_prefixes6_file" ]; then
            printf '%s\n' "$iface" >> "$TMP_ROOT/active_ifaces.lst"
        fi
    done
    ACTIVE_IFACES="$(cat "$TMP_ROOT/active_ifaces.lst" 2>/dev/null || true)"
}

build_active_iface_refresh_order() {
    ACTIVE_IFACES_REFRESH_ORDER="$(iface_build_order_by_dependency "$ACTIVE_IFACES" active_iface_upstream_dep)"
}

active_iface_upstream_dep() {
    iface="$1"
    [ -n "$iface" ] || return 0
    load_work_iface_conf "$iface"
    trim_var_local "${SELF_ROUTE_VIA:-}"
}

print_interfaces_build_summary() {
    info "Сводка по интерфейсам"

    if [ -z "$ALL_WORK_IFACES" ]; then
        echo "  (интерфейсы отсутствуют)"
        return 0
    fi

    printf '%s\n' "$ALL_WORK_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue

        generated_build_info_file="$(iface_generated_build_info_file_of "$iface")"
        generated_fqdn_file="$(iface_generated_fqdn_file_of "$iface")"
        generated_prefixes4_file="$(iface_generated_prefixes4_file_of "$iface")"
        generated_prefixes6_file="$(iface_generated_prefixes6_file_of "$iface")"

        fqdn_lines=0
        prefix4_lines=0
        prefix6_lines=0
        fqdn_files=0
        prefix_files=0
        active="no"

        if [ -f "$generated_build_info_file" ]; then
            fqdn_files="$(awk -F= '/^FQDN_FILES=/{print $2; exit}' "$generated_build_info_file")"
            prefix_files="$(awk -F= '/^PREFIX_FILES=/{print $2; exit}' "$generated_build_info_file")"
            fqdn_lines="$(awk -F= '/^FQDN_LINES=/{print $2; exit}' "$generated_build_info_file")"
            prefix4_lines="$(awk -F= '/^PREFIX4_LINES=/{print $2; exit}' "$generated_build_info_file")"
            prefix6_lines="$(awk -F= '/^PREFIX6_LINES=/{print $2; exit}' "$generated_build_info_file")"
        fi

        [ -n "${fqdn_files:-}" ] || fqdn_files=0
        [ -n "${prefix_files:-}" ] || prefix_files=0
        [ -n "${fqdn_lines:-}" ] || fqdn_lines=0
        [ -n "${prefix4_lines:-}" ] || prefix4_lines=0
        [ -n "${prefix6_lines:-}" ] || prefix6_lines=0

        if [ -s "$generated_fqdn_file" ] || [ -s "$generated_prefixes4_file" ] || [ -s "$generated_prefixes6_file" ]; then
            active="yes"
        fi

        printf '  - %s: active=%s, fqdn_files=%s, fqdn_lines=%s, prefix_files=%s, prefix4_lines=%s, prefix6_lines=%s\n' \
            "$iface" "$active" "$fqdn_files" "$fqdn_lines" "$prefix_files" "$prefix4_lines" "$prefix6_lines"
    done
}

print_runtime_summary() {
    total_ifaces=0
    active_ifaces_count=0
    total_fqdn_lines=0
    total_prefix4_lines=0
    total_prefix6_lines=0

    if [ -n "$ALL_WORK_IFACES" ]; then
        total_ifaces="$(printf '%s\n' "$ALL_WORK_IFACES" | sed '/^$/d' | wc -l | tr -d ' ')"
    fi

    if [ -n "$ACTIVE_IFACES" ]; then
        active_ifaces_count="$(printf '%s\n' "$ACTIVE_IFACES" | sed '/^$/d' | wc -l | tr -d ' ')"
    fi

    printf '%s\n' "$ACTIVE_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        generated_build_info_file="$(iface_generated_build_info_file_of "$iface")"
        [ -f "$generated_build_info_file" ] || continue

        fqdn_lines="$(awk -F= '/^FQDN_LINES=/{print $2; exit}' "$generated_build_info_file")"
        prefix4_lines="$(awk -F= '/^PREFIX4_LINES=/{print $2; exit}' "$generated_build_info_file")"
        prefix6_lines="$(awk -F= '/^PREFIX6_LINES=/{print $2; exit}' "$generated_build_info_file")"

        [ -n "${fqdn_lines:-}" ] || fqdn_lines=0
        [ -n "${prefix4_lines:-}" ] || prefix4_lines=0
        [ -n "${prefix6_lines:-}" ] || prefix6_lines=0

        total_fqdn_lines=$((total_fqdn_lines + fqdn_lines))
        total_prefix4_lines=$((total_prefix4_lines + prefix4_lines))
        total_prefix6_lines=$((total_prefix6_lines + prefix6_lines))

        printf '%s %s %s\n' "$total_fqdn_lines" "$total_prefix4_lines" "$total_prefix6_lines" > "$TMP_ROOT/runtime-summary.totals"
    done

    if [ -f "$TMP_ROOT/runtime-summary.totals" ]; then
        total_fqdn_lines="$(awk '{print $1}' "$TMP_ROOT/runtime-summary.totals")"
        total_prefix4_lines="$(awk '{print $2}' "$TMP_ROOT/runtime-summary.totals")"
        total_prefix6_lines="$(awk '{print $3}' "$TMP_ROOT/runtime-summary.totals")"
    fi

    echo
    echo "Сводка runtime:"
    echo "  interfaces_total : $total_ifaces"
    echo "  interfaces_active: $active_ifaces_count"
    echo "  fqdn_lines_total : $total_fqdn_lines"
    echo "  prefix4_lines_total: $total_prefix4_lines"
    echo "  prefix6_lines_total: $total_prefix6_lines"
}

ensure_iface_peer_options() {
    iface="$1"
    load_work_iface_conf "$iface"

    peer_section="$(trim_var_local "${AMNEZIAWG_PEER_SECTION:-}")"
    [ -n "$peer_section" ] || return 0

    if ! uci -q get "${peer_section}.public_key" >/dev/null 2>&1; then
        warn "Не найдена секция peer для $iface: $peer_section (пропускаю контроль route_allowed_ips/persistent_keepalive)"
        return 0
    fi

    current_rai="$(uci -q get "${peer_section}.route_allowed_ips" 2>/dev/null || true)"
    if [ "$current_rai" != "$ROUTE_ALLOWED_IPS_DEFAULT" ]; then
        info "Восстанавливаю route_allowed_ips для $iface ($peer_section): $current_rai -> $ROUTE_ALLOWED_IPS_DEFAULT"
        uci set "${peer_section}.route_allowed_ips=$ROUTE_ALLOWED_IPS_DEFAULT"
    fi

    current_pk="$(uci -q get "${peer_section}.persistent_keepalive" 2>/dev/null || true)"
    if [ "$current_pk" != "$PERSISTENT_KEEPALIVE_DEFAULT" ]; then
        info "Восстанавливаю persistent_keepalive для $iface ($peer_section): $current_pk -> $PERSISTENT_KEEPALIVE_DEFAULT"
        uci set "${peer_section}.persistent_keepalive=$PERSISTENT_KEEPALIVE_DEFAULT"
    fi
}

build_combined_dnsmasq() {
    : > "$COMBINED_DNSMASQ_TMP"
    {
        echo "# autogenerated by domain-routing"
        printf '%s\n' "$ACTIVE_IFACES" | while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            load_work_iface_conf "$iface"
            generated_fqdn_file="$(iface_generated_fqdn_file_of "$iface")"
            [ -s "$generated_fqdn_file" ] || continue
            meta_file="$(work_iface_config_dir_of "$iface")/source.conf.meta"
            vpn_dns_csv="$(iface_vpn_dns_meta_dns_csv "$meta_file")"
            vpn_resolver="$(iface_vpn_dns_preferred_resolver "$vpn_dns_csv")"
            # Один и тот же отфильтрованный список: и метка туннеля, и DNS туннеля.
            while IFS= read -r fqdn; do
                [ -n "$fqdn" ] || continue
                echo "nftset=/$fqdn/4#inet#fw4#$NFT_FQDN4_SET_NAME"
                echo "nftset=/$fqdn/6#inet#fw4#$NFT_FQDN6_SET_NAME"
                if [ -n "${vpn_resolver:-}" ]; then
                    echo "server=/$fqdn/${vpn_resolver}@${VPN_DEV}"
                fi
            done < "$generated_fqdn_file"
        done
    } > "$COMBINED_DNSMASQ_TMP"
}

nft_append_mark_rules() {
    mark_hex="$1"
    fqdn4_set="$2"
    fqdn6_set="$3"
    prefix4_set="$4"
    prefix6_set="$5"
    generated_fqdn_file="$6"
    generated_prefixes4_file="$7"
    generated_prefixes6_file="$8"

    if [ -s "$generated_fqdn_file" ]; then
        echo "    ip daddr @$fqdn4_set counter meta mark set $mark_hex"
        echo "    ip6 daddr @$fqdn6_set counter meta mark set $mark_hex"
    fi
    if [ -s "$generated_prefixes4_file" ]; then
        echo "    ip daddr @$prefix4_set counter meta mark set $mark_hex"
    fi
    if [ -s "$generated_prefixes6_file" ]; then
        echo "    ip6 daddr @$prefix6_set counter meta mark set $mark_hex"
    fi
}

# fw4 check/reload merges include into the live inet fw4 table. Chains/sets left
# from a prior include or manual `nft add chain` make the next apply fail with
# "File exists" unless we drop our objects first.
purge_runtime_nft_objects() {
    ifaces_list="${ALL_WORK_IFACES:-$ACTIVE_IFACES}"
    [ -n "$ifaces_list" ] || return 0
    if ! nft list table inet fw4 >/dev/null 2>&1; then
        return 0
    fi

    info "Удаляю старые nft chains/sets iface-routing (перед reload firewall)"
    printf '%s\n' "$ifaces_list" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        conf_file="$(work_iface_conf_of "$iface")"
        [ -f "$conf_file" ] || continue
        load_iface_conf_from_file "$conf_file" "$iface"

        for chain_name in "$NFT_OUTPUT_CHAIN_NAME" "$NFT_CHAIN_NAME"; do
            nft delete chain inet fw4 "$chain_name" 2>/dev/null || true
        done
        for set_name in "$NFT_FQDN4_SET_NAME" "$NFT_FQDN6_SET_NAME" "$NFT_PREFIX4_SET_NAME" "$NFT_PREFIX6_SET_NAME"; do
            nft delete set inet fw4 "$set_name" 2>/dev/null || true
        done
        pbr_bypass_purge_nft_sets_for_iface "$iface"
    done
}

build_combined_nft() {
    wan_dns_ips="$TMP_ROOT/wan-dns-target-ips"
    iface_vpn_dns_collect_wan_target_ips "${PROFILE_DIR}/dns-routing/dns" > "$wan_dns_ips" || true
    {
        printf '# autogenerated by domain-routing\n'
        printf '%s\n' "$ACTIVE_IFACES" | while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            load_work_iface_conf "$iface"
            generated_fqdn_file="$(iface_generated_fqdn_file_of "$iface")"
            generated_prefixes4_file="$(iface_generated_prefixes4_file_of "$iface")"
            generated_prefixes6_file="$(iface_generated_prefixes6_file_of "$iface")"

            # Optional: skip VPN PBR for listed UCI networks (e.g. guest → WAN).
            pbr_bypass_emit_nft_sets_for_iface "$INTERFACE_NAME" "${PBR_BYPASS_NETWORKS:-}"

            echo
            echo "set $NFT_FQDN4_SET_NAME {"
            echo "    type ipv4_addr"
            echo "    comment \"autogenerated FQDN IPv4 routing set for $iface\""
            echo "}"

            echo
            echo "set $NFT_FQDN6_SET_NAME {"
            echo "    type ipv6_addr"
            echo "    comment \"autogenerated FQDN IPv6 routing set for $iface\""
            echo "}"

            echo
            echo "set $NFT_PREFIX4_SET_NAME {"
            echo "    type ipv4_addr"
            echo "    flags interval"
            echo "    auto-merge"
            echo "    comment \"autogenerated prefix IPv4 routing set for $iface\""
            if [ -s "$generated_prefixes4_file" ]; then
                echo "    elements = {"
                while IFS= read -r prefix; do
                    [ -n "$prefix" ] || continue
                    printf '        %s,\n' "$prefix"
                done < "$generated_prefixes4_file" | sed '$ s/,$//'
                echo "    }"
            fi
            echo "}"

            echo
            echo "set $NFT_PREFIX6_SET_NAME {"
            echo "    type ipv6_addr"
            echo "    flags interval"
            echo "    auto-merge"
            echo "    comment \"autogenerated prefix IPv6 routing set for $iface\""
            if [ -s "$generated_prefixes6_file" ]; then
                echo "    elements = {"
                while IFS= read -r prefix; do
                    [ -n "$prefix" ] || continue
                    printf '        %s,\n' "$prefix"
                done < "$generated_prefixes6_file" | sed '$ s/,$//'
                echo "    }"
            fi
            echo "}"

            echo
            echo "chain $NFT_CHAIN_NAME {"
            echo "    type filter hook prerouting priority mangle; policy accept;"
            pbr_bypass_emit_prerouting_return_for_iface "$INTERFACE_NAME"
            nft_append_mark_rules "$MARK_HEX" "$NFT_FQDN4_SET_NAME" "$NFT_FQDN6_SET_NAME" \
                "$NFT_PREFIX4_SET_NAME" "$NFT_PREFIX6_SET_NAME" \
                "$generated_fqdn_file" "$generated_prefixes4_file" "$generated_prefixes6_file"
            echo "}"

            echo
            echo "chain $NFT_OUTPUT_CHAIN_NAME {"
            echo "    type route hook output priority mangle; policy accept;"
            echo "    comment \"xfree local output routing marks for $iface (route chain reroutes after mark)\""
            pbr_bypass_emit_output_return_for_iface "$INTERFACE_NAME"
            nft_append_mark_rules "$MARK_HEX" "$NFT_FQDN4_SET_NAME" "$NFT_FQDN6_SET_NAME" \
                "$NFT_PREFIX4_SET_NAME" "$NFT_PREFIX6_SET_NAME" \
                "$generated_fqdn_file" "$generated_prefixes4_file" "$generated_prefixes6_file"
            meta_file="$(work_iface_config_dir_of "$iface")/source.conf.meta"
            vpn_dns_csv="$(iface_vpn_dns_meta_dns_csv "$meta_file")"
            iface_vpn_dns_nft_output_marks "$MARK_HEX" "$vpn_dns_csv" "$wan_dns_ips"
            echo "}"
        done
    } > "$COMBINED_NFT_TMP"
}

build_combined_hotplug() {
    {
        cat <<'EOF2'
#!/bin/sh

POLICY_ROUTING_LIB='__POLICY_ROUTING_LIB__'
if [ -f "$POLICY_ROUTING_LIB" ]; then
    # shellcheck disable=SC1090
    . "$POLICY_ROUTING_LIB"
fi

ensure_peer_options() {
    peer_section="$1"
    route_allowed="$2"
    keepalive="$3"

    [ -n "$peer_section" ] || return 0
    if ! uci -q get "${peer_section}.public_key" >/dev/null 2>&1; then
        return 0
    fi

    changed=0
    current_rai="$(uci -q get "${peer_section}.route_allowed_ips" 2>/dev/null || true)"
    if [ "$current_rai" != "$route_allowed" ]; then
        uci set "${peer_section}.route_allowed_ips=$route_allowed"
        changed=1
    fi

    current_pk="$(uci -q get "${peer_section}.persistent_keepalive" 2>/dev/null || true)"
    if [ "$current_pk" != "$keepalive" ]; then
        uci set "${peer_section}.persistent_keepalive=$keepalive"
        changed=1
    fi

    if [ "$changed" -eq 1 ]; then
        uci commit network
    fi
}

apply_one() {
    vpn_dev="$1"
    mark_hex="$2"
    route_table_name="$3"
    pref="$4"
    peer_section="$5"
    route_allowed="$6"
    keepalive="$7"

    ip link show "$vpn_dev" >/dev/null 2>&1 || return 0
    ensure_peer_options "$peer_section" "$route_allowed" "$keepalive"

    if ip -4 addr show dev "$vpn_dev" 2>/dev/null | grep -q 'inet '; then
        if command -v policy_apply_iface4 >/dev/null 2>&1; then
            policy_apply_iface4 "$vpn_dev" "$mark_hex" "$route_table_name" "$pref" || true
        else
            ip route replace default dev "$vpn_dev" table "$route_table_name" 2>/dev/null || true
            while ip rule del lookup "$route_table_name" pref "$pref" 2>/dev/null; do :; done
            while ip rule del fwmark "$mark_hex" lookup "$route_table_name" 2>/dev/null; do :; done
            ip rule add fwmark "$mark_hex" lookup "$route_table_name" pref "$pref" 2>/dev/null || true
        fi
    fi

    if ip -6 addr show dev "$vpn_dev" scope global 2>/dev/null | grep -q 'inet6 '; then
        if command -v policy_apply_iface6 >/dev/null 2>&1; then
            policy_apply_iface6 "$vpn_dev" "$mark_hex" "$route_table_name" "$pref" || true
        else
            ip -6 route replace default dev "$vpn_dev" table "$route_table_name" 2>/dev/null || true
            while ip -6 rule del lookup "$route_table_name" pref "$pref" 2>/dev/null; do :; done
            while ip -6 rule del fwmark "$mark_hex" lookup "$route_table_name" 2>/dev/null; do :; done
            ip -6 rule add fwmark "$mark_hex" lookup "$route_table_name" pref "$pref" 2>/dev/null || true
        fi
    fi
}

case "$ACTION" in
    ifup|ifupdate)
EOF2
        printf '%s\n' "$ACTIVE_IFACES" | while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            load_work_iface_conf "$iface"
            printf '        if [ -n "${INTERFACE:-}" ] && [ "$INTERFACE" = "%s" ]; then\n' "$VPN_DEV"
            printf '            apply_one "%s" "%s" "%s" "%s" "%s" "%s" "%s"\n' "$VPN_DEV" "$MARK_HEX" "$ROUTE_TABLE_NAME" "$IP_RULE_PREF" "$AMNEZIAWG_PEER_SECTION" "$ROUTE_ALLOWED_IPS_DEFAULT" "$PERSISTENT_KEEPALIVE_DEFAULT"
            printf '        elif [ -n "${DEVICE:-}" ] && [ "$DEVICE" = "%s" ]; then\n' "$VPN_DEV"
            printf '            apply_one "%s" "%s" "%s" "%s" "%s" "%s" "%s"\n' "$VPN_DEV" "$MARK_HEX" "$ROUTE_TABLE_NAME" "$IP_RULE_PREF" "$AMNEZIAWG_PEER_SECTION" "$ROUTE_ALLOWED_IPS_DEFAULT" "$PERSISTENT_KEEPALIVE_DEFAULT"
            printf '        elif [ -z "${INTERFACE:-}" ] && [ -z "${DEVICE:-}" ]; then\n'
            printf '            apply_one "%s" "%s" "%s" "%s" "%s" "%s" "%s"\n' "$VPN_DEV" "$MARK_HEX" "$ROUTE_TABLE_NAME" "$IP_RULE_PREF" "$AMNEZIAWG_PEER_SECTION" "$ROUTE_ALLOWED_IPS_DEFAULT" "$PERSISTENT_KEEPALIVE_DEFAULT"
            printf '        fi\n'
        done
        cat <<'EOF2'
        ;;
esac
EOF2
    } > "$COMBINED_HOTPLUG_TMP"
    sed -i "s|__POLICY_ROUTING_LIB__|$POLICY_ROUTING_SH|g" "$COMBINED_HOTPLUG_TMP"
    chmod +x "$COMBINED_HOTPLUG_TMP"
}

ensure_firewall_include() {
    info "Проверяю firewall include"
    found=""
    while IFS= read -r s; do
        [ -n "$s" ] || continue
        path="$(uci -q get "$s.path" 2>/dev/null || true)"
        if [ "$path" = "$NFT_FILE" ]; then
            found="$s"
            break
        fi
    done <<EOF2
$(uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=include$/\1/p" || true)
EOF2

    if [ -z "$found" ]; then
        sec="$(uci add firewall include)"
        uci set firewall."$sec".type='nftables'
        uci set firewall."$sec".path="$NFT_FILE"
        uci set firewall."$sec".fw4_compatible='1'
        uci set firewall."$sec".enabled='1'
    else
        uci set "$found".type='nftables'
        uci set "$found".path="$NFT_FILE"
        uci set "$found".fw4_compatible='1'
        uci set "$found".enabled='1'
        uci -q delete "${found}.comment" || true
    fi
}

install_runtime() {
    info "Устанавливаю runtime-файлы"

    mkdir -p "$SYSTEM_DOMAIN_ROUTING_DIR" "$DNSMASQ_DIR" /etc/hotplug.d/iface

    cp -f "$COMBINED_DNSMASQ_TMP" "$DNSMASQ_FILE"
    rm -f "$DNSMASQ_DIR/90-xfree-toolbox-routing.conf" 2>/dev/null || true
    rm -f "$DNSMASQ_DIR/90-domain-routing.conf" 2>/dev/null || true
    cp -f "$COMBINED_NFT_TMP" "$NFT_FILE"
    rm -f "$SYSTEM_DOMAIN_ROUTING_DIR/90-domain-routing.nft" 2>/dev/null || true
    cp -f "$COMBINED_HOTPLUG_TMP" "$HOTPLUG_FILE"

    chmod 644 "$DNSMASQ_FILE" "$NFT_FILE"
    chmod +x "$HOTPLUG_FILE"
}

reload_runtime() {
    printf '%s\n' "$ACTIVE_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        ensure_iface_peer_options "$iface"
    done

    info "Коммичу UCI"
    uci commit dhcp
    uci commit firewall
    uci commit network

    info "Перезапускаю dnsmasq"
    refresh_target service dnsmasq stop-start
    if ! /etc/init.d/dnsmasq status >/dev/null 2>&1; then
        die "dnsmasq не запустился после применения runtime. Проверьте $DNSMASQ_FILE и поддержку nftset в dnsmasq."
    fi

    info "Мягко перечитываю network"
    if command -v reload_network_soft >/dev/null 2>&1; then
        reload_network_soft
    else
        /etc/init.d/network reload
    fi

    info "Перезапускаю firewall"
    purge_runtime_nft_objects
    refresh_target service firewall

    if [ -n "$ACTIVE_IFACES_REFRESH_ORDER" ]; then
        info "Порядок перезапуска интерфейсов (с учётом uplink-зависимостей):"
        printf '%s\n' "$ACTIVE_IFACES_REFRESH_ORDER" | sed 's/^/  - /'
    fi

    printf '%s\n' "${ACTIVE_IFACES_REFRESH_ORDER:-$ACTIVE_IFACES}" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        load_work_iface_conf "$iface"
        if ! uci -q get "network.$VPN_DEV" >/dev/null 2>&1; then
            warn "Пропускаю перезапуск $VPN_DEV: секция network.$VPN_DEV отсутствует (возможно, интерфейс удалён)"
            continue
        fi
        iface_disabled="$(uci -q get "network.$VPN_DEV.disabled" 2>/dev/null || true)"
        case "$iface_disabled" in
            1|true|on|yes)
                info "Пропускаю перезапуск интерфейса: $VPN_DEV (network.$VPN_DEV.disabled=$iface_disabled)"
                continue
                ;;
        esac
        info "Переподнимаю интерфейс $VPN_DEV"
        refresh_target interface "$VPN_DEV"
        if is_iface_ready4 "$VPN_DEV"; then
            info "Применяю policy routing IPv4 для $VPN_DEV"
            policy_apply_iface4 "$VPN_DEV" "$MARK_HEX" "$ROUTE_TABLE_NAME" "$IP_RULE_PREF"
        else
            warn "Интерфейс $VPN_DEV пока не готов по IPv4. Policy routing IPv4 применится через hotplug"
        fi

        if is_iface_ready6 "$VPN_DEV"; then
            info "Применяю policy routing IPv6 для $VPN_DEV"
            policy_apply_iface6 "$VPN_DEV" "$MARK_HEX" "$ROUTE_TABLE_NAME" "$IP_RULE_PREF"
        else
            warn "Интерфейс $VPN_DEV пока не готов по IPv6. Policy routing IPv6 применится через hotplug"
        fi
    done
}

refresh_self_route_runtime() {
    if [ ! -x "$SELF_ROUTE_APPLY_SCRIPT" ]; then
        warn "Self-route refresh пропущен: скрипт не найден или не исполняемый: $SELF_ROUTE_APPLY_SCRIPT"
        return 0
    fi

    # Не запускаем self-route hotplug refresh, если ни у одного iface нет SELF_ROUTE_VIA.
    has_self_route_via=0
    printf '%s\n' "$ALL_WORK_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        conf_file="$(work_iface_conf_of "$iface")"
        [ -f "$conf_file" ] || continue
        via_val="$(conf_value_from_file "$conf_file" "SELF_ROUTE_VIA" || true)"
        via_val="$(trim_var_local "${via_val:-}")"
        [ -n "$via_val" ] || continue
        printf '1\n'
        break
    done > "$TMP_ROOT/self-route-via.present"
    if [ -f "$TMP_ROOT/self-route-via.present" ]; then
        has_self_route_via="$(cat "$TMP_ROOT/self-route-via.present" 2>/dev/null || printf '0')"
    fi
    rm -f "$TMP_ROOT/self-route-via.present" 2>/dev/null || true
    if [ "$has_self_route_via" != "1" ]; then
        return 0
    fi

    info "Пересобираю self-route исключения после apply-routing"
    if ! "$SELF_ROUTE_APPLY_SCRIPT" --run-hotplug; then
        warn "Self-route hotplug refresh завершился с ошибкой (пропускаю, продолжаю)"
    fi
}

install_recovery_uplink_hotplug() {
    if [ ! -f "$RECOVERY_UPLINK_HOTPLUG_SCRIPT" ]; then
        return 0
    fi
    if [ ! -x "$RECOVERY_UPLINK_HOTPLUG_SCRIPT" ]; then
        chmod +x "$RECOVERY_UPLINK_HOTPLUG_SCRIPT" 2>/dev/null || true
    fi
    info "Устанавливаю hotplug recovery uplink (detect wan/wwan/lte ifup)"
    recovery_log="$TMP_ROOT/recovery-uplink-install.log"
    if ! "$RECOVERY_UPLINK_HOTPLUG_SCRIPT" --install >"$recovery_log" 2>&1; then
        warn "Recovery uplink hotplug install завершился с ошибкой (пропускаю, продолжаю)"
        if [ -s "$recovery_log" ]; then
            while IFS= read -r line; do
                [ -n "$line" ] || continue
                warn "recovery-uplink: $line"
            done < "$recovery_log"
        fi
        rm -f "$recovery_log" 2>/dev/null || true
        return 0
    fi
    if [ -s "$recovery_log" ]; then
        cat "$recovery_log"
    fi
    rm -f "$recovery_log" 2>/dev/null || true
}

main() {
    [ -d "$INTERFACES_DIR" ] || die "Каталог interfaces не найден: $INTERFACES_DIR"

    ALL_WORK_IFACES="$(list_work_interfaces || true)"

    if ! dnsmasq -v 2>/dev/null | grep -qi nftset; then
        die "dnsmasq не поддерживает nftset. Нужен dnsmasq-full с поддержкой nftset."
    fi

    mkdir -p "$SYSTEM_DOMAIN_ROUTING_DIR" "$SYSTEM_INTERFACES_DIR" "$SYSTEM_GENERATED_DIR" "$DNSMASQ_DIR" /etc/hotplug.d/iface "$BACKUP_ROOT"

    TMP_ROOT="$(mktemp -d)"
    COMBINED_DNSMASQ_TMP="$TMP_ROOT/90-xfree-toolbox-fqdn-routing.conf"
    COMBINED_NFT_TMP="$TMP_ROOT/90-xfree-toolbox-fqdn-routing.nft"
    COMBINED_HOTPLUG_TMP="$TMP_ROOT/90-xfree-toolbox-routing.hotplug"

    if [ -n "$ALL_WORK_IFACES" ]; then
        validate_all_iface_configs
        assert_unique_iface_values
    fi

    create_backup
    common_cleanup_domain_routing_owned "$ROUTE_TABLE_PREFIX" "$NFT_FILE" "$DNSMASQ_FILE" "$HOTPLUG_FILE" "$DNSMASQ_DIR" "$SYSTEM_GENERATED_DIR" "$SYSTEM_INTERFACES_DIR" "$ENABLE_LEGACY_CLEANUP"

    if [ -z "$ALL_WORK_IFACES" ]; then
        uci commit dhcp
        uci commit firewall
        uci commit network
        refresh_target service dnsmasq stop-start
        purge_runtime_nft_objects
        refresh_target service firewall
        success "Готово: интерфейсы отсутствуют, runtime очищен"
        exit 0
    fi

    printf '%s\n' "$ALL_WORK_IFACES" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        info "Пересобираю generated для iface=$iface"
        rebuild_generated_for_iface "$iface"
    done

    detect_active_ifaces
    build_active_iface_refresh_order
    print_interfaces_build_summary

    if [ -z "$ACTIVE_IFACES" ]; then
        sync_rt_tables_to_active_state
        uci commit dhcp
        uci commit firewall
        uci commit network
        refresh_target service dnsmasq stop-start
        purge_runtime_nft_objects
        refresh_target service firewall
        success "Готово: активных интерфейсов со списками нет, runtime очищен"
        exit 0
    fi

    ensure_dnsmasq_confdir
    build_combined_dnsmasq
    build_combined_nft
    build_combined_hotplug
    install_runtime
    ensure_firewall_include
    sync_rt_tables_to_active_state
    reload_runtime
    refresh_self_route_runtime
    install_recovery_uplink_hotplug

    trap - HUP QUIT PIPE

    success "Готово"
    echo
    echo "Активные интерфейсы:"
    printf '%s\n' "$ACTIVE_IFACES" | sed 's/^/  - /'
    print_runtime_summary
}

main "$@"
