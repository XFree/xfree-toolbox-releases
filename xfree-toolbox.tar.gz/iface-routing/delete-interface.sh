#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
UI_SH="$ROOT_DIR/lib/ui.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

[ -f "$UI_SH" ] && . "$UI_SH"
[ -f "$CONFIG_FILE" ] && . "$CONFIG_FILE"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
SYSTEM_DOMAIN_ROUTING_DIR="${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}"
SYSTEM_INTERFACES_DIR="${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}"
SYSTEM_GENERATED_DIR="${SYSTEM_GENERATED_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/interfaces}"
BACKUP_ROOT="${BACKUP_ROOT:-$(common_backup_root)}"
BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"
APPLY_ROUTING_SCRIPT="${APPLY_ROUTING_SCRIPT:-$ROOT_DIR/lib/apply-dns-and-iface-routing.sh}"
SELF_ROUTE_APPLY_SCRIPT="${SELF_ROUTE_APPLY_SCRIPT:-$SCRIPT_DIR/self-route/apply.sh}"

QUIET=0
IFACE_ARG=""
PURGE_FILES=0
FULL_RECONCILE=0
CLEANUP_ORPHANS=0
ROLLBACK_NEEDED=0
NETWORK_BACKUP=""
FIREWALL_BACKUP=""

usage() {
    cat <<EOF2
Usage:
  $(basename "$0") [options] [iface]

Options:
  -i, --iface NAME   Remove specific interface
  --purge-files      Also remove interface files/directories
  --full-reconcile   Run full iface-routing apply-routing after deletion
  --cleanup-orphans  After deletion run global orphan cleanup (self-route --cleanup)
  --quiet            Less output
  -h, --help         Show help

Behavior:
  - Removes network.<iface>
  - Removes all peer sections of type amneziawg_<iface>
  - Detaches <iface> from shared firewall zone 'vpn'
  - Keeps shared zone 'vpn' by default
  - Optionally removes interface directories from project/system storage
EOF2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        -i|--iface)
            shift
            [ "$#" -gt 0 ] || die "--iface requires NAME"
            IFACE_ARG="$1"
            ;;
        --purge-files)
            PURGE_FILES=1
            ;;
        --full-reconcile)
            FULL_RECONCILE=1
            ;;
        --cleanup-orphans)
            CLEANUP_ORPHANS=1
            ;;
        --quiet)
            QUIET=1
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            if [ -z "$IFACE_ARG" ]; then
                IFACE_ARG="$1"
            else
                die "Unexpected argument: $1"
            fi
            ;;
    esac
    shift || true
done

for cmd in uci awk sed grep mktemp basename dirname date cut find sort tr rm ip; do
    require_cmd "$cmd"
done

mkdir -p "$INTERFACES_DIR"

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

iface_dir_of() {
    printf '%s/%s\n' "$INTERFACES_DIR" "$1"
}

system_iface_dir_of() {
    printf '%s/%s\n' "$SYSTEM_INTERFACES_DIR" "$1"
}

generated_dir_of() {
    printf '%s/%s\n' "$SYSTEM_GENERATED_DIR" "$1"
}

iface_conf_of() {
    printf '%s/config/iface.conf\n' "$(iface_dir_of "$1")"
}

iface_conf_value() {
    conf="$1"
    key="$2"
    [ -f "$conf" ] || return 0
    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$conf"
}

is_known_iface() {
    iface="$1"
    [ -d "$(iface_dir_of "$iface")" ] || return 1
    [ -f "$(iface_conf_of "$iface")" ] || return 1
    return 0
}

list_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    find "$INTERFACES_DIR" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null | sort | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        is_known_iface "$iface" || continue
        printf '%s\n' "$iface"
    done
}

choose_interface_interactive() {
    tmp="$(mktemp)"
    trap 'rm -f "$tmp"' EXIT INT TERM
    list_interfaces > "$tmp"

    if [ ! -s "$tmp" ]; then
        die "Не найдено интерфейсов в $INTERFACES_DIR"
    fi

    if command -v ui_menu >/dev/null 2>&1; then
        set --
        while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            set -- "$@" "$iface" "remove"
        done < "$tmp"
        choice="$(ui_menu "Выбор интерфейса" "Выберите интерфейс для удаления" 20 100 10 "$@" || true)"
        [ -n "${choice:-}" ] || return 1
        printf '%s\n' "$choice"
    else
        nl -w2 -s') ' "$tmp" >&2
        printf 'Select interface: ' >&2
        IFS= read -r num || return 1
        case "$num" in
            ''|*[!0-9]*) die "Invalid selection: $num" ;;
        esac
        sed -n "${num}p" "$tmp"
    fi

    trap - EXIT INT TERM
    rm -f "$tmp"
}

save_backups() {
    # Backup policy: UCI rollback snapshot for this delete run; rotated by common_backup_rotate.
    NETWORK_BACKUP="$(common_backup_path iface-routing network.before.delete uci)"
    FIREWALL_BACKUP="$(common_backup_path iface-routing firewall.before.delete uci)"

    say "[*] Saving backups"
    uci export network > "$NETWORK_BACKUP"
    uci export firewall > "$FIREWALL_BACKUP"
    common_backup_rotate "$(dirname -- "$NETWORK_BACKUP")" "network.before.delete" "$BACKUP_KEEP"
    common_backup_rotate "$(dirname -- "$FIREWALL_BACKUP")" "firewall.before.delete" "$BACKUP_KEEP"
    ROLLBACK_NEEDED=1
}

safe_reload_after_rollback() {
    /etc/init.d/firewall reload >/dev/null 2>&1 || /etc/init.d/firewall restart >/dev/null 2>&1 || true
}

rollback() {
    [ "$ROLLBACK_NEEDED" = "1" ] || return 0

    warn "Error detected. Rolling back UCI config"

    if [ -f "$NETWORK_BACKUP" ]; then
        uci import network < "$NETWORK_BACKUP" || true
        uci commit network || true
    fi

    if [ -f "$FIREWALL_BACKUP" ]; then
        uci import firewall < "$FIREWALL_BACKUP" || true
        uci commit firewall || true
    fi

    safe_reload_after_rollback
}
trap rollback EXIT INT TERM

find_zone_by_name() {
    want="$1"

    if [ "$(uci -q get "firewall.$want" 2>/dev/null || true)" = "zone" ]; then
        printf 'firewall.%s\n' "$want"
        return 0
    fi

    { uci show firewall 2>/dev/null || true; } \
        | sed -n "s/^\(firewall\.[^.]*\)\.name='${want}'$/\1/p" \
        | head -n 1
}

remove_iface_from_zone_network() {
    zone_ref="$1"
    iface="$2"
    # Use del_list to avoid corrupting quoted list values.
    uci -q del_list "${zone_ref}.network=$iface" || true
}

delete_iface_network_sections() {
    iface="$1"
    peer_type="amneziawg_$iface"

    say "[*] Removing network interface: $iface"
    uci -q delete "network.$iface" || true

    refs="$({ uci show network 2>/dev/null || true; } | awk -F= -v t="$peer_type" '$2==t { sub(/^network\./, "", $1); print $1 }')"
    if [ -n "$refs" ]; then
        printf '%s\n' "$refs" | while IFS= read -r ref || [ -n "$ref" ]; do
            [ -n "$ref" ] || continue
            say "[*] Removing peer section: $ref"
            uci -q delete "network.$ref" || true
        done
    fi

    uci commit network
}

detach_from_shared_vpn_zone() {
    iface="$1"

    zone_ref="$(find_zone_by_name vpn || true)"
    if [ -z "$zone_ref" ]; then
        say "[*] Shared firewall zone vpn not found, nothing to detach"
        return 0
    fi

    say "[*] Detaching $iface from shared firewall zone: vpn"
    remove_iface_from_zone_network "$zone_ref" "$iface"
    uci commit firewall
}

bring_iface_down() {
    iface="$1"
    say "[*] Bringing interface down: $iface"
    ifdown "$iface" >/dev/null 2>&1 || true
}

reload_services() {
    iface="$1"

    info "Останавливаю интерфейс $iface и перечитываю network"
    refresh_target interface "$iface" ifdown-only
    refresh_target service network reload

    info "Перезапускаю firewall"
    refresh_target service firewall
}

cleanup_iface_policy_routing() {
    iface="$1"
    conf_file="$(iface_conf_of "$iface")"
    route_table_name="$(iface_conf_value "$conf_file" "ROUTE_TABLE_NAME" || true)"
    route_table_id="$(iface_conf_value "$conf_file" "ROUTE_TABLE_ID" || true)"
    mark_hex="$(iface_conf_value "$conf_file" "MARK_HEX" || true)"
    ip_rule_pref="$(iface_conf_value "$conf_file" "IP_RULE_PREF" || true)"

    [ -n "$route_table_name" ] || route_table_name="$iface"

    info "Очищаю policy routing для интерфейса $iface (table=$route_table_name)"
    if [ -n "$ip_rule_pref" ]; then
        while ip rule del lookup "$route_table_name" pref "$ip_rule_pref" 2>/dev/null; do :; done
        while ip -6 rule del lookup "$route_table_name" pref "$ip_rule_pref" 2>/dev/null; do :; done
    fi
    if [ -n "$mark_hex" ]; then
        while ip rule del fwmark "$mark_hex" lookup "$route_table_name" 2>/dev/null; do :; done
        while ip -6 rule del fwmark "$mark_hex" lookup "$route_table_name" 2>/dev/null; do :; done
    fi
    while ip rule del lookup "$route_table_name" 2>/dev/null; do :; done
    while ip -6 rule del lookup "$route_table_name" 2>/dev/null; do :; done

    ip route flush table "$route_table_name" 2>/dev/null || true
    ip -6 route flush table "$route_table_name" 2>/dev/null || true

    case "$route_table_id" in
        ''|*[!0-9]*) ;;
        *)
            ip route flush table "$route_table_id" 2>/dev/null || true
            ip -6 route flush table "$route_table_id" 2>/dev/null || true
            ;;
    esac
}

reconcile_routing_runtime_full() {
    if [ ! -x "$APPLY_ROUTING_SCRIPT" ]; then
        warn "Скрипт полной пересборки маршрутизации не найден или не исполняемый: $APPLY_ROUTING_SCRIPT"
        warn "Runtime может содержать хвосты маршрутизации"
        return 0
    fi

    info "Выполняю полную пересборку iface-routing runtime"
    "$APPLY_ROUTING_SCRIPT"
}

cleanup_orphans_if_requested() {
    [ "$CLEANUP_ORPHANS" = "1" ] || return 0
    if [ ! -x "$SELF_ROUTE_APPLY_SCRIPT" ]; then
        warn "Скрипт cleanup-orphans не найден или не исполняемый: $SELF_ROUTE_APPLY_SCRIPT"
        return 0
    fi
    info "Запускаю удаление сирот self-route (--cleanup)"
    "$SELF_ROUTE_APPLY_SCRIPT" --cleanup
}

purge_files() {
    iface="$1"

    proj_dir="$(iface_dir_of "$iface")"
    sys_dir="$(system_iface_dir_of "$iface")"
    gen_dir="$(generated_dir_of "$iface")"

    if [ -d "$proj_dir" ]; then
        say "[*] Removing project interface dir: $proj_dir"
        rm -rf "$proj_dir"
    fi

    if [ -d "$sys_dir" ]; then
        say "[*] Removing system interface dir: $sys_dir"
        rm -rf "$sys_dir"
    fi

    if [ -d "$gen_dir" ]; then
        say "[*] Removing generated dir: $gen_dir"
        rm -rf "$gen_dir"
    fi
}

show_result() {
    iface="$1"

    say "[*] Remaining network sections related to $iface:"
    uci show network | grep -E "(^network\.${iface}\.|^network\.${iface}=|=amneziawg_${iface}$)" || true

    say "[*] Remaining firewall config:"
    uci show firewall | grep -E "(^firewall\.[^.]+=zone$|^firewall\.[^.]+=forwarding$|\.name='vpn'$|\.src='lan'$|\.dest='vpn'$|\.network=)" || true
}

main() {
    iface="${IFACE_ARG:-}"
    if [ -z "$iface" ]; then
        iface="$(choose_interface_interactive || true)"
        [ -n "$iface" ] || exit 0
    fi

    iface="$(sanitize_name "$iface")"
    [ -n "$iface" ] || die "Имя интерфейса пустое"

    if ! is_known_iface "$iface"; then
        warn "Интерфейсный каталог не найден или неполон: $(iface_dir_of "$iface")"
        say "[*] Continuing with UCI cleanup for iface=$iface"
    fi

    if uci changes network | grep -q .; then
        warn "Uncommitted changes detected in 'network'"
        warn "Run: uci commit network  or  uci revert network"
        die "Refusing to delete interface over dirty UCI state"
    fi

    if uci changes firewall | grep -q .; then
        warn "Uncommitted changes detected in 'firewall'"
        warn "Run: uci commit firewall  or  uci revert firewall"
        die "Refusing to delete interface over dirty UCI state"
    fi

    say "[*] Deleting interface: $iface"
    save_backups
    bring_iface_down "$iface"
    cleanup_iface_policy_routing "$iface"
    delete_iface_network_sections "$iface"
    detach_from_shared_vpn_zone "$iface"
    reload_services "$iface"
    if [ "$FULL_RECONCILE" = "1" ]; then
        reconcile_routing_runtime_full
    fi
    cleanup_orphans_if_requested

    if [ "$PURGE_FILES" = "1" ]; then
        purge_files "$iface"
    fi

    ROLLBACK_NEEDED=0
    show_result "$iface"
    say "[*] Done."
}

main "$@"
