# shellcheck shell=sh

trim_var() {
    printf '%s' "$1" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//'
}

resolve_path_from() {
    base_dir="$1"
    target_path="$2"

    target_path="$(trim_var "$target_path")"

    case "$target_path" in
        '')
            printf '%s\n' "$target_path"
            ;;
        /*)
            printf '%s\n' "$target_path"
            ;;
        *)
            printf '%s\n' "$base_dir/$target_path"
            ;;
    esac
}

sanitize_iface_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
BASE_DIR="$(trim_var "$SCRIPT_DIR")"

[ -d "$BASE_DIR" ] || {
    echo "[!] BASE_DIR does not exist: $BASE_DIR" >&2
    exit 1
}

DNSMASQ_RESTART_SLEEP="${DNSMASQ_RESTART_SLEEP:-1}"

SYSTEM_DOMAIN_ROUTING_DIR="${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}"
DNSMASQ_DIR="${DNSMASQ_DIR:-/etc/dnsmasq.d/xfree-toolbox-routing}"
HOTPLUG_FILE="${HOTPLUG_FILE:-/etc/hotplug.d/iface/90-xfree-toolbox-routing}"
if command -v common_backup_root >/dev/null 2>&1; then
    BACKUP_ROOT="${BACKUP_ROOT:-$(common_backup_root)/iface-routing}"
    BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"
else
    BACKUP_ROOT="${BACKUP_ROOT:-$SYSTEM_DOMAIN_ROUTING_DIR/backup}"
    BACKUP_KEEP="${BACKUP_KEEP:-5}"
fi

CONF_DIR="${CONF_DIR:-$BASE_DIR/conf}"
if command -v common_profile_dir >/dev/null 2>&1; then
    PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
else
    PROFILE_DIR="${PROFILE_DIR:-$ROOT_DIR/profiles/${XFREE_PROFILE:-default}}"
fi
# ui.conf exports a relative INTERFACES_DIR (../profiles/default/...) that
# would otherwise stick via := after PROFILE_DIR is already resolved.
# Keep an absolute INTERFACES_DIR from apply-template / host materialize.
case "${INTERFACES_DIR:-}" in
    /*) ;;
    *) INTERFACES_DIR="$PROFILE_DIR/iface-routing/interfaces" ;;
esac

SYSTEM_INTERFACES_DIR="${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}"
SYSTEM_GENERATED_DIR="${SYSTEM_GENERATED_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/interfaces}"

DNSMASQ_FILE="${DNSMASQ_FILE:-$DNSMASQ_DIR/90-xfree-toolbox-fqdn-routing.conf}"
NFT_FILE="${NFT_FILE:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/90-xfree-toolbox-fqdn-routing.nft}"
