#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
UI_SH="$ROOT_DIR/lib/ui.sh"
IFACE_ORDER_SH="$SCRIPT_DIR/lib/iface-order.sh"
IFACE_STATE_SYNC_SH="$SCRIPT_DIR/lib/iface-state-sync.sh"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

[ -f "$UI_SH" ] && . "$UI_SH"
[ -f "$IFACE_ORDER_SH" ] || die "Не найден iface order lib: $IFACE_ORDER_SH"
. "$IFACE_ORDER_SH"
[ -f "$IFACE_STATE_SYNC_SH" ] || die "Не найден iface state sync lib: $IFACE_STATE_SYNC_SH"
. "$IFACE_STATE_SYNC_SH"

BACKUP_ROOT="${BACKUP_ROOT:-$(common_backup_root)}"
BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"
REGENERATE_SCRIPT="${REGENERATE_SCRIPT:-$SCRIPT_DIR/regenerate-interface-config.sh}"
SELF_ROUTE_APPLY_SCRIPT="${SELF_ROUTE_APPLY_SCRIPT:-$SCRIPT_DIR/self-route/apply.sh}"
QUIET=0
IFACE_ARG=""
APPLY_ALL=0
PROFILE_DIR_ARG="${PROFILE_DIR:-}"

ROLLBACK_NEEDED=0
NETWORK_BACKUP=""
FIREWALL_BACKUP=""

usage() {
    cat <<EOF2
Usage:
  $(basename "$0") [options] [iface]

Options:
  -i, --iface NAME   Apply specific interface
  --all              Apply all interfaces from profile
  --profile-dir DIR  Explicit profile directory (overrides active profile)
  --quiet            Less output
  -h, --help         Show help

Behavior:
  - Reads interface config from: interfaces/<iface>/config/
  - Applies network.uci for the selected interface
  - Ensures shared firewall zone 'vpn' and forwarding 'lan -> vpn'
  - Brings up the interface
EOF2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        -i|--iface)
            shift
            [ "$#" -gt 0 ] || die "--iface requires NAME"
            IFACE_ARG="$1"
            ;;
        --quiet)
            QUIET=1
            ;;
        --all)
            APPLY_ALL=1
            ;;
        --profile-dir)
            shift
            [ "$#" -gt 0 ] || die "--profile-dir requires DIR"
            PROFILE_DIR_ARG="$1"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            if [ -z "$IFACE_ARG" ]; then
                IFACE_ARG="$1"
            else
                die "Unexpected argument: $1"
            fi
            ;;
    esac
    shift || true
done

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "$PROFILE_DIR_ARG")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
SYSTEM_DOMAIN_ROUTING_DIR="${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}"
SYSTEM_INTERFACES_DIR="${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}"

for cmd in uci awk sed grep mktemp basename dirname date cut find sort tr; do
    require_cmd "$cmd"
done

mkdir -p "$INTERFACES_DIR"

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

iface_dir_of() {
    printf '%s/%s\n' "$INTERFACES_DIR" "$1"
}

iface_config_dir_of() {
    printf '%s/config\n' "$(iface_dir_of "$1")"
}

iface_conf_of() {
    printf '%s/iface.conf\n' "$(iface_config_dir_of "$1")"
}

iface_network_uci_of() {
    printf '%s/network.uci\n' "$(iface_config_dir_of "$1")"
}

iface_firewall_uci_of() {
    printf '%s/firewall.uci\n' "$(iface_config_dir_of "$1")"
}

iface_source_conf_of() {
    printf '%s/source.conf\n' "$(iface_config_dir_of "$1")"
}

iface_source_meta_of() {
    printf '%s/source.conf.meta\n' "$(iface_config_dir_of "$1")"
}

is_valid_iface_dir() {
    iface="$1"
    dir="$(iface_dir_of "$iface")"
    [ -d "$dir" ] || return 1
    [ -f "$(iface_conf_of "$iface")" ] || return 1
    [ -f "$(iface_network_uci_of "$iface")" ] || [ -f "$(iface_source_meta_of "$iface")" ] || return 1
    return 0
}

source_has_private_key() {
    file="$1"
    [ -f "$file" ] || return 1
    grep -q '^PrivateKey=' "$file" 2>/dev/null
}

maybe_regenerate_interface_config() {
    iface="$1"
    config_dir="$(iface_config_dir_of "$iface")"
    network_uci="$(iface_network_uci_of "$iface")"
    source_conf="$(iface_source_conf_of "$iface")"
    source_meta="$(iface_source_meta_of "$iface")"
    template_marker="$config_dir/TEMPLATE"

    [ -f "$source_meta" ] || return 0
    # Auto-regeneration is intended only for template interfaces.
    [ -f "$template_marker" ] || return 0

    if [ -f "$network_uci" ] && source_has_private_key "$source_conf"; then
        return 0
    fi

    [ -f "$REGENERATE_SCRIPT" ] || die "Для восстановления отсутствует regenerate script: $REGENERATE_SCRIPT"
    info "Отсутствует конфигурация интерфейса $iface, генерация из метаданных (source.conf.meta)..."
    gen_kind="$(sed -n "s/^GENERATOR_KIND='\\(.*\\)'\$/\\1/p" "$source_meta" 2>/dev/null || true)"
    case "$gen_kind" in
        proton)
            common_wait_network_after_restart "${XFREE_NETWORK_WAIT_SEC:-90}" account.protonvpn.com https || \
                warn "HTTPS account.protonvpn.com не готов — Proton guest может не создаться"
            ;;
        warp)
            common_wait_network_after_restart "${XFREE_NETWORK_WAIT_SEC:-90}" api.cloudflareclient.com https || \
                warn "HTTPS api.cloudflareclient.com не готов — WARP register может не пройти"
            ;;
    esac
    "$REGENERATE_SCRIPT" --iface "$iface"
}

list_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    common_list_domain_interfaces "$INTERFACES_DIR" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        is_valid_iface_dir "$iface" || continue
        printf '%s\n' "$iface"
    done
}

iface_upstream_dep() {
    iface="$1"
    cfg="$(iface_conf_of "$iface")"
    iface_upstream_dep_from_conf "$cfg"
}

choose_interface_interactive() {
    ui_domain_iface_select \
        --dir "$INTERFACES_DIR" \
        --title "Выбор интерфейса" \
        --prompt "Выберите интерфейс для применения" \
        --item-desc "config" \
        --filter-cmd is_valid_iface_dir \
        --empty-die
}

save_backups() {
    # Backup policy: UCI rollback snapshot for this apply run; rotated by common_backup_rotate.
    NETWORK_BACKUP="$(common_backup_path iface-routing network.before uci)"
    FIREWALL_BACKUP="$(common_backup_path iface-routing firewall.before uci)"

    say "[*] Saving backups"
    uci export network > "$NETWORK_BACKUP"
    uci export firewall > "$FIREWALL_BACKUP"
    common_backup_rotate "$(dirname -- "$NETWORK_BACKUP")" "network.before" "$BACKUP_KEEP"
    common_backup_rotate "$(dirname -- "$FIREWALL_BACKUP")" "firewall.before" "$BACKUP_KEEP"
    ROLLBACK_NEEDED=1
}

safe_reload_after_rollback() {
    /etc/init.d/firewall reload >/dev/null 2>&1 || /etc/init.d/firewall restart >/dev/null 2>&1 || true
}

rollback() {
    [ "$ROLLBACK_NEEDED" = "1" ] || return 0

    warn "Error detected. Rolling back UCI config"

    if [ -f "$NETWORK_BACKUP" ]; then
        uci import network < "$NETWORK_BACKUP" || true
        uci commit network || true
    fi

    if [ -f "$FIREWALL_BACKUP" ]; then
        uci import firewall < "$FIREWALL_BACKUP" || true
        uci commit firewall || true
    fi

    safe_reload_after_rollback
}
trap rollback EXIT INT TERM

delete_iface_network_sections() {
    iface="$1"
    peer_type="amneziawg_$iface"

    say "[*] Removing old managed sections for iface=$iface"
    uci -q delete "network.$iface" || true
    uci -q delete "openvpn.$iface" || true
    rm -f "/etc/xfree-toolbox/iface-routing/vless/$iface.json" 2>/dev/null || true
    if [ -x "/etc/init.d/xfree-singbox" ]; then
        /etc/init.d/xfree-singbox restart >/dev/null 2>&1 || true
    fi

    refs="$({ uci show network 2>/dev/null || true; } | awk -F= -v t="$peer_type" '$2==t { sub(/^network\./, "", $1); print $1 }')"
    if [ -n "$refs" ]; then
        printf '%s\n' "$refs" | while IFS= read -r ref || [ -n "$ref" ]; do
            [ -n "$ref" ] || continue
            say "[*] Removing peer section: $ref"
            uci -q delete "network.$ref" || true
        done
    fi

    uci commit network
    uci commit openvpn 2>/dev/null || true
}

apply_openvpn_profile() {
    iface="$1"
    iface_dir="$2"
    openvpn_uci="$iface_dir/config/openvpn.uci"
    client_ovpn="$iface_dir/config/client.ovpn"
    cred_env="$iface_dir/config/credentials.env"
    totp_script="$SCRIPT_DIR/vpn/openvpn/totp-gen.sh"

    [ -f "$openvpn_uci" ] || return 0
    [ -f "$client_ovpn" ] || return 0

    runtime_ovpn_dir="/etc/xfree-toolbox/iface-routing/openvpn"
    mkdir -p "$runtime_ovpn_dir"
    cp -f "$client_ovpn" "$runtime_ovpn_dir/$iface.ovpn"
    chmod 600 "$runtime_ovpn_dir/$iface.ovpn" 2>/dev/null || true

    if [ -f "$cred_env" ]; then
        cp -f "$cred_env" "$runtime_ovpn_dir/$iface.env"
        chmod 600 "$runtime_ovpn_dir/$iface.env" 2>/dev/null || true

        totp_script="$SCRIPT_DIR/vpn/openvpn/totp-gen.sh"
        if [ -f "$totp_script" ]; then
            cp -f "$totp_script" "$runtime_ovpn_dir/totp-gen.sh"
            chmod +x "$runtime_ovpn_dir/totp-gen.sh" 2>/dev/null || true
        fi

        refresh_script="$SCRIPT_DIR/vpn/openvpn/refresh-auth.sh"
        if [ -f "$refresh_script" ]; then
            cp -f "$refresh_script" "$runtime_ovpn_dir/refresh-auth.sh"
            chmod +x "$runtime_ovpn_dir/refresh-auth.sh" 2>/dev/null || true
            "$runtime_ovpn_dir/refresh-auth.sh" "$iface" >/dev/null 2>&1 || true
        fi
    fi

    runner_script="$SCRIPT_DIR/vpn/openvpn/openvpn-runner.sh"
    if [ -f "$runner_script" ]; then
        cp -f "$runner_script" "$runtime_ovpn_dir/openvpn-runner.sh"
        chmod +x "$runtime_ovpn_dir/openvpn-runner.sh" 2>/dev/null || true
        if [ -f "/etc/init.d/openvpn" ] && ! grep -q "openvpn-runner.sh" /etc/init.d/openvpn; then
            sed -i "s|^PROG=/usr/sbin/openvpn|PROG=/usr/sbin/openvpn\n[ -x $runtime_ovpn_dir/openvpn-runner.sh ] \&\& PROG=$runtime_ovpn_dir/openvpn-runner.sh|" /etc/init.d/openvpn
        fi
    fi

    # Ensure lifecycle library is present in system runtime directory
    if [ -f "$SCRIPT_DIR/lib/iface-lifecycle.sh" ]; then
        mkdir -p /etc/xfree-toolbox/iface-routing/lib
        cp -f "$SCRIPT_DIR/lib/iface-lifecycle.sh" /etc/xfree-toolbox/iface-routing/lib/iface-lifecycle.sh
        chmod 644 /etc/xfree-toolbox/iface-routing/lib/iface-lifecycle.sh 2>/dev/null || true
    fi

    say "[*] Merging OpenVPN profile for $iface"
    uci -m import openvpn < "$openvpn_uci"
    uci commit openvpn
}

apply_vless_profile() {
    iface="$1"
    iface_dir="$2"
    singbox_json="$iface_dir/config/singbox.json"

    [ -f "$singbox_json" ] || return 0

    runtime_vless_dir="/etc/xfree-toolbox/iface-routing/vless"
    mkdir -p "$runtime_vless_dir"
    cp -f "$singbox_json" "$runtime_vless_dir/$iface.json"
    chmod 600 "$runtime_vless_dir/$iface.json" 2>/dev/null || true

    init_tmpl="$SCRIPT_DIR/vpn/vless/xfree-singbox.init"
    if [ -f "$init_tmpl" ]; then
        if [ ! -f "/etc/init.d/xfree-singbox" ] || ! cmp -s "$init_tmpl" "/etc/init.d/xfree-singbox"; then
            cp -f "$init_tmpl" /etc/init.d/xfree-singbox
            chmod 755 /etc/init.d/xfree-singbox 2>/dev/null || true
        fi
        /etc/init.d/xfree-singbox enable >/dev/null 2>&1 || true
        say "[*] Starting/restarting sing-box for $iface..."
        /etc/init.d/xfree-singbox restart >/dev/null 2>&1 || true
    fi

    # sing-box TUN inbound requires firewall rule to accept local loop traffic from tun device
    tun_dev="$(awk -F= '$1=="VPN_DEV"{gsub(/[ \047"]/,"",$2); print $2}' "$iface_dir/config/iface.conf" 2>/dev/null || true)"
    if [ -n "$tun_dev" ]; then
        rule_name="allow_singbox_tun_${iface}"
        if [ "$(uci -q get "firewall.$rule_name" 2>/dev/null || true)" != "rule" ]; then
            say "[*] Adding firewall rule for sing-box tun: $tun_dev"
            uci set "firewall.$rule_name=rule"
            uci set "firewall.$rule_name.name=Allow-singbox-tun-$iface"
            uci set "firewall.$rule_name.src=vpn"
            uci set "firewall.$rule_name.device=$tun_dev"
            uci set "firewall.$rule_name.target=ACCEPT"
            uci commit firewall
            FIREWALL_ZONE_CHANGED=1
        fi
    fi
}

apply_network_profile() {
    network_uci="$1"
    say "[*] Merging network profile"
    uci -m import network < "$network_uci"
    uci commit network
}

find_zone_by_name() {
    want="$1"

    if [ "$(uci -q get "firewall.$want" 2>/dev/null || true)" = "zone" ]; then
        printf 'firewall.%s\n' "$want"
        return 0
    fi

    { uci show firewall 2>/dev/null || true; } \
        | sed -n "s/^\(firewall\.[^.]*\)\.name='${want}'$/\1/p" \
        | head -n 1
}

find_forwarding_section() {
    src="$1"
    dest="$2"
    for sec in $(uci show firewall 2>/dev/null | sed -n 's/^\(firewall\.[^.]*\)=forwarding$/\1/p'); do
        fsrc="$(uci -q get "${sec}.src" 2>/dev/null || true)"
        fdest="$(uci -q get "${sec}.dest" 2>/dev/null || true)"
        if [ "$fsrc" = "$src" ] && [ "$fdest" = "$dest" ]; then
            printf '%s\n' "$sec"
            return 0
        fi
    done
    return 1
}

ensure_zone_network_member() {
    zone_ref="$1"
    iface="$2"

    current="$(uci -q get "${zone_ref}.network" 2>/dev/null || true)"
    printf '%s\n' "$current" | tr ' ' '\n' | grep -Fx "$iface" >/dev/null 2>&1 && return 0
    uci add_list "${zone_ref}.network=$iface"
}

normalize_zone_network_members() {
    zone_ref="$1"
    current="$(uci -q get "${zone_ref}.network" 2>/dev/null || true)"
    [ -n "$current" ] || return 0

    set +u
    eval "set -- $current"
    set -u

    normalized=""
    for token in "$@"; do
        [ -n "${token:-}" ] || continue
        # Historic broken values may contain multiple iface names in one token.
        for part in $(printf '%s\n' "$token"); do
            [ -n "$part" ] || continue
            case " $normalized " in
                *" $part "*) ;;
                *) normalized="${normalized:+$normalized }$part" ;;
            esac
        done
    done

    [ -n "$normalized" ] || {
        uci -q delete "${zone_ref}.network" || true
        return 0
    }

    uci -q delete "${zone_ref}.network" || true
    for member in $normalized; do
        uci add_list "${zone_ref}.network=$member"
    done
}

ensure_shared_vpn_zone() {
    iface="$1"

    common_firewall_dedupe_zones_by_name
    common_firewall_dedupe_forwardings

    zone_ref="$(find_zone_by_name vpn || true)"
    if [ -z "$zone_ref" ]; then
        say "[*] Creating shared firewall zone: vpn"
        uci set firewall.vpn=zone
        uci set firewall.vpn.name=vpn
        uci set firewall.vpn.input=REJECT
        uci set firewall.vpn.output=ACCEPT
        uci set firewall.vpn.forward=REJECT
        uci set firewall.vpn.masq=1
        uci set firewall.vpn.masq6=1
        uci set firewall.vpn.mtu_fix=1
        zone_ref='firewall.vpn'
    else
        say "[*] Reusing shared firewall zone: vpn"
        uci set "${zone_ref}.name=vpn"
        [ -n "$(uci -q get "${zone_ref}.input" 2>/dev/null || true)" ] || uci set "${zone_ref}.input=REJECT"
        [ -n "$(uci -q get "${zone_ref}.output" 2>/dev/null || true)" ] || uci set "${zone_ref}.output=ACCEPT"
        [ -n "$(uci -q get "${zone_ref}.forward" 2>/dev/null || true)" ] || uci set "${zone_ref}.forward=REJECT"
        [ -n "$(uci -q get "${zone_ref}.masq" 2>/dev/null || true)" ] || uci set "${zone_ref}.masq=1"
        [ -n "$(uci -q get "${zone_ref}.masq6" 2>/dev/null || true)" ] || uci set "${zone_ref}.masq6=1"
        [ -n "$(uci -q get "${zone_ref}.mtu_fix" 2>/dev/null || true)" ] || uci set "${zone_ref}.mtu_fix=1"
    fi

    normalize_zone_network_members "$zone_ref"
    ensure_zone_network_member "$zone_ref" "$iface"

    fwd_ref="$(find_forwarding_section lan vpn || true)"
    if [ -z "$fwd_ref" ]; then
        say "[*] Creating forwarding lan -> vpn"
        uci set firewall.lan_to_vpn=forwarding
        uci set firewall.lan_to_vpn.src=lan
        uci set firewall.lan_to_vpn.dest=vpn
    fi

    FIREWALL_ZONE_CHANGED=0
    if uci changes firewall | grep -q .; then
        FIREWALL_ZONE_CHANGED=1
        uci commit firewall
    fi
}

get_target_peer_public_key() {
    awk -F "'" '$0 ~ /^[[:space:]]*option public_key / { print $2; exit }' "$1"
}

get_target_peer_endpoint_host() {
    awk -F "'" '$0 ~ /^[[:space:]]*option endpoint_host / { print $2; exit }' "$1"
}

get_target_peer_endpoint_port() {
    awk -F "'" '$0 ~ /^[[:space:]]*option endpoint_port / { print $2; exit }' "$1"
}

validate_post_state() {
    iface="$1"
    network_uci="$2"
    iface_proto="$(uci -q get "network.$iface.proto" 2>/dev/null || true)"

    if [ "$iface_proto" = "amneziawg" ]; then
        peer_type="amneziawg_$iface"
        target_pk="$(get_target_peer_public_key "$network_uci")"
        target_host="$(get_target_peer_endpoint_host "$network_uci")"
        target_port="$(get_target_peer_endpoint_port "$network_uci")"
        found_count=0

        refs="$({ uci show network 2>/dev/null || true; } | awk -F= -v t="$peer_type" '$2==t { sub(/^network\./, "", $1); print $1 }')"
        if [ -n "$refs" ]; then
            for ref in $refs; do
                [ -n "$ref" ] || continue
                current_pk="$(uci -q get "network.${ref}.public_key" 2>/dev/null || true)"
                current_host="$(uci -q get "network.${ref}.endpoint_host" 2>/dev/null || true)"
                current_port="$(uci -q get "network.${ref}.endpoint_port" 2>/dev/null || true)"
                if [ "$current_pk" = "$target_pk" ] && [ "$current_host" = "$target_host" ] && [ "$current_port" = "$target_port" ]; then
                    found_count=$((found_count + 1))
                fi
            done
        fi

        [ "$found_count" -eq 1 ] || die "Expected exactly one matching $peer_type peer after apply, got: $found_count"
    elif [ "$iface_proto" = "none" ] || [ "$iface_proto" = "unmanaged" ]; then
        vpn_proto="$(awk -F= '$1=="VPN_PROTO"{gsub(/[\047"]/,"",$2); print $2}' "$(iface_conf_of "$iface")" 2>/dev/null || true)"
        if [ "$vpn_proto" = "vless" ]; then
            [ -f "/etc/xfree-toolbox/iface-routing/vless/$iface.json" ] || warn "sing-box config missing for $iface"
        else
            # OpenVPN / TUN unmanaged interface
            [ "$(uci -q get "openvpn.$iface.enabled" 2>/dev/null || true)" = "1" ] || warn "openvpn.$iface is not enabled in /etc/config/openvpn"
        fi
    else
        die "network.$iface.proto is invalid: $iface_proto"
    fi

    zone_ref="$(find_zone_by_name vpn || true)"
    [ -n "$zone_ref" ] || die "Firewall zone 'vpn' is missing after apply"

    zone_networks="$(uci -q get "${zone_ref}.network" 2>/dev/null || true)"
    printf '%s\n' "$zone_networks" | tr ' ' '\n' | grep -Fx "$iface" >/dev/null 2>&1 || die "Interface $iface is not attached to zone vpn"
}

reload_services() {
    iface="$1"
    firewall_changed="${2:-0}"

    if [ "$firewall_changed" = "1" ]; then
        info "Перезагрузка подсистемы firewall..."
        refresh_target service firewall reload
    else
        info "Конфигурация firewall не изменялась, перезагрузка пропущена"
    fi

    info "Применение параметров network..."
    refresh_target service network reload

    iface_proto="$(uci -q get "network.$iface.proto" 2>/dev/null || true)"
    if [ "$iface_proto" = "none" ] || [ "$iface_proto" = "unmanaged" ]; then
        info "Запуск интерфейса $iface (proto=$iface_proto)..."
        ifup "$iface" >/dev/null 2>&1 || true
    else
        info "Перезапуск интерфейса $iface..."
        refresh_target interface "$iface"
    fi

    if [ -f "/etc/config/openvpn" ] && [ "$(uci -q get "openvpn.$iface.enabled" 2>/dev/null || true)" = "1" ]; then
        if [ -x "/etc/xfree-toolbox/iface-routing/openvpn/refresh-auth.sh" ]; then
            /etc/xfree-toolbox/iface-routing/openvpn/refresh-auth.sh "$iface" >/dev/null 2>&1 || true
        fi
        info "Перезапуск openvpn ($iface)..."
        /etc/init.d/openvpn enable >/dev/null 2>&1 || true
        /etc/init.d/openvpn restart "$iface" >/dev/null 2>&1 || true
    fi
}

refresh_self_route_runtime() {
    if [ ! -x "$SELF_ROUTE_APPLY_SCRIPT" ]; then
        warn "Self-route refresh пропущен: скрипт не найден или не исполняемый: $SELF_ROUTE_APPLY_SCRIPT"
        return 0
    fi

    info "Очистка устаревших маршрутов self-route..."
    if ! "$SELF_ROUTE_APPLY_SCRIPT" --cleanup; then
        warn "Self-route cleanup завершился с ошибкой (пропускаю, продолжаю)"
    fi

    info "Обновление маршрутов self-route (hotplug)..."
    if ! "$SELF_ROUTE_APPLY_SCRIPT" --run-hotplug; then
        warn "Self-route hotplug refresh завершился с ошибкой (пропускаю, продолжаю)"
    fi
}

show_result() {
    iface="$1"
    say "[*] Resulting network config for $iface:"
    uci show network | grep -E "(^network\.${iface}\.|^network\.${iface}=|=amneziawg_${iface}$|^network\.[^.]+\.(description|public_key|endpoint_host|endpoint_port|route_allowed_ips|persistent_keepalive|allowed_ips)=)" || true

    say "[*] Resulting firewall config:"
    uci show firewall | grep -E "(^firewall\.[^.]+=zone$|^firewall\.[^.]+=forwarding$|\.name='vpn'$|\.src='lan'$|\.dest='vpn'$|\.network=)" || true
}

snapshot_iface_network_uci() {
    _snap_iface="$1"
    { uci show network 2>/dev/null || true; } \
        | grep -E "^network\.${_snap_iface}(\.|=)|^network\.@amneziawg_${_snap_iface}\[|^network\.[^.]*=amneziawg_${_snap_iface}$" \
        | sort || true
}

apply_single_interface() {
    iface="$1"
    post_runtime="${2:-1}"
    changed_dir="${3:-}"
    [ -n "$iface" ] || die "Имя интерфейса пустое"
    iface="$(sanitize_name "$iface")"
    if [ -z "$iface" ]; then
        die "Имя интерфейса пустое после sanitize"
    fi

    is_valid_iface_dir "$iface" || die "Некорректный каталог интерфейса: $(iface_dir_of "$iface")"

    iface_dir="$(iface_dir_of "$iface")"
    maybe_regenerate_interface_config "$iface"
    network_uci="$(iface_network_uci_of "$iface")"
    firewall_uci="$(iface_firewall_uci_of "$iface")"

    [ -f "$network_uci" ] || die "Missing file: $network_uci"
    [ -f "$firewall_uci" ] || warn "Missing file (continuing): $firewall_uci"

    say "[*] Applying interface: $iface"
    say "[*] Interface dir    : $iface_dir"

    if uci changes network | grep -q .; then
        warn "Uncommitted changes detected in 'network'"
        warn "Run: uci commit network  or  uci revert network"
        die "Refusing to apply interface over dirty UCI state"
    fi

    if uci changes firewall | grep -q .; then
        warn "Uncommitted changes detected in 'firewall'"
        warn "Run: uci commit firewall  or  uci revert firewall"
        die "Refusing to apply interface over dirty UCI state"
    fi

    net_snap_before="$(snapshot_iface_network_uci "$iface")"
    save_backups
    delete_iface_network_sections "$iface"
    apply_network_profile "$network_uci"
    apply_openvpn_profile "$iface" "$iface_dir"
    apply_vless_profile "$iface" "$iface_dir"
    net_snap_after="$(snapshot_iface_network_uci "$iface")"
    NETWORK_CONFIG_CHANGED=0
    if [ "$net_snap_before" != "$net_snap_after" ]; then
        NETWORK_CONFIG_CHANGED=1
    fi
    FIREWALL_ZONE_CHANGED=0
    ensure_shared_vpn_zone "$iface"
    validate_post_state "$iface" "$network_uci"
    info "Синхронизация конфигурации $iface в рабочее состояние..."
    iface_state_sync_config_from_work "$iface" "$INTERFACES_DIR" "$SYSTEM_INTERFACES_DIR"
    if [ -n "$changed_dir" ] && [ -d "$changed_dir" ]; then
        [ "$NETWORK_CONFIG_CHANGED" = "1" ] && : > "$changed_dir/$iface.net"
        [ "$FIREWALL_ZONE_CHANGED" = "1" ] && : > "$changed_dir/$iface.fw"
    fi
    if [ "$post_runtime" = "1" ]; then
        reload_services "$iface" "$FIREWALL_ZONE_CHANGED"
        refresh_self_route_runtime
    fi

    ROLLBACK_NEEDED=0
    show_result "$iface"
    say "[*] Done."
}

main() {
    if [ "$APPLY_ALL" = "1" ] && [ -n "${IFACE_ARG:-}" ]; then
        die "Нельзя одновременно использовать --all и --iface"
    fi

    if [ "$APPLY_ALL" = "1" ]; then
        lines="$(list_interfaces || true)"
        if [ -z "${lines:-}" ]; then
            warn "Не найдено валидных интерфейсов в $INTERFACES_DIR, шаг apply-interfaces пропущен"
            return 0
        fi
        lines="$(iface_build_order_by_dependency "$lines" iface_upstream_dep)"
        info "Applying all interfaces from profile (with uplink dependency order)"
        printf '%s\n' "$lines" | while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            info " - $iface"
        done
        applied_ifaces=""
        failed_ifaces=""
        changed_dir="$(mktemp -d "${TMPDIR:-/tmp}/xfree-apply-ifaces-changed.XXXXXX")"
        while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            info "=== Applying interface: $iface ==="
            # Subshell: regenerate/die must not abort remaining ifaces (WARP after Proton).
            if ( apply_single_interface "$iface" 0 "$changed_dir" ); then
                applied_ifaces="${applied_ifaces:+$applied_ifaces }$iface"
            else
                warn "Не удалось применить интерфейс $iface — продолжаю остальные"
                failed_ifaces="${failed_ifaces:+$failed_ifaces }$iface"
            fi
        done <<EOF
$lines
EOF
        fw_any_changed=0
        net_any_changed=0
        for _f in "$changed_dir"/*.fw; do
            [ -e "$_f" ] && fw_any_changed=1 && break
        done
        for _f in "$changed_dir"/*.net; do
            [ -e "$_f" ] && net_any_changed=1 && break
        done
        if [ "$fw_any_changed" = "1" ]; then
            info "Итоговая перезагрузка firewall..."
            refresh_target service firewall reload
        else
            info "Конфигурация firewall не изменялась, перезагрузка пропущена"
        fi
        if [ "$net_any_changed" = "1" ]; then
            info "Итоговое применение параметров network..."
            refresh_target service network reload
        else
            info "Параметры network не изменялись, перезагрузка пропущена"
        fi
        for iface in $applied_ifaces; do
            [ -n "$iface" ] || continue
            if [ ! -f "$changed_dir/$iface.net" ] && [ ! -f "$changed_dir/$iface.fw" ]; then
                info "Конфигурация интерфейса $iface не изменялась — перезапуск пропущен"
                continue
            fi
            iface_proto="$(uci -q get "network.$iface.proto" 2>/dev/null || true)"
            if [ "$iface_proto" = "none" ] || [ "$iface_proto" = "unmanaged" ]; then
                info "Запуск интерфейса $iface (proto=$iface_proto)..."
                ifup "$iface" >/dev/null 2>&1 || true
            else
                info "Перезапуск интерфейса $iface..."
                refresh_target interface "$iface"
            fi
        done
        rm -rf "$changed_dir" 2>/dev/null || true
        refresh_self_route_runtime
        if [ -n "$failed_ifaces" ]; then
            die "Не удалось применить интерфейсы:$failed_ifaces"
        fi
        return 0
    fi

    iface="${IFACE_ARG:-}"
    if [ -z "$iface" ]; then
        iface="$(choose_interface_interactive || true)"
        [ -n "$iface" ] || exit 0
    fi

    apply_single_interface "$iface" 1
}

main "$@"
