#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
COMMON_SH="$ROOT_DIR/lib/common.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-$SCRIPT_DIR/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"
[ -f "$CONFIG_FILE" ] && . "$CONFIG_FILE" || true

require_cmd_local() {
    cmd="$1"
    command -v "$cmd" >/dev/null 2>&1 || die "Не найдена команда: $cmd"
}

trim() { printf '%s' "$1" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//'; }
sanitize_name() { printf '%s' "$1" | tr -cd 'A-Za-z0-9._-'; }

MODE="scan"
TARGETS="all"
DELETE_RT_TABLES=0
DELETE_RUNTIME=0

while [ "$#" -gt 0 ]; do
    case "$1" in
        --scan) MODE="scan" ;;
        --clean) MODE="clean" ;;
        --targets)
            shift
            [ "$#" -gt 0 ] || die "--targets requires value"
            TARGETS="$1"
            ;;
        --delete-rt-tables) DELETE_RT_TABLES=1 ;;
        --delete-runtime) DELETE_RUNTIME=1 ;;
        -h|--help)
            cat <<EOF2
Usage:
  $(basename "$0") --scan [--targets all|orphan|legacy]
  $(basename "$0") --clean [--targets all|orphan|legacy] [--delete-rt-tables] [--delete-runtime]
EOF2
            exit 0
            ;;
        *) die "Unexpected argument: $1" ;;
    esac
    shift || true
done

for cmd in awk cat find grep ip nft sed sort uniq wc cut tr basename dirname; do
    require_cmd_local "$cmd"
done

BASE_DIR="$(trim "${BASE_DIR:-$SCRIPT_DIR}")"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="$(trim "${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}")"
SYSTEM_DOMAIN_ROUTING_DIR="$(trim "${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}")"
DNSMASQ_DIR="$(trim "${DNSMASQ_DIR:-/etc/dnsmasq.d/xfree-toolbox-routing}")"
DNSMASQ_FILE="$(trim "${DNSMASQ_FILE:-$DNSMASQ_DIR/90-xfree-toolbox-fqdn-routing.conf}")"
NFT_FILE="$(trim "${NFT_FILE:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/90-xfree-toolbox-fqdn-routing.nft}")"
HOTPLUG_FILE="$(trim "${HOTPLUG_FILE:-/etc/hotplug.d/iface/90-xfree-toolbox-routing}")"
RT_TABLES_FILE="/etc/iproute2/rt_tables"

TMP_ROOT="$(mktemp -d)"
trap 'rm -rf "$TMP_ROOT" 2>/dev/null || true' EXIT INT TERM

ACT_IFACES="$TMP_ROOT/interfaces.tsv"
ACT_MARKS="$TMP_ROOT/marks.lst"
ACT_TABLE_NAMES="$TMP_ROOT/table_names.lst"
ACT_TABLE_IDS="$TMP_ROOT/table_ids.lst"
ACT_PREFS="$TMP_ROOT/prefs.lst"
ACT_NFT_NAMES="$TMP_ROOT/nft_names.lst"
OWNED_KEYS="$TMP_ROOT/owned_keys.lst"
CAND_RULES="$TMP_ROOT/candidate_rules.tsv"
CAND_TABLES="$TMP_ROOT/candidate_tables.tsv"
CAND_ROUTES="$TMP_ROOT/candidate_routes.tsv"
CAND_RUNTIME="$TMP_ROOT/candidate_runtime.tsv"
CAND_NFT="$TMP_ROOT/candidate_nft.tsv"

: > "$ACT_IFACES"
: > "$ACT_MARKS"
: > "$ACT_TABLE_NAMES"
: > "$ACT_TABLE_IDS"
: > "$ACT_PREFS"
: > "$ACT_NFT_NAMES"
: > "$OWNED_KEYS"
: > "$CAND_RULES"
: > "$CAND_TABLES"
: > "$CAND_ROUTES"
: > "$CAND_RUNTIME"
: > "$CAND_NFT"

list_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    find "$INTERFACES_DIR" -type f -path '*/config/iface.conf' 2>/dev/null | sed "s|$INTERFACES_DIR/||" | sed 's|/config/iface.conf$||' | sed '/^$/d' | sort -u
}

load_iface_conf_print() {
    iface="$1"
    conf_file="$INTERFACES_DIR/$iface/config/iface.conf"
    [ -f "$conf_file" ] || return 1

    INTERFACE_NAME=''
    VPN_DEV=''
    MARK_HEX=''
    ROUTE_TABLE_ID=''
    ROUTE_TABLE_NAME=''
    IP_RULE_PREF=''
    NFT_FQDN_SET_NAME=''
    NFT_PREFIX_SET_NAME=''
    NFT_FQDN4_SET_NAME=''
    NFT_FQDN6_SET_NAME=''
    NFT_PREFIX4_SET_NAME=''
    NFT_PREFIX6_SET_NAME=''
    NFT_CHAIN_NAME=''

    # shellcheck disable=SC1090
    . "$conf_file"

    INTERFACE_NAME="$(trim "${INTERFACE_NAME:-$iface}")"
    VPN_DEV="$(trim "${VPN_DEV:-$INTERFACE_NAME}")"
    MARK_HEX="$(trim "${MARK_HEX:-}")"
    ROUTE_TABLE_ID="$(trim "${ROUTE_TABLE_ID:-}")"
    ROUTE_TABLE_NAME="$(trim "${ROUTE_TABLE_NAME:-$INTERFACE_NAME}")"
    IP_RULE_PREF="$(trim "${IP_RULE_PREF:-10000}")"

    legacy_fqdn4="$(trim "${NFT_FQDN_SET_NAME:-}")"
    legacy_prefix4="$(trim "${NFT_PREFIX_SET_NAME:-}")"

    NFT_FQDN4_SET_NAME="$(trim "${NFT_FQDN4_SET_NAME:-${legacy_fqdn4:-${INTERFACE_NAME}_fqdn4}}")"
    NFT_FQDN6_SET_NAME="$(trim "${NFT_FQDN6_SET_NAME:-${INTERFACE_NAME}_fqdn6}")"
    NFT_PREFIX4_SET_NAME="$(trim "${NFT_PREFIX4_SET_NAME:-${legacy_prefix4:-${INTERFACE_NAME}_prefixes4}}")"
    NFT_PREFIX6_SET_NAME="$(trim "${NFT_PREFIX6_SET_NAME:-${INTERFACE_NAME}_prefixes6}")"
    NFT_CHAIN_NAME="$(trim "${NFT_CHAIN_NAME:-mangle_prerouting_${INTERFACE_NAME}}")"

    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "$iface" "$VPN_DEV" "$MARK_HEX" "$ROUTE_TABLE_ID" "$ROUTE_TABLE_NAME" "$IP_RULE_PREF" \
        "$NFT_FQDN4_SET_NAME" "$NFT_FQDN6_SET_NAME" "$NFT_PREFIX4_SET_NAME" "$NFT_PREFIX6_SET_NAME" "$NFT_CHAIN_NAME"
}

mark_owned() {
    key="$1"
    printf '%s\n' "$key" >> "$OWNED_KEYS"
}

is_owned() {
    key="$1"
    grep -Fx "$key" "$OWNED_KEYS" >/dev/null 2>&1
}

matches_targets() {
    cls="$1"
    case "$TARGETS" in
        all) return 0 ;;
        orphan) [ "$cls" = "orphan" ] ;;
        legacy) [ "$cls" = "legacy" ] ;;
        *) return 0 ;;
    esac
}

collect_interfaces() {
    info "Собираю актуальные настройки из interfaces"
    ifaces="$(list_interfaces || true)"
    if [ -z "$ifaces" ]; then
        warn "Каталог interfaces пуст или не найден: $INTERFACES_DIR"
        return 0
    fi
    printf '%s\n' "$ifaces" | while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        load_iface_conf_print "$iface" >> "$ACT_IFACES" || true
    done

    if [ ! -s "$ACT_IFACES" ]; then
        warn "Не удалось прочитать ни один iface.conf"
        return 0
    fi

    awk -F '\t' '{print $3}' "$ACT_IFACES" | sed '/^$/d' | sort -u > "$ACT_MARKS"
    awk -F '\t' '{print $5}' "$ACT_IFACES" | sed '/^$/d' | sort -u > "$ACT_TABLE_NAMES"
    awk -F '\t' '{print $4}' "$ACT_IFACES" | sed '/^$/d' | sort -u > "$ACT_TABLE_IDS"
    awk -F '\t' '{print $6}' "$ACT_IFACES" | sed '/^$/d' | sort -u > "$ACT_PREFS"
    awk -F '\t' '{print $7"\n"$8"\n"$9"\n"$10"\n"$11"\n""mangle_output_"$1}' "$ACT_IFACES" | sed '/^$/d' | sort -u > "$ACT_NFT_NAMES"
}

IP_RULE_TXT="$TMP_ROOT/ip_rule.txt"
RT_TABLES_TXT="$TMP_ROOT/rt_tables.txt"
NFT_TXT="$TMP_ROOT/nft.txt"
DNSMASQ_TXT="$TMP_ROOT/dnsmasq.txt"
HOTPLUG_TXT="$TMP_ROOT/hotplug.txt"

scan_system() {
    info "Считываю ip rule"
    ip rule show > "$IP_RULE_TXT" 2>/dev/null || true

    info "Считываю /etc/iproute2/rt_tables"
    [ -f "$RT_TABLES_FILE" ] && cat "$RT_TABLES_FILE" > "$RT_TABLES_TXT" || : > "$RT_TABLES_TXT"

    info "Считываю nft ruleset"
    nft list ruleset > "$NFT_TXT" 2>/dev/null || true

    info "Сканирую dnsmasq nftset"
    if [ -d "$DNSMASQ_DIR" ]; then
        grep -R "nftset=" "$DNSMASQ_DIR" 2>/dev/null > "$DNSMASQ_TXT" || : > "$DNSMASQ_TXT"
    else
        : > "$DNSMASQ_TXT"
    fi

    info "Сканирую hotplug"
    if [ -f "$HOTPLUG_FILE" ]; then
        cat "$HOTPLUG_FILE" > "$HOTPLUG_TXT"
    else
        : > "$HOTPLUG_TXT"
    fi
}

has_token_in_file() {
    token="$1"
    file="$2"
    [ -n "$token" ] || return 1
    [ -f "$file" ] || return 1
    grep -F "$token" "$file" >/dev/null 2>&1
}

real_iface_state() {
    dev="$1"
    [ -n "$dev" ] || { echo "UNKNOWN"; return; }
    if ! ip link show "$dev" >/dev/null 2>&1; then
        echo "NOT FOUND"
        return
    fi
    state="$(ip link show "$dev" 2>/dev/null | sed -n 's/.*state \([A-Z][A-Z_]*\).*/\1/p' | head -n 1)"
    [ -n "$state" ] || state="FOUND"
    echo "$state"
}

show_interface_sections() {
    echo
    echo "==== АКТУАЛЬНЫЕ ИНТЕРФЕЙСЫ ===="
    if [ ! -s "$ACT_IFACES" ]; then
        echo "(не найдены)"
        return 0
    fi

    while IFS='\t' read -r iface vpn_dev mark_hex table_id table_name pref nft_fqdn4 nft_fqdn6 nft_prefix4 nft_prefix6 nft_chain; do
        [ -n "$iface" ] || continue
        echo
        echo "==== ИНТЕРФЕЙС: $iface ===="
        echo "CONFIG:"
        echo "  VPN_DEV=$vpn_dev"
        echo "  MARK_HEX=$mark_hex"
        echo "  ROUTE_TABLE_ID=$table_id"
        echo "  ROUTE_TABLE_NAME=$table_name"
        echo "  IP_RULE_PREF=$pref"
        echo "  NFT_FQDN4_SET_NAME=$nft_fqdn4"
        echo "  NFT_FQDN6_SET_NAME=$nft_fqdn6"
        echo "  NFT_PREFIX4_SET_NAME=$nft_prefix4"
        echo "  NFT_PREFIX6_SET_NAME=$nft_prefix6"
        echo "  NFT_CHAIN_NAME=$nft_chain"
        echo "  NFT_OUTPUT_CHAIN_NAME=mangle_output_${iface}"
        echo "REAL IFACE: $(real_iface_state "$vpn_dev")"

        found_rule=0; found_table=0; found_routes=0; found_nft=0; found_dnsmasq=0; found_hotplug=0

        echo "OWNED RULES:"
        awk -v m="$mark_hex" -v t="$table_name" -v p="$pref" '
            index($0, "fwmark " m) && index($0, "lookup " t) {
                if (p == "" || index($0, p ":") == 1 || index($0, " pref " p) > 0 || 1) print
            }
        ' "$IP_RULE_TXT" | while IFS= read -r line; do
            [ -n "$line" ] || continue
            found_rule=1
            printf '  %s\n' "$line"
        done
        if ! awk -v m="$mark_hex" -v t="$table_name" 'index($0, "fwmark " m) && index($0, "lookup " t){exit 0} END{exit 1}' "$IP_RULE_TXT" 2>/dev/null; then
            echo "  (не найдены)"
        else
            found_rule=1
            awk -v m="$mark_hex" -v t="$table_name" 'index($0, "fwmark " m) && index($0, "lookup " t){print "  "$0}' "$IP_RULE_TXT"
            awk -v m="$mark_hex" -v t="$table_name" 'index($0, "fwmark " m) && index($0, "lookup " t){print}' "$IP_RULE_TXT" | while IFS= read -r line; do
                mark_owned "RULE|$line"
            done
        fi

        echo "OWNED RT_TABLES:"
        if awk -v id="$table_id" -v t="$table_name" '$1==id && $2==t {print "  "$0; found=1} END{exit !found}' "$RT_TABLES_TXT"; then
            found_table=1
            mark_owned "TABLE|$table_id|$table_name"
        else
            echo "  (не найдены)"
        fi

        echo "OWNED ROUTES:"
        routes_file="$TMP_ROOT/routes_${iface}.txt"
        ip route show table "$table_name" > "$routes_file" 2>/dev/null || true
        if [ -s "$routes_file" ]; then
            sed 's/^/  /' "$routes_file"
            found_routes=1
            while IFS= read -r rline; do
                [ -n "$rline" ] || continue
                mark_owned "ROUTE|$table_name|$rline"
            done < "$routes_file"
        else
            echo "  (не найдены)"
        fi

        echo "OWNED NFT:"
        nft_any=0
        for token in "$mark_hex" "$nft_fqdn4" "$nft_fqdn6" "$nft_prefix4" "$nft_prefix6" "$nft_chain" "mangle_output_${iface}"; do
            [ -n "$token" ] || continue
            grep -F "$token" "$NFT_TXT" 2>/dev/null | while IFS= read -r nline; do
                [ -n "$nline" ] || continue
                nft_any=1
                :
            done
        done
        nft_lines="$TMP_ROOT/nft_${iface}.txt"
        : > "$nft_lines"
        for token in "$mark_hex" "$nft_fqdn4" "$nft_fqdn6" "$nft_prefix4" "$nft_prefix6" "$nft_chain" "mangle_output_${iface}"; do
            [ -n "$token" ] || continue
            grep -F "$token" "$NFT_TXT" 2>/dev/null || true
        done | sort -u > "$nft_lines"
        if [ -s "$nft_lines" ]; then
            sed 's/^/  /' "$nft_lines"
            found_nft=1
            while IFS= read -r nline; do
                [ -n "$nline" ] || continue
                mark_owned "NFT|$nline"
            done < "$nft_lines"
        else
            echo "  (не найдены)"
        fi

        echo "OWNED DNSMASQ NFTSET:"
        dns_file="$TMP_ROOT/dns_${iface}.txt"
        : > "$dns_file"
        for token in "$nft_fqdn4" "$nft_fqdn6" "$nft_prefix4" "$nft_prefix6"; do
            [ -n "$token" ] || continue
            grep -F "$token" "$DNSMASQ_TXT" 2>/dev/null || true
        done | sort -u > "$dns_file"
        if [ -s "$dns_file" ]; then
            sed 's/^/  /' "$dns_file"
            found_dnsmasq=1
            while IFS= read -r dline; do
                [ -n "$dline" ] || continue
                mark_owned "DNSMASQ|$dline"
            done < "$dns_file"
        else
            echo "  (не найдены)"
        fi

        echo "OWNED HOTPLUG REFS:"
        hp_file="$TMP_ROOT/hp_${iface}.txt"
        : > "$hp_file"
        for token in "$vpn_dev" "$mark_hex" "$table_name" "$pref"; do
            [ -n "$token" ] || continue
            grep -F "$token" "$HOTPLUG_TXT" 2>/dev/null || true
        done | sort -u > "$hp_file"
        if [ -s "$hp_file" ]; then
            sed 's/^/  /' "$hp_file"
            found_hotplug=1
            while IFS= read -r hline; do
                [ -n "$hline" ] || continue
                mark_owned "HOTPLUG|$hline"
            done < "$hp_file"
        else
            echo "  (не найдены)"
        fi

        status="OK"
        missing=0
        [ "$found_rule" -eq 1 ] || missing=$((missing+1))
        [ "$found_table" -eq 1 ] || missing=$((missing+1))
        [ "$found_nft" -eq 1 ] || missing=$((missing+1))
        if [ "$missing" -ge 3 ]; then
            status="BROKEN"
        elif [ "$missing" -gt 0 ]; then
            status="PARTIAL"
        fi
        echo "STATUS: $status"
    done < "$ACT_IFACES"
}

collect_candidates() {
    # rules
    while IFS= read -r line; do
        [ -n "$line" ] || continue
        case "$line" in
            *"lookup local"*|*"lookup main"*|*"lookup default"*) continue ;;
        esac
        class="foreign"
        reason="not-claimed"
        if has_token_in_file "$line" "$HOTPLUG_FILE" || has_token_in_file "$line" "$NFT_FILE" || has_token_in_file "$line" "$DNSMASQ_FILE"; then
            class="likely-owned"
            reason="referenced-by-domain-routing-runtime"
        fi
        mark="$(printf '%s\n' "$line" | sed -n 's/.*fwmark \([^ ]*\).*/\1/p')"
        table="$(printf '%s\n' "$line" | sed -n 's/.*lookup \([^ ]*\).*/\1/p')"
        if [ -n "$mark" ] && grep -Fx "$mark" "$ACT_MARKS" >/dev/null 2>&1; then
            mark_owned "RULE|$line"
            continue
        fi
        if [ -n "$table" ] && grep -Fx "$table" "$ACT_TABLE_NAMES" >/dev/null 2>&1; then
            mark_owned "RULE|$line"
            continue
        fi
        if [ "$class" = "likely-owned" ]; then
            if [ -z "$table" ] || ! grep -Fx "$table" "$ACT_TABLE_NAMES" >/dev/null 2>&1; then
                class="orphan"
                reason="no-interface-config-for-runtime-rule"
            fi
        fi
        if matches_targets "$class"; then
            printf '%s\t%s\t%s\n' "$class" "$reason" "$line" >> "$CAND_RULES"
        fi
    done < "$IP_RULE_TXT"

    # rt_tables
    awk 'NF>=2 && $1 !~ /^(255|254|253|0)$/ {print $1"\t"$2}' "$RT_TABLES_TXT" | while IFS='\t' read -r id name; do
        [ -n "$name" ] || continue
        if grep -Fx "$name" "$ACT_TABLE_NAMES" >/dev/null 2>&1 || grep -Fx "$id" "$ACT_TABLE_IDS" >/dev/null 2>&1; then
            mark_owned "TABLE|$id|$name"
            continue
        fi
        class="foreign"
        reason="not-claimed"
        if has_token_in_file "$name" "$HOTPLUG_FILE" || has_token_in_file "$name" "$NFT_FILE" || has_token_in_file "$name" "$DNSMASQ_FILE"; then
            class="orphan"
            reason="runtime-table-without-interface-config"
        elif [ "$name" = "vpnmark" ]; then
            class="legacy"
            reason="legacy-vpnmark"
        fi
        if matches_targets "$class"; then
            printf '%s\t%s\t%s\t%s\n' "$class" "$reason" "$id" "$name" >> "$CAND_TABLES"
        fi
    done

    # routes for candidate tables + active unowned runtime tables
    awk -F '\t' '{print $4}' "$CAND_TABLES" | sed '/^$/d' | sort -u | while IFS= read -r table; do
        [ -n "$table" ] || continue
        ip route show table "$table" 2>/dev/null | while IFS= read -r rline; do
            [ -n "$rline" ] || continue
            printf 'orphan\ttable-candidate\t%s\t%s\n' "$table" "$rline" >> "$CAND_ROUTES"
        done
    done

    # runtime files - only system runtime, not /root and not backups
    for path in "$DNSMASQ_FILE" "$NFT_FILE" "$HOTPLUG_FILE"; do
        [ -e "$path" ] || continue
        class="likely-owned"
        reason="domain-routing-runtime-file"
        if [ ! -s "$ACT_IFACES" ]; then
            class="orphan"
            reason="runtime-file-without-any-interface-config"
        else
            referenced=0
            while IFS='\t' read -r iface vpn_dev mark_hex table_id table_name pref nft_fqdn4 nft_fqdn6 nft_prefix4 nft_prefix6 nft_chain; do
                [ -n "$iface" ] || continue
                for token in "$vpn_dev" "$mark_hex" "$table_name" "$nft_fqdn4" "$nft_fqdn6" "$nft_prefix4" "$nft_prefix6" "$nft_chain" "mangle_output_${iface}"; do
                    [ -n "$token" ] || continue
                    if grep -F "$token" "$path" >/dev/null 2>&1; then
                        referenced=1
                        break 2
                    fi
                done
            done < "$ACT_IFACES"
            if [ "$referenced" -eq 0 ]; then
                class="orphan"
                reason="runtime-file-not-matching-any-interface-config"
            fi
        fi
        if matches_targets "$class"; then
            printf '%s\t%s\t%s\n' "$class" "$reason" "$path" >> "$CAND_RUNTIME"
        fi
    done

    # nft standalone candidates (only lines mentioning domain-routing runtime tokens or legacy vpnmark)
    if [ -f "$NFT_FILE" ]; then
        grep -F "mark set" "$NFT_TXT" 2>/dev/null | while IFS= read -r nline; do
            [ -n "$nline" ] || continue
            owned=0
            while IFS= read -r mark; do
                [ -n "$mark" ] || continue
                if printf '%s\n' "$nline" | grep -F "$mark" >/dev/null 2>&1; then owned=1; break; fi
            done < "$ACT_MARKS"
            [ "$owned" -eq 1 ] && { mark_owned "NFT|$nline"; continue; }
            class="foreign"
            reason="not-claimed"
            if printf '%s\n' "$nline" | grep -F "0x10000" >/dev/null 2>&1 || grep -F "$nline" "$NFT_FILE" >/dev/null 2>&1; then
                class="orphan"
                reason="runtime-nft-mark-without-interface-config"
            fi
            if matches_targets "$class"; then
                printf '%s\t%s\t%s\n' "$class" "$reason" "$nline" >> "$CAND_NFT"
            fi
        done
    fi
}

print_unassigned() {
    echo
    echo "==== НЕПРИВЯЗАННЫЕ RULES ===="
    if [ -s "$CAND_RULES" ]; then
        awk -F '\t' '{printf "[%s] %s | %s\n", $1, $3, $2}' "$CAND_RULES"
    else
        echo "(нет)"
    fi

    echo
    echo "==== НЕПРИВЯЗАННЫЕ RT_TABLES ===="
    if [ -s "$CAND_TABLES" ]; then
        awk -F '\t' '{printf "[%s] %s %s | %s\n", $1, $3, $4, $2}' "$CAND_TABLES"
    else
        echo "(нет)"
    fi

    echo
    echo "==== НЕПРИВЯЗАННЫЕ ROUTES ===="
    if [ -s "$CAND_ROUTES" ]; then
        awk -F '\t' '{printf "[%s] table=%s route=%s | %s\n", $1, $3, $4, $2}' "$CAND_ROUTES"
    else
        echo "(нет)"
    fi

    echo
    echo "==== НЕПРИВЯЗАННЫЕ NFT ===="
    if [ -s "$CAND_NFT" ]; then
        awk -F '\t' '{printf "[%s] %s | %s\n", $1, $3, $2}' "$CAND_NFT"
    else
        echo "(нет)"
    fi

    echo
    echo "==== НЕПРИВЯЗАННЫЕ RUNTIME FILES ===="
    if [ -s "$CAND_RUNTIME" ]; then
        awk -F '\t' '{printf "[%s] %s | %s\n", $1, $3, $2}' "$CAND_RUNTIME"
    else
        echo "(нет)"
    fi
}

print_summary_candidates() {
    echo
    echo "==== ИТОГОВЫЕ КАНДИДАТЫ НА УДАЛЕНИЕ ===="
    total_rules="$(wc -l < "$CAND_RULES" | tr -d ' ')"
    total_tables="$(wc -l < "$CAND_TABLES" | tr -d ' ')"
    total_routes="$(wc -l < "$CAND_ROUTES" | tr -d ' ')"
    total_nft="$(wc -l < "$CAND_NFT" | tr -d ' ')"
    total_runtime="$(wc -l < "$CAND_RUNTIME" | tr -d ' ')"
    echo "SUMMARY:"
    echo "  candidate rules     : $total_rules"
    echo "  candidate rt_tables : $total_tables"
    echo "  candidate routes    : $total_routes"
    echo "  candidate nft       : $total_nft"
    echo "  candidate runtime   : $total_runtime"

    echo
    echo "RULES:"
    [ -s "$CAND_RULES" ] && awk -F '\t' '{printf "  [%s] %s\n      reason: %s\n", $1, $3, $2}' "$CAND_RULES" || echo "  (нет)"
    echo "RT_TABLES:"
    [ -s "$CAND_TABLES" ] && awk -F '\t' '{printf "  [%s] %s %s\n      reason: %s\n", $1, $3, $4, $2}' "$CAND_TABLES" || echo "  (нет)"
    echo "ROUTES:"
    [ -s "$CAND_ROUTES" ] && awk -F '\t' '{printf "  [%s] table=%s route=%s\n      reason: %s\n", $1, $3, $4, $2}' "$CAND_ROUTES" || echo "  (нет)"
    echo "NFT:"
    [ -s "$CAND_NFT" ] && awk -F '\t' '{printf "  [%s] %s\n      reason: %s\n", $1, $3, $2}' "$CAND_NFT" || echo "  (нет)"
    echo "RUNTIME FILES:"
    [ -s "$CAND_RUNTIME" ] && awk -F '\t' '{printf "  [%s] %s\n      reason: %s\n", $1, $3, $2}' "$CAND_RUNTIME" || echo "  (нет)"
}

clean_candidates() {
    echo
    info "Запускаю очистку кандидатов"

    if [ -s "$CAND_RULES" ]; then
        awk -F '\t' '{print $3}' "$CAND_RULES" | while IFS= read -r line; do
            pref="$(printf '%s\n' "$line" | sed -n 's/^\([0-9][0-9]*\):.*/\1/p')"
            mark="$(printf '%s\n' "$line" | sed -n 's/.*fwmark \([^ ]*\).*/\1/p')"
            table="$(printf '%s\n' "$line" | sed -n 's/.*lookup \([^ ]*\).*/\1/p')"
            if [ -n "$pref" ] && [ -n "$table" ]; then
                while ip rule del lookup "$table" pref "$pref" 2>/dev/null; do :; done
            fi
            if [ -n "$mark" ] && [ -n "$table" ]; then
                while ip rule del fwmark "$mark" lookup "$table" 2>/dev/null; do :; done
            fi
            info "Удалено rule-кандидат: $line"
        done
    fi

    if [ -s "$CAND_TABLES" ]; then
        awk -F '\t' '{print $4}' "$CAND_TABLES" | sort -u | while IFS= read -r table; do
            [ -n "$table" ] || continue
            ip route flush table "$table" 2>/dev/null || true
            info "Очищена таблица маршрутов: $table"
        done
    fi

    if [ "$DELETE_RT_TABLES" = "1" ] && [ -s "$CAND_TABLES" ]; then
        cp "$RT_TABLES_FILE" "$TMP_ROOT/rt_tables.before" 2>/dev/null || true
        awk -F '\t' '{print $4}' "$CAND_TABLES" | sort -u | while IFS= read -r table; do
            [ -n "$table" ] || continue
            sed -i "/[[:space:]]$table$/d" "$RT_TABLES_FILE"
            info "Удалена запись из rt_tables: $table"
        done
    fi

    if [ "$DELETE_RUNTIME" = "1" ] && [ -s "$CAND_RUNTIME" ]; then
        awk -F '\t' '{print $3}' "$CAND_RUNTIME" | sort -u | while IFS= read -r path; do
            [ -n "$path" ] || continue
            rm -f "$path" 2>/dev/null || true
            info "Удалён runtime-файл: $path"
        done
    fi
}

main() {
    collect_interfaces
    scan_system

    show_interface_sections
    collect_candidates
    print_unassigned
    print_summary_candidates

    if [ "$MODE" = "clean" ]; then
        clean_candidates
    fi
}

main "$@"
