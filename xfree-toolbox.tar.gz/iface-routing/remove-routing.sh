#!/bin/sh
set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
COMMON_SH="${ROOT_DIR}/lib/common.sh"

[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"
[ -f "$CONFIG_FILE" ] || { echo "[-] Не найден конфиг: $CONFIG_FILE" >&2; exit 1; }
. "$CONFIG_FILE"

for cmd in ip uci grep sed rm rmdir find; do require_cmd "$cmd"; done

BASE_DIR="${BASE_DIR:-$SCRIPT_DIR}"
SYSTEM_DOMAIN_ROUTING_DIR="${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}"
SYSTEM_INTERFACES_DIR="${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}"
SYSTEM_GENERATED_DIR="${SYSTEM_GENERATED_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/interfaces}"
DNSMASQ_DIR="${DNSMASQ_DIR:-/etc/dnsmasq.d/xfree-toolbox-routing}"
DNSMASQ_FILE="${DNSMASQ_FILE:-$DNSMASQ_DIR/90-xfree-toolbox-fqdn-routing.conf}"
NFT_FILE="${NFT_FILE:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/90-xfree-toolbox-fqdn-routing.nft}"
HOTPLUG_FILE="${HOTPLUG_FILE:-/etc/hotplug.d/iface/90-xfree-toolbox-routing}"
ROUTE_TABLE_PREFIX="${ROUTE_TABLE_PREFIX:-xfree-routing-rt-}"
ENABLE_LEGACY_CLEANUP="${ENABLE_LEGACY_CLEANUP:-1}"

info "Откат domain-routing: шаг 1 — таблицы xfree-*, runtime и generated toolbox"
common_cleanup_domain_routing_core "$ROUTE_TABLE_PREFIX" "$NFT_FILE" "$DNSMASQ_FILE" "$HOTPLUG_FILE" "$DNSMASQ_DIR" "$SYSTEM_GENERATED_DIR" "$SYSTEM_INTERFACES_DIR" "$ENABLE_LEGACY_CLEANUP"

if [ "$ENABLE_LEGACY_CLEANUP" = "1" ]; then
  info "Откат domain-routing: шаг 2 — legacy (vpnmark, firewall include, старые domain-routing/dnsmasq)"
  common_cleanup_domain_routing_legacy "$ROUTE_TABLE_PREFIX" "$NFT_FILE" "$DNSMASQ_FILE" "$HOTPLUG_FILE" "$DNSMASQ_DIR" "$SYSTEM_GENERATED_DIR" "$SYSTEM_INTERFACES_DIR" "$ENABLE_LEGACY_CLEANUP"
else
  info "Откат domain-routing: шаг 2 пропущен (ENABLE_LEGACY_CLEANUP=0)"
fi

info "Коммичу UCI"
uci commit dhcp || true
uci commit firewall || true
uci commit network || true

info "Перезапускаю dnsmasq"
refresh_target service dnsmasq stop-start
info "Перезапускаю firewall"
refresh_target service firewall

success "Rollback завершён"
