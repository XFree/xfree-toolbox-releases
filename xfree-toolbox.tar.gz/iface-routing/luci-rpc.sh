#!/bin/sh
# shellcheck shell=sh
# Non-interactive VPN-tunnel menu actions for LuCI (ubus xfree-toolbox ifaceMenu).
# Mirrors CLI xft → 7 (iface-routing/menu.yaml). Lists for sites → Маршруты → VPN.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

ACTION="${1:-}"
ARG="${2:-}"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
SYSTEM_DOMAIN_ROUTING_DIR="${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}"
SYSTEM_INTERFACES_DIR="${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}"
SYSTEM_GENERATED_DIR="${SYSTEM_GENERATED_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/interfaces}"
APPLY_SH="${APPLY_SH:-$SCRIPT_DIR/apply-interfaces.sh}"
APPLY_ROUTING_SH="${APPLY_ROUTING_SH:-$ROOT_DIR/lib/apply-dns-and-iface-routing.sh}"
DELETE_SH="${DELETE_SH:-$SCRIPT_DIR/delete-interface.sh}"
REGENERATE_SH="${REGENERATE_SH:-$SCRIPT_DIR/regenerate-interface-config.sh}"
UPDATE_SH="${UPDATE_SH:-$SCRIPT_DIR/update-interface-config.sh}"
CONVERTER_SH="${CONVERTER_SH:-$SCRIPT_DIR/conf-to-interface-uci.sh}"
SELF_ROUTE_SH="${SELF_ROUTE_SH:-$SCRIPT_DIR/self-route/apply.sh}"
PBR_APPLY_SH="${PBR_APPLY_SH:-$SCRIPT_DIR/pbr-bypass/apply.sh}"
WARP_GEN_SH="${WARP_GEN_SH:-$SCRIPT_DIR/vpn/warp/generate.sh}"
PROTON_GEN_SH="${PROTON_GEN_SH:-$SCRIPT_DIR/vpn/proton/generate.sh}"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"
WARP_CONF_DIR="$(xfree_profile_warp_conf_dir "$PROFILE_DIR" 2>/dev/null || printf '%s/warp' "$PROFILE_VPN_DIR")"
PROTON_CONF_DIR="$(xfree_profile_proton_conf_dir "$PROFILE_DIR" 2>/dev/null || printf '%s/proton' "$PROFILE_VPN_DIR")"
LUCIRPC_SH="$SCRIPT_DIR/luci-rpc.sh"

if [ -f "$ROOT_DIR/lib/background-tasks.sh" ]; then
	# shellcheck disable=SC1091
	. "$ROOT_DIR/lib/background-tasks.sh"
fi

iface_luci_emit_task_status() {
	_running=0
	_task=""
	_pid=""
	_log=""
	_last_status=""
	_last_exit=""

	if bg_tasks_is_running; then
		_running=1
		_task="${BG_TASK_NAME:-}"
		_pid="${BG_TASK_PID:-}"
		_log="${BG_TASK_LOG_FILE:-}"
	elif bg_tasks_read_last_meta; then
		_task="${BG_TASK_LAST_NAME:-}"
		_log="${BG_TASK_LAST_LOG_FILE:-}"
		_last_status="${BG_TASK_LAST_STATUS:-}"
		_last_exit="${BG_TASK_LAST_EXIT_CODE:-}"
	fi

	if [ "$_running" -eq 1 ]; then
		printf 'STATUS=running\n'
	elif [ -n "$_last_status" ] || [ -n "$_task" ]; then
		printf 'STATUS=idle\n'
	else
		printf 'STATUS=none\n'
	fi
	[ -n "$_task" ] && printf 'TASK=%s\n' "$_task"
	[ -n "$_pid" ] && printf 'PID=%s\n' "$_pid"
	[ -n "$_log" ] && printf 'LOG=%s\n' "$_log"
	[ -n "$_last_status" ] && printf 'LAST_STATUS=%s\n' "$_last_status"
	[ -n "$_last_exit" ] && printf 'LAST_EXIT=%s\n' "$_last_exit"
	if [ -n "$_log" ] && [ -f "$_log" ]; then
		printf '---\n'
		tail -n 120 "$_log" 2>/dev/null || true
	fi
}

iface_luci_start_bg() {
	_task="$1"
	shift
	_runner="$ROOT_DIR/lib/bg-task-run.sh"
	_log="${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}/${_task}.log"

	[ -f "$_runner" ] || die_usage "нет $_runner (фоновые задачи)"
	if bg_tasks_is_running; then
		printf '=== Задача уже выполняется ===\n'
		printf 'STATUS=already_running\n'
		iface_luci_emit_task_status
		return 0
	fi

	printf '=== Запуск в фоне: %s ===\n' "$_task"
	printf 'Лог: %s\n\n' "$_log"
	(
		export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
		sh "$_runner" "$_task" --log "$_log" -- env IFACE_LUCI_FOREGROUND=1 "$@"
	) >/dev/null 2>&1 &
	sleep 1
	iface_luci_emit_task_status
}

# LuCI/uhttpd ~60s — длинные apply/delete/regenerate в фоне (см. lib/bg-task-run.sh).
iface_luci_want_bg() {
	[ "${IFACE_LUCI_FOREGROUND:-}" = "1" ] && return 1
	case "$ACTION" in
	delete)
		case "$ARG" in
		*'|'*)
			_mode="${ARG#*|}"
			case "$_mode" in
			reconcile|orphans|full) return 0 ;;
			esac
			;;
		esac
		return 1
		;;
	applyAll|applyRouting|regenerateAll|regenerateTemplates|regenerateOne|applyOne|createFromConf|createFromOvpn|protocolsInstall|protocolsRemove|updateFromConf|warpGenerate|protonGenerate|warpProvision|protonProvision|regenerateOpts|confDelete|confDeleteUnused|pbrApplyBulk|reconnect|toggleEnabled)
		return 0
		;;
	esac
	return 1
}

iface_luci_try_bg() {
	_task="$1"
	shift

	iface_luci_want_bg || return 1
	if [ "$#" -gt 0 ]; then
		iface_luci_start_bg "$_task" "$@"
	else
		iface_luci_start_bg "$_task" sh "$LUCIRPC_SH" "$ACTION"
	fi
	return 0
}

action_task_status() {
	printf '=== Фоновая задача (VPN / iface-routing) ===\n'
	iface_luci_emit_task_status
}

run() {
	_title="$1"
	shift
	printf '=== %s ===\n' "$_title"
	sh "$@"
}

die_usage() {
	printf '%s\n' "$1" >&2
	exit 1
}

need_arg() {
	[ -n "${ARG:-}" ] || die_usage "ifaceMenu $ACTION: требуется arg"
}

list_ifaces() {
	[ -d "$INTERFACES_DIR" ] || return 0
	for d in "$INTERFACES_DIR"/*; do
		[ -d "$d" ] || continue
		basename "$d"
	done | sort -u
}

list_template_ifaces() {
	[ -d "$INTERFACES_DIR" ] || return 0
	find "$INTERFACES_DIR" -type f -path '*/config/TEMPLATE' 2>/dev/null \
		| sed "s|$INTERFACES_DIR/||" \
		| sed 's|/config/TEMPLATE$||' \
		| sed '/^$/d' \
		| sort -u
}

meta_get() {
	_f="$1"
	_k="$2"
	[ -f "$_f" ] || return 0
	awk -F= -v k="$_k" '
		$1 == k {
			sub(/^[^=]*=/, "")
			gsub(/\r/, "")
			gsub(/^[[:space:]]+|[[:space:]]+$/, "")
			gsub(/^['\'']|['\'']$/, "")
			gsub(/^"|"$/, "")
			print
			exit
		}
	' "$_f"
}

iface_conf_get() {
	_f="$1"
	_k="$2"
	[ -f "$_f" ] || return 0
	awk -F= -v k="$_k" '
		{
			line=$0
			sub(/\r$/, "", line)
			sub(/^[[:space:]]+/, "", line)
			if (line ~ /^#/ || line == "") next
			split(line, a, "=")
			name=a[1]
			sub(/[[:space:]]+$/, "", name)
			if (name != k) next
			val=substr(line, index(line, "=") + 1)
			gsub(/^[[:space:]]+|[[:space:]]+$/, "", val)
			gsub(/^'\''|'\''$/, "", val)
			print val
			exit
		}
	' "$_f"
}

# Returns 0 and prints interface name if .conf is used by any interface, returns 1 if unused.
conf_find_used_by() {
	_conf_path="$1"
	[ -f "$_conf_path" ] || return 1
	_conf_file="$(basename "$_conf_path")"
	_conf_base="$(basename "$_conf_path" .conf)"
	_conf_pk="$(awk -F= '/^[[:space:]]*PrivateKey[[:space:]]*=/ {gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2); print $2; exit}' "$_conf_path" 2>/dev/null || true)"

	for _search_dir in "$INTERFACES_DIR" "$SYSTEM_INTERFACES_DIR"; do
		[ -d "$_search_dir" ] || continue
		for _idir in "$_search_dir"/*; do
			[ -d "$_idir" ] || continue
			_iname="$(basename "$_idir")"

			# 1. Exact file match with source.conf
			if [ -f "$_idir/config/source.conf" ] && cmp -s "$_conf_path" "$_idir/config/source.conf"; then
				printf '%s\n' "$_iname"
				return 0
			fi

			# 2. PrivateKey match with source.conf or UCI network
			if [ -n "$_conf_pk" ]; then
				if [ -f "$_idir/config/source.conf" ]; then
					_ipk="$(awk -F= '/^[[:space:]]*PrivateKey[[:space:]]*=/ {gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2); print $2; exit}' "$_idir/config/source.conf" 2>/dev/null || true)"
					if [ -n "$_ipk" ] && [ "$_conf_pk" = "$_ipk" ]; then
						printf '%s\n' "$_iname"
						return 0
					fi
				fi
				if command -v uci >/dev/null 2>&1; then
					_upk="$(uci -q get "network.${_iname}.private_key" 2>/dev/null || true)"
					if [ -n "$_upk" ] && [ "$_conf_pk" = "$_upk" ]; then
						printf '%s\n' "$_iname"
						return 0
					fi
				fi
			fi

			# 3. PROFILE_BASENAME match with source.conf.meta
			if [ -f "$_idir/config/source.conf.meta" ]; then
				_pbase="$(meta_get "$_idir/config/source.conf.meta" PROFILE_BASENAME 2>/dev/null | tr -d "'\"")"
				if [ -n "$_pbase" ] && { [ "$_pbase" = "$_conf_base" ] || [ "$_pbase" = "$_conf_file" ]; }; then
					printf '%s\n' "$_iname"
					return 0
				fi
			fi
		done
	done

	if [ -n "$_conf_pk" ] && command -v uci >/dev/null 2>&1; then
		_uci_iface="$(uci -q show network 2>/dev/null | awk -F'[.=]' -v pk="$_conf_pk" '$3 == "private_key" && $4 == pk {print $2; exit}' || true)"
		if [ -n "$_uci_iface" ]; then
			printf '%s\n' "$_uci_iface"
			return 0
		fi
	fi

	return 1
}

print_iface_row() {
	_iface="$1"
	_work=нет
	_sys=нет
	_gen=нет
	_src=нет
	_kind=""
	_server=""
	[ -d "$INTERFACES_DIR/$_iface" ] && _work=да
	[ -d "$SYSTEM_INTERFACES_DIR/$_iface" ] && _sys=да
	[ -d "$SYSTEM_GENERATED_DIR/$_iface" ] && _gen=да
	[ -f "$INTERFACES_DIR/$_iface/config/source.conf" ] && _src=да
	_kind="$(meta_get "$INTERFACES_DIR/$_iface/config/source.conf.meta" GENERATOR_KIND)"
	_server="$(meta_get "$INTERFACES_DIR/$_iface/config/source.conf.meta" SERVER_NAME)"
	_kind="$(printf '%s' "$_kind" | tr -d "'\"")"
	_server="$(printf '%s' "$_server" | tr -d "'\"")"
	printf '%s  work=%s state=%s gen=%s source=%s' "$_iface" "$_work" "$_sys" "$_gen" "$_src"
	[ -n "$_kind" ] && printf ' kind=%s' "$_kind"
	[ -n "$_server" ] && printf ' server=%s' "$_server"
	printf '\n'
}

# Extract "key":"value" / "key":true|false from traffic_path_runtime_iface JSON.
_summary_json_str() {
	printf '%s' "$1" | sed -n "s/.*\"$2\":\"\\([^\"]*\\)\".*/\\1/p" | head -n 1
}

_summary_json_bool01() {
	_b="$(printf '%s' "$1" | sed -n "s/.*\"$2\":\\(true\\|false\\).*/\\1/p" | head -n 1)"
	case "$_b" in
	true) printf '1' ;;
	*) printf '0' ;;
	esac
}

_summary_pipe_safe() {
	printf '%s' "$1" | tr -d "'\"|\r\n"
}

# Machine-readable hub payload for LuCI vpn-panel (KEY=value / IFACE=…|k=v).
action_summary() {
	_count=0
	_state_ok=0
	_source_ok=0
	_gen_ok=0
	_tp_ready=0
	if [ -f "$ROOT_DIR/diagnostics/lib/traffic-path.sh" ]; then
		# shellcheck disable=SC1091
		. "$ROOT_DIR/diagnostics/lib/traffic-path.sh"
		TRAFFIC_PATH_ROOT="$ROOT_DIR"
		traffic_path_init_paths
		_tp_ready=1
	fi
	printf 'PROFILE_DIR=%s\n' "$PROFILE_DIR"
	printf 'INTERFACES_DIR=%s\n' "$INTERFACES_DIR"
	printf 'WARP_CONF_DIR=%s\n' "$WARP_CONF_DIR"
	printf 'PROTON_CONF_DIR=%s\n' "$PROTON_CONF_DIR"
	for _iface in $(list_ifaces); do
		_count=$((_count + 1))
		_work=0
		_state=0
		_gen=0
		_src=0
		_kind=""
		_server=""
		_country=""
		_city=""
		_colo=""
		_health="unknown"
		_iface_up=0
		_probe=""
		_proton=""
		_sess=""
		_cert=""
		_dev="$_iface"
		_rt_ok=0
		_meta="$INTERFACES_DIR/$_iface/config/source.conf.meta"
		[ -f "$_meta" ] || _meta="$INTERFACES_DIR/$_iface/config/source.ovpn.meta"
		[ -d "$INTERFACES_DIR/$_iface" ] && _work=1
		[ -d "$SYSTEM_INTERFACES_DIR/$_iface" ] && _state=1
		[ -d "$SYSTEM_GENERATED_DIR/$_iface" ] && _gen=1
		{ [ -f "$INTERFACES_DIR/$_iface/config/source.conf" ] || [ -f "$INTERFACES_DIR/$_iface/config/source.ovpn" ]; } && _src=1
		[ "$_state" -eq 1 ] && _state_ok=$((_state_ok + 1))
		[ "$_src" -eq 1 ] && _source_ok=$((_source_ok + 1))
		[ "$_gen" -eq 1 ] && _gen_ok=$((_gen_ok + 1))
		_kind="$(meta_get "$_meta" GENERATOR_KIND)"
		if [ -z "$_kind" ] && [ -f "$INTERFACES_DIR/$_iface/config/iface.conf" ]; then
			_proto="$(iface_conf_get "$INTERFACES_DIR/$_iface/config/iface.conf" PROTOCOL_LABEL || true)"
			case "$_proto" in
				[Oo]pen[Vv][Pp][Nn]) _kind="openvpn" ;;
				*) _kind="$_proto" ;;
			esac
		fi
		_server="$(meta_get "$_meta" SERVER_NAME)"
		_country="$(meta_get "$_meta" SERVER_COUNTRY)"
		_city="$(meta_get "$_meta" SERVER_CITY)"
		_colo="$(meta_get "$_meta" ENDPOINT_COLO)"
		_kind="$(_summary_pipe_safe "$_kind")"
		_server="$(_summary_pipe_safe "$_server")"
		_country="$(_summary_pipe_safe "$_country")"
		_city="$(_summary_pipe_safe "$_city")"
		_colo="$(_summary_pipe_safe "$_colo")"
		# Cloudflare — не страна. COUNTRY_FILTER у WARP = id сервера (def/xfree), не гео.
		case "$_country" in
		[Cc]loudflare|CLOUDFLARE) _country="" ;;
		esac
		if [ -z "$_country" ]; then
			case "$_kind" in
			proton)
				_country="$(meta_get "$_meta" COUNTRY_FILTER)"
				_country="$(_summary_pipe_safe "$_country")"
				;;
			esac
		fi
		if [ "$_tp_ready" -eq 1 ]; then
			_rt="$(traffic_path_runtime_iface "$_iface" 2>/dev/null || true)"
			if [ -n "$_rt" ]; then
				_health="$(_summary_pipe_safe "$(_summary_json_str "$_rt" health)")"
				[ -n "$_health" ] || _health="unknown"
				_iface_up="$(_summary_json_bool01 "$_rt" ifaceUp)"
				_probe="$(_summary_pipe_safe "$(_summary_json_str "$_rt" monitorLine)")"
				_proton="$(_summary_pipe_safe "$(_summary_json_str "$_rt" protonAuth)")"
				_sess="$(_summary_pipe_safe "$(_summary_json_str "$_rt" protonSess)")"
				_cert="$(_summary_pipe_safe "$(_summary_json_str "$_rt" certLocal)")"
				_dev="$(_summary_pipe_safe "$(_summary_json_str "$_rt" vpnDev)")"
				[ -n "$_dev" ] || _dev="$_iface"
				_rt_ok="$(_summary_json_bool01 "$_rt" ok)"
			fi
		fi
		_lists=0
		for _ld in "$INTERFACES_DIR/$_iface/fqdn.d" "$INTERFACES_DIR/$_iface/prefixes.d"; do
			if [ -d "$_ld" ]; then
				_n="$(find "$_ld" -type f -name '*.lst' 2>/dev/null | wc -l)"
				_lists=$((_lists + _n))
			fi
		done
		_self_route_via=""
		_pbr_bypass=""
		if [ -f "$INTERFACES_DIR/$_iface/config/iface.conf" ]; then
			_self_route_via="$(iface_conf_get "$INTERFACES_DIR/$_iface/config/iface.conf" SELF_ROUTE_VIA || true)"
			_self_route_via="$(_summary_pipe_safe "$_self_route_via")"
			_pbr_bypass="$(iface_conf_get "$INTERFACES_DIR/$_iface/config/iface.conf" PBR_BYPASS_NETWORKS || true)"
			_pbr_bypass="$(_summary_pipe_safe "$_pbr_bypass")"
		fi
		_has_totp=0
		if [ -f "$INTERFACES_DIR/$_iface/config/credentials.env" ]; then
			grep -qE "^TOTP_SECRET='?[^'\"[:space:]]+" "$INTERFACES_DIR/$_iface/config/credentials.env" 2>/dev/null && _has_totp=1
		elif [ -f "/etc/xfree-toolbox/iface-routing/openvpn/$_iface.env" ]; then
			grep -qE "^TOTP_SECRET='?[^'\"[:space:]]+" "/etc/xfree-toolbox/iface-routing/openvpn/$_iface.env" 2>/dev/null && _has_totp=1
		fi
		_disabled=0
		if [ -f "$INTERFACES_DIR/$_iface/config/iface.conf" ]; then
			_dis="$(iface_conf_get "$INTERFACES_DIR/$_iface/config/iface.conf" DISABLED || true)"
			case "$_dis" in
				1|true|on|yes) _disabled=1 ;;
			esac
		fi
		if [ "$_disabled" -eq 0 ]; then
			_uci_dis="$(uci -q get "network.$_iface.disabled" 2>/dev/null || true)"
			case "$_uci_dis" in
				1|true|on|yes) _disabled=1 ;;
			esac
		fi
		if [ "$_disabled" -eq 0 ] && [ -f "/etc/config/openvpn" ]; then
			_ovpn_en="$(uci -q get "openvpn.$_iface.enabled" 2>/dev/null || true)"
			if [ "$_ovpn_en" = "0" ]; then
				_disabled=1
			fi
		fi
		printf 'IFACE=%s|work=%s|state=%s|gen=%s|source=%s|kind=%s|server=%s|country=%s|city=%s|colo=%s|health=%s|iface_up=%s|probe=%s|proton=%s|sess=%s|cert=%s|dev=%s|rt_ok=%s|lists=%s|self_route_via=%s|pbr_bypass=%s|has_totp=%s|disabled=%s\n' \
			"$_iface" "$_work" "$_state" "$_gen" "$_src" "$_kind" "$_server" \
			"$_country" "$_city" "$_colo" \
			"$_health" "$_iface_up" "$_probe" "$_proton" "$_sess" "$_cert" "$_dev" "$_rt_ok" "$_lists" "$_self_route_via" "$_pbr_bypass" "$_has_totp" "$_disabled"
	done
	_self_route_hotplug=0
	[ -f /etc/hotplug.d/iface/95-xfree-toolbox-self-route ] && _self_route_hotplug=1
	printf 'SELF_ROUTE_HOTPLUG=%s\n' "$_self_route_hotplug"
	printf 'COUNT=%s\n' "$_count"
	printf 'STATE_OK=%s\n' "$_state_ok"
	printf 'SOURCE_OK=%s\n' "$_source_ok"
	printf 'GEN_OK=%s\n' "$_gen_ok"
	for _tpl in $(list_template_ifaces); do
		_kind="$(meta_get "$INTERFACES_DIR/$_tpl/config/source.conf.meta" GENERATOR_KIND)"
		_kind="$(_summary_pipe_safe "$_kind")"
		[ -n "$_kind" ] || case "$_tpl" in
		warp|proton) _kind="$_tpl" ;;
		*) _kind="vpn" ;;
		esac
		_occupied=0
		if [ -f "$INTERFACES_DIR/$_tpl/config/source.conf" ]; then
			_occupied=1
		fi
		printf 'CREATE_SLOT=%s|kind=%s|occupied=%s\n' "$_tpl" "$_kind" "$_occupied"
	done
	# Следующее свободное имя warpN (учитывает слоты proton на 0x1202 и т.п.).
	_claimed=""
	for _cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
		[ -f "$_cfg" ] || continue
		_mh="$(iface_conf_get "$_cfg" MARK_HEX)"
		_mh="$(printf '%s' "$_mh" | tr 'A-F' 'a-f')"
		case "$_mh" in
		0x12[0-9a-f][0-9a-f])
			_sn="${_mh#0x12}"
			_sn=$((0x$_sn))
			_claimed="$_claimed $_sn "
			;;
		esac
	done
	_free_warp=""
	_s=1
	while [ "$_s" -le 32 ]; do
		if [ "$_s" -eq 1 ]; then
			_cand=warp
		else
			_cand="warp$_s"
		fi
		case "$_claimed" in
		*" $_s "*) _s=$((_s + 1)); continue ;;
		esac
		[ -d "$INTERFACES_DIR/$_cand" ] && { _s=$((_s + 1)); continue; }
		_free_warp="$_cand"
		break
	done
	[ -n "$_free_warp" ] && printf 'FREE_WARP_IFACE=%s\n' "$_free_warp"
	_free_proton=""
	if [ ! -d "$INTERFACES_DIR/proton" ]; then
		_free_proton=proton
	else
		_s=2
		while [ "$_s" -le 32 ]; do
			_cand="proton$_s"
			[ -d "$INTERFACES_DIR/$_cand" ] || { _free_proton="$_cand"; break; }
			_s=$((_s + 1))
		done
	fi
	[ -n "$_free_proton" ] && printf 'FREE_PROTON_IFACE=%s\n' "$_free_proton"
	for _label_dir in "warp|$WARP_CONF_DIR" "proton|$PROTON_CONF_DIR" "vpn|$PROFILE_VPN_DIR"; do
		_lab="${_label_dir%%|*}"
		_dir="${_label_dir#*|}"
		[ -d "$_dir" ] || continue
		find "$_dir" -maxdepth 2 -type f \( -name '*.conf' -o -name '*.ovpn' \) 2>/dev/null | sort | while IFS= read -r _f; do
			[ -n "$_f" ] || continue
			# Локальное время роутера (TZ/zoneinfo); birth часто недоступен → mtime.
			_when="$(date -r "$_f" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
			[ -n "$_when" ] || _when="$(date -r "$_f" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || true)"
			_used="$(conf_find_used_by "$_f" || true)"
			_cur_lab="$_lab"
			case "$_f" in
				*.ovpn) _cur_lab="openvpn" ;;
			esac
			printf 'CONF=%s|%s|%s|%s\n' "$_cur_lab" "$(basename "$_f")" "$_when" "$_used"
		done
	done

	if [ -f "$ROOT_DIR/iface-routing/vpn/protocols/protocols.sh" ]; then
		# shellcheck disable=SC1090
		. "$ROOT_DIR/iface-routing/vpn/protocols/protocols.sh"
		printf 'PROTO_AWG_STATUS=%s\n' "$(proto_awg_status_label 2>/dev/null || echo 'Не установлен')"
		printf 'PROTO_AWG_INSTALLED=%s\n' "$(proto_awg_is_installed && printf '1' || printf '0')"
		printf 'PROTO_OPENVPN_STATUS=%s\n' "$(proto_openvpn_status_label 2>/dev/null || echo 'Не установлен')"
		printf 'PROTO_OPENVPN_INSTALLED=%s\n' "$(proto_openvpn_is_installed && printf '1' || printf '0')"
		printf 'PROTO_VLESS_STATUS=%s\n' "$(proto_vless_status_label 2>/dev/null || echo 'Не установлен')"
		printf 'PROTO_VLESS_INSTALLED=%s\n' "$(proto_vless_is_installed && printf '1' || printf '0')"
	fi

	_wstate="/tmp/domain-routing-warp"
	_tmpv=""
	[ -f "$_wstate/server" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/server")" || _tmpv=""
	[ -n "$_tmpv" ] || _tmpv="xfree"
	printf 'WARP_SERVER=%s\n' "$_tmpv"
	[ -f "$_wstate/profile" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/profile")" || _tmpv=""
	[ -n "$_tmpv" ] || _tmpv="2.0:1"
	printf 'WARP_PROFILE=%s\n' "$_tmpv"
	[ -f "$_wstate/mode" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/mode")" || _tmpv=""
	[ -n "$_tmpv" ] || _tmpv="local"
	printf 'WARP_MODE=%s\n' "$_tmpv"
	[ -f "$_wstate/i1_mode" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/i1_mode")" || _tmpv=""
	[ -n "$_tmpv" ] || _tmpv="fixed"
	printf 'WARP_I1_MODE=%s\n' "$_tmpv"
	[ -f "$_wstate/i1_domain" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/i1_domain")" || _tmpv=""
	printf 'WARP_I1_DOMAIN=%s\n' "$_tmpv"
	[ -f "$_wstate/name" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/name")" || _tmpv=""
	printf 'WARP_NAME=%s\n' "$_tmpv"
	[ -f "$_wstate/selection" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/selection")" || _tmpv=""
	[ -n "$_tmpv" ] || _tmpv="best"
	printf 'WARP_SELECTION=%s\n' "$_tmpv"
	[ -f "$_wstate/exclude_ru" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/exclude_ru")" || _tmpv=""
	[ -n "$_tmpv" ] || _tmpv="1"
	printf 'WARP_EXCLUDE_RU=%s\n' "$_tmpv"
	[ -f "$_wstate/max_servers" ] && _tmpv="$(tr -d '\r\n' <"$_wstate/max_servers")" || _tmpv=""
	[ -n "$_tmpv" ] || _tmpv="50"
	printf 'WARP_MAX_SERVERS=%s\n' "$_tmpv"

	_pstate="/tmp/domain-routing-proton"
	# Defaults for LuCI form when state empty
	printf 'PROTON_COUNTRY=%s\n' "$([ -f "$_pstate/country" ] && tr -d '\r\n' <"$_pstate/country" || printf 'NL')"
	printf 'PROTON_SESSION_MODE=%s\n' "$([ -f "$_pstate/session_mode" ] && tr -d '\r\n' <"$_pstate/session_mode" || printf 'guest')"
	printf 'PROTON_PROFILE=%s\n' "$([ -f "$_pstate/profile" ] && tr -d '\r\n' <"$_pstate/profile" || printf '2.0:1')"
	printf 'PROTON_MODE=%s\n' "$([ -f "$_pstate/mode" ] && tr -d '\r\n' <"$_pstate/mode" || printf 'local')"
	printf 'PROTON_NAME=%s\n' "$([ -f "$_pstate/name" ] && tr -d '\r\n' <"$_pstate/name" || true)"
	printf 'PROTON_MTU=%s\n' "$([ -f "$_pstate/mtu" ] && tr -d '\r\n' <"$_pstate/mtu" || printf '1280')"
	printf 'PROTON_FREE_ONLY=%s\n' "$([ -f "$_pstate/free_only" ] && tr -d '\r\n' <"$_pstate/free_only" || printf '1')"
	printf 'PROTON_REQUIRE_IPV6=%s\n' "$([ -f "$_pstate/require_ipv6" ] && tr -d '\r\n' <"$_pstate/require_ipv6" || printf '0')"
	printf 'PROTON_SELECTION_MODE=%s\n' "$([ -f "$_pstate/selection_mode" ] && tr -d '\r\n' <"$_pstate/selection_mode" || printf 'best')"
	printf 'PROTON_AWG_NOISE=%s\n' "$([ -f "$_pstate/awg_noise" ] && tr -d '\r\n' <"$_pstate/awg_noise" || printf '0')"
	printf 'PROTON_I1_ENTROPY=%s\n' "$([ -f "$_pstate/i1_entropy" ] && tr -d '\r\n' <"$_pstate/i1_entropy" || printf 'r32')"
	if [ -d "$_pstate" ]; then
		for _f in "$_pstate"/*; do
			[ -f "$_f" ] || continue
			_bn="$(basename "$_f" | tr 'a-z-' 'A-Z_')"
			case "$_bn" in
			COUNTRY|SESSION_MODE|PROFILE|MODE|NAME|MTU|FREE_ONLY|REQUIRE_IPV6|SELECTION_MODE|AWG_NOISE|I1_ENTROPY) continue ;;
			esac
			_tmpv="$(tr -d '\r\n' <"$_f")"
			printf 'PROTON_%s=%s\n' "$_bn" "$_tmpv"
		done
	fi

	_uci_nets="$(uci show network 2>/dev/null | sed -n 's/^network\.\([^.]*\)=interface$/\1/p' | grep -vE '^(loopback|wan|wan6|awg_ingress|proton.*|warp.*)$' | tr '\n' ' ' || true)"
	printf 'UCI_NETWORKS=%s\n' "$_uci_nets"
}

action_list() {
	printf '=== VPN-туннели (профиль) ===\n'
	printf 'PROFILE_DIR=%s\n' "$PROFILE_DIR"
	printf 'INTERFACES_DIR=%s\n\n' "$INTERFACES_DIR"
	_any=0
	for _iface in $(list_ifaces); do
		_any=1
		print_iface_row "$_iface"
	done
	[ "$_any" -eq 1 ] || printf 'Интерфейсы не найдены.\n'
}

action_show() {
	need_arg
	_iface="$ARG"
	_dir="$INTERFACES_DIR/$_iface"
	[ -d "$_dir" ] || die_usage "нет туннеля: $_iface"
	printf '=== Настройки туннеля: %s ===\n\n' "$_iface"
	for _name in iface.conf source.conf source.conf.meta source.ovpn client.ovpn openvpn.uci network.uci firewall.uci; do
		_f="$_dir/config/$_name"
		if [ -f "$_f" ]; then
			printf '--- %s ---\n' "$_name"
			cat "$_f"
			printf '\n'
		fi
	done

	printf '--- Журнал подключения (logread) ---\n'
	if command -v logread >/dev/null 2>&1; then
		_log="$(logread -e "$_iface" 2>/dev/null | tail -n 20 || true)"
		if [ -z "$_log" ]; then
			_log="$(logread -e "openvpn" 2>/dev/null | tail -n 20 || true)"
		fi
		if [ -n "$_log" ]; then
			printf '%s\n' "$_log"
		else
			printf '(нет записей в журнале)\n'
		fi
	else
		printf '(logread недоступен)\n'
	fi
	printf '\n'
}

action_show_file() {
	need_arg
	# arg: iface|file  file ∈ iface.conf|source.conf|source.conf.meta|network.uci|firewall.uci
	_iface="${ARG%%|*}"
	_file="${ARG#*|}"
	[ -n "$_iface" ] && [ -n "$_file" ] && [ "$_iface" != "$ARG" ] || \
		die_usage "arg: <iface>|<file>"
	case "$_file" in
	iface.conf|source.conf|source.conf.meta|network.uci|firewall.uci) ;;
	*) die_usage "unknown file: $_file" ;;
	esac
	_f="$INTERFACES_DIR/$_iface/config/$_file"
	printf '=== %s / %s ===\n' "$_iface" "$_file"
	[ -f "$_f" ] || die_usage "нет файла: $_f"
	cat "$_f"
}

action_apply_one() {
	need_arg
	iface_luci_try_bg "iface-apply-$ARG" sh "$LUCIRPC_SH" applyOne "$ARG" && return 0
	run "Применить туннель: $ARG" "$APPLY_SH" --iface "$ARG"
	if [ -f "$APPLY_ROUTING_SH" ]; then
		run "Применить маршрутизацию ($ARG)" "$APPLY_ROUTING_SH" --profile-dir "$PROFILE_DIR" --iface "$ARG"
	fi
}

action_apply_all() {
	iface_luci_try_bg "iface-apply-all" sh "$LUCIRPC_SH" applyAll && return 0
	run "Применить все туннели" "$APPLY_SH" --all
}

# Списки сайтов (Маршруты → VPN/DNS): profile → runtime (как CLI apply-dns-and-iface-routing).
action_apply_routing() {
	[ -f "$APPLY_ROUTING_SH" ] || die_usage "нет $APPLY_ROUTING_SH"
	if [ -n "${ARG:-}" ]; then
		iface_luci_try_bg "iface-apply-routing-$ARG" sh "$LUCIRPC_SH" applyRouting "$ARG" && return 0
		run "Применить маршрутизацию ($ARG)" "$APPLY_ROUTING_SH" --profile-dir "$PROFILE_DIR" --iface "$ARG"
	else
		iface_luci_try_bg "iface-apply-routing" sh "$LUCIRPC_SH" applyRouting && return 0
		run "Применить маршрутизацию списков" "$APPLY_ROUTING_SH" --profile-dir "$PROFILE_DIR"
	fi
}

action_reconnect() {
	need_arg
	_iface="$ARG"
	iface_luci_try_bg "iface-reconnect-$_iface" sh "$LUCIRPC_SH" reconnect "$_iface" && return 0

	printf '=== Переподключение туннеля: %s ===\n' "$_iface"

	_lifecycle_sh="$ROOT_DIR/iface-routing/lib/iface-lifecycle.sh"
	[ -f "$_lifecycle_sh" ] || _lifecycle_sh="/etc/xfree-toolbox/iface-routing/lib/iface-lifecycle.sh"

	if [ -f "$_lifecycle_sh" ]; then
		# shellcheck disable=SC1090
		. "$_lifecycle_sh"
		iface_reconnect "$_iface"
	else
		printf 'Переподнятие интерфейса %s...\n' "$_iface"
		if command -v ifdown >/dev/null 2>&1; then
			ifdown "$_iface" >/dev/null 2>&1 || true
			sleep 1
			ifup "$_iface" >/dev/null 2>&1 || true
		fi
	fi
	printf 'Готово.\n'
}

action_toggle_enabled() {
	need_arg
	_iface="${ARG%%|*}"
	_force_state=""
	case "$ARG" in
		*'|'*) _force_state="${ARG#*|}" ;;
	esac

	_cfg="$INTERFACES_DIR/$_iface/config/iface.conf"
	[ -f "$_cfg" ] || die_usage "Конфиг интерфейса не найден: $_cfg"

	_curr_disabled="$(iface_conf_get "$_cfg" DISABLED || true)"
	case "$_curr_disabled" in
		1|true|on|yes) _is_dis=1 ;;
		*) _is_dis=0 ;;
	esac

	if [ -n "$_force_state" ]; then
		case "$_force_state" in
			1|disable|off|disabled|true) _new_dis=1 ;;
			0|enable|on|enabled|false) _new_dis=0 ;;
			*) die_usage "force state: 1 (disabled) or 0 (enabled)" ;;
		esac
	else
		if [ "$_is_dis" = "1" ]; then
			_new_dis=0
		else
			_new_dis=1
		fi
	fi

	iface_luci_try_bg "iface-toggle-$_iface" sh "$LUCIRPC_SH" toggleEnabled "$_iface|$_new_dis" && return 0

	if [ "$_new_dis" = "1" ]; then
		printf '=== Отключение туннеля: %s ===\n' "$_iface"
		if grep -qE '^DISABLED=' "$_cfg"; then
			sed -i "s/^DISABLED=.*/DISABLED='1'/" "$_cfg"
		else
			printf "DISABLED='1'\n" >> "$_cfg"
		fi
		if [ -f "$SYSTEM_INTERFACES_DIR/$_iface/config/iface.conf" ]; then
			if grep -qE '^DISABLED=' "$SYSTEM_INTERFACES_DIR/$_iface/config/iface.conf"; then
				sed -i "s/^DISABLED=.*/DISABLED='1'/" "$SYSTEM_INTERFACES_DIR/$_iface/config/iface.conf"
			else
				printf "DISABLED='1'\n" >> "$SYSTEM_INTERFACES_DIR/$_iface/config/iface.conf"
			fi
		fi

		if uci -q get "network.$_iface" >/dev/null 2>&1; then
			uci set "network.$_iface.disabled=1"
			uci commit network
		fi
		if [ -f "/etc/config/openvpn" ] && uci -q get "openvpn.$_iface" >/dev/null 2>&1; then
			uci set "openvpn.$_iface.enabled=0"
			uci commit openvpn
			/etc/init.d/openvpn reload >/dev/null 2>&1 || true
		fi

		if command -v ifdown >/dev/null 2>&1; then
			ifdown "$_iface" >/dev/null 2>&1 || true
		fi

		printf 'Снятие правил маршрутизации...\n'
		sh "$APPLY_ROUTING_SH" --profile-dir "$PROFILE_DIR" --iface "$_iface"
		printf 'Туннель %s отключен, правила маршрутизации сняты.\n' "$_iface"
	else
		printf '=== Включение туннеля: %s ===\n' "$_iface"
		if grep -qE '^DISABLED=' "$_cfg"; then
			sed -i "s/^DISABLED=.*/DISABLED='0'/" "$_cfg"
		else
			printf "DISABLED='0'\n" >> "$_cfg"
		fi
		if [ -f "$SYSTEM_INTERFACES_DIR/$_iface/config/iface.conf" ]; then
			if grep -qE '^DISABLED=' "$SYSTEM_INTERFACES_DIR/$_iface/config/iface.conf"; then
				sed -i "s/^DISABLED=.*/DISABLED='0'/" "$SYSTEM_INTERFACES_DIR/$_iface/config/iface.conf"
			else
				printf "DISABLED='0'\n" >> "$SYSTEM_INTERFACES_DIR/$_iface/config/iface.conf"
			fi
		fi

		if uci -q get "network.$_iface" >/dev/null 2>&1; then
			uci -q delete "network.$_iface.disabled" || true
			uci commit network
		fi
		if command -v ifup >/dev/null 2>&1; then
			ifup "$_iface" >/dev/null 2>&1 || true
		fi
		if [ -f "/etc/config/openvpn" ] && uci -q get "openvpn.$_iface" >/dev/null 2>&1; then
			uci set "openvpn.$_iface.enabled=1"
			uci commit openvpn
			if [ -x "/etc/xfree-toolbox/iface-routing/openvpn/refresh-auth.sh" ]; then
				/etc/xfree-toolbox/iface-routing/openvpn/refresh-auth.sh "$_iface" >/dev/null 2>&1 || true
			elif [ -x "$ROOT_DIR/iface-routing/vpn/openvpn/refresh-auth.sh" ]; then
				sh "$ROOT_DIR/iface-routing/vpn/openvpn/refresh-auth.sh" "$_iface" >/dev/null 2>&1 || true
			fi
			/etc/init.d/openvpn restart "$_iface" >/dev/null 2>&1 || true
		fi

		printf 'Применение правил маршрутизации...\n'
		sh "$APPLY_ROUTING_SH" --profile-dir "$PROFILE_DIR" --iface "$_iface"

		printf 'Туннель %s включен и активирован.\n' "$_iface"
	fi
}


action_regenerate_one() {
	need_arg
	iface_luci_try_bg "iface-regenerate-$ARG" sh "$LUCIRPC_SH" regenerateOne "$ARG" && return 0
	run "Пересобрать конфиг: $ARG" "$REGENERATE_SH" --iface "$ARG" --force
}

action_regenerate_templates() {
	iface_luci_try_bg "iface-regenerate-templates" sh "$LUCIRPC_SH" regenerateTemplates && return 0
	printf '=== Пересобрать template-туннели ===\n'
	_n=0
	for _iface in $(list_template_ifaces); do
		_n=$((_n + 1))
		printf '\n-- %s --\n' "$_iface"
		sh "$REGENERATE_SH" --iface "$_iface" --force
	done
	[ "$_n" -gt 0 ] || printf 'Template-интерфейсы не найдены.\n'
}

action_regenerate_all() {
	iface_luci_try_bg "iface-regenerate-all" sh "$LUCIRPC_SH" regenerateAll && return 0
	printf '=== Пересобрать все туннели ===\n'
	_n=0
	for _iface in $(list_ifaces); do
		_n=$((_n + 1))
		printf '\n-- %s --\n' "$_iface"
		sh "$REGENERATE_SH" --iface "$_iface" --force
	done
	[ "$_n" -gt 0 ] || printf 'Интерфейсы не найдены.\n'
}

action_delete() {
	need_arg
	# arg: iface  or  iface|mode
	# mode: basic | reconcile | orphans | full  (default basic)
	_iface="${ARG%%|*}"
	_mode=basic
	case "$ARG" in
	*'|'*) _mode="${ARG#*|}" ;;
	esac
	_extra=""
	case "$_mode" in
	basic|"") _extra="" ;;
	reconcile) _extra="--full-reconcile" ;;
	orphans) _extra="--cleanup-orphans" ;;
	full) _extra="--full-reconcile --cleanup-orphans" ;;
	*) die_usage "delete mode: basic|reconcile|orphans|full" ;;
	esac
	iface_luci_try_bg "iface-delete-$_iface" sh "$LUCIRPC_SH" delete "$ARG" && return 0
	# shellcheck disable=SC2086
	run "Удалить туннель: $_iface ($_mode)" "$DELETE_SH" --iface "$_iface" --purge-files $_extra
}

resolve_conf_path() {
	_src="$1"
	case "$_src" in
	/*)
		[ -f "$_src" ] || die_usage "нет .conf: $_src"
		printf '%s\n' "$_src"
		return 0
		;;
	esac
	for _base in "$WARP_CONF_DIR" "$PROTON_CONF_DIR" "$PROFILE_VPN_DIR" "$SCRIPT_DIR/conf"; do
		[ -f "$_base/$_src" ] || continue
		printf '%s\n' "$_base/$_src"
		return 0
	done
	die_usage "нет .conf: $_src (искали в warp/proton/vpn/conf)"
}

action_list_confs() {
	printf '=== Последние .conf ===\n'
	for _label_dir in "warp|$WARP_CONF_DIR" "proton|$PROTON_CONF_DIR"; do
		_lab="${_label_dir%%|*}"
		_dir="${_label_dir#*|}"
		printf '\n[%s] %s\n' "$_lab" "$_dir"
		if [ -d "$_dir" ]; then
			find "$_dir" -maxdepth 1 -type f -name '*.conf' 2>/dev/null | sort | tail -n 20 | while IFS= read -r _f; do
				[ -n "$_f" ] || continue
				printf '  %s\n' "$(basename "$_f")"
			done
		else
			printf '  (каталог отсутствует)\n'
		fi
	done
}

resolve_conf_kind_path() {
	_kind="$1"
	_file="$2"
	case "$_kind" in
	warp) _base="$WARP_CONF_DIR" ;;
	proton) _base="$PROTON_CONF_DIR" ;;
	*) die_usage "conf kind: warp|proton" ;;
	esac
	case "$_file" in
	*/*|*'..'*|*'|'*) die_usage "некорректное имя .conf" ;;
	esac
	_path="$_base/$_file"
	[ -f "$_path" ] || die_usage "нет $_path"
	printf '%s\n' "$_path"
}

# arg: kind|file
action_conf_show() {
	need_arg
	_kind="${ARG%%|*}"
	_file="${ARG#*|}"
	[ -n "$_kind" ] && [ -n "$_file" ] && [ "$_kind" != "$ARG" ] || \
		die_usage "arg: <warp|proton>|<file.conf>"
	_path="$(resolve_conf_kind_path "$_kind" "$_file")"
	printf '=== %s / %s ===\n' "$_kind" "$_file"
	printf 'CONF_BODY_BEGIN\n'
	cat "$_path"
	printf '\nCONF_BODY_END\n'
	if [ -f "${_path}.meta" ]; then
		printf 'META_BODY_BEGIN\n'
		cat "${_path}.meta"
		printf '\nMETA_BODY_END\n'
	fi
}

# arg: kind|file
action_conf_delete() {
	need_arg
	iface_luci_try_bg "iface-conf-delete" sh "$LUCIRPC_SH" confDelete "$ARG" && return 0
	_kind="${ARG%%|*}"
	_file="${ARG#*|}"
	[ -n "$_kind" ] && [ -n "$_file" ] && [ "$_kind" != "$ARG" ] || \
		die_usage "arg: <warp|proton>|<file.conf>"
	_path="$(resolve_conf_kind_path "$_kind" "$_file")"
	printf '=== Удалить %s / %s ===\n' "$_kind" "$_file"
	rm -f "$_path" "${_path}.meta"
	printf 'OK deleted %s\n' "$_file"
}

# arg: [kind] (warp|proton or empty for all)
action_conf_delete_unused() {
	iface_luci_try_bg "iface-conf-delete-unused" sh "$LUCIRPC_SH" confDeleteUnused "${ARG:-}" && return 0
	_filter="${ARG:-}"
	case "$_filter" in
	warp) _dirs="warp|$WARP_CONF_DIR" ;;
	proton) _dirs="proton|$PROTON_CONF_DIR" ;;
	"") _dirs="warp|$WARP_CONF_DIR proton|$PROTON_CONF_DIR" ;;
	*) die_usage "arg: [warp|proton]" ;;
	esac

	printf '=== Удаление неиспользуемых .conf ===\n'
	_deleted=0
	_skipped=0
	for _label_dir in $_dirs; do
		_lab="${_label_dir%%|*}"
		_dir="${_label_dir#*|}"
		[ -d "$_dir" ] || continue
		for _f in "$_dir"/*.conf; do
			[ -f "$_f" ] || continue
			_fname="$(basename "$_f")"
			_used_by="$(conf_find_used_by "$_f" || true)"
			if [ -n "$_used_by" ]; then
				_skipped=$((_skipped + 1))
				printf 'Пропуск %s: используется в [%s]\n' "$_fname" "$_used_by"
			else
				rm -f "$_f" "${_f}.meta"
				_deleted=$((_deleted + 1))
				printf 'Удалён %s / %s\n' "$_lab" "$_fname"
			fi
		done
	done
	printf 'Всего удалено: %d, пропущено (в работе): %d\n' "$_deleted" "$_skipped"
}

# arg: kind|file|<body with newlines as \n escaped OR use HERE - better: base64>
# Use: kind|file|b64:<base64>
action_conf_save() {
	need_arg
	_kind="${ARG%%|*}"
	_rest="${ARG#*|}"
	_file="${_rest%%|*}"
	_payload="${_rest#*|}"
	[ -n "$_kind" ] && [ -n "$_file" ] && [ "$_file" != "$_rest" ] || \
		die_usage "arg: <warp|proton>|<file.conf>|b64:<data>"
	case "$_kind" in
	warp) _base="$WARP_CONF_DIR" ;;
	proton) _base="$PROTON_CONF_DIR" ;;
	*) die_usage "conf kind: warp|proton" ;;
	esac
	case "$_file" in
	*/*|*'..'*|*'|'*) die_usage "некорректное имя .conf" ;;
	*.conf) ;;
	*) die_usage "ожидается *.conf" ;;
	esac
	mkdir -p "$_base"
	_path="$_base/$_file"
	case "$_payload" in
	b64:*)
		_b64="${_payload#b64:}"
		printf '%s' "$_b64" | base64 -d >"$_path" || die_usage "base64 decode failed"
		;;
	*)
		die_usage "payload: b64:<base64>"
		;;
	esac
	printf '=== Сохранён %s / %s (%s bytes) ===\n' "$_kind" "$_file" "$(wc -c <"$_path" | tr -d ' ')"
}

# arg: iface — dump source.conf.meta as KEY=value lines for LuCI dialog
action_iface_meta() {
	need_arg
	_meta="$INTERFACES_DIR/$ARG/config/source.conf.meta"
	[ -f "$_meta" ] || _meta="$INTERFACES_DIR/$ARG/config/source.ovpn.meta"
	[ -f "$_meta" ] || die_usage "нет meta: $_meta"
	printf '=== Meta %s ===\n' "$ARG"
	printf 'IFACE=%s\n' "$ARG"
	while IFS= read -r _line || [ -n "$_line" ]; do
		_line="$(printf '%s' "$_line" | tr -d '\r')"
		[ -n "$_line" ] || continue
		case "$_line" in
		\#*) continue ;;
		*=*)
			_k="${_line%%=*}"
			_v="${_line#*=}"
			_v="$(printf '%s' "$_v" | sed "s/^'//;s/'$//")"
			printf 'META_%s=%s\n' "$_k" "$_v"
			;;
		esac
	done <"$_meta"

	_creds="$INTERFACES_DIR/$ARG/config/credentials.env"
	if [ -f "$_creds" ]; then
		_user="$(grep -E '^AUTH_USER=' "$_creds" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
		[ -n "$_user" ] && printf 'META_AUTH_USER=%s\n' "$_user"
		if grep -qE '^AUTH_PASS=' "$_creds" 2>/dev/null; then
			printf 'META_HAS_PASS=1\n'
		fi
		if grep -qE '^TOTP_SECRET=' "$_creds" 2>/dev/null; then
			printf 'META_HAS_TOTP=1\n'
		fi
	fi

	if [ -f "$INTERFACES_DIR/$ARG/config/iface.conf" ]; then
		_tip="$(grep -E '^TEST_IP=' "$INTERFACES_DIR/$ARG/config/iface.conf" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
		if [ -n "$_tip" ]; then
			printf 'META_TEST_IP=%s\n' "$_tip"
		fi
		_dns="$(grep -E '^DNS_VALUE=' "$INTERFACES_DIR/$ARG/config/iface.conf" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
		if [ -n "$_dns" ]; then
			printf 'META_DNS_VALUE=%s\n' "$_dns"
		fi
	fi
	return 0
}

meta_set_key() {
	_file="$1"
	_key="$2"
	_val="$3"
	_tmp="${_file}.tmp.$$"
	_found=0
	if [ -f "$_file" ]; then
		while IFS= read -r _line || [ -n "$_line" ]; do
			_line="$(printf '%s' "$_line" | tr -d '\r')"
			case "$_line" in
			"${_key}="*)
				printf "%s='%s'\n" "$_key" "$_val"
				_found=1
				;;
			*)
				printf '%s\n' "$_line"
				;;
			esac
		done <"$_file" >"$_tmp"
	else
		: >"$_tmp"
	fi
	[ "$_found" = "1" ] || printf "%s='%s'\n" "$_key" "$_val" >>"$_tmp"
	mv -f "$_tmp" "$_file"
}

# arg: iface|server=…|selection=…|exclude_ru=…|profile=…|mode=…|… (warp)
#  or: iface|country=…|session_mode=…|profile=…|mtu=… (proton)
action_regenerate_opts() {
	need_arg
	iface_luci_try_bg "iface-regenerate-opts" sh "$LUCIRPC_SH" regenerateOpts "$ARG" && return 0
	_iface="${ARG%%|*}"
	_opts="${ARG#*|}"
	[ -n "$_iface" ] && [ "$_iface" != "$ARG" ] || die_usage "arg: <iface>|key=val|…"
	_meta="$INTERFACES_DIR/$_iface/config/source.conf.meta"
	[ -f "$_meta" ] || die_usage "нет $_meta"
	_kind="$(meta_get "$_meta" GENERATOR_KIND)"
	_kind="$(printf '%s' "$_kind" | tr -d "'\"")"
	if [ "$_kind" = "warp" ]; then
		_wmp="$SCRIPT_DIR/vpn/lib/warp-meta-policy.sh"
		if [ -f "$_wmp" ]; then
			# shellcheck disable=SC1090
			. "$_wmp"
			warp_meta_policy_migrate_file "$_meta" >/dev/null || true
		fi
	fi
	_old_ifs="$IFS"
	IFS='|'
	# shellcheck disable=SC2086
	set -- $_opts
	IFS="$_old_ifs"
	_prof=""
	_session_mode=""
	for _pair in "$@"; do
		_k="${_pair%%=*}"
		_v="${_pair#*=}"
		[ "$_k" = "$_pair" ] && continue
		case "$_kind" in
		warp)
			case "$_k" in
			server)
				meta_set_key "$_meta" SERVER_ID "$_v"
				meta_set_key "$_meta" SERVER_NAME "$(printf '%s' "$_v" | tr 'a-z' 'A-Z')"
				meta_set_key "$_meta" COUNTRY_FILTER "$(printf '%s' "$_v" | tr 'a-z' 'A-Z')"
				;;
			selection) meta_set_key "$_meta" SELECTION_MODE "$_v" ;;
			exclude_ru) meta_set_key "$_meta" EXCLUDE_RU "$_v" ;;
			max_servers) meta_set_key "$_meta" MAX_SERVERS "$_v" ;;
			mode) meta_set_key "$_meta" PROFILE_MODE "$_v" ;;
			i1_mode) meta_set_key "$_meta" I1_MODE "$_v" ;;
			i1_domain) meta_set_key "$_meta" I1_DOMAIN "$_v" ;;
			profile) _prof="$_v" ;;
			name) ;;
			*) warn "regenerateOpts warp: ignore $_k" ;;
			esac
			;;
		proton)
			case "$_k" in
			country) meta_set_key "$_meta" SERVER_COUNTRY "$_v"; meta_set_key "$_meta" COUNTRY_FILTER "$_v" ;;
			session_mode) _session_mode="$_v" ;;
			profile) _prof="$_v" ;;
			mode) meta_set_key "$_meta" PROFILE_MODE "$_v" ;;
			awg_noise) meta_set_key "$_meta" AWG_NOISE_ENABLED "$_v" ;;
			i1_entropy)
				meta_set_key "$_meta" AWG_I1_ENTROPY "$_v"
				case "$_v" in
				off) meta_set_key "$_meta" AWG_I1_ENTROPY_ENABLED "0" ;;
				*) meta_set_key "$_meta" AWG_I1_ENTROPY_ENABLED "1" ;;
				esac
				;;
			mtu) meta_set_key "$_meta" MTU "$_v" ;;
			free_only) meta_set_key "$_meta" FREE_ONLY "$_v" ;;
			require_ipv6) meta_set_key "$_meta" REQUIRE_IPV6 "$_v" ;;
			selection_mode) meta_set_key "$_meta" SELECTION_MODE "$_v" ;;
			name) ;;
			*) warn "regenerateOpts proton: ignore $_k" ;;
			esac
			;;
		*)
			die "regenerateOpts: неизвестный GENERATOR_KIND=$_kind"
			;;
		esac
	done
	if [ -n "$_prof" ]; then
		_ver="${_prof%%:*}"
		_var="${_prof##*:}"
		case "$_var" in 1|2|3) ;; *) _var=1 ;; esac
		meta_set_key "$_meta" VARIANT_ID "$_var"
		case "$_kind" in
		proton)
			case "$_ver" in 1.5|2.0) ;; *) _ver=2.0 ;; esac
			meta_set_key "$_meta" AWG_VERSION "$_ver"
			;;
		warp)
			meta_set_key "$_meta" AWG_VERSION "2.0"
			;;
		esac
	fi
	if [ "$_kind" = "proton" ] && [ -n "$_session_mode" ]; then
		case "$(printf '%s' "$_session_mode" | tr 'A-Z' 'a-z')" in
		guest) meta_set_key "$_meta" SESSION_AUTH_MODE "guest" ;;
		permanent|named|web) meta_set_key "$_meta" SESSION_AUTH_MODE "web" ;;
		esac
	fi
	printf '=== Пересобрать %s с обновлёнными параметрами ===\n' "$_iface"
	sh "$REGENERATE_SH" --iface "$_iface" --force
	printf '\n=== Применить %s ===\n' "$_iface"
	sh "$APPLY_SH" --iface "$_iface"
}

action_create() {
	need_arg
	# arg: iface|source.conf-basename-or-path
	_iface="${ARG%%|*}"
	_src="${ARG#*|}"
	[ -n "$_iface" ] && [ -n "$_src" ] && [ "$_iface" != "$ARG" ] || \
		die_usage "arg: <iface>|<source.conf>"
	_path="$(resolve_conf_path "$_src")"
	iface_luci_try_bg "iface-create-$_iface" sh "$LUCIRPC_SH" createFromConf "$ARG" && return 0
	run "Создать туннель $_iface из $(basename "$_path")" \
		"$CONVERTER_SH" --iface "$_iface" --source "$_path"
}

action_create_from_ovpn() {
	need_arg
	# arg: iface|source.ovpn[|user|pass|totp|apply]
	_iface="$(printf '%s' "$ARG" | awk -F'|' '{print $1}')"
	_src="$(printf '%s' "$ARG" | awk -F'|' '{print $2}')"
	_user="$(printf '%s' "$ARG" | awk -F'|' '{print $3}')"
	_pass="$(printf '%s' "$ARG" | awk -F'|' '{print $4}')"
	_totp="$(printf '%s' "$ARG" | awk -F'|' '{print $5}')"
	_apply="$(printf '%s' "$ARG" | awk -F'|' '{print $6}')"
	_fmt="$(printf '%s' "$ARG" | awk -F'|' '{print $7}')"
	_test_ip="$(printf '%s' "$ARG" | awk -F'|' '{print $8}')"
	_dns="$(printf '%s' "$ARG" | awk -F'|' '{print $9}')"

	[ -n "$_iface" ] || die_usage "arg: <iface>|[source.ovpn][|<user>|<pass>|<totp>|<apply>|<format>|<test_ip>|<dns>]"
	_tmp_ovpn=""
	if case "$_src" in b64:*) true ;; *) false ;; esac; then
		_b64="${_src#b64:}"
		_tmp_ovpn="/tmp/ovpn_upload_${_iface}.ovpn"
		printf '%s' "$_b64" | base64 -d >"$_tmp_ovpn" || die_usage "ошибка декодирования содержимого .ovpn (base64)"
		_path="$_tmp_ovpn"
		_src="$_tmp_ovpn"
	elif [ -z "$_src" ] && [ -f "$INTERFACES_DIR/$_iface/config/source.ovpn" ]; then
		_path="$INTERFACES_DIR/$_iface/config/source.ovpn"
	else
		[ -n "$_src" ] || die_usage "arg: <iface>|<source.ovpn>[|<user>|<pass>|<totp>|<apply>|<format>]"
		_path="$(resolve_conf_path "$_src")"
	fi

	_tmp_cred=""
	if case "$_pass" in env:*) true ;; *) false ;; esac; then
		_cred_file="${_pass#env:}"
		if [ -f "$_cred_file" ]; then
			# shellcheck disable=SC1090
			. "$_cred_file"
			rm -f "$_cred_file"
			_pass="${AUTH_PASS:-}"
			_totp="${TOTP_SECRET:-}"
			_fmt="${TOTP_AUTH_FORMAT:-}"
			[ -n "${AUTH_USER:-}" ] && _user="$AUTH_USER"
		fi
	elif [ -n "$_pass" ] || [ -n "$_totp" ] || [ -n "$_fmt" ]; then
		_tmp_cred="/tmp/ovpn_cred_${_iface}.env"
		(
			touch "$_tmp_cred"
			chmod 600 "$_tmp_cred"
			printf 'AUTH_USER=%s\nAUTH_PASS=%s\nTOTP_SECRET=%s\nTOTP_AUTH_FORMAT=%s\n' \
				"$_user" "$_pass" "$_totp" "${_fmt:-scrv1}" >"$_tmp_cred"
		)
		ARG="$_iface|$_src|$_user|env:$_tmp_cred||$_apply|$_fmt|$_test_ip|$_dns"
	else
		ARG="$_iface|$_src|$_user|||$_apply|$_fmt|$_test_ip|$_dns"
	fi

	iface_luci_try_bg "iface-create-ovpn-$_iface" sh "$LUCIRPC_SH" createFromOvpn "$ARG" && return 0

	_ovpn_converter="$ROOT_DIR/iface-routing/vpn/openvpn/ovpn-to-interface.sh"
	[ -x "$_ovpn_converter" ] || die_usage "не найден конвертер: $_ovpn_converter"

	printf '=== Настройка OpenVPN интерфейса: %s ===\n' "$_iface"
	set -- "$_ovpn_converter" --iface "$_iface" --source "$_path"
	[ -n "$_user" ] && set -- "$@" --auth-user "$_user"
	[ -n "$_pass" ] && set -- "$@" --auth-pass "$_pass"
	[ -n "$_totp" ] && set -- "$@" --totp-secret "$_totp"
	[ -n "$_fmt" ] && set -- "$@" --auth-format "$_fmt"
	[ -n "$_test_ip" ] && set -- "$@" --test-ip "$_test_ip"
	[ -n "$_dns" ] && set -- "$@" --dns "$_dns"
	"$@"
	[ -n "$_tmp_ovpn" ] && rm -f "$_tmp_ovpn"
	[ -n "$_tmp_cred" ] && rm -f "$_tmp_cred"

	_ensure_ovpn="$ROOT_DIR/iface-routing/vpn/openvpn/ensure-openvpn.sh"
	if [ -x "$_ensure_ovpn" ]; then
		if ! "$_ensure_ovpn" --check >/dev/null 2>&1; then
			printf '\n[*] Установка пакета OpenVPN в систему (~0.4 MB)...\n'
			"$_ensure_ovpn" --install-if-missing || true
		fi
	fi

	if [ "$_apply" = "1" ]; then
		printf '\n[*] Применение интерфейса %s на роутере...\n' "$_iface"
		sh "$APPLY_SH" --iface "$_iface"
	fi
}

action_protocols_status() {
	if [ -f "$ROOT_DIR/iface-routing/vpn/protocols/protocols.sh" ]; then
		# shellcheck disable=SC1090
		. "$ROOT_DIR/iface-routing/vpn/protocols/protocols.sh"
		printf 'AWG=%s\n' "$(proto_awg_status_label)"
		printf 'OPENVPN=%s\n' "$(proto_openvpn_status_label)"
		printf 'VLESS=%s\n' "$(proto_vless_status_label)"
		printf 'FREETURN=%s\n' "$(proto_freeturn_status_label)"
	fi
}

action_protocols_install() {
	need_arg
	_proto="$ARG"
	iface_luci_try_bg "proto-install-$_proto" sh "$LUCIRPC_SH" protocolsInstall "$_proto" && return 0
	# shellcheck disable=SC1090
	. "$ROOT_DIR/iface-routing/vpn/protocols/protocols.sh"
	case "$_proto" in
	awg)
		printf '=== Установка AmneziaWG ===\n'
		proto_awg_install
		;;
	openvpn)
		printf '=== Установка OpenVPN ===\n'
		proto_openvpn_install
		;;
	vless)
		printf '=== Установка sing-box (VLESS) ===\n'
		proto_vless_install
		;;
	freeturn)
		printf '=== Установка FreeTurn Client ===\n'
		proto_freeturn_install
		;;
	*)
		die_usage "unknown protocol: $_proto"
		;;
	esac
}

action_protocols_remove() {
	need_arg
	_proto="$ARG"
	iface_luci_try_bg "proto-remove-$_proto" sh "$LUCIRPC_SH" protocolsRemove "$_proto" && return 0
	# shellcheck disable=SC1090
	. "$ROOT_DIR/iface-routing/vpn/protocols/protocols.sh"
	case "$_proto" in
	openvpn)
		printf '=== Удаление OpenVPN ===\n'
		proto_openvpn_remove
		;;
	vless)
		printf '=== Удаление sing-box (VLESS) ===\n'
		proto_vless_remove
		;;
	freeturn)
		printf '=== Удаление FreeTurn Client ===\n'
		proto_freeturn_remove
		;;
	*)
		die_usage "cannot remove protocol: $_proto"
		;;
	esac
}

action_update() {
	need_arg
	_iface="${ARG%%|*}"
	_src="${ARG#*|}"
	[ -n "$_iface" ] && [ -n "$_src" ] && [ "$_iface" != "$ARG" ] || \
		die_usage "arg: <iface>|<source.conf>"
	_path="$(resolve_conf_path "$_src")"
	iface_luci_try_bg "iface-update-$_iface" sh "$LUCIRPC_SH" updateFromConf "$ARG" && return 0
	run "Обновить туннель $_iface из $(basename "$_path")" \
		"$UPDATE_SH" --iface "$_iface" --source "$_path"
}

action_warp_status() {
	_state="/tmp/domain-routing-warp"
	printf '=== WARP генератор: параметры ===\n'
	printf 'Каталог .conf: %s\n' "$WARP_CONF_DIR"
	for _k in server profile mode i1_mode i1_domain name selection exclude_ru max_servers; do
		_v=""
		[ -f "$_state/$_k" ] && _v="$(tr -d '\r\n' <"$_state/$_k")"
		case "$_k" in
		server) [ -n "$_v" ] || _v="xfree" ;;
		profile) [ -n "$_v" ] || _v="2.0:1" ;;
		mode) [ -n "$_v" ] || _v="local" ;;
		i1_mode) [ -n "$_v" ] || _v="fixed" ;;
		selection) [ -n "$_v" ] || _v="best" ;;
		exclude_ru) [ -n "$_v" ] || _v="1" ;;
		max_servers) [ -n "$_v" ] || _v="50" ;;
		esac
		[ -n "$_v" ] || _v="—"
		printf '%s: %s\n' "$_k" "$_v"
	done
}

# arg: server=…|profile=…|mode=…|i1_mode=…|i1_domain=…|name=…|selection=…|exclude_ru=…|max_servers=…
action_warp_save() {
	need_arg
	_state="/tmp/domain-routing-warp"
	mkdir -p "$_state"
	_old_ifs="$IFS"
	IFS='|'
	# shellcheck disable=SC2086
	set -- $ARG
	IFS="$_old_ifs"
	for _pair in "$@"; do
		_k="${_pair%%=*}"
		_v="${_pair#*=}"
		[ "$_k" = "$_pair" ] && continue
		case "$_k" in
		server|profile|mode|i1_mode|i1_domain|name|selection|exclude_ru|max_servers)
			printf '%s\n' "$_v" >"$_state/$_k"
			;;
		*)
			die_usage "warpSave: неизвестный ключ $_k"
			;;
		esac
	done
	printf '=== WARP: параметры сохранены ===\n'
	action_warp_status
}

action_warp_generate() {
	iface_luci_try_bg "iface-warp-generate" sh "$LUCIRPC_SH" warpGenerate && return 0
	[ -f "$WARP_GEN_SH" ] || die_usage "нет $WARP_GEN_SH"
	_state="/tmp/domain-routing-warp"
	_srv="xfree"
	_prof="2.0:1"
	_mode="local"
	_i1="fixed"
	_dom=""
	_name=""
	_sel="best"
	_exclude_ru="1"
	_max_servers="50"
	[ -f "$_state/server" ] && _srv="$(tr -d '\r\n' <"$_state/server")"
	[ -f "$_state/profile" ] && _prof="$(tr -d '\r\n' <"$_state/profile")"
	[ -f "$_state/mode" ] && _mode="$(tr -d '\r\n' <"$_state/mode")"
	[ -f "$_state/i1_mode" ] && _i1="$(tr -d '\r\n' <"$_state/i1_mode")"
	[ -f "$_state/i1_domain" ] && _dom="$(tr -d '\r\n' <"$_state/i1_domain")"
	[ -f "$_state/name" ] && _name="$(tr -d '\r\n' <"$_state/name")"
	[ -f "$_state/selection" ] && _sel="$(tr -d '\r\n' <"$_state/selection")"
	[ -f "$_state/exclude_ru" ] && _exclude_ru="$(tr -d '\r\n' <"$_state/exclude_ru")"
	[ -f "$_state/max_servers" ] && _max_servers="$(tr -d '\r\n' <"$_state/max_servers")"
	_var="${_prof##*:}"
	case "$_var" in
	1|2|3) ;;
	*) _var=1 ;;
	esac
	case "$_mode" in
	raw|local) ;;
	*) _mode=local ;;
	esac
	case "$_sel" in
	best|random) ;;
	*) _sel=best ;;
	esac
	case "$_exclude_ru" in
	1|yes|on|true|YES|TRUE) _exclude_ru=1 ;;
	*) _exclude_ru=0 ;;
	esac
	case "$_max_servers" in
	''|*[!0-9]*) _max_servers=50 ;;
	esac
	[ "$_max_servers" -gt 0 ] 2>/dev/null || _max_servers=50
	set -- "$WARP_GEN_SH" --server "$_srv" --variant "$_var" "--$_mode" --i1-mode "$_i1" --max-servers "$_max_servers"
	case "$_sel" in
	random) set -- "$@" --random ;;
	*) set -- "$@" --best ;;
	esac
	if [ "$_exclude_ru" = "1" ]; then
		set -- "$@" --exclude-ru
	else
		set -- "$@" --allow-ru
	fi
	[ -n "$_dom" ] && set -- "$@" --i1-domain "$_dom"
	[ -n "$_name" ] && set -- "$@" --name "$_name"
	run "WARP: сгенерировать конфиг" "$@"
}

luci_provision_finish() {
	_iface="$1"
	_log="$2"
	_src=""
	[ -n "$_iface" ] || die "provision: пустое имя интерфейса"
	[ -f "$_log" ] || die "provision: нет лога generate"
	_src="$(grep '^SOURCE=' "$_log" | head -n 1 | cut -d= -f2- | tr -d '\r\n')"
	[ -n "$_src" ] || die "generate не вернул SOURCE= (см. лог выше)"
	[ -f "$_src" ] || die "нет файла SOURCE: $_src"
	_base="$(basename "$_src")"
	[ -f "$CONVERTER_SH" ] || die_usage "нет $CONVERTER_SH"
	printf '\n=== Создать интерфейс %s из %s ===\n' "$_iface" "$_base"
	sh "$CONVERTER_SH" --iface "$_iface" --source "$_src"
	printf '\n=== Применить %s ===\n' "$_iface"
	sh "$APPLY_SH" --iface "$_iface"
	printf 'PROVISION_OK=1\n'
	printf 'IFACE=%s\n' "$_iface"
	printf 'SOURCE=%s\n' "$_src"
}

# arg: <iface>|server=…|profile=…|…  (как warpSave + generate + create + apply)
action_warp_provision() {
	iface_luci_try_bg "iface-warp-provision" sh "$LUCIRPC_SH" warpProvision "$ARG" && return 0
	need_arg
	_iface="${ARG%%|*}"
	_save="${ARG#*|}"
	[ -n "$_iface" ] && [ "$_iface" != "$ARG" ] || \
		die_usage "warpProvision: <iface>|server=…|…"
	ARG="$_save"
	action_warp_save
	_gen_log="$(mktemp "${TMPDIR:-/tmp}/luci-warp-provision.XXXXXX")"
	trap 'rm -f "$_gen_log"' EXIT INT TERM
	printf '=== WARP: генерация для нового интерфейса %s ===\n' "$_iface"
	# shellcheck disable=SC2034
	ARG=""
	IFACE_LUCI_FOREGROUND=1
	export IFACE_LUCI_FOREGROUND
	if ! action_warp_generate >"$_gen_log" 2>&1; then
		cat "$_gen_log"
		exit 1
	fi
	cat "$_gen_log"
	luci_provision_finish "$_iface" "$_gen_log"
}

action_proton_status() {
	_state="/tmp/domain-routing-proton"
	printf '=== Proton генератор: параметры ===\n'
	printf 'Каталог .conf: %s\n' "$PROTON_CONF_DIR"
	for _k in country session_mode profile mode name mtu free_only require_ipv6 selection_mode awg_noise i1_entropy; do
		_v=""
		[ -f "$_state/$_k" ] && _v="$(tr -d '\r\n' <"$_state/$_k")"
		case "$_k" in
		country) [ -n "$_v" ] || _v="NL" ;;
		session_mode) [ -n "$_v" ] || _v="guest" ;;
		profile) [ -n "$_v" ] || _v="2.0:1" ;;
		mode) [ -n "$_v" ] || _v="local" ;;
		mtu) [ -n "$_v" ] || _v="1280" ;;
		free_only) [ -n "$_v" ] || _v="1" ;;
		require_ipv6) [ -n "$_v" ] || _v="0" ;;
		selection_mode) [ -n "$_v" ] || _v="best" ;;
		awg_noise) [ -n "$_v" ] || _v="0" ;;
		i1_entropy) [ -n "$_v" ] || _v="r32" ;;
		esac
		[ -n "$_v" ] || _v="—"
		printf '%s: %s\n' "$_k" "$_v"
	done
}

# arg: country=…|session_mode=…|profile=…|name=…|mtu=…|free_only=…|require_ipv6=…|selection_mode=…
action_proton_save() {
	need_arg
	_state="/tmp/domain-routing-proton"
	mkdir -p "$_state"
	_old_ifs="$IFS"
	IFS='|'
	# shellcheck disable=SC2086
	set -- $ARG
	IFS="$_old_ifs"
	for _pair in "$@"; do
		_k="${_pair%%=*}"
		_v="${_pair#*=}"
		[ "$_k" = "$_pair" ] && continue
		case "$_k" in
		country|session_mode|profile|mode|name|mtu|free_only|require_ipv6|selection_mode|session|awg_noise|i1_entropy)
			printf '%s\n' "$_v" >"$_state/$_k"
			;;
		*)
			die_usage "protonSave: неизвестный ключ $_k"
			;;
		esac
	done
	printf '=== Proton: параметры сохранены ===\n'
	action_proton_status
}

action_proton_generate() {
	iface_luci_try_bg "iface-proton-generate" sh "$LUCIRPC_SH" protonGenerate && return 0
	[ -f "$PROTON_GEN_SH" ] || die_usage "нет $PROTON_GEN_SH"
	_state="/tmp/domain-routing-proton"
	_country="NL"
	_session_mode="guest"
	_prof="2.0:1"
	_mode="local"
	_mtu="1280"
	_free_only="1"
	_require_ipv6="0"
	_sel="best"
	_name=""
	_session=""
	[ -f "$_state/country" ] && _country="$(tr -d '\r\n' <"$_state/country")"
	[ -f "$_state/session_mode" ] && _session_mode="$(tr -d '\r\n' <"$_state/session_mode")"
	[ -f "$_state/profile" ] && _prof="$(tr -d '\r\n' <"$_state/profile")"
	[ -f "$_state/mode" ] && _mode="$(tr -d '\r\n' <"$_state/mode")"
	[ -f "$_state/mtu" ] && _mtu="$(tr -d '\r\n' <"$_state/mtu")"
	[ -f "$_state/free_only" ] && _free_only="$(tr -d '\r\n' <"$_state/free_only")"
	[ -f "$_state/require_ipv6" ] && _require_ipv6="$(tr -d '\r\n' <"$_state/require_ipv6")"
	[ -f "$_state/selection_mode" ] && _sel="$(tr -d '\r\n' <"$_state/selection_mode")"
	[ -f "$_state/name" ] && _name="$(tr -d '\r\n' <"$_state/name")"
	[ -f "$_state/session" ] && _session="$(tr -d '\r\n' <"$_state/session")"
	[ -n "$_country" ] || _country="NL"
	[ -n "$_session_mode" ] || _session_mode="guest"
	case "$_mode" in
	raw|local) ;;
	*) _mode="local" ;;
	esac
	_ver="${_prof%%:*}"
	_var="${_prof##*:}"
	case "$_var" in
	1|2|3) ;;
	*) _var=1 ;;
	esac
	case "$_ver" in
	1.5|2.0) ;;
	*) _ver=2.0 ;;
	esac
	set -- "$PROTON_GEN_SH" "--$_mode" --country "$_country" --version "$_ver" --variant "$_var" --mtu "$_mtu"
	case "$(printf '%s' "$_session_mode" | tr 'A-Z' 'a-z')" in
	guest)
		set -- "$@" --acquire-guest
		;;
	permanent|named)
		[ -n "$_session" ] || die "Proton: постоянная сессия — выберите каталог сессии (CLI/menu) или «гостевая»"
		set -- "$@" --session "$_session"
		;;
	*)
		die "Proton: неизвестный session_mode=$_session_mode (guest|permanent)"
		;;
	esac
	case "$_free_only" in
	1|yes|YES|true|TRUE) set -- "$@" --free-only ;;
	*) set -- "$@" --all-tiers ;;
	esac
	case "$_require_ipv6" in
	1|yes|YES|true|TRUE) set -- "$@" --ipv6-only ;;
	*) set -- "$@" --all-ip ;;
	esac
	case "$_sel" in
	interactive) set -- "$@" --interactive ;;
	random) set -- "$@" --best ;;
	*) set -- "$@" --best ;;
	esac
	[ -n "$_name" ] && set -- "$@" --name "$_name"
	if [ -f "$_state/awg_noise" ]; then
		_noise="$(tr -d '\r\n' <"$_state/awg_noise")"
		case "$_noise" in
		1|yes|YES|true|TRUE) set -- "$@" --with-noise ;;
		esac
	fi
	if [ -f "$_state/i1_entropy" ]; then
		_ent="$(tr -d '\r\n' <"$_state/i1_entropy")"
		[ -n "$_ent" ] && set -- "$@" --i1-entropy "$_ent"
	fi
	run "Proton: сгенерировать (raw, API)" "$@"
}

# arg: <iface>|country=…|session_mode=…|…
action_proton_provision() {
	iface_luci_try_bg "iface-proton-provision" sh "$LUCIRPC_SH" protonProvision "$ARG" && return 0
	need_arg
	_iface="${ARG%%|*}"
	_save="${ARG#*|}"
	[ -n "$_iface" ] && [ "$_iface" != "$ARG" ] || \
		die_usage "protonProvision: <iface>|country=…|…"
	ARG="$_save"
	action_proton_save
	_gen_log="$(mktemp "${TMPDIR:-/tmp}/luci-proton-provision.XXXXXX")"
	trap 'rm -f "$_gen_log"' EXIT INT TERM
	printf '=== Proton: генерация для нового интерфейса %s ===\n' "$_iface"
	ARG=""
	IFACE_LUCI_FOREGROUND=1
	export IFACE_LUCI_FOREGROUND
	if ! action_proton_generate >"$_gen_log" 2>&1; then
		cat "$_gen_log"
		exit 1
	fi
	cat "$_gen_log"
	luci_provision_finish "$_iface" "$_gen_log"
}

action_selfroute_status() {
	printf '=== Self-route ===\n'
	_any=0
	for _cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
		[ -f "$_cfg" ] || continue
		_target="$(iface_conf_get "$_cfg" INTERFACE_NAME)"
		_via="$(iface_conf_get "$_cfg" SELF_ROUTE_VIA)"
		[ -n "$_via" ] || continue
		[ -n "$_target" ] || _target="$(basename "$(dirname "$(dirname "$_cfg")")")"
		_any=1
		printf '%s -> %s\n' "$_target" "$_via"
	done
	[ "$_any" -eq 1 ] || printf 'SELF_ROUTE_VIA не задан ни у одного туннеля.\n'
	if [ -f /etc/hotplug.d/iface/95-xfree-toolbox-self-route ]; then
		printf '\nhotplug: установлен\n'
	else
		printf '\nhotplug: нет\n'
	fi
}

action_selfroute_apply() {
	need_arg
	# arg: target|via
	_target="${ARG%%|*}"
	_via="${ARG#*|}"
	[ -n "$_target" ] && [ -n "$_via" ] && [ "$_target" != "$ARG" ] || \
		die_usage "arg: <target-iface>|<via-iface>"
	run "Self-route: $_target -> $_via" "$SELF_ROUTE_SH" --iface "$_target" --via "$_via"
}

action_selfroute_remove() {
	need_arg
	run "Self-route: удалить $ARG" "$SELF_ROUTE_SH" --iface "$ARG" --remove
}

action_selfroute_rebuild() {
	run "Self-route: rebuild hotplug" "$SELF_ROUTE_SH" --rebuild-hotplug
}

action_selfroute_refresh() {
	run "Self-route: runtime host-routes" "$SELF_ROUTE_SH" --run-hotplug
}

action_selfroute_cleanup() {
	run "Self-route: cleanup" "$SELF_ROUTE_SH" --cleanup
}

action_pbr_status() {
	printf '=== PBR bypass (сети без VPN → WAN) ===\n'
	_any=0
	for _cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
		[ -f "$_cfg" ] || continue
		_nets="$(iface_conf_get "$_cfg" PBR_BYPASS_NETWORKS)"
		[ -n "$_nets" ] || continue
		_iface="$(basename "$(dirname "$(dirname "$_cfg")")")"
		_any=1
		printf '%s: %s\n' "$_iface" "$_nets"
	done
	[ "$_any" -eq 1 ] || printf 'PBR_BYPASS_NETWORKS пуст у всех туннелей.\n'
}

action_pbr_apply() {
	need_arg
	[ -f "$PBR_APPLY_SH" ] || die_usage "нет $PBR_APPLY_SH"
	_iface="$(printf '%s' "$ARG" | cut -d'|' -f1)"
	_nets="$(printf '%s' "$ARG" | cut -d'|' -f2-)"
	if [ -z "$_nets" ] || [ "$_nets" = "-" ]; then
		run "PBR bypass: очистить $_iface" "$PBR_APPLY_SH" --iface "$_iface" --clear --apply-routing
	else
		run "PBR bypass: $_iface → $_nets" "$PBR_APPLY_SH" --iface "$_iface" --networks "$_nets" --apply-routing
	fi
}

action_pbr_apply_bulk() {
	need_arg
	[ -f "$PBR_APPLY_SH" ] || die_usage "нет $PBR_APPLY_SH"
	iface_luci_try_bg "iface-pbr-apply" sh "$LUCIRPC_SH" pbrApplyBulk "$ARG" && return 0
	printf '%s' "$ARG" | tr ';' '\n' | while IFS= read -r _item; do
		[ -n "$_item" ] || continue
		_iface="$(printf '%s' "$_item" | cut -d'=' -f1)"
		_nets="$(printf '%s' "$_item" | cut -d'=' -f2-)"
		[ -n "$_iface" ] || continue
		if [ -z "$_nets" ] || [ "$_nets" = "-" ]; then
			"$PBR_APPLY_SH" --iface "$_iface" --clear
		else
			"$PBR_APPLY_SH" --iface "$_iface" --networks "$_nets"
		fi
	done
	if [ -f "$APPLY_ROUTING_SH" ]; then
		run "PBR bypass: применить маршрутизацию" "$APPLY_ROUTING_SH" --profile-dir "$PROFILE_DIR"
	else
		printf 'PBR bypass обновлён.\n'
	fi
}

action_pbr_clear() {
	need_arg
	[ -f "$PBR_APPLY_SH" ] || die_usage "нет $PBR_APPLY_SH"
	run "PBR bypass: очистить $ARG" "$PBR_APPLY_SH" --iface "$ARG" --clear --apply-routing
}

action_get_totp() {
	need_arg
	_arg="$ARG"
	_sec=""
	case "$_arg" in
	secret:*)
		_sec="${_arg#secret:}"
		;;
	*)
		_iface="$_arg"
		if [ -f "$INTERFACES_DIR/$_iface/config/credentials.env" ]; then
			_sec="$(grep -E '^TOTP_SECRET=' "$INTERFACES_DIR/$_iface/config/credentials.env" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
		elif [ -f "/etc/xfree-toolbox/iface-routing/openvpn/$_iface.env" ]; then
			_sec="$(grep -E '^TOTP_SECRET=' "/etc/xfree-toolbox/iface-routing/openvpn/$_iface.env" 2>/dev/null | cut -d= -f2- | tr -d "'\"" || true)"
		fi
		;;
	esac
	case "$_sec" in
	*secret=*)
		_sec="${_sec#*secret=}"
		_sec="${_sec%%&*}"
		;;
	esac
	_sec="$(printf '%s' "$_sec" | tr -d ' \r\n\t' | tr 'a-z' 'A-Z')"
	[ -n "$_sec" ] || die_usage "нет TOTP_SECRET для $_arg"
	_totp_script="$ROOT_DIR/iface-routing/vpn/openvpn/totp-gen.sh"
	[ -f "$_totp_script" ] || _totp_script="/etc/xfree-toolbox/iface-routing/openvpn/totp-gen.sh"
	_code=""
	if command -v oathtool >/dev/null 2>&1; then
		_code="$(oathtool --totp -b "$_sec" 2>/dev/null || true)"
	elif [ -f "$_totp_script" ]; then
		_code="$(sh "$_totp_script" "$_sec" 2>/dev/null || true)"
	fi
	_now="$(date +%s)"
	_rem="$(( 30 - (_now % 30) ))"
	printf 'CODE=%s\nTTL=%s\n' "$_code" "$_rem"
}

case "$ACTION" in
list) action_list ;;
taskStatus) action_task_status ;;
summary) action_summary ;;
show) action_show ;;
showFile) action_show_file ;;
applyOne) action_apply_one ;;
applyAll) action_apply_all ;;
applyRouting) action_apply_routing ;;
regenerateOne) action_regenerate_one ;;
regenerateTemplates) action_regenerate_templates ;;
regenerateAll) action_regenerate_all ;;
delete) action_delete ;;
listConfs) action_list_confs ;;
confShow) action_conf_show ;;
confDelete) action_conf_delete ;;
confDeleteUnused) action_conf_delete_unused ;;
confSave) action_conf_save ;;
ifaceMeta) action_iface_meta ;;
regenerateOpts) action_regenerate_opts ;;
createFromConf) action_create ;;
createFromOvpn) action_create_from_ovpn ;;
protocolsStatus) action_protocols_status ;;
protocolsInstall) action_protocols_install ;;
protocolsRemove) action_protocols_remove ;;
updateFromConf) action_update ;;
warpStatus) action_warp_status ;;
warpSave) action_warp_save ;;
warpGenerate) action_warp_generate ;;
warpProvision) action_warp_provision ;;
protonStatus) action_proton_status ;;
protonSave) action_proton_save ;;
protonGenerate) action_proton_generate ;;
protonProvision) action_proton_provision ;;
selfRouteStatus) action_selfroute_status ;;
selfRouteApply) action_selfroute_apply ;;
selfRouteRemove) action_selfroute_remove ;;
selfRouteRebuildHotplug) action_selfroute_rebuild ;;
selfRouteRunHotplug) action_selfroute_refresh ;;
selfRouteCleanup) action_selfroute_cleanup ;;
pbrStatus) action_pbr_status ;;
pbrApply) action_pbr_apply ;;
pbrApplyBulk) action_pbr_apply_bulk ;;
pbrClear) action_pbr_clear ;;
getTotp) action_get_totp ;;
reconnect) action_reconnect ;;
toggleEnabled) action_toggle_enabled ;;
*)
	printf 'unknown ifaceMenu action: %s\n' "${ACTION:-?}" >&2
	exit 1
	;;
esac
