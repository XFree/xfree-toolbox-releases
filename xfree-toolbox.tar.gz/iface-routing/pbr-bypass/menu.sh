#!/bin/sh
# shellcheck shell=sh
# UI: PBR_BYPASS_NETWORKS for VPN ifaces — skip VPN marks for listed UCI networks.
#
# Consumers: iface-routing/menu.yaml → pbr_bypass_menu
# Not for: zapret exclude, firewall zone auto-detect

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"
COMMON_SH="${ROOT_DIR}/lib/common.sh"
UI_SH="${ROOT_DIR}/lib/ui.sh"
APPLY_SH="${SCRIPT_DIR}/apply.sh"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"
[ -f "$UI_SH" ] && . "$UI_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"

run_log() { ui_menu_invoke_with_output "$@"; }

list_profile_ifaces() {
    for d in "$INTERFACES_DIR"/*; do
        [ -d "$d" ] || continue
        basename "$d"
    done
}

list_uci_network_ifaces() {
    command -v uci >/dev/null 2>&1 || return 1
    uci show network 2>/dev/null | sed -n 's/^network\.\([^.]*\)=interface$/\1/p' | sort -u
}

conf_get_value() {
    cfg="$1"
    key="$2"
    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$cfg"
}

select_profile_iface() {
    lines=''
    for iface in $(list_profile_ifaces); do
        [ -n "$iface" ] || continue
        lines="${lines}${iface}\n"
    done
    [ -n "$lines" ] || {
        ui_msgbox "PBR bypass" "Нет интерфейсов в профиле: $INTERFACES_DIR"
        return 1
    }
    ui_select_from_lines "PBR bypass" "VPN-интерфейс (списки/mark'и)" "$(printf '%b' "$lines")" 20 78 10
}

show_status() {
    text=''
    count=0
    for cfg in "$INTERFACES_DIR"/*/config/iface.conf; do
        [ -f "$cfg" ] || continue
        name="$(conf_get_value "$cfg" 'INTERFACE_NAME' || true)"
        bypass="$(conf_get_value "$cfg" 'PBR_BYPASS_NETWORKS' || true)"
        [ -n "$name" ] || continue
        if [ -n "$bypass" ]; then
            text="${text}${name}: PBR_BYPASS_NETWORKS='${bypass}'\n"
            count=$((count + 1))
        else
            text="${text}${name}: (bypass выключен)\n"
        fi
    done
    if [ "$count" -eq 0 ] && [ -z "$text" ]; then
        text='Нет интерфейсов в профиле\n'
    fi
    ui_msgbox "PBR bypass статус" "${text}\nUCI network → device/CIDR при apply-routing.\nПустой список = marks как обычно."
}

run_configure() {
    target="$(select_profile_iface)" || return 0
    cfg="$INTERFACES_DIR/$target/config/iface.conf"
    [ -f "$cfg" ] || {
        ui_msgbox "PBR bypass" "Нет iface.conf: $cfg"
        return 0
    }

    nets="$(list_uci_network_ifaces || true)"
    if [ -z "$nets" ]; then
        ui_msgbox "PBR bypass" "Нет network.*=interface в UCI."
        return 0
    fi

    current="$(conf_get_value "$cfg" 'PBR_BYPASS_NETWORKS' || true)"
    set --
    for net in $nets; do
        [ -n "$net" ] || continue
        on="OFF"
        printf '%s\n' "$current" | tr ',\t' ' ' | tr -s ' ' '\n' | grep -Fxq "$net" && on="ON"
        set -- "$@" "$net" "$net" "$on"
    done

    if ! selected="$(ui_checklist "PBR bypass: $target" \
"Отметьте UCI-сети: для них mark'и $target не применяются (WAN).
Пустой OK — выключить bypass.
Esc — отмена без записи." \
        22 84 12 "$@")"; then
        return 0
    fi

    networks="$(printf '%s\n' "$selected" | tr '\n' ' ' | tr -s ' ' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"

    if ui_yesno "PBR bypass" \
"Записать PBR_BYPASS_NETWORKS='${networks}'
для $target и сразу apply-routing (nft)?

Нет — только записать в iface.conf."; then
        run_log "PBR bypass: $target → '${networks}' + apply-routing" \
            "$APPLY_SH" --iface "$target" --networks "$networks" --apply-routing
    else
        run_log "PBR bypass: $target → '${networks}'" \
            "$APPLY_SH" --iface "$target" --networks "$networks"
    fi
}

run_clear() {
    target="$(select_profile_iface)" || return 0
    if ! ui_yesno "PBR bypass" "Очистить PBR_BYPASS_NETWORKS у $target и apply-routing?"; then
        return 0
    fi
    run_log "PBR bypass: clear $target + apply-routing" \
        "$APPLY_SH" --iface "$target" --clear --apply-routing
}

main_loop() {
    while :; do
        choice="$(ui_menu "PBR bypass (сети → WAN)" \
"Для VPN-интерфейса: какие UCI-сети не маркировать в туннель." 16 84 6 \
            "1" "Показать статус" \
            "2" "Настроить (checklist сетей)" \
            "3" "Очистить bypass у интерфейса" \
            "0" "Назад" || true)"
        [ -n "${choice:-}" ] || break
        case "$choice" in
            1) show_status ;;
            2) run_configure ;;
            3) run_clear ;;
            0) break ;;
        esac
    done
}

[ -f "$APPLY_SH" ] || die "Не найден apply.sh: $APPLY_SH"
chmod +x "$APPLY_SH" 2>/dev/null || true

main_loop
