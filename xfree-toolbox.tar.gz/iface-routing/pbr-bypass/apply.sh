#!/bin/sh
# shellcheck shell=sh
# Write PBR_BYPASS_NETWORKS in iface.conf (UCI network names, space-separated).
# Usage:
#   apply.sh --iface warp --networks 'guest'
#   apply.sh --iface warp --networks ''   # clear
#   apply.sh --iface warp --clear

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"
COMMON_SH="${ROOT_DIR}/lib/common.sh"
APPLY_ROUTING_SH="${DOMAIN_ROUTING_DIR}/apply-routing.sh"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"

iface_conf_path() {
    printf '%s/%s/config/iface.conf\n' "$INTERFACES_DIR" "$1"
}

set_conf_value() {
    cfg="$1"
    key="$2"
    value="$3"

    tmp="${cfg}.tmp.$$"
    awk -v key="$key" -v value="$value" '
        BEGIN { done = 0 }
        $0 ~ "^" key "=" {
            print key "=\047" value "\047"
            done = 1
            next
        }
        { print }
        END {
            if (!done) {
                print key "=\047" value "\047"
            }
        }
    ' "$cfg" > "$tmp"
    mv "$tmp" "$cfg"
}

normalize_networks() {
    printf '%s\n' "${1:-}" | tr ',\t' ' ' | tr -s ' ' '\n' | sed '/^$/d' | sort -u | tr '\n' ' ' | sed 's/[[:space:]]*$//'
}

TARGET_IFACE=''
NETWORKS=''
CLEAR=0
RUN_APPLY_ROUTING=0

while [ "$#" -gt 0 ]; do
    case "$1" in
        --iface)
            [ "$#" -ge 2 ] || die "Не указано значение для --iface"
            TARGET_IFACE="$2"
            shift 2
            ;;
        --networks)
            [ "$#" -ge 2 ] || die "Не указано значение для --networks"
            NETWORKS="$2"
            shift 2
            ;;
        --clear)
            CLEAR=1
            shift
            ;;
        --apply-routing)
            RUN_APPLY_ROUTING=1
            shift
            ;;
        -h|--help)
            cat <<EOF
Usage:
  $(basename "$0") --iface NAME --networks 'guest lan'
  $(basename "$0") --iface NAME --clear
  $(basename "$0") --iface NAME --networks 'guest' --apply-routing
EOF
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
done

[ -n "$TARGET_IFACE" ] || die "Нужен --iface"
cfg="$(iface_conf_path "$TARGET_IFACE")"
[ -f "$cfg" ] || die "Не найден iface.conf: $cfg"

if [ "$CLEAR" = 1 ]; then
    NETWORKS=''
fi
NETWORKS="$(normalize_networks "$NETWORKS")"

set_conf_value "$cfg" 'PBR_BYPASS_NETWORKS' "$NETWORKS"

if [ -n "$NETWORKS" ]; then
    success "PBR_BYPASS_NETWORKS='$NETWORKS' для $TARGET_IFACE"
else
    success "PBR_BYPASS_NETWORKS очищен для $TARGET_IFACE (bypass выключен)"
fi

if [ "$RUN_APPLY_ROUTING" = 1 ]; then
    [ -x "$APPLY_ROUTING_SH" ] || [ -f "$APPLY_ROUTING_SH" ] || die "Не найден apply-routing: $APPLY_ROUTING_SH"
    info "Запуск apply-routing (обновить nft mark chains)…"
    sh "$APPLY_ROUTING_SH"
fi
