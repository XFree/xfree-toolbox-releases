#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="${ROOT_DIR}/lib/common.sh"
UI_SH="${ROOT_DIR}/lib/ui.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"

[ -f "$UI_SH" ] || { echo "[-] Не найден ui.sh: $UI_SH" >&2; exit 1; }
. "$UI_SH"

[ -f "$CONFIG_FILE" ] || { echo "[-] Не найден config.sh: $CONFIG_FILE" >&2; exit 1; }
. "$CONFIG_FILE"

ui_init
ui_trap_cleanup_on_exit

UPDATE_INTERFACE_CONFIG_SCRIPT="${UPDATE_INTERFACE_CONFIG_SCRIPT:-$SCRIPT_DIR/update-interface-config.sh}"
CONVERTER_SCRIPT="${CONVERTER_SCRIPT:-$SCRIPT_DIR/conf-to-interface-uci.sh}"
APPLY_INTERFACES_SCRIPT="${APPLY_INTERFACES_SCRIPT:-$SCRIPT_DIR/apply-interfaces.sh}"
DELETE_INTERFACE_SCRIPT="${DELETE_INTERFACE_SCRIPT:-$SCRIPT_DIR/delete-interface.sh}"
WARP_MENU_SCRIPT="${WARP_MENU_SCRIPT:-$SCRIPT_DIR/vpn/warp/menu.sh}"
PROTON_MENU_SCRIPT="${PROTON_MENU_SCRIPT:-$SCRIPT_DIR/vpn/proton/menu.sh}"
REGENERATE_INTERFACE_SCRIPT="${REGENERATE_INTERFACE_SCRIPT:-$SCRIPT_DIR/regenerate-interface-config.sh}"

[ -f "$CONVERTER_SCRIPT" ] || die "Не найден converter script: $CONVERTER_SCRIPT"
[ -x "$CONVERTER_SCRIPT" ] || chmod +x "$CONVERTER_SCRIPT" 2>/dev/null || true

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
SYSTEM_DOMAIN_ROUTING_DIR="${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}"
SYSTEM_INTERFACES_DIR="${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}"
SYSTEM_GENERATED_DIR="${SYSTEM_GENERATED_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/interfaces}"
CONF_DIR="${CONF_DIR:-$SCRIPT_DIR/conf}"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"

run_log() {
    title="$1"
    shift
    ui_run_with_output "$title" "$@"
}

iface_dir_of() {
    printf '%s/%s\n' "$INTERFACES_DIR" "$1"
}

iface_config_dir_of() {
    printf '%s/config\n' "$(iface_dir_of "$1")"
}

iface_conf_of() {
    printf '%s/iface.conf\n' "$(iface_config_dir_of "$1")"
}

iface_network_uci_of() {
    printf '%s/network.uci\n' "$(iface_config_dir_of "$1")"
}

iface_firewall_uci_of() {
    printf '%s/firewall.uci\n' "$(iface_config_dir_of "$1")"
}

iface_source_conf_of() {
    printf '%s/source.conf\n' "$(iface_config_dir_of "$1")"
}

iface_source_meta_of() {
    printf '%s/source.conf.meta\n' "$(iface_config_dir_of "$1")"
}

system_iface_dir_of() {
    printf '%s/%s\n' "$SYSTEM_INTERFACES_DIR" "$1"
}

system_generated_dir_of() {
    printf '%s/%s\n' "$SYSTEM_GENERATED_DIR" "$1"
}

select_conf_file() {
    list_file="${UI_TMP_ROOT:-/tmp}/iface-source-conf-list.$$"
    : > "$list_file"

    detect_generator_kind() {
        meta_file="$1"
        [ -f "$meta_file" ] || return 1
        awk -F= '
            {
                gsub(/\r/, "")
            }
            $1 == "GENERATOR_KIND" {
                v = substr($0, index($0, "=") + 1)
                sub(/^[[:space:]]+/, "", v)
                sub(/[[:space:]]+$/, "", v)
                gsub(/\r/, "", v)
                gsub(/^\047|\047$/, "", v)
                print v
                exit
            }
        ' "$meta_file"
    }

    meta_get_value() {
        meta_file="$1"
        key="$2"
        [ -f "$meta_file" ] || return 1
        awk -F= -v want="$key" '
            {
                gsub(/\r/, "")
            }
            $1 == want {
                v = substr($0, index($0, "=") + 1)
                sub(/^[[:space:]]+/, "", v)
                sub(/[[:space:]]+$/, "", v)
                gsub(/\r/, "", v)
                gsub(/^\047|\047$/, "", v)
                print v
                exit
            }
        ' "$meta_file"
    }

    format_generated_local() {
        utc_value="$1"
        [ -n "${utc_value:-}" ] || return 1

        utc_plain="$utc_value"
        case "$utc_plain" in
            *Z) utc_plain="${utc_plain%Z}" ;;
        esac

        epoch=""
        epoch="$(date -u -D '%Y-%m-%dT%H:%M:%S' -d "$utc_plain" +%s 2>/dev/null || true)"
        case "$epoch" in ''|*[!0-9]*) epoch="" ;; esac
        if [ -z "$epoch" ]; then
            utc_sp="$(printf '%s' "$utc_plain" | tr 'T' ' ')"
            epoch="$(date -u -d "$utc_sp" +%s 2>/dev/null || true)"
            case "$epoch" in ''|*[!0-9]*) epoch="" ;; esac
        fi

        if [ -n "$epoch" ]; then
            local_value="$(date -d "@$epoch" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
            [ -n "${local_value:-}" ] || local_value="$(date -r "$epoch" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
            [ -n "${local_value:-}" ] || return 1
            printf '%s\n' "$local_value"
            return 0
        fi

        local_value="$(date -d "$utc_value" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
        if [ -n "${local_value:-}" ]; then
            printf '%s\n' "$local_value"
            return 0
        fi

        local_value="$(date -D '%Y-%m-%dT%H:%M:%SZ' -d "$utc_value" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
        [ -n "${local_value:-}" ] || return 1
        printf '%s\n' "$local_value"
    }

    add_conf_file() {
        f="$1"
        kind_default="$2"
        [ -f "$f" ] || return 0

        base="$(basename -- "$f")"
        meta_file="${f}.meta"
        kind="$(detect_generator_kind "$meta_file" 2>/dev/null || true)"
        [ -n "${kind:-}" ] || kind="$kind_default"
                server_name="$(meta_get_value "$meta_file" "SERVER_NAME" 2>/dev/null || true)"
                server_country="$(meta_get_value "$meta_file" "SERVER_COUNTRY" 2>/dev/null || true)"
                server_city="$(meta_get_value "$meta_file" "SERVER_CITY" 2>/dev/null || true)"
                peer_name="$(meta_get_value "$meta_file" "PEER_NAME" 2>/dev/null || true)"
                country_filter="$(meta_get_value "$meta_file" "COUNTRY_FILTER" 2>/dev/null || true)"
                server_id_meta="$(meta_get_value "$meta_file" "SERVER_ID" 2>/dev/null || true)"
                endpoint_label="$(meta_get_value "$meta_file" "ENDPOINT_LABEL" 2>/dev/null || true)"
                endpoint_host="$(meta_get_value "$meta_file" "ENDPOINT_HOST" 2>/dev/null || true)"
                profile_mode="$(meta_get_value "$meta_file" "PROFILE_MODE" 2>/dev/null || true)"
                generated_at_utc="$(meta_get_value "$meta_file" "GENERATED_AT_UTC" 2>/dev/null || true)"
                generated_at_local="$(format_generated_local "$generated_at_utc" 2>/dev/null || true)"
                [ -n "${generated_at_local:-}" ] || {
                    ts="$(stat -c '%Y' "$f" 2>/dev/null || true)"
                    case "$ts" in
                        ''|*[!0-9]*) generated_at_local="n/a" ;;
                        *)
                            generated_at_local="$(date -d "@$ts" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
                            [ -n "${generated_at_local:-}" ] || generated_at_local="n/a"
                            ;;
                    esac
                }

                hint_line="$(awk '
                    {
                        gsub(/\r/, "")
                    }
                    /^# XFREE_CONF_LIST_HINT=/ {
                        v = $0
                        sub(/^# XFREE_CONF_LIST_HINT=/, "", v)
                        print v
                        exit
                    }
                ' "$f" 2>/dev/null || true)"
                if [ -n "${hint_line:-}" ]; then
                    hint_name="$(printf '%s' "$hint_line" | cut -d '|' -f1)"
                    hint_country="$(printf '%s' "$hint_line" | cut -d '|' -f2)"
                    hint_city="$(printf '%s' "$hint_line" | cut -d '|' -f3-)"
                    [ -z "${server_name:-}" ] && [ -n "${hint_name:-}" ] && server_name="$hint_name"
                    [ -z "${server_country:-}" ] && [ -n "${hint_country:-}" ] && server_country="$hint_country"
                    [ -z "${server_city:-}" ] && [ -n "${hint_city:-}" ] && server_city="$hint_city"
                fi

                [ -n "${server_name:-}" ] || server_name="$peer_name"
                if [ -z "${server_name:-}" ]; then
                    server_name="$(awk '
                        {
                            gsub(/\r/, "")
                        }
                        /^# PROTON_DEVICE_NAME=/ { next }
                        /^# XFREE_CONF_LIST_HINT=/ { next }
                        /^# ---/ { next }
                        /^# mode:/ { next }
                        /^# original:/ { next }
                        /^# applied:/ { next }
                        /^# uci-recommendation:/ { next }
                        /^#   / { next }
                        /^# / { sub(/^# ?/, ""); print; exit }
                    ' "$f" 2>/dev/null || true)"
                fi
                case "${kind:-}" in
                    warp)
                        [ -n "${server_name:-}" ] || {
                            case "${server_id_meta:-}" in
                                ''|[!a-zA-Z0-9._-]*) ;;
                                *) server_name="$server_id_meta" ;;
                            esac
                        }
                        ;;
                esac
                if [ -z "${server_name:-}" ] && [ -n "${endpoint_label:-}" ]; then
                    server_name="$endpoint_label"
                fi
                if [ -z "${server_name:-}" ] && [ -n "${endpoint_host:-}" ]; then
                    server_name="$endpoint_host"
                fi
                [ -n "${server_name:-}" ] || server_name="${base%.conf}"

                [ -n "${server_country:-}" ] || server_country="$country_filter"
                if [ -z "${server_country:-}" ]; then
                    case "${kind:-}" in
                        warp) server_country="Cloudflare" ;;
                    esac
                fi
                if [ -z "${server_country:-}" ] && [ -n "${profile_mode:-}" ]; then
                    server_country="$profile_mode"
                fi
                [ -n "${server_country:-}" ] || server_country="-"

                if [ -z "${server_city:-}" ] && [ -n "${endpoint_label:-}" ]; then
                    server_city="$endpoint_label"
                fi
                if [ -z "${server_city:-}" ] && [ -n "${endpoint_host:-}" ]; then
                    server_city="$endpoint_host"
                fi
                if [ -z "${server_city:-}" ] && [ -n "${profile_mode:-}" ]; then
                    server_city="$profile_mode"
                fi
                [ -n "${server_city:-}" ] || server_city="-"

                case "${server_country:-}" in \?|'') server_country='-' ;; esac
                case "${server_city:-}" in \?|'') server_city='-' ;; esac

        label="[$generated_at_local] [$kind] $server_name ($server_country/$server_city)"
        printf '%s|%s\n' "$label" "$f" >> "$list_file"
    }

    add_conf_from_dir() {
        conf_dir="$1"
        kind_default="$2"
        [ -d "$conf_dir" ] || return 0
        for f in "$conf_dir"/*.conf; do
            [ -f "$f" ] || continue
            add_conf_file "$f" "$kind_default"
        done
    }

    provider_conf_dir() {
        provider="$1"
        case "$provider" in
            proton) xfree_profile_proton_conf_dir "$PROFILE_DIR" ;;
            warp) xfree_profile_warp_conf_dir "$PROFILE_DIR" ;;
            *) printf '%s/%s/conf\n' "$PROFILE_VPN_DIR" "$provider" ;;
        esac
    }

    add_conf_tree() {
        root="$1"
        [ -d "$root" ] || return 0

        for gen_dir in "$root"/*; do
            [ -d "$gen_dir" ] || continue
            gen_name="$(basename -- "$gen_dir")"
            conf_dir="$(provider_conf_dir "$gen_name")"
            add_conf_from_dir "$conf_dir" "$gen_name"
        done
    }

    add_conf_tree "$PROFILE_VPN_DIR"

    [ -s "$list_file" ] || {
        rm -f "$list_file"
        ui_msgbox "Исходные .conf" "Нет файлов *.conf в vpn/<provider>/conf/ (профиль: $PROFILE_DIR).

Сначала сгенерируйте конфиг (WARP/Proton) или импортируйте .conf.
Если конфиги лежат в старом vpn/<provider>/, выполните migrate-profile-vpn-conf-layout.sh."
        return 1
    }

    lines="$(sort -u "$list_file")"
    set --
    idx=1
    while IFS='|' read -r label path; do
        [ -n "${label:-}" ] || continue
        [ -n "${path:-}" ] || continue
        set -- "$@" "$idx" "$label"
        eval "UI_CONFSEL_$idx=\"\$path\""
        idx=$((idx + 1))
    done <<EOF
$lines
EOF

    [ "$#" -gt 0 ] || {
        rm -f "$list_file"
        ui_msgbox "Исходные .conf" "Нет доступных вариантов .conf для выбора."
        return 1
    }
    choice="$(ui_menu "Исходные .conf" "Выберите .conf-файл" 22 110 12 "$@" || true)"
    rm -f "$list_file"
    [ -n "${choice:-}" ] || return 1

    eval "selected_path=\${UI_CONFSEL_$choice:-}"
    [ -n "${selected_path:-}" ] || return 1
    printf '%s\n' "$selected_path"
}

list_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    find "$INTERFACES_DIR" -type f -path '*/config/iface.conf' 2>/dev/null \
        | sed "s|$INTERFACES_DIR/||" \
        | sed 's|/config/iface.conf$||' \
        | sed '/^$/d' \
        | sort -u
}

select_interface_name() {
    lines="$(list_interfaces || true)"
    [ -n "${lines:-}" ] || {
        ui_msgbox "Интерфейсы" "Интерфейсы не найдены.

Сначала создайте интерфейс: пункт «Создать интерфейс из .conf»."
        return 1
    }
    ui_select_from_lines "Интерфейсы" "Выберите интерфейс" "$lines" 20 90 10
}

show_text_file() {
    title="$1"
    file="$2"
    [ -f "$file" ] || {
        ui_msgbox "Ошибка" "Файл не найден:\n$file"
        return 0
    }
    ui_show_textbox "$title" "$file" 30 110
}

suggest_next_iface_name() {
    idx=1
    while :; do
        if [ "$idx" -eq 1 ]; then
            iface="warp"
        else
            iface="warp$idx"
        fi
        [ -d "$INTERFACES_DIR/$iface" ] || {
            printf '%s\n' "$iface"
            return 0
        }
        idx=$((idx + 1))
    done
}

meta_get_value() {
    meta_file="$1"
    key="$2"
    [ -f "$meta_file" ] || return 1
    awk -F= -v want="$key" '
        {
            gsub(/\r/, "")
        }
        $1 == want {
            v = substr($0, index($0, "=") + 1)
            sub(/^[[:space:]]+/, "", v)
            sub(/[[:space:]]+$/, "", v)
            gsub(/\r/, "", v)
            gsub(/^\047|\047$/, "", v)
            print v
            exit
        }
    ' "$meta_file"
}

sanitize_iface_token() {
    token="$1"
    token="$(common_lower_ascii "$token" 2>/dev/null || printf '%s' "$token" | tr 'A-Z' 'a-z')"
    token="$(printf '%s' "$token" | sed 's/[^a-z0-9]/_/g; s/__*/_/g; s/^_//; s/_$//')"
    [ -n "$token" ] || token="vpn"
    printf '%s\n' "$token"
}

iface_name_taken() {
    want="$1"
    [ -n "$want" ] || return 0

    [ -d "$INTERFACES_DIR/$want" ] && return 0
    if list_interfaces 2>/dev/null | awk -v want="$want" '
        $0 == want { found=1 }
        END { exit(found ? 0 : 1) }
    '; then
        return 0
    fi
    return 1
}

next_iface_name_for_prefix() {
    prefix="$1"
    prefix="$(sanitize_iface_token "$prefix")"
    n=1
    while :; do
        candidate="${prefix}_${n}"
        if ! iface_name_taken "$candidate"; then
            printf '%s\n' "$candidate"
            return 0
        fi
        n=$((n + 1))
    done
}

build_iface_name_suggestions() {
    src_conf="$1"
    src_meta="${src_conf}.meta"

    kind="$(meta_get_value "$src_meta" "GENERATOR_KIND" 2>/dev/null || true)"
    country="$(meta_get_value "$src_meta" "SERVER_COUNTRY" 2>/dev/null || true)"
    city="$(meta_get_value "$src_meta" "SERVER_CITY" 2>/dev/null || true)"
    server_id="$(meta_get_value "$src_meta" "SERVER_ID" 2>/dev/null || true)"

    [ -n "${kind:-}" ] || kind="vpn"
    [ -n "${country:-}" ] || country="${server_id:-def}"
    [ -n "${country:-}" ] || country="def"
    [ -n "${city:-}" ] || city="site"

    kind_t="$(sanitize_iface_token "$kind")"
    country_t="$(sanitize_iface_token "$country")"
    city_t="$(sanitize_iface_token "$city")"

    suggested_auto="$(next_iface_name_for_prefix "${kind_t}_${country_t}")"
    suggested_with_city="$(next_iface_name_for_prefix "${kind_t}_${country_t}_${city_t}")"
    suggested_short="$(next_iface_name_for_prefix "${kind_t}")"

    printf '%s\t%s\t%s\n' "$suggested_auto" "$suggested_with_city" "$suggested_short"
}

choose_create_mode() {
    suggested_auto="$1"
    suggested_with_city="$2"
    suggested_short="$3"

    ui_menu "Создание интерфейса" "Выберите режим" 18 96 10 \
        "1" "Авто: $suggested_auto" \
        "2" "Авто: $suggested_with_city" \
        "3" "Авто: $suggested_short" \
        "4" "Ввести вручную" \
        "0" "Назад"
}

create_interface() {
    src_conf="$(select_conf_file || true)"
    [ -n "${src_conf:-}" ] || return 0

    suggestions="$(build_iface_name_suggestions "$src_conf")"
    suggested_auto="$(printf '%s\n' "$suggestions" | awk -F "$(printf '\t')" '{print $1}')"
    suggested_with_city="$(printf '%s\n' "$suggestions" | awk -F "$(printf '\t')" '{print $2}')"
    suggested_short="$(printf '%s\n' "$suggestions" | awk -F "$(printf '\t')" '{print $3}')"
    [ -n "${suggested_auto:-}" ] || suggested_auto="$(suggest_next_iface_name)"
    [ -n "${suggested_with_city:-}" ] || suggested_with_city="$suggested_auto"
    [ -n "${suggested_short:-}" ] || suggested_short="$suggested_auto"

    mode="$(choose_create_mode "$suggested_auto" "$suggested_with_city" "$suggested_short" || true)"
    [ -n "${mode:-}" ] || return 0

    case "$mode" in
        1)
            run_log "Создание интерфейса из .conf" \
                "$CONVERTER_SCRIPT" \
                --iface "$suggested_auto" \
                --source "$src_conf"
            ;;
        2)
            run_log "Создание интерфейса из .conf: $suggested_with_city" \
                "$CONVERTER_SCRIPT" \
                --iface "$suggested_with_city" \
                --source "$src_conf"
            ;;
        3)
            run_log "Создание интерфейса из .conf: $suggested_short" \
                "$CONVERTER_SCRIPT" \
                --iface "$suggested_short" \
                --source "$src_conf"
            ;;
        4)
            iface_name="$(ui_inputbox "Имя интерфейса" "Введите имя интерфейса (по умолчанию авто-вариант)" "$suggested_auto" || true)"
            [ -n "${iface_name:-}" ] || return 0
            run_log "Создание интерфейса из .conf: $iface_name" \
                "$CONVERTER_SCRIPT" \
                --iface "$iface_name" \
                --source "$src_conf"
            ;;
        0) return 0 ;;
    esac
}

update_interface() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0

    src_conf="$(select_conf_file || true)"
    [ -n "${src_conf:-}" ] || return 0

    run_log "Обновление интерфейса из .conf: $iface" \
        "$UPDATE_INTERFACE_CONFIG_SCRIPT" \
        --iface "$iface" \
        --source "$src_conf"
}

regenerate_interface_config_for_iface() {
    iface="$1"
    [ -n "${iface:-}" ] || return 0

    run_log "Пересоздание конфигурации: $iface" \
        "$REGENERATE_INTERFACE_SCRIPT" \
        --iface "$iface" \
        --force
}

list_template_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    find "$INTERFACES_DIR" -type f -path '*/config/TEMPLATE' 2>/dev/null \
        | sed "s|$INTERFACES_DIR/||" \
        | sed 's|/config/TEMPLATE$||' \
        | sed '/^$/d' \
        | sort -u
}

regenerate_selected_interface() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0
    regenerate_interface_config_for_iface "$iface"
}

regenerate_all_template_interfaces() {
    lines="$(list_template_interfaces || true)"
    [ -n "${lines:-}" ] || {
        ui_msgbox "Пересоздать конфигурацию" "Template-интерфейсы не найдены."
        return 0
    }

    while IFS= read -r iface; do
        [ -n "${iface:-}" ] || continue
        regenerate_interface_config_for_iface "$iface"
    done <<EOF
$lines
EOF
}

regenerate_all_interfaces() {
    lines="$(list_interfaces || true)"
    [ -n "${lines:-}" ] || {
        ui_msgbox "Пересоздать конфигурацию" "Интерфейсы не найдены."
        return 0
    }

    while IFS= read -r iface; do
        [ -n "${iface:-}" ] || continue
        regenerate_interface_config_for_iface "$iface"
    done <<EOF
$lines
EOF
}

regenerate_interface_menu() {
    while true; do
        choice="$(ui_menu "Пересоздать конфигурацию" "Выберите, для каких интерфейсов пересоздать конфигурацию" 20 96 10 \
            "1" "Выбрать интерфейс" \
            "2" "Для template-интерфейсов" \
            "3" "Для всех интерфейсов" \
            "0" "Назад" || true)"

        [ -n "${choice:-}" ] || return 0
        case "$choice" in
            1) regenerate_selected_interface ;;
            2) regenerate_all_template_interfaces ;;
            3) regenerate_all_interfaces ;;
            0) return 0 ;;
        esac
    done
}

apply_interface_to_system() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0

    run_log "Применение интерфейса: $iface" \
        "$APPLY_INTERFACES_SCRIPT" \
        --iface "$iface"
}

apply_all_interfaces_to_system() {
    run_log "Применение всех интерфейсов" \
        "$APPLY_INTERFACES_SCRIPT" \
        --all
}

build_interfaces_status_text() {
    out="$1"
    {
        echo "Интерфейсы"
        echo
        echo "Статусы: да = найдено, нет = отсутствует"
        echo

        lines="$(list_interfaces || true)"
        if [ -z "${lines:-}" ]; then
            echo "Интерфейсы не найдены."
            exit 0
        fi

        printf '%s\n' "$lines" | while IFS= read -r iface; do
            [ -n "$iface" ] || continue

            work="нет"
            system_copy="нет"
            generated="нет"
            fqdn_lists="нет"
            prefix_lists="нет"
            source_conf="нет"
            generator_kind=""
            server_name=""
            proton_device_name=""
            meta_file="$(iface_source_meta_of "$iface")"

            [ -d "$(iface_dir_of "$iface")" ] && work="да"
            [ -d "$(system_iface_dir_of "$iface")" ] && system_copy="да"
            [ -d "$(system_generated_dir_of "$iface")" ] && generated="да"

            find "$(iface_dir_of "$iface")/fqdn.d" -maxdepth 1 -type f 2>/dev/null | grep -q . && fqdn_lists="да" || true
            find "$(iface_dir_of "$iface")/prefixes.d" -maxdepth 1 -type f 2>/dev/null | grep -q . && prefix_lists="да" || true
            [ -f "$(iface_source_conf_of "$iface")" ] && source_conf="да"
            generator_kind="$(meta_get_value "$meta_file" "GENERATOR_KIND" 2>/dev/null || true)"
            session_name="$(meta_get_value "$meta_file" "SESSION_NAME" 2>/dev/null || true)"
            session_auth="$(meta_get_value "$meta_file" "SESSION_AUTH_MODE" 2>/dev/null || true)"
            cert_utc="$(meta_get_value "$meta_file" "CERT_EXPIRATION_UTC" 2>/dev/null || true)"
            server_name="$(meta_get_value "$meta_file" "SERVER_NAME" 2>/dev/null || true)"
            proton_device_name="$(meta_get_value "$meta_file" "PROTON_DEVICE_NAME" 2>/dev/null || true)"

            echo "[$iface]"
            echo "  profile workdir   : $work"
            echo "  system state copy : $system_copy"
            echo "  generated cache   : $generated"
            echo "  source.conf       : $source_conf"
            echo "  fqdn.d files      : $fqdn_lists"
            echo "  prefixes.d files  : $prefix_lists"
            [ -n "${generator_kind:-}" ] && echo "  generator kind    : $generator_kind"
            [ -n "${session_auth:-}" ] && echo "  session auth      : $session_auth"
            [ -n "${session_name:-}" ] && echo "  session name      : $session_name"
            [ -n "${cert_utc:-}" ] && echo "  cert until        : $cert_utc"
            [ -n "${server_name:-}" ] && echo "  server name       : $server_name"
            [ -n "${proton_device_name:-}" ] && echo "  proton device     : $proton_device_name"
            echo
        done
    } > "$out"
}

show_interfaces_list() {
    out="${UI_TMP_ROOT:-/tmp}/interfaces-status.txt"
    build_interfaces_status_text "$out"
    ui_show_textbox "Список интерфейсов" "$out" 30 110
}

delete_interface() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0

    if ! ui_confirm "Удаление интерфейса" "Удалить интерфейс '$iface'?

Будет удалён каталог:
$INTERFACES_DIR/$iface"; then
        return 0
    fi

    if [ -x "$DELETE_INTERFACE_SCRIPT" ]; then
        extra_delete_args=''
        delete_mode="$(ui_menu "Удаление интерфейса" "Выберите режим очистки runtime после удаления '$iface'" 20 100 12 \
            "1" "Базовый (только удаляемый интерфейс)" \
            "2" "Базовый + full reconcile (apply-routing)" \
            "3" "Базовый + cleanup сирот self-route" \
            "4" "Базовый + full reconcile + cleanup сирот" \
            "0" "Отмена" || true)"
        [ -n "${delete_mode:-}" ] || return 0
        case "$delete_mode" in
            1) extra_delete_args='' ;;
            2) extra_delete_args='--full-reconcile' ;;
            3) extra_delete_args='--cleanup-orphans' ;;
            4) extra_delete_args='--full-reconcile --cleanup-orphans' ;;
            0) return 0 ;;
            *) return 0 ;;
        esac

        if ui_confirm "Удаление интерфейса из системы" "Удалить интерфейс '$iface' также из системы?

Будут удалены UCI/network/firewall-привязки этого интерфейса."; then
            set -- "$DELETE_INTERFACE_SCRIPT" --iface "$iface" --purge-files
            for arg in $extra_delete_args; do
                set -- "$@" "$arg"
            done
            run_log "Удаление интерфейса из системы: $iface" "$@"
        else
            rm -rf "$INTERFACES_DIR/$iface"
            ui_msgbox "Удаление интерфейса" "Каталог интерфейса удалён.

Системная конфигурация не изменялась.
Для очистки runtime затем выполните:
Применить выбранные сайты"
        fi
    else
        ui_msgbox "Удаление интерфейса" "Каталог интерфейса удалён.

Скрипт delete-interface.sh не найден или не исполняем.
Если интерфейс ранее применялся в систему, удалите его системную конфигурацию отдельно."
    fi
}

show_interface_menu() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0

    while true; do
        choice="$(ui_menu "Интерфейс: $iface" "Выберите действие" 26 92 18 \
            "1" "Показать iface.conf" \
            "2" "Показать source.conf" \
            "3" "Показать source.conf.meta" \
            "4" "Показать network.uci" \
            "5" "Показать firewall.uci" \
            "0" "Назад" || true)"

        [ -n "${choice:-}" ] || return 0
        case "$choice" in
            1) show_text_file "iface.conf" "$(iface_conf_of "$iface")" ;;
            2) show_text_file "source.conf" "$(iface_source_conf_of "$iface")" ;;
            3) show_text_file "source.conf.meta" "$(iface_source_meta_of "$iface")" ;;
            4) show_text_file "network.uci" "$(iface_network_uci_of "$iface")" ;;
            5) show_text_file "firewall.uci" "$(iface_firewall_uci_of "$iface")" ;;
            0) return 0 ;;
        esac
    done
}

iface_dispatch_core_choice() {
    choice="$1"
    case "$choice" in
        1) "$WARP_MENU_SCRIPT" ui ;;
        2) "$PROTON_MENU_SCRIPT" ui ;;
        3) show_interfaces_list ;;
        4) create_interface ;;
        5) update_interface ;;
        6) regenerate_interface_menu ;;
        7) apply_interface_to_system ;;
        8) apply_all_interfaces_to_system ;;
        9) delete_interface ;;
        10) show_interface_menu ;;
        *) return 1 ;;
    esac
}

main_menu() {
    while true; do
        choice="$(ui_menu "VPN-туннели" "Выберите действие" 26 96 18 \
            "1" "Генератор WARP-конфигов" \
            "2" "Генератор Proton-конфигов" \
            "3" "Показать список туннелей" \
            "4" "Создать туннель из .conf" \
            "5" "Обновить туннель из .conf" \
            "6" "Пересобрать конфиг туннеля" \
            "7" "Применить туннель на роутере" \
            "8" "Применить все туннели" \
            "9" "Удалить туннель" \
            "10" "Показать настройки туннеля" \
            "0" "Назад" || true)"

        [ -n "${choice:-}" ] || exit 0
        case "$choice" in
            0) exit 0 ;;
            *)
                iface_dispatch_core_choice "$choice" || true
                ;;
        esac
    done
}

if [ "${MENU_INTERFACES_SOURCED:-0}" != 1 ]; then
    case "${1:-}" in
        ui) main_menu ;;
        *) echo "Usage: $0 ui"; exit 1 ;;
    esac
fi
