#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="${ROOT_DIR}/lib/common.sh"
UI_SH="${ROOT_DIR}/lib/ui.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
. "$COMMON_SH"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"

[ -f "$UI_SH" ] || { echo "[-] Не найден ui.sh: $UI_SH" >&2; exit 1; }
. "$UI_SH"

[ -f "$CONFIG_FILE" ] || { echo "[-] Не найден config.sh: $CONFIG_FILE" >&2; exit 1; }
. "$CONFIG_FILE"

ui_init
ui_trap_cleanup_on_exit

UPDATE_INTERFACE_CONFIG_SCRIPT="${UPDATE_INTERFACE_CONFIG_SCRIPT:-$SCRIPT_DIR/update-interface-config.sh}"
CONVERTER_SCRIPT="${CONVERTER_SCRIPT:-$SCRIPT_DIR/conf-to-interface-uci.sh}"
APPLY_INTERFACES_SCRIPT="${APPLY_INTERFACES_SCRIPT:-$SCRIPT_DIR/apply-interfaces.sh}"
DELETE_INTERFACE_SCRIPT="${DELETE_INTERFACE_SCRIPT:-$SCRIPT_DIR/delete-interface.sh}"
WARP_MENU_SCRIPT="${WARP_MENU_SCRIPT:-$SCRIPT_DIR/vpn/warp/menu.sh}"
PROTON_MENU_SCRIPT="${PROTON_MENU_SCRIPT:-$SCRIPT_DIR/vpn/proton/menu.sh}"
REGENERATE_INTERFACE_SCRIPT="${REGENERATE_INTERFACE_SCRIPT:-$SCRIPT_DIR/regenerate-interface-config.sh}"
OVPN_CONVERTER_SCRIPT="${OVPN_CONVERTER_SCRIPT:-$SCRIPT_DIR/vpn/openvpn/ovpn-to-interface.sh}"
OPENVPN_ENSURE_SCRIPT="${OPENVPN_ENSURE_SCRIPT:-$SCRIPT_DIR/vpn/openvpn/ensure-openvpn.sh}"
PROTOCOLS_MENU_SCRIPT="${PROTOCOLS_MENU_SCRIPT:-$SCRIPT_DIR/vpn/protocols/menu.sh}"
NORM_CONF_SCRIPT="${NORM_CONF_SCRIPT:-$SCRIPT_DIR/normalize-conf.sh}"

[ -f "$CONVERTER_SCRIPT" ] || die "Не найден converter script: $CONVERTER_SCRIPT"
[ -x "$CONVERTER_SCRIPT" ] || chmod +x "$CONVERTER_SCRIPT" 2>/dev/null || true

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
SYSTEM_DOMAIN_ROUTING_DIR="${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}"
SYSTEM_INTERFACES_DIR="${SYSTEM_INTERFACES_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/state/interfaces}"
SYSTEM_GENERATED_DIR="${SYSTEM_GENERATED_DIR:-$SYSTEM_DOMAIN_ROUTING_DIR/generated/interfaces}"
CONF_DIR="${CONF_DIR:-$SCRIPT_DIR/conf}"
PROFILE_VPN_DIR="${PROFILE_VPN_DIR:-$PROFILE_DIR/vpn}"

run_log() {
    title="$1"
    shift
    ui_run_with_output "$title" "$@"
}

iface_dir_of() {
    printf '%s/%s\n' "$INTERFACES_DIR" "$1"
}

iface_config_dir_of() {
    printf '%s/config\n' "$(iface_dir_of "$1")"
}

iface_conf_of() {
    printf '%s/iface.conf\n' "$(iface_config_dir_of "$1")"
}

iface_network_uci_of() {
    printf '%s/network.uci\n' "$(iface_config_dir_of "$1")"
}

iface_firewall_uci_of() {
    printf '%s/firewall.uci\n' "$(iface_config_dir_of "$1")"
}

iface_source_conf_of() {
    printf '%s/source.conf\n' "$(iface_config_dir_of "$1")"
}

iface_source_meta_of() {
    printf '%s/source.conf.meta\n' "$(iface_config_dir_of "$1")"
}

system_iface_dir_of() {
    printf '%s/%s\n' "$SYSTEM_INTERFACES_DIR" "$1"
}

system_generated_dir_of() {
    printf '%s/%s\n' "$SYSTEM_GENERATED_DIR" "$1"
}

select_conf_file() {
    list_file="${UI_TMP_ROOT:-/tmp}/iface-source-conf-list.$$"
    : > "$list_file"

    detect_generator_kind() {
        meta_file="$1"
        [ -f "$meta_file" ] || return 1
        awk -F= '
            {
                gsub(/\r/, "")
            }
            $1 == "GENERATOR_KIND" {
                v = substr($0, index($0, "=") + 1)
                sub(/^[[:space:]]+/, "", v)
                sub(/[[:space:]]+$/, "", v)
                gsub(/\r/, "", v)
                gsub(/^\047|\047$/, "", v)
                print v
                exit
            }
        ' "$meta_file"
    }

    meta_get_value() {
        meta_file="$1"
        key="$2"
        [ -f "$meta_file" ] || return 1
        awk -F= -v want="$key" '
            {
                gsub(/\r/, "")
            }
            $1 == want {
                v = substr($0, index($0, "=") + 1)
                sub(/^[[:space:]]+/, "", v)
                sub(/[[:space:]]+$/, "", v)
                gsub(/\r/, "", v)
                gsub(/^\047|\047$/, "", v)
                print v
                exit
            }
        ' "$meta_file"
    }

    format_generated_local() {
        utc_value="$1"
        [ -n "${utc_value:-}" ] || return 1

        utc_plain="$utc_value"
        case "$utc_plain" in
            *Z) utc_plain="${utc_plain%Z}" ;;
        esac

        epoch=""
        epoch="$(date -u -D '%Y-%m-%dT%H:%M:%S' -d "$utc_plain" +%s 2>/dev/null || true)"
        case "$epoch" in ''|*[!0-9]*) epoch="" ;; esac
        if [ -z "$epoch" ]; then
            utc_sp="$(printf '%s' "$utc_plain" | tr 'T' ' ')"
            epoch="$(date -u -d "$utc_sp" +%s 2>/dev/null || true)"
            case "$epoch" in ''|*[!0-9]*) epoch="" ;; esac
        fi

        if [ -n "$epoch" ]; then
            local_value="$(date -d "@$epoch" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
            [ -n "${local_value:-}" ] || local_value="$(date -r "$epoch" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
            [ -n "${local_value:-}" ] || return 1
            printf '%s\n' "$local_value"
            return 0
        fi

        local_value="$(date -d "$utc_value" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
        if [ -n "${local_value:-}" ]; then
            printf '%s\n' "$local_value"
            return 0
        fi

        local_value="$(date -D '%Y-%m-%dT%H:%M:%SZ' -d "$utc_value" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
        [ -n "${local_value:-}" ] || return 1
        printf '%s\n' "$local_value"
    }

    add_conf_file() {
        f="$1"
        kind_default="$2"
        [ -f "$f" ] || return 0

        base="$(basename -- "$f")"
        meta_file="${f}.meta"
        kind="$(detect_generator_kind "$meta_file" 2>/dev/null || true)"
        [ -n "${kind:-}" ] || kind="$kind_default"
                server_name="$(meta_get_value "$meta_file" "SERVER_NAME" 2>/dev/null || true)"
                server_country="$(meta_get_value "$meta_file" "SERVER_COUNTRY" 2>/dev/null || true)"
                server_city="$(meta_get_value "$meta_file" "SERVER_CITY" 2>/dev/null || true)"
                peer_name="$(meta_get_value "$meta_file" "PEER_NAME" 2>/dev/null || true)"
                country_filter="$(meta_get_value "$meta_file" "COUNTRY_FILTER" 2>/dev/null || true)"
                server_id_meta="$(meta_get_value "$meta_file" "SERVER_ID" 2>/dev/null || true)"
                endpoint_label="$(meta_get_value "$meta_file" "ENDPOINT_LABEL" 2>/dev/null || true)"
                endpoint_host="$(meta_get_value "$meta_file" "ENDPOINT_HOST" 2>/dev/null || true)"
                profile_mode="$(meta_get_value "$meta_file" "PROFILE_MODE" 2>/dev/null || true)"
                generated_at_utc="$(meta_get_value "$meta_file" "GENERATED_AT_UTC" 2>/dev/null || true)"
                generated_at_local="$(format_generated_local "$generated_at_utc" 2>/dev/null || true)"
                [ -n "${generated_at_local:-}" ] || {
                    ts="$(stat -c '%Y' "$f" 2>/dev/null || true)"
                    case "$ts" in
                        ''|*[!0-9]*) generated_at_local="n/a" ;;
                        *)
                            generated_at_local="$(date -d "@$ts" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
                            [ -n "${generated_at_local:-}" ] || generated_at_local="n/a"
                            ;;
                    esac
                }

                hint_line="$(awk '
                    {
                        gsub(/\r/, "")
                    }
                    /^# XFREE_CONF_LIST_HINT=/ {
                        v = $0
                        sub(/^# XFREE_CONF_LIST_HINT=/, "", v)
                        print v
                        exit
                    }
                ' "$f" 2>/dev/null || true)"
                if [ -n "${hint_line:-}" ]; then
                    hint_name="$(printf '%s' "$hint_line" | cut -d '|' -f1)"
                    hint_country="$(printf '%s' "$hint_line" | cut -d '|' -f2)"
                    hint_city="$(printf '%s' "$hint_line" | cut -d '|' -f3-)"
                    [ -z "${server_name:-}" ] && [ -n "${hint_name:-}" ] && server_name="$hint_name"
                    [ -z "${server_country:-}" ] && [ -n "${hint_country:-}" ] && server_country="$hint_country"
                    [ -z "${server_city:-}" ] && [ -n "${hint_city:-}" ] && server_city="$hint_city"
                fi

                [ -n "${server_name:-}" ] || server_name="$peer_name"
                if [ -z "${server_name:-}" ]; then
                    server_name="$(awk '
                        {
                            gsub(/\r/, "")
                        }
                        /^# PROTON_DEVICE_NAME=/ { next }
                        /^# XFREE_CONF_LIST_HINT=/ { next }
                        /^# ---/ { next }
                        /^# mode:/ { next }
                        /^# original:/ { next }
                        /^# applied:/ { next }
                        /^# uci-recommendation:/ { next }
                        /^#   / { next }
                        /^# / { sub(/^# ?/, ""); print; exit }
                    ' "$f" 2>/dev/null || true)"
                fi
                case "${kind:-}" in
                    warp)
                        [ -n "${server_name:-}" ] || {
                            case "${server_id_meta:-}" in
                                ''|[!a-zA-Z0-9._-]*) ;;
                                *) server_name="$server_id_meta" ;;
                            esac
                        }
                        ;;
                esac
                if [ -z "${server_name:-}" ] && [ -n "${endpoint_label:-}" ]; then
                    server_name="$endpoint_label"
                fi
                if [ -z "${server_name:-}" ] && [ -n "${endpoint_host:-}" ]; then
                    server_name="$endpoint_host"
                fi
                [ -n "${server_name:-}" ] || server_name="${base%.conf}"

                [ -n "${server_country:-}" ] || server_country="$country_filter"
                if [ -z "${server_country:-}" ]; then
                    case "${kind:-}" in
                        warp) server_country="Cloudflare" ;;
                    esac
                fi
                if [ -z "${server_country:-}" ] && [ -n "${profile_mode:-}" ]; then
                    server_country="$profile_mode"
                fi
                [ -n "${server_country:-}" ] || server_country="-"

                if [ -z "${server_city:-}" ] && [ -n "${endpoint_label:-}" ]; then
                    server_city="$endpoint_label"
                fi
                if [ -z "${server_city:-}" ] && [ -n "${endpoint_host:-}" ]; then
                    server_city="$endpoint_host"
                fi
                if [ -z "${server_city:-}" ] && [ -n "${profile_mode:-}" ]; then
                    server_city="$profile_mode"
                fi
                [ -n "${server_city:-}" ] || server_city="-"

                case "${server_country:-}" in \?|'') server_country='-' ;; esac
                case "${server_city:-}" in \?|'') server_city='-' ;; esac

        label="[$generated_at_local] [$kind] $server_name ($server_country/$server_city)"
        printf '%s|%s\n' "$label" "$f" >> "$list_file"
    }

    add_conf_from_dir() {
        conf_dir="$1"
        kind_default="$2"
        [ -d "$conf_dir" ] || return 0
        for f in "$conf_dir"/*.conf; do
            [ -f "$f" ] || continue
            add_conf_file "$f" "$kind_default"
        done
    }

    provider_conf_dir() {
        provider="$1"
        case "$provider" in
            proton) xfree_profile_proton_conf_dir "$PROFILE_DIR" ;;
            warp) xfree_profile_warp_conf_dir "$PROFILE_DIR" ;;
            *) printf '%s/%s/conf\n' "$PROFILE_VPN_DIR" "$provider" ;;
        esac
    }

    add_conf_tree() {
        root="$1"
        [ -d "$root" ] || return 0

        for gen_dir in "$root"/*; do
            [ -d "$gen_dir" ] || continue
            gen_name="$(basename -- "$gen_dir")"
            conf_dir="$(provider_conf_dir "$gen_name")"
            add_conf_from_dir "$conf_dir" "$gen_name"
            if [ "$conf_dir" != "$gen_dir" ]; then
                add_conf_from_dir "$gen_dir" "$gen_name"
            fi
        done
    }

    add_conf_tree "$PROFILE_VPN_DIR"
    add_conf_from_dir "$PROFILE_VPN_DIR/custom" "custom"
    add_conf_from_dir "$PROFILE_VPN_DIR/amnezia" "amnezia"
    add_conf_from_dir "$CONF_DIR" "conf"
    add_conf_from_dir "/root" "root"
    add_conf_from_dir "/tmp" "tmp"

    lines="$(sort -u "$list_file")"
    set --
    idx=1
    if [ -s "$list_file" ]; then
        while IFS='|' read -r label path; do
            [ -n "${label:-}" ] || continue
            [ -n "${path:-}" ] || continue
            set -- "$@" "$idx" "$label"
            eval "UI_CONFSEL_$idx=\"\$path\""
            idx=$((idx + 1))
        done <<EOF
$lines
EOF
    fi
    rm -f "$list_file"

    set -- "$@" "m" "Ввести путь к файлу вручную"
    set -- "$@" "p" "Вставить текст конфига (буфер обмена)"

    choice="$(ui_menu "Исходные .conf" "Выберите .conf-файл или способ импорта" 22 110 12 "$@" || true)"
    [ -n "${choice:-}" ] || return 1

    case "$choice" in
        m)
            custom_path="$(ui_inputbox "Путь к .conf" "Введите полный путь к .conf файлу" "/root/client.conf" || true)"
            [ -n "${custom_path:-}" ] || return 1
            [ -f "$custom_path" ] || {
                ui_msgbox "Ошибка" "Файл не найден: $custom_path"
                return 1
            }
            if [ -x "$NORM_CONF_SCRIPT" ]; then
                "$NORM_CONF_SCRIPT" --in-place --write-meta "$custom_path" 2>/dev/null || true
            fi
            printf '%s\n' "$custom_path"
            ;;
        p)
            tmp_paste="${UI_TMP_ROOT:-/tmp}/conf-import-paste.$$"
            if ! ui_capture_tty_multiline_to_file "Вставка .conf файла" "$tmp_paste" "После сохранения откроется создание интерфейса."; then
                rm -f "$tmp_paste"
                return 1
            fi
            if [ ! -s "$tmp_paste" ]; then
                rm -f "$tmp_paste"
                ui_msgbox "Импорт .conf" "Пустой ввод. Отменено."
                return 1
            fi
            conf_name="$(ui_inputbox "Имя для сохранения" "Введите имя файла для сохранения в профиле:" "amnezia_custom" || true)"
            [ -n "$conf_name" ] || conf_name="amnezia_custom"
            conf_name="$(printf '%s' "$conf_name" | tr -cd 'A-Za-z0-9_-')"
            target_dir="$PROFILE_VPN_DIR/custom"
            mkdir -p "$target_dir"
            target_file="$target_dir/${conf_name}.conf"
            if [ -x "$NORM_CONF_SCRIPT" ]; then
                "$NORM_CONF_SCRIPT" --source "$tmp_paste" --dest "$target_file" --write-meta
            else
                mv "$tmp_paste" "$target_file"
            fi
            rm -f "$tmp_paste"
            printf '%s\n' "$target_file"
            ;;
        *)
            eval "selected_path=\${UI_CONFSEL_$choice:-}"
            [ -n "${selected_path:-}" ] || return 1
            printf '%s\n' "$selected_path"
            ;;
    esac
}

list_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    find "$INTERFACES_DIR" -type f -path '*/config/iface.conf' 2>/dev/null \
        | sed "s|$INTERFACES_DIR/||" \
        | sed 's|/config/iface.conf$||' \
        | sed '/^$/d' \
        | sort -u
}

select_interface_name() {
    lines="$(list_interfaces || true)"
    [ -n "${lines:-}" ] || {
        ui_msgbox "Интерфейсы" "Интерфейсы не найдены.

Сначала создайте интерфейс: пункт «Создать интерфейс из .conf»."
        return 1
    }
    ui_select_from_lines "Интерфейсы" "Выберите интерфейс" "$lines" 20 90 10
}

show_text_file() {
    title="$1"
    file="$2"
    [ -f "$file" ] || {
        ui_msgbox "Ошибка" "Файл не найден:\n$file"
        return 0
    }
    ui_show_textbox "$title" "$file" 30 110
}

suggest_next_iface_name() {
    idx=1
    while :; do
        if [ "$idx" -eq 1 ]; then
            iface="warp"
        else
            iface="warp$idx"
        fi
        [ -d "$INTERFACES_DIR/$iface" ] || {
            printf '%s\n' "$iface"
            return 0
        }
        idx=$((idx + 1))
    done
}

meta_get_value() {
    meta_file="$1"
    key="$2"
    [ -f "$meta_file" ] || return 1
    awk -F= -v want="$key" '
        {
            gsub(/\r/, "")
        }
        $1 == want {
            v = substr($0, index($0, "=") + 1)
            sub(/^[[:space:]]+/, "", v)
            sub(/[[:space:]]+$/, "", v)
            gsub(/\r/, "", v)
            gsub(/^\047|\047$/, "", v)
            print v
            exit
        }
    ' "$meta_file"
}

sanitize_iface_token() {
    token="$1"
    token="$(common_lower_ascii "$token" 2>/dev/null || printf '%s' "$token" | tr 'A-Z' 'a-z')"
    token="$(printf '%s' "$token" | sed 's/[^a-z0-9]/_/g; s/__*/_/g; s/^_//; s/_$//')"
    [ -n "$token" ] || token="vpn"
    printf '%s\n' "$token"
}

iface_name_taken() {
    want="$1"
    [ -n "$want" ] || return 0

    [ -d "$INTERFACES_DIR/$want" ] && return 0
    if list_interfaces 2>/dev/null | awk -v want="$want" '
        $0 == want { found=1 }
        END { exit(found ? 0 : 1) }
    '; then
        return 0
    fi
    return 1
}

next_iface_name_for_prefix() {
    prefix="$1"
    prefix="$(sanitize_iface_token "$prefix")"
    n=1
    while :; do
        candidate="${prefix}_${n}"
        if ! iface_name_taken "$candidate"; then
            printf '%s\n' "$candidate"
            return 0
        fi
        n=$((n + 1))
    done
}

build_iface_name_suggestions() {
    src_conf="$1"
    src_meta="${src_conf}.meta"

    kind="$(meta_get_value "$src_meta" "GENERATOR_KIND" 2>/dev/null || true)"
    country="$(meta_get_value "$src_meta" "SERVER_COUNTRY" 2>/dev/null || true)"
    city="$(meta_get_value "$src_meta" "SERVER_CITY" 2>/dev/null || true)"
    server_id="$(meta_get_value "$src_meta" "SERVER_ID" 2>/dev/null || true)"

    [ -n "${kind:-}" ] || kind="vpn"
    [ -n "${country:-}" ] || country="${server_id:-def}"
    [ -n "${country:-}" ] || country="def"
    [ -n "${city:-}" ] || city="site"

    kind_t="$(sanitize_iface_token "$kind")"
    country_t="$(sanitize_iface_token "$country")"
    city_t="$(sanitize_iface_token "$city")"

    suggested_auto="$(next_iface_name_for_prefix "${kind_t}_${country_t}")"
    suggested_with_city="$(next_iface_name_for_prefix "${kind_t}_${country_t}_${city_t}")"
    suggested_short="$(next_iface_name_for_prefix "${kind_t}")"

    printf '%s\t%s\t%s\n' "$suggested_auto" "$suggested_with_city" "$suggested_short"
}

choose_create_mode() {
    suggested_auto="$1"
    suggested_with_city="$2"
    suggested_short="$3"

    ui_menu "Создание интерфейса" "Выберите режим" 18 96 10 \
        "1" "Авто: $suggested_auto" \
        "2" "Авто: $suggested_with_city" \
        "3" "Авто: $suggested_short" \
        "4" "Ввести вручную" \
        "0" "Назад"
}

create_interface_from_file() {
    src_conf="$1"
    [ -n "${src_conf:-}" ] || return 0

    suggestions="$(build_iface_name_suggestions "$src_conf")"
    suggested_auto="$(printf '%s\n' "$suggestions" | awk -F "$(printf '\t')" '{print $1}')"
    suggested_with_city="$(printf '%s\n' "$suggestions" | awk -F "$(printf '\t')" '{print $2}')"
    suggested_short="$(printf '%s\n' "$suggestions" | awk -F "$(printf '\t')" '{print $3}')"
    [ -n "${suggested_auto:-}" ] || suggested_auto="$(suggest_next_iface_name)"
    [ -n "${suggested_with_city:-}" ] || suggested_with_city="$suggested_auto"
    [ -n "${suggested_short:-}" ] || suggested_short="$suggested_auto"

    mode="$(choose_create_mode "$suggested_auto" "$suggested_with_city" "$suggested_short" || true)"
    [ -n "${mode:-}" ] || return 0

    case "$mode" in
        1)
            run_log "Создание интерфейса из .conf" \
                "$CONVERTER_SCRIPT" \
                --iface "$suggested_auto" \
                --source "$src_conf"
            ;;
        2)
            run_log "Создание интерфейса из .conf: $suggested_with_city" \
                "$CONVERTER_SCRIPT" \
                --iface "$suggested_with_city" \
                --source "$src_conf"
            ;;
        3)
            run_log "Создание интерфейса из .conf: $suggested_short" \
                "$CONVERTER_SCRIPT" \
                --iface "$suggested_short" \
                --source "$src_conf"
            ;;
        4)
            iface_name="$(ui_inputbox "Имя интерфейса" "Введите имя интерфейса (по умолчанию авто-вариант)" "$suggested_auto" || true)"
            [ -n "${iface_name:-}" ] || return 0
            run_log "Создание интерфейса из .conf: $iface_name" \
                "$CONVERTER_SCRIPT" \
                --iface "$iface_name" \
                --source "$src_conf"
            ;;
        0) return 0 ;;
    esac
}

create_interface() {
    src_conf="$(select_conf_file || true)"
    [ -n "${src_conf:-}" ] || return 0
    create_interface_from_file "$src_conf"
}

import_conf_interactive() {
    import_choice="$(ui_menu "Импорт .conf (Amnezia / WireGuard)" "Выберите способ импорта конфигурации:" 18 90 6 \
        "1" "Из файла на роутере (указать путь)" \
        "2" "Вставить текст конфига (буфер обмена)" \
        "0" "Назад" || true)"

    [ -n "${import_choice:-}" ] || return 0
    target_file=""

    case "$import_choice" in
        1)
            custom_path="$(ui_inputbox "Путь к .conf" "Введите полный путь к .conf файлу" "/root/client.conf" || true)"
            [ -n "${custom_path:-}" ] || return 0
            [ -f "$custom_path" ] || {
                ui_msgbox "Ошибка" "Файл не найден: $custom_path"
                return 0
            }
            base_name="$(basename "$custom_path" .conf)"
            target_dir="$PROFILE_VPN_DIR/custom"
            mkdir -p "$target_dir"
            target_file="$target_dir/${base_name}.conf"
            if [ -x "$NORM_CONF_SCRIPT" ]; then
                "$NORM_CONF_SCRIPT" --source "$custom_path" --dest "$target_file" --write-meta
            else
                cp -f "$custom_path" "$target_file"
            fi
            ;;
        2)
            tmp_paste="${UI_TMP_ROOT:-/tmp}/conf-import-paste.$$"
            if ! ui_capture_tty_multiline_to_file "Вставка .conf файла" "$tmp_paste" "После сохранения откроется создание интерфейса."; then
                rm -f "$tmp_paste"
                return 0
            fi
            if [ ! -s "$tmp_paste" ]; then
                rm -f "$tmp_paste"
                ui_msgbox "Импорт .conf" "Пустой ввод. Отменено."
                return 0
            fi
            conf_name="$(ui_inputbox "Имя для сохранения" "Введите имя файла для сохранения в профиле:" "amnezia_custom" || true)"
            [ -n "$conf_name" ] || conf_name="amnezia_custom"
            conf_name="$(printf '%s' "$conf_name" | tr -cd 'A-Za-z0-9_-')"
            target_dir="$PROFILE_VPN_DIR/custom"
            mkdir -p "$target_dir"
            target_file="$target_dir/${conf_name}.conf"
            if [ -x "$NORM_CONF_SCRIPT" ]; then
                "$NORM_CONF_SCRIPT" --source "$tmp_paste" --dest "$target_file" --write-meta
            else
                mv "$tmp_paste" "$target_file"
            fi
            rm -f "$tmp_paste"
            ;;
        0|*) return 0 ;;
    esac

    [ -n "$target_file" ] && [ -f "$target_file" ] || return 0

    if ui_confirm "Создание интерфейса" "Конфиг успешно сохранён и нормализован:\n$target_file\n\nСоздать интерфейс роутера сейчас?"; then
        create_interface_from_file "$target_file"
    fi
}

select_ovpn_file() {
    list_file="${UI_TMP_ROOT:-/tmp}/ovpn-source-list.$$"
    : > "$list_file"

    scan_ovpn_dir() {
        d="$1"
        [ -d "$d" ] || return 0
        for f in "$d"/*.ovpn; do
            [ -f "$f" ] || continue
            printf '%s|%s\n' "$(basename "$f")" "$f" >> "$list_file"
        done
    }

    scan_ovpn_dir "$CONF_DIR"
    scan_ovpn_dir "$PROFILE_VPN_DIR/openvpn"
    scan_ovpn_dir "$PROFILE_DIR"
    scan_ovpn_dir "/root"
    scan_ovpn_dir "/tmp"

    set --
    idx=1
    if [ -s "$list_file" ]; then
        while IFS='|' read -r label path; do
            [ -n "$label" ] || continue
            set -- "$@" "$idx" "$label ($path)"
            eval "UI_OVPENSEL_$idx=\"\$path\""
            idx=$((idx + 1))
        done < "$list_file"
    fi
    rm -f "$list_file"

    set -- "$@" "m" "Ввести путь к файлу вручную"

    choice="$(ui_menu "Выбор .ovpn файла" "Выберите файл OpenVPN или укажите путь" 20 90 10 "$@" || true)"
    [ -n "${choice:-}" ] || return 1

    case "$choice" in
        m)
            custom_path="$(ui_inputbox "Путь к .ovpn" "Введите полный путь к .ovpn файлу" "/root/client.ovpn" || true)"
            [ -n "${custom_path:-}" ] || return 1
            [ -f "$custom_path" ] || {
                ui_msgbox "Ошибка" "Файл не найден: $custom_path"
                return 1
            }
            printf '%s\n' "$custom_path"
            ;;
        *)
            eval "selected_path=\${UI_OVPENSEL_$choice:-}"
            [ -n "${selected_path:-}" ] || return 1
            printf '%s\n' "$selected_path"
            ;;
    esac
}

create_openvpn_interface() {
    ovpn_file="$(select_ovpn_file || true)"
    [ -n "${ovpn_file:-}" ] || return 0

    base_name="$(basename "$ovpn_file" .ovpn)"
    default_iface="$(sanitize_iface_token "$base_name")"
    if iface_name_taken "$default_iface"; then
        default_iface="$(next_iface_name_for_prefix "$default_iface")"
    fi

    iface_name="$(ui_inputbox "Имя интерфейса" "Введите имя интерфейса для OpenVPN (например work, corp)" "$default_iface" || true)"
    [ -n "${iface_name:-}" ] || return 0

    # Проверяем, требует ли .ovpn авторизации или static-challenge (2FA)
    needs_auth=0
    needs_static_challenge=0
    if grep -E '^[[:space:]]*auth-user-pass' "$ovpn_file" >/dev/null 2>&1; then
        needs_auth=1
    fi
    if grep -E '^[[:space:]]*static-challenge' "$ovpn_file" >/dev/null 2>&1; then
        needs_static_challenge=1
    fi

    auth_user=""
    auth_pass=""
    totp_secret=""

    ask_auth=0
    if [ "$needs_auth" = "1" ] || [ "$needs_static_challenge" = "1" ]; then
        ask_auth=1
    elif ui_confirm "Авторизация OpenVPN" "Требуется ли логин и пароль для подключения к этому туннелю?"; then
        ask_auth=1
    fi

    if [ "$ask_auth" = "1" ]; then
        auth_user="$(ui_inputbox "Логин OpenVPN" "Введите имя пользователя (login):" "" || true)"
        [ -n "$auth_user" ] || { ui_msgbox "Отмена" "Логин не указан, создание интерфейса отменено."; return 0; }

        auth_pass="$(ui_passwordbox "Пароль OpenVPN" "Введите пароль:" "" || true)"
        [ -n "$auth_pass" ] || { ui_msgbox "Отмена" "Пароль не указан, создание интерфейса отменено."; return 0; }

        want_totp=0
        if [ "$needs_static_challenge" = "1" ]; then
            want_totp=1
        elif ui_confirm "Двухфакторная аутентификация (2FA / TOTP)" "Используется ли двухфакторная аутентификация (динамический 6-значный OTP код из приложения на телефоне)?"; then
            want_totp=1
        fi

        if [ "$want_totp" = "1" ]; then
            totp_secret="$(ui_passwordbox "Секретный ключ TOTP (2FA)" "Введите секретный ключ Base32 или otpauth:// ссылку (из Яндекс Ключ):" "" || true)"
            totp_secret="$(printf '%s' "$totp_secret" | tr -d ' \t\r\n')"
            case "$totp_secret" in
                *secret=*)
                    totp_secret="${totp_secret#*secret=}"
                    totp_secret="${totp_secret%%&*}"
                    ;;
            esac
            if [ -n "$totp_secret" ]; then
                totp_script="$SCRIPT_DIR/vpn/openvpn/totp-gen.sh"
                if [ -x "$totp_script" ]; then
                    test_code="$("$totp_script" "$totp_secret" 2>/dev/null || true)"
                    if [ -n "$test_code" ]; then
                        ui_msgbox "TOTP ключ подтверждён" "Код TOTP успешно рассчитан: $test_code\n(Сверьте с приложением на телефоне)"
                    else
                        ui_msgbox "Внимание" "Не удалось рассчитать код из ключа. Проверьте правильность Base32 строки."
                    fi
                fi
            fi
        fi
    fi

    set -- "$OVPN_CONVERTER_SCRIPT" --source "$ovpn_file" --iface "$iface_name"
    if [ -n "$auth_user" ]; then
        set -- "$@" --auth-user "$auth_user" --auth-pass "$auth_pass"
    fi
    if [ -n "$totp_secret" ]; then
        set -- "$@" --totp-secret "$totp_secret"
    fi

    run_log "Создание OpenVPN интерфейса: $iface_name" "$@"

    if [ -x "$OPENVPN_ENSURE_SCRIPT" ]; then
        if ! "$OPENVPN_ENSURE_SCRIPT" --check >/dev/null 2>&1; then
            if ui_confirm "OpenVPN не установлен" "Пакет OpenVPN не установлен в системе. Установить сейчас (~0.4 MB)?"; then
                run_log "Установка OpenVPN" "$OPENVPN_ENSURE_SCRIPT" --install-if-missing
            fi
        fi
    fi

    if ui_confirm "Применение интерфейса" "Интерфейс '$iface_name' успешно создан в профиле.\nПрименить его прямо сейчас на роутере?"; then
        run_log "Применение интерфейса: $iface_name" "$APPLY_INTERFACES_SCRIPT" --iface "$iface_name"
    fi
}

open_protocols_menu() {
    if [ -f "$PROTOCOLS_MENU_SCRIPT" ]; then
        sh "$PROTOCOLS_MENU_SCRIPT"
    else
        ui_msgbox "Ошибка" "Скрипт управления протоколами не найден: $PROTOCOLS_MENU_SCRIPT"
    fi
}

update_interface() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0

    src_conf="$(select_conf_file || true)"
    [ -n "${src_conf:-}" ] || return 0

    run_log "Обновление интерфейса из .conf: $iface" \
        "$UPDATE_INTERFACE_CONFIG_SCRIPT" \
        --iface "$iface" \
        --source "$src_conf"
}

regenerate_interface_config_for_iface() {
    iface="$1"
    [ -n "${iface:-}" ] || return 0

    run_log "Пересоздание конфигурации: $iface" \
        "$REGENERATE_INTERFACE_SCRIPT" \
        --iface "$iface" \
        --force
}

list_template_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    find "$INTERFACES_DIR" -type f -path '*/config/TEMPLATE' 2>/dev/null \
        | sed "s|$INTERFACES_DIR/||" \
        | sed 's|/config/TEMPLATE$||' \
        | sed '/^$/d' \
        | sort -u
}

regenerate_selected_interface() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0
    regenerate_interface_config_for_iface "$iface"
}

regenerate_all_template_interfaces() {
    lines="$(list_template_interfaces || true)"
    [ -n "${lines:-}" ] || {
        ui_msgbox "Пересоздать конфигурацию" "Template-интерфейсы не найдены."
        return 0
    }

    while IFS= read -r iface; do
        [ -n "${iface:-}" ] || continue
        regenerate_interface_config_for_iface "$iface"
    done <<EOF
$lines
EOF
}

regenerate_all_interfaces() {
    lines="$(list_interfaces || true)"
    [ -n "${lines:-}" ] || {
        ui_msgbox "Пересоздать конфигурацию" "Интерфейсы не найдены."
        return 0
    }

    while IFS= read -r iface; do
        [ -n "${iface:-}" ] || continue
        regenerate_interface_config_for_iface "$iface"
    done <<EOF
$lines
EOF
}

regenerate_interface_menu() {
    while true; do
        choice="$(ui_menu "Пересоздать конфигурацию" "Выберите, для каких интерфейсов пересоздать конфигурацию" 20 96 10 \
            "1" "Выбрать интерфейс" \
            "2" "Для template-интерфейсов" \
            "3" "Для всех интерфейсов" \
            "0" "Назад" || true)"

        [ -n "${choice:-}" ] || return 0
        case "$choice" in
            1) regenerate_selected_interface ;;
            2) regenerate_all_template_interfaces ;;
            3) regenerate_all_interfaces ;;
            0) return 0 ;;
        esac
    done
}

apply_interface_to_system() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0

    run_log "Применение интерфейса: $iface" \
        "$APPLY_INTERFACES_SCRIPT" \
        --iface "$iface"
}

apply_all_interfaces_to_system() {
    run_log "Применение всех интерфейсов" \
        "$APPLY_INTERFACES_SCRIPT" \
        --all
}

build_interfaces_status_text() {
    out="$1"
    {
        echo "Интерфейсы"
        echo
        echo "Статусы: да = найдено, нет = отсутствует"
        echo

        lines="$(list_interfaces || true)"
        if [ -z "${lines:-}" ]; then
            echo "Интерфейсы не найдены."
            exit 0
        fi

        printf '%s\n' "$lines" | while IFS= read -r iface; do
            [ -n "$iface" ] || continue

            work="нет"
            system_copy="нет"
            generated="нет"
            fqdn_lists="нет"
            prefix_lists="нет"
            source_conf="нет"
            generator_kind=""
            server_name=""
            proton_device_name=""
            meta_file="$(iface_source_meta_of "$iface")"

            [ -d "$(iface_dir_of "$iface")" ] && work="да"
            [ -d "$(system_iface_dir_of "$iface")" ] && system_copy="да"
            [ -d "$(system_generated_dir_of "$iface")" ] && generated="да"

            find "$(iface_dir_of "$iface")/fqdn.d" -maxdepth 1 -type f 2>/dev/null | grep -q . && fqdn_lists="да" || true
            find "$(iface_dir_of "$iface")/prefixes.d" -maxdepth 1 -type f 2>/dev/null | grep -q . && prefix_lists="да" || true
            [ -f "$(iface_source_conf_of "$iface")" ] && source_conf="да"
            generator_kind="$(meta_get_value "$meta_file" "GENERATOR_KIND" 2>/dev/null || true)"
            session_name="$(meta_get_value "$meta_file" "SESSION_NAME" 2>/dev/null || true)"
            session_auth="$(meta_get_value "$meta_file" "SESSION_AUTH_MODE" 2>/dev/null || true)"
            cert_utc="$(meta_get_value "$meta_file" "CERT_EXPIRATION_UTC" 2>/dev/null || true)"
            server_name="$(meta_get_value "$meta_file" "SERVER_NAME" 2>/dev/null || true)"
            proton_device_name="$(meta_get_value "$meta_file" "PROTON_DEVICE_NAME" 2>/dev/null || true)"

            echo "[$iface]"
            echo "  profile workdir   : $work"
            echo "  system state copy : $system_copy"
            echo "  generated cache   : $generated"
            echo "  source.conf       : $source_conf"
            echo "  fqdn.d files      : $fqdn_lists"
            echo "  prefixes.d files  : $prefix_lists"
            [ -n "${generator_kind:-}" ] && echo "  generator kind    : $generator_kind"
            [ -n "${session_auth:-}" ] && echo "  session auth      : $session_auth"
            [ -n "${session_name:-}" ] && echo "  session name      : $session_name"
            [ -n "${cert_utc:-}" ] && echo "  cert until        : $cert_utc"
            [ -n "${server_name:-}" ] && echo "  server name       : $server_name"
            [ -n "${proton_device_name:-}" ] && echo "  proton device     : $proton_device_name"
            echo
        done
    } > "$out"
}

show_interfaces_list() {
    out="${UI_TMP_ROOT:-/tmp}/interfaces-status.txt"
    build_interfaces_status_text "$out"
    ui_show_textbox "Список интерфейсов" "$out" 30 110
}

delete_interface() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0

    if ! ui_confirm "Удаление интерфейса" "Удалить интерфейс '$iface'?

Будет удалён каталог:
$INTERFACES_DIR/$iface"; then
        return 0
    fi

    if [ -x "$DELETE_INTERFACE_SCRIPT" ]; then
        extra_delete_args=''
        delete_mode="$(ui_menu "Удаление интерфейса" "Выберите режим очистки runtime после удаления '$iface'" 20 100 12 \
            "1" "Базовый (только удаляемый интерфейс)" \
            "2" "Базовый + full reconcile (apply-routing)" \
            "3" "Базовый + cleanup сирот self-route" \
            "4" "Базовый + full reconcile + cleanup сирот" \
            "0" "Отмена" || true)"
        [ -n "${delete_mode:-}" ] || return 0
        case "$delete_mode" in
            1) extra_delete_args='' ;;
            2) extra_delete_args='--full-reconcile' ;;
            3) extra_delete_args='--cleanup-orphans' ;;
            4) extra_delete_args='--full-reconcile --cleanup-orphans' ;;
            0) return 0 ;;
            *) return 0 ;;
        esac

        if ui_confirm "Удаление интерфейса из системы" "Удалить интерфейс '$iface' также из системы?

Будут удалены UCI/network/firewall-привязки этого интерфейса."; then
            set -- "$DELETE_INTERFACE_SCRIPT" --iface "$iface" --purge-files
            for arg in $extra_delete_args; do
                set -- "$@" "$arg"
            done
            run_log "Удаление интерфейса из системы: $iface" "$@"
        else
            rm -rf "$INTERFACES_DIR/$iface"
            ui_msgbox "Удаление интерфейса" "Каталог интерфейса удалён.

Системная конфигурация не изменялась.
Для очистки runtime затем выполните:
Применить выбранные сайты"
        fi
    else
        ui_msgbox "Удаление интерфейса" "Каталог интерфейса удалён.

Скрипт delete-interface.sh не найден или не исполняем.
Если интерфейс ранее применялся в систему, удалите его системную конфигурацию отдельно."
    fi
}

show_interface_menu() {
    iface="$(select_interface_name || true)"
    [ -n "${iface:-}" ] || return 0

    while true; do
        choice="$(ui_menu "Интерфейс: $iface" "Выберите действие" 26 92 18 \
            "1" "Показать iface.conf" \
            "2" "Показать source.conf" \
            "3" "Показать source.conf.meta" \
            "4" "Показать network.uci" \
            "5" "Показать firewall.uci" \
            "0" "Назад" || true)"

        [ -n "${choice:-}" ] || return 0
        case "$choice" in
            1) show_text_file "iface.conf" "$(iface_conf_of "$iface")" ;;
            2) show_text_file "source.conf" "$(iface_source_conf_of "$iface")" ;;
            3) show_text_file "source.conf.meta" "$(iface_source_meta_of "$iface")" ;;
            4) show_text_file "network.uci" "$(iface_network_uci_of "$iface")" ;;
            5) show_text_file "firewall.uci" "$(iface_firewall_uci_of "$iface")" ;;
            0) return 0 ;;
        esac
    done
}

iface_dispatch_core_choice() {
    choice="$1"
    case "$choice" in
        1) "$WARP_MENU_SCRIPT" ui ;;
        2) "$PROTON_MENU_SCRIPT" ui ;;
        3) show_interfaces_list ;;
        4) create_interface ;;
        5) update_interface ;;
        6) regenerate_interface_menu ;;
        7) apply_interface_to_system ;;
        8) apply_all_interfaces_to_system ;;
        9) delete_interface ;;
        10) show_interface_menu ;;
        13) create_openvpn_interface ;;
        14) open_protocols_menu ;;
        15) import_conf_interactive ;;
        *) return 1 ;;
    esac
}

main_menu() {
    while true; do
        choice="$(ui_menu "VPN-туннели" "Выберите действие" 26 96 18 \
            "1" "Генератор WARP-конфигов" \
            "2" "Генератор Proton-конфигов" \
            "3" "Показать список туннелей" \
            "4" "Создать туннель из .conf" \
            "15" "Импорт .conf (Amnezia / WG / буфер)" \
            "13" "Создать туннель из .ovpn" \
            "5" "Обновить туннель из .conf" \
            "6" "Пересобрать конфиг туннеля" \
            "7" "Применить туннель на роутере" \
            "8" "Применить все туннели" \
            "9" "Удалить туннель" \
            "10" "Показать настройки туннеля" \
            "14" "Компоненты протоколов VPN" \
            "0" "Назад" || true)"

        [ -n "${choice:-}" ] || exit 0
        case "$choice" in
            0) exit 0 ;;
            *)
                iface_dispatch_core_choice "$choice" || true
                ;;
        esac
    done
}

if [ "${MENU_INTERFACES_SOURCED:-0}" != 1 ]; then
    case "${1:-}" in
        ui) main_menu ;;
        *) echo "Usage: $0 ui"; exit 1 ;;
    esac
fi
