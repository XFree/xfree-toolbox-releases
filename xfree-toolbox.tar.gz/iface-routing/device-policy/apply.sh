#!/bin/sh
# shellcheck shell=sh
# Apply device routing policies (Direct WAN / VPN bypass / Zapret bypass / Forced tunnel / Forced Zapret).
# Spec: project/specs/device-routing-policy.md

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="${ROOT_DIR}/lib/common.sh"
[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

LIB_SH="${SCRIPT_DIR}/lib.sh"
[ -f "$LIB_SH" ] || die "Не найден lib.sh: $LIB_SH"
. "$LIB_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
GEN_DIR="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/device-policy/generated"
NFT_INCLUDE_DIR="${NFT_INCLUDE_DIR:-/etc/nftables.d}"
ZAPRET_CUSTOM_D="${ZAPRET_CUSTOM_D:-/opt/zapret/init.d/openwrt/custom.d}"

QUIET=0
APPLY_FW=1

while [ "$#" -gt 0 ]; do
    case "$1" in
        --profile-dir)
            [ "$#" -ge 2 ] || die "--profile-dir requires value"
            PROFILE_DIR="$2"
            shift 2
            ;;
        --apply)
            # Flag for compatibility with RPC / runner
            shift
            ;;
        --no-fw-reload)
            APPLY_FW=0
            shift
            ;;
        --quiet|-q)
            QUIET=1
            shift
            ;;
        -h|--help)
            cat <<EOF
Usage: $(basename "$0") [options]

Options:
  --profile-dir <DIR>   Set active profile directory
  --no-fw-reload        Generate rules without fw4 reload
  --quiet, -q           Suppress informational messages
EOF
            exit 0
            ;;
        *)
            die "Unknown option: $1"
            ;;
    esac
done

CFG="$(device_policy_conf_path "$PROFILE_DIR")"
mkdir -p "$GEN_DIR" 2>/dev/null || true

# Helper to find mark_hex for an interface
get_iface_mark() {
    _target_iface="$1"
    _mark=""
    for _cf in \
        "$PROFILE_DIR/iface-routing/interfaces/$_target_iface/config/iface.conf" \
        "$ROOT_DIR/iface-routing/interfaces/$_target_iface/config/iface.conf" \
        "$ROOT_DIR/profile-templates/warp-proton/iface-routing/interfaces/$_target_iface/config/iface.conf" \
        "$ROOT_DIR/profiles/default/iface-routing/interfaces/$_target_iface/config/iface.conf"; do
        if [ -f "$_cf" ]; then
            _mark="$(grep -E '^MARK_HEX=' "$_cf" 2>/dev/null | head -n1 | cut -d'=' -f2 | tr -d "'\" ")"
            [ -n "$_mark" ] && break
        fi
    done
    if [ -z "$_mark" ]; then
        case "$_target_iface" in
            warp) _mark="0x1201" ;;
            proton) _mark="0x1202" ;;
            amneziavpn*|amnezia*) _mark="0x1203" ;;
            *) _mark="0x1201" ;;
        esac
    fi
    printf '%s\n' "$_mark"
}

remove_firewall_include() {
    _path="$1"
    command -v uci >/dev/null 2>&1 || return 0
    _changed=0
    for _sec in $(uci show firewall 2>/dev/null | grep -E '\.path=' | grep -F "$_path" | cut -d'.' -f2 | cut -d'=' -f1); do
        uci delete firewall."$_sec" 2>/dev/null || true
        _changed=1
    done
    [ "$_changed" = "1" ] && uci commit firewall 2>/dev/null || true
}

_vpn_ips=""
_vpn_macs=""
_zapret_bypass_ips=""
_zapret_bypass_macs=""
_zapret_force_ips=""
_zapret_force_macs=""

# Temp files for forced interfaces
FORCED_DIR="$GEN_DIR/forced_tmp_$$"
rm -rf "$FORCED_DIR" 2>/dev/null || true
mkdir -p "$FORCED_DIR"

if [ -f "$CFG" ]; then
    while IFS='|' read -r _id _name _ip _mac _sv _sz _comment _fi _fz || [ -n "$_id" ]; do
        [ -n "$_id" ] || continue
        case "$_id" in
            \#*) continue ;;
        esac

        _n_ip="$(device_policy_normalize_ip "${_ip:-}")"
        _n_mac="$(device_policy_normalize_mac "${_mac:-}")"
        _sv="${_sv:-1}"
        _sz="${_sz:-1}"
        _fi="${_fi:-}"
        _fz="${_fz:-0}"

        # 1. VPN routing logic
        if [ -n "$_fi" ]; then
            # Forced into specific tunnel interface
            printf '%s\n' "$_fi" >> "$FORCED_DIR/ifaces.list"
            [ -n "$_n_ip" ] && printf '%s\n' "$_n_ip" >> "$FORCED_DIR/${_fi}_ips.list"
            [ -n "$_n_mac" ] && printf '%s\n' "$_n_mac" >> "$FORCED_DIR/${_fi}_macs.list"
        elif [ "$_sv" = "1" ]; then
            # Bypass VPN (Direct WAN)
            [ -n "$_n_ip" ] && _vpn_ips="${_vpn_ips}${_vpn_ips:+ }${_n_ip}"
            [ -n "$_n_mac" ] && _vpn_macs="${_vpn_macs}${_vpn_macs:+ }${_n_mac}"
        fi

        # 2. Zapret routing logic
        if [ "$_fz" = "1" ]; then
            # Forced Zapret
            [ -n "$_n_ip" ] && _zapret_force_ips="${_zapret_force_ips}${_zapret_force_ips:+ }${_n_ip}"
            [ -n "$_n_mac" ] && _zapret_force_macs="${_zapret_force_macs}${_zapret_force_macs:+ }${_n_mac}"
        elif [ "$_sz" = "1" ]; then
            # Bypass Zapret
            [ -n "$_n_ip" ] && _zapret_bypass_ips="${_zapret_bypass_ips}${_zapret_bypass_ips:+ }${_n_ip}"
            [ -n "$_n_mac" ] && _zapret_bypass_macs="${_zapret_bypass_macs}${_zapret_bypass_macs:+ }${_n_mac}"
        fi
    done < "$CFG"
fi

# 1. Generate VPN rules for table inet fw4 (bypass + force)
VPN_NFT_FILE="$GEN_DIR/10-xfree-device-policy-vpn.nft"
{
    echo "# Autogenerated by xfree-toolbox device-policy"
    echo "set xfree_device_bypass_vpn4 {"
    echo "    type ipv4_addr"
    echo "    flags interval"
    echo "    auto-merge"
    echo "    comment \"xfree: device bypass VPN by IPv4\""
    if [ -n "$_vpn_ips" ]; then
        echo "    elements = {"
        for ip in $_vpn_ips; do
            case "$ip" in
                */*) printf '        %s,\n' "$ip" ;;
                *) printf '        %s/32,\n' "$ip" ;;
            esac
        done | sed '$ s/,$//'
        echo "    }"
    fi
    echo "}"
    echo ""
    echo "set xfree_device_bypass_vpn_mac {"
    echo "    type ether_addr"
    echo "    comment \"xfree: device bypass VPN by MAC\""
    if [ -n "$_vpn_macs" ]; then
        echo "    elements = {"
        for mac in $_vpn_macs; do
            printf '        %s,\n' "$mac"
        done | sed '$ s/,$//'
        echo "    }"
    fi
    echo "}"
    echo ""
    # Forced tunnels
    _unique_ifaces=""
    if [ -f "$FORCED_DIR/ifaces.list" ]; then
        _unique_ifaces="$(sort -u "$FORCED_DIR/ifaces.list")"
    fi

    for iface in $_unique_ifaces; do
        _mark="$(get_iface_mark "$iface")"
        echo "set xfree_device_force_${iface}4 {"
        echo "    type ipv4_addr"
        echo "    flags interval"
        echo "    auto-merge"
        echo "    comment \"xfree: force $iface tunnel by IPv4\""
        if [ -f "$FORCED_DIR/${iface}_ips.list" ]; then
            echo "    elements = {"
            while read -r ip || [ -n "$ip" ]; do
                [ -n "$ip" ] || continue
                case "$ip" in
                    */*) printf '        %s,\n' "$ip" ;;
                    *) printf '        %s/32,\n' "$ip" ;;
                esac
            done < "$FORCED_DIR/${iface}_ips.list" | sed '$ s/,$//'
            echo "    }"
        fi
        echo "}"
        echo ""
        echo "set xfree_device_force_${iface}_mac {"
        echo "    type ether_addr"
        echo "    comment \"xfree: force $iface tunnel by MAC\""
        if [ -f "$FORCED_DIR/${iface}_macs.list" ]; then
            echo "    elements = {"
            while read -r mac || [ -n "$mac" ]; do
                [ -n "$mac" ] || continue
                printf '        %s,\n' "$mac"
            done < "$FORCED_DIR/${iface}_macs.list" | sed '$ s/,$//'
            echo "    }"
        fi
        echo "}"
        echo ""
    done

    echo "chain mangle_prerouting_device_force {"
    echo "    type filter hook prerouting priority mangle + 4; policy accept;"
    for iface in $_unique_ifaces; do
        _mark="$(get_iface_mark "$iface")"
        echo "    ip saddr @xfree_device_force_${iface}4 counter meta mark set $_mark accept comment \"xfree: force $iface tunnel by IP\""
        echo "    ether saddr @xfree_device_force_${iface}_mac counter meta mark set $_mark accept comment \"xfree: force $iface tunnel by MAC\""
    done
    echo "}"
    echo ""
    echo "chain mangle_prerouting_device_bypass {"
    echo "    type filter hook prerouting priority mangle + 5; policy accept;"
    echo "    ip saddr @xfree_device_bypass_vpn4 counter meta mark set 0x0 return comment \"xfree: device bypass VPN marks\""
    echo "    ether saddr @xfree_device_bypass_vpn_mac counter meta mark set 0x0 return comment \"xfree: device bypass VPN marks\""
    echo "}"
} > "$VPN_NFT_FILE"

rm -rf "$FORCED_DIR" 2>/dev/null || true

# Install into /etc/nftables.d so fw4 automatically loads it (avoid duplicate uci firewall include)
mkdir -p "$NFT_INCLUDE_DIR" 2>/dev/null || true
cp -f "$VPN_NFT_FILE" "$NFT_INCLUDE_DIR/10-xfree-device-policy.nft" 2>/dev/null || true
remove_firewall_include "$NFT_INCLUDE_DIR/10-xfree-device-policy.nft"

# 2. Generate Zapret bypass and force NFT rules for table inet zapret
ZAPRET_NFT_FILE="$GEN_DIR/zapret-device-policy.nft"
{
    echo "# Autogenerated by xfree-toolbox device-policy for zapret"
    echo "table inet zapret {"
    echo "    set xfree_device_bypass_zapret4 {"
    echo "        type ipv4_addr"
    echo "        flags interval"
    echo "        auto-merge"
    if [ -n "$_zapret_bypass_ips" ]; then
        echo "        elements = {"
        for ip in $_zapret_bypass_ips; do
            case "$ip" in
                */*) printf '            %s,\n' "$ip" ;;
                *) printf '            %s/32,\n' "$ip" ;;
            esac
        done | sed '$ s/,$//'
        echo "        }"
    fi
    echo "    }"
    echo ""
    echo "    set xfree_device_bypass_zapret_mac {"
    echo "        type ether_addr"
    if [ -n "$_zapret_bypass_macs" ]; then
        echo "        elements = {"
        for mac in $_zapret_bypass_macs; do
            printf '            %s,\n' "$mac"
        done | sed '$ s/,$//'
        echo "        }"
    fi
    echo "    }"
    echo ""
    echo "    set xfree_device_force_zapret4 {"
    echo "        type ipv4_addr"
    echo "        flags interval"
    echo "        auto-merge"
    if [ -n "$_zapret_force_ips" ]; then
        echo "        elements = {"
        for ip in $_zapret_force_ips; do
            case "$ip" in
                */*) printf '            %s,\n' "$ip" ;;
                *) printf '            %s/32,\n' "$ip" ;;
            esac
        done | sed '$ s/,$//'
        echo "        }"
    fi
    echo "    }"
    echo ""
    echo "    set xfree_device_force_zapret_mac {"
    echo "        type ether_addr"
    if [ -n "$_zapret_force_macs" ]; then
        echo "        elements = {"
        for mac in $_zapret_force_macs; do
            printf '            %s,\n' "$mac"
        done | sed '$ s/,$//'
        echo "        }"
    fi
    echo "    }"
    echo "}"
    echo "add chain inet zapret postnat_bypass { type filter hook postrouting priority 98; policy accept; }"
    echo "flush chain inet zapret postnat_bypass"
    echo "add rule inet zapret postnat_bypass ip saddr @xfree_device_bypass_zapret4 meta mark set meta mark | 0x40000000 ct mark set ct mark | 0x80000000 return comment \"xfree: device bypass zapret\""
    echo "add rule inet zapret postnat_bypass ether saddr @xfree_device_bypass_zapret_mac meta mark set meta mark | 0x40000000 ct mark set ct mark | 0x80000000 return comment \"xfree: device bypass zapret\""
    echo ""
    echo "add chain inet zapret prenat_bypass { type filter hook prerouting priority -105; policy accept; }"
    echo "flush chain inet zapret prenat_bypass"
    echo "add rule inet zapret prenat_bypass ip saddr @xfree_device_bypass_zapret4 meta mark set meta mark | 0x40000000 ct mark set ct mark | 0x80000000 return comment \"xfree: device bypass zapret\""
    echo "add rule inet zapret prenat_bypass ether saddr @xfree_device_bypass_zapret_mac meta mark set meta mark | 0x40000000 ct mark set ct mark | 0x80000000 return comment \"xfree: device bypass zapret\""
    echo ""
    echo "add chain inet zapret postnat_force_zapret { type filter hook postrouting priority 102; policy accept; }"
    echo "flush chain inet zapret postnat_force_zapret"
    echo "add rule inet zapret postnat_force_zapret ip saddr @xfree_device_force_zapret4 tcp dport { 80, 443, 2053, 2083, 2087, 2096, 5222, 5223, 8443 } ct original packets 1-9 meta mark & 0x40000000 == 0x0 ct mark set ct mark | 0x40000000 queue flags bypass to 200 comment \"xfree: force device to zapret TCP\""
    echo "add rule inet zapret postnat_force_zapret ip saddr @xfree_device_force_zapret4 udp dport { 443, 500, 1701, 3478, 4443, 4500, 8095, 8443, 19294-19344, 50000-65534 } ct original packets 1-9 meta mark & 0x40000000 == 0x0 ct mark set ct mark | 0x40000000 queue flags bypass to 200 comment \"xfree: force device to zapret UDP\""
    echo "add rule inet zapret postnat_force_zapret ether saddr @xfree_device_force_zapret_mac tcp dport { 80, 443, 2053, 2083, 2087, 2096, 5222, 5223, 8443 } ct original packets 1-9 meta mark & 0x40000000 == 0x0 ct mark set ct mark | 0x40000000 queue flags bypass to 200 comment \"xfree: force device to zapret TCP by MAC\""
    echo "add rule inet zapret postnat_force_zapret ether saddr @xfree_device_force_zapret_mac udp dport { 443, 500, 1701, 3478, 4443, 4500, 8095, 8443, 19294-19344, 50000-65534 } ct original packets 1-9 meta mark & 0x40000000 == 0x0 ct mark set ct mark | 0x40000000 queue flags bypass to 200 comment \"xfree: force device to zapret UDP by MAC\""
} > "$ZAPRET_NFT_FILE"

apply_zapret_device_policy_nft() {
    _nft="$1"
    [ -f "$_nft" ] || return 0
    nft delete chain inet zapret postnat_bypass 2>/dev/null || true
    nft -f "$_nft" 2>/dev/null || true
    if nft list chain inet zapret prenat >/dev/null 2>&1; then
        for _h in $(nft -a list chain inet zapret prenat 2>/dev/null | sed -n 's/.*comment "xfree: device bypass zapret prenat" # handle \([0-9][0-9]*\).*/\1/p'); do
            nft delete rule inet zapret prenat handle "$_h" 2>/dev/null || true
        done
        nft insert rule inet zapret prenat ct mark \& 0x80000000 != 0x0 return comment "xfree: device bypass zapret prenat" 2>/dev/null || true
    fi
}

# Install hook into zapret custom.d if zapret is present
if [ -d "$ZAPRET_CUSTOM_D" ]; then
    HOOK_SH="$ZAPRET_CUSTOM_D/90-xfree-device-bypass.sh"
    cat << 'HOOK_EOF' > "$HOOK_SH"
#!/bin/sh
zapret_custom_firewall_nft() {
    _nft="/etc/xfree-toolbox/device-policy/generated/zapret-device-policy.nft"
    [ -f "$_nft" ] || _nft="/etc/xfree-toolbox/device-policy/generated/zapret-bypass.nft"
    [ -f "$_nft" ] || return 0
    nft delete chain inet zapret postnat_bypass 2>/dev/null || true
    nft -f "$_nft" 2>/dev/null || true
    if nft list chain inet zapret prenat >/dev/null 2>&1; then
        for _h in $(nft -a list chain inet zapret prenat 2>/dev/null | sed -n 's/.*comment "xfree: device bypass zapret prenat" # handle \([0-9][0-9]*\).*/\1/p'); do
            nft delete rule inet zapret prenat handle "$_h" 2>/dev/null || true
        done
        nft insert rule inet zapret prenat ct mark \& 0x80000000 != 0x0 return comment "xfree: device bypass zapret prenat" 2>/dev/null || true
    fi
}
HOOK_EOF
    chmod +x "$HOOK_SH" 2>/dev/null || true
fi

# Apply to active runtime with complete set flushing
if command -v nft >/dev/null 2>&1; then
    # Delete existing device-policy chains so priority/rule updates apply cleanly without duplicates
    nft delete chain inet fw4 mangle_prerouting_device_bypass 2>/dev/null || true
    nft delete chain inet fw4 mangle_prerouting_device_force 2>/dev/null || true
    # Flush all existing xfree_device_* sets in inet fw4
    for _s in $(nft list sets table inet fw4 2>/dev/null | grep -o 'xfree_device_[A-Za-z0-9_]*'); do
        nft flush set inet fw4 "$_s" 2>/dev/null || true
    done
    printf 'table inet fw4 {\ninclude "%s"\n}\n' "$NFT_INCLUDE_DIR/10-xfree-device-policy.nft" | nft -f - 2>/dev/null || true

    # Flush all existing xfree_device_* sets in inet zapret
    if nft list table inet zapret >/dev/null 2>&1; then
        for _zs in $(nft list sets table inet zapret 2>/dev/null | grep -o 'xfree_device_[A-Za-z0-9_]*'); do
            nft flush set inet zapret "$_zs" 2>/dev/null || true
        done
        apply_zapret_device_policy_nft "$ZAPRET_NFT_FILE"
    fi
fi

if [ "$APPLY_FW" = "1" ] && command -v fw4 >/dev/null 2>&1; then
    fw4 reload >/dev/null 2>&1 || true
fi

if [ "$QUIET" != "1" ]; then
    _count="$(device_policy_list "$CFG" | wc -l | tr -d ' ')"
    success "Device Policy: применены правила маршрутизации для устройств (всего: $_count)"
fi
