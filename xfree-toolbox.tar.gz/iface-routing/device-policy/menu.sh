#!/bin/sh
# shellcheck shell=sh
# UI: Device routing policy menu (Direct WAN bypass / VPN bypass / Zapret bypass).
# Usage:
#   menu.sh [ui]
# Spec: project/specs/device-routing-policy.md

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
DOMAIN_ROUTING_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$DOMAIN_ROUTING_DIR/.." && pwd -P)"

COMMON_SH="${ROOT_DIR}/lib/common.sh"
UI_SH="${ROOT_DIR}/lib/ui.sh"
LIB_SH="${SCRIPT_DIR}/lib.sh"
APPLY_SH="${SCRIPT_DIR}/apply.sh"

[ -f "$COMMON_SH" ] || { echo "[-] missing common.sh" >&2; exit 1; }
[ -f "$UI_SH" ] || { echo "[-] missing ui.sh" >&2; exit 1; }
[ -f "$LIB_SH" ] || { echo "[-] missing lib.sh" >&2; exit 1; }
[ -f "$APPLY_SH" ] || { echo "[-] missing apply.sh" >&2; exit 1; }

. "$COMMON_SH"
. "$UI_SH"
. "$LIB_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
CFG="$(device_policy_conf_path "$PROFILE_DIR")"

action_list() {
    _entries="$(device_policy_list "$CFG")"
    if [ -z "$_entries" ]; then
        ui_msgbox "Исключения устройств" "Список исключений пуст.\nВсе устройства обрабатываются роутером в обычном режиме."
        return 0
    fi

    _out="Настроенные устройства:\n\n"
    while IFS='|' read -r _id _name _ip _mac _sv _sz _comment || [ -n "$_id" ]; do
        [ -n "$_id" ] || continue
        _mode=""
        if [ "$_sv" = "1" ] && [ "$_sz" = "1" ]; then
            _mode="Чистый WAN (без VPN и Zapret)"
        elif [ "$_sv" = "1" ]; then
            _mode="Только без VPN"
        elif [ "$_sz" = "1" ]; then
            _mode="Только без Zapret"
        else
            _mode="Обычный режим"
        fi
        _target="${_ip:-$_mac}"
        [ -n "$_ip" ] && [ -n "$_mac" ] && _target="$_ip ($_mac)"
        _out="${_out}• ${_name:-$_id} [${_target}]\n  Режим: ${_mode}\n"
    done <<EOF
$_entries
EOF
    ui_msgbox "Исключения устройств" "$_out"
}

action_select_policy() {
    # Returns 1|1, 1|0, 0|1
    _pchoice="$(ui_menu "Режим обхода" \
        "wan" "Чистый WAN (напрямую, без VPN и без Zapret)" \
        "vpn" "Пропуск только VPN (трафик идёт в WAN, но Zapret работает)" \
        "zapret" "Пропуск только Zapret (без nfqws десинхронизации)")" || return 1

    case "$_pchoice" in
        wan) printf '1|1\n' ;;
        vpn) printf '1|0\n' ;;
        zapret) printf '0|1\n' ;;
        *) return 1 ;;
    esac
}

action_add_from_lan() {
    _clients="$(device_policy_scan_network_clients)"
    if [ -z "$_clients" ]; then
        ui_msgbox "Клиенты сети" "Активные клиенты не обнаружены в DHCP leases / ARP таблице."
        return 0
    fi

    _lines=""
    _idx=1
    while IFS='|' read -r _ip _mac _host || [ -n "$_ip" ]; do
        [ -n "$_ip" ] || continue
        _desc="$_ip"
        [ -n "$_host" ] && _desc="$_host ($_ip)"
        [ -n "$_mac" ] && _desc="$_desc [$_mac]"
        _lines="${_lines}${_idx}\t${_desc}\n"
        _idx=$((_idx + 1))
    done <<EOF
$_clients
EOF

    _pick="$(ui_select_from_lines "Выбор устройства" "Выберите устройство из сети для настройки исключения:" "$(printf '%b' "$_lines")" 20 78 10)" || return 0
    [ -n "$_pick" ] || return 0

    # Get chosen client line
    _selected="$(printf '%b' "$_clients" | sed -n "${_pick}p")"
    [ -n "$_selected" ] || return 0

    _sel_ip="$(printf '%s' "$_selected" | cut -d'|' -f1)"
    _sel_mac="$(printf '%s' "$_selected" | cut -d'|' -f2)"
    _sel_host="$(printf '%s' "$_selected" | cut -d'|' -f3)"

    _def_name="${_sel_host:-$sel_ip}"
    _name="$(ui_input "Имя устройства" "Введите понятное имя для этого устройства:" "$_def_name")" || return 0
    [ -n "$_name" ] || _name="$_def_name"

    _policy="$(action_select_policy)" || return 0
    _sv="$(printf '%s' "$_policy" | cut -d'|' -f1)"
    _sz="$(printf '%s' "$_policy" | cut -d'|' -f2)"

    _id="dev_$(printf '%s' "$_sel_ip" | tr '.' '_')"
    device_policy_upsert "$CFG" "$_id" "$_name" "$_sel_ip" "$_sel_mac" "$_sv" "$_sz" "Added from LAN scan"

    if ui_yesno "Применение правил" "Устройство '$_name' сохранено.\nПрименить правила маршрутизации прямо сейчас?"; then
        "$APPLY_SH" --profile-dir "$PROFILE_DIR"
        ui_msgbox "Готово" "Правила обхода для устройства '$_name' успешно применены!"
    fi
}

action_add_manual() {
    _name="$(ui_input "Добавление устройства" "Введите имя устройства (например, My-PC или Proxmox-VM):" "")" || return 0
    [ -n "$_name" ] || return 0

    _ip="$(ui_input "IP адрес / подсеть" "Введите IP-адрес или подсеть устройства (или оставьте пустым, если привязка по MAC):" "")" || return 0
    _mac="$(ui_input "MAC адрес" "Введите MAC-адрес устройства (или оставьте пустым, если привязка только по IP):" "")" || return 0

    if [ -z "$_ip" ] && [ -z "$_mac" ]; then
        ui_msgbox "Ошибка" "Необходимо указать хотя бы IP-адрес или MAC-адрес."
        return 0
    fi

    _policy="$(action_select_policy)" || return 0
    _sv="$(printf '%s' "$_policy" | cut -d'|' -f1)"
    _sz="$(printf '%s' "$_policy" | cut -d'|' -f2)"

    _id="dev_$(date +%s)"
    [ -n "$_ip" ] && _id="dev_$(printf '%s' "$_ip" | tr './' '__')"

    device_policy_upsert "$CFG" "$_id" "$_name" "$_ip" "$_mac" "$_sv" "$_sz" "Manual entry"

    if ui_yesno "Применение правил" "Устройство '$_name' сохранено.\nПрименить правила маршрутизации прямо сейчас?"; then
        "$APPLY_SH" --profile-dir "$PROFILE_DIR"
        ui_msgbox "Готово" "Правила обхода для устройства '$_name' успешно применены!"
    fi
}

action_delete() {
    _entries="$(device_policy_list "$CFG")"
    if [ -z "$_entries" ]; then
        ui_msgbox "Удаление" "Список устройств пуст."
        return 0
    fi

    _lines=""
    _idx=1
    while IFS='|' read -r _id _name _ip _mac _rest || [ -n "$_id" ]; do
        [ -n "$_id" ] || continue
        _target="${_ip:-$_mac}"
        _lines="${_lines}${_idx}\t${_name:-$_id} [${_target}]\n"
        _idx=$((_idx + 1))
    done <<EOF
$_entries
EOF

    _pick="$(ui_select_from_lines "Удаление исключения" "Выберите устройство для удаления:" "$(printf '%b' "$_lines")" 18 76 8)" || return 0
    [ -n "$_pick" ] || return 0

    _selected="$(printf '%b' "$_entries" | sed -n "${_pick}p")"
    _del_id="$(printf '%s' "$_selected" | cut -d'|' -f1)"
    _del_name="$(printf '%s' "$_selected" | cut -d'|' -f2)"

    if ui_yesno "Подтверждение" "Удалить исключение для '${_del_name:-$_del_id}'?"; then
        device_policy_delete "$CFG" "$_del_id"
        "$APPLY_SH" --profile-dir "$PROFILE_DIR"
        ui_msgbox "Готово" "Исключение удалено, правила маршрутизации обновлены."
    fi
}

action_apply() {
    "$APPLY_SH" --profile-dir "$PROFILE_DIR"
    ui_msgbox "Готово" "Правила исключений для устройств успешно обновлены и применены в системе."
}

device_policy_menu() {
    while true; do
        _choice="$(ui_menu "Устройства: прямой WAN / исключения" \
            "list" "Показать настроенные устройства" \
            "add_lan" "Выбрать устройство из сети (DHCP / ARP)" \
            "add_manual" "Добавить устройство вручную (IP или MAC)" \
            "delete" "Удалить устройство из исключений" \
            "apply" "Применить правила прямо сейчас" \
            "back" "Назад в меню маршрутов")" || break

        case "$_choice" in
            list) action_list ;;
            add_lan) action_add_from_lan ;;
            add_manual) action_add_manual ;;
            delete) action_delete ;;
            apply) action_apply ;;
            back|*) break ;;
        esac
    done
}

device_policy_menu
