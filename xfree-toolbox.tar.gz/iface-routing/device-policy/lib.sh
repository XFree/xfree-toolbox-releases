#!/bin/sh
# shellcheck shell=sh
# Device routing policy library (Direct WAN / VPN bypass / Zapret bypass for clients).
# Spec: project/specs/device-routing-policy.md

device_policy_conf_path() {
    _pdir="${1:-}"
    [ -n "$_pdir" ] || return 1
    printf '%s/routing/devices.conf\n' "$_pdir"
}

device_policy_init_conf() {
    _cfg="$1"
    [ -n "$_cfg" ] || return 1
    _dir="$(dirname "$_cfg")"
    mkdir -p "$_dir" 2>/dev/null || true
    if [ ! -f "$_cfg" ]; then
        cat << 'EOF' > "$_cfg"
# id|name|ip_or_cidr|mac|skip_vpn|skip_zapret|comment
EOF
    fi
}

device_policy_normalize_mac() {
    _raw="${1:-}"
    [ -n "$_raw" ] || return 0
    _clean="$(printf '%s\n' "$_raw" | tr '[:upper:]' '[:lower:]' | tr -cd '0-9a-f')"
    [ "$(printf '%s' "$_clean" | wc -c)" -eq 12 ] || return 0
    printf '%s\n' "$_clean" | sed -E 's/(..)(..)(..)(..)(..)(..)/\1:\2:\3:\4:\5:\6/'
}

device_policy_normalize_ip() {
    _raw="${1:-}"
    [ -n "$_raw" ] || return 0
    printf '%s\n' "$_raw" | tr -d ' \t\r\n' | grep -E '^([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?$' || true
}

# Scan DHCP leases + ARP table + IP neighbor cache.
# Output format: IP|MAC|HOSTNAME
device_policy_scan_network_clients() {
    _tmp_leases="${TMPDIR:-/tmp}/xfree-clients.$$"
    rm -f "$_tmp_leases"
    touch "$_tmp_leases"

    # 1. DHCP leases (/tmp/dhcp.leases format: timestamp mac ip hostname client-id)
    if [ -f /tmp/dhcp.leases ]; then
        while read -r _ts _mac _ip _host _rest || [ -n "$_ip" ]; do
            [ -n "$_ip" ] || continue
            [ "$_ip" = "*" ] && continue
            _n_mac="$(device_policy_normalize_mac "$_mac")"
            [ "$_host" = "*" ] && _host=""
            printf '%s|%s|%s\n' "$_ip" "$_n_mac" "$_host" >> "$_tmp_leases"
        done < /tmp/dhcp.leases
    fi

    # 2. ARP table (/proc/net/arp: IP type flags MAC mask dev)
    if [ -f /proc/net/arp ]; then
        awk 'NR>1 && $4 != "00:00:00:00:00:00" {print $1 "|" tolower($4) "|"}' /proc/net/arp >> "$_tmp_leases" 2>/dev/null || true
    fi

    # 3. IP neighbor
    if command -v ip >/dev/null 2>&1; then
        ip neigh show 2>/dev/null | awk '$5 ~ /^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$/ {print $1 "|" tolower($5) "|"}' >> "$_tmp_leases" 2>/dev/null || true
    fi

    # Deduplicate by IP, preferring entries with hostname
    if [ -s "$_tmp_leases" ]; then
        awk -F'|' '
            {
                ip = $1; mac = $2; host = $3
                if (ip == "") next
                if (!(ip in seen) || (host != "" && hosts[ip] == "")) {
                    seen[ip] = 1
                    macs[ip] = (mac != "" ? mac : macs[ip])
                    hosts[ip] = host
                }
            }
            END {
                for (ip in seen) {
                    print ip "|" macs[ip] "|" hosts[ip]
                }
            }
        ' "$_tmp_leases" | sort -t'.' -k1,1n -k2,2n -k3,3n -k4,4n
    fi
    rm -f "$_tmp_leases"
}

# Read devices list: id|name|ip_or_cidr|mac|skip_vpn|skip_zapret|comment
device_policy_list() {
    _cfg="$1"
    [ -f "$_cfg" ] || return 0
    grep -vE '^[[:space:]]*#' "$_cfg" | grep -vE '^[[:space:]]*$' || true
}

# Get one device by ID
device_policy_get() {
    _cfg="$1"
    _id="$2"
    [ -f "$_cfg" ] || return 1
    device_policy_list "$_cfg" | awk -F'|' -v id="$_id" '$1 == id {print; exit}'
}

# Add or update device entry
device_policy_upsert() {
    _cfg="$1"
    _id="$2"
    _name="$3"
    _ip="$4"
    _mac="$5"
    _skip_vpn="${6:-1}"
    _skip_zapret="${7:-1}"
    _comment="${8:-}"

    device_policy_init_conf "$_cfg"
    _tmp="${_cfg}.tmp.$$"
    _n_mac="$(device_policy_normalize_mac "$_mac")"
    _n_ip="$(device_policy_normalize_ip "$_ip")"

    awk -F'|' -v id="$_id" -v name="$_name" -v ip="$_n_ip" -v mac="$_n_mac" \
        -v sv="$_skip_vpn" -v sz="$_skip_zapret" -v c="$_comment" '
        BEGIN { found = 0 }
        $1 == id {
            print id "|" name "|" ip "|" mac "|" sv "|" sz "|" c
            found = 1
            next
        }
        { print }
        END {
            if (!found) {
                print id "|" name "|" ip "|" mac "|" sv "|" sz "|" c
            }
        }
    ' "$_cfg" > "$_tmp"
    mv -f "$_tmp" "$_cfg"
}

# Delete device entry
device_policy_delete() {
    _cfg="$1"
    _id="$2"
    [ -f "$_cfg" ] || return 0
    _tmp="${_cfg}.tmp.$$"
    awk -F'|' -v id="$_id" '$1 != id { print }' "$_cfg" > "$_tmp"
    mv -f "$_tmp" "$_cfg"
}
