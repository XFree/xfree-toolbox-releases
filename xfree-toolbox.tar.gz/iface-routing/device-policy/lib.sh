#!/bin/sh
# shellcheck shell=sh
# Device routing policy library (Direct WAN / VPN bypass / Zapret bypass for clients).
# Spec: project/specs/device-routing-policy.md

device_policy_conf_path() {
    _pdir="${1:-}"
    [ -n "$_pdir" ] || return 1
    printf '%s/routing/devices.conf\n' "$_pdir"
}

device_policy_init_conf() {
    _cfg="$1"
    [ -n "$_cfg" ] || return 1
    _dir="$(dirname "$_cfg")"
    mkdir -p "$_dir" 2>/dev/null || true
    if [ ! -f "$_cfg" ]; then
        cat << 'EOF' > "$_cfg"
# id|name|ip_or_cidr|mac|skip_vpn|skip_zapret|comment|force_iface|force_zapret
EOF
    fi
}

device_policy_normalize_mac() {
    _raw="${1:-}"
    [ -n "$_raw" ] || return 0
    _clean="$(printf '%s\n' "$_raw" | tr '[:upper:]' '[:lower:]' | tr -cd '0-9a-f')"
    [ "$(printf '%s' "$_clean" | wc -c)" -eq 12 ] || return 0
    printf '%s\n' "$_clean" | sed -E 's/(..)(..)(..)(..)(..)(..)/\1:\2:\3:\4:\5:\6/'
}

device_policy_normalize_ip() {
    _raw="${1:-}"
    [ -n "$_raw" ] || return 0
    printf '%s\n' "$_raw" | tr -d ' \t\r\n' | grep -E '^([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?$' || true
}

# Scan network clients (DHCP leases, static hosts, ARP table, neighbor cache).
# Arguments:
#   $1: mode  - "passive" (default, read local caches only) or "active" (send probes)
#   $2: scope - "lan" (default, LAN interfaces only) or "all" (include WAN/parent network)
# Output format: IP|MAC|HOSTNAME
device_policy_scan_network_clients() {
    _mode="${1:-passive}"
    _scope="${2:-lan}"

    _tmp_leases="${TMPDIR:-/tmp}/xfree-clients.$$"
    rm -f "$_tmp_leases"
    touch "$_tmp_leases"

    _local_ips=""
    _local_macs=""
    if command -v ip >/dev/null 2>&1; then
        _local_ips="$(ip -o addr show 2>/dev/null | awk '{print $4}' | cut -d'/' -f1 | tr '\n' ' ')"
        _local_macs="$(ip -o link show 2>/dev/null | awk '{for (i=1; i<=NF; i++) if ($i == "link/ether") print tolower($(i+1))}' | tr '\n' ' ')"
    fi
    _gw="$(ip route show default 2>/dev/null | awk '{for (i=1; i<=NF; i++) if ($i == "via") print $(i+1)}' | head -n1)"

    # Identify LAN devices / interfaces (br-lan, lan, wlan, etc.)
    _lan_devs=""
    if command -v uci >/dev/null 2>&1; then
        _lan_devs="$(uci -q get network.lan.device || uci -q get network.lan.ifname || true)"
    fi
    [ -n "$_lan_devs" ] || _lan_devs="br-lan"

    # 1. Active discovery (ONLY if mode is "active" or "scan")
    if [ "$_mode" = "active" ] || [ "$_mode" = "scan" ]; then
        if command -v ip >/dev/null 2>&1; then
            if [ "$_scope" = "all" ]; then
                _target_dev_regex="^(br-lan|lan|eth|wlan)"
            else
                _target_dev_regex="^(${_lan_devs}|br-lan|lan|wlan)"
            fi

            for _brd in $(ip -o -4 addr show 2>/dev/null | awk -v reg="$_target_dev_regex" '$4 !~ /^127\./ && $2 ~ reg && $6 != "" && $6 != "255.255.255.255" {print $6}'); do
                ping -c 1 -W 1 "$_brd" >/dev/null 2>&1 &
            done

            for _sub in $(ip -o -4 addr show 2>/dev/null | awk -v reg="$_target_dev_regex" '$4 !~ /^127\./ && $2 ~ reg {split($4, a, "."); print a[1]"."a[2]"."a[3]"."}'); do
                for _i in $(seq 1 30) $(seq 225 240); do
                    ping -c 1 -W 1 "${_sub}${_i}" >/dev/null 2>&1 &
                done
            done
            wait 2>/dev/null || true
        fi
    fi

    # 2. DHCP dynamic leases (/tmp/dhcp.leases: timestamp mac ip hostname client-id)
    if [ -f /tmp/dhcp.leases ]; then
        while read -r _ts _mac _ip _host _rest || [ -n "$_ip" ]; do
            [ -n "$_ip" ] || continue
            [ "$_ip" = "*" ] && continue
            _n_mac="$(device_policy_normalize_mac "$_mac")"
            [ "$_host" = "*" ] && _host=""
            printf '%s|%s|%s\n' "$_ip" "$_n_mac" "$_host" >> "$_tmp_leases"
        done < /tmp/dhcp.leases
    fi

    # 3. UCI static leases (/etc/config/dhcp)
    if command -v uci >/dev/null 2>&1; then
        uci -q show dhcp | awk -F'=' '
            /dhcp\.@host\[[0-9]+\]\.name=/ { split($1, a, "."); names[a[2]] = $2 }
            /dhcp\.@host\[[0-9]+\]\.ip=/ { split($1, a, "."); ips[a[2]] = $2 }
            /dhcp\.@host\[[0-9]+\]\.mac=/ { split($1, a, "."); macs[a[2]] = $2 }
            END {
                for (h in names) {
                    gsub(/[\047\042]/, "", names[h])
                    gsub(/[\047\042]/, "", ips[h])
                    gsub(/[\047\042]/, "", macs[h])
                    if (ips[h] != "" || macs[h] != "") {
                        print ips[h] "|" tolower(macs[h]) "|" names[h]
                    }
                }
            }
        ' >> "$_tmp_leases" 2>/dev/null || true
    fi

    # 4. /etc/hosts and /tmp/hosts/*
    for _hf in /etc/hosts /tmp/hosts/*; do
        [ -f "$_hf" ] || continue
        awk '
            $1 ~ /^([0-9]{1,3}\.){3}[0-9]{1,3}$/ && $1 !~ /^(127\.|0\.)/ {
                if ($2 != "" && $2 != "localhost" && $2 != "openwrt") {
                    print $1 "||" $2
                }
            }
        ' "$_hf" >> "$_tmp_leases" 2>/dev/null || true
    done

    # 5. ARP table (/proc/net/arp: IP type flags MAC mask dev)
    if [ -f /proc/net/arp ]; then
        if [ "$_scope" = "all" ]; then
            awk 'NR>1 && $4 != "00:00:00:00:00:00" {print $1 "|" tolower($4) "|"}' /proc/net/arp >> "$_tmp_leases" 2>/dev/null || true
        else
            awk -v lan="$_lan_devs" 'NR>1 && $4 != "00:00:00:00:00:00" && ($6 ~ lan || $6 ~ /^(br-lan|lan|wlan)/) {print $1 "|" tolower($4) "|"}' /proc/net/arp >> "$_tmp_leases" 2>/dev/null || true
        fi
    fi

    # 6. IP neighbor cache (excluding INCOMPLETE, FAILED, and fe80:*)
    if command -v ip >/dev/null 2>&1; then
        if [ "$_scope" = "all" ]; then
            ip neigh show 2>/dev/null | grep -v INCOMPLETE | grep -v FAILED | awk '
                $1 ~ /^fe80:/ { next }
                $5 ~ /^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$/ {
                    print $1 "|" tolower($5) "|"
                }
            ' >> "$_tmp_leases" 2>/dev/null || true
        else
            ip neigh show 2>/dev/null | grep -v INCOMPLETE | grep -v FAILED | awk -v lan="$_lan_devs" '
                $1 ~ /^fe80:/ { next }
                ($3 ~ lan || $3 ~ /^(br-lan|lan|wlan)/) && $5 ~ /^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$/ {
                    print $1 "|" tolower($5) "|"
                }
            ' >> "$_tmp_leases" 2>/dev/null || true
        fi
    fi

    # 7. Deduplicate, filter router self & link-local, and resolve missing hostnames
    if [ -s "$_tmp_leases" ]; then
        awk -F'|' -v my_ips="$_local_ips" -v my_macs="$_local_macs" '
            BEGIN {
                split(my_ips, mip, " ")
                for (i in mip) if (mip[i] != "") is_self_ip[mip[i]] = 1
                split(my_macs, mmac, " ")
                for (i in mmac) if (mmac[i] != "") is_self_mac[mmac[i]] = 1
                total = 0
            }
            {
                ip = $1; mac = tolower($2); host = $3
                if (ip ~ /^fe80:/ || ip ~ /^127\./) next
                if (is_self_ip[ip] || is_self_mac[mac]) next
                if (ip == "" && mac == "") next

                k = (mac != "" ? mac : ip)
                if (!(k in seen)) {
                    seen[k] = 1
                    keys[total] = k
                    total++
                }
                if (ip != "" && (ips[k] == "" || ips[k] ~ /^fe80:/)) ips[k] = ip
                if (mac != "" && macs[k] == "") macs[k] = mac
                if (host != "" && hosts[k] == "") hosts[k] = host
            }
            END {
                for (i = 0; i < total; i++) {
                    k = keys[i]
                    print ips[k] "|" macs[k] "|" hosts[k]
                }
            }
        ' "$_tmp_leases" | while IFS='|' read -r _ip _mac _h; do
            if [ -z "$_h" ] && [ -n "$_ip" ] && [ -n "$_gw" ] && [ "$_mode" = "active" ]; then
                _rev="$(nslookup "$_ip" "$_gw" 2>/dev/null | awk '/name =/ {gsub(/\.$/, "", $NF); print $NF}' | head -n1)"
                [ -n "$_rev" ] && _h="$_rev"
            fi
            printf '%s|%s|%s\n' "$_ip" "$_mac" "$_h"
        done | sort -t'.' -k1,1n -k2,2n -k3,3n -k4,4n
    fi
    rm -f "$_tmp_leases"
}

# Read devices list: id|name|ip_or_cidr|mac|skip_vpn|skip_zapret|comment|force_iface|force_zapret
device_policy_list() {
    _cfg="$1"
    [ -f "$_cfg" ] || return 0
    grep -vE '^[[:space:]]*#' "$_cfg" | grep -vE '^[[:space:]]*$' | awk -F'|' '
        $1 != "" && ($3 != "" || $4 != "") { print }
    ' || true
}

# Get one device by ID
device_policy_get() {
    _cfg="$1"
    _id="$2"
    [ -f "$_cfg" ] || return 1
    device_policy_list "$_cfg" | awk -F'|' -v id="$_id" '$1 == id {print; exit}'
}

# Add or update device entry
device_policy_upsert() {
    _cfg="$1"
    _id="$2"
    _name="$3"
    _ip="$4"
    _mac="$5"
    _skip_vpn="${6:-1}"
    _skip_zapret="${7:-1}"
    _comment="${8:-}"
    _force_iface="${9:-}"
    _force_zapret="${10:-0}"

    device_policy_init_conf "$_cfg"
    _tmp="${_cfg}.tmp.$$"
    _n_mac="$(device_policy_normalize_mac "$_mac")"
    _n_ip="$(device_policy_normalize_ip "$_ip")"

    awk -F'|' -v id="$_id" -v name="$_name" -v ip="$_n_ip" -v mac="$_n_mac" \
        -v sv="$_skip_vpn" -v sz="$_skip_zapret" -v c="$_comment" \
        -v fi="$_force_iface" -v fz="$_force_zapret" '
        BEGIN { found = 0 }
        $1 == id {
            print id "|" name "|" ip "|" mac "|" sv "|" sz "|" c "|" fi "|" fz
            found = 1
            next
        }
        { print }
        END {
            if (!found) {
                print id "|" name "|" ip "|" mac "|" sv "|" sz "|" c "|" fi "|" fz
            }
        }
    ' "$_cfg" > "$_tmp"
    mv -f "$_tmp" "$_cfg"
}

# Delete device entry
device_policy_delete() {
    _cfg="$1"
    _id="$2"
    [ -f "$_cfg" ] || return 0
    _tmp="${_cfg}.tmp.$$"
    awk -F'|' -v id="$_id" '$1 != id { print }' "$_cfg" > "$_tmp"
    mv -f "$_tmp" "$_cfg"
}
