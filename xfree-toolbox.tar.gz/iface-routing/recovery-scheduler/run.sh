#!/bin/sh
# shellcheck shell=sh
# CLI for iface recovery scheduler (task queue + microtask digest).
#
# Usage:
#   run.sh schedule [reason] [debounce_sec]
#   run.sh tick [--force]
#   run.sh digest [--force]
#   run.sh digest-bg [--force]
#   run.sh status
#   run.sh cancel

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"
COMMON_SH="$ROOT_DIR/lib/common.sh"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"

RECOVERY_SCHEDULER_ROOT_DIR="$ROOT_DIR"
RECOVERY_SCHEDULER_COMMON_SH="$COMMON_SH"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
RECOVERY_SCHEDULER_INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"

# shellcheck disable=SC1091
. "$ROOT_DIR/iface-routing/lib/recovery-scheduler.sh"

usage() {
    cat <<USAGE
Usage:
  $(basename "$0") schedule [reason] [debounce_sec]
  $(basename "$0") tick [--force]
  $(basename "$0") digest [--force]
  $(basename "$0") digest-bg [--force]
  $(basename "$0") finalize [--force]
  $(basename "$0") status
  $(basename "$0") cancel

Macrotask queue + microtask digest (browser-like turn).
digest-bg — drain через lib/bg-task-run.sh (task iface-recovery-digest).
ENABLED=0 в $RECOVERY_SCHEDULER_CONF_FILE по умолчанию:
  tick/digest без --force ничего не делают.
USAGE
}

MODE="${1:-}"
shift || true

case "$MODE" in
    schedule)
        reason="${1:-manual}"
        debounce="${2:-}"
        schedule_recovery "$reason" "$debounce"
        recovery_scheduler_status_text
        ;;
    tick|digest|finalize)
        force=0
        [ "${1:-}" = "--force" ] && force=1
        recovery_scheduler_tick "$force"
        recovery_scheduler_status_text
        ;;
    digest-bg)
        force=0
        [ "${1:-}" = "--force" ] && force=1
        recovery_scheduler_tick_background "$force"
        recovery_scheduler_status_text
        ;;
    status)
        recovery_scheduler_status_text
        ;;
    cancel)
        recovery_scheduler_cancel
        recovery_scheduler_status_text
        ;;
    -h|--help|'')
        usage
        ;;
    *)
        die "Неизвестная команда: $MODE"
        ;;
esac
