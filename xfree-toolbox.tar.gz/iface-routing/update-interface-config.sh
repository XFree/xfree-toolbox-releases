#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
[ -f "$SCRIPT_DIR/config.sh" ] && . "$SCRIPT_DIR/config.sh"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
CONVERTER_SCRIPT="${CONVERTER_SCRIPT:-$SCRIPT_DIR/conf-to-interface-uci.sh}"

IFACE_NAME=""
SOURCE_FILE=""

usage() {
    cat <<EOF
Usage: $(basename "$0") --iface <name> --source <file|basename>

Updates the working iface-routing configuration for an interface from a source
.conf and validates that all expected config files were rebuilt in-place.
EOF
}

source_has_private_key() {
    file="$1"
    [ -f "$file" ] || return 1
    grep -q '^PrivateKey=' "$file" 2>/dev/null
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --iface)
            shift
            [ "$#" -gt 0 ] || die "--iface требует имя"
            IFACE_NAME="$1"
            ;;
        --source)
            shift
            [ "$#" -gt 0 ] || die "--source требует значение"
            SOURCE_FILE="$1"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift || true
done

[ -n "$IFACE_NAME" ] || die "Требуется --iface"
[ -n "$SOURCE_FILE" ] || die "Требуется --source"

IFACE_NAME="$(printf '%s\n' "$IFACE_NAME" | tr -cd 'A-Za-z0-9._-')"
[ -n "$IFACE_NAME" ] || die "Имя интерфейса после очистки пустое"
[ -f "$CONVERTER_SCRIPT" ] || die "Не найден converter: $CONVERTER_SCRIPT"

config_dir="$INTERFACES_DIR/$IFACE_NAME/config"
iface_conf="$config_dir/iface.conf"
source_conf="$config_dir/source.conf"
source_meta="$config_dir/source.conf.meta"
network_uci="$config_dir/network.uci"
firewall_uci="$config_dir/firewall.uci"

info "Обновляю рабочую конфигурацию интерфейса $IFACE_NAME"
"$CONVERTER_SCRIPT" --iface "$IFACE_NAME" --source "$SOURCE_FILE" >/dev/null

[ -f "$iface_conf" ] || die "После обновления не создан iface.conf: $iface_conf"
[ -f "$source_conf" ] || die "После обновления не создан source.conf: $source_conf"
[ -f "$source_meta" ] || die "После обновления не создан source.conf.meta: $source_meta"
[ -f "$network_uci" ] || die "После обновления не создан network.uci: $network_uci"
[ -f "$firewall_uci" ] || die "После обновления не создан firewall.uci: $firewall_uci"
source_has_private_key "$source_conf" || die "После обновления source.conf не содержит PrivateKey: $source_conf"

success "Рабочая конфигурация интерфейса обновлена: $IFACE_NAME"
