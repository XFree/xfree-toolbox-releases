#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
COMMON_SH="${ROOT_DIR}/lib/common.sh"
CONFIG_FILE="${DOMAIN_ROUTING_CONFIG:-${SCRIPT_DIR}/config.sh}"

[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
. "$COMMON_SH"
[ -f "$CONFIG_FILE" ] && . "$CONFIG_FILE" || true

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"

trim() {
    printf '%s' "$1" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//'
}

iface_conf_of() {
    printf '%s/%s/config/iface.conf\n' "$INTERFACES_DIR" "$1"
}

usage() {
    cat <<EOF
Usage:
  $(basename "$0") --iface <name>
EOF
}

IFACE=""

while [ "$#" -gt 0 ]; do
    case "$1" in
        --iface)
            shift
            [ "$#" -gt 0 ] || die "Не указан iface после --iface"
            IFACE="$1"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift || true
done

[ -n "$IFACE" ] || die "Нужно указать --iface <name>"

CONF="$(iface_conf_of "$IFACE")"
[ -f "$CONF" ] || die "Не найден iface.conf: $CONF"

INTERFACE_NAME=''
NFT_FQDN_SET_NAME=''
NFT_PREFIX_SET_NAME=''
NFT_FQDN4_SET_NAME=''
NFT_FQDN6_SET_NAME=''
NFT_PREFIX4_SET_NAME=''
NFT_PREFIX6_SET_NAME=''
NFT_CHAIN_NAME=''
NFT_OUTPUT_CHAIN_NAME=''

# shellcheck disable=SC1090
. "$CONF"

INTERFACE_NAME="$(trim "${INTERFACE_NAME:-$IFACE}")"

is_legacy=0
if [ -n "${NFT_FQDN_SET_NAME:-}" ] || [ -n "${NFT_PREFIX_SET_NAME:-}" ]; then
    if [ -z "${NFT_FQDN4_SET_NAME:-}" ] || [ -z "${NFT_FQDN6_SET_NAME:-}" ] || [ -z "${NFT_PREFIX4_SET_NAME:-}" ] || [ -z "${NFT_PREFIX6_SET_NAME:-}" ]; then
        is_legacy=1
    fi
fi

if [ "$is_legacy" -eq 0 ]; then
    info "Интерфейс '$IFACE' уже использует новую схему nft-имен"
    exit 0
fi

TMP="$(mktemp)"
trap 'rm -f "$TMP" 2>/dev/null || true' EXIT INT TERM

awk '
    !/^NFT_FQDN_SET_NAME=/ &&
    !/^NFT_PREFIX_SET_NAME=/ &&
    !/^NFT_FQDN4_SET_NAME=/ &&
    !/^NFT_FQDN6_SET_NAME=/ &&
    !/^NFT_PREFIX4_SET_NAME=/ &&
    !/^NFT_PREFIX6_SET_NAME=/ &&
    !/^NFT_CHAIN_NAME=/ &&
    !/^NFT_OUTPUT_CHAIN_NAME=/
' "$CONF" > "$TMP"

cat >> "$TMP" <<EOF

# dual-stack nft naming
NFT_FQDN4_SET_NAME='${INTERFACE_NAME}_fqdn4'
NFT_FQDN6_SET_NAME='${INTERFACE_NAME}_fqdn6'
NFT_PREFIX4_SET_NAME='${INTERFACE_NAME}_prefixes4'
NFT_PREFIX6_SET_NAME='${INTERFACE_NAME}_prefixes6'
NFT_CHAIN_NAME='mangle_prerouting_${INTERFACE_NAME}'
NFT_OUTPUT_CHAIN_NAME='mangle_output_${INTERFACE_NAME}'
EOF

# Backup policy exception: single legacy migration .bak next to iface.conf; overwritten on repeated migration.
cp -f "$CONF" "${CONF}.bak"
mv "$TMP" "$CONF"

success "Миграция завершена: $IFACE"
info "Резервная копия: ${CONF}.bak"
