#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"
[ -f "$ROOT_DIR/lib/upstreams.sh" ] && . "$ROOT_DIR/lib/upstreams.sh"
[ -f "$SCRIPT_DIR/config.sh" ] && . "$SCRIPT_DIR/config.sh"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
ACTIVE_BASE_DIR="${SYSTEM_INTERFACES_DIR:-${SYSTEM_DOMAIN_ROUTING_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}}/state/interfaces}"

TMP_DIR="${TMPDIR:-/tmp}/check-upstream-updates.$$"
ENTITIES_TSV="$TMP_DIR/entities.tsv"
FILES_TSV="$TMP_DIR/files.tsv"

HAS_CHANGES=0
HAS_WARNINGS=0

cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT INT TERM

mkdir -p "$TMP_DIR"
upstreams_build_model_tsv "$ROOT_DIR" "$ENTITIES_TSV" "$FILES_TSV"

normalize_file() {
    src="$1"
    dst="$2"
    if [ -f "$src" ]; then
        tr -d '\r' < "$src" | sed '/^[[:space:]]*$/d' > "$dst"
    else
        : > "$dst"
    fi
}

check_active_dir() {
    iface="$1"
    kind="$2"
    active_dir="$3"

    [ -d "$active_dir" ] || return 0

    find "$active_dir" -maxdepth 1 -type f -name '*.lst' | sort | while IFS= read -r active_path; do
        [ -f "$active_path" ] || continue
        dest_name="$(basename "$active_path")"

        line="$(awk -F '|' -v dest="$dest_name" -v kind="$kind" '$2 == kind && $4 == dest { print; exit }' "$FILES_TSV")"
        if [ -z "$line" ]; then
            printf '[!] [%s] Для активного файла не найден upstream-источник: %s\n' "$iface" "$active_path"
            HAS_WARNINGS=1
            continue
        fi

        src_path="$(printf '%s\n' "$line" | awk -F '|' '{print $3}')"
        if [ ! -f "$src_path" ]; then
            printf '[!] [%s] Для активного файла upstream-файл отсутствует: %s -> %s\n' "$iface" "$active_path" "$src_path"
            HAS_WARNINGS=1
            continue
        fi

        src_norm="$TMP_DIR/src.norm.$$"
        active_norm="$TMP_DIR/active.norm.$$"
        normalize_file "$src_path" "$src_norm"
        normalize_file "$active_path" "$active_norm"

        if ! cmp -s "$src_norm" "$active_norm"; then
            printf '[*] [%s] Обновление найдено: %s\n' "$iface" "$dest_name"
            HAS_CHANGES=1
        fi
    done
}

find "$INTERFACES_DIR" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null | sort | while IFS= read -r iface; do
    [ -n "${iface:-}" ] || continue
    [ -f "$INTERFACES_DIR/$iface/config/iface.conf" ] || continue
    check_active_dir "$iface" "fqdn" "$ACTIVE_BASE_DIR/$iface/fqdn.d"
    check_active_dir "$iface" "prefix" "$ACTIVE_BASE_DIR/$iface/prefixes.d"
done

if [ "$HAS_CHANGES" -eq 1 ]; then
    printf '\n[!] В активных списках обнаружены обновления. Требуется применить изменения.\n'
    exit 10
fi

if [ "$HAS_WARNINGS" -eq 1 ]; then
    printf '\n[!] Есть активные файлы без текущего upstream-источника. Проверьте состав активных списков.\n'
    exit 11
fi

printf '[*] Активные списки уже соответствуют текущим upstream.\n'
exit 0
