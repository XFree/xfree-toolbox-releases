#!/bin/sh
# Hand-written handlers for cli.run component=custom in iface-routing/menu.yaml.
# shellcheck shell=sh

run_script() { ui_menu_invoke_script_relaxed "$@"; }

self_route_menu() {
	run_script "$SCRIPT_DIR/self-route/menu.sh" ui
}

pbr_bypass_menu() {
	run_script "$SCRIPT_DIR/pbr-bypass/menu.sh" ui
}

device_policy_menu() {
	run_script "$SCRIPT_DIR/device-policy/menu.sh" ui
}

iface_menu_choice_1() { iface_dispatch_core_choice 1; }
iface_menu_choice_2() { iface_dispatch_core_choice 2; }
iface_menu_choice_3() { iface_dispatch_core_choice 3; }
iface_menu_choice_4() { iface_dispatch_core_choice 4; }
iface_menu_choice_5() { iface_dispatch_core_choice 5; }
iface_menu_choice_6() { iface_dispatch_core_choice 6; }
iface_menu_choice_7() { iface_dispatch_core_choice 7; }
iface_menu_choice_8() { iface_dispatch_core_choice 8; }
iface_menu_choice_9() { iface_dispatch_core_choice 9; }
iface_menu_choice_10() { iface_dispatch_core_choice 10; }
iface_menu_choice_13() { iface_dispatch_core_choice 13; }
iface_menu_choice_16() { iface_dispatch_core_choice 16; }
iface_menu_choice_14() { iface_dispatch_core_choice 14; }
