#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
[ -f "$SCRIPT_DIR/config.sh" ] && . "$SCRIPT_DIR/config.sh"

CONF_DIR="${CONF_DIR:-$SCRIPT_DIR/conf}"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
LOCAL_DNS="${LOCAL_DNS:-127.0.0.1}"

# Зарезервированный диапазон routing-slot.
RESERVED_SLOT_MIN="${RESERVED_SLOT_MIN:-1}"
RESERVED_SLOT_MAX="${RESERVED_SLOT_MAX:-255}"

# routing namespace
ROUTE_TABLE_PREFIX="${ROUTE_TABLE_PREFIX:-xfree-routing-rt-}"

SOURCE_FILE=""
IFACE_NAME=""

usage() {
  cat <<EOF2
Usage:
  $(basename "$0") --iface IFACE|auto --source FILE|BASENAME

Examples:
  $(basename "$0") --iface auto --source WARPm1_10.conf
  $(basename "$0") --iface warp3 --source /root/domain-routing/conf/WARPm1_10.conf
  $(basename "$0") --iface proton --source /path/to/profiles/<profile>/vpn/proton/conf/example.conf
EOF2
}

sanitize_name() {
  printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

sanitize_profile_name() {
  name="$1"
  name="$(basename "$name" .conf)"
  sanitize_name "$name"
}

resolve_source_conf() {
  value="$1"

  [ -n "$value" ] || return 1
  [ -f "$value" ] && { printf '%s\n' "$value"; return 0; }
  [ -f "$CONF_DIR/$value" ] && { printf '%s\n' "$CONF_DIR/$value"; return 0; }
  [ -f "$CONF_DIR/${value}.conf" ] && { printf '%s\n' "$CONF_DIR/${value}.conf"; return 0; }
  return 1
}

parse_conf_value() {
  file="$1"
  key="$2"
  awk -F '=' -v want="$key" '
    $1 ~ "^[[:space:]]*" want "[[:space:]]*$" {
      v = substr($0, index($0, "=") + 1)
      sub(/^[[:space:]]+/, "", v)
      sub(/[[:space:]]+$/, "", v)
      print v
      exit
    }
  ' "$file"
}

parse_peer_value() {
  file="$1"
  key="$2"
  awk -F '=' -v want="$key" '
    BEGIN { in_peer = 0 }
    /^[[:space:]]*\[Peer\][[:space:]]*$/ { in_peer = 1; next }
    /^[[:space:]]*\[/ && $0 !~ /^[[:space:]]*\[Peer\][[:space:]]*$/ { in_peer = 0 }
    in_peer && $1 ~ "^[[:space:]]*" want "[[:space:]]*$" {
      v = substr($0, index($0, "=") + 1)
      sub(/^[[:space:]]+/, "", v)
      sub(/[[:space:]]+$/, "", v)
      print v
      exit
    }
  ' "$file"
}

split_csv_to_lines() {
  printf '%s\n' "$1" | tr ',' '\n' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | sed '/^$/d'
}

meta_get() {
  file="$1"
  key="$2"
  [ -f "$file" ] || return 0
  awk -F= -v want="$key" '
    {
      gsub(/\r/, "")
    }
    $1 == want {
      v = substr($0, index($0, "=") + 1)
      sub(/^[[:space:]]+/, "", v)
      sub(/[[:space:]]+$/, "", v)
      gsub(/^\047|\047$/, "", v)
      print v
      exit
    }
  ' "$file"
}

iface_conf_value() {
  file="$1"
  key="$2"
  [ -f "$file" ] || return 0
  awk -F= -v want="$key" '
    $1 == want {
      v = substr($0, index($0, "=") + 1)
      sub(/^[[:space:]]+/, "", v)
      sub(/[[:space:]]+$/, "", v)
      gsub(/^\047|\047$/, "", v)
      print v
      exit
    }
  ' "$file"
}

normalize_hex() {
  value="$1"
  value="$(printf '%s\n' "$value" | tr 'A-F' 'a-f')"
  case "$value" in
    0x*) n="${value#0x}" ;;
    *) n="$value" ;;
  esac
  [ -n "$n" ] || return 1
  printf '0x%x\n' "0x$n"
}

slot_for_iface() {
  iface="$1"
  case "$iface" in
    warp) printf '1\n' ;;
    warp[0-9]*)
      num="${iface#warp}"
      [ -n "$num" ] || return 1
      case "$num" in
        ''|*[!0-9]*) return 1 ;;
      esac
      printf '%s\n' "$num"
      ;;
    *)
      return 1
      ;;
  esac
}

iface_for_slot() {
  slot="$1"
  [ "$slot" -eq 1 ] && { printf 'warp\n'; return 0; }
  printf 'warp%s\n' "$slot"
}

mark_hex_for_slot() {
  slot="$1"
  printf '0x12%02x\n' "$slot"
}

table_id_for_slot() {
  slot="$1"
  printf '%s\n' "$((200 + slot))"
}

pref_for_slot() {
  slot="$1"
  printf '%s\n' "$((12000 + slot))"
}

route_table_name_for_iface() {
  iface="$1"
  printf '%s%s\n' "$ROUTE_TABLE_PREFIX" "$iface"
}

nft_fqdn4_set_name_for_iface() {
  iface="$1"
  printf '%s_fqdn4\n' "$iface"
}

nft_fqdn6_set_name_for_iface() {
  iface="$1"
  printf '%s_fqdn6\n' "$iface"
}

nft_prefix4_set_name_for_iface() {
  iface="$1"
  printf '%s_prefixes4\n' "$iface"
}

nft_prefix6_set_name_for_iface() {
  iface="$1"
  printf '%s_prefixes6\n' "$iface"
}

nft_chain_name_for_iface() {
  iface="$1"
  printf 'mangle_prerouting_%s\n' "$iface"
}

nft_output_chain_name_for_iface() {
  iface="$1"
  printf 'mangle_output_%s\n' "$iface"
}

default_peer_section_for_iface() {
  iface="$1"
  printf 'network.@amneziawg_%s[0]\n' "$iface"
}

slot_claimed_by_other_iface() {
  slot="$1"
  expected_iface="$2"
  expected_mark="$(mark_hex_for_slot "$slot")"
  expected_table_id="$(table_id_for_slot "$slot")"
  expected_pref="$(pref_for_slot "$slot")"

  for file in "$INTERFACES_DIR"/*/config/iface.conf; do
    [ -f "$file" ] || continue

    cfg_iface="$(iface_conf_value "$file" "INTERFACE_NAME")"
    cfg_mark="$(iface_conf_value "$file" "MARK_HEX")"
    cfg_table_id="$(iface_conf_value "$file" "ROUTE_TABLE_ID")"
    cfg_pref="$(iface_conf_value "$file" "IP_RULE_PREF")"

    [ -n "$cfg_iface" ] || continue
    [ "$cfg_iface" = "$expected_iface" ] && continue

    [ -n "$cfg_mark" ] && [ "$(normalize_hex "$cfg_mark" 2>/dev/null || true)" = "$expected_mark" ] && return 0
    [ -n "$cfg_table_id" ] && [ "$cfg_table_id" = "$expected_table_id" ] && return 0
    [ -n "$cfg_pref" ] && [ "$cfg_pref" = "$expected_pref" ] && return 0
  done

  return 1
}

slot_exists_for_same_iface() {
  iface="$1"

  [ -d "$INTERFACES_DIR/$iface" ] && return 0

  for file in "$INTERFACES_DIR"/*/config/iface.conf; do
    [ -f "$file" ] || continue
    cfg_iface="$(iface_conf_value "$file" "INTERFACE_NAME")"
    [ "$cfg_iface" = "$iface" ] && return 0
  done

  return 1
}

find_free_auto_slot() {
  slot="$RESERVED_SLOT_MIN"
  while [ "$slot" -le "$RESERVED_SLOT_MAX" ]; do
    iface="$(iface_for_slot "$slot")"
    if ! slot_exists_for_same_iface "$iface" && ! slot_claimed_by_other_iface "$slot" "$iface"; then
      printf '%s\n' "$slot"
      return 0
    fi
    slot=$((slot + 1))
  done
  return 1
}

find_free_slot_for_iface() {
  iface="$1"
  slot="$RESERVED_SLOT_MIN"
  while [ "$slot" -le "$RESERVED_SLOT_MAX" ]; do
    if ! slot_claimed_by_other_iface "$slot" "$iface"; then
      printf '%s\n' "$slot"
      return 0
    fi
    slot=$((slot + 1))
  done
  return 1
}

choose_slot_for_new_iface() {
  iface="$1"
  preferred_slot="$(slot_for_iface "$iface" 2>/dev/null || true)"

  if [ -n "$preferred_slot" ]; then
    if slot_claimed_by_other_iface "$preferred_slot" "$iface"; then
      die "slot=$preferred_slot для интерфейса $iface уже занят другим интерфейсом"
    fi
    printf '%s\n' "$preferred_slot"
    return 0
  fi

  find_free_slot_for_iface "$iface" || return 1
}

choose_slot_for_existing_iface() {
  iface="$1"

  preferred_slot="$(slot_for_iface "$iface" 2>/dev/null || true)"
  if [ -n "$preferred_slot" ] && ! slot_claimed_by_other_iface "$preferred_slot" "$iface"; then
    printf '%s\n' "$preferred_slot"
    return 0
  fi

  find_free_slot_for_iface "$iface" || return 1
}

write_iface_conf_new() {
  dst="$1"
  iface="$2"
  slot="$3"
  source_conf_name="$4"
  source_meta_name="$5"

  mark_hex="$(mark_hex_for_slot "$slot")"
  route_table_id="$(table_id_for_slot "$slot")"
  route_table_name="$(route_table_name_for_iface "$iface")"
  ip_rule_pref="$(pref_for_slot "$slot")"
  nft_fqdn4_set_name="$(nft_fqdn4_set_name_for_iface "$iface")"
  nft_fqdn6_set_name="$(nft_fqdn6_set_name_for_iface "$iface")"
  nft_prefix4_set_name="$(nft_prefix4_set_name_for_iface "$iface")"
  nft_prefix6_set_name="$(nft_prefix6_set_name_for_iface "$iface")"
  nft_chain_name="$(nft_chain_name_for_iface "$iface")"
  nft_output_chain_name="$(nft_output_chain_name_for_iface "$iface")"
  peer_section="$(default_peer_section_for_iface "$iface")"

  cat > "$dst" <<EOF2
# shellcheck shell=sh

INTERFACE_NAME='$iface'
VPN_DEV='$iface'

SOURCE_CONF='$source_conf_name'
SOURCE_META='$source_meta_name'

NETWORK_DELETE_SECTIONS='$iface amneziawg_$iface'
FIREWALL_MODEL='shared-vpn-zone'

MARK_HEX='$mark_hex'
ROUTE_TABLE_ID='$route_table_id'
ROUTE_TABLE_NAME='$route_table_name'
IP_RULE_PREF='$ip_rule_pref'

ROUTING_MODE='vpn'

PROTOCOL_LABEL='AmneziaWG'
AMNEZIAWG_PEER_SECTION='$peer_section'
PERSISTENT_KEEPALIVE_DEFAULT='20'
# TEST_IP для check-routing (ICMP через VPN_DEV). Переопределите при необходимости.
TEST_IP='1.1.1.1'

NFT_FQDN4_SET_NAME='$nft_fqdn4_set_name'
NFT_FQDN6_SET_NAME='$nft_fqdn6_set_name'
NFT_PREFIX4_SET_NAME='$nft_prefix4_set_name'
NFT_PREFIX6_SET_NAME='$nft_prefix6_set_name'
NFT_CHAIN_NAME='$nft_chain_name'
NFT_OUTPUT_CHAIN_NAME='$nft_output_chain_name'

# self-route:
# если задан интерфейс, endpoint данного интерфейса будет направляться через него.
# Пример: SELF_ROUTE_VIA='warp'
SELF_ROUTE_VIA=''

# Skip VPN PBR marks for traffic from these OpenWrt UCI networks (space-separated).
# Example: PBR_BYPASS_NETWORKS='guest' → br-guest goes to WAN, not this VPN.
# Empty = no bypass.
PBR_BYPASS_NETWORKS=''
EOF2
}

write_iface_conf_update() {
  dst="$1"
  existing_iface_conf="$2"
  iface="$3"
  source_conf_name="$4"
  source_meta_name="$5"

  existing_iface="$(iface_conf_value "$existing_iface_conf" "INTERFACE_NAME")"
  existing_vpn_dev="$(iface_conf_value "$existing_iface_conf" "VPN_DEV")"
  existing_mark_hex="$(iface_conf_value "$existing_iface_conf" "MARK_HEX")"
  existing_route_table_id="$(iface_conf_value "$existing_iface_conf" "ROUTE_TABLE_ID")"
  existing_route_table_name="$(iface_conf_value "$existing_iface_conf" "ROUTE_TABLE_NAME")"
  existing_ip_rule_pref="$(iface_conf_value "$existing_iface_conf" "IP_RULE_PREF")"
  existing_network_delete_sections="$(iface_conf_value "$existing_iface_conf" "NETWORK_DELETE_SECTIONS")"
  existing_firewall_model="$(iface_conf_value "$existing_iface_conf" "FIREWALL_MODEL")"
  existing_routing_mode="$(iface_conf_value "$existing_iface_conf" "ROUTING_MODE")"
  existing_protocol_label="$(iface_conf_value "$existing_iface_conf" "PROTOCOL_LABEL")"
  existing_peer_section="$(iface_conf_value "$existing_iface_conf" "AMNEZIAWG_PEER_SECTION")"
  existing_keepalive_default="$(iface_conf_value "$existing_iface_conf" "PERSISTENT_KEEPALIVE_DEFAULT")"
  existing_test_ip="$(iface_conf_value "$existing_iface_conf" "TEST_IP")"
  existing_nft_fqdn4_set_name="$(iface_conf_value "$existing_iface_conf" "NFT_FQDN4_SET_NAME")"
  existing_nft_fqdn6_set_name="$(iface_conf_value "$existing_iface_conf" "NFT_FQDN6_SET_NAME")"
  existing_nft_prefix4_set_name="$(iface_conf_value "$existing_iface_conf" "NFT_PREFIX4_SET_NAME")"
  existing_nft_prefix6_set_name="$(iface_conf_value "$existing_iface_conf" "NFT_PREFIX6_SET_NAME")"
  existing_nft_chain_name="$(iface_conf_value "$existing_iface_conf" "NFT_CHAIN_NAME")"
  existing_nft_output_chain_name="$(iface_conf_value "$existing_iface_conf" "NFT_OUTPUT_CHAIN_NAME")"
  existing_self_route_via="$(iface_conf_value "$existing_iface_conf" "SELF_ROUTE_VIA")"
  existing_pbr_bypass_networks="$(iface_conf_value "$existing_iface_conf" "PBR_BYPASS_NETWORKS")"

  [ -n "$existing_iface" ] || existing_iface="$iface"
  [ "$existing_iface" = "$iface" ] || die "INTERFACE_NAME в существующем iface.conf не совпадает: $existing_iface != $iface"

  [ -n "$existing_vpn_dev" ] || existing_vpn_dev="$iface"
  [ -n "$existing_network_delete_sections" ] || existing_network_delete_sections="$iface amneziawg_$iface"
  [ -n "$existing_firewall_model" ] || existing_firewall_model="shared-vpn-zone"
  [ -n "$existing_routing_mode" ] || existing_routing_mode="vpn"
  [ -n "$existing_protocol_label" ] || existing_protocol_label="AmneziaWG"
  [ -n "$existing_peer_section" ] || existing_peer_section="$(default_peer_section_for_iface "$iface")"
  [ -n "$existing_keepalive_default" ] || existing_keepalive_default="20"
  [ -n "$existing_test_ip" ] || existing_test_ip="1.1.1.1"
  [ -n "$existing_nft_fqdn4_set_name" ] || existing_nft_fqdn4_set_name="$(nft_fqdn4_set_name_for_iface "$iface")"
  [ -n "$existing_nft_fqdn6_set_name" ] || existing_nft_fqdn6_set_name="$(nft_fqdn6_set_name_for_iface "$iface")"
  [ -n "$existing_nft_prefix4_set_name" ] || existing_nft_prefix4_set_name="$(nft_prefix4_set_name_for_iface "$iface")"
  [ -n "$existing_nft_prefix6_set_name" ] || existing_nft_prefix6_set_name="$(nft_prefix6_set_name_for_iface "$iface")"
  [ -n "$existing_nft_chain_name" ] || existing_nft_chain_name="$(nft_chain_name_for_iface "$iface")"
  [ -n "$existing_nft_output_chain_name" ] || existing_nft_output_chain_name="$(nft_output_chain_name_for_iface "$iface")"

  if [ -z "$existing_mark_hex" ] || [ -z "$existing_route_table_id" ] || [ -z "$existing_ip_rule_pref" ]; then
    slot="$(choose_slot_for_existing_iface "$iface")" || die "Не удалось подобрать routing-slot для $iface"
    [ -n "$existing_mark_hex" ] || existing_mark_hex="$(mark_hex_for_slot "$slot")"
    [ -n "$existing_route_table_id" ] || existing_route_table_id="$(table_id_for_slot "$slot")"
    [ -n "$existing_ip_rule_pref" ] || existing_ip_rule_pref="$(pref_for_slot "$slot")"
  fi

  [ -n "$existing_route_table_name" ] || existing_route_table_name="$(route_table_name_for_iface "$iface")"

  cat > "$dst" <<EOF2
# shellcheck shell=sh

INTERFACE_NAME='$iface'
VPN_DEV='$existing_vpn_dev'

SOURCE_CONF='$source_conf_name'
SOURCE_META='$source_meta_name'

NETWORK_DELETE_SECTIONS='$existing_network_delete_sections'
FIREWALL_MODEL='$existing_firewall_model'

MARK_HEX='$existing_mark_hex'
ROUTE_TABLE_ID='$existing_route_table_id'
ROUTE_TABLE_NAME='$existing_route_table_name'
IP_RULE_PREF='$existing_ip_rule_pref'

ROUTING_MODE='$existing_routing_mode'

PROTOCOL_LABEL='$existing_protocol_label'
AMNEZIAWG_PEER_SECTION='$existing_peer_section'
PERSISTENT_KEEPALIVE_DEFAULT='$existing_keepalive_default'
TEST_IP='$existing_test_ip'

NFT_FQDN4_SET_NAME='$existing_nft_fqdn4_set_name'
NFT_FQDN6_SET_NAME='$existing_nft_fqdn6_set_name'
NFT_PREFIX4_SET_NAME='$existing_nft_prefix4_set_name'
NFT_PREFIX6_SET_NAME='$existing_nft_prefix6_set_name'
NFT_CHAIN_NAME='$existing_nft_chain_name'
NFT_OUTPUT_CHAIN_NAME='$existing_nft_output_chain_name'

# self-route:
# если задан интерфейс, endpoint данного интерфейса будет направляться через него.
# Пример: SELF_ROUTE_VIA='warp'
SELF_ROUTE_VIA='$existing_self_route_via'

# Skip VPN PBR marks for traffic from these OpenWrt UCI networks (space-separated).
# Example: PBR_BYPASS_NETWORKS='guest' → br-guest goes to WAN, not this VPN.
# Empty = no bypass.
PBR_BYPASS_NETWORKS='$existing_pbr_bypass_networks'
EOF2
}

parse_route_allowed_ips() {
  file="$1"
  value=""

  value="$(parse_peer_value "$file" "RouteAllowedIPs" 2>/dev/null || true)"
  case "$value" in
    0|1) printf '%s\n' "$value"; return 0 ;;
  esac

  value="$(parse_conf_value "$file" "RouteAllowedIPs" 2>/dev/null || true)"
  case "$value" in
    0|1) printf '%s\n' "$value"; return 0 ;;
  esac

  value="$(awk '
    match($0, /^[[:space:]]*#[[:space:]]*option[[:space:]]+route_allowed_ips[[:space:]]+\047([01])\047/, m) {
      print m[1]
      exit
    }
  ' "$file" 2>/dev/null || true)"
  case "$value" in
    0|1) printf '%s\n' "$value"; return 0 ;;
  esac

  printf '0\n'
}

parse_default_route() {
  file="$1"
  value=""

  value="$(parse_conf_value "$file" "DefaultRoute" 2>/dev/null || true)"
  case "$value" in
    0|1) printf '%s\n' "$value"; return 0 ;;
  esac

  value="$(awk '
    match($0, /^[[:space:]]*#[[:space:]]*option[[:space:]]+defaultroute[[:space:]]+\047([01])\047/, m) {
      print m[1]
      exit
    }
  ' "$file" 2>/dev/null || true)"
  case "$value" in
    0|1) printf '%s\n' "$value"; return 0 ;;
  esac

  printf '0\n'
}

meta_upsert_value() {
  meta_file="$1"
  key="$2"
  value="$3"
  tmp="${meta_file}.tmp.$$"

  awk -v key="$key" -v value="$value" '
    BEGIN { done = 0 }
    $0 ~ ("^" key "=") {
      print key "=\047" value "\047"
      done = 1
      next
    }
    { print }
    END {
      if (!done) {
        print key "=\047" value "\047"
      }
    }
  ' "$meta_file" > "$tmp"
  mv "$tmp" "$meta_file"
}

ensure_source_meta_defaults() {
  src_conf="$1"
  meta_file="$2"

  [ -f "$meta_file" ] || return 0

  route_allowed_default="$(parse_route_allowed_ips "$src_conf")"
  keepalive_default="20"

  meta_upsert_value "$meta_file" "ROUTE_ALLOWED_IPS_DEFAULT" "$route_allowed_default"
  meta_upsert_value "$meta_file" "PERSISTENT_KEEPALIVE_DEFAULT" "$keepalive_default"
}

write_network_uci() {
  src_conf="$1"
  dst="$2"
  iface="$3"

  private_key="$(parse_conf_value "$src_conf" "PrivateKey")"
  mtu="$(parse_conf_value "$src_conf" "MTU")"
  addr_value="$(parse_conf_value "$src_conf" "Address")"
  dns_value="$(parse_conf_value "$src_conf" "DNS")"
  s1="$(parse_conf_value "$src_conf" "S1")"
  s2="$(parse_conf_value "$src_conf" "S2")"
  s3="$(parse_conf_value "$src_conf" "S3")"
  s4="$(parse_conf_value "$src_conf" "S4")"
  jc="$(parse_conf_value "$src_conf" "Jc")"
  jmin="$(parse_conf_value "$src_conf" "Jmin")"
  jmax="$(parse_conf_value "$src_conf" "Jmax")"
  h1="$(parse_conf_value "$src_conf" "H1")"
  h2="$(parse_conf_value "$src_conf" "H2")"
  h3="$(parse_conf_value "$src_conf" "H3")"
  h4="$(parse_conf_value "$src_conf" "H4")"
  i1="$(parse_conf_value "$src_conf" "I1")"
  i2="$(parse_conf_value "$src_conf" "I2")"
  i3="$(parse_conf_value "$src_conf" "I3")"
  i4="$(parse_conf_value "$src_conf" "I4")"
  i5="$(parse_conf_value "$src_conf" "I5")"

  public_key="$(parse_peer_value "$src_conf" "PublicKey")"
  allowed_ips="$(parse_peer_value "$src_conf" "AllowedIPs")"
  endpoint="$(parse_peer_value "$src_conf" "Endpoint")"
  route_allowed_ips="$(parse_route_allowed_ips "$src_conf")"
  default_route="$(parse_default_route "$src_conf")"

  [ -n "$private_key" ] || die "В conf отсутствует PrivateKey"
  [ -n "$public_key" ] || die "В conf отсутствует PublicKey в секции [Peer]"
  [ -n "$endpoint" ] || die "В conf отсутствует Endpoint в секции [Peer]"

  endpoint_host="${endpoint%:*}"
  endpoint_port="${endpoint##*:}"
  [ -n "$endpoint_host" ] || die "Не удалось разобрать Endpoint host"
  [ -n "$endpoint_port" ] || die "Не удалось разобрать Endpoint port"

  cat > "$dst" <<EOF2
package network

config interface '$iface'
        option proto 'amneziawg'
        option private_key '$private_key'
        option defaultroute '$default_route'
EOF2

  if [ -n "$mtu" ]; then
    printf "        option mtu '%s'\n" "$mtu" >> "$dst"
  fi

  if [ -n "$jc" ]; then
    printf "        option awg_jc '%s'\n" "$jc" >> "$dst"
  fi
  if [ -n "$jmin" ]; then
    printf "        option awg_jmin '%s'\n" "$jmin" >> "$dst"
  fi
  if [ -n "$jmax" ]; then
    printf "        option awg_jmax '%s'\n" "$jmax" >> "$dst"
  fi

  if [ -n "$s1" ]; then
    printf "        option awg_s1 '%s'\n" "$s1" >> "$dst"
  fi
  if [ -n "$s2" ]; then
    printf "        option awg_s2 '%s'\n" "$s2" >> "$dst"
  fi
  if [ -n "$s3" ]; then
    printf "        option awg_s3 '%s'\n" "$s3" >> "$dst"
  fi
  if [ -n "$s4" ]; then
    printf "        option awg_s4 '%s'\n" "$s4" >> "$dst"
  fi

  if [ -n "$h1" ]; then
    printf "        option awg_h1 '%s'\n" "$h1" >> "$dst"
  fi
  if [ -n "$h2" ]; then
    printf "        option awg_h2 '%s'\n" "$h2" >> "$dst"
  fi
  if [ -n "$h3" ]; then
    printf "        option awg_h3 '%s'\n" "$h3" >> "$dst"
  fi
  if [ -n "$h4" ]; then
    printf "        option awg_h4 '%s'\n" "$h4" >> "$dst"
  fi

  if [ -n "$i1" ]; then
    printf "        option awg_i1 '%s'\n" "$i1" >> "$dst"
  fi
  if [ -n "$i2" ]; then
    printf "        option awg_i2 '%s'\n" "$i2" >> "$dst"
  fi
  if [ -n "$i3" ]; then
    printf "        option awg_i3 '%s'\n" "$i3" >> "$dst"
  fi
  if [ -n "$i4" ]; then
    printf "        option awg_i4 '%s'\n" "$i4" >> "$dst"
  fi
  if [ -n "$i5" ]; then
    printf "        option awg_i5 '%s'\n" "$i5" >> "$dst"
  fi

  printf "        option multipath 'off'\n" >> "$dst"

  if [ -n "$addr_value" ]; then
    split_csv_to_lines "$addr_value" | while IFS= read -r item || [ -n "$item" ]; do
      [ -n "$item" ] || continue
      item="${item%%/*}"
      printf "        list addresses '%s'\n" "$item" >> "$dst"
    done
  fi

  if [ -n "$dns_value" ]; then
    split_csv_to_lines "$dns_value" | while IFS= read -r item || [ -n "$item" ]; do
      [ -n "$item" ] || continue
      printf "        list dns '%s'\n" "$item" >> "$dst"
    done
  else
    printf "        list dns '%s'\n" "$LOCAL_DNS" >> "$dst"
  fi

  description="$(basename "$src_conf")"

  cat >> "$dst" <<EOF2

config amneziawg_$iface
        option description '$description'
        option public_key '$public_key'
        option endpoint_host '$endpoint_host'
        option endpoint_port '$endpoint_port'
        option persistent_keepalive '20'
        option route_allowed_ips '$route_allowed_ips'
EOF2

  if [ -n "$allowed_ips" ]; then
    split_csv_to_lines "$allowed_ips" | while IFS= read -r item || [ -n "$item" ]; do
      [ -n "$item" ] || continue
      printf "        list allowed_ips '%s'\n" "$item" >> "$dst"
    done
  fi

  grep -q "list allowed_ips '0.0.0.0/0'" "$dst" || printf "        list allowed_ips '0.0.0.0/0'\n" >> "$dst"
  grep -q "list allowed_ips '::/0'" "$dst" || printf "        list allowed_ips '::/0'\n" >> "$dst"
}

write_firewall_uci() {
  dst="$1"
  iface="$2"

  cat > "$dst" <<EOF2
package firewall

# Этот файл не создает отдельную zone.
# Интерфейс '$iface' должен быть добавлен в общую зону 'vpn'.
# Применение лучше делать идемпотентно из отдельного apply-скрипта.

config include
        option type 'script'
        option path '/bin/true'

# interface=$iface
# zone=vpn
# forwarding=lan->vpn
EOF2
}

main() {
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --iface)
        shift
        [ "$#" -gt 0 ] || die "--iface требует значение"
        IFACE_NAME="$1"
        ;;
      --source)
        shift
        [ "$#" -gt 0 ] || die "--source требует значение"
        SOURCE_FILE="$1"
        ;;
      -h|--help)
        usage
        exit 0
        ;;
      *)
        die "Неизвестный аргумент: $1"
        ;;
    esac
    shift || true
  done

  [ -n "$IFACE_NAME" ] || die "Требуется --iface IFACE|auto"
  [ -n "$SOURCE_FILE" ] || die "Требуется --source FILE|BASENAME"

  IFACE_NAME="$(sanitize_name "$IFACE_NAME")"
  [ -n "$IFACE_NAME" ] || die "Имя интерфейса после очистки пустое"

  src_conf="$(resolve_source_conf "$SOURCE_FILE" || true)"
  [ -n "$src_conf" ] || die "Не найден исходный conf-файл: $SOURCE_FILE"
  [ -f "$src_conf" ] || die "Файл не найден: $src_conf"

  src_meta="${src_conf}.meta"
  generator_kind="$(meta_get "$src_meta" "GENERATOR_KIND")"
  server_id="$(meta_get "$src_meta" "SERVER_ID")"
  variant_id="$(meta_get "$src_meta" "VARIANT_ID")"
  profile_basename="$(meta_get "$src_meta" "PROFILE_BASENAME")"
  profile_label="$(meta_get "$src_meta" "PROFILE_LABEL")"
  endpoint="$(meta_get "$src_meta" "ENDPOINT")"
  endpoint_host="$(meta_get "$src_meta" "ENDPOINT_HOST")"
  endpoint_port="$(meta_get "$src_meta" "ENDPOINT_PORT")"
  endpoint_label="$(meta_get "$src_meta" "ENDPOINT_LABEL")"
  dns_value="$(meta_get "$src_meta" "DNS_VALUE")"
  allowed_ips="$(meta_get "$src_meta" "ALLOWED_IPS")"
  generated_at_utc="$(meta_get "$src_meta" "GENERATED_AT_UTC")"

  [ -n "$generator_kind" ] || generator_kind="manual"
  [ -n "$server_id" ] || server_id=""
  [ -n "$variant_id" ] || variant_id=""
  [ -n "$profile_basename" ] || profile_basename="$(sanitize_profile_name "$src_conf")"
  [ -n "$profile_label" ] || profile_label="$profile_basename"
  [ -n "$endpoint" ] || endpoint="$(parse_peer_value "$src_conf" "Endpoint")"
  [ -n "$endpoint_host" ] || endpoint_host="${endpoint%:*}"
  [ -n "$endpoint_port" ] || endpoint_port="${endpoint##*:}"
  [ -n "$endpoint_label" ] || endpoint_label="$endpoint_host"
  [ -n "$dns_value" ] || dns_value="$(parse_conf_value "$src_conf" "DNS")"
  [ -n "$allowed_ips" ] || allowed_ips="$(parse_peer_value "$src_conf" "AllowedIPs")"
  [ -n "$generated_at_utc" ] || generated_at_utc=""

  mode_label=""
  selected_slot=""
  iface_dir=""
  config_dir=""
  existing_iface_conf=""

  case "$IFACE_NAME" in
    auto)
      selected_slot="$(find_free_auto_slot || true)"
      [ -n "$selected_slot" ] || die "Не найден свободный slot в зарезервированном диапазоне ${RESERVED_SLOT_MIN}..${RESERVED_SLOT_MAX}"
      IFACE_NAME="$(iface_for_slot "$selected_slot")"
      mode_label="new-auto"
      ;;
    *)
      iface_dir="$INTERFACES_DIR/$IFACE_NAME"
      config_dir="$iface_dir/config"
      existing_iface_conf="$config_dir/iface.conf"

      if [ -f "$existing_iface_conf" ]; then
        mode_label="update-existing"
      else
        selected_slot="$(choose_slot_for_new_iface "$IFACE_NAME" || true)"
        [ -n "$selected_slot" ] || die "Не удалось подобрать routing-slot для интерфейса $IFACE_NAME"
        mode_label="new-explicit"
      fi
      ;;
  esac

  [ -n "$iface_dir" ] || iface_dir="$INTERFACES_DIR/$IFACE_NAME"
  [ -n "$config_dir" ] || config_dir="$iface_dir/config"

  mkdir -p "$config_dir" "$iface_dir/fqdn.d" "$iface_dir/fqdn.exclude.d" "$iface_dir/prefixes.d"

  out_iface_conf="$config_dir/iface.conf"
  out_network="$config_dir/network.uci"
  out_firewall="$config_dir/firewall.uci"
  out_source="$config_dir/source.conf"
  out_source_meta="$config_dir/source.conf.meta"

  info "Исходный файл: $(basename "$src_conf")"
  info "Интерфейс: $IFACE_NAME"
  info "Режим: $mode_label"
  info "Каталог интерфейса: $iface_dir"

  cp -f "$src_conf" "$out_source"
  info "Обновлён source.conf: $out_source"

  if [ -f "$src_meta" ]; then
    cp -f "$src_meta" "$out_source_meta"
  else
    {
      printf "GENERATOR_KIND='%s'\n" "$generator_kind"
      printf "SERVER_ID='%s'\n" "$server_id"
      printf "VARIANT_ID='%s'\n" "$variant_id"
      printf "NAME_SCHEMA_VERSION='7'\n"
      printf "PROFILE_BASENAME='%s'\n" "$profile_basename"
      printf "PROFILE_LABEL='%s'\n" "$profile_label"
      printf "ENDPOINT='%s'\n" "$endpoint"
      printf "ENDPOINT_HOST='%s'\n" "$endpoint_host"
      printf "ENDPOINT_PORT='%s'\n" "$endpoint_port"
      printf "ENDPOINT_LABEL='%s'\n" "$endpoint_label"
      printf "DNS_VALUE='%s'\n" "$dns_value"
      printf "ALLOWED_IPS='%s'\n" "$allowed_ips"
      printf "GENERATED_AT_UTC='%s'\n" "$generated_at_utc"
    } > "$out_source_meta"
  fi
  ensure_source_meta_defaults "$src_conf" "$out_source_meta"
  info "Обновлён source.conf.meta: $out_source_meta"

  write_network_uci "$src_conf" "$out_network" "$IFACE_NAME"
  info "Обновлён network.uci: $out_network"

  write_firewall_uci "$out_firewall" "$IFACE_NAME"
  info "Обновлён firewall.uci: $out_firewall"

  case "$mode_label" in
    new-auto|new-explicit)
      write_iface_conf_new \
        "$out_iface_conf" \
        "$IFACE_NAME" \
        "$selected_slot" \
        "source.conf" \
        "source.conf.meta"
      ;;
    update-existing)
      write_iface_conf_update \
        "$out_iface_conf" \
        "$existing_iface_conf" \
        "$IFACE_NAME" \
        "source.conf" \
        "source.conf.meta"
      ;;
    *)
      die "Неизвестный режим: $mode_label"
      ;;
  esac

  info "Обновлён iface.conf: $out_iface_conf"

  success "Конфиг интерфейса сгенерирован: $iface_dir"
}

main "$@"
