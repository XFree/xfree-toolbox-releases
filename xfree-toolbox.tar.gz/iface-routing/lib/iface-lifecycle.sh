#!/bin/sh
# shellcheck shell=sh
# Canonical interface lifecycle, credential acquisition & reconnection library for xfree-toolbox
# Implements unified polymorphic contract: iface_reconnect "$iface"

iface_get_kind() {
    _iface="$1"
    [ -n "$_iface" ] || { printf 'unknown\n'; return 1; }

    # 1. From source metadata in profiles or system state
    _prof_dir="${PROFILE_DIR:-}"
    if [ -z "$_prof_dir" ] && command -v common_profile_dir >/dev/null 2>&1; then
        _prof_dir="$(common_profile_dir 2>/dev/null || true)"
    fi
    for _meta in \
        ${_prof_dir:+"$_prof_dir/iface-routing/interfaces/$_iface/config/source.conf.meta"} \
        ${_prof_dir:+"$_prof_dir/iface-routing/interfaces/$_iface/config/source.ovpn.meta"} \
        ${_prof_dir:+"$_prof_dir/iface-routing/interfaces/$_iface/config/source.vless.meta"} \
        "/etc/xfree-toolbox/iface-routing/interfaces/$_iface/config/source.conf.meta" \
        "/etc/xfree-toolbox/iface-routing/interfaces/$_iface/config/source.ovpn.meta" \
        "/etc/xfree-toolbox/iface-routing/interfaces/$_iface/config/source.vless.meta"; do
        if [ -n "$_meta" ] && [ -f "$_meta" ]; then
            _k="$(sed -n "s/^GENERATOR_KIND='\\(.*\\)'\$/\\1/p" "$_meta" 2>/dev/null || true)"
            case "$_k" in
                openvpn|proton|warp|amneziawg|wireguard|vless)
                    printf '%s\n' "$_k"
                    return 0
                    ;;
            esac
        fi
    done

    # 2. From OpenVPN / VLESS runtime files or UCI config
    if [ -f "/etc/xfree-toolbox/iface-routing/openvpn/$_iface.ovpn" ] || \
       { [ -f "/etc/config/openvpn" ] && uci -q get "openvpn.$_iface" >/dev/null 2>&1; }; then
        printf 'openvpn\n'
        return 0
    fi
    if [ -f "/etc/xfree-toolbox/iface-routing/vless/$_iface.json" ] || \
       { [ -n "$_prof_dir" ] && [ -f "$_prof_dir/iface-routing/interfaces/$_iface/config/singbox.json" ]; }; then
        printf 'vless\n'
        return 0
    fi

    # 3. From interface config
    for _cfg in \
        ${_prof_dir:+"$_prof_dir/iface-routing/interfaces/$_iface/config/iface.conf"} \
        "/etc/xfree-toolbox/iface-routing/interfaces/$_iface/config/iface.conf"; do
        if [ -n "$_cfg" ] && [ -f "$_cfg" ]; then
            _proto="$(sed -n "s/^PROTOCOL_LABEL='\\(.*\\)'\$/\\1/p" "$_cfg" 2>/dev/null || true)"
            case "$_proto" in
                [Oo]pen[Vv][Pp][Nn]) printf 'openvpn\n'; return 0 ;;
                *VLESS*|*vless*) printf 'vless\n'; return 0 ;;
            esac
            _vproto="$(sed -n "s/^VPN_PROTO='\\(.*\\)'\$/\\1/p" "$_cfg" 2>/dev/null || true)"
            case "$_vproto" in
                vless|openvpn|wireguard|amneziawg) printf '%s\n' "$_vproto"; return 0 ;;
            esac
            _type="$(sed -n "s/^TYPE='\\(.*\\)'\$/\\1/p" "$_cfg" 2>/dev/null || true)"
            case "$_type" in
                vless|openvpn|wireguard|amneziawg) printf '%s\n' "$_type"; return 0 ;;
            esac
            [ -n "$_proto" ] && { printf '%s\n' "$_proto"; return 0; }
        fi
    done

    # 4. From network UCI proto
    _proto="$(uci -q get "network.$_iface.proto" 2>/dev/null || true)"
    case "$_proto" in
        amneziawg|wireguard) printf '%s\n' "$_proto"; return 0 ;;
        none|unmanaged)
            if [ -f "/etc/xfree-toolbox/iface-routing/openvpn/$_iface.ovpn" ]; then
                printf 'openvpn\n'
                return 0
            fi
            ;;
    esac

    printf '%s\n' "${_proto:-unknown}"
    return 0
}

# Step 1: Pre-connect / key acquisition step
# Returns 0 on success (or if no key renewal needed), non-zero on critical failure.
iface_refresh_credentials() {
    _iface="$1"
    _kind="$(iface_get_kind "$_iface")"

    case "$_kind" in
        openvpn)
            # Ensure runtime credentials.env exists if present in profile
            _prof_dir="${PROFILE_DIR:-}"
            if [ -z "$_prof_dir" ] && command -v common_profile_dir >/dev/null 2>&1; then
                _prof_dir="$(common_profile_dir 2>/dev/null || true)"
            fi
            for _dir in \
                ${_prof_dir:+"$_prof_dir/iface-routing/interfaces/$_iface/config"} \
                "/etc/xfree-toolbox/iface-routing/interfaces/$_iface/config"; do
                if [ -n "$_dir" ] && [ -f "$_dir/credentials.env" ]; then
                    mkdir -p /etc/xfree-toolbox/iface-routing/openvpn
                    cp -f "$_dir/credentials.env" "/etc/xfree-toolbox/iface-routing/openvpn/$_iface.env" 2>/dev/null || true
                    chmod 600 "/etc/xfree-toolbox/iface-routing/openvpn/$_iface.env" 2>/dev/null || true
                    break
                fi
            done

            _refreshed=0
            for _sh in \
                "/etc/xfree-toolbox/iface-routing/openvpn/refresh-auth.sh" \
                "/root/xfree-toolbox/iface-routing/vpn/openvpn/refresh-auth.sh"; do
                if [ -x "$_sh" ]; then
                    "$_sh" "$_iface"
                    _refreshed=1
                    break
                fi
            done
            return 0
            ;;

        proton)
            # Renew Proton credentials on bounce only when cert is due/expired or explicitly forced.
            # Full outage rebuild (tunnel-fail / both) runs after 3/3 bounce failure in tunnel probe.
            if command -v proton_guest_renew_execute >/dev/null 2>&1; then
                _should_renew=0
                if [ "${PROTON_FORCE_RENEW:-0}" = "1" ]; then
                    _should_renew=1
                elif command -v proton_guest_renew_cert_due_iface >/dev/null 2>&1 && \
                     proton_guest_renew_cert_due_iface "$_iface" "${USB_WATCH_PROTON_GUEST_RENEW_SKEW_SEC:-600}" 2>/dev/null; then
                    _should_renew=1
                fi
                if [ "$_should_renew" -eq 1 ]; then
                    proton_guest_renew_execute "$_iface" || true
                fi
            fi
            return 0
            ;;

        warp)
            # WARP uses static keys unless rotated via regenerate-interface-config
            return 0
            ;;

        amneziawg|wireguard|*)
            # Static keys, no pre-connect step required
            return 0
            ;;
    esac
}

# Step 2 & 3: Teardown, bringup and transport restart
iface_reconnect() {
    _iface="$1"
    [ -n "$_iface" ] || return 1
    _kind="$(iface_get_kind "$_iface")"

    # 1. Acquire new key/token/credentials
    iface_refresh_credentials "$_iface" || true

    # 2. Restart transport and interface
    case "$_kind" in
        openvpn)
            if command -v ifdown >/dev/null 2>&1; then
                ifdown "$_iface" >/dev/null 2>&1 || true
            fi
            if [ -f "/etc/config/openvpn" ]; then
                /etc/init.d/openvpn stop "$_iface" >/dev/null 2>&1 || true
                _ovpn_pid="$(pgrep -f "openvpn.*$_iface" 2>/dev/null || true)"
                if [ -n "$_ovpn_pid" ]; then
                    kill -15 $_ovpn_pid 2>/dev/null || true
                    sleep 1
                    kill -9 $_ovpn_pid 2>/dev/null || true
                fi
            fi
            sleep 1
            if command -v ifup >/dev/null 2>&1; then
                ifup "$_iface" >/dev/null 2>&1 || true
            fi
            if [ -f "/etc/config/openvpn" ]; then
                /etc/init.d/openvpn restart "$_iface" >/dev/null 2>&1 || \
                /etc/init.d/openvpn start "$_iface" >/dev/null 2>&1 || true
            fi
            ;;

        vless)
            if command -v ifdown >/dev/null 2>&1; then
                ifdown "$_iface" >/dev/null 2>&1 || true
            fi
            if [ -x "/etc/init.d/xfree-singbox" ]; then
                /etc/init.d/xfree-singbox restart >/dev/null 2>&1 || true
            fi
            sleep 1
            if command -v ifup >/dev/null 2>&1; then
                ifup "$_iface" >/dev/null 2>&1 || true
            fi
            ;;

        *)
            if command -v ifdown >/dev/null 2>&1; then
                ifdown "$_iface" >/dev/null 2>&1 || true
                sleep 1
                ifup "$_iface" >/dev/null 2>&1 || true
            fi
            ;;
    esac

    # 3. Wait for interface device to be present (up to 20s)
    if command -v wait_interface_ready >/dev/null 2>&1; then
        wait_interface_ready "$_iface" 20 1 0 || true
    fi

    return 0
}
