#!/bin/sh
# shellcheck shell=sh
# When sourced from apply-interfaces/apply-routing, $0 is the caller path, not this file.
# Callers set ROOT_DIR to the toolbox root before sourcing — keep it if valid.
if [ -z "${ROOT_DIR:-}" ] || [ ! -f "$ROOT_DIR/lib/state-sync.sh" ]; then
    SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"
fi

[ -f "$ROOT_DIR/lib/state-sync.sh" ] || {
    printf '[-] Не найден state-sync lib: %s\n' "$ROOT_DIR/lib/state-sync.sh" >&2
    exit 1
}
# shellcheck disable=SC1090
. "$ROOT_DIR/lib/state-sync.sh"

iface_state_sync_config_from_work() {
    iface="$1"
    work_interfaces_dir="$2"
    state_interfaces_dir="$3"
    state_sync_iface_config_mirror_from_work "$iface" "$work_interfaces_dir" "$state_interfaces_dir"
}

iface_state_sync_lists_from_work() {
    iface="$1"
    work_interfaces_dir="$2"
    state_interfaces_dir="$3"
    state_sync_iface_lists_mirror_from_work "$iface" "$work_interfaces_dir" "$state_interfaces_dir"
}

# Compare only *.lst under fqdn.d and prefixes.d (same scope as state_sync_iface_lists_mirror_from_work).
# Returns 0 if work and state differ (needs apply), 1 if identical.
iface_state_iface_lists_out_of_sync() {
    iface="$1"
    work_interfaces_dir="$2"
    state_interfaces_dir="$3"

    [ -n "${iface:-}" ] || return 1
    [ -n "${work_interfaces_dir:-}" ] || return 1
    [ -n "${state_interfaces_dir:-}" ] || return 1

    for sub in fqdn.d prefixes.d; do
        wd="$work_interfaces_dir/$iface/$sub"
        sd="$state_interfaces_dir/$iface/$sub"
        tw="$(mktemp -d)" || return 1
        ts="$(mktemp -d)" || {
            rm -rf "$tw"
            return 1
        }

        if [ -d "$wd" ]; then
            for f in "$wd"/*.lst; do
                [ -f "$f" ] || continue
                cp -f "$f" "$tw/"
            done
        fi
        mkdir -p "$sd" 2>/dev/null || true
        if [ -d "$sd" ]; then
            for f in "$sd"/*.lst; do
                [ -f "$f" ] || continue
                cp -f "$f" "$ts/"
            done
        fi

        diff_ok=0
        if diff -qr "$tw" "$ts" >/dev/null 2>&1; then
            diff_ok=1
        fi
        rm -rf "$tw" "$ts"
        [ "$diff_ok" -eq 1 ] || return 0
    done
    return 1
}

# Returns 0 if any profile interface has list dirs out of sync with system state.
iface_state_any_iface_lists_out_of_sync() {
    work_interfaces_dir="$1"
    state_interfaces_dir="$2"

    [ -d "$work_interfaces_dir" ] || return 1

    for idir in "$work_interfaces_dir"/*; do
        [ -d "$idir" ] || continue
        iface="$(basename "$idir")"
        [ -f "$idir/config/iface.conf" ] || continue
        if iface_state_iface_lists_out_of_sync "$iface" "$work_interfaces_dir" "$state_interfaces_dir"; then
            return 0
        fi
    done
    return 1
}
