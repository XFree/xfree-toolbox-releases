#!/bin/sh
# shellcheck shell=sh
# Shared AmneziaWG/WireGuard handshake helpers (awg|wg dump).
# Peer lines: tab-separated; field 5 = latest_handshake epoch (0 = never).

VPN_HANDSHAKE_LIB_SOURCED="${VPN_HANDSHAKE_LIB_SOURCED:-}"
[ -n "$VPN_HANDSHAKE_LIB_SOURCED" ] && return 0
VPN_HANDSHAKE_LIB_SOURCED=1

# Max age (seconds) treated as fresh handshake for status "ok".
: "${VPN_HANDSHAKE_FRESH_SEC:=180}"

vpn_handshake_dump_max_ts() {
    _dump="$1"
    # Skip interface row (NR>1). Require peer-like width (NF>=8).
    printf '%s\n' "$_dump" | awk -F'\t' 'NR>1 && NF>=8 { v=$5+0; if (v>m) m=v } END { print m+0 }'
}

vpn_handshake_dump_for_dev() {
    _dev="$1"
    [ -n "$_dev" ] || return 1
    _dump=""
    if command -v awg >/dev/null 2>&1; then
        _dump="$(awg show "$_dev" dump 2>/dev/null || true)"
    fi
    if [ -z "$_dump" ] && command -v wg >/dev/null 2>&1; then
        _dump="$(wg show "$_dev" dump 2>/dev/null || true)"
    fi
    [ -n "$_dump" ] || return 1
    printf '%s\n' "$_dump"
}

# Prints: down | unknown | none | ok | stale
# Optional 2nd line via VPN_HANDSHAKE_DETAIL=1: age_sec or note.
vpn_handshake_status() {
    _dev="$1"
    _fresh="${2:-$VPN_HANDSHAKE_FRESH_SEC}"
    case "$_fresh" in
        ''|*[!0-9]*) _fresh=180 ;;
    esac

    if [ -z "$_dev" ] || ! ip link show "$_dev" >/dev/null 2>&1; then
        printf 'down\n'
        return 0
    fi

    _dump="$(vpn_handshake_dump_for_dev "$_dev" 2>/dev/null || true)"
    if [ -z "$_dump" ]; then
        printf 'unknown\n'
        return 0
    fi

    _ts="$(vpn_handshake_dump_max_ts "$_dump")"
    case "$_ts" in
        ''|0)
            printf 'none\n'
            return 0
            ;;
    esac

    _now="$(date +%s 2>/dev/null || echo 0)"
    if [ "$_now" -eq 0 ] 2>/dev/null; then
        printf 'unknown\n'
        return 0
    fi
    _age=$((_now - _ts))
    if [ "$_age" -lt 0 ] 2>/dev/null; then
        printf 'unknown\n'
        return 0
    fi
    if [ "$_age" -le "$_fresh" ] 2>/dev/null; then
        printf 'ok\n'
    else
        printf 'stale\n'
    fi
    if [ "${VPN_HANDSHAKE_DETAIL:-0}" = "1" ]; then
        printf '%s\n' "$_age"
    fi
    return 0
}

# Compact label for status UI: hs=ok(12s) | hs=none | hs=stale(400s) | hs=? | hs=down
vpn_handshake_status_label() {
    _dev="$1"
    _fresh="${2:-$VPN_HANDSHAKE_FRESH_SEC}"
    VPN_HANDSHAKE_DETAIL=1
    _out="$(vpn_handshake_status "$_dev" "$_fresh" 2>/dev/null || true)"
    VPN_HANDSHAKE_DETAIL=0
    _st="$(printf '%s\n' "$_out" | sed -n '1p')"
    _age="$(printf '%s\n' "$_out" | sed -n '2p')"
    case "$_st" in
        ok)
            if [ -n "$_age" ]; then
                printf 'hs=ok(%ss)' "$_age"
            else
                printf 'hs=ok'
            fi
            ;;
        stale)
            if [ -n "$_age" ]; then
                printf 'hs=stale(%ss)' "$_age"
            else
                printf 'hs=stale'
            fi
            ;;
        none) printf 'hs=none' ;;
        down) printf 'hs=down' ;;
        *) printf 'hs=?' ;;
    esac
}
