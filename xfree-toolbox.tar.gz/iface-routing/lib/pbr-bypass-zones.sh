#!/bin/sh
# shellcheck shell=sh
# Per VPN iface (iface.conf): PBR_BYPASS_NETWORKS='guest lan'
# Space/comma-separated OpenWrt UCI *network* interface names.
# Traffic from those networks skips this iface's VPN PBR marks → direct WAN.
# Empty = no bypass (default). No auto firewall-zone detection.

# 255.255.255.0 → 24
pbr_bypass_netmask_to_prefix() {
    mask="$1"
    case "$mask" in
        255.255.255.255) printf '32\n' ;;
        255.255.255.254) printf '31\n' ;;
        255.255.255.252) printf '30\n' ;;
        255.255.255.248) printf '29\n' ;;
        255.255.255.240) printf '28\n' ;;
        255.255.255.224) printf '27\n' ;;
        255.255.255.192) printf '26\n' ;;
        255.255.255.128) printf '25\n' ;;
        255.255.255.0) printf '24\n' ;;
        255.255.254.0) printf '23\n' ;;
        255.255.252.0) printf '22\n' ;;
        255.255.248.0) printf '21\n' ;;
        255.255.240.0) printf '20\n' ;;
        255.255.224.0) printf '19\n' ;;
        255.255.192.0) printf '18\n' ;;
        255.255.128.0) printf '17\n' ;;
        255.255.0.0) printf '16\n' ;;
        255.254.0.0) printf '15\n' ;;
        255.252.0.0) printf '14\n' ;;
        255.248.0.0) printf '13\n' ;;
        255.240.0.0) printf '12\n' ;;
        255.224.0.0) printf '11\n' ;;
        255.192.0.0) printf '10\n' ;;
        255.128.0.0) printf '9\n' ;;
        255.0.0.0) printf '8\n' ;;
        *) printf '%s\n' "" ;;
    esac
}

# ip + netmask → network/prefix (e.g. 192.168.32.1 + 255.255.255.0 → 192.168.32.0/24)
pbr_bypass_ipv4_network_cidr() {
    ip="$1"
    mask="$2"
    prefix="$(pbr_bypass_netmask_to_prefix "$mask")"
    [ -n "$ip" ] && [ -n "$prefix" ] || return 1
    old_ifs="$IFS"
    IFS=.
    # shellcheck disable=SC2086
    set -- $ip
    IFS="$old_ifs"
    [ "$#" -eq 4 ] || return 1
    a1=$1 a2=$2 a3=$3 a4=$4
    IFS=.
    # shellcheck disable=SC2086
    set -- $mask
    IFS="$old_ifs"
    [ "$#" -eq 4 ] || return 1
    printf '%d.%d.%d.%d/%s\n' \
        $((a1 & $1)) $((a2 & $2)) $((a3 & $3)) $((a4 & $4)) "$prefix"
}

pbr_bypass_parse_networks() {
    # stdin or $1: raw PBR_BYPASS_NETWORKS value → one network name per line
    raw="${1:-}"
    printf '%s\n' "$raw" | tr ',\t' ' ' | tr -s ' ' '\n' | sed '/^$/d'
}

pbr_bypass_network_iif() {
    net="$1"
    [ -n "$net" ] || return 0
    command -v uci >/dev/null 2>&1 || return 0

    dev="$(uci -q get "network.${net}.device" 2>/dev/null || true)"
    if [ -z "$dev" ] && command -v ifstatus >/dev/null 2>&1 && command -v jsonfilter >/dev/null 2>&1; then
        dev="$(ifstatus "$net" 2>/dev/null | jsonfilter -e '@["l3_device"]' 2>/dev/null || true)"
    fi
    if [ -z "$dev" ] && command -v ubus >/dev/null 2>&1 && command -v jsonfilter >/dev/null 2>&1; then
        dev="$(ubus call "network.interface.${net}" status 2>/dev/null | jsonfilter -e '@["l3_device"]' 2>/dev/null || true)"
    fi
    if [ -z "$dev" ]; then
        case "$net" in
            *[!a-zA-Z0-9_-]*) ;;
            *)
                if [ -d "/sys/class/net/br-${net}" ]; then
                    dev="br-${net}"
                elif [ -d "/sys/class/net/${net}" ]; then
                    dev="$net"
                fi
                ;;
        esac
    fi
    [ -n "$dev" ] || return 0
    printf '%s\n' "$dev"
}

pbr_bypass_network_ipv4_cidr() {
    net="$1"
    [ -n "$net" ] || return 0
    command -v uci >/dev/null 2>&1 || return 0

    ip="$(uci -q get "network.${net}.ipaddr" 2>/dev/null || true)"
    ip="$(printf '%s\n' "$ip" | awk '{print $1; exit}')"
    case "$ip" in
        */*)
            printf '%s\n' "$ip"
            return 0
            ;;
    esac
    mask="$(uci -q get "network.${net}.netmask" 2>/dev/null || true)"
    [ -n "$ip" ] || return 0
    if [ -n "$mask" ]; then
        pbr_bypass_ipv4_network_cidr "$ip" "$mask" 2>/dev/null || printf '%s/32\n' "$ip"
    else
        printf '%s/32\n' "$ip"
    fi
}

pbr_bypass_network_ipv6_cidrs() {
    net="$1"
    [ -n "$net" ] || return 0
    command -v uci >/dev/null 2>&1 || return 0
    uci -q get "network.${net}.ip6addr" 2>/dev/null | tr ' \t' '\n' | sed '/^$/d' | while IFS= read -r a; do
        case "$a" in
            *:*)
                case "$a" in
                    */*) printf '%s\n' "$a" ;;
                    *) printf '%s/128\n' "$a" ;;
                esac
                ;;
        esac
    done
}

pbr_bypass_collect_iifs_from_networks() {
    networks_raw="$1"
    pbr_bypass_parse_networks "$networks_raw" | while IFS= read -r net; do
        [ -n "$net" ] || continue
        pbr_bypass_network_iif "$net"
    done | sed '/^$/d' | sort -u
}

pbr_bypass_collect_ipv4_from_networks() {
    networks_raw="$1"
    pbr_bypass_parse_networks "$networks_raw" | while IFS= read -r net; do
        [ -n "$net" ] || continue
        pbr_bypass_network_ipv4_cidr "$net"
    done | sed '/^$/d' | sort -u
}

pbr_bypass_collect_ipv6_from_networks() {
    networks_raw="$1"
    pbr_bypass_parse_networks "$networks_raw" | while IFS= read -r net; do
        [ -n "$net" ] || continue
        pbr_bypass_network_ipv6_cidrs "$net"
    done | sed '/^$/d' | sort -u
}

pbr_bypass_iif_set_name_for_iface() {
    printf '%s_pbr_bypass_iif\n' "$1"
}

pbr_bypass_v4_set_name_for_iface() {
    printf '%s_pbr_bypass4\n' "$1"
}

pbr_bypass_v6_set_name_for_iface() {
    printf '%s_pbr_bypass6\n' "$1"
}

# Emit per-iface bypass sets from PBR_BYPASS_NETWORKS (may be empty).
pbr_bypass_emit_nft_sets_for_iface() {
    iface="$1"
    networks_raw="${2:-}"
    iif_set="$(pbr_bypass_iif_set_name_for_iface "$iface")"
    v4_set="$(pbr_bypass_v4_set_name_for_iface "$iface")"
    v6_set="$(pbr_bypass_v6_set_name_for_iface "$iface")"

    iifs="$(pbr_bypass_collect_iifs_from_networks "$networks_raw")"
    v4="$(pbr_bypass_collect_ipv4_from_networks "$networks_raw")"
    v6="$(pbr_bypass_collect_ipv6_from_networks "$networks_raw")"

    echo
    echo "set $iif_set {"
    echo "    type ifname"
    echo "    comment \"xfree: PBR_BYPASS_NETWORKS ingress for $iface\""
    if [ -n "$iifs" ]; then
        echo "    elements = {"
        printf '%s\n' "$iifs" | while IFS= read -r ifn; do
            [ -n "$ifn" ] || continue
            # nft wants: "br-guest" — do not write literal backslash-quotes into the file
            printf '        "%s",\n' "$ifn"
        done | sed '$ s/,$//'
        echo "    }"
    fi
    echo "}"

    echo
    echo "set $v4_set {"
    echo "    type ipv4_addr"
    echo "    flags interval"
    echo "    auto-merge"
    echo "    comment \"xfree: PBR_BYPASS_NETWORKS IPv4 saddr for $iface\""
    if [ -n "$v4" ]; then
        echo "    elements = {"
        printf '%s\n' "$v4" | while IFS= read -r cidr; do
            [ -n "$cidr" ] || continue
            printf '        %s,\n' "$cidr"
        done | sed '$ s/,$//'
        echo "    }"
    fi
    echo "}"

    echo
    echo "set $v6_set {"
    echo "    type ipv6_addr"
    echo "    flags interval"
    echo "    auto-merge"
    echo "    comment \"xfree: PBR_BYPASS_NETWORKS IPv6 saddr for $iface\""
    if [ -n "$v6" ]; then
        echo "    elements = {"
        printf '%s\n' "$v6" | while IFS= read -r cidr; do
            [ -n "$cidr" ] || continue
            printf '        %s,\n' "$cidr"
        done | sed '$ s/,$//'
        echo "    }"
    fi
    echo "}"
}

pbr_bypass_emit_prerouting_return_for_iface() {
    iface="$1"
    iif_set="$(pbr_bypass_iif_set_name_for_iface "$iface")"
    echo "    iifname @$iif_set return comment \"xfree: PBR_BYPASS_NETWORKS skip VPN PBR ($iface)\""
}

pbr_bypass_emit_output_return_for_iface() {
    iface="$1"
    v4_set="$(pbr_bypass_v4_set_name_for_iface "$iface")"
    v6_set="$(pbr_bypass_v6_set_name_for_iface "$iface")"
    echo "    ip saddr @$v4_set return comment \"xfree: PBR_BYPASS_NETWORKS skip VPN PBR ($iface)\""
    echo "    ip6 saddr @$v6_set return comment \"xfree: PBR_BYPASS_NETWORKS skip VPN PBR ($iface)\""
}

pbr_bypass_purge_nft_sets_for_iface() {
    iface="$1"
    [ -n "$iface" ] || return 0
    if ! command -v nft >/dev/null 2>&1; then
        return 0
    fi
    if ! nft list table inet fw4 >/dev/null 2>&1; then
        return 0
    fi
    for set_name in \
        "$(pbr_bypass_iif_set_name_for_iface "$iface")" \
        "$(pbr_bypass_v4_set_name_for_iface "$iface")" \
        "$(pbr_bypass_v6_set_name_for_iface "$iface")"; do
        nft delete set inet fw4 "$set_name" 2>/dev/null || true
    done
    # Legacy global sets from zone-based bypass (one release).
    nft delete set inet fw4 xfree_pbr_bypass_iif 2>/dev/null || true
    nft delete set inet fw4 xfree_pbr_bypass4 2>/dev/null || true
    nft delete set inet fw4 xfree_pbr_bypass6 2>/dev/null || true
}
