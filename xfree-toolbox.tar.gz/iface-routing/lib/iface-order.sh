#!/bin/sh
# shellcheck shell=sh

# Shared ordering helpers for iface-routing scripts.
# Computes interface order with uplink dependencies (SELF_ROUTE_VIA):
# - dependency targets are prioritized
# - dependent interfaces are placed after their dependency when possible

iface_conf_get_value() {
    cfg="$1"
    key="$2"
    [ -f "$cfg" ] || return 0
    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$cfg"
}

iface_upstream_dep_from_conf() {
    cfg="$1"
    iface_conf_get_value "$cfg" "SELF_ROUTE_VIA"
}

iface_order_list_has_value() {
    list="$1"
    value="$2"
    [ -n "$value" ] || return 1
    printf '%s\n' "$list" | awk -v want="$value" '
        $0 == want { found=1; exit }
        END { exit found ? 0 : 1 }
    '
}

# Usage:
#   iface_build_order_by_dependency "<iface-lines>" "<dependency-resolver-fn>"
# dependency-resolver-fn receives iface name and should print dependency iface or empty string.
iface_build_order_by_dependency() {
    all_ifaces="$(printf '%s\n' "${1:-}" | sed '/^$/d')"
    resolver_fn="${2:-}"
    [ -n "$all_ifaces" ] || return 0
    [ -n "$resolver_fn" ] || {
        printf '%s\n' "$all_ifaces"
        return 0
    }

    remaining="$all_ifaces"
    ordered=""
    dep_targets=""
    iteration=0

    while IFS= read -r iface; do
        [ -n "$iface" ] || continue
        dep="$($resolver_fn "$iface" 2>/dev/null || true)"
        [ -n "${dep:-}" ] || continue
        if iface_order_list_has_value "$all_ifaces" "$dep" && ! iface_order_list_has_value "$dep_targets" "$dep"; then
            dep_targets="$(printf '%s\n%s\n' "$dep_targets" "$dep" | sed '/^$/d')"
        fi
    done <<EOF
$all_ifaces
EOF

    while [ -n "$remaining" ]; do
        iteration=$((iteration + 1))
        [ "$iteration" -le 128 ] || {
            if [ -n "${warn:-}" ]; then
                warn "Слишком много итераций при вычислении порядка интерфейсов; использую fallback"
            fi
            ordered="$(printf '%s\n%s\n' "$ordered" "$remaining" | sed '/^$/d')"
            break
        }

        progress=0
        next_remaining=""
        deferred_ready=""

        while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            dep="$($resolver_fn "$iface" 2>/dev/null || true)"

            if [ -z "${dep:-}" ] || ! iface_order_list_has_value "$all_ifaces" "$dep" || iface_order_list_has_value "$ordered" "$dep"; then
                if iface_order_list_has_value "$dep_targets" "$iface"; then
                    if ! iface_order_list_has_value "$ordered" "$iface"; then
                        ordered="$(printf '%s\n%s\n' "$ordered" "$iface" | sed '/^$/d')"
                    fi
                else
                    deferred_ready="$(printf '%s\n%s\n' "$deferred_ready" "$iface" | sed '/^$/d')"
                fi
                progress=1
            else
                next_remaining="$(printf '%s\n%s\n' "$next_remaining" "$iface" | sed '/^$/d')"
            fi
        done <<EOF
$remaining
EOF

        while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            if ! iface_order_list_has_value "$ordered" "$iface"; then
                ordered="$(printf '%s\n%s\n' "$ordered" "$iface" | sed '/^$/d')"
            fi
        done <<EOF
$deferred_ready
EOF

        if [ "$progress" -eq 0 ]; then
            if [ -n "${warn:-}" ]; then
                warn "Обнаружена циклическая/неразрешимая зависимость SELF_ROUTE_VIA; остаток будет обработан в исходном порядке"
            fi
            ordered="$(printf '%s\n%s\n' "$ordered" "$remaining" | sed '/^$/d')"
            break
        fi

        remaining="$next_remaining"
    done

    printf '%s\n' "$ordered" | sed '/^$/d'
}
