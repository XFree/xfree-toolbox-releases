#!/bin/sh
# shellcheck shell=sh
# Selective WAN6 (IPv6) guard & VPN IPv6 leak prevention for iface-routing / fw4.
# Uses shared policy contract from lib/wan6-policy.sh.

_WAN6_GUARD_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/../.." 2>/dev/null && pwd -P || printf '%s' "${ROOT_DIR:-/root/xfree-toolbox}")"
if [ -f "$_WAN6_GUARD_ROOT/lib/wan6-policy.sh" ]; then
    # shellcheck disable=SC1091
    . "$_WAN6_GUARD_ROOT/lib/wan6-policy.sh"
elif [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/lib/wan6-policy.sh" ]; then
    # shellcheck disable=SC1091
    . "$ROOT_DIR/lib/wan6-policy.sh"
fi

wan6_guard_load_policy() { wan6_policy_load "$@"; }
wan6_guard_write_policy() { wan6_policy_write "$@"; }

wan6_guard_emit_dnsmasq() {
    wan6_policy_load
    _eff_mode="$(wan6_policy_effective_mode)"
    [ "$_eff_mode" = "selective" ] || return 0

    _w6_fqdn_dir="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/wan6/fqdn.d"
    if [ -d "$_w6_fqdn_dir" ]; then
        printf '\n# Selective WAN6 allowlist (from matrix: %s)\n' "$_w6_fqdn_dir"
        _w6_has_files=0
        for _w6_f in "$_w6_fqdn_dir"/*.lst; do
            [ -f "$_w6_f" ] || continue
            _w6_has_files=1
            break
        done
        if [ "$_w6_has_files" -eq 1 ]; then
            awk '
                /^[[:space:]]*(#|$)/ { next }
                {
                    gsub(/\r/, "")
                    sub(/#.*/, "")
                    gsub(/^[[:space:]]+|[[:space:]]+$/, "")
                    if ($0 ~ /^[A-Za-z0-9._-]+$/ && !seen[$0]++) {
                        printf "nftset=/%s/6#inet#fw4#xfree_wan6_allow6\n", $0
                    }
                }
            ' "$_w6_fqdn_dir"/*.lst
        fi
        return 0
    fi

    printf '\n# Selective WAN6 allowlist (YouTube/Google direct IPv6)\n'
    for _dom in $XFREE_WAN6_ALLOW_DOMAINS; do
        _dom="$(printf '%s' "$_dom" | tr -cd 'A-Za-z0-9._-')"
        [ -n "$_dom" ] || continue
        printf 'nftset=/%s/6#inet#fw4#xfree_wan6_allow6\n' "$_dom"
    done
}

wan6_guard_purge_nft() {
    nft list table inet fw4 >/dev/null 2>&1 || return 0
    nft flush chain inet fw4 xfree_wan6_guard 2>/dev/null || true
    nft delete chain inet fw4 xfree_wan6_guard 2>/dev/null || true
    nft flush set inet fw4 xfree_wan6_allow6 2>/dev/null || true
    nft delete set inet fw4 xfree_wan6_allow6 2>/dev/null || true
}

# Emit nftables set & forward guard chain inside table inet fw4.
# $1 = newline-separated active VPN iface names
wan6_guard_emit_nft() {
    _ifaces="${1:-}"
    _eff_mode="$(wan6_policy_effective_mode)"
    [ "$_eff_mode" != "off" ] || return 0

    if [ "$_eff_mode" = "selective" ]; then
        cat <<'EOF_SET'

set xfree_wan6_allow6 {
    type ipv6_addr
    comment "xfree: selective WAN6 allowlist (populated by dnsmasq nftset)"
}
EOF_SET
    fi

    cat <<'EOF_CHAIN_HDR'

chain xfree_wan6_guard {
    type filter hook forward priority filter; policy accept;
    comment "xfree: VPN IPv6 leak guard & selective WAN6 policy"
    meta nfproto != ipv6 return
    ip6 daddr { fe80::/10, fc00::/7, ff00::/8 } return
EOF_CHAIN_HDR

    # Per-VPN IPv6 leak guard:
    # - If VPN has IPv6 (ip -6 rule routes marked traffic to $VPN_DEV), oifname == $VPN_DEV -> return (allow)
    # - If VPN is IPv4-only (or down), kernel routes marked traffic to WAN -> oifname != $VPN_DEV -> reject!
    if [ -n "$_ifaces" ]; then
        printf '%s\n' "$_ifaces" | while IFS= read -r _iface; do
            [ -n "$_iface" ] || continue
            load_work_iface_conf "$_iface"
            [ -n "${MARK_HEX:-}" ] && [ -n "${VPN_DEV:-}" ] || continue
            printf '    meta mark %s oifname != "%s" counter reject with icmpv6 type admin-prohibited comment "xfree: block IPv6 leak for VPN (%s)"\n' \
                "$MARK_HEX" "$VPN_DEV" "$_iface"
            printf '    meta mark %s oifname "%s" counter return comment "xfree: allow IPv6 inside VPN (%s)"\n' \
                "$MARK_HEX" "$VPN_DEV" "$_iface"
        done
    fi

    if [ "$_eff_mode" = "selective" ]; then
        cat <<'EOF_SEL'
    ip6 daddr @xfree_wan6_allow6 counter return comment "xfree: allow selective WAN6"
    iifname "br-*" oifname != "br-*" counter reject with icmpv6 type admin-prohibited comment "xfree: selective WAN6 reject non-allowlisted"
EOF_SEL
    fi

    printf '}\n'
}
