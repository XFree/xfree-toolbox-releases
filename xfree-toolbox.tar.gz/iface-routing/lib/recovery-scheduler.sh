#!/bin/sh
# shellcheck shell=sh
# Iface stack recovery planner on lib/task-queue.sh (macrotask recover_stack + micro reconcile).
# API reference: docs/sdk/task-queue/

RECOVERY_SCHEDULER_LIB_SOURCED="${RECOVERY_SCHEDULER_LIB_SOURCED:-}"
[ -n "$RECOVERY_SCHEDULER_LIB_SOURCED" ] && return 0
RECOVERY_SCHEDULER_LIB_SOURCED=1

_recovery_scheduler_lib_dir() {
    CDPATH= cd -- "$(dirname -- "$0")" && pwd -P
}

if [ -z "${RECOVERY_SCHEDULER_ROOT_DIR:-}" ]; then
    _rsd="$(_recovery_scheduler_lib_dir)"
    RECOVERY_SCHEDULER_ROOT_DIR="$(CDPATH= cd -- "$_rsd/.." && pwd -P)"
fi

RECOVERY_SCHEDULER_STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
RECOVERY_SCHEDULER_CONF_FILE="${RECOVERY_SCHEDULER_CONF_FILE:-$RECOVERY_SCHEDULER_STATE_ROOT/system/iface-recovery-scheduler.conf}"
RECOVERY_SCHEDULER_STATE_FILE="${RECOVERY_SCHEDULER_STATE_FILE:-$RECOVERY_SCHEDULER_STATE_ROOT/system/iface-recovery-scheduler.state}"
RECOVERY_SCHEDULER_TASK_QUEUE_FILE="${RECOVERY_SCHEDULER_TASK_QUEUE_FILE:-$RECOVERY_SCHEDULER_STATE_ROOT/system/iface-recovery-scheduler.tasks}"
RECOVERY_SCHEDULER_MICRO_QUEUE_FILE="${RECOVERY_SCHEDULER_MICRO_QUEUE_FILE:-$RECOVERY_SCHEDULER_STATE_ROOT/system/iface-recovery-scheduler.micro}"
RECOVERY_SCHEDULER_LOG_FILE="${RECOVERY_SCHEDULER_LOG_FILE:-$RECOVERY_SCHEDULER_STATE_ROOT/system/iface-recovery-scheduler.log}"

RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC="${RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC:-3}"

# Wire generic queue (legacy state filenames on router).
TASK_QUEUE_ID="${TASK_QUEUE_ID:-iface-recovery}"
TASK_QUEUE_CONF_FILE="$RECOVERY_SCHEDULER_CONF_FILE"
TASK_QUEUE_STATE_FILE="$RECOVERY_SCHEDULER_STATE_FILE"
TASK_QUEUE_TASKS_FILE="$RECOVERY_SCHEDULER_TASK_QUEUE_FILE"
TASK_QUEUE_MICRO_FILE="$RECOVERY_SCHEDULER_MICRO_QUEUE_FILE"
TASK_QUEUE_LOG_FILE="$RECOVERY_SCHEDULER_LOG_FILE"
TASK_QUEUE_LOG_TAG="${TASK_QUEUE_LOG_TAG:-xfree-iface-recovery}"
TASK_QUEUE_TEST_ACTIONS_FILE="${RECOVERY_SCHEDULER_TEST_ACTIONS_FILE:-${TASK_QUEUE_TEST_ACTIONS_FILE:-}}"

# shellcheck disable=SC1091
. "${RECOVERY_SCHEDULER_ROOT_DIR}/lib/task-queue.sh"

# Tests may set RECOVERY_SCHEDULER_TEST_NOW_EPOCH; generic tests use TASK_QUEUE_TEST_NOW_EPOCH.
task_queue_now_epoch() {
    if [ -n "${RECOVERY_SCHEDULER_TEST_NOW_EPOCH:-}" ]; then
        printf '%s' "$RECOVERY_SCHEDULER_TEST_NOW_EPOCH"
        return 0
    fi
    if [ -n "${TASK_QUEUE_TEST_NOW_EPOCH:-}" ]; then
        printf '%s' "$TASK_QUEUE_TEST_NOW_EPOCH"
        return 0
    fi
    date +%s 2>/dev/null || echo 0
}

RECOVERY_JOB_RECOVER_STACK='recover_stack'
RECOVERY_MICRO_SELF_ROUTE='self_route_reconcile'

# Aliases for callers and tests (recovery_scheduler_* → task_queue_*).
recovery_scheduler_conf_get() { task_queue_conf_get "$@"; }
recovery_scheduler_conf_kv_set() { task_queue_conf_kv_set "$@"; }
recovery_scheduler_state_get() { task_queue_state_get "$@"; }
recovery_scheduler_state_set() { task_queue_state_set "$@"; }
recovery_scheduler_state_path() { task_queue_state_path; }
recovery_scheduler_conf_path() { task_queue_conf_path; }
recovery_scheduler_sanitize_token() { task_queue_sanitize_token "$@"; }
recovery_scheduler_queue_nonempty() { task_queue_queue_nonempty "$@"; }
recovery_scheduler_task_queue_nonempty() { task_queue_tasks_nonempty; }
recovery_scheduler_micro_queue_nonempty() { task_queue_micro_nonempty; }
recovery_scheduler_any_queue_nonempty() { task_queue_any_nonempty; }
recovery_scheduler_queue_pop_head() { task_queue_pop_head "$@"; }
recovery_scheduler_queue_enqueue_coalesced() {
    task_queue_enqueue_coalesced "$1" "$2" "$3" "$4" "$5"
}
recovery_scheduler_bump_run_after() { task_queue_bump_run_after "$@"; }
recovery_scheduler_enqueue_task() { task_queue_enqueue_task "$@"; }
recovery_scheduler_enqueue_micro() { task_queue_enqueue_micro "$@"; }
recovery_scheduler_reset_schedule_meta() { task_queue_reset_schedule_meta; }
recovery_scheduler_cancel() { task_queue_cancel; }
recovery_scheduler_ready_to_digest() { task_queue_ready_to_digest "$@"; }
recovery_scheduler_queue_dump_lines() { task_queue_dump_lines "$@"; }
recovery_scheduler_digest_pass() { task_queue_digest_pass; }
recovery_scheduler_digest() { task_queue_digest "$@"; }
recovery_scheduler_finalize() { task_queue_finalize "$@"; }
recovery_scheduler_tick() { task_queue_tick "$@"; }
recovery_scheduler_test_action() { task_queue_test_action "$@"; }

recovery_scheduler_now_epoch() { task_queue_now_epoch; }

recovery_scheduler_log() {
    task_queue_hook_log "$1"
}

recovery_scheduler_conf_ensure() {
    _file="$(recovery_scheduler_conf_path)"
    mkdir -p "$(dirname -- "$_file")" 2>/dev/null || true
    [ -f "$_file" ] && return 0
    cat >"$_file" <<'EOF'
# Iface recovery planner (task-queue consumer; not auto-wired yet)
ENABLED=0
DEBOUNCE_SEC=15
MAX_DELAY_SEC=60
UPLINK_SETTLE_SEC=3
DIGEST_MAX_PASSES=4
EOF
}

recovery_scheduler_load_config() {
    task_queue_load_config
    _cf="$(recovery_scheduler_conf_path)"
    RECOVERY_SCHEDULER_ENABLED="$TASK_QUEUE_ENABLED"
    RECOVERY_SCHEDULER_DEBOUNCE_SEC="$TASK_QUEUE_DEBOUNCE_SEC"
    RECOVERY_SCHEDULER_MAX_DELAY_SEC="$TASK_QUEUE_MAX_DELAY_SEC"
    RECOVERY_SCHEDULER_DIGEST_MAX_PASSES="$TASK_QUEUE_DIGEST_MAX_PASSES"
    RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC="$(recovery_scheduler_conf_get "$_cf" UPLINK_SETTLE_SEC 3)"
    case "$RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC" in
        ''|*[!0-9]*) RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC=3 ;;
    esac
}

recovery_scheduler_status_text() {
    task_queue_status_text
    recovery_scheduler_load_config
    printf 'uplink_settle_sec=%s\n' "$RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC"
}

task_queue_hook_validate_job() {
    case "$1" in
        recover_stack) return 0 ;;
        *) return 1 ;;
    esac
}

task_queue_hook_validate_micro() {
    case "$1" in
        self_route_reconcile) return 0 ;;
        *) return 1 ;;
    esac
}

recovery_scheduler_iface_conf_get() {
    _cfg="$1"
    _key="$2"
    [ -f "$_cfg" ] || return 1
    awk -F= -v key="$_key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$_cfg"
}

recovery_scheduler_profile_ifaces() {
    _interfaces_dir="$1"
    for _d in "$_interfaces_dir"/*/config/iface.conf; do
        [ -f "$_d" ] || continue
        _dirname="$(dirname "$(dirname "$_d")")"
        basename "$_dirname"
    done | sort -u
}

recovery_scheduler_upstream_dep_from_cfg() {
    _cfg="$1"
    recovery_scheduler_iface_conf_get "$_cfg" SELF_ROUTE_VIA
}

recovery_scheduler_upstream_dep_for_iface() {
    _iface="$1"
    _cfg="${RECOVERY_SCHEDULER_INTERFACES_DIR}/$_iface/config/iface.conf"
    recovery_scheduler_upstream_dep_from_cfg "$_cfg"
}

recovery_scheduler_collect_uplinks() {
    _interfaces_dir="$1"
    for _cfg in "$_interfaces_dir"/*/config/iface.conf; do
        [ -f "$_cfg" ] || continue
        _uplink="$(recovery_scheduler_upstream_dep_from_cfg "$_cfg" || true)"
        [ -n "$_uplink" ] || continue
        case "$_uplink" in
            ''|*[!A-Za-z0-9_-]*) continue ;;
        esac
        printf '%s\n' "$_uplink"
    done | sort -u
}

recovery_scheduler_uci_iface_exists() {
    _iface="$1"
    case "$_iface" in
        ''|*[!A-Za-z0-9_-]*) return 1 ;;
    esac
    command -v uci >/dev/null 2>&1 || return 1
    uci -q get "network.${_iface}" >/dev/null 2>&1
}

recovery_scheduler_iface_is_up() {
    _iface="$1"
    case "$_iface" in
        ''|*[!A-Za-z0-9_-]*) return 1 ;;
    esac
    if command -v ubus >/dev/null 2>&1; then
        ubus call network.interface."$_iface" status 2>/dev/null | grep -q '"up": true' && return 0
    fi
    ip -4 addr show dev "$_iface" 2>/dev/null | grep -q 'inet ' && return 0
    return 1
}

recovery_scheduler_bounce_iface() {
    _iface="$1"
    _common_sh="${2:-}"

    case "$_iface" in
        ''|*[!A-Za-z0-9_-]*) return 1 ;;
    esac
    if [ "${RECOVERY_SCHEDULER_STUB_BOUNCE:-0}" = "1" ]; then
        recovery_scheduler_test_action "bounce:$_iface"
        return 0
    fi
    [ -f "$_common_sh" ] || return 1

    if recovery_scheduler_iface_is_up "$_iface"; then
        if (
            # shellcheck disable=SC1090
            . "$_common_sh"
            refresh_target interface "$_iface" bounce
        ); then
            return 0
        fi
        return 1
    fi

    recovery_scheduler_log "task recover_stack: ifup $_iface (was down)"
    if (
        # shellcheck disable=SC1090
        . "$_common_sh"
        refresh_target interface "$_iface" ifup-only
    ); then
        return 0
    fi
    return 1
}

recovery_scheduler_job_recover_stack() {
    _reason="$1"
    _root_dir="${RECOVERY_SCHEDULER_ROOT_DIR}"
    _common_sh="${RECOVERY_SCHEDULER_COMMON_SH:-$RECOVERY_SCHEDULER_ROOT_DIR/lib/common.sh}"
    _interfaces_dir="${RECOVERY_SCHEDULER_INTERFACES_DIR:-}"

    RECOVERY_SCHEDULER_INTERFACES_DIR="$_interfaces_dir"

    recovery_scheduler_log "task recover_stack: begin reason=$_reason"

    if [ "${RECOVERY_SCHEDULER_STUB_EXECUTOR:-0}" = "1" ]; then
        recovery_scheduler_test_action "job:recover_stack:$_reason"
        recovery_scheduler_enqueue_micro "$RECOVERY_MICRO_SELF_ROUTE" "after:$_reason"
        recovery_scheduler_log "task recover_stack: done (stub)"
        return 0
    fi

    [ -f "$_common_sh" ] || {
        recovery_scheduler_log "task recover_stack: common.sh not found"
        return 1
    }
    # shellcheck disable=SC1090
    . "$_common_sh"

    _order_lib="$_root_dir/iface-routing/lib/iface-order.sh"
    [ -f "$_order_lib" ] || {
        recovery_scheduler_log "task recover_stack: iface-order.sh not found"
        return 1
    }
    # shellcheck disable=SC1090
    . "$_order_lib"

    _profile_ifaces="$(recovery_scheduler_profile_ifaces "$_interfaces_dir" || true)"
    _uplinks="$(recovery_scheduler_collect_uplinks "$_interfaces_dir" || true)"

    recovery_scheduler_load_config
    case "$RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC" in
        ''|*[!0-9]*) ;;
        *)
            [ "$RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC" -gt 0 ] 2>/dev/null && sleep "$RECOVERY_SCHEDULER_UPLINK_SETTLE_SEC"
            ;;
    esac

    if [ -n "$_uplinks" ]; then
        printf '%s\n' "$_uplinks" | while IFS= read -r _uplink; do
            [ -n "$_uplink" ] || continue
            recovery_scheduler_uci_iface_exists "$_uplink" || {
                recovery_scheduler_log "task recover_stack: skip uplink $_uplink (not in UCI)"
                continue
            }
            recovery_scheduler_log "task recover_stack: bounce uplink $_uplink"
            recovery_scheduler_bounce_iface "$_uplink" "$_common_sh" || \
                recovery_scheduler_log "task recover_stack: uplink $_uplink bounce failed"
        done
    fi

    if [ -z "$_profile_ifaces" ]; then
        recovery_scheduler_log "task recover_stack: no profile interfaces"
    else
        _ordered="$(iface_build_order_by_dependency "$_profile_ifaces" recovery_scheduler_upstream_dep_for_iface)"
        printf '%s\n' "$_ordered" | while IFS= read -r _iface; do
            [ -n "$_iface" ] || continue
            recovery_scheduler_log "task recover_stack: bounce vpn $_iface"
            recovery_scheduler_bounce_iface "$_iface" "$_common_sh" || \
                recovery_scheduler_log "task recover_stack: vpn $_iface bounce failed"
        done
    fi

    recovery_scheduler_enqueue_micro "$RECOVERY_MICRO_SELF_ROUTE" "after:$_reason"
    recovery_scheduler_log "task recover_stack: done"
    return 0
}

recovery_scheduler_run_micro_self_route() {
    _reason="$1"
    _root_dir="${RECOVERY_SCHEDULER_ROOT_DIR}"
    _self_route_apply="$_root_dir/iface-routing/self-route/apply.sh"
    recovery_scheduler_log "micro self_route_reconcile: begin reason=$_reason"
    if [ "${RECOVERY_SCHEDULER_STUB_MICRO:-0}" = "1" ]; then
        recovery_scheduler_test_action "micro:self_route_reconcile:$_reason"
        recovery_scheduler_log "micro self_route_reconcile: done (stub)"
        return 0
    fi
    if [ -x "$_self_route_apply" ]; then
        "$_self_route_apply" --run-hotplug || {
            recovery_scheduler_log "micro self_route_reconcile: failed (continuing)"
            return 1
        }
    else
        recovery_scheduler_log "micro self_route_reconcile: apply.sh not executable"
        return 1
    fi
    recovery_scheduler_log "micro self_route_reconcile: done"
    return 0
}

task_queue_hook_execute_task() {
    case "$1" in
        recover_stack)
            recovery_scheduler_job_recover_stack "$2"
            ;;
        *)
            recovery_scheduler_log "task: unknown type=$1 (skip)"
            return 1
            ;;
    esac
}

task_queue_hook_execute_micro() {
    case "$1" in
        self_route_reconcile)
            recovery_scheduler_run_micro_self_route "$2"
            ;;
        *)
            recovery_scheduler_log "micro: unknown type=$1 (skip)"
            return 1
            ;;
    esac
}

schedule_recovery() {
    recovery_scheduler_enqueue_task "$RECOVERY_JOB_RECOVER_STACK" "${1:-unspecified}" "${2:-}"
}

# Map recovery-specific schedule reasons (planner contract for future wiring).
recovery_scheduler_reason_for_event() {
    _event="$1"
    _detail="${2:-}"
    case "$_event" in
        uplink_ifup)
            [ -n "$_detail" ] && printf 'uplink_ifup:%s' "$_detail" || printf '%s' 'uplink_ifup'
            ;;
        connectivity_up) printf '%s' 'connectivity_up' ;;
        modem_recovered) printf '%s' 'modem_recovered' ;;
        manual_refresh) printf '%s' 'manual_refresh' ;;
        apply_routing) printf '%s' 'apply_routing' ;;
        iface_applied)
            [ -n "$_detail" ] && printf 'iface_applied:%s' "$_detail" || printf '%s' 'iface_applied'
            ;;
        *)
            [ -n "$_detail" ] && printf '%s:%s' "$_event" "$_detail" || printf '%s' "${_event:-unspecified}"
            ;;
    esac
}

schedule_recovery_event() {
    _event="$1"
    _detail="${2:-}"
    _debounce="${3:-}"
    _reason="$(recovery_scheduler_reason_for_event "$_event" "$_detail")"
    schedule_recovery "$_reason" "$_debounce"
}

# Hotplug / внешние вызовы: uplink ifup → recover_stack (debounced).
recovery_scheduler_on_uplink_ifup() {
    _iface="${1:-}"
    [ -n "$_iface" ] || return 0
    schedule_recovery_event uplink_ifup "$_iface"
    recovery_scheduler_tick_background 0 2>/dev/null || true
}

recovery_scheduler_tick_background() {
    _force="${1:-0}"
    _root_dir="${RECOVERY_SCHEDULER_ROOT_DIR}"
    _run_sh="$_root_dir/iface-routing/recovery-scheduler/run.sh"
    _bg_runner="$_root_dir/lib/bg-task-run.sh"
    _force_arg=""

    [ -f "$_bg_runner" ] || {
        recovery_scheduler_log "tick_background: bg-task-run.sh not found"
        return 1
    }
    [ -f "$_run_sh" ] || {
        recovery_scheduler_log "tick_background: run.sh not found"
        return 1
    }
    [ "$_force" = "1" ] && _force_arg="--force"

    recovery_scheduler_log "tick_background: spawn iface-recovery-digest force=$_force"
    # shellcheck disable=SC2086
    ( sh "$_bg_runner" iface-recovery-digest -- sh "$_run_sh" digest $_force_arg ) &
    return 0
}

# Called from task_queue_digest when queue exists but debounce not elapsed.
task_queue_hook_digest_not_due() {
    _due="$1"
    case "$_due" in
        ''|*[!0-9]*) _due=15 ;;
    esac
    [ "$_due" -lt 1 ] && _due=1
    [ "$_due" -gt 300 ] && _due=300
    _root_dir="${RECOVERY_SCHEDULER_ROOT_DIR}"
    _run_sh="$_root_dir/iface-routing/recovery-scheduler/run.sh"
    _bg_runner="$_root_dir/lib/bg-task-run.sh"
    [ -f "$_bg_runner" ] && [ -f "$_run_sh" ] || return 0
    recovery_scheduler_log "digest: rearm in ${_due}s"
    (
        sleep "$_due"
        sh "$_bg_runner" iface-recovery-digest -- sh "$_run_sh" digest
    ) &
    return 0
}

recovery_scheduler_schedule_and_tick_background() {
    _reason="${1:-unspecified}"
    _debounce="${2:-}"
    _force="${3:-0}"
    schedule_recovery "$_reason" "$_debounce"
    recovery_scheduler_tick_background "$_force"
}

recovery_scheduler_validate_job_type() {
    task_queue_hook_validate_job "$1"
}

recovery_scheduler_validate_micro_type() {
    task_queue_hook_validate_micro "$1"
}

recovery_scheduler_execute_task_line() {
    _line="$1"
    task_queue_execute_task_line "$_line"
}

recovery_scheduler_execute_micro_line() {
    _line="$1"
    task_queue_execute_micro_line "$_line"
}
