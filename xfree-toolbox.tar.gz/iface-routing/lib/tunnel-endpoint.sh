#!/bin/sh
# shellcheck shell=sh
# Эндпоинт конкретного туннеля для nft-исключения транспорта.
# Явные ENDPOINT_HOST / ENDPOINT_PORT / ENDPOINT_PROTO не перезаписываются:
# их задаёт iface.conf или разбор source.ovpn. Пустые поля берутся из
# source.conf.meta этого же интерфейса (его пишет генератор warp/proton/awg).

tunnel_endpoint_meta_value() {
    _te_file="$1"
    _te_key="$2"
    [ -f "$_te_file" ] || return 0
    awk -F= -v key="$_te_key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$_te_file"
}

tunnel_endpoint_fill_from_meta() {
    _te_meta="$1"
    [ -n "$_te_meta" ] && [ -f "$_te_meta" ] || return 0

    if [ -z "${ENDPOINT_HOST:-}" ]; then
        ENDPOINT_HOST="$(tunnel_endpoint_meta_value "$_te_meta" "ENDPOINT_HOST" || true)"
        ENDPOINT_HOST="$(printf '%s' "${ENDPOINT_HOST:-}" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
    fi
    if [ -z "${ENDPOINT_PORT:-}" ]; then
        ENDPOINT_PORT="$(tunnel_endpoint_meta_value "$_te_meta" "ENDPOINT_PORT" || true)"
        ENDPOINT_PORT="$(printf '%s' "${ENDPOINT_PORT:-}" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
    fi
    if [ -z "${ENDPOINT_PROTO:-}" ]; then
        ENDPOINT_PROTO="$(tunnel_endpoint_meta_value "$_te_meta" "ENDPOINT_PROTO" || true)"
        ENDPOINT_PROTO="$(printf '%s' "${ENDPOINT_PROTO:-}" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
    fi

    # Генератор всегда пишет и ENDPOINT='host:port', и разделённые поля.
    # Разделённых может не быть у старого meta.
    if [ -z "${ENDPOINT_HOST:-}" ] || [ -z "${ENDPOINT_PORT:-}" ]; then
        _te_full="$(tunnel_endpoint_meta_value "$_te_meta" "ENDPOINT" || true)"
        _te_full="$(printf '%s' "${_te_full:-}" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
        case "$_te_full" in
            *:*)
                _te_host="${_te_full%:*}"
                _te_port="${_te_full##*:}"
                case "$_te_port" in
                    ''|*[!0-9]*) ;;
                    *)
                        [ -n "${ENDPOINT_HOST:-}" ] || ENDPOINT_HOST="$_te_host"
                        [ -n "${ENDPOINT_PORT:-}" ] || ENDPOINT_PORT="$_te_port"
                        ;;
                esac
                ;;
        esac
    fi

    case "${ENDPOINT_PORT:-}" in
        ''|*[!0-9]*) ENDPOINT_PORT="" ;;
        *)
            if [ "$ENDPOINT_PORT" -lt 1 ] || [ "$ENDPOINT_PORT" -gt 65535 ]; then
                ENDPOINT_PORT=""
            fi
            ;;
    esac

    case "${ENDPOINT_PROTO:-}" in
        udp|tcp) ;;
        *) ENDPOINT_PROTO="" ;;
    esac
}
