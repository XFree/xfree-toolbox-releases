# shellcheck shell=sh
# Idempotent IPv4/IPv6 policy-routing helpers for apply-routing and iface hotplug.
#
# `ip route replace default` / `ip rule add` return EEXIST ("RTNETLINK answers:
# File exists") when:
# - hotplug ifup already installed the same default/rule while apply-routing
#   re-applies after wait-for-IPv4;
# - a leftover default with a different nexthop/metric occupies the table.
# apply-routing runs under set -eu, so that used to abort the whole apply.

POLICY_ROUTING_LOCK="${POLICY_ROUTING_LOCK:-/var/lock/xfree-toolbox-policy-routing.lock}"

policy_rtnetlink_is_exists() {
    case "$1" in
        *'File exists'*) return 0 ;;
        *) return 1 ;;
    esac
}

# Target: OpenWrt 25 (BusyBox flock, no -w). Fallback: OpenWrt 24.x, same BusyBox.
# util-linux flock (host/CI) has -w timeout; probe and use it when present:
#   BusyBox: flock [-sxun] FD | { FILE [-c] PROG ARGS }
policy_flock_supports_timeout() {
    case "${POLICY_ROUTING_FLOCK_HAS_W:-}" in
        1) return 0 ;;
        0) return 1 ;;
    esac
    _probe="${TMPDIR:-/tmp}/xfree-policy-flock-probe.$$"
    if (flock -w 0 8) 8>"$_probe" 2>/dev/null; then
        POLICY_ROUTING_FLOCK_HAS_W=1
        rm -f "$_probe"
        return 0
    fi
    POLICY_ROUTING_FLOCK_HAS_W=0
    rm -f "$_probe"
    return 1
}

policy_with_lock() {
    if [ "${POLICY_ROUTING_SKIP_LOCK:-0}" = "1" ]; then
        "$@"
        return $?
    fi
    if ! command -v flock >/dev/null 2>&1; then
        "$@"
        return $?
    fi
    lock_dir="$(dirname "$POLICY_ROUTING_LOCK")"
    mkdir -p "$lock_dir" 2>/dev/null || true
    if policy_flock_supports_timeout; then
        (
            flock -w 30 9 || true
            "$@"
        ) 9>"$POLICY_ROUTING_LOCK"
        return $?
    fi
    (
        flock 9 || true
        "$@"
    ) 9>"$POLICY_ROUTING_LOCK"
}

policy_flush_default4() {
    table="$1"
    while ip route del default table "$table" 2>/dev/null; do :; done
    while ip route del 0.0.0.0/0 table "$table" 2>/dev/null; do :; done
}

policy_flush_default6() {
    table="$1"
    while ip -6 route del default table "$table" 2>/dev/null; do :; done
    while ip -6 route del ::/0 table "$table" 2>/dev/null; do :; done
}

policy_flush_rule4() {
    mark_hex="$1"
    table="$2"
    pref="$3"
    while ip rule del lookup "$table" pref "$pref" 2>/dev/null; do :; done
    while ip rule del fwmark "$mark_hex" lookup "$table" 2>/dev/null; do :; done
    while ip rule del lookup "$table" 2>/dev/null; do :; done
}

policy_flush_rule6() {
    mark_hex="$1"
    table="$2"
    pref="$3"
    while ip -6 rule del lookup "$table" pref "$pref" 2>/dev/null; do :; done
    while ip -6 rule del fwmark "$mark_hex" lookup "$table" 2>/dev/null; do :; done
    while ip -6 rule del lookup "$table" 2>/dev/null; do :; done
}

policy_default_is_ours4() {
    table="$1"
    vpn_dev="$2"
    ip route show table "$table" 2>/dev/null | grep '^default ' | grep -q "dev $vpn_dev"
}

policy_default_is_ours6() {
    table="$1"
    vpn_dev="$2"
    ip -6 route show table "$table" 2>/dev/null | grep '^default ' | grep -q "dev $vpn_dev"
}

policy_rule_is_ours4() {
    mark_hex="$1"
    table="$2"
    pref="$3"
    ip rule show 2>/dev/null | grep -E "^${pref}:" | grep -F "fwmark $mark_hex" | grep -q "$table"
}

policy_rule_is_ours6() {
    mark_hex="$1"
    table="$2"
    pref="$3"
    ip -6 rule show 2>/dev/null | grep -E "^${pref}:" | grep -F "fwmark $mark_hex" | grep -q "$table"
}

policy_ensure_default4() {
    vpn_dev="$1"
    table="$2"
    n=0
    while [ "$n" -lt 5 ]; do
        n=$((n + 1))
        policy_flush_default4 "$table"
        err="$(ip route add default dev "$vpn_dev" table "$table" 2>&1)" && return 0
        if ! policy_rtnetlink_is_exists "$err"; then
            printf '%s\n' "$err" >&2
            return 1
        fi
        if policy_default_is_ours4 "$table" "$vpn_dev"; then
            return 0
        fi
    done
    printf '%s\n' "Не удалось установить default dev $vpn_dev table $table (File exists)" >&2
    return 1
}

policy_ensure_default6() {
    vpn_dev="$1"
    table="$2"
    n=0
    while [ "$n" -lt 5 ]; do
        n=$((n + 1))
        policy_flush_default6 "$table"
        err="$(ip -6 route add default dev "$vpn_dev" table "$table" 2>&1)" && return 0
        if ! policy_rtnetlink_is_exists "$err"; then
            printf '%s\n' "$err" >&2
            return 1
        fi
        if policy_default_is_ours6 "$table" "$vpn_dev"; then
            return 0
        fi
    done
    printf '%s\n' "Не удалось установить IPv6 default dev $vpn_dev table $table (File exists)" >&2
    return 1
}

policy_ensure_rule4() {
    mark_hex="$1"
    table="$2"
    pref="$3"
    n=0
    while [ "$n" -lt 5 ]; do
        n=$((n + 1))
        policy_flush_rule4 "$mark_hex" "$table" "$pref"
        err="$(ip rule add fwmark "$mark_hex" lookup "$table" pref "$pref" 2>&1)" && return 0
        if ! policy_rtnetlink_is_exists "$err"; then
            printf '%s\n' "$err" >&2
            return 1
        fi
        if policy_rule_is_ours4 "$mark_hex" "$table" "$pref"; then
            return 0
        fi
    done
    printf '%s\n' "Не удалось добавить ip rule fwmark $mark_hex lookup $table pref $pref (File exists)" >&2
    return 1
}

policy_ensure_rule6() {
    mark_hex="$1"
    table="$2"
    pref="$3"
    n=0
    while [ "$n" -lt 5 ]; do
        n=$((n + 1))
        policy_flush_rule6 "$mark_hex" "$table" "$pref"
        err="$(ip -6 rule add fwmark "$mark_hex" lookup "$table" pref "$pref" 2>&1)" && return 0
        if ! policy_rtnetlink_is_exists "$err"; then
            printf '%s\n' "$err" >&2
            return 1
        fi
        if policy_rule_is_ours6 "$mark_hex" "$table" "$pref"; then
            return 0
        fi
    done
    printf '%s\n' "Не удалось добавить ip -6 rule fwmark $mark_hex lookup $table pref $pref (File exists)" >&2
    return 1
}

policy_apply_iface4_unlocked() {
    vpn_dev="$1"
    mark_hex="$2"
    table="$3"
    pref="$4"
    policy_ensure_default4 "$vpn_dev" "$table"
    policy_ensure_rule4 "$mark_hex" "$table" "$pref"
}

policy_apply_iface6_unlocked() {
    vpn_dev="$1"
    mark_hex="$2"
    table="$3"
    pref="$4"
    policy_ensure_default6 "$vpn_dev" "$table"
    policy_ensure_rule6 "$mark_hex" "$table" "$pref"
}

policy_apply_iface4() {
    policy_with_lock policy_apply_iface4_unlocked "$@"
}

policy_apply_iface6() {
    policy_with_lock policy_apply_iface6_unlocked "$@"
}
