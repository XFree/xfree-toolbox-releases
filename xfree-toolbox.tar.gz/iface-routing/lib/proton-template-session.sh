#!/bin/sh
# shellcheck shell=sh
# Разрешение Proton session bundle для template restore (prepare / regenerate).

# Values from lib/template-layout-scrub-lib.sh — not real endpoint overrides.
is_template_meta_token() {
    case "$1" in
        ''|'***RECREATE***'|'***GENERATE***'|'***PROMPT***') return 0 ;;
        *) return 1 ;;
    esac
}

# Guest identity: SESSION_AUTH_MODE=guest or SESSION_NAME=guest-*.
# Restore/renew then mints a new credentialless session (WARP-style), no leftover tokens required.
proton_restore_is_guest_identity() {
    _mode="$(printf '%s' "${1:-}" | tr 'A-Z' 'a-z' | tr -d '\r')"
    _name="${2:-}"
    [ "$_mode" = "guest" ] && return 0
    case "$_name" in
        guest-*) return 0 ;;
    esac
    return 1
}

# Restore/prepare: mint guest (--acquire-guest) when identity is guest, leftover
# guest tokens exist, or there is no resolved web session. Manual .conf paste is
# opt-in (prepare --proton-manual-import / PROTON_MANUAL_CONF_FILE).
proton_restore_should_acquire_guest() {
    _mode="${1:-}"
    _name="${2:-}"
    _root="${3:-}"
    _slug="${4:-}"
    proton_restore_is_guest_identity "$_mode" "$_name" && return 0
    if [ -z "$_mode" ] && [ -n "$_slug" ] && [ -n "$_root" ] && \
        [ -f "$_root/$_slug/access_token.txt" ]; then
        return 0
    fi
    [ -z "$_slug" ] || [ -z "$_root" ]
}

proton_profile_session_ref() {
    profile_sessions_dir="$1"
    session_name_value="$2"
    session_dir_value="$3"

    [ -d "$profile_sessions_dir" ] || return 1

    for candidate in \
        "$session_name_value" \
        "$(basename -- "${session_dir_value:-}")" \
        "$(basename -- "${session_name_value:-}")"
    do
        [ -n "${candidate:-}" ] || continue
        [ "$candidate" = "." ] && continue
        [ "$candidate" = "/" ] && continue
        is_template_meta_token "$candidate" && continue
        if [ -d "$profile_sessions_dir/$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

proton_pick_latest_session_bundle() {
    sessions_root="$1"
    best="" best_mtime=0

    [ -d "$sessions_root" ] || return 1

    for d in "$sessions_root"/*; do
        [ -d "$d" ] || continue
        [ -f "$d/cookies.txt" ] || continue
        [ -f "$d/x_pm_uid.txt" ] || continue
        if [ -f "$d/state.json" ]; then
            m="$(stat -c '%Y' "$d/state.json" 2>/dev/null || stat -f '%m' "$d/state.json" 2>/dev/null || echo 0)"
        else
            m="$(stat -c '%Y' "$d/cookies.txt" 2>/dev/null || stat -f '%m' "$d/cookies.txt" 2>/dev/null || echo 0)"
        fi
        case "$m" in
            ''|*[!0-9]*) m=0 ;;
        esac
        if [ "$m" -ge "$best_mtime" ]; then
            best_mtime="$m"
            best="$(basename -- "$d")"
        fi
    done

    [ -n "$best" ] || return 1
    printf '%s\n' "$best"
}

# stdout: line1=sessions_root line2=session_slug; exit 0 if resolved
proton_resolve_session_for_template_restore() {
    profile_sessions_dir="$1"
    operator_sessions_dir="${2:-}"
    session_name_value="${3:-}"
    session_dir_value="${4:-}"

    resolved_root=""
    resolved_slug=""

    profile_ref="$(proton_profile_session_ref "$profile_sessions_dir" "$session_name_value" "$session_dir_value" 2>/dev/null)" || profile_ref=""
    if [ -n "$profile_ref" ]; then
        resolved_root="$profile_sessions_dir"
        resolved_slug="$profile_ref"
        printf '%s\n' "$resolved_root"
        printf '%s\n' "$resolved_slug"
        return 0
    fi

    if [ -n "$operator_sessions_dir" ] && [ -d "$operator_sessions_dir" ]; then
        op_ref="$(proton_profile_session_ref "$operator_sessions_dir" "$session_name_value" "$session_dir_value" 2>/dev/null)" || op_ref=""
        if [ -n "$op_ref" ]; then
            resolved_root="$operator_sessions_dir"
            resolved_slug="$op_ref"
            printf '%s\n' "$resolved_root"
            printf '%s\n' "$resolved_slug"
            return 0
        fi
        latest_ref="$(proton_pick_latest_session_bundle "$operator_sessions_dir" 2>/dev/null)" || latest_ref=""
        if [ -n "$latest_ref" ]; then
            resolved_root="$operator_sessions_dir"
            resolved_slug="$latest_ref"
            printf '%s\n' "$resolved_root"
            printf '%s\n' "$resolved_slug"
            return 0
        fi
    fi

    if [ -n "${session_dir_value:-}" ] && [ -d "$session_dir_value" ]; then
        printf '%s\n' "$(dirname -- "$session_dir_value")"
        printf '%s\n' "$(basename -- "$session_dir_value")"
        return 0
    fi

    return 1
}
