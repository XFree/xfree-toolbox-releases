#!/bin/sh
# shellcheck shell=sh
# Автоматическое добавление обязательных инфраструктурных исключений (xft, proton) для туннелей.

iface_seed_default_excludes() {
    _iface_dir="$1"
    _root_dir="${2:-${ROOT_DIR:-}}"
    [ -n "$_iface_dir" ] && [ -n "$_root_dir" ] || return 0
    _ex_dir="$_iface_dir/fqdn.exclude.d"
    mkdir -p "$_ex_dir"

    if [ ! -f "$_ex_dir/user__group__xft.lst" ] && [ -f "$_root_dir/upstreams/user/upstream/xft/fqdn-xft.lst" ]; then
        cp -f "$_root_dir/upstreams/user/upstream/xft/fqdn-xft.lst" "$_ex_dir/user__group__xft.lst"
    fi
    if [ ! -f "$_ex_dir/user__service__vpn__proton__fqdn.lst" ] && [ -f "$_root_dir/upstreams/user/upstream/vpn/proton/fqdn-proton.lst" ]; then
        cp -f "$_root_dir/upstreams/user/upstream/vpn/proton/fqdn-proton.lst" "$_ex_dir/user__service__vpn__proton__fqdn.lst"
    fi
}
