#!/bin/sh
# shellcheck shell=sh
# Port failover and adaptive rotation for VPN interfaces under DPI / ТСПУ.
# Supported protocols:
#   - warp: Cloudflare WARP multi-port pool
#   - proton: Proton VPN multi-port pool

IFACE_PORT_FAILOVER_LIB_SOURCED="${IFACE_PORT_FAILOVER_LIB_SOURCED:-}"
[ -n "$IFACE_PORT_FAILOVER_LIB_SOURCED" ] && return 0
IFACE_PORT_FAILOVER_LIB_SOURCED=1

# Priority port pool for WARP (most resilient ports in RU DPI first)
IFACE_PORT_WARP_POOL="${IFACE_PORT_WARP_POOL:-2408 8319 4500 500 946 864 854 859 878 880 890 894 908 928 934 1070 1180 1387 1701 1843 2371 2506 3138 3476 3581 3854 4177 4198 4233 5279 5956 7103 7152 7156 7281 7559 8742 8854 8886}"

# Priority port pool for Proton VPN (standard supported wireguard ports)
IFACE_PORT_PROTON_POOL="${IFACE_PORT_PROTON_POOL:-51820 443 500 4500 1194 5060}"

iface_port_get_kind() {
    _iface="$1"
    if command -v iface_get_kind >/dev/null 2>&1; then
        iface_get_kind "$_iface"
        return $?
    fi
    case "$_iface" in
        warp*|*warp*) printf 'warp\n'; return 0 ;;
        proton*|*proton*) printf 'proton\n'; return 0 ;;
    esac
    printf 'unknown\n'
    return 1
}

iface_port_failover_supported() {
    _iface="$1"
    _kind="$(iface_port_get_kind "$_iface" 2>/dev/null || true)"
    case "$_kind" in
        warp|proton) return 0 ;;
    esac
    return 1
}

iface_port_get_candidates() {
    _iface="$1"
    _kind="$(iface_port_get_kind "$_iface" 2>/dev/null || true)"
    case "$_kind" in
        warp) printf '%s\n' "$IFACE_PORT_WARP_POOL" ;;
        proton) printf '%s\n' "$IFACE_PORT_PROTON_POOL" ;;
        *) return 1 ;;
    esac
}

iface_port_get_current() {
    _iface="$1"
    _port=""
    # 1. From UCI
    if command -v uci >/dev/null 2>&1; then
        _port="$(uci -q get "network.@amneziawg_${_iface}[0].endpoint_port" 2>/dev/null || true)"
        [ -n "$_port" ] || _port="$(uci -q get "network.${_iface}.endpoint_port" 2>/dev/null || true)"
    fi
    # 2. From iface.conf
    if [ -z "$_port" ]; then
        _prof_dir="${PROFILE_DIR:-}"
        if [ -z "$_prof_dir" ] && command -v common_profile_dir >/dev/null 2>&1; then
            _prof_dir="$(common_profile_dir 2>/dev/null || true)"
        fi
        for _d in \
            ${_prof_dir:+"$_prof_dir/iface-routing/interfaces/$_iface"} \
            "/etc/xfree-toolbox/iface-routing/interfaces/$_iface"; do
            [ -n "$_d" ] || continue
            if [ -f "$_d/config/iface.conf" ]; then
                _port="$(sed -n "s/^ENDPOINT_PORT='\\(.*\\)'\$/\\1/p" "$_d/config/iface.conf" 2>/dev/null || true)"
                [ -n "$_port" ] && break
            fi
            if [ -f "$_d/config/source.conf" ]; then
                _port="$(sed -n "s/^Endpoint[[:space:]]*=[[:space:]]*.*:\([0-9]\+\)[[:space:]]*\$/\1/p" "$_d/config/source.conf" 2>/dev/null || true)"
                [ -n "$_port" ] && break
            fi
        done
    fi
    # 3. From kernel endpoint
    if [ -z "$_port" ]; then
        _tool="awg"
        command -v awg >/dev/null 2>&1 || _tool="wg"
        if command -v "$_tool" >/dev/null 2>&1; then
            _ep="$("$_tool" show "$_iface" endpoints 2>/dev/null | awk 'NF>=2 { print $2; exit }')"
            _port="${_ep##*:}"
        fi
    fi
    printf '%s\n' "${_port:-unknown}"
}

iface_port_get_next() {
    _iface="$1"
    _cur="$(iface_port_get_current "$_iface")"
    _candidates="$(iface_port_get_candidates "$_iface" 2>/dev/null || true)"
    [ -n "$_candidates" ] || return 1

    _next=""
    _found_cur=0
    _first=""
    for _p in $_candidates; do
        [ -z "$_first" ] && [ "$_p" != "$_cur" ] && _first="$_p"
        if [ "$_found_cur" = "1" ] && [ "$_p" != "$_cur" ]; then
            _next="$_p"
            break
        fi
        if [ "$_p" = "$_cur" ]; then
            _found_cur=1
        fi
    done
    [ -n "$_next" ] || _next="$_first"
    [ -n "$_next" ] || return 1
    printf '%s\n' "$_next"
}

iface_port_apply_kernel() {
    _iface="$1"
    _new_port="$2"
    _dev="${3:-$_iface}"

    _tool="awg"
    command -v awg >/dev/null 2>&1 || _tool="wg"
    command -v "$_tool" >/dev/null 2>&1 || return 1
    ip link show "$_dev" >/dev/null 2>&1 || return 1

    _pk="$("$_tool" show "$_dev" peers 2>/dev/null | head -n 1)"
    [ -n "$_pk" ] || return 1
    _ep="$("$_tool" show "$_dev" endpoints 2>/dev/null | awk -v pk="$_pk" '$1==pk{print $2}')"
    [ -n "$_ep" ] || return 1
    _host="${_ep%:*}"
    [ -n "$_host" ] || return 1

    "$_tool" set "$_dev" peer "$_pk" endpoint "${_host}:${_new_port}" 2>/dev/null
}

iface_port_materialize() {
    _iface="$1"
    _new_port="$2"

    # 1. Update UCI
    if command -v uci >/dev/null 2>&1; then
        if uci -q get "network.@amneziawg_${_iface}[0]" >/dev/null 2>&1; then
            uci set "network.@amneziawg_${_iface}[0].endpoint_port=${_new_port}" 2>/dev/null || true
            uci commit network 2>/dev/null || true
        elif uci -q get "network.${_iface}" >/dev/null 2>&1; then
            uci set "network.${_iface}.endpoint_port=${_new_port}" 2>/dev/null || true
            uci commit network 2>/dev/null || true
        fi
    fi

    # 2. Update profile configs
    _prof_dir="${PROFILE_DIR:-}"
    if [ -z "$_prof_dir" ] && command -v common_profile_dir >/dev/null 2>&1; then
        _prof_dir="$(common_profile_dir 2>/dev/null || true)"
    fi
    for _base in \
        ${_prof_dir:+"$_prof_dir/iface-routing/interfaces/$_iface"} \
        "/etc/xfree-toolbox/iface-routing/interfaces/$_iface"; do
        [ -n "$_base" ] || continue
        [ -d "$_base/config" ] || continue
        # iface.conf
        _cfg="$_base/config/iface.conf"
        if [ -f "$_cfg" ]; then
            if grep -q '^ENDPOINT_PORT=' "$_cfg" 2>/dev/null; then
                sed -i "s/^ENDPOINT_PORT=.*/ENDPOINT_PORT='${_new_port}'/" "$_cfg" 2>/dev/null || true
            else
                printf "ENDPOINT_PORT='%s'\n" "$_new_port" >> "$_cfg"
            fi
        fi
        # source.conf
        _src="$_base/config/source.conf"
        if [ -f "$_src" ]; then
            sed -i -E "s/^(Endpoint[[:space:]]*=[[:space:]]*[^:]+):[0-9]+/\1:${_new_port}/" "$_src" 2>/dev/null || true
        fi
        # source.conf.meta
        _meta="$_base/config/source.conf.meta"
        if [ -f "$_meta" ]; then
            if grep -q '^ENDPOINT_PORT=' "$_meta" 2>/dev/null; then
                sed -i "s/^ENDPOINT_PORT=.*/ENDPOINT_PORT='${_new_port}'/" "$_meta" 2>/dev/null || true
            else
                printf "ENDPOINT_PORT='%s'\n" "$_new_port" >> "$_meta"
            fi
        fi
        # network.uci
        _nuci="$_base/config/network.uci"
        if [ -f "$_nuci" ]; then
            sed -i -E "s/option endpoint_port '[0-9]+'/option endpoint_port '${_new_port}'/" "$_nuci" 2>/dev/null || true
        fi
    done
}

iface_port_test_data() {
    _dev="$1"
    _port="${2:-}"
    command -v curl >/dev/null 2>&1 || return 1
    _url="${USB_WATCH_TUNNEL_HTTP_URL:-http://connectivitycheck.gstatic.com/generate_204}"
    if curl -fs --connect-timeout 2 -m 3 -o /dev/null --interface "$_dev" "$_url" >/dev/null 2>&1; then
        if command -v vpn_handshake_status >/dev/null 2>&1; then
            case "$(vpn_handshake_status "$_dev" 2>/dev/null | sed -n '1p' || true)" in
                none|down) return 1 ;;
            esac
        fi
        return 0
    fi
    # Если после первой попытки handshake не прошёл — не тратим время на запасной URL.
    if command -v vpn_handshake_status >/dev/null 2>&1; then
        case "$(vpn_handshake_status "$_dev" 2>/dev/null | sed -n '1p' || true)" in
            none|down) return 1 ;;
        esac
    fi
    _url_alt="${USB_WATCH_TUNNEL_HTTP_URL_ALT:-http://cp.cloudflare.com/generate_204}"
    if curl -fs --connect-timeout 2 -m 3 -o /dev/null --interface "$_dev" "$_url_alt" >/dev/null 2>&1; then
        if command -v vpn_handshake_status >/dev/null 2>&1; then
            case "$(vpn_handshake_status "$_dev" 2>/dev/null | sed -n '1p' || true)" in
                none|down) return 1 ;;
            esac
        fi
        return 0
    fi
    return 1
}

iface_port_cursor_key() {
    _tok="$(printf '%s' "${1:-}" | tr -c 'A-Za-z0-9_' '_')"
    printf 'TUNNEL_PORT_CURSOR_%s' "$_tok"
}

iface_port_rotate_try() {
    _iface="$1"
    _dev="${2:-$_iface}"

    iface_port_failover_supported "$_iface" || return 1
    _cur="$(iface_port_get_current "$_iface")"
    _orig_port="$_cur"
    _candidates="$(iface_port_get_candidates "$_iface" 2>/dev/null || true)"
    [ -n "$_candidates" ] || return 1

    _settle="${IFACE_PORT_FAILOVER_SETTLE_SEC:-2}"
    _max_attempts="${IFACE_PORT_FAILOVER_ATTEMPTS:-5}"

    _cursor_key="$(iface_port_cursor_key "$_iface")"
    _target_port="$_cur"
    if command -v usb_watch_state_get >/dev/null 2>&1; then
        _saved_cursor="$(usb_watch_state_get "$_cursor_key" "" 2>/dev/null || true)"
        [ -n "$_saved_cursor" ] && _target_port="$_saved_cursor"
    fi

    _tried=0
    while [ "$_tried" -lt "$_max_attempts" ]; do
        _next=""
        _found=0
        _first=""
        for _p in $_candidates; do
            [ -z "$_first" ] && [ "$_p" != "$_cur" ] && _first="$_p"
            if [ "$_found" = "1" ] && [ "$_p" != "$_cur" ]; then
                _next="$_p"
                break
            fi
            [ "$_p" = "$_target_port" ] && _found=1
        done
        [ -n "$_next" ] || _next="$_first"
        [ -n "$_next" ] && [ "$_next" != "$_cur" ] || break

        _target_port="$_next"
        _tried=$((_tried + 1))
        if command -v usb_watch_state_set >/dev/null 2>&1; then
            usb_watch_state_set "$_cursor_key" "$_next" 2>/dev/null || true
        fi

        iface_port_apply_kernel "$_iface" "$_next" "$_dev" || true
        if ! ip link show "$_dev" >/dev/null 2>&1; then
            if command -v ifup >/dev/null 2>&1; then
                ifup "$_iface" >/dev/null 2>&1 || true
            fi
        fi
        [ "$_settle" -gt 0 ] 2>/dev/null && sleep "$_settle"

        if iface_port_test_data "$_dev" "$_next"; then
            iface_port_materialize "$_iface" "$_next"
            if command -v usb_watch_state_set >/dev/null 2>&1; then
                usb_watch_state_set "$_cursor_key" "" 2>/dev/null || true
            fi
            printf '%s\n' "$_next"
            return 0
        fi
    done

    # Все попытки не удались — откатываем порт в ядре к исходному, но сохраняем курсор для следующего цикла.
    case "$_orig_port" in
        ''|unknown|*[!0-9]*) ;;
        *) iface_port_apply_kernel "$_iface" "$_orig_port" "$_dev" || true ;;
    esac
    return 1
}
