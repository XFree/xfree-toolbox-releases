#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
TB=/root/xfree-toolbox
P="$TB/profiles/default/zapret"
S=/etc/xfree-toolbox/zapret
echo '=== applied-profile / active ==='
cat /etc/xfree-toolbox/applied-profile.env 2>/dev/null || true
cat /etc/xfree-toolbox/active-profile 2>/dev/null || true
echo '=== profile sections.order (head/tail) ==='
wc -l "$P/sections.order" 2>/dev/null || echo 'no order'
head -5 "$P/sections.order" 2>/dev/null || true
tail -5 "$P/sections.order" 2>/dev/null || true
echo '=== profile section count / with conf / with fqdn ==='
n=0; nc=0; nf=0
for d in "$P/sections"/*; do
  [ -d "$d" ] || continue
  n=$((n+1))
  [ -f "$d/config/section.conf" ] && nc=$((nc+1))
  ls "$d/fqdn.d"/*.lst >/dev/null 2>&1 && nf=$((nf+1))
done
echo "profile_sections=$n with_conf=$nc with_fqdn_lst=$nf"
echo '=== state section count / with conf / with fqdn ==='
n=0; nc=0; nf=0
for d in "$S/state/sections"/*; do
  [ -d "$d" ] || continue
  n=$((n+1))
  [ -f "$d/config/section.conf" ] && nc=$((nc+1))
  ls "$d/fqdn.d"/*.lst >/dev/null 2>&1 && nf=$((nf+1))
done
echo "state_sections=$n with_conf=$nc with_fqdn_lst=$nf"
echo '=== profile youtube_29 ==='
cat "$P/sections/youtube_29/config/section.conf" 2>&1 || true
ls -la "$P/sections/youtube_29/fqdn.d" 2>&1 | head
wc -l "$P/sections/youtube_29/fqdn.d"/*.lst 2>/dev/null || true
echo '=== state youtube_29 ==='
ls -la "$S/state/sections/youtube_29" "$S/state/sections/youtube_29/config" "$S/state/sections/youtube_29/fqdn.d" 2>&1 | head -30
echo '=== generated block / template ==='
ls -la "$S/generated" 2>&1 | head -20
ls -la "$P" 2>&1 | head -30
echo '=== zapret.template / engine ==='
ls -la "$P/zapret" "$P/zapret.template" "$P/engine.conf" 2>&1 || true
head -5 "$P/engine.conf" 2>/dev/null || true
echo '=== /etc/config/zapret ==='
cat /etc/config/zapret
echo '=== recent zapret logs ==='
ls -lt /tmp/zapret* /var/log/zapret* "$S"/*.log 2>/dev/null | head -20 || true
ls -lt /etc/xfree-toolbox/system/*.log 2>/dev/null | head -10 || true
echo '=== last apply-ish logs grep ==='
grep -iE 'zapret|NFQWS|hostlist|section' /etc/xfree-toolbox/system/*.log 2>/dev/null | tail -40 || true
echo '=== menu/apply last ==='
ls -lt "$TB/zapret"/*.log 2>/dev/null | head || true
# try find sync marker
find "$S" -name '*.sig' -o -name '*apply*' -o -name '*.log' 2>/dev/null | head -40
REMOTE
