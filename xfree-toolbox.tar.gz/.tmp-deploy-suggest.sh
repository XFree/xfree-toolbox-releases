#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
BASE=build/openwrt/luci-app-xfree-toolbox/htdocs/luci-static/resources
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/xfree-dashboard.css" \
  "$SSH_TARGET:/www/luci-static/resources/xfree-toolbox/xfree-dashboard.css"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/traffic-map.js" \
  "$SSH_TARGET:/www/luci-static/resources/xfree-toolbox/traffic-map.js"
scp "${SCP_OPTS[@]}" \
  "$BASE/view/xfree-toolbox/shell.js" \
  "$SSH_TARGET:/www/luci-static/resources/view/xfree-toolbox/shell.js"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
chmod 644 \
  /www/luci-static/resources/xfree-toolbox/xfree-dashboard.css \
  /www/luci-static/resources/xfree-toolbox/traffic-map.js \
  /www/luci-static/resources/view/xfree-toolbox/shell.js
grep -n "v=20261004i\|display: block\|flex: 0 0 auto\|plain div" \
  /www/luci-static/resources/view/xfree-toolbox/shell.js \
  /www/luci-static/resources/xfree-toolbox/xfree-dashboard.css \
  /www/luci-static/resources/xfree-toolbox/traffic-map.js | head -30
REMOTE
