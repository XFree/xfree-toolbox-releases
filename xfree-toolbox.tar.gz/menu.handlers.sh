#!/bin/sh
# Hand-written handlers for cli.run component=custom in menu.yaml (root menu).
# shellcheck shell=sh

current_profile_name() {
	common_active_profile_name "$ROOT_DIR"
}

current_profile_dir() {
	common_profile_dir "$ROOT_DIR"
}

list_profile_names() {
	common_list_profile_dirnames "$ROOT_DIR"
}

set_active_profile_in_config() {
	common_set_active_profile_in_config "$ROOT_DIR" "$1" || return 1
	common_profile_env_clear_overrides
	load_base_config "$ROOT_DIR"
}

select_active_profile_root() {
	profiles="$(list_profile_names || true)"
	[ -n "${profiles:-}" ] || {
		ui_msgbox "Активный профиль" "Каталог profiles пуст или не найден."
		return 0
	}

	current="$(current_profile_name)"
	current_dir="$(current_profile_dir)"
	applied="$(common_applied_profile_name 2>/dev/null || true)"
	applied_note=""
	[ -n "${applied:-}" ] && applied_note="
Применённый к системе: $applied"
	choice="$(ui_select_from_lines "Активный профиль" "Выберите рабочий профиль для меню и правок.

Текущий рабочий: $current
Каталог: $current_dir$applied_note

После выбора можно сразу применить профиль к системе." "$profiles" 22 90 12 || true)"
	[ -n "${choice:-}" ] || return 0

	case "$choice" in
		*[!A-Za-z0-9._-]*|'')
			ui_msgbox "Активный профиль" "Некорректное имя профиля: $choice"
			return 0
			;;
	esac

	switched=0
	if [ "$choice" != "$current" ]; then
		set_active_profile_in_config "$choice" || {
			ui_msgbox "Активный профиль" "Не удалось записать профиль «$choice» в config.sh"
			return 0
		}
		switched=1
	fi

	if ui_confirm "Применить профиль" \
"Рабочий профиль: $choice

Применить его к системе сейчас (apply-template)?

Нет — только переключить для работы в меню; применённый останется: ${applied:-<нет записи>}."; then
		# Always sync config before apply (even if choice==current): stale PROFILE_DIR
		# in the menu shell can make "current" look like the choice while config.sh
		# still points at another profile (e.g. deleted default).
		set_active_profile_in_config "$choice" || {
			ui_msgbox "Применить профиль" "Не удалось записать профиль «$choice» в config.sh"
			return 0
		}
		_apply="$ROOT_DIR/templates/apply-template.sh"
		_profile_dir="$(common_profile_resolve_dir "$ROOT_DIR" "$choice")"
		[ -d "$_profile_dir" ] || {
			ui_msgbox "Применить профиль" "Каталог профиля не найден:
$_profile_dir"
			return 0
		}
		[ -f "$_apply" ] || {
			ui_msgbox "Применить профиль" "Не найден:
$_apply"
			return 0
		}
		[ -x "$_apply" ] || chmod +x "$_apply" 2>/dev/null || true
		ui_menu_invoke_with_output "Применить профиль: $choice" \
			env \
			PROFILE_DIR="$_profile_dir" \
			XFREE_APPLY_PROFILE_DIR="$_profile_dir" \
			XFREE_PROFILE="$choice" \
			XFREE_PROFILE_DIR="profiles/$choice" \
			sh "$_apply" || true
	elif [ "$switched" = "1" ]; then
		ui_msgbox "Активный профиль" "Рабочий профиль: $choice

К системе не применялся. При следующем старте меню снова подтянется применённый (${applied:-—}), если он записан."
	fi
}

root_gen_menu_hint() {
	current_profile="$(current_profile_name)"
	current_profile_dir_value="$(current_profile_dir)"
	applied_profile="$(common_applied_profile_name 2>/dev/null || true)"
	if [ -n "${applied_profile:-}" ] && [ "$applied_profile" != "$current_profile" ]; then
		printf 'Выберите раздел\n\nРабочий профиль: %s\nПрименённый: %s\nКаталог: %s\nРежим меню: %s' \
			"$current_profile" "$applied_profile" "$current_profile_dir_value" "$(_menu_mode_label)"
	else
		printf 'Выберите раздел\n\nАктивный профиль: %s\nКаталог: %s\nРежим меню: %s' \
			"$current_profile" "$current_profile_dir_value" "$(_menu_mode_label)"
	fi
}

root_menu_mode_title() {
	printf 'Режим работы (%s)' "$(_menu_mode_label)"
}

root_menu_toggle_mode() {
	was="$(_menu_mode_label)"
	menu_mode_toggle
	now="$(_menu_mode_label)"
	ui_msgbox "Режим работы" "Было: $was
Стало: $now

В подменю отображаются пункты выбранного режима."
}

root_menu_choice_2() {
	select_active_profile_root
}
