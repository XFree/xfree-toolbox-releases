#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
rm -f .git/index.lock

git add agents/dev/dns-routing/AGENT.md templates/tests/test-zapret-lists-on-xbox-dns.sh

# Ensure no probe junk is staged.
git diff --cached --name-only | grep -E '^\.tmp|^;$' | while IFS= read -r f; do
  git reset HEAD -- "$f" >/dev/null 2>&1 || true
done

git commit -m "$(cat <<'EOF'
Move xft DNS to Google DoH, replace cloud-front-flare with cdn-host, and ship pending LuCI and diagnostics updates.

Poisoned plain UDP made proton/xft names NXDOMAIN; bind user/xft to dns.google DoH in templates and keep sync/recreate as full dns-routing replace.
EOF
)"

git status --short | head -40
git log -1 --oneline
