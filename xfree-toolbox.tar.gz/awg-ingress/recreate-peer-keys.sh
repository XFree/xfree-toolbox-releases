#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

PEER="${1:-}"
ENDPOINT="${2:-}"
[ -n "$PEER" ] || die "Использование: $0 <peer-name-or-slug> [endpoint-host:port]"

awgingress_recreate_peer_keys "$PEER" "$ENDPOINT"
