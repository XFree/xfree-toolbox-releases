#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

case "${1:-}" in
    --list)
        awgingress_list_peer_choices
        exit 0
        ;;
esac

WRITE=0
if [ "${1:-}" = "--write" ]; then
    WRITE=1
    shift
fi

PEER="${1:-}"
ENDPOINT="${2:-}"
[ -n "$PEER" ] || die "Использование: $0 [--write] <peer-name-or-slug> [endpoint-host:port] | --list"

if [ "$WRITE" = "1" ]; then
    cfg_path="$(awgingress_regenerate_peer_config "$PEER" "$ENDPOINT")"
    success "Конфиг peer обновлён: $cfg_path"
else
    awgingress_show_peer_config "$PEER" "$ENDPOINT"
fi
