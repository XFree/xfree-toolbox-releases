#!/bin/sh
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd -P)"
COMMON_CANDIDATES="
$SCRIPT_DIR/../lib/common.sh
$SCRIPT_DIR/lib/common.sh
$SCRIPT_DIR/common.sh
"
COMMON_SH=""
for p in $COMMON_CANDIDATES; do
  [ -f "$p" ] && COMMON_SH="$p" && break
done
[ -n "$COMMON_SH" ] || {
  printf '[-] common.sh not found near %s\n' "$0" >&2
  exit 1
}
# shellcheck disable=SC1090
. "$COMMON_SH"

RESOLVER="$SCRIPT_DIR/resolve-awg-release.sh"
[ -x "$RESOLVER" ] || [ -f "$RESOLVER" ] || die "Resolver not found: $RESOLVER"

TAG=""
OUT_DIR="/tmp/awg"
DEBUG="${DEBUG:-1}"
SHOW_REASON=0
KEEP=0

while [ $# -gt 0 ]; do
  case "$1" in
    --tag)
      shift
      [ $# -gt 0 ] || die "--tag requires value"
      TAG="$1"
      ;;
    --dir|--download-dir)
      shift
      [ $# -gt 0 ] || die "--dir requires value"
      OUT_DIR="$1"
      ;;
    --show-reason) SHOW_REASON=1 ;;
    --keep) KEEP=1 ;;
    --no-debug) DEBUG=0 ;;
    *) die "Unknown argument: $1" ;;
  esac
  shift
done

info "Подготавливаю описание релиза AWG"

if [ "$SHOW_REASON" = "1" ]; then
  resolver_out="$("$RESOLVER" --emit-shell ${TAG:+--tag "$TAG"} --show-reason)" \
    || die "Не удалось определить состав релиза AWG"
else
  resolver_out="$("$RESOLVER" --emit-shell ${TAG:+--tag "$TAG"})" \
    || die "Не удалось определить состав релиза AWG"
fi

eval "$resolver_out"

[ -n "$AWG_TAG" ] || die "Резолвер не вернул AWG_TAG"
[ -n "$AWG_FILES" ] || die "Резолвер не вернул список файлов"
[ -n "$AWG_URLS" ] || die "Резолвер не вернул список URL"

mkdir -p "$OUT_DIR"
info "Каталог загрузки: $OUT_DIR"
info "Выбранный тег: $AWG_TAG"
[ "$SHOW_REASON" = "1" ] && info "Причина выбора: $AWG_SELECT_REASON"

set -- $AWG_FILES
files_count=$#
idx=1
for url in $AWG_URLS; do
  eval "file=\${$idx}"
  [ -n "$file" ] || die "Не удалось сопоставить имя файла для URL: $url"
  info "Скачиваю ($idx/$files_count): $file"
  http_fetch_file "$url" "$OUT_DIR/$file" || die "Не удалось скачать: $file"
  idx=$((idx + 1))
done

[ "$KEEP" = "1" ] && debug "Опция --keep принята (no-op для download)"

success "Загрузка завершена: $OUT_DIR"
