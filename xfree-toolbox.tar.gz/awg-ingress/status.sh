#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

AWG_ENSURE_SCRIPT="${AWG_ENSURE_SCRIPT:-$SCRIPT_DIR/ensure-awg.sh}"
CHECK_AWG_ONLY=0

usage() {
  cat <<EOF
Usage: $0 [--check-awg-only]

Show AWG ingress status.

Options:
  --check-awg-only  Check awg and exit without full ingress status
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --check-awg-only)
      CHECK_AWG_ONLY=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Неизвестный аргумент: $1"
      ;;
  esac
  shift
done

show_awg_install_state() {
  info "=== AWG TOOLING ==="
  [ -f "$AWG_ENSURE_SCRIPT" ] || die "Не найден ensure script: $AWG_ENSURE_SCRIPT"
  if sh "$AWG_ENSURE_SCRIPT"; then
    awg_bin="$(command -v awg 2>/dev/null || true)"
    awg_version="$("${awg_bin:-awg}" --version 2>/dev/null | head -n1 || true)"
    if [ -n "$awg_version" ]; then
      info "AWG version: $awg_version"
    fi
  else
    info "Подсказка: установите AWG через меню 'Установка AWG' или вызовите ensure-awg.sh --install-if-missing"
  fi
}

show_awg_install_state
if [ "$CHECK_AWG_ONLY" = "1" ]; then
  exit 0
fi
awgingress_status
