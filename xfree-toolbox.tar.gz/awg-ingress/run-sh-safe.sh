#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_PATH="${1:-}"
shift || true

[ -n "$SCRIPT_PATH" ] || {
  echo "Usage: $0 <script.sh> [args...]" >&2
  exit 2
}
[ -f "$SCRIPT_PATH" ] || {
  echo "Script not found: $SCRIPT_PATH" >&2
  exit 2
}

run_once() {
  sh "$SCRIPT_PATH" "$@"
}

if run_once "$@"; then
  exit 0
fi
first_rc=$?

grep -q $'\r' "$SCRIPT_PATH" 2>/dev/null || exit "$first_rc"

case "${SCRIPT_PATH:-}" in
  *.sh)
    script_dir="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
    script_base="$(basename -- "$SCRIPT_PATH")"
    tmp_script="$script_dir/.${script_base}.shfix.$$"
    awk '{ sub(/\r$/, ""); print }' "$SCRIPT_PATH" > "$tmp_script"
    chmod +x "$tmp_script" 2>/dev/null || true
    if sh "$tmp_script" "$@"; then
      rm -f "$tmp_script"
      exit 0
    fi
    second_rc=$?
    rm -f "$tmp_script"
    exit "$second_rc"
    ;;
esac

exit "$first_rc"
