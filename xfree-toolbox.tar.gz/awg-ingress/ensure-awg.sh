#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"

AWG_INSTALL_RELEASE_SCRIPT="${AWG_INSTALL_RELEASE_SCRIPT:-$SCRIPT_DIR/install-awg-release.sh}"
INSTALL_IF_MISSING=0
UPGRADE=0

usage() {
  cat <<EOF
Usage: $0 [--install-if-missing] [--upgrade|--force]

Check AWG installation state.

Options:
  --install-if-missing   Install AWG if it is missing
  --upgrade|--force      Install or update AWG release packages even if already installed
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --install-if-missing)
      INSTALL_IF_MISSING=1
      ;;
    --upgrade|--force)
      UPGRADE=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Неизвестный аргумент: $1"
      ;;
  esac
  shift
done

if [ "$UPGRADE" != "1" ] && command -v awg >/dev/null 2>&1; then
  awg_bin="$(command -v awg)"
  info "Проверка AWG: найден бинарник"
  success "AWG установлен: $awg_bin"
  awg_version="$("$awg_bin" --version 2>/dev/null | head -n1 || true)"
  [ -n "$awg_version" ] && info "AWG version: $awg_version"
  exit 0
fi

if [ "$INSTALL_IF_MISSING" != "1" ] && [ "$UPGRADE" != "1" ]; then
  warn "AWG не установлен"
  exit 1
fi

[ -f "$AWG_INSTALL_RELEASE_SCRIPT" ] || die "Не найден install script: $AWG_INSTALL_RELEASE_SCRIPT"
if [ "$UPGRADE" = "1" ]; then
  info "Запускаю установку/обновление релиза AWG"
else
  info "AWG отсутствует, запускаю установку"
fi
"$AWG_INSTALL_RELEASE_SCRIPT"
command -v awg >/dev/null 2>&1 || die "AWG не появился после установки"
success "AWG установлен"
awg_bin="$(command -v awg)"
awg_version="$("$awg_bin" --version 2>/dev/null | head -n1 || true)"
[ -n "$awg_version" ] && info "AWG version: $awg_version"
