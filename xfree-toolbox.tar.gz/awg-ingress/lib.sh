#!/bin/sh
# shellcheck shell=sh

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
. "$SCRIPT_DIR/config.sh"

awgingress_require_awg() {
    command -v awg >/dev/null 2>&1 || die "Не найден awg. Установите AmneziaWG."
}

awgingress_get_router_public_key() {
    awg show "$AWG_INGRESS_IF" public-key 2>/dev/null
}

awgingress_slug() {
    common_lower_ascii "$1" | sed 's/[^a-z0-9._-]/-/g; s/--*/-/g; s/^-//; s/-$//'
}

awgingress_peer_config_path() {
    slug="$1"
    awgingress_peer_client_conf_file "$slug"
}

awgingress_is_template_value() {
    value="${1:-}"
    case "$value" in
        '***RECREATE***'|'***GENERATE***'|'***PROMPT***')
            return 0
            ;;
    esac
    return 1
}

awgingress_quote_sh() {
    value="$1"
    printf '%s' "$value" | sed "s/'/'\\\\''/g; 1s/^/'/; \$s/\$/'/"
}

awgingress_endpoint_with_port() {
    host="$1"
    [ -n "$host" ] || return 1
    printf '%s:%s\n' "$host" "$AWG_INGRESS_PORT"
}

awgingress_detect_network_ipv4() {
    network_name="$1"
    [ -n "$network_name" ] || return 1

    if command -v ifstatus >/dev/null 2>&1 && command -v jsonfilter >/dev/null 2>&1; then
        ip="$(ifstatus "$network_name" 2>/dev/null | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null || true)"
        if [ -n "$ip" ]; then
            printf '%s\n' "$ip"
            return 0
        fi
    fi

    if command -v ubus >/dev/null 2>&1 && command -v jsonfilter >/dev/null 2>&1; then
        ip="$(ubus call "network.interface.$network_name" status 2>/dev/null | jsonfilter -e '@["ipv4-address"][0].address' 2>/dev/null || true)"
        if [ -n "$ip" ]; then
            printf '%s\n' "$ip"
            return 0
        fi
    fi

    ip="$(uci -q get "network.$network_name.ipaddr" 2>/dev/null || true)"
    if [ -n "$ip" ]; then
        printf '%s\n' "$ip"
    fi
}

awgingress_list_network_endpoint_choices_tsv() {
    seen="${TMPDIR:-/tmp}/awgingress-network-seen.$$"
    : > "$seen"

    while IFS= read -r network_name; do
        [ -n "$network_name" ] || continue
        grep -Fxq "$network_name" "$seen" 2>/dev/null && continue
        printf '%s\n' "$network_name" >> "$seen"

        ip="$(awgingress_detect_network_ipv4 "$network_name" 2>/dev/null || true)"
        [ -n "$ip" ] || continue
        case "$ip" in
            127.*) continue ;;
        esac
        endpoint="$(awgingress_endpoint_with_port "$ip" 2>/dev/null || true)"
        [ -n "$endpoint" ] || continue
        printf '%s\t%s\t%s\n' "$network_name" "$ip" "$endpoint"
    done <<EOF
$(uci show network 2>/dev/null | sed -n 's/^network\.\([^.]*\)=interface$/\1/p' || true)
EOF

    rm -f "$seen"
}

awgingress_save_default_peer_endpoint() {
    endpoint="$1"
    [ -n "$endpoint" ] || die "Пустой endpoint по умолчанию"

    mkdir -p "$AWG_INGRESS_CONFIG_DIR"
    cat > "$AWG_INGRESS_LOCAL_CONFIG_FILE" <<EOF
AWG_INGRESS_PEER_ENDPOINT=$(awgingress_quote_sh "$endpoint")
EOF
}

awgingress_default_peer_endpoint() {
    if [ -n "${AWG_INGRESS_PEER_ENDPOINT:-}" ] && ! awgingress_is_template_value "$AWG_INGRESS_PEER_ENDPOINT"; then
        printf '%s\n' "$AWG_INGRESS_PEER_ENDPOINT"
        return 0
    fi

    endpoint="$(awgingress_list_network_endpoint_choices_tsv 2>/dev/null | awk -F "$(printf '\t')" 'NR == 1 { print $3; exit }')"
    if [ -n "${endpoint:-}" ] && ! awgingress_is_template_value "$endpoint"; then
        printf '%s\n' "$endpoint"
        return 0
    fi

    endpoint="$(awgingress_endpoint_with_port "$AWG_INGRESS_ENDPOINT_DOMAIN" 2>/dev/null || true)"
    if [ -n "${endpoint:-}" ] && ! awgingress_is_template_value "$endpoint"; then
        printf '%s\n' "$endpoint"
        return 0
    fi

    return 1
}

awgingress_peer_state_dir() {
    slug="$1"
    printf '%s/%s\n' "$AWG_INGRESS_PEERS_DIR" "$slug"
}

awgingress_write_secret_file() {
    path="$1"
    value="$2"

    mkdir -p "$(dirname -- "$path")"
    old_umask="$(umask)"
    umask 077
    printf '%s\n' "$value" > "$path"
    umask "$old_umask"
    chmod 600 "$path" 2>/dev/null || true
}

awgingress_public_from_private() {
    private_key="$1"
    printf '%s\n' "$private_key" | awg pubkey
}

awgingress_store_server_identity() {
    private_key="$1"
    [ -n "$private_key" ] || die "Пустой private key сервера"

    public_key="$(awgingress_public_from_private "$private_key")" || die "Не удалось вычислить public key сервера"
    [ -n "$public_key" ] || die "Пустой public key сервера"

    awgingress_write_secret_file "$AWG_INGRESS_SERVER_DIR/private.key" "$private_key"
    printf '%s\n' "$public_key" > "$AWG_INGRESS_SERVER_DIR/public.key"

    server_env_path="$AWG_INGRESS_SERVER_DIR/server.env"
    extra_tmp="${AWG_INGRESS_SERVER_DIR}/.server.env.extra.$$"
    : > "$extra_tmp"
    if [ -f "$server_env_path" ]; then
        grep -vE '^(AWG_INGRESS_IF|AWG_INGRESS_ADDR|AWG_INGRESS_PORT|AWG_INGRESS_PUBLIC_KEY)=' "$server_env_path" \
            >> "$extra_tmp" 2>/dev/null || true
    fi
    cat > "$server_env_path" <<EOF
AWG_INGRESS_IF=$AWG_INGRESS_IF
AWG_INGRESS_ADDR=$AWG_INGRESS_ADDR
AWG_INGRESS_PORT=$AWG_INGRESS_PORT
AWG_INGRESS_PUBLIC_KEY=$public_key
EOF
    if [ -s "$extra_tmp" ]; then
        cat "$extra_tmp" >> "$server_env_path"
    fi
    rm -f "$extra_tmp"
}

awgingress_get_server_private_key() {
    private_key="$(uci -q get "network.$AWG_INGRESS_IF.private_key" 2>/dev/null || true)"
    if [ -n "$private_key" ]; then
        printf '%s\n' "$private_key"
        return 0
    fi

    if [ -f "$AWG_INGRESS_SERVER_DIR/private.key" ]; then
        sed -n '1p' "$AWG_INGRESS_SERVER_DIR/private.key"
        return 0
    fi

    awg genkey
}

awgingress_sync_server_identity_from_uci() {
    private_key="$(uci -q get "network.$AWG_INGRESS_IF.private_key" 2>/dev/null || true)"
    [ -n "$private_key" ] || return 0
    awgingress_store_server_identity "$private_key"
}

awgingress_import_server_private_key_state() {
    key_file="$1"
    [ -f "$key_file" ] || return 1

    private_key="$(sed -n '1p' "$key_file")"
    [ -n "$private_key" ] || die "Пустой private key сервера: $key_file"

    info "Импортирую private key сервера в state: $key_file"
    awgingress_store_server_identity "$private_key"
    return 0
}

awgingress_import_server_private_key() {
    key_file="$1"

    awgingress_import_server_private_key_state "$key_file" || return 1
    private_key="$(sed -n '1p' "$key_file")"
    uci set "network.$AWG_INGRESS_IF=interface"
    uci set "network.$AWG_INGRESS_IF.private_key=$private_key"
    awgingress_configure_ingress
    return 0
}

awgingress_store_peer_state() {
    slug="$1"
    name="$2"
    ip="$3"
    private_key="$4"
    public_key="$5"
    endpoint="$6"
    cfg_path="$7"

    peer_dir="$(awgingress_peer_state_dir "$slug")"
    mkdir -p "$peer_dir"
    awgingress_write_secret_file "$peer_dir/private.key" "$private_key"
    printf '%s\n' "$public_key" > "$peer_dir/public.key"
    cat > "$peer_dir/peer.env" <<EOF
PEER_SLUG=$slug
PEER_NAME=$name
PEER_IP=$ip
PEER_PUBLIC_KEY=$public_key
PEER_ENDPOINT=$endpoint
EOF
    client_conf="$peer_dir/client.conf"
    if [ -f "$cfg_path" ] && [ "$cfg_path" != "$client_conf" ]; then
        cp -f "$cfg_path" "$client_conf"
    fi
    chmod 600 "$client_conf" 2>/dev/null || true
}

awgingress_peers_meta_file() {
    printf '%s/peers.tsv\n' "$AWG_INGRESS_STATE_DIR"
}

awgingress_peers_meta_add() {
    name="$1"
    ip="$2"
    pub="$3"
    slug="$4"

    meta="$(awgingress_peers_meta_file)"
    touch "$meta"
    grep -F -v "$(printf '%s\t' "$slug")" "$meta" > "$meta.tmp" 2>/dev/null || true
    printf '%s\t%s\t%s\t%s\n' "$slug" "$name" "$ip" "$pub" >> "$meta.tmp"
    mv "$meta.tmp" "$meta"
}

awgingress_peers_meta_list() {
    meta="$(awgingress_peers_meta_file)"
    [ -f "$meta" ] || {
        echo "Peers не найдены"
        return 0
    }
    cat "$meta"
}

awgingress_sync_peers_meta_from_uci() {
    meta="$(awgingress_peers_meta_file)"
    tmp_meta="${meta}.tmp.$$"

    mkdir -p "$(dirname -- "$meta")"
    : > "$tmp_meta"

    awgingress_list_uci_peers_tsv | while IFS="$(printf '\t')" read -r slug name ip pub section; do
        [ -n "${slug:-}" ] || continue
        [ -n "${ip:-}" ] || continue
        [ -n "${pub:-}" ] || continue
        printf '%s\t%s\t%s\t%s\n' "$slug" "${name:-$slug}" "$ip" "$pub" >> "$tmp_meta"
    done

    mv "$tmp_meta" "$meta"
}

awgingress_sync_profile_meta_from_state() {
    profile_meta="$AWG_INGRESS_PROFILE_DIR/peers.tsv"
    state_meta="$(awgingress_peers_meta_file)"

    mkdir -p "$AWG_INGRESS_PROFILE_DIR"
    if [ -f "$state_meta" ]; then
        cp -f "$state_meta" "$profile_meta"
    else
        rm -f "$profile_meta"
    fi
}

awgingress_sync_state_from_profile() {
    mkdir -p "$AWG_INGRESS_STATE_DIR" "$AWG_INGRESS_SERVER_DIR" "$AWG_INGRESS_PEERS_DIR"

    if [ -d "$AWG_INGRESS_PROFILE_DIR/server" ]; then
        rm -rf "$AWG_INGRESS_SERVER_DIR"
        cp -a "$AWG_INGRESS_PROFILE_DIR/server" "$AWG_INGRESS_SERVER_DIR"
    fi

    if [ -d "$AWG_INGRESS_PROFILE_DIR/peers" ]; then
        rm -rf "$AWG_INGRESS_PEERS_DIR"
        cp -a "$AWG_INGRESS_PROFILE_DIR/peers" "$AWG_INGRESS_PEERS_DIR"
    fi

    if [ -f "$AWG_INGRESS_PROFILE_DIR/peers.tsv" ]; then
        cp -f "$AWG_INGRESS_PROFILE_DIR/peers.tsv" "$(awgingress_peers_meta_file)"
    fi
}

awgingress_peer_meta_lookup() {
    slug="$1"
    field="$2"
    meta="$(awgingress_peers_meta_file)"
    [ -f "$meta" ] || return 1

    awk -F "$(printf '\t')" -v s="$slug" -v f="$field" '
        $1 == s {
            if (f == "name") print $2
            else if (f == "ip") print $3
            else if (f == "public") print $4
            else print $0
            found=1
            exit
        }
        END { exit found ? 0 : 1 }
    ' "$meta"
}

awgingress_resolve_peer_slug() {
    slug_or_name="$1"
    [ -n "$slug_or_name" ] || return 1

    slug="$(awgingress_slug "$slug_or_name")"
    peer_dir="$(awgingress_peer_state_dir "$slug")"
    if [ -d "$peer_dir" ]; then
        printf '%s\n' "$slug"
        return 0
    fi

    meta="$(awgingress_peers_meta_file)"
    [ -f "$meta" ] || return 1
    found_slug="$(awk -F "$(printf '\t')" -v want="$slug_or_name" -v want_slug="$slug" '
        $1 == want || $1 == want_slug || $2 == want { print $1; exit }
    ' "$meta")"
    [ -n "${found_slug:-}" ] || return 1
    printf '%s\n' "$found_slug"
}

awgingress_peer_state_env_file() {
    slug="$1"
    printf '%s/peer.env\n' "$(awgingress_peer_state_dir "$slug")"
}

awgingress_peer_private_key_file() {
    slug="$1"
    printf '%s/private.key\n' "$(awgingress_peer_state_dir "$slug")"
}

awgingress_peer_client_conf_file() {
    slug="$1"
    printf '%s/client.conf\n' "$(awgingress_peer_state_dir "$slug")"
}

awgingress_peer_state_public_key_file() {
    slug="$1"
    printf '%s/public.key\n' "$(awgingress_peer_state_dir "$slug")"
}

awgingress_load_peer_state() {
    slug="$1"
    peer_dir="$(awgingress_peer_state_dir "$slug")"
    env_file="$(awgingress_peer_state_env_file "$slug")"
    priv_file="$(awgingress_peer_private_key_file "$slug")"

    [ -d "$peer_dir" ] || die "Не найден state peer: $slug"
    [ -f "$env_file" ] || die "Не найден peer.env: $env_file"
    [ -f "$priv_file" ] || die "Не найден private.key: $priv_file"

    PEER_NAME_STATE="$(sed -n 's/^PEER_NAME=//p' "$env_file" | head -n1 | tr -d '\r')"
    PEER_IP_STATE="$(sed -n 's/^PEER_IP=//p' "$env_file" | head -n1 | tr -d '\r')"
    PEER_PUBLIC_KEY_STATE="$(sed -n 's/^PEER_PUBLIC_KEY=//p' "$env_file" | head -n1 | tr -d '\r')"
    PEER_ENDPOINT_STATE="$(sed -n 's/^PEER_ENDPOINT=//p' "$env_file" | head -n1 | tr -d '\r')"
    PEER_PRIVATE_KEY_STATE="$(sed -n '1p' "$priv_file" | tr -d '\r')"

    [ -n "$PEER_NAME_STATE" ] || PEER_NAME_STATE="$slug"
    [ -n "$PEER_IP_STATE" ] || die "В peer.env отсутствует PEER_IP: $env_file"
    [ -n "$PEER_PRIVATE_KEY_STATE" ] || die "Пустой private.key peer: $priv_file"
}

awgingress_prepare_server_state_from_template() {
    awgingress_require_awg
    awgingress_ensure_dirs

    server_env="$AWG_INGRESS_SERVER_DIR/server.env"
    server_private="$AWG_INGRESS_SERVER_DIR/private.key"
    server_public_marker=""
    recreate_server=0

    if [ -f "$server_env" ]; then
        server_public_marker="$(sed -n 's/^AWG_INGRESS_PUBLIC_KEY=//p' "$server_env" | head -n1 | tr -d '\r')"
    fi

    if awgingress_is_template_value "$server_public_marker"; then
        recreate_server=1
    elif [ ! -f "$server_private" ]; then
        recreate_server=1
    fi

    if [ "$recreate_server" = "1" ]; then
        info "AWG ingress template: создаю новую identity сервера"
        server_private_value="$(awg genkey)"
    else
        server_private_value="$(sed -n '1p' "$server_private" | tr -d '\r')"
        [ -n "$server_private_value" ] || die "Пустой private.key сервера: $server_private"
        info "AWG ingress template: использую существующий state private key сервера"
    fi

    awgingress_store_server_identity "$server_private_value"
}

awgingress_prepare_peer_state_from_template() {
    slug="$1"

    [ -n "$slug" ] || die "Не указан slug peer"

    awgingress_require_awg
    awgingress_ensure_dirs

    peer_dir="$(awgingress_peer_state_dir "$slug")"
    env_file="$(awgingress_peer_state_env_file "$slug")"
    priv_file="$(awgingress_peer_private_key_file "$slug")"
    pub_file="$(awgingress_peer_state_public_key_file "$slug")"

    [ -d "$peer_dir" ] || die "Не найден state peer: $peer_dir"
    [ -f "$env_file" ] || die "Не найден peer.env: $env_file"

    peer_name="$(sed -n 's/^PEER_NAME=//p' "$env_file" | head -n1 | tr -d '\r')"
    peer_ip="$(sed -n 's/^PEER_IP=//p' "$env_file" | head -n1 | tr -d '\r')"
    peer_public_marker="$(sed -n 's/^PEER_PUBLIC_KEY=//p' "$env_file" | head -n1 | tr -d '\r')"
    peer_endpoint="$(sed -n 's/^PEER_ENDPOINT=//p' "$env_file" | head -n1 | tr -d '\r')"

    [ -n "$peer_name" ] || peer_name="$slug"
    [ -n "$peer_ip" ] || die "В peer.env отсутствует PEER_IP: $env_file"

    recreate_peer=0
    if awgingress_is_template_value "$peer_public_marker"; then
        recreate_peer=1
    elif [ ! -f "$priv_file" ] || [ ! -f "$pub_file" ]; then
        recreate_peer=1
    fi

    if awgingress_is_template_value "$peer_endpoint" || [ -z "$peer_endpoint" ]; then
        peer_endpoint="$(awgingress_default_peer_endpoint 2>/dev/null || true)"
        [ -n "$peer_endpoint" ] || die "Для peer $peer_name не задан PEER_ENDPOINT. Сначала сохраните endpoint по умолчанию в меню AWG ingress."
    fi

    if [ "$recreate_peer" = "1" ]; then
        info "AWG ingress template: создаю новую identity peer $peer_name"
        peer_priv="$(awg genkey)"
    else
        peer_priv="$(sed -n '1p' "$priv_file" | tr -d '\r')"
        [ -n "$peer_priv" ] || die "Пустой private.key peer: $priv_file"
        info "AWG ingress template: использую существующий state private key peer $peer_name"
    fi

    peer_pub="$(awgingress_public_from_private "$peer_priv")" || die "Не удалось вычислить public key peer $peer_name"
    [ -n "$peer_pub" ] || die "Пустой public key peer: $peer_name"

    awgingress_store_peer_state "$slug" "$peer_name" "$peer_ip" "$peer_priv" "$peer_pub" "$peer_endpoint" ""
    awgingress_peers_meta_add "$peer_name" "$peer_ip" "$peer_pub" "$slug"
    awgingress_regenerate_peer_config "$slug" "$peer_endpoint" >/dev/null
}

# Host-side template prep: materialize peer keys when endpoint is still a template token.
# Full peer materialization (endpoint + client.conf) remains for router prepare.
awgingress_prepare_peer_keys_from_template() {
    slug="$1"

    [ -n "$slug" ] || die "Не указан slug peer"

    awgingress_require_awg
    awgingress_ensure_dirs

    peer_dir="$(awgingress_peer_state_dir "$slug")"
    env_file="$(awgingress_peer_state_env_file "$slug")"
    priv_file="$(awgingress_peer_private_key_file "$slug")"
    pub_file="$(awgingress_peer_state_public_key_file "$slug")"

    [ -d "$peer_dir" ] || die "Не найден state peer: $peer_dir"
    [ -f "$env_file" ] || die "Не найден peer.env: $env_file"

    peer_name="$(sed -n 's/^PEER_NAME=//p' "$env_file" | head -n1 | tr -d '\r')"
    peer_ip="$(sed -n 's/^PEER_IP=//p' "$env_file" | head -n1 | tr -d '\r')"
    peer_public_marker="$(sed -n 's/^PEER_PUBLIC_KEY=//p' "$env_file" | head -n1 | tr -d '\r')"
    peer_endpoint="$(sed -n 's/^PEER_ENDPOINT=//p' "$env_file" | head -n1 | tr -d '\r')"

    [ -n "$peer_name" ] || peer_name="$slug"
    [ -n "$peer_ip" ] || die "В peer.env отсутствует PEER_IP: $env_file"

    if ! awgingress_is_template_value "$peer_endpoint" && [ -n "$peer_endpoint" ]; then
        awgingress_prepare_peer_state_from_template "$slug"
        return $?
    fi

    resolved_endpoint="$(awgingress_default_peer_endpoint 2>/dev/null || true)"
    if [ -n "$resolved_endpoint" ]; then
        awgingress_prepare_peer_state_from_template "$slug"
        return $?
    fi

    recreate_peer=0
    if awgingress_is_template_value "$peer_public_marker"; then
        recreate_peer=1
    elif [ ! -f "$priv_file" ] || [ ! -f "$pub_file" ]; then
        recreate_peer=1
    fi

    if [ "$recreate_peer" != "1" ]; then
        info "AWG ingress template (host): ключи peer $peer_name уже есть, endpoint — на роутере"
        return 0
    fi

    info "AWG ingress template (host): создаю ключи peer $peer_name (endpoint заполнит prepare на роутере)"
    peer_priv="$(awg genkey)"
    peer_pub="$(awgingress_public_from_private "$peer_priv")" || die "Не удалось вычислить public key peer $peer_name"
    [ -n "$peer_pub" ] || die "Пустой public key peer: $peer_name"

    awgingress_write_secret_file "$priv_file" "$peer_priv"
    printf '%s\n' "$peer_pub" > "$pub_file"
    chmod 600 "$pub_file" 2>/dev/null || true

    tmp_env="${env_file}.tmp.$$"
    awk -F '=' -v pub="$peer_pub" '
        BEGIN { updated=0 }
        $1 == "PEER_PUBLIC_KEY" { print "PEER_PUBLIC_KEY=" pub; updated=1; next }
        { print }
        END { if (!updated) print "PEER_PUBLIC_KEY=" pub }
    ' "$env_file" > "$tmp_env"
    mv "$tmp_env" "$env_file"

    return 0
}

awgingress_prepare_template_state_host() {
    template_marker="${AWG_INGRESS_STATE_ROOT}/TEMPLATE"
    state_template_marker="${AWG_INGRESS_STATE_DIR}/TEMPLATE"

    if [ ! -f "$template_marker" ] && [ ! -f "$state_template_marker" ]; then
        info "AWG ingress template marker не найден, host-подготовка не требуется"
        return 0
    fi

    awgingress_prepare_server_state_from_template

    peers_prepared=0
    if [ -d "$AWG_INGRESS_PEERS_DIR" ]; then
        for peer_dir in "$AWG_INGRESS_PEERS_DIR"/*; do
            [ -d "$peer_dir" ] || continue
            slug="$(basename -- "$peer_dir")"
            awgingress_prepare_peer_keys_from_template "$slug"
            peers_prepared=$((peers_prepared + 1))
        done
    fi

    success "AWG ingress host-подготовка: server + ключи peers=$peers_prepared (endpoint/client.conf — на роутере)"
}

awgingress_prepare_template_state() {
    template_marker="${AWG_INGRESS_STATE_ROOT}/TEMPLATE"
    state_template_marker="${AWG_INGRESS_STATE_DIR}/TEMPLATE"

    if [ ! -f "$template_marker" ] && [ ! -f "$state_template_marker" ]; then
        info "AWG ingress template marker не найден, подготовка не требуется"
        return 0
    fi

    awgingress_prepare_server_state_from_template

    peers_prepared=0
    if [ -d "$AWG_INGRESS_PEERS_DIR" ]; then
        for peer_dir in "$AWG_INGRESS_PEERS_DIR"/*; do
            [ -d "$peer_dir" ] || continue
            slug="$(basename -- "$peer_dir")"
            awgingress_prepare_peer_state_from_template "$slug"
            peers_prepared=$((peers_prepared + 1))
        done
    fi

    success "AWG ingress template подготовлен: peers=$peers_prepared"
}

awgingress_list_peer_choices() {
    meta="$(awgingress_peers_meta_file)"
    listed=0
    if [ -f "$meta" ]; then
        while IFS="$(printf '\t')" read -r slug name ip pub; do
            [ -n "${slug:-}" ] || continue
            printf '%s\t%s (%s)\n' "$slug" "${name:-$slug}" "${ip:-no-ip}"
            listed=$((listed + 1))
        done < "$meta"
    fi

    # Fallback: if state meta is missing/stale, list peers from live UCI.
    if [ "$listed" -eq 0 ]; then
        awgingress_list_uci_peers_tsv | while IFS="$(printf '\t')" read -r slug name ip pub section; do
            [ -n "${slug:-}" ] || continue
            printf '%s\t%s (%s)\n' "$slug" "${name:-$slug}" "${ip:-no-ip}"
        done
    fi
}

awgingress_show_peer_config() {
    slug_or_name="$1"
    endpoint="${2:-}"

    awgingress_render_peer_config "$slug_or_name" "$endpoint"
}

awgingress_render_peer_config() {
    slug_or_name="$1"
    endpoint="${2:-}"
    outfile="${3:-}"

    [ -n "$slug_or_name" ] || die "Не указан peer"

    slug="$(awgingress_resolve_peer_slug "$slug_or_name")" || die "Не найден peer: $slug_or_name"
    awgingress_load_peer_state "$slug"

    [ -n "$endpoint" ] || endpoint="${PEER_ENDPOINT_STATE:-${AWG_INGRESS_PEER_ENDPOINT:-}}"
    [ -n "$endpoint" ] || die "Не задан endpoint для peer $PEER_NAME_STATE. Сначала выполните 'Обновить конфиг peer'."
    peer_dns="${AWG_INGRESS_PEER_DNS:-}"
    if awgingress_is_template_value "$peer_dns"; then
        peer_dns=""
    fi

    router_pub="$(awgingress_get_router_public_key 2>/dev/null || true)"
    if [ -z "$router_pub" ] && [ -f "$AWG_INGRESS_SERVER_DIR/public.key" ]; then
        router_pub="$(sed -n '1p' "$AWG_INGRESS_SERVER_DIR/public.key" | tr -d '\r')"
    fi
    [ -n "$router_pub" ] || die "Не удалось получить public key роутера"

    if [ -n "$outfile" ]; then
        {
            printf '[Interface]\n'
            printf 'PrivateKey=%s\n' "$PEER_PRIVATE_KEY_STATE"
            printf 'Address=%s/%s\n' "$PEER_IP_STATE" "$AWG_INGRESS_PEER_PREFIX"
            if [ -n "$peer_dns" ]; then
                printf 'DNS=%s\n' "$peer_dns"
            fi
            printf 'MTU=1280\n\n'
            printf '[Peer]\n'
            printf 'PublicKey=%s\n' "$router_pub"
            printf 'Endpoint=%s\n' "$endpoint"
            printf 'AllowedIPs=0.0.0.0/0\n'
            printf 'PersistentKeepalive=25\n'
        } > "$outfile"
        return 0
    fi

    printf '[Interface]\n'
    printf 'PrivateKey=%s\n' "$PEER_PRIVATE_KEY_STATE"
    printf 'Address=%s/%s\n' "$PEER_IP_STATE" "$AWG_INGRESS_PEER_PREFIX"
    if [ -n "$peer_dns" ]; then
        printf 'DNS=%s\n' "$peer_dns"
    fi
    printf 'MTU=1280\n\n'
    printf '[Peer]\n'
    printf 'PublicKey=%s\n' "$router_pub"
    printf 'Endpoint=%s\n' "$endpoint"
    printf 'AllowedIPs=0.0.0.0/0\n'
    printf 'PersistentKeepalive=25\n'
}

awgingress_regenerate_peer_config() {
    slug_or_name="$1"
    endpoint="${2:-}"

    slug="$(awgingress_resolve_peer_slug "$slug_or_name")" || die "Не найден peer: $slug_or_name"
    cfg_path="$(awgingress_peer_config_path "$slug")"

    awgingress_render_peer_config "$slug" "$endpoint" "$cfg_path"
    chmod 600 "$cfg_path" 2>/dev/null || true

    if [ -n "${endpoint:-}" ] && [ -f "$(awgingress_peer_state_env_file "$slug")" ]; then
        env_file="$(awgingress_peer_state_env_file "$slug")"
        tmp_env="${env_file}.tmp.$$"
        awk -F '=' -v endpoint="$endpoint" '
            BEGIN { updated=0 }
            $1 == "PEER_ENDPOINT" { print "PEER_ENDPOINT=" endpoint; updated=1; next }
            { print }
            END { if (!updated) print "PEER_ENDPOINT=" endpoint }
        ' "$env_file" > "$tmp_env"
        mv "$tmp_env" "$env_file"
    fi

    printf '%s\n' "$cfg_path"
}

awgingress_next_peer_host() {
    meta="$(awgingress_peers_meta_file)"
    max=1

    if [ -f "$meta" ]; then
        while IFS="$(printf '\t')" read -r _slug _name ip _pub; do
            host="${ip##*.}"
            case "$host" in
                ''|*[!0-9]*) ;;
                *) [ "$host" -gt "$max" ] && max="$host" ;;
            esac
        done < "$meta"
    fi

    echo $((max + 1))
}

awgingress_add_or_update_peer_uci() {
    name="$1"
    peer_ip="$2"
    peer_pub="$3"

    found=""
    while IFS= read -r s; do
        [ -n "$s" ] || continue
        pub="$(uci -q get "$s.public_key" 2>/dev/null || true)"
        desc="$(uci -q get "$s.description" 2>/dev/null || true)"
        if [ "$pub" = "$peer_pub" ] || [ "$desc" = "$name" ]; then
            found="$s"
            break
        fi
    done <<EOF
$(uci show network 2>/dev/null | sed -n "s/^\(network\.[^.]*\)=amneziawg_${AWG_INGRESS_IF}$/\1/p" || true)
EOF

    case "$found" in
        network.*) found="${found#network.}" ;;
    esac

    if [ -z "$found" ]; then
        uci add network amneziawg_"$AWG_INGRESS_IF" >/dev/null
        found='@amneziawg_'
        found="${found}${AWG_INGRESS_IF}[-1]"
    fi

    uci set "network.${found}.public_key=$peer_pub"
    uci -q delete "network.${found}.allowed_ips" || true
    uci add_list "network.${found}.allowed_ips=$peer_ip/32"
    uci set "network.${found}.persistent_keepalive=20"
    uci set "network.${found}.description=$name"
}

# После UCI commit: только ingress. Полный network restart роняет wifi STA (udhcpc) и LAN SSH.
awgingress_reload_ingress_iface() {
    if [ -z "${AWG_INGRESS_IF:-}" ]; then
        warn "AWG ingress: пустой AWG_INGRESS_IF, пропускаю ifup"
        return 0
    fi
    if command -v ifup >/dev/null 2>&1; then
        info "ifup $AWG_INGRESS_IF (без полного network restart)"
        ifup "$AWG_INGRESS_IF" || warn "ifup $AWG_INGRESS_IF не удался"
        return 0
    fi
    warn "ifup недоступен, пропускаю reload $AWG_INGRESS_IF"
}

awgingress_configure_ingress() {
    awgingress_require_awg
    awgingress_ensure_dirs

    [ -n "${AWG_INGRESS_IF:-}" ] || die "AWG ingress: пустой AWG_INGRESS_IF"
    [ -n "${AWG_INGRESS_ADDR:-}" ] || die "AWG ingress: пустой AWG_INGRESS_ADDR"
    awgingress_is_template_value "${AWG_INGRESS_ADDR:-}" && die "AWG ingress: AWG_INGRESS_ADDR содержит template token ($AWG_INGRESS_ADDR)"
    [ -n "${AWG_INGRESS_PORT:-}" ] || die "AWG ingress: пустой AWG_INGRESS_PORT"
    awgingress_is_template_value "${AWG_INGRESS_PORT:-}" && die "AWG ingress: AWG_INGRESS_PORT содержит template token ($AWG_INGRESS_PORT)"
    case "$AWG_INGRESS_PORT" in
        ''|*[!0-9]*) die "AWG ingress: AWG_INGRESS_PORT должен быть числом, получено: $AWG_INGRESS_PORT" ;;
    esac

    router_priv="$(awgingress_get_server_private_key)" || die "Не удалось получить private key интерфейса"
    if uci -q get "network.$AWG_INGRESS_IF.private_key" >/dev/null 2>&1; then
        info "Использую существующий private key интерфейса $AWG_INGRESS_IF"
    elif [ -f "$AWG_INGRESS_SERVER_DIR/private.key" ]; then
        info "Восстанавливаю private key интерфейса $AWG_INGRESS_IF из state"
    else
        info "Создаю новый private key интерфейса $AWG_INGRESS_IF"
    fi
    awgingress_store_server_identity "$router_priv"

    info "Настраиваю интерфейс $AWG_INGRESS_IF"
    uci set "network.$AWG_INGRESS_IF=interface"
    uci set "network.$AWG_INGRESS_IF.proto=amneziawg"
    uci set "network.$AWG_INGRESS_IF.private_key=$router_priv"
    # Option may be absent on first run; do not fail under set -e.
    uci -q delete "network.$AWG_INGRESS_IF.addresses" || true
    uci add_list "network.$AWG_INGRESS_IF.addresses=$AWG_INGRESS_ADDR"
    uci set "network.$AWG_INGRESS_IF.listen_port=$AWG_INGRESS_PORT"

    uci commit network
    awgingress_reload_ingress_iface

    success "Интерфейс $AWG_INGRESS_IF настроен"
    info "Публичный ключ роутера: $(awgingress_get_router_public_key)"
}

# WAN input: optional UCI batch template profiles/.../awg-ingress/server/firewall.uci (or state copy).
# Placeholders: @AWG_INGRESS_PORT@ @AWG_INGRESS_IF@.
# No "commit firewall" inside the template.
# If the file is absent, managed sections are removed.
awgingress_apply_server_firewall_batch_template() {
    tpl=""
    for candidate in "$AWG_INGRESS_SERVER_DIR/firewall.uci" "$AWG_INGRESS_PROFILE_DIR/server/firewall.uci"; do
        if [ -f "$candidate" ]; then
            tpl="$candidate"
            break
        fi
    done

    wan_sec="awg_ingress_wan"
    lan_fwd_sec="awg_ingress_to_lan"
    if [ -z "$tpl" ]; then
        uci -q delete "firewall.$wan_sec" || true
        uci -q delete "firewall.$lan_fwd_sec" || true
        return 0
    fi

    tmp="${AWG_INGRESS_SERVER_DIR}/.firewall.uci.batch.$$"
    sed -e "s|@AWG_INGRESS_PORT@|$AWG_INGRESS_PORT|g" \
        -e "s|@AWG_INGRESS_IF@|$AWG_INGRESS_IF|g" \
        -e "s|@AWG_INGRESS_ZONE@|$AWG_INGRESS_FIREWALL_ZONE_NAME|g" \
        -e "s|@AWG_INGRESS_LAN_ZONE@|$AWG_INGRESS_LAN_ZONE|g" \
        "$tpl" > "$tmp" || die "Не удалось подставить placeholders в firewall.uci"

    uci -q delete "firewall.$wan_sec" || true
    uci -q delete "firewall.$lan_fwd_sec" || true
    if grep -qEv '^[[:space:]]*(#|$)' "$tmp"; then
        grep -vE '^[[:space:]]*(#|$)' "$tmp" | uci batch || die "uci batch: $tpl"
    fi
    rm -f "$tmp"
}

awgingress_sync_server_firewall_template() {
    mkdir -p "$AWG_INGRESS_SERVER_DIR" "$AWG_INGRESS_PROFILE_DIR/server"
    tpl="${AWG_INGRESS_SERVER_DIR}/firewall.uci"

    cat > "$tpl" <<EOF
# UCI batch-шаблон для ingress: WAN -> listen-порт.
# Подстановки: @AWG_INGRESS_PORT@ @AWG_INGRESS_IF@
# Не добавляйте commit firewall — коммит делает awg-ingress.

set firewall.awg_ingress_wan=rule
set firewall.awg_ingress_wan.name='Allow-awg-ingress-wan'
set firewall.awg_ingress_wan.src='wan'
set firewall.awg_ingress_wan.proto='udp'
set firewall.awg_ingress_wan.dest_port='@AWG_INGRESS_PORT@'
set firewall.awg_ingress_wan.target='ACCEPT'
EOF

    cp -f "$tpl" "$AWG_INGRESS_PROFILE_DIR/server/firewall.uci"
}

awgingress_cleanup_forwarding_duplicates() {
    src_zone="$AWG_INGRESS_FIREWALL_ZONE_NAME"
    keep_wan="$AWG_INGRESS_FIREWALL_FWD_WAN_NAME"
    keep_vpn="$AWG_INGRESS_FIREWALL_FWD_VPN_NAME"
    keep_lan="awg_ingress_to_lan"

    while IFS= read -r sec; do
        [ -n "$sec" ] || continue
        sec_id="${sec#firewall.}"
        [ "$sec_id" = "$keep_wan" ] && continue
        [ "$sec_id" = "$keep_vpn" ] && continue
        [ "$sec_id" = "$keep_lan" ] && continue
        case "$sec_id" in
            @forwarding\[*\]) ;;
            *) continue ;;
        esac

        fsrc="$(uci -q get "$sec.src" 2>/dev/null || true)"
        fdest="$(uci -q get "$sec.dest" 2>/dev/null || true)"
        [ "$fsrc" = "$src_zone" ] || continue

        case "$fdest" in
            wan|vpn|"$AWG_INGRESS_LAN_ZONE")
                info "firewall: удаляю дубликат forwarding $sec (src=$fsrc dest=$fdest)"
                uci -q delete "$sec" || true
                ;;
        esac
    done <<EOF
$(uci show firewall 2>/dev/null | sed -n 's/^\(firewall\.[^.]*\)=forwarding$/\1/p' || true)
EOF
}

awgingress_configure_firewall() {
    info "Настраиваю firewall для $AWG_INGRESS_IF"

    common_firewall_dedupe_zones_by_name
    awgingress_cleanup_forwarding_duplicates

    uci set "firewall.$AWG_INGRESS_FIREWALL_ZONE=zone"
    uci set "firewall.$AWG_INGRESS_FIREWALL_ZONE.name=$AWG_INGRESS_FIREWALL_ZONE_NAME"
    # Option may be absent on first run; do not fail under set -e.
    uci -q delete "firewall.$AWG_INGRESS_FIREWALL_ZONE.network" || true
    uci add_list "firewall.$AWG_INGRESS_FIREWALL_ZONE.network=$AWG_INGRESS_IF"
    uci set "firewall.$AWG_INGRESS_FIREWALL_ZONE.input=ACCEPT"
    uci set "firewall.$AWG_INGRESS_FIREWALL_ZONE.output=ACCEPT"
    uci set "firewall.$AWG_INGRESS_FIREWALL_ZONE.forward=ACCEPT"
    uci set "firewall.$AWG_INGRESS_FIREWALL_ZONE.masq=1"
    uci set "firewall.$AWG_INGRESS_FIREWALL_ZONE.mtu_fix=1"

    uci set "firewall.$AWG_INGRESS_FIREWALL_FWD_WAN_NAME=forwarding"
    uci set "firewall.$AWG_INGRESS_FIREWALL_FWD_WAN_NAME.src=$AWG_INGRESS_FIREWALL_ZONE_NAME"
    uci set "firewall.$AWG_INGRESS_FIREWALL_FWD_WAN_NAME.dest=wan"

    uci set "firewall.$AWG_INGRESS_FIREWALL_FWD_VPN_NAME=forwarding"
    uci set "firewall.$AWG_INGRESS_FIREWALL_FWD_VPN_NAME.src=$AWG_INGRESS_FIREWALL_ZONE_NAME"
    uci set "firewall.$AWG_INGRESS_FIREWALL_FWD_VPN_NAME.dest=$AWG_INGRESS_VPN_ZONE"

    uci set "firewall.awg_ingress_to_lan=forwarding"
    uci set "firewall.awg_ingress_to_lan.src=$AWG_INGRESS_FIREWALL_ZONE_NAME"
    uci set "firewall.awg_ingress_to_lan.dest=$AWG_INGRESS_LAN_ZONE"

    awgingress_apply_server_firewall_batch_template

    uci commit firewall
    /etc/init.d/firewall restart

    success "Firewall для $AWG_INGRESS_IF настроен"
}

awgingress_add_peer() {
    name="$1"
    endpoint="${2:-$AWG_INGRESS_PEER_ENDPOINT}"

    [ -n "$name" ] || die "Не указано имя клиента"

    awgingress_require_awg
    awgingress_ensure_dirs

    router_pub="$(awgingress_get_router_public_key)" || die "Не удалось получить public key роутера"
    [ -n "$router_pub" ] || die "Не удалось получить public key роутера"

    slug="$(awgingress_slug "$name")"
    [ -n "$slug" ] || die "Не удалось нормализовать имя клиента"

    host="$(awgingress_next_peer_host)"
    peer_ip="$AWG_INGRESS_PEER_NET.$host"

    peer_dir="$(awgingress_peer_state_dir "$slug")"
    if [ -f "$peer_dir/private.key" ]; then
        peer_priv="$(sed -n '1p' "$peer_dir/private.key")"
        peer_pub="$(awgingress_public_from_private "$peer_priv")" || die "Не удалось вычислить public key клиента"
        info "Использую существующий private key peer $name"
    else
        keypair="$(awg genkey | {
            read -r priv
            pub="$(printf '%s\n' "$priv" | awg pubkey)"
            printf '%s\t%s\n' "$priv" "$pub"
        })" || die "Не удалось сгенерировать ключи клиента"

        peer_priv="$(printf '%s' "$keypair" | awk -F '\t' '{print $1}')"
        peer_pub="$(printf '%s' "$keypair" | awk -F '\t' '{print $2}')"
    fi

    existing_ip="$(awgingress_peer_meta_lookup "$slug" ip 2>/dev/null || true)"
    [ -n "$existing_ip" ] && peer_ip="$existing_ip"

    info "Добавляю peer $name ($peer_ip)"
    awgingress_add_or_update_peer_uci "$name" "$peer_ip" "$peer_pub"

    uci commit network
    awgingress_reload_ingress_iface

    awgingress_peers_meta_add "$name" "$peer_ip" "$peer_pub" "$slug"
    awgingress_store_peer_state "$slug" "$name" "$peer_ip" "$peer_priv" "$peer_pub" "$endpoint" ""
    cfg_path="$(awgingress_regenerate_peer_config "$slug" "$endpoint")"
    success "Peer создан: $cfg_path"
}

awgingress_add_peer_state_only() {
    name="$1"
    endpoint="${2:-$AWG_INGRESS_PEER_ENDPOINT}"

    [ -n "$name" ] || die "Не указано имя клиента"

    awgingress_require_awg
    awgingress_ensure_dirs
    awgingress_sync_server_identity_from_uci

    slug="$(awgingress_slug "$name")"
    [ -n "$slug" ] || die "Не удалось нормализовать имя клиента"

    host="$(awgingress_next_peer_host)"
    peer_ip="$AWG_INGRESS_PEER_NET.$host"

    peer_dir="$(awgingress_peer_state_dir "$slug")"
    if [ -f "$peer_dir/private.key" ]; then
        peer_priv="$(sed -n '1p' "$peer_dir/private.key")"
        peer_pub="$(awgingress_public_from_private "$peer_priv")" || die "Не удалось вычислить public key клиента"
        info "Использую существующий private key peer $name"
    else
        keypair="$(awg genkey | {
            read -r priv
            pub="$(printf '%s\n' "$priv" | awg pubkey)"
            printf '%s\t%s\n' "$priv" "$pub"
        })" || die "Не удалось сгенерировать ключи клиента"
        peer_priv="$(printf '%s' "$keypair" | awk -F '\t' '{print $1}')"
        peer_pub="$(printf '%s' "$keypair" | awk -F '\t' '{print $2}')"
    fi

    existing_ip="$(awgingress_peer_meta_lookup "$slug" ip 2>/dev/null || true)"
    [ -n "$existing_ip" ] && peer_ip="$existing_ip"

    [ -n "$endpoint" ] || endpoint="$(awgingress_default_peer_endpoint 2>/dev/null || true)"
    [ -n "$endpoint" ] || die "Не задан endpoint для peer $name. Сначала сохраните endpoint по умолчанию."

    awgingress_peers_meta_add "$name" "$peer_ip" "$peer_pub" "$slug"
    awgingress_store_peer_state "$slug" "$name" "$peer_ip" "$peer_priv" "$peer_pub" "$endpoint" ""
    cfg_path="$(awgingress_regenerate_peer_config "$slug" "$endpoint")"
    success "Peer добавлен в state/profile: $cfg_path"
}

awgingress_apply_peers_from_state() {
    # Profile is the source of truth for apply flow.
    awgingress_sync_state_from_profile
    awgingress_ensure_dirs
    awgingress_sync_server_identity_from_uci
    applied=0
    state_peers=0

    for peer_dir in "$AWG_INGRESS_PEERS_DIR"/*; do
        [ -d "$peer_dir" ] || continue
        slug="$(basename -- "$peer_dir")"
        state_peers=$((state_peers + 1))
        awgingress_load_peer_state "$slug"
        awgingress_add_or_update_peer_uci "$PEER_NAME_STATE" "$PEER_IP_STATE" "$PEER_PUBLIC_KEY_STATE"
        applied=$((applied + 1))
    done

    if [ "$state_peers" -eq 0 ]; then
        warn "В profile/state нет peers для применения, выполняю только синхронизацию meta из UCI"
        awgingress_sync_peers_meta_from_uci
        awgingress_sync_profile_meta_from_state
        success "Peers profile/state синхронизирован"
        return 0
    fi

    uci commit network
    awgingress_reload_ingress_iface
    awgingress_sync_peers_meta_from_uci
    awgingress_sync_profile_meta_from_state
    success "Peers применены из profile/state в систему и profile/state синхронизирован: $applied"
}

awgingress_conf_value() {
    key="$1"
    file="$2"
    awk -F '=' -v key="$key" '
        /^[[:space:]]*#/ { next }
        /^[[:space:]]*\[/ { next }
        {
            k=$1
            v=$0
            sub(/=.*/, "", k)
            sub(/^[^=]*=/, "", v)
            gsub(/\r/, "", k)
            gsub(/\r/, "", v)
            gsub(/^[ \t]+|[ \t]+$/, "", k)
            gsub(/^[ \t]+|[ \t]+$/, "", v)
            if (k == key) {
                print v
                exit
            }
        }
    ' "$file"
}

awgingress_import_peer_config_state() {
    cfg="$1"
    name="${2:-}"

    [ -f "$cfg" ] || die "Конфиг не найден: $cfg"
    awgingress_require_awg
    awgingress_ensure_dirs
    awgingress_sync_server_identity_from_uci

    [ -n "$name" ] || name="$(basename "$cfg" .conf)"
    slug="$(awgingress_slug "$name")"
    [ -n "$slug" ] || die "Не удалось нормализовать имя peer: $name"

    peer_priv="$(awgingress_conf_value PrivateKey "$cfg")"
    peer_ip_cidr="$(awgingress_conf_value Address "$cfg")"
    endpoint="$(awgingress_conf_value Endpoint "$cfg")"

    [ -n "$peer_priv" ] || die "В конфиге нет Interface.PrivateKey: $cfg"
    [ -n "$peer_ip_cidr" ] || die "В конфиге нет Interface.Address: $cfg"

    peer_ip="${peer_ip_cidr%%/*}"
    peer_pub="$(awgingress_public_from_private "$peer_priv")" || die "Не удалось вычислить public key peer"
    router_pub="$(awgingress_conf_value PublicKey "$cfg")"

    if [ -f "$AWG_INGRESS_SERVER_DIR/public.key" ] && [ -n "$router_pub" ]; then
        state_router_pub="$(sed -n '1p' "$AWG_INGRESS_SERVER_DIR/public.key")"
        [ "$state_router_pub" = "$router_pub" ] || warn "Public key сервера в $cfg отличается от state"
    fi

    client_conf_path="$(awgingress_peer_config_path "$slug")"
    mkdir -p "$(dirname -- "$client_conf_path")"
    cp -f "$cfg" "$client_conf_path"
    chmod 600 "$client_conf_path" 2>/dev/null || true

    awgingress_peers_meta_add "$name" "$peer_ip" "$peer_pub" "$slug"
    awgingress_store_peer_state "$slug" "$name" "$peer_ip" "$peer_priv" "$peer_pub" "$endpoint" "$client_conf_path"
}

awgingress_import_peer_config() {
    cfg="$1"
    name="${2:-}"

    awgingress_import_peer_config_state "$cfg" "$name"

    slug="$(awgingress_slug "${name:-$(basename "$cfg" .conf)}")"
    peer_ip="$(awgingress_peer_meta_lookup "$slug" ip)"
    peer_pub="$(awgingress_peer_meta_lookup "$slug" public)"
    peer_name="$(awgingress_peer_meta_lookup "$slug" name)"

    info "Применяю peer $peer_name ($peer_ip) в UCI"
    awgingress_add_or_update_peer_uci "$peer_name" "$peer_ip" "$peer_pub"
    uci commit network
    awgingress_reload_ingress_iface
}

awgingress_import_source_dir() {
    if [ -n "${AWG_INGRESS_IMPORT_DIR:-}" ]; then
        printf '%s\n' "$AWG_INGRESS_IMPORT_DIR"
        return 0
    fi

    printf '%s\n' "$AWG_INGRESS_PROFILE_MIGRATION_DIR"
}

awgingress_list_uci_peers_tsv() {
    while IFS= read -r s; do
        [ -n "$s" ] || continue

        pub="$(uci -q get "$s.public_key" 2>/dev/null || true)"
        name="$(uci -q get "$s.description" 2>/dev/null || true)"
        ip="$(uci -q get "$s.allowed_ips" 2>/dev/null | head -n1 || true)"

        [ -n "$pub" ] || continue
        [ -n "$ip" ] || continue

        ip="${ip%%,*}"
        ip="${ip%%/*}"
        [ -n "$name" ] || name="$(basename "$s")"
        slug="$(awgingress_slug "$name")"
        [ -n "$slug" ] || continue

        printf '%s\t%s\t%s\t%s\t%s\n' "$slug" "$name" "$ip" "$pub" "$s"
    done <<EOF
$(uci show network 2>/dev/null | sed -n "s/^\(network\.[^.]*\)=amneziawg_${AWG_INGRESS_IF}$/\1/p" || true)
EOF
}

awgingress_reset_peer_state() {
    rm -rf "$AWG_INGRESS_PEERS_DIR"
    mkdir -p "$AWG_INGRESS_PEERS_DIR"
    : > "$(awgingress_peers_meta_file)"
}

awgingress_match_uci_by_pub() {
    cfg_pub="$1"
    uci_file="$2"
    awk -F "$(printf '\t')" -v want="$cfg_pub" '$4 == want { print }' "$uci_file"
}

awgingress_match_uci_by_ip() {
    cfg_ip="$1"
    uci_file="$2"
    awk -F "$(printf '\t')" -v want="$cfg_ip" '$3 == want { print }' "$uci_file"
}

awgingress_report_reconcile() {
    report_matched_file="$1"
    report_missing_uci_file="$2"
    report_missing_cfg_file="$3"
    report_ambiguous_file="$4"

    {
        echo "=== RECONCILE REPORT ==="
        echo "Matched pairs: $(wc -l < "$report_matched_file" | awk '{print $1}')"
        echo "Missing in UCI: $(wc -l < "$report_missing_uci_file" | awk '{print $1}')"
        echo "Missing config: $(wc -l < "$report_missing_cfg_file" | awk '{print $1}')"
        echo "Ambiguous    : $(wc -l < "$report_ambiguous_file" | awk '{print $1}')"

        if [ -s "$report_missing_uci_file" ]; then
            echo
            echo "--- Configs without UCI peer ---"
            cat "$report_missing_uci_file"
        fi

        if [ -s "$report_missing_cfg_file" ]; then
            echo
            echo "--- UCI peers without config ---"
            cat "$report_missing_cfg_file"
        fi

        if [ -s "$report_ambiguous_file" ]; then
            echo
            echo "--- Ambiguous matches ---"
            cat "$report_ambiguous_file"
        fi
    } >&2
}

awgingress_reconcile_import_pairs() {
    import_dir="$1"
    out_file="$2"
    tmp_dir="$(mktemp -d)"
    cfg_file="$tmp_dir/configs.tsv"
    uci_file="$tmp_dir/uci.tsv"
    reconcile_matched_file="$tmp_dir/matched.tsv"
    missing_uci_file="$tmp_dir/missing-uci.txt"
    missing_cfg_file="$tmp_dir/missing-config.txt"
    ambiguous_file="$tmp_dir/ambiguous.txt"
    used_uci_file="$tmp_dir/used-uci.sections"

    : > "$cfg_file"
    : > "$reconcile_matched_file"
    : > "$missing_uci_file"
    : > "$missing_cfg_file"
    : > "$ambiguous_file"
    : > "$used_uci_file"

    for cfg in "$import_dir"/*.conf; do
        [ -f "$cfg" ] || continue

        cfg_name="$(basename "$cfg" .conf)"
        cfg_slug="$(awgingress_slug "$cfg_name")"
        cfg_priv="$(awgingress_conf_value PrivateKey "$cfg")"
        cfg_ip_cidr="$(awgingress_conf_value Address "$cfg")"
        cfg_ip="${cfg_ip_cidr%%/*}"
        cfg_endpoint="$(awgingress_conf_value Endpoint "$cfg")"
        cfg_server_pub="$(awgingress_conf_value PublicKey "$cfg")"

        [ -n "$cfg_priv" ] || die "В конфиге нет Interface.PrivateKey: $cfg"
        [ -n "$cfg_ip" ] || die "В конфиге нет Interface.Address: $cfg"

        cfg_client_pub="$(awgingress_public_from_private "$cfg_priv")" || die "Не удалось вычислить public key клиента: $cfg"
        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
            "$cfg_slug" "$cfg_name" "$cfg_ip" "$cfg_client_pub" "$cfg_endpoint" "$cfg_server_pub" "$cfg" >> "$cfg_file"
    done

    [ -s "$cfg_file" ] || {
        rm -rf "$tmp_dir"
        error "В каталоге импорта нет .conf файлов: $import_dir"
        error "Добавьте client .conf в profiles/<active>/awg-ingress/migration или укажите --dir <migration-dir>"
        return 1
    }

    awgingress_list_uci_peers_tsv > "$uci_file"
    [ -s "$uci_file" ] || {
        rm -rf "$tmp_dir"
        error "В UCI не найдено peers для $AWG_INGRESS_IF"
        return 1
    }

    server_pub=""
    if [ -f "$AWG_INGRESS_SERVER_DIR/public.key" ]; then
        server_pub="$(sed -n '1p' "$AWG_INGRESS_SERVER_DIR/public.key")"
    fi

    while IFS="$(printf '\t')" read -r cfg_slug cfg_name cfg_ip cfg_client_pub cfg_endpoint cfg_server_pub cfg_path; do
        matches="$(awgingress_match_uci_by_pub "$cfg_client_pub" "$uci_file")"
        match_count="$(printf '%s\n' "$matches" | sed '/^$/d' | wc -l | awk '{print $1}')"
        match_reason="public_key"

        if [ "$match_count" -eq 0 ]; then
            matches="$(awgingress_match_uci_by_ip "$cfg_ip" "$uci_file")"
            match_count="$(printf '%s\n' "$matches" | sed '/^$/d' | wc -l | awk '{print $1}')"
            match_reason="ip"
        fi

        if [ -n "$server_pub" ] && [ -n "$cfg_server_pub" ] && [ "$server_pub" != "$cfg_server_pub" ]; then
            printf '%s\tserver public key mismatch\tconfig=%s\tstate=%s\n' "$cfg_path" "$cfg_server_pub" "$server_pub" >> "$ambiguous_file"
            continue
        fi

        case "$match_count" in
            0)
                printf '%s\tclient_pub=%s\tip=%s\n' "$cfg_path" "$cfg_client_pub" "$cfg_ip" >> "$missing_uci_file"
                ;;
            1)
                uci_line="$(printf '%s\n' "$matches" | sed -n '1p')"
                uci_slug="$(printf '%s\n' "$uci_line" | awk -F "$(printf '\t')" '{print $1}')"
                uci_name="$(printf '%s\n' "$uci_line" | awk -F "$(printf '\t')" '{print $2}')"
                uci_ip="$(printf '%s\n' "$uci_line" | awk -F "$(printf '\t')" '{print $3}')"
                uci_pub="$(printf '%s\n' "$uci_line" | awk -F "$(printf '\t')" '{print $4}')"
                uci_section="$(printf '%s\n' "$uci_line" | awk -F "$(printf '\t')" '{print $5}')"

                printf '%s\n' "$uci_section" >> "$used_uci_file"
                printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
                    "$cfg_path" "$uci_slug" "$uci_name" "$uci_ip" "$uci_pub" "$cfg_client_pub" "$cfg_endpoint" "$cfg_ip" "$match_reason" >> "$reconcile_matched_file"
                ;;
            *)
                printf '%s\t%s\tclient_pub=%s\tip=%s\n' "$cfg_path" "$match_reason" "$cfg_client_pub" "$cfg_ip" >> "$ambiguous_file"
                ;;
        esac
    done < "$cfg_file"

    while IFS="$(printf '\t')" read -r uci_slug uci_name uci_ip uci_pub uci_section; do
        if ! grep -Fxq "$uci_section" "$used_uci_file" 2>/dev/null; then
            printf '%s\tpublic_key=%s\tip=%s\tsection=%s\n' "$uci_name" "$uci_pub" "$uci_ip" "$uci_section" >> "$missing_cfg_file"
        fi
    done < "$uci_file"

    awgingress_report_reconcile "$reconcile_matched_file" "$missing_uci_file" "$missing_cfg_file" "$ambiguous_file"

    if [ -s "$missing_uci_file" ] || [ -s "$missing_cfg_file" ] || [ -s "$ambiguous_file" ]; then
        rm -rf "$tmp_dir"
        return 1
    fi

    cp -f "$reconcile_matched_file" "$out_file"
    rm -rf "$tmp_dir"
    return 0
}

awgingress_import_migration_dir_state() {
    awgingress_ensure_dirs
    import_dir="$(awgingress_import_source_dir)"
    matched_file="$(mktemp)"
    trap 'rm -f "$matched_file"' EXIT HUP INT TERM
    awgingress_sync_server_identity_from_uci

    if [ -f "$import_dir/server.private.key" ]; then
        awgingress_import_server_private_key_state "$import_dir/server.private.key"
    elif [ -f "$import_dir/private.key" ]; then
        awgingress_import_server_private_key_state "$import_dir/private.key"
    fi

    awgingress_reconcile_import_pairs "$import_dir" "$matched_file" || die "Импорт peers завершился с ошибками сопоставления"
    awgingress_reset_peer_state
    while IFS="$(printf '\t')" read -r cfg_path uci_slug uci_name uci_ip uci_pub cfg_client_pub cfg_endpoint cfg_ip match_reason; do
        [ -n "${cfg_path:-}" ] || continue
        info "Импортирую peer $uci_name из $(basename "$cfg_path") (match: $match_reason)"
        awgingress_import_peer_config_state "$cfg_path" "$uci_name"
    done < "$matched_file"
    trap - EXIT HUP INT TERM
    rm -f "$matched_file"
}

awgingress_import_migration_dir() {
    awgingress_import_migration_dir_state
    success "State AWG ingress восстановлен из profile migration и UCI"
}

awgingress_status() {
    echo "=== PROFILE ==="
    echo "Config dir: $AWG_INGRESS_CONFIG_DIR"
    echo "Local cfg : $AWG_INGRESS_LOCAL_CONFIG_FILE"
    echo "State dir : $AWG_INGRESS_STATE_DIR"
    echo "Profile migration: $AWG_INGRESS_PROFILE_MIGRATION_DIR"
    echo "Import source    : $(awgingress_import_source_dir)"
    if [ -n "${AWG_INGRESS_PEER_ENDPOINT:-}" ]; then
        echo "Default endpoint : $AWG_INGRESS_PEER_ENDPOINT"
    fi
    echo
    echo "=== SERVER IDENTITY ==="
    [ -f "$AWG_INGRESS_SERVER_DIR/public.key" ] && printf 'State public key: %s\n' "$(sed -n '1p' "$AWG_INGRESS_SERVER_DIR/public.key")" || true
    echo
    echo "=== PORTS ==="
    netstat -lpn 2>/dev/null | grep -E "$AWG_INGRESS_PORT" || true
    echo
    echo "=== AWG SHOW ==="
    awg show "$AWG_INGRESS_IF" 2>/dev/null || true
    echo
    echo "=== UCI PEERS ==="
    uci show network 2>/dev/null | grep -E "^network\\.[^.]+=amneziawg_${AWG_INGRESS_IF}$|^network\\.[^.]+\\.(description|public_key|allowed_ips|persistent_keepalive)=" || true
    echo
    echo "=== GENERATED PEERS ==="
    awgingress_peers_meta_list || true
}
