#!/bin/sh
# shellcheck shell=sh
# Non-interactive AWG Ingress VPN-server actions for LuCI (ubus xfree-toolbox awgMenu).
# Mirrors CLI xft → 8 (awg-ingress/menu.yaml).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

ACTION="${1:-status}"
ARG="${2:-}"
PAYLOAD="${3:-}"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/config.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib.sh"

LUCIRPC_SH="$SCRIPT_DIR/luci-rpc.sh"

if [ -f "$ROOT_DIR/lib/background-tasks.sh" ]; then
	# shellcheck disable=SC1091
	. "$ROOT_DIR/lib/background-tasks.sh"
fi

die_usage() {
	echo "Usage error: $*" >&2
	exit 2
}

need_arg() {
	[ -n "$ARG" ] || die_usage "action '$ACTION' requires argument"
}

awg_luci_want_bg() {
	[ "${AWG_LUCI_FOREGROUND:-0}" = "1" ] && return 1
	case "${ACTION:-}" in
	serverSetup|serverRecreateKeys|vkTurnSetup)
		return 0
		;;
	esac
	return 1
}

awg_luci_try_bg() {
	_task="$1"
	shift

	awg_luci_want_bg || return 1
	if [ "$#" -gt 0 ]; then
		if [ -f "$ROOT_DIR/lib/background-tasks.sh" ]; then
			bg_tasks_start "$_task" env AWG_LUCI_FOREGROUND=1 "$@"
		fi
	else
		if [ -f "$ROOT_DIR/lib/background-tasks.sh" ]; then
			bg_tasks_start "$_task" env AWG_LUCI_FOREGROUND=1 sh "$LUCIRPC_SH" "$ACTION"
		fi
	fi
}

action_status() {
	_installed=0
	_awg_ver=""
	if command -v awg >/dev/null 2>&1; then
		_installed=1
		_awg_ver="$(awg --version 2>/dev/null | head -n 1 || true)"
	fi
	printf 'SERVER_INSTALLED=%s\n' "$_installed"
	printf 'AWG_VERSION=%s\n' "$_awg_ver"
	printf 'SERVER_IFACE=%s\n' "$AWG_INGRESS_IF"
	printf 'SERVER_ADDR=%s\n' "$AWG_INGRESS_ADDR"
	printf 'SERVER_PORT=%s\n' "$AWG_INGRESS_PORT"

	_running=0
	if command -v awg >/dev/null 2>&1 && awg show "$AWG_INGRESS_IF" >/dev/null 2>&1; then
		_running=1
	elif netstat -lpn 2>/dev/null | grep -q ":$AWG_INGRESS_PORT "; then
		_running=1
	fi
	printf 'SERVER_RUNNING=%s\n' "$_running"

	_pubkey=""
	if [ -f "$AWG_INGRESS_SERVER_DIR/public.key" ]; then
		_pubkey="$(sed -n '1p' "$AWG_INGRESS_SERVER_DIR/public.key" | tr -d '\r')"
	elif command -v uci >/dev/null 2>&1; then
		_pubkey="$(uci -q get "network.$AWG_INGRESS_IF.public_key" 2>/dev/null || true)"
	fi
	printf 'SERVER_PUBKEY=%s\n' "$_pubkey"

	_def_ep="${AWG_INGRESS_PEER_ENDPOINT:-}"
	printf 'DEFAULT_ENDPOINT=%s\n' "$_def_ep"

	# AWG Obfuscation params
	_awg_params=""
	if command -v uci >/dev/null 2>&1; then
		for _p in jc jmin jmax s1 s2 h1 h2 h3 h4; do
			_v="$(uci -q get "network.$AWG_INGRESS_IF.$_p" 2>/dev/null || true)"
			[ -n "$_v" ] && _awg_params="$_awg_params $_p=$_v"
		done
	fi
	_awg_params="$(printf '%s' "$_awg_params" | sed 's/^ //')"
	printf 'OBFUSCATION=%s\n' "$_awg_params"

	# VK-Turn proxy status
	_vk_installed=0
	_vk_running=0
	_vk_port="49151"
	_vk_ver=""
	if [ -f "$ROOT_DIR/vk-turn/config.sh" ]; then
		_vk_port="$(sh -c ". $ROOT_DIR/vk-turn/config.sh 2>/dev/null && echo \$VKTURN_PORT" || echo "49151")"
	fi
	[ -n "$_vk_port" ] || _vk_port="49151"
	if [ -f "/opt/vk-turn-proxy/server" ]; then
		_vk_installed=1
		if pidof server >/dev/null 2>&1 || netstat -lpn 2>/dev/null | grep -qE "vk-turn|:$_vk_port"; then
			_vk_running=1
		fi
		if [ -f "/opt/vk-turn-proxy/version" ]; then
			_vk_ver="$(head -n 1 /opt/vk-turn-proxy/version 2>/dev/null | tr -d '\r\n\t ')"
		fi
	fi
	printf 'VKTURN_INSTALLED=%s\n' "$_vk_installed"
	printf 'VKTURN_RUNNING=%s\n' "$_vk_running"
	printf 'VKTURN_PORT=%s\n' "$_vk_port"
	printf 'VKTURN_VERSION=%s\n' "$_vk_ver"

	# Dump live awg stats if running
	_dump_file="/tmp/awg-ingress-dump.$$"
	if [ "$_running" = "1" ] && command -v awg >/dev/null 2>&1; then
		awg show "$AWG_INGRESS_IF" dump 2>/dev/null >"$_dump_file" || : >"$_dump_file"
	else
		: >"$_dump_file"
	fi

	# List peers
	_meta_file="$(awgingress_peers_meta_file)"
	_peer_count=0
	if [ -f "$_meta_file" ]; then
		while IFS="$(printf '\t')" read -r _slug _name _ip _pub; do
			[ -n "${_slug:-}" ] || continue
			_peer_count=$((_peer_count + 1))

			_hs=0
			_rx=0
			_tx=0
			_keepalive=25

			if [ -s "$_dump_file" ]; then
				_peer_stat="$(awk -F "$(printf '\t')" -v pub="$_pub" '$1 == pub { print $5 "|" $6 "|" $7 "|" $8; exit }' "$_dump_file" 2>/dev/null || true)"
				if [ -n "$_peer_stat" ]; then
					_hs="${_peer_stat%%|*}"
					_rest="${_peer_stat#*|}"
					_rx="${_rest%%|*}"
					_rest="${_rest#*|}"
					_tx="${_rest%%|*}"
					_keepalive="${_rest#*|}"
				fi
			fi

			_peer_ep=""
			_peer_env="$(awgingress_peer_state_env_file "$_slug")"
			if [ -f "$_peer_env" ]; then
				_peer_ep="$(awk -F= '$1 == "PEER_ENDPOINT" { print $2; exit }' "$_peer_env" 2>/dev/null | tr -d "'\"" || true)"
			fi
			[ -n "$_peer_ep" ] || _peer_ep="$_def_ep"

			printf 'PEER=%s|%s|%s|%s|%s|%s|%s|%s|%s\n' \
				"$_slug" "$_name" "$_ip" "$_pub" "$_peer_ep" "$_hs" "$_rx" "$_tx" "$_keepalive"
		done <"$_meta_file"
	fi
	rm -f "$_dump_file"
	printf 'PEER_COUNT=%d\n' "$_peer_count"

	# Endpoint choices
	_wan_ep="$(awgingress_endpoint_with_port "${AWG_INGRESS_ENDPOINT_WAN_HOST:-}" 2>/dev/null || true)"
	_domain_ep="$(awgingress_endpoint_with_port "${AWG_INGRESS_ENDPOINT_DOMAIN:-}" 2>/dev/null || true)"
	[ -n "$_wan_ep" ] && printf 'ENDPOINT_CHOICE=wan|WAN (%s)|%s\n' "$_wan_ep" "$_wan_ep"
	[ -n "$_domain_ep" ] && printf 'ENDPOINT_CHOICE=domain|Домен (%s)|%s\n' "$_domain_ep" "$_domain_ep"

	_net_choices="$(awgingress_list_network_endpoint_choices_tsv 2>/dev/null || true)"
	if [ -n "$_net_choices" ]; then
		printf '%s\n' "$_net_choices" | while IFS="$(printf '\t')" read -r _nname _nip _nep; do
			[ -n "${_nname:-}" ] || continue
			[ -n "${_nep:-}" ] || continue
			printf 'ENDPOINT_CHOICE=net:%s|Сеть %s (%s)|%s\n' "$_nname" "$_nname" "$_nep" "$_nep"
		done
	fi
}

action_server_apply() {
	printf '=== Применение параметров AWG ingress сервера ===\n'
	sh "$SCRIPT_DIR/apply-peers.sh"
	if command -v ifup >/dev/null 2>&1; then
		ifup "$AWG_INGRESS_IF" 2>/dev/null || true
	fi
	printf 'OK сервер применён\n'
}

action_server_setup() {
	awg_luci_try_bg "awg-server-setup" sh "$LUCIRPC_SH" serverSetup && return 0
	printf '=== Настройка / обновление сервера AWG ===\n'
	sh "$SCRIPT_DIR/setup-server.sh"
	printf 'OK сервер настроен\n'
}

action_server_recreate_keys() {
	awg_luci_try_bg "awg-recreate-server-keys" sh "$LUCIRPC_SH" serverRecreateKeys && return 0
	printf '=== Пересоздание ключей сервера AWG ===\n'
	sh "$SCRIPT_DIR/recreate-server-keys.sh"
	sh "$SCRIPT_DIR/apply-peers.sh"
	printf 'OK ключи сервера пересозданы\n'
}

action_server_configure_firewall() {
	printf '=== Настройка firewall для AWG ingress ===\n'
	sh "$SCRIPT_DIR/configure-firewall.sh"
	printf 'OK firewall настроен\n'
}

action_server_set_endpoint() {
	need_arg
	printf '=== Сохранение endpoint по умолчанию: %s ===\n' "$ARG"
	awgingress_save_default_peer_endpoint "$ARG"
	printf 'OK endpoint сохранён: %s\n' "$ARG"
}

action_peer_add() {
	need_arg
	_name="${ARG%%|*}"
	_ep="${ARG#*|}"
	[ "$_ep" = "$ARG" ] && _ep=""

	printf '=== Добавление клиента %s ===\n' "$_name"
	sh "$SCRIPT_DIR/add-peer-state.sh" "$_name" "$_ep"
	sh "$SCRIPT_DIR/apply-peers.sh"
	printf 'OK клиент добавлен: %s\n' "$_name"
}

action_peer_delete() {
	need_arg
	printf '=== Удаление клиента %s ===\n' "$ARG"
	sh "$SCRIPT_DIR/delete-peer.sh" "$ARG"
	sh "$SCRIPT_DIR/apply-peers.sh"
	printf 'OK клиент удалён: %s\n' "$ARG"
}

action_peer_recreate_keys() {
	need_arg
	_slug="${ARG%%|*}"
	_ep="${ARG#*|}"
	[ "$_ep" = "$ARG" ] && _ep=""

	printf '=== Пересоздание ключей клиента %s ===\n' "$_slug"
	sh "$SCRIPT_DIR/recreate-peer-keys.sh" "$_slug" "$_ep"
	sh "$SCRIPT_DIR/apply-peers.sh"
	printf 'OK ключи клиента пересозданы: %s\n' "$_slug"
}

action_peer_show_config() {
	need_arg
	printf '=== Конфигурация клиента %s ===\n' "$ARG"
	printf 'CONF_BODY_BEGIN\n'
	awgingress_render_peer_config "$ARG" ""
	printf '\nCONF_BODY_END\n'
}

action_peer_update_endpoint() {
	need_arg
	_slug="${ARG%%|*}"
	_ep="${ARG#*|}"
	[ "$_ep" != "$ARG" ] || die_usage "arg: <slug>|<endpoint>"

	printf '=== Обновление endpoint клиента %s → %s ===\n' "$_slug" "$_ep"
	sh "$SCRIPT_DIR/show-peer-config.sh" --write "$_slug" "$_ep"
	printf 'OK endpoint клиента обновлён\n'
}

action_vkturn_status() {
	printf '=== Статус VK-Turn proxy ===\n'
	sh "$ROOT_DIR/vk-turn/status.sh"
}

action_vkturn_setup() {
	printf '=== Настройка VK-Turn proxy ===\n'
	sh "$ROOT_DIR/vk-turn/setup-server.sh"
	printf 'OK VK-Turn настроен\n'
}

action_vkturn_restart() {
	printf '=== Запуск/перезапуск службы VK-Turn proxy ===\n'
	if [ -x /etc/init.d/vk-turn ]; then
		/etc/init.d/vk-turn restart
		printf 'OK служба перезапущена\n'
	elif [ -f "$ROOT_DIR/vk-turn/install-service.sh" ]; then
		sh "$ROOT_DIR/vk-turn/install-service.sh"
		printf 'OK служба установлена и перезапущена\n'
	else
		printf 'Скрипт install-service.sh не найден\n'
	fi
}

action_vkturn_stop() {
	printf '=== Остановка службы VK-Turn proxy ===\n'
	if [ -x /etc/init.d/vk-turn ]; then
		/etc/init.d/vk-turn stop
		printf 'OK служба остановлена\n'
	else
		printf 'Служба /etc/init.d/vk-turn не установлена\n'
	fi
}

action_vkturn_configure_firewall() {
	printf '=== Настройка Firewall для VK-Turn proxy ===\n'
	sh "$ROOT_DIR/vk-turn/configure-firewall.sh"
	printf 'OK Firewall для VK-Turn настроен\n'
}

action_vkturn_update() {
	printf '=== Проверка и обновление бинарника VK-Turn proxy ===\n'
	sh "$ROOT_DIR/vk-turn/update.sh"
	printf 'OK проверка/обновление завершено\n'
}

case "$ACTION" in
status|summary) action_status ;;
serverApply) action_server_apply ;;
serverSetup) action_server_setup ;;
serverRecreateKeys) action_server_recreate_keys ;;
serverConfigureFirewall) action_server_configure_firewall ;;
serverSetEndpoint) action_server_set_endpoint ;;
peerAdd) action_peer_add ;;
peerDelete) action_peer_delete ;;
peerRecreateKeys) action_peer_recreate_keys ;;
peerShowConfig) action_peer_show_config ;;
peerUpdateEndpoint) action_peer_update_endpoint ;;
vkTurnStatus) action_vkturn_status ;;
vkTurnSetup) action_vkturn_setup ;;
vkTurnRestart) action_vkturn_restart ;;
vkTurnStop) action_vkturn_stop ;;
vkTurnConfigureFirewall) action_vkturn_configure_firewall ;;
vkTurnUpdate) action_vkturn_update ;;
*)
	printf 'unknown awgMenu action: %s\n' "${ACTION:-?}" >&2
	exit 1
	;;
esac
