#!/bin/sh
# Hand-written handlers for cli.run component=custom in awg-ingress/menu.yaml.
# shellcheck shell=sh

AWG_ADD_PEER_STATE_SCRIPT="${AWG_ADD_PEER_STATE_SCRIPT:-$SCRIPT_DIR/add-peer-state.sh}"
AWG_APPLY_PEERS_SCRIPT="${AWG_APPLY_PEERS_SCRIPT:-$SCRIPT_DIR/apply-peers.sh}"
VK_TURN_MENU_SCRIPT="${VK_TURN_MENU_SCRIPT:-$ROOT_DIR/vk-turn/menu.gen.sh}"

awg_run() {
	title="$1"
	shift
	ui_menu_chmod_first_if_needed "$@"
	ui_menu_invoke_with_output "$title" "$@"
}

select_awg_ingress_endpoint() {
	preferred_endpoint="${1:-}"
	network_choices="$(awgingress_list_network_endpoint_choices_tsv || true)"
	wan_endpoint="$(awgingress_endpoint_with_port "$AWG_INGRESS_ENDPOINT_WAN_HOST" 2>/dev/null || true)"
	domain_endpoint="$(awgingress_endpoint_with_port "$AWG_INGRESS_ENDPOINT_DOMAIN" 2>/dev/null || true)"
	current_endpoint="${preferred_endpoint:-${AWG_INGRESS_PEER_ENDPOINT:-}}"
	default_item=""
	current_listed=0

	set --
	if [ -n "${wan_endpoint:-}" ]; then
		set -- "$@" "wan" "WAN: $wan_endpoint"
		if [ -n "$current_endpoint" ] && [ "$current_endpoint" = "$wan_endpoint" ]; then
			default_item="wan"
			current_listed=1
		elif [ -z "$default_item" ]; then
			default_item="wan"
		fi
	fi

	while IFS="$(printf '\t')" read -r net_name net_ip net_endpoint; do
		[ -n "${net_name:-}" ] || continue
		set -- "$@" "net:$net_name" "Сеть $net_name: $net_endpoint"
		if [ -n "$current_endpoint" ] && [ "$current_endpoint" = "$net_endpoint" ]; then
			default_item="net:$net_name"
			current_listed=1
		fi
	done <<EOF
$network_choices
EOF

	if [ -n "${domain_endpoint:-}" ]; then
		set -- "$@" "domain" "Домен: $domain_endpoint"
		if [ -n "$current_endpoint" ] && [ "$current_endpoint" = "$domain_endpoint" ]; then
			default_item="domain"
			current_listed=1
		fi
	fi

	if [ -n "$current_endpoint" ] && [ "$current_listed" = "0" ]; then
		set -- "$@" "current" "Текущий: $current_endpoint"
		default_item="current"
	fi

	set -- "$@" "manual" "Ввести вручную"

	old_default_item="${UI_MENU_DEFAULT_ITEM:-}"
	UI_MENU_DEFAULT_ITEM="$default_item"
	export UI_MENU_DEFAULT_ITEM
	endpoint_choice="$(ui_menu "AWG ingress peer" "Выберите endpoint для client config" 18 90 8 "$@" || true)"
	if [ -n "${old_default_item:-}" ]; then
		UI_MENU_DEFAULT_ITEM="$old_default_item"
		export UI_MENU_DEFAULT_ITEM
	else
		unset UI_MENU_DEFAULT_ITEM
	fi
	[ -n "${endpoint_choice:-}" ] || return 1

	case "$endpoint_choice" in
		wan)
			endpoint="$wan_endpoint"
			;;
		net:*)
			selected_net="${endpoint_choice#net:}"
			endpoint="$(printf '%s\n' "$network_choices" | awk -F "$(printf '\t')" -v want="$selected_net" '$1 == want { print $3; exit }')"
			;;
		domain)
			endpoint="$domain_endpoint"
			;;
		current)
			endpoint="$current_endpoint"
			;;
		manual|"")
			manual_default="${current_endpoint:-${AWG_INGRESS_PEER_ENDPOINT:-}}"
			[ -n "${manual_default:-}" ] || manual_default="${wan_endpoint:-}"
			[ -n "${manual_default:-}" ] || manual_default="$(printf '%s\n' "$network_choices" | awk -F "$(printf '\t')" 'NR == 1 { print $3; exit }')"
			[ -n "${manual_default:-}" ] || manual_default="${domain_endpoint:-}"
			endpoint="$(ui_inputbox "AWG ingress peer" "Введите endpoint host:port" "$manual_default" || true)"
			[ -n "${endpoint:-}" ] || return 1
			;;
	esac

	[ -n "${endpoint:-}" ] || endpoint="$current_endpoint"
	[ -n "${endpoint:-}" ] || endpoint="${AWG_INGRESS_PEER_ENDPOINT:-}"
	[ -n "${endpoint:-}" ] || endpoint="${wan_endpoint:-}"
	[ -n "${endpoint:-}" ] || endpoint="$(printf '%s\n' "$network_choices" | awk -F "$(printf '\t')" 'NR == 1 { print $3; exit }')"
	[ -n "${endpoint:-}" ] || endpoint="${domain_endpoint:-}"
	[ -n "${endpoint:-}" ] || return 1

	printf '%s\n' "$endpoint"
}

peer_endpoint_from_state() {
	peer_input="$1"
	[ -n "${peer_input:-}" ] || return 0

	slug="$(awgingress_resolve_peer_slug "$peer_input" 2>/dev/null || true)"
	[ -n "${slug:-}" ] || return 0
	awgingress_load_peer_state "$slug" >/dev/null 2>&1 || return 0
	printf '%s\n' "${PEER_ENDPOINT_STATE:-}"
}

awg_menu_choice_2() {
	awg_run "AWG ingress server" "$SCRIPT_DIR/setup-server.sh"
}

awg_menu_choice_3() {
	awg_run "AWG ingress interface" "$SCRIPT_DIR/configure-ingress.sh"
}

awg_menu_choice_4() {
	awg_run "AWG ingress firewall" "$SCRIPT_DIR/configure-firewall.sh"
}

awg_menu_choice_5() {
	name="$(ui_inputbox "AWG ingress peer" "Введите имя peer" "" || true)"
	[ -n "${name:-}" ] || return 0
	endpoint="$(select_awg_ingress_endpoint || true)"
	[ -n "${endpoint:-}" ] || return 0
	awg_run "Добавление peer в профиль (state)" "$AWG_ADD_PEER_STATE_SCRIPT" "$name" "$endpoint"
}

awg_menu_choice_6() {
	choices="$(sh "$SCRIPT_DIR/show-peer-config.sh" --list || true)"
	if [ -n "${choices:-}" ]; then
		peer="$(ui_select_from_lines "AWG ingress peer" "Выберите peer" "$choices" 20 90 10 || true)"
		peer="${peer%%	*}"
	else
		peer="$(ui_inputbox "AWG ingress peer" "Введите имя или slug peer" "" || true)"
	fi
	[ -n "${peer:-}" ] || return 0
	awg_run "Конфиг peer" "$SCRIPT_DIR/show-peer-config.sh" "$peer"
}

awg_menu_choice_7() {
	choices="$(sh "$SCRIPT_DIR/show-peer-config.sh" --list || true)"
	if [ -n "${choices:-}" ]; then
		peer="$(ui_select_from_lines "AWG ingress peer" "Выберите peer" "$choices" 20 90 10 || true)"
		peer="${peer%%	*}"
	else
		peer="$(ui_inputbox "AWG ingress peer" "Введите имя или slug peer" "" || true)"
	fi
	[ -n "${peer:-}" ] || return 0
	peer_endpoint="$(peer_endpoint_from_state "$peer" || true)"
	endpoint="$(select_awg_ingress_endpoint "$peer_endpoint" || true)"
	[ -n "${endpoint:-}" ] || return 0
	awg_run "Обновление конфига peer" "$SCRIPT_DIR/show-peer-config.sh" --write "$peer" "$endpoint"
}

awg_menu_choice_8() {
	awg_run "Применение peers из profile/state в систему" "$AWG_APPLY_PEERS_SCRIPT"
}

awg_menu_choice_9() {
	awg_run "Status" "$SCRIPT_DIR/status.sh"
}

awg_menu_choice_10() {
	endpoint="$(select_awg_ingress_endpoint || true)"
	[ -n "${endpoint:-}" ] || return 0
	if ui_confirm "AWG ingress" "Сохранить endpoint по умолчанию?\n\n$endpoint"; then
		if awgingress_save_default_peer_endpoint "$endpoint"; then
			AWG_INGRESS_PEER_ENDPOINT="$endpoint"
			ui_msgbox "AWG ingress" "Endpoint по умолчанию сохранён:\n\n$endpoint"
		else
			ui_msgbox "AWG ingress" "Не удалось сохранить endpoint по умолчанию."
		fi
	fi
}

awg_menu_choice_11() {
	[ -f "$VK_TURN_MENU_SCRIPT" ] && [ ! -x "$VK_TURN_MENU_SCRIPT" ] && chmod +x "$VK_TURN_MENU_SCRIPT" 2>/dev/null || true
	ui_menu_invoke_script_relaxed "$VK_TURN_MENU_SCRIPT" ui || true
}
