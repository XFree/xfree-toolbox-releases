#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

awgingress_ensure_dirs
awgingress_sync_server_identity_from_uci
awgingress_sync_server_firewall_template
awgingress_sync_peers_meta_from_uci
awgingress_sync_profile_meta_from_state

meta_file="$(awgingress_peers_meta_file)"
peers_count="$(wc -l < "$meta_file" 2>/dev/null | awk '{print $1}')"
success "AWG state синхронизирован из UCI: peers=$peers_count"
