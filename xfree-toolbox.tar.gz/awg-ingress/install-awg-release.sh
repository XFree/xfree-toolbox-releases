#!/bin/sh
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." 2>/dev/null && pwd -P)"
COMMON_CANDIDATES="
$ROOT_DIR/lib/common.sh
$SCRIPT_DIR/../lib/common.sh
$SCRIPT_DIR/lib/common.sh
$SCRIPT_DIR/common.sh
"
COMMON_SH=""
for p in $COMMON_CANDIDATES; do
  [ -f "$p" ] && COMMON_SH="$p" && break
done
[ -n "$COMMON_SH" ] || {
  printf '[-] common.sh not found near %s\n' "$0" >&2
  exit 1
}
# shellcheck disable=SC1090
. "$COMMON_SH"

PKG_MGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
[ -f "$PKG_MGR_SH" ] || die "Не найден pkgmgr.sh: $PKG_MGR_SH"
# shellcheck disable=SC1090
. "$PKG_MGR_SH"

DOWNLOADER="$SCRIPT_DIR/download-awg-release.sh"
[ -x "$DOWNLOADER" ] || [ -f "$DOWNLOADER" ] || die "Downloader not found: $DOWNLOADER"

RESOLVER="$SCRIPT_DIR/resolve-awg-release.sh"
[ -x "$RESOLVER" ] || [ -f "$RESOLVER" ] || die "Resolver not found: $RESOLVER"

TAG=""
DIR="/tmp/awg"
KEEP=0
DEBUG="${DEBUG:-1}"
SHOW_REASON=0

while [ $# -gt 0 ]; do
  case "$1" in
    --tag)
      shift
      [ $# -gt 0 ] || die "--tag requires value"
      TAG="$1"
      ;;
    --dir|--download-dir)
      shift
      [ $# -gt 0 ] || die "$1 requires value"
      DIR="$1"
      ;;
    --keep) KEEP=1 ;;
    --show-reason) SHOW_REASON=1 ;;
    --no-debug) DEBUG=0 ;;
    *) die "Unknown argument: $1" ;;
  esac
  shift
done

info "Скачиваю релиз AWG"
if [ "$SHOW_REASON" = "1" ]; then
  "$DOWNLOADER" ${TAG:+--tag "$TAG"} --dir "$DIR" --show-reason
  resolver_out="$("$RESOLVER" --emit-shell ${TAG:+--tag "$TAG"} --show-reason)" \
    || die "Не удалось определить порядок установки AWG"
else
  "$DOWNLOADER" ${TAG:+--tag "$TAG"} --dir "$DIR"
  resolver_out="$("$RESOLVER" --emit-shell ${TAG:+--tag "$TAG"})" \
    || die "Не удалось определить порядок установки AWG"
fi

eval "$resolver_out"

[ -n "$AWG_FILES" ] || die "Резолвер не вернул список пакетов для установки"

case "$PM" in
  apk) PKG_EXT="apk" ;;
  opkg) PKG_EXT="ipk" ;;
  *) die "Неизвестный менеджер пакетов: $PM" ;;
esac

pm_update_index_optional

install_one() {
  f="$1"
  [ -f "$f" ] || die "Файл пакета не найден: $f"
  info "Устанавливаю: $(basename -- "$f")"
  pm_install_file "$f" || die "Не удалось установить: $f"
}

info "Устанавливаю пакеты ($PKG_EXT)"
found=0
installed_count=0
for file in $AWG_FILES; do
  [ -n "$file" ] || continue
  found=1
  install_one "$DIR/$file"
  installed_count=$((installed_count + 1))
done

[ "$found" = "1" ] || die "Пакеты для установки не найдены в: $DIR"

# После apk: kmod + перезапуск netifd, иначе proto amneziawg не регистрируется
# (Proton/WARP: proto=none / NO_DEVICE). Reload только ingress iface — в lib.sh.
if [ "$installed_count" -gt 0 ] 2>/dev/null; then
  if command -v modprobe >/dev/null 2>&1; then
    info "Загружаю модуль amneziawg"
    modprobe amneziawg 2>/dev/null || true
  fi
  if [ -x /etc/init.d/network ]; then
    info "Перезапускаю сеть, чтобы netifd подхватил proto amneziawg"
    /etc/init.d/network restart || warn "network restart завершился с ошибкой"
    common_wait_network_after_restart "${XFREE_NETWORK_WAIT_SEC:-90}" || \
      warn "Сеть не стала готова после установки AWG (маршрут/DNS); продолжаю"
  fi
fi

if [ "$KEEP" != "1" ]; then
  info "Очищаю каталог загрузки: $DIR"
  rm -f "$DIR"/*."$PKG_EXT" 2>/dev/null || true
fi

success "Установка AWG завершена"
