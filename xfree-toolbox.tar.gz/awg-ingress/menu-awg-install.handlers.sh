#!/bin/sh
# Hand-written handlers for menu-awg-install.yaml (AWG install submenu).
# shellcheck shell=sh

AWG_RESOLVE_RELEASE_SCRIPT="${AWG_RESOLVE_RELEASE_SCRIPT:-$SCRIPT_DIR/resolve-awg-release.sh}"
AWG_DOWNLOAD_RELEASE_SCRIPT="${AWG_DOWNLOAD_RELEASE_SCRIPT:-$SCRIPT_DIR/download-awg-release.sh}"
AWG_INSTALL_RELEASE_SCRIPT="${AWG_INSTALL_RELEASE_SCRIPT:-$SCRIPT_DIR/install-awg-release.sh}"
AWG_ENSURE_SCRIPT="${AWG_ENSURE_SCRIPT:-$SCRIPT_DIR/ensure-awg.sh}"
RUN_SH_SAFE_SCRIPT="${RUN_SH_SAFE_SCRIPT:-$SCRIPT_DIR/run-sh-safe.sh}"

awg_install_run() {
	title="$1"
	shift
	ui_menu_chmod_first_if_needed "$@"
	ui_menu_invoke_with_output "$title" "$@"
}

awg_install_choice_1() {
	awg_install_run "Проверка установки AWG" "$RUN_SH_SAFE_SCRIPT" "$AWG_ENSURE_SCRIPT"
}

awg_install_choice_2() {
	awg_install_run "Проверка/установка AWG" "$RUN_SH_SAFE_SCRIPT" "$AWG_ENSURE_SCRIPT" --install-if-missing
}

awg_install_choice_3() {
	awg_install_run "Информация о релизе AWG" "$AWG_RESOLVE_RELEASE_SCRIPT" --summary --show-reason
}

awg_install_choice_4() {
	awg_install_run "Совместимые теги AWG" "$AWG_RESOLVE_RELEASE_SCRIPT" --list-compatible-tags
}

awg_install_choice_5() {
	awg_install_run "Скачивание AWG" "$AWG_DOWNLOAD_RELEASE_SCRIPT" --show-reason --keep
}

awg_install_choice_6() {
	awg_install_run "Установка AWG" "$AWG_INSTALL_RELEASE_SCRIPT" --show-reason
}
