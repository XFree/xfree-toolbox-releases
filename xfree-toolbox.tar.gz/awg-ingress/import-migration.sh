#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

STATE_ONLY=0

while [ "$#" -gt 0 ]; do
    case "$1" in
        --state-only)
            STATE_ONLY=1
            shift
            ;;
        *)
            break
            ;;
    esac
done

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

case "${1:-}" in
    --file)
        shift
        [ -n "${1:-}" ] || die "Использование: $0 --file <client.conf> [peer-name]"
        cfg="$1"
        name="${2:-}"
        if [ "$STATE_ONLY" = "1" ]; then
            awgingress_import_peer_config_state "$cfg" "$name"
            success "Peer state импортирован: $cfg"
        else
            awgingress_import_peer_config "$cfg" "$name"
            success "Peer импортирован: $cfg"
        fi
        ;;
    ""|--dir)
        [ "${1:-}" = "--dir" ] && shift || true
        if [ -n "${1:-}" ]; then
            AWG_INGRESS_IMPORT_DIR="$1"
        fi
        if [ "$STATE_ONLY" = "1" ]; then
            awgingress_import_migration_dir_state
            success "State импортирован из: $AWG_INGRESS_IMPORT_DIR"
        else
            awgingress_import_migration_dir
        fi
        ;;
    -h|--help)
        cat <<EOF
Usage:
  $0
  $0 --state-only
  $0 --dir <migration-dir>
  $0 --state-only --dir <migration-dir>
  $0 --file <client.conf> [peer-name]
  $0 --state-only --file <client.conf> [peer-name]

Default import dir:
  $AWG_INGRESS_IMPORT_DIR
EOF
        ;;
    *)
        die "Неизвестный параметр: $1"
        ;;
esac
