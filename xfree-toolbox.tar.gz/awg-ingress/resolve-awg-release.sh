#!/bin/sh
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd -P)"
COMMON_CANDIDATES="
$SCRIPT_DIR/../lib/common.sh
$SCRIPT_DIR/lib/common.sh
$SCRIPT_DIR/common.sh
"
COMMON_SH=""
for p in $COMMON_CANDIDATES; do
  [ -f "$p" ] && COMMON_SH="$p" && break
done
[ -n "$COMMON_SH" ] || {
  printf '[-] common.sh not found near %s\n' "$0" >&2
  exit 1
}
# shellcheck disable=SC1090
. "$COMMON_SH"

ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
export ROOT_DIR
PKGMGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
[ -f "$PKGMGR_SH" ] || die "pkgmgr.sh not found: $PKGMGR_SH"
# shellcheck disable=SC1090
. "$PKGMGR_SH"

REPO_OWNER_DEFAULT="Slava-Shchipunov"
REPO_NAME_DEFAULT="awg-openwrt"

REPO_OWNER="$REPO_OWNER_DEFAULT"
REPO_NAME="$REPO_NAME_DEFAULT"
BASE_URL="https://github.com/${REPO_OWNER}/${REPO_NAME}"

MODE="summary"
EXPLICIT_TAG=""
SHOW_REASON=0
STRICT_TAG=0
DEBUG="${DEBUG:-1}"

# kmod first: amneziawg-tools pulls kernel deps from repos after apk/opkg update.
REQUIRED_PKGS="kmod-amneziawg amneziawg-tools luci-proto-amneziawg luci-i18n-amneziawg-ru"
AWG_SELECT_REASON=""

usage() {
  cat <<USAGE
Usage:
  $(common_basename) [--summary|--urls|--emit-shell|--list-compatible-tags] [options]

Options:
  --summary
  --urls
  --emit-shell
  --list-tags
  --list-compatible-tags
  --tag <vX.Y.Z>
  --show-reason
  --strict-tag
  --no-debug
USAGE
}

note() {
  case "$MODE" in
    emit-shell|urls) info_err "$*" ;;
    *) info "$*" ;;
  esac
}

while [ $# -gt 0 ]; do
  case "$1" in
    --summary) MODE="summary" ;;
    --urls) MODE="urls" ;;
    --emit-shell) MODE="emit-shell" ;;
    --list-tags|--list-compatible-tags) MODE="list-tags" ;;
    --tag)
      shift
      [ $# -gt 0 ] || die "--tag requires value"
      EXPLICIT_TAG="$1"
      ;;
    --show-reason) SHOW_REASON=1 ;;
    --strict-tag) STRICT_TAG=1 ;;
    --no-debug) DEBUG=0 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown argument: $1" ;;
  esac
  shift
done

http_get() {
  http_fetch_text "$1"
}

http_exists() {
  http_head_exists "$1"
}

normalize_arch() {
  arch_raw="$1"
  target_raw="$2"

  arch="$(printf '%s' "$arch_raw" | tr -d '\r')"
  target="$(printf '%s' "$target_raw" | tr -d '\r' | tr '/' '_')"

  case "$arch" in
    *filogic*|*mediatek_filogic*) printf '%s\n' "$arch" ;;
    aarch64_cortex-a53)
      if [ -n "$target" ]; then
        printf '%s_%s\n' "$arch" "$target"
      else
        printf '%s\n' "$arch"
      fi
      ;;
    *)
      printf '%s\n' "$arch"
      ;;
  esac
}

load_openwrt_release() {
  [ -f /etc/openwrt_release ] || die "/etc/openwrt_release not found"
  # shellcheck disable=SC1091
  . /etc/openwrt_release

  OWRT_VER="$DISTRIB_RELEASE"
  OWRT_ARCH="$(normalize_arch "${DISTRIB_ARCH:-}" "${DISTRIB_TARGET:-}")"

  [ -n "$OWRT_VER" ] || die "Could not detect OpenWrt release"
  [ -n "$OWRT_ARCH" ] || die "Could not detect OpenWrt arch"

  debug "Detected OpenWrt release: $OWRT_VER"
  debug "Detected OpenWrt arch: $OWRT_ARCH"
}

select_repo_for_release() {
  case "$OWRT_VER" in
    24.10.0|24.10.1|24.10.2)
      REPO_OWNER="yanjore"
      REPO_NAME="awg-openwrt"
      AWG_SELECT_REASON="repo-override-yanjore"
      ;;
    *)
      REPO_OWNER="$REPO_OWNER_DEFAULT"
      REPO_NAME="$REPO_NAME_DEFAULT"
      AWG_SELECT_REASON=""
      ;;
  esac

  BASE_URL="https://github.com/${REPO_OWNER}/${REPO_NAME}"
  debug "Selected AWG repo: ${REPO_OWNER}/${REPO_NAME}"
}

select_pkg_ext() {
  if command -v apk >/dev/null 2>&1; then
    PKG_EXT="apk"
    PKG_MGR="apk"
  else
    PKG_EXT="ipk"
    PKG_MGR="opkg"
  fi
}

extract_page_tags() {
  html_file="$1"
  grep -oE '>v[0-9]+\.[0-9]+\.[0-9]+<' "$html_file" \
    | tr -d '<>' \
    | sed '/^$/d' \
    | sort -u
}

extract_next_tags_url() {
  html_file="$1"
  current_url="$2"

  next_rel="$(grep -oE 'href="/[^"]+/tags\?after=v[0-9.]+"' "$html_file" \
    | sed 's/^href="//' \
    | sed 's/"$//' \
    | grep "/${REPO_OWNER}/${REPO_NAME}/tags?after=v" \
    | sort -u \
    | tail -n1)"

  [ -n "$next_rel" ] || return 1

  next_url="https://github.com${next_rel}"
  [ "$next_url" = "$current_url" ] && return 1
  printf '%s\n' "$next_url"
}

fetch_tags() {
  url="${BASE_URL}/tags"
  page=1
  seen_urls=""
  tmp_dir="$(mktemp -d)" || die "mktemp failed"
  trap 'rm -rf "$tmp_dir"' EXIT INT TERM

  while [ -n "$url" ]; do
    case " $seen_urls " in
      *" $url "*)
        debug "Stopping pagination: already visited $url"
        break
        ;;
    esac
    seen_urls="$seen_urls $url"

    debug "Fetching tags page $page: $url"
    html_file="$tmp_dir/page_${page}.html"
    if ! http_get "$url" > "$html_file"; then
      die "Failed to fetch tags page: $url"
    fi

    extract_page_tags "$html_file"

    next_url="$(extract_next_tags_url "$html_file" "$url" 2>/dev/null || true)"
    if [ -n "$next_url" ]; then
      url="$next_url"
      page=$((page + 1))
      if [ "$page" -gt 20 ]; then
        debug "Stopping pagination: page limit reached"
        break
      fi
    else
      url=""
    fi
  done | sort -V | uniq

  rm -rf "$tmp_dir"
  trap - EXIT INT TERM
}

tag_has_all_assets() {
  tag="$1"

  for pkg in $REQUIRED_PKGS; do
    file="${pkg}_${tag}_${OWRT_ARCH}.${PKG_EXT}"
    url="${BASE_URL}/releases/download/${tag}/${file}"
    debug "Probe asset: $url"
    http_exists "$url" || return 1
  done
  return 0
}

resolve_packages() {
  AWG_FILES=""
  AWG_URLS=""

  for pkg in $REQUIRED_PKGS; do
    file="${pkg}_${AWG_TAG}_${OWRT_ARCH}.${PKG_EXT}"
    url="${BASE_URL}/releases/download/${AWG_TAG}/${file}"
    AWG_FILES="${AWG_FILES}${AWG_FILES:+ }${file}"
    AWG_URLS="${AWG_URLS}${AWG_URLS:+ }${url}"
  done
}

select_tag() {
  tags="$1"

  if [ -n "$EXPLICIT_TAG" ]; then
    candidate="$EXPLICIT_TAG"
    if [ -n "$AWG_SELECT_REASON" ]; then
      AWG_SELECT_REASON="${AWG_SELECT_REASON},manual-explicit-tag"
    else
      AWG_SELECT_REASON="manual-explicit-tag"
    fi
  else
    candidate="v${OWRT_VER}"
    if [ -n "$AWG_SELECT_REASON" ]; then
      AWG_SELECT_REASON="${AWG_SELECT_REASON},exact-openwrt-version"
    else
      AWG_SELECT_REASON="exact-openwrt-version"
    fi
  fi

  printf '%s\n' "$tags" | grep -qx "$candidate" || die "Tag not found: $candidate"
  note "Найден подходящий тег: $candidate"

  tag_has_all_assets "$candidate" || die "Assets not ready: $candidate"
  note "Пакеты для тега готовы: $candidate"

  AWG_TAG="$candidate"
  AWG_VER="${AWG_TAG#v}"
}

print_summary() {
  info "Repository      : ${REPO_OWNER}/${REPO_NAME}"
  info "Package manager: $PKG_MGR"
  info "OpenWrt release : $OWRT_VER"
  info "OpenWrt arch    : $OWRT_ARCH"
  info "Package ext     : .$PKG_EXT"
  info "Requested tag   : ${EXPLICIT_TAG:-v$OWRT_VER}"
  info "Selected tag    : $AWG_TAG"
  [ "$SHOW_REASON" = "1" ] && info "Select reason   : $AWG_SELECT_REASON"
  info "Status          : ready"
  info "Files:"
  for f in $AWG_FILES; do
    say "    - $f"
  done
  info "URLs:"
  for u in $AWG_URLS; do
    say "    - $u"
  done
}

emit_shell() {
  printf 'AWG_TAG="%s"\n' "$AWG_TAG"
  printf 'AWG_VER="%s"\n' "$AWG_VER"
  printf 'AWG_OPENWRT_RELEASE="%s"\n' "$OWRT_VER"
  printf 'AWG_OPENWRT_ARCH="%s"\n' "$OWRT_ARCH"
  printf 'AWG_PKG_EXT="%s"\n' "$PKG_EXT"
  printf 'AWG_SELECT_REASON="%s"\n' "$AWG_SELECT_REASON"
  printf 'AWG_REPO_OWNER="%s"\n' "$REPO_OWNER"
  printf 'AWG_REPO_NAME="%s"\n' "$REPO_NAME"
  printf 'AWG_BASE_URL="%s"\n' "$BASE_URL"
  printf 'AWG_FILES="%s"\n' "$AWG_FILES"
  printf 'AWG_URLS="%s"\n' "$AWG_URLS"
}

list_tags() {
  info "Repository      : ${REPO_OWNER}/${REPO_NAME}"
  info "OpenWrt release : $OWRT_VER"
  info "OpenWrt arch    : $OWRT_ARCH"
  info "Compatible tag  : ${AWG_TAG:-${EXPLICIT_TAG:-v$OWRT_VER}}"
  if [ "$SHOW_REASON" = "1" ] && [ -n "$AWG_SELECT_REASON" ]; then
    info "Select reason   : $AWG_SELECT_REASON"
  fi
  say ""
  say "--- Available tags ---"
  printf '%s\n' "$1"
}

main() {
  load_openwrt_release
  select_pkg_ext
  http_need_tools
  select_repo_for_release
  TAGS="$(fetch_tags)"
  [ -n "$TAGS" ] || die "No tags found"
  select_tag "$TAGS"
  resolve_packages

  case "$MODE" in
    summary) print_summary ;;
    urls) printf '%s\n' $AWG_URLS ;;
    emit-shell) emit_shell ;;
    list-tags) list_tags "$TAGS" ;;
    *) die "Unsupported mode: $MODE" ;;
  esac
}

main "$@"
