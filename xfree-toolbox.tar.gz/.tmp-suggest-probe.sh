#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo '=== suggest youtube ==='
ubus call xfree-toolbox trafficPath '{"action":"suggest","fqdn":"youtube","limit":"15"}'
echo
echo '=== hexdump first item chars ==='
ubus call xfree-toolbox trafficPath '{"action":"suggest","fqdn":"youtube","limit":"3"}' | head -c 400 | hexdump -C | head -20
echo '=== CSS suggest on router ==='
grep -n 'tm-suggest' /www/luci-static/resources/xfree-toolbox/xfree-dashboard.css | head -20
REMOTE
