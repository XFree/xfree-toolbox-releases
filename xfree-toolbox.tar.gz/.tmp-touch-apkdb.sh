#!/bin/sh
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
. ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"

# Restore clean luci version.uc (undo experimental xfreebust suffix).
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
printf "%s\n" "export const revision = '26.273.20498~1fcad1e', branch = 'LuCI openwrt-25.12 branch';" > /usr/share/ucode/luci/version.uc
# LuCI JS cache key includes pkgs_update_time = mtime(/lib/apk/db/installed)
touch /lib/apk/db/installed
rm -f /tmp/luci-indexcache* 2>/dev/null || true
/etc/init.d/uhttpd reload 2>/dev/null || true
echo "apk db mtime: $(date -r /lib/apk/db/installed '+%s %F %T')"
REMOTE
