#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
P=/root/xfree-toolbox/profiles/default/iface-routing/interfaces
for iface in proton warp warp3; do
  echo "===== $iface ====="
  m="$P/$iface/config/source.conf.meta"
  if [ -f "$m" ]; then
    grep -E '^(GENERATOR_KIND|SERVER_|COUNTRY|ENDPOINT_|SELECTION|EXCLUDE)' "$m" || true
  else
    echo "(no meta)"
  fi
done
REMOTE
