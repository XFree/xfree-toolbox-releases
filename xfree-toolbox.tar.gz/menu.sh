#!/bin/sh
# shellcheck shell=sh
# Entry: stable launcher path (xft, deploy). Logic in menu.gen.sh + menu.startup.sh.
set -eu

_script="$(readlink -f "$0" 2>/dev/null || printf '%s' "$0")"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$_script")" && pwd -P)"
ROOT_DIR="$SCRIPT_DIR"

# `sh` so WSL /mnt/d does not depend on +x or a shebang (CRLF shebang → exec: not found).
exec sh "$ROOT_DIR/menu.gen.sh" "${1:-ui}"
