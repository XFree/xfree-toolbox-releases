#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
scp "${SCP_OPTS[@]}" \
  diagnostics/lib/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/lib/traffic-path.sh"
scp "${SCP_OPTS[@]}" \
  diagnostics/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/traffic-path.sh"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
chmod +x /root/xfree-toolbox/diagnostics/traffic-path.sh
echo '=== state/dns sections ==='
ls /etc/xfree-toolbox/dns-routing/state/dns 2>/dev/null || echo 'no state/dns'
echo '=== map ids ==='
awk -F'|' 'NF>=3 && $3!="" { print $3 }' /etc/xfree-toolbox/dns-routing/generated/dns-redirects.map 2>/dev/null | sort -u | head -40
echo '=== summary dns nodes ==='
/root/xfree-toolbox/diagnostics/traffic-path.sh summary | tr ',' '\n' | grep '"id":"dns:' || echo 'NO DNS NODES'
echo '=== count ==='
/root/xfree-toolbox/diagnostics/traffic-path.sh summary | tr ',' '\n' | grep -c '"id":"dns:' || true
REMOTE
