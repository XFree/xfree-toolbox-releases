#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
scp "${SCP_OPTS[@]}" \
  diagnostics/dns-check.sh \
  "$SSH_TARGET:$TB/diagnostics/dns-check.sh"
scp "${SCP_OPTS[@]}" \
  diagnostics/lib/dns-check.sh \
  "$SSH_TARGET:$TB/diagnostics/lib/dns-check.sh"
# Profile DNS sections + template copies (for sync later)
for t in default default-with-proton default-with-proton-ai; do
  scp "${SCP_OPTS[@]}" -r \
    "profile-templates/$t/dns-routing/dns/google-dns-no-doh" \
    "profile-templates/$t/dns-routing/dns/dns.google" \
    "$SSH_TARGET:$TB/profile-templates/$t/dns-routing/dns/" 2>/dev/null || true
  scp "${SCP_OPTS[@]}" \
    "profile-templates/$t/https-dns-proxy/https-dns-proxy" \
    "$SSH_TARGET:$TB/profile-templates/$t/https-dns-proxy/https-dns-proxy" 2>/dev/null || true
done
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
TB=/root/xfree-toolbox
chmod +x "$TB/diagnostics/dns-check.sh"
chmod 644 "$TB/diagnostics/lib/dns-check.sh"
# Active profile workspace
AP="$(cat /etc/xfree-toolbox/active-profile 2>/dev/null || echo default)"
PDIR="$TB/profiles/$AP/dns-routing/dns"
mkdir -p "$PDIR/google-dns-no-doh/config" "$PDIR/dns.google/config"
cp -f "$TB/profile-templates/default/dns-routing/dns/google-dns-no-doh/config/dns.conf" \
  "$PDIR/google-dns-no-doh/config/dns.conf"
cp -f "$TB/profile-templates/default/dns-routing/dns/dns.google/config/dns.conf" \
  "$PDIR/dns.google/config/dns.conf"
# Ensure https-dns-proxy listen 5062
if ! uci -q show https-dns-proxy | grep -Fq "listen_port='5062'"; then
  idx="$(uci add https-dns-proxy https-dns-proxy)"
  uci set "https-dns-proxy.$idx.resolver_url=https://dns.google/dns-query"
  uci set "https-dns-proxy.$idx.bootstrap_dns=8.8.8.8,8.8.4.4"
  uci set "https-dns-proxy.$idx.listen_addr=127.0.0.1"
  uci set "https-dns-proxy.$idx.listen_port=5062"
  uci set "https-dns-proxy.$idx.user=nobody"
  uci set "https-dns-proxy.$idx.group=nogroup"
  uci commit https-dns-proxy
  if [ -x /etc/init.d/https-dns-proxy ]; then
    /etc/init.d/https-dns-proxy restart 2>/dev/null || true
    sleep 2
  fi
fi
# Smoke: print-only shows Google
sh "$TB/diagnostics/dns-check.sh" --print-only 2>&1 | grep -E '8\.8\.8\.8#53|127\.0\.0\.1#5062|Секции' | head -20
# Quick parallel check on tiny host set
export XFREE_DNS_CHECK_HOSTS='ya.ru example.com'
sh "$TB/diagnostics/dns-check.sh" --bg-start 2>&1 | head -15
REMOTE
