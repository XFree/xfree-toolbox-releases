#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE' || true
set +e
echo "=== VERSION / etag ==="
cat /root/xfree-toolbox/VERSION 2>/dev/null
cat /root/xfree-toolbox/.update-etag 2>/dev/null | head -3
ls -la /root/xfree-toolbox/VERSION /root/xfree-toolbox/.update-etag 2>/dev/null
echo "=== apk policy ==="
apk policy xfree-toolbox 2>/dev/null | head -20
echo "=== profile-templates xft ==="
find /root/xfree-toolbox/profile-templates -name 'user__group__xft.lst' 2>/dev/null
echo "=== active profile dns xft ==="
. /root/xfree-toolbox/lib/common.sh 2>/dev/null
load_base_config /root/xfree-toolbox 2>/dev/null
p="$(common_active_profile_name /root/xfree-toolbox 2>/dev/null)"
echo "active=$p"
find "/root/xfree-toolbox/profiles/$p/dns-routing" -name 'user__group__xft.lst' 2>/dev/null
echo "=== dns.google fqdn.d ==="
ls -la "/root/xfree-toolbox/profiles/$p/dns-routing/dns/dns.google/fqdn.d" 2>/dev/null
ls -la /root/xfree-toolbox/profile-templates/*/dns-routing/dns/dns.google/fqdn.d 2>/dev/null
echo "=== cloudflare-dns-no-doh fqdn.d ==="
ls -la "/root/xfree-toolbox/profiles/$p/dns-routing/dns/cloudflare-dns-no-doh/fqdn.d" 2>/dev/null
ls -la /root/xfree-toolbox/profile-templates/*/dns-routing/dns/cloudflare-dns-no-doh/fqdn.d 2>/dev/null
echo "=== done ==="
REMOTE
