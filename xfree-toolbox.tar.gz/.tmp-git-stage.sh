#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils

git add -A

# Unstage local probe/deploy junk and accidental empty filename.
while IFS= read -r path; do
  [ -n "$path" ] || continue
  case "$path" in
    .tmp*|.tmp-luci-shots|.tmp-luci-shots/*|\;)
      git reset HEAD -- "$path" >/dev/null 2>&1 || true
      ;;
  esac
done <<EOF
$(git diff --cached --name-only; git ls-files --others --exclude-standard)
EOF

# Extra: untracked tmp must not stay staged if somehow added.
git ls-files --cached | while IFS= read -r path; do
  case "$path" in
    .tmp*|\;)
      git rm -f --cached -- "$path" >/dev/null 2>&1 || true
      ;;
  esac
done

echo "staged files: $(git diff --cached --name-only | wc -l)"
echo "untracked tmp samples:"
git status --short | grep -E '^\?\? \.tmp|^\?\? ;' | head -20 || true
echo "staged sample:"
git diff --cached --name-only | head -40
