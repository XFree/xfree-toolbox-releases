#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"

ssh "${SSH_OPTS[@]}" "$SSH_TARGET" 'cat > /tmp/xfree-mx-stages.sh && sh /tmp/xfree-mx-stages.sh' <<'EOS'
set -eu
TB=/root/xfree-toolbox
export ROOT_DIR="$TB"
. "$TB/lib/common.sh"
. "$TB/lib/upstreams.sh"
. "$TB/lib/selection/upstream-selection.sh"
selection_upstream_init_all "$TB"
_cat=$(selection_catalog_prepare "$TB")
_cols=$(mktemp); _present=$(mktemp); _checked=$(mktemp); _tmp=$(mktemp)
: > "$_cols"; : > "$_present"

echo "files=$(_cat_lines=$(wc -l < "$_cat/files.tsv"); echo $_cat_lines) entities=$(wc -l < "$_cat/entities.tsv")"

echo "== iface register =="
/usr/bin/time -f "real=%e" sh -c '
  TB=/root/xfree-toolbox; . "$TB/lib/common.sh"; . "$TB/lib/upstreams.sh"
  . "$TB/lib/selection/upstream-selection.sh"; selection_upstream_init_all "$TB"
  _cols=$(mktemp); _present=$(mktemp); _tmp=$(mktemp); : > "$_cols"; : > "$_present"
  selection_iface_list_scope_ids > "$_tmp" 2>/dev/null || :
  while IFS= read -r id || [ -n "${id:-}" ]; do
    [ -n "${id:-}" ] || continue
    selection_matrix_register_scope iface "$id" "$id" all "$_cols" "$_present"
  done < "$_tmp"
  echo "cols=$(wc -l < "$_cols") present=$(wc -l < "$_present")"
  rm -f "$_cols" "$_present" "$_tmp"
'

echo "== dns register =="
/usr/bin/time -f "real=%e" sh -c '
  TB=/root/xfree-toolbox; . "$TB/lib/common.sh"; . "$TB/lib/upstreams.sh"
  . "$TB/lib/selection/upstream-selection.sh"; selection_upstream_init_all "$TB"
  _cols=$(mktemp); _present=$(mktemp); _tmp=$(mktemp); : > "$_cols"; : > "$_present"
  if command -v dns_routing_list_instances_tsv >/dev/null 2>&1; then
    dns_routing_list_instances_tsv > "$_tmp" 2>/dev/null || true
  fi
  while IFS="|" read -r idx id host t u || [ -n "${id:-}" ]; do
    [ -n "${id:-}" ] || continue
    selection_matrix_register_scope dns "$id" "${host:-$id}" fqdn_only "$_cols" "$_present"
  done < "$_tmp"
  echo "cols=$(wc -l < "$_cols") present=$(wc -l < "$_present") dns_rows=$(wc -l < "$_tmp")"
  rm -f "$_cols" "$_present" "$_tmp"
'

echo "== zapret register =="
/usr/bin/time -f "real=%e" sh -c '
  TB=/root/xfree-toolbox; . "$TB/lib/common.sh"; . "$TB/lib/upstreams.sh"
  . "$TB/lib/selection/upstream-selection.sh"; selection_upstream_init_all "$TB"
  _cols=$(mktemp); _present=$(mktemp); _tmp=$(mktemp); : > "$_cols"; : > "$_present"
  if [ -d "${SELECTION_ZAPRET_SECTIONS:-}" ]; then
    for d in "$SELECTION_ZAPRET_SECTIONS"/*; do
      [ -d "$d" ] || continue
      id=$(basename "$d")
      if selection_zapret_section_on_p "$d/config/section.conf"; then lab="[ON] $id"; else lab="[OFF] $id"; fi
      printf "%s\t%s\n" "$id" "$lab" >> "$_tmp"
    done
  fi
  while IFS="$(printf "\t")" read -r id lab || [ -n "${id:-}" ]; do
    [ -n "${id:-}" ] || continue
    selection_matrix_register_scope zapret "$id" "$lab" all "$_cols" "$_present"
  done < "$_tmp"
  echo "cols=$(wc -l < "$_cols") present=$(wc -l < "$_present") sections=$(wc -l < "$_tmp")"
  rm -f "$_cols" "$_present" "$_tmp"
'

echo "== build full cols/present once, then time resolve+emit =="
: > "$_cols"; : > "$_present"
selection_iface_list_scope_ids > "$_tmp" 2>/dev/null || :
while IFS= read -r id || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope iface "$id" "$id" all "$_cols" "$_present"
done < "$_tmp"
: > "$_tmp"
if command -v dns_routing_list_instances_tsv >/dev/null 2>&1; then
  dns_routing_list_instances_tsv > "$_tmp" 2>/dev/null || true
fi
while IFS="|" read -r idx id host t u || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope dns "$id" "${host:-$id}" fqdn_only "$_cols" "$_present"
done < "$_tmp"
: > "$_tmp"
if [ -d "${SELECTION_ZAPRET_SECTIONS:-}" ]; then
  for d in "$SELECTION_ZAPRET_SECTIONS"/*; do
    [ -d "$d" ] || continue
    id=$(basename "$d")
    printf "%s\t%s\n" "$id" "$id" >> "$_tmp"
  done
fi
while IFS="$(printf "\t")" read -r id lab || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope zapret "$id" "$lab" all "$_cols" "$_present"
done < "$_tmp"
selection_zapret_disable_flags 2>/dev/null || true
echo "prepared cols=$(wc -l < "$_cols") present=$(wc -l < "$_present")"

# extract awk body to a temp script for timing
awk_script=$(sed -n '/^selection_matrix_resolve_checked()/,/^}/p' "$TB/lib/selection/upstream-selection.sh" | head -n -1 | tail -n +2)
# easier: call function timed via wrapping shell that only times the awk invocation
cat > /tmp/xfree-resolve-wrap.sh <<WRAP
set -eu
TB=/root/xfree-toolbox
. "\$TB/lib/common.sh"
. "\$TB/lib/upstreams.sh"
. "\$TB/lib/selection/upstream-selection.sh"
selection_upstream_init_all "\$TB"
selection_matrix_resolve_checked "$_cat/files.tsv" "$_cols" "$_present" "$_checked" \
  "${SELECTION_ZAPRET_DV4:-0}" "${SELECTION_ZAPRET_DV6:-0}"
WRAP
/usr/bin/time -f "resolve_checked(+source) real=%e" sh /tmp/xfree-resolve-wrap.sh
echo "checked=$(wc -l < "$_checked")"

cat > /tmp/xfree-emit-wrap.sh <<WRAP
set -eu
TB=/root/xfree-toolbox
. "\$TB/lib/selection/json.sh"
selection_json_emit_matrix "$_cat/entities.tsv" "$_cols" "$_checked" > /tmp/xfree-emit.json
WRAP
/usr/bin/time -f "emit_matrix(+json.sh) real=%e" sh /tmp/xfree-emit-wrap.sh
echo "emit_bytes=$(wc -c < /tmp/xfree-emit.json)"

# pure awk time: dump the awk from resolve by re-running with time on awk only
# replicate call args
_mx_files_tsv="$_cat/files.tsv"
_mx_cols="$_cols"
_mx_present="$_present"
_mx_checked="/tmp/xfree-checked2.tsv"
_mx_dv4="${SELECTION_ZAPRET_DV4:-0}"
_mx_dv6="${SELECTION_ZAPRET_DV6:-0}"
# pull awk program by invoking function... instead copy from file between quotes
# Use busybox time around a direct reimplementation call:
/usr/bin/time -f "resolve_fn_in_current_shell real=%e" sh -c '
  . /root/xfree-toolbox/lib/selection/upstream-selection.sh
  # already sourced above in parent — this is fresh
  selection_upstream_init_all /root/xfree-toolbox >/dev/null 2>&1 || true
' 2>&1 | head -1

# Time awk only by exporting and calling selection_matrix_resolve_checked from already-sourced shell:
(
  start=$(cut -d" " -f1 /proc/uptime)
  selection_matrix_resolve_checked "$_cat/files.tsv" "$_cols" "$_present" /tmp/xfree-checked3.tsv \
    "${SELECTION_ZAPRET_DV4:-0}" "${SELECTION_ZAPRET_DV6:-0}"
  end=$(cut -d" " -f1 /proc/uptime)
  awk -v s="$start" -v e="$end" 'BEGIN{printf "resolve_uptime_delta=%.3fs\n", e-s}'
)
(
  start=$(cut -d" " -f1 /proc/uptime)
  selection_json_emit_matrix "$_cat/entities.tsv" "$_cols" /tmp/xfree-checked3.tsv > /tmp/xfree-emit2.json
  end=$(cut -d" " -f1 /proc/uptime)
  awk -v s="$start" -v e="$end" 'BEGIN{printf "emit_uptime_delta=%.3fs\n", e-s}'
)
(
  start=$(cut -d" " -f1 /proc/uptime)
  : > "$_cols"; : > "$_present"
  selection_iface_list_scope_ids > "$_tmp" 2>/dev/null || :
  while IFS= read -r id || [ -n "${id:-}" ]; do
    [ -n "${id:-}" ] || continue
    selection_matrix_register_scope iface "$id" "$id" all "$_cols" "$_present"
  done < "$_tmp"
  : > "$_tmp"
  if command -v dns_routing_list_instances_tsv >/dev/null 2>&1; then
    dns_routing_list_instances_tsv > "$_tmp" 2>/dev/null || true
  fi
  while IFS="|" read -r idx id host t u || [ -n "${id:-}" ]; do
    [ -n "${id:-}" ] || continue
    selection_matrix_register_scope dns "$id" "${host:-$id}" fqdn_only "$_cols" "$_present"
  done < "$_tmp"
  : > "$_tmp"
  if [ -d "${SELECTION_ZAPRET_SECTIONS:-}" ]; then
    for d in "$SELECTION_ZAPRET_SECTIONS"/*; do
      [ -d "$d" ] || continue
      id=$(basename "$d")
      if selection_zapret_section_on_p "$d/config/section.conf"; then lab="[ON] $id"; else lab="[OFF] $id"; fi
      printf "%s\t%s\n" "$id" "$lab" >> "$_tmp"
    done
  fi
  while IFS="$(printf "\t")" read -r id lab || [ -n "${id:-}" ]; do
    [ -n "${id:-}" ] || continue
    selection_matrix_register_scope zapret "$id" "$lab" all "$_cols" "$_present"
  done < "$_tmp"
  end=$(cut -d" " -f1 /proc/uptime)
  awk -v s="$start" -v e="$end" 'BEGIN{printf "all_register_uptime_delta=%.3fs cols=%d present=%d\n", e-s, '"$(wc -l < "$_cols")"'", '"$(wc -l < "$_present")"'}'
)

echo "== old N x enabled_tags (zapret only) =="
(
  start=$(cut -d" " -f1 /proc/uptime)
  n=0
  for d in "$SELECTION_ZAPRET_SECTIONS"/*; do
    [ -d "$d" ] || continue
    n=$((n+1))
    upstreams_build_enabled_tags_tsv zapret "$_cat/files.tsv" \
      "$d/fqdn.d" "$d/prefixes.d" all \
      "${SELECTION_ZAPRET_DV4:-0}" "${SELECTION_ZAPRET_DV6:-0}" >/dev/null
  done
  end=$(cut -d" " -f1 /proc/uptime)
  awk -v s="$start" -v e="$end" -v n="$n" 'BEGIN{printf "old_zapret_enabled_tags=%.3fs sections=%d\n", e-s, n}'
)

rm -f "$_cols" "$_present" "$_checked" "$_tmp"
EOS
