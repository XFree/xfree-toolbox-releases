#!/bin/sh
# shellcheck shell=sh
# Remove profiles/<name>/ (workspace only). Never touches profile-templates/.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"

load_base_config "$ROOT_DIR"

PROFILE_NAME=""
ALLOW_ACTIVE=0

usage() {
  cat <<EOF
Usage: $(basename "$0") --profile <name> [--allow-active]

Deletes the working profile directory profiles/<name>/.
Does not modify profile-templates/.

By default refuses to delete the active profile (XFREE_PROFILE).
Use --allow-active only from automation that already retargeted config.

Options:
  --profile <name>   Profile directory name under profiles/
  --allow-active     Allow deleting the currently active profile
  -h, --help
EOF
  exit 2
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --profile)
      [ "$#" -ge 2 ] || usage
      PROFILE_NAME="$2"
      shift 2
      ;;
    --allow-active)
      ALLOW_ACTIVE=1
      shift
      ;;
    -h|--help)
      usage
      ;;
    *)
      usage
      ;;
  esac
done

PROFILE_NAME="$(common_sanitize_profile_name "$PROFILE_NAME" 2>/dev/null)" || {
  echo "[!] Invalid or empty --profile" >&2
  exit 1
}

profiles_dir="$(common_profiles_dir "$ROOT_DIR")"
profile_dir="$profiles_dir/$PROFILE_NAME"

case "$profile_dir" in
  "$profiles_dir"/*) ;;
  *)
    echo "[!] Refusing path outside profiles/: $profile_dir" >&2
    exit 1
    ;;
esac

[ -d "$profile_dir" ] || {
  echo "[!] Profile not found: profiles/$PROFILE_NAME" >&2
  exit 1
}

# Resolve symlinks; still must stay under profiles/.
resolved="$(CDPATH= cd -- "$profile_dir" && pwd -P)"
profiles_resolved="$(CDPATH= cd -- "$profiles_dir" && pwd -P)"
case "$resolved" in
  "$profiles_resolved"/*) ;;
  *)
    echo "[!] Refusing resolved path outside profiles/: $resolved" >&2
    exit 1
    ;;
esac

active="$(common_active_profile_name "$ROOT_DIR")"
applied="$(common_applied_profile_name 2>/dev/null || true)"
if [ "$ALLOW_ACTIVE" != "1" ] && [ "$PROFILE_NAME" = "$active" ]; then
  echo "[!] Refusing to delete active profile: $PROFILE_NAME" >&2
  echo "[!] Switch active profile first, or pass --allow-active." >&2
  exit 1
fi
if [ "$ALLOW_ACTIVE" != "1" ] && [ -n "${applied:-}" ] && [ "$PROFILE_NAME" = "$applied" ]; then
  echo "[!] Refusing to delete applied profile: $PROFILE_NAME" >&2
  echo "[!] Apply another profile first, or pass --allow-active." >&2
  exit 1
fi

rm -rf -- "$resolved"
if [ -n "${applied:-}" ] && [ "$PROFILE_NAME" = "$applied" ]; then
  common_clear_applied_profile 2>/dev/null || true
fi
echo "[+] Deleted profiles/$PROFILE_NAME"
exit 0
