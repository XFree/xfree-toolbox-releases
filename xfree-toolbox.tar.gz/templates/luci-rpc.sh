#!/bin/sh
# shellcheck shell=sh
# LuCI ubus helper: catalog of templates/profiles and invoke of CLI-equivalent ops.
# Called from /usr/libexec/rpcd/xfree-toolbox (templatesMenu).
# stdout = JSON. Not for interactive TTY.
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
export ROOT_DIR

. /usr/share/libubox/jshn.sh
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"
. "$ROOT_DIR/lib/background-tasks.sh"

json_fail() {
	json_init
	json_add_int code 1
	json_add_int running 0
	json_add_string stdout ""
	json_add_string stderr "$1"
	json_dump
}

_dummy_clear() {
	case "$1" in
		-|"" ) printf '' ;;
		*) printf '%s' "$1" ;;
	esac
}

_sanitize() {
	common_sanitize_profile_name "${1:-}" 2>/dev/null || true
}

_json_add_name_array() {
	_arr="$1"
	_tmp="$2"
	json_add_array "$_arr"
	if [ -f "$_tmp" ]; then
		while IFS= read -r _n || [ -n "$_n" ]; do
			[ -n "$_n" ] || continue
			json_add_string "" "$_n"
		done < "$_tmp"
	fi
	json_close_array
}

_json_add_template_ref() {
	_plist="$1"
	_pdir="$(common_profiles_dir "$ROOT_DIR" 2>/dev/null || true)"
	json_add_object templateRef
	if [ -n "$_pdir" ] && [ -f "$_plist" ]; then
		while IFS= read -r _n || [ -n "$_n" ]; do
			[ -n "$_n" ] || continue
			_meta="$_pdir/$_n/EXPORT-META.txt"
			_ref=""
			if [ -f "$_meta" ]; then
				_ref="$(awk -F= '
					/^[[:space:]]*TEMPLATE_REF=/ {
						v=$2
						sub(/^[[:space:]]*/, "", v)
						sub(/[[:space:]]*$/, "", v)
						gsub(/^"/, "", v); gsub(/"$/, "", v)
						print v
						exit
					}
				' "$_meta" 2>/dev/null || true)"
			fi
			[ -n "$_ref" ] || _ref="$_n"
			json_add_string "$_n" "$_ref"
		done < "$_plist"
	fi
	json_close_object
}

templates_luci_catalog() {
	_active="$(common_active_profile_name "$ROOT_DIR" 2>/dev/null || true)"
	_applied="$(common_applied_profile_name 2>/dev/null || true)"
	_tfile="$(mktemp)"
	_pfile="$(mktemp)"
	common_list_profile_template_dirnames "$ROOT_DIR" 2>/dev/null >"$_tfile" || true
	common_list_profile_dirnames "$ROOT_DIR" 2>/dev/null >"$_pfile" || true

	json_init
	json_add_int code 0
	json_add_string active "${_active:-}"
	json_add_string applied "${_applied:-}"
	_json_add_name_array templates "$_tfile"
	_json_add_name_array profiles "$_pfile"
	_json_add_template_ref "$_pfile"
	rm -f "$_tfile" "$_pfile"
	json_dump
}

templates_luci_status() {
	_running=0
	_task=""
	_pid=""
	_log=""
	_out=""
	_last_status=""
	_last_exit=""

	if bg_tasks_is_running; then
		_running=1
		_task="${BG_TASK_NAME:-}"
		_pid="${BG_TASK_PID:-}"
		_log="${BG_TASK_LOG_FILE:-}"
	elif bg_tasks_read_last_meta; then
		_task="${BG_TASK_LAST_NAME:-}"
		_log="${BG_TASK_LAST_LOG_FILE:-}"
		_last_status="${BG_TASK_LAST_STATUS:-}"
		_last_exit="${BG_TASK_LAST_EXIT_CODE:-}"
	fi

	if [ -n "$_log" ] && [ -f "$_log" ]; then
		_out="$(tail -n 220 "$_log" 2>/dev/null || true)"
	fi

	json_init
	json_add_int code 0
	json_add_int running "$_running"
	json_add_string task "$_task"
	json_add_string pid "$_pid"
	json_add_string log "$_log"
	json_add_string lastStatus "$_last_status"
	json_add_string lastExit "$_last_exit"
	json_add_string stdout "$_out"
	json_add_string stderr ""
	json_dump
}

templates_luci_start_bg() {
	_task="$1"
	shift
	_runner="$ROOT_DIR/lib/bg-task-run.sh"
	_log="${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}/${_task}.log"
	[ -f "$_runner" ] || {
		json_fail "missing: $_runner"
		return 0
	}
	if bg_tasks_is_running; then
		json_init
		json_add_int code 1
		json_add_int running 1
		json_add_string task "${BG_TASK_NAME:-}"
		json_add_string pid "${BG_TASK_PID:-}"
		json_add_string log "${BG_TASK_LOG_FILE:-}"
		json_add_string stdout ""
		json_add_string stderr "already running: ${BG_TASK_NAME:-task}"
		json_dump
		return 0
	fi
	(
		export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
		sh "$_runner" "$_task" --log "$_log" -- sh "$@"
	) >/dev/null 2>&1 &
	sleep 1
	templates_luci_status
}

templates_luci_run_sync() {
	_errf="$(mktemp)"
	_code=0
	_out=""
	_out="$(sh "$@" 2>"$_errf")" || _code=$?
	_err="$(cat "$_errf" 2>/dev/null || true)"
	rm -f "$_errf"
	json_init
	json_add_int code "$_code"
	json_add_int running 0
	json_add_string stdout "$_out"
	json_add_string stderr "$_err"
	json_dump
}

templates_luci_run() {
	_op="$1"
	_template="$(_sanitize "$(_dummy_clear "$2")")"
	_profile="$(_sanitize "$(_dummy_clear "$3")")"
	_force="$(_dummy_clear "$4")"
	case "$_force" in
		1|true|yes|on) _force=1 ;;
		*) _force=0 ;;
	esac

	case "$_op" in
	syncApply)
		[ -n "$_template" ] && [ -n "$_profile" ] || {
			json_fail "нужны шаблон и профиль"
			return 0
		}
		templates_luci_start_bg apply-template \
			"$ROOT_DIR/templates/update-and-apply-pipeline.sh" \
			"$ROOT_DIR" "$_template" "$_profile" 1 1 \
			"Обновить и применить: $_template" sync 0
		;;
    recreateApply)
		[ -n "$_template" ] && [ -n "$_profile" ] || {
			json_fail "нужны шаблон и профиль"
			return 0
		}
		templates_luci_start_bg apply-template \
			"$ROOT_DIR/templates/update-and-apply-pipeline.sh" \
			"$ROOT_DIR" "$_template" "$_profile" 1 1 \
			"Пересоздать и применить: $_template" instantiate 1
		;;
	restoreDiff)
		[ -n "$_profile" ] || {
			json_fail "нужен профиль"
			return 0
		}
		templates_luci_run_sync "$ROOT_DIR/templates/restore-profile-from-state.sh" \
			--diff-only --profile "$_profile"
		;;
	restoreApply)
		[ -n "$_profile" ] || {
			json_fail "нужен профиль"
			return 0
		}
		templates_luci_run_sync "$ROOT_DIR/templates/restore-profile-from-state.sh" \
			--profile "$_profile"
		;;
	deleteProfile)
		[ -n "$_profile" ] || {
			json_fail "нужен профиль"
			return 0
		}
		templates_luci_run_sync "$ROOT_DIR/templates/delete-profile.sh" \
			--profile "$_profile"
		;;
	instantiate)
		[ -n "$_template" ] && [ -n "$_profile" ] || {
			json_fail "нужны шаблон и имя профиля"
			return 0
		}
		_inst="$ROOT_DIR/templates/instantiate-profile-from-template.sh"
		if [ "$_force" = "1" ]; then
			templates_luci_start_bg instantiate-profile \
				"$_inst" --template "$_template" --profile "$_profile" --force
		else
			templates_luci_start_bg instantiate-profile \
				"$_inst" --template "$_template" --profile "$_profile"
		fi
		;;
	*)
		json_fail "unknown op: ${_op:-?}"
		;;
	esac
}

_action="$(_dummy_clear "${1:-}")"
case "$_action" in
catalog)
	templates_luci_catalog
	;;
status)
	templates_luci_status
	;;
run)
	templates_luci_run "${2:-}" "${3:-}" "${4:-}" "${5:-}"
	;;
*)
	json_fail "usage: catalog | status | run <op> [template] [profile] [force]"
	;;
esac
