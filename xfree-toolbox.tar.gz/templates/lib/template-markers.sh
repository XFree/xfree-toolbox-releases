#!/bin/sh
# shellcheck shell=sh
# Shared template marker detection/cleanup for prepare-template.sh

template_marker_has_private_key_line() {
	file="$1"
	[ -f "$file" ] || return 1
	grep -q '^PrivateKey=' "$file" 2>/dev/null
}

template_iface_config_has_marker() {
	config_dir="$1"
	iface_dir="$2"
	[ -f "$config_dir/TEMPLATE" ] || [ -f "$iface_dir/TEMPLATE" ]
}

template_iface_config_is_materialized() {
	config_dir="$1"
	[ -f "$config_dir/network.uci" ] && template_marker_has_private_key_line "$config_dir/source.conf"
}

# Per-iface marker present and iface not yet materialized.
template_iface_config_needs_work() {
	config_dir="$1"
	iface_dir="$2"
	template_iface_config_has_marker "$config_dir" "$iface_dir" || return 1
	template_iface_config_is_materialized "$config_dir" && return 1
	return 0
}

template_tree_has_placeholder_tokens() {
	tree_root="$1"
	[ -d "$tree_root" ] || return 1
	if command -v rg >/dev/null 2>&1; then
		rg -q '\*\*\*RECREATE\*\*\*|\*\*\*PROMPT\*\*\*|\*\*\*GENERATE\*\*\*' "$tree_root" 2>/dev/null
		return $?
	fi
	grep -R -q -E '\*\*\*RECREATE\*\*\*|\*\*\*PROMPT\*\*\*|\*\*\*GENERATE\*\*\*' "$tree_root" 2>/dev/null
}

template_awg_dir_needs_work() {
	awg_dir="$1"
	[ -d "$awg_dir" ] || return 1
	if template_tree_has_placeholder_tokens "$awg_dir"; then
		return 0
	fi
	if [ -f "$awg_dir/server/server.env" ] && \
		grep -q '\*\*\*RECREATE\*\*\*' "$awg_dir/server/server.env" 2>/dev/null; then
		return 0
	fi
	if [ -d "$awg_dir/peers" ] && \
		grep -R -q -E '\*\*\*RECREATE\*\*\*|\*\*\*PROMPT\*\*\*' "$awg_dir/peers" 2>/dev/null; then
		return 0
	fi
	return 1
}

template_profile_iface_routing_has_pending_work() {
	profile_dir="$1"
	interfaces_dir="$2"
	[ -d "$interfaces_dir" ] || return 1

	iface_list_file="$(mktemp "${TMPDIR:-/tmp}/xfree-template-iface-list.XXXXXX")"
	find "$interfaces_dir" -mindepth 3 -maxdepth 3 -type f -path '*/config/iface.conf' 2>/dev/null | sort >"$iface_list_file"
	pending=1
	while IFS= read -r iface_conf; do
		[ -n "$iface_conf" ] || continue
		config_dir="$(dirname -- "$iface_conf")"
		iface_dir="$(dirname -- "$config_dir")"
		if template_iface_config_needs_work "$config_dir" "$iface_dir"; then
			pending=0
			break
		fi
	done <"$iface_list_file"
	rm -f "$iface_list_file"
	[ "$pending" -eq 0 ]
}

template_profile_has_pending_markers() {
	profile_dir="$1"
	interfaces_dir="${2:-$profile_dir/iface-routing/interfaces}"
	awg_dir="${3:-$profile_dir/awg-ingress}"

	if template_profile_iface_routing_has_pending_work "$profile_dir" "$interfaces_dir"; then
		return 0
	fi
	if template_awg_dir_needs_work "$awg_dir"; then
		return 0
	fi
	return 1
}

# Remove stale empty TEMPLATE files when nothing remains to materialize.
template_profile_cleanup_stale_markers() {
	profile_dir="$1"
	interfaces_dir="${2:-$profile_dir/iface-routing/interfaces}"
	awg_dir="${3:-$profile_dir/awg-ingress}"
	log_fn="${4:-:}"

	if [ -d "$interfaces_dir" ]; then
		iface_list_file="$(mktemp "${TMPDIR:-/tmp}/xfree-template-iface-list.XXXXXX")"
		find "$interfaces_dir" -mindepth 3 -maxdepth 3 -type f -path '*/config/iface.conf' 2>/dev/null | sort >"$iface_list_file"
		while IFS= read -r iface_conf; do
			[ -n "$iface_conf" ] || continue
			config_dir="$(dirname -- "$iface_conf")"
			iface_dir="$(dirname -- "$config_dir")"
			iface="$(basename -- "$iface_dir")"
			if template_iface_config_has_marker "$config_dir" "$iface_dir" && \
				template_iface_config_is_materialized "$config_dir"; then
				[ -f "$config_dir/TEMPLATE" ] && rm -f "$config_dir/TEMPLATE" 2>/dev/null || true
				[ -f "$iface_dir/TEMPLATE" ] && rm -f "$iface_dir/TEMPLATE" 2>/dev/null || true
				"$log_fn" "iface-routing template: снят устаревший маркер $iface (уже подготовлен)"
			fi
		done <"$iface_list_file"
		rm -f "$iface_list_file"
	fi

	if ! template_profile_iface_routing_has_pending_work "$profile_dir" "$interfaces_dir"; then
		if [ -f "$interfaces_dir/TEMPLATE" ]; then
			rm -f "$interfaces_dir/TEMPLATE" 2>/dev/null || true
			"$log_fn" "iface-routing template: снят устаревший маркер interfaces/TEMPLATE"
		fi
		if [ -f "$profile_dir/iface-routing/TEMPLATE" ]; then
			rm -f "$profile_dir/iface-routing/TEMPLATE" 2>/dev/null || true
			"$log_fn" "iface-routing template: снят устаревший маркер iface-routing/TEMPLATE"
		fi
	fi

	if ! template_awg_dir_needs_work "$awg_dir"; then
		if [ -f "$awg_dir/TEMPLATE" ]; then
			rm -f "$awg_dir/TEMPLATE" 2>/dev/null || true
			"$log_fn" "AWG ingress: снят устаревший маркер awg-ingress/TEMPLATE"
		fi
	fi

	if ! template_profile_has_pending_markers "$profile_dir" "$interfaces_dir" "$awg_dir"; then
		if [ -f "$profile_dir/TEMPLATE" ]; then
			rm -f "$profile_dir/TEMPLATE" 2>/dev/null || true
			"$log_fn" "template: снят устаревший маркер профиля TEMPLATE"
		fi
	fi
}
