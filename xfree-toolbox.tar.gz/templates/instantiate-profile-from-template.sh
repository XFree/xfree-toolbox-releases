#!/bin/sh
# shellcheck shell=sh
# Copy profile-templates/<template> -> profiles/<profile>, then prepare-template.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/profile-from-template-lib.sh"

load_base_config "$ROOT_DIR"

TEMPLATE_NAME=""
PROFILE_NAME=""
FORCE=0
RECREATED=0
COPY_ONLY=0
PREPARE_ONLY=0
PREPARE_SCRIPT="${PREPARE_SCRIPT:-$SCRIPT_DIR/prepare-template.sh}"

usage() {
  cat <<EOF
Usage: $(basename "$0") --template <id> --profile <name> [options]

Copies a reusable template from profile-templates/<template>/ into
profiles/<profile>/ (all module trees + TEMPLATE markers), then runs
prepare-template for iface-routing and awg-ingress.

A missing directory is resolved via TEMPLATE_ALIAS (see sync-profile-from-template.sh).
TEMPLATE_REF in the new profile meta is the surviving directory name.

Options:
  --force     Replace existing profiles/<profile>/ directory
  --recreated Mark EXPORT-META as recreated (menu: пересоздать существующий)
  --copy-only   Only copy template -> profile (no prepare-template)
  --prepare-only  Only prepare-template (profile must already exist)
  -h, --help
EOF
  exit 2
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --template)
      shift
      [ "$#" -gt 0 ] || xfree_pt_die "Не указано значение для --template"
      TEMPLATE_NAME="$1"
      ;;
    --profile)
      shift
      [ "$#" -gt 0 ] || xfree_pt_die "Не указано значение для --profile"
      PROFILE_NAME="$1"
      ;;
    --force) FORCE=1 ;;
    --recreated) RECREATED=1 ;;
    --copy-only) COPY_ONLY=1 ;;
    --prepare-only) PREPARE_ONLY=1 ;;
    -h | --help) usage ;;
    *)
      xfree_pt_die "Неизвестный аргумент: $1"
      ;;
  esac
  shift || true
done

[ -n "$TEMPLATE_NAME" ] && [ -n "$PROFILE_NAME" ] || usage

TEMPLATE_NAME="$(common_sanitize_profile_name "$TEMPLATE_NAME")" || xfree_pt_die "Некорректное имя шаблона"
PROFILE_NAME="$(common_sanitize_profile_name "$PROFILE_NAME")" || xfree_pt_die "Некорректное имя профиля"

_pt_rc=0
_pt_canonical="$(common_profile_template_resolve_id "$ROOT_DIR" "$TEMPLATE_NAME")" || _pt_rc=$?
if [ "$_pt_rc" -eq 2 ]; then
  xfree_pt_die "Неоднозначный алиас шаблона: $TEMPLATE_NAME"
fi
if [ "$_pt_rc" -ne 0 ] || [ -z "$_pt_canonical" ]; then
  xfree_pt_die "Шаблон не найден: $TEMPLATE_NAME"
fi
if [ "$_pt_canonical" != "$TEMPLATE_NAME" ]; then
  xfree_pt_info "[*] Каталог profile-templates/$TEMPLATE_NAME отсутствует; алиас -> $_pt_canonical (TEMPLATE_REF будет записан как $_pt_canonical)"
fi
TEMPLATE_NAME="$_pt_canonical"

template_dir="$(common_profile_template_resolve_dir "$ROOT_DIR" "$TEMPLATE_NAME")"
profile_dir="$(common_profile_resolve_dir "$ROOT_DIR" "$PROFILE_NAME")"

[ -d "$template_dir" ] || xfree_pt_die "Шаблон не найден: $template_dir"

if [ "$COPY_ONLY" = "1" ] && [ "$PREPARE_ONLY" = "1" ]; then
  xfree_pt_die "Нельзя совмещать --copy-only и --prepare-only"
fi

if [ "$PREPARE_ONLY" != "1" ]; then
  if [ -e "$profile_dir" ]; then
    if [ "$FORCE" != "1" ]; then
      if xfree_pt_profile_is_materialized "$profile_dir"; then
        xfree_pt_die "Профиль уже существует: $profile_dir (используйте --force)"
      fi
      xfree_pt_info "[*] Профиль неполный или пустой — пересоздаём без --force"
      xfree_pt_remove_path "$profile_dir"
    else
      xfree_pt_remove_path "$profile_dir"
    fi
  fi

  xfree_pt_info "[*] Копирование шаблона $TEMPLATE_NAME -> profiles/$PROFILE_NAME"
  xfree_pt_copy_full_template_to_profile "$template_dir" "$profile_dir"
  xfree_pt_write_profile_meta_instantiate "$profile_dir" "$PROFILE_NAME" "$TEMPLATE_NAME" "$RECREATED"
  xfree_pt_info "[+] Скопировано: $profile_dir"
fi

if [ "$COPY_ONLY" = "1" ]; then
  exit 0
fi

[ -d "$profile_dir" ] || xfree_pt_die "Профиль не найден для prepare: $profile_dir"

[ -f "$PREPARE_SCRIPT" ] || xfree_pt_die "Не найден prepare-template: $PREPARE_SCRIPT"
[ -x "$PREPARE_SCRIPT" ] || chmod +x "$PREPARE_SCRIPT" 2>/dev/null || true

xfree_pt_info "[*] маркеры TEMPLATE (iface-routing + awg-ingress)…"
if ! PROFILE_DIR="$profile_dir" sh "$PREPARE_SCRIPT" \
  --profile-dir "$profile_dir" \
  --iface-routing \
  --awg-ingress; then
  xfree_pt_die "не удалось материализовать маркеры TEMPLATE"
fi

xfree_pt_info "[+] профиль: $profile_dir"
xfree_pt_info "[*] Применение: меню «Обновить и применить» или «Пересоздать и применить»"
