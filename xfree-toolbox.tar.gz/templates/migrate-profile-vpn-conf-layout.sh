#!/bin/sh
# shellcheck shell=sh
# One-time: profiles/<name>/vpn/{proton,warp}/*.conf -> .../conf/*.conf
# (does not touch sessions/ or other subdirs)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/operator-store-layout.sh"
load_base_config "$ROOT_DIR"

PROFILES_DIR="$(common_profiles_dir "$ROOT_DIR")"
DRY_RUN=0

usage() {
    cat <<EOF
Usage: $(basename "$0") [--dry-run] [--profiles-dir DIR]

Move legacy flat VPN configs into vpn/<provider>/conf/ under each profile.
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --dry-run) DRY_RUN=1; shift ;;
        --profiles-dir)
            shift
            [ "$#" -gt 0 ] || die "Не указано значение для --profiles-dir"
            PROFILES_DIR="$1"
            shift
            ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
done

[ -d "$PROFILES_DIR" ] || {
    info "Каталог profiles не найден: $PROFILES_DIR"
    exit 0
}

migrate_provider_conf() {
    profile_root="$1"
    provider="$2"
    legacy=""
    target=""

    case "$provider" in
        proton)
            legacy="$(xfree_profile_legacy_proton_conf_dir "$profile_root")"
            target="$(xfree_profile_proton_conf_dir "$profile_root")"
            ;;
        warp)
            legacy="$(xfree_profile_legacy_warp_conf_dir "$profile_root")"
            target="$(xfree_profile_warp_conf_dir "$profile_root")"
            ;;
        *) return 0 ;;
    esac

    [ -d "$legacy" ] || return 0
    xfree_profile_dir_has_conf_files "$legacy" || return 0

    if [ "$DRY_RUN" = "1" ]; then
        info "[dry-run] mkdir -p $target"
    else
        mkdir -p "$target"
    fi

    for f in "$legacy"/*.conf "$legacy"/*.conf.meta; do
        [ -e "$f" ] || continue
        base="$(basename -- "$f")"
        dest="$target/$base"
        if [ -e "$dest" ]; then
            warn "Пропуск (уже есть): $dest"
            continue
        fi
        if [ "$DRY_RUN" = "1" ]; then
            info "[dry-run] mv $f -> $dest"
        else
            mv -- "$f" "$dest"
            info "Перенесено: $f -> $dest"
        fi
    done
}

for profile_dir in "$PROFILES_DIR"/*; do
    [ -d "$profile_dir" ] || continue
    profile_name="$(basename -- "$profile_dir")"
    info "Профиль: $profile_name"
    migrate_provider_conf "$profile_dir" proton
    migrate_provider_conf "$profile_dir" warp
done

success "Готово. Канон: profiles/<name>/vpn/<provider>/conf/*.conf"
