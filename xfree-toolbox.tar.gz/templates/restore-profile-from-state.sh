#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
MATERIALIZE_SCRIPT="${MATERIALIZE_SCRIPT:-$ROOT_DIR/system/materialize-profile-layout-from-state.sh}"
DIFF_CMD="${DIFF_CMD:-diff}"
DIFF_ONLY=0
TARGET_PROFILE=""

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

resolve_diff_cmd() {
    if command -v "$DIFF_CMD" >/dev/null 2>&1; then
        printf '%s\n' "$DIFF_CMD"
        return 0
    fi

    if command -v busybox >/dev/null 2>&1 && busybox --list 2>/dev/null | grep -Fxq diff; then
        printf '%s\n' "busybox diff"
        return 0
    fi

    return 1
}

show_profile_diff() {
    current_dir="$1"
    new_dir="$2"
    diff_file="$3"
    diff_runner="$(resolve_diff_cmd || true)"

    if [ -z "${diff_runner:-}" ]; then
        warn "Команда diff не найдена, сравнение пропущено"
        warn "Установите базовые пакеты toolbox или пакет diffutils"
        return 2
    fi

    if [ ! -e "$current_dir" ]; then
        info "Текущий профиль отсутствует, будет создан новый: $current_dir"
        return 1
    fi

    tmp_raw="${diff_file}.raw"
    if sh -c "$diff_runner -ruN \"\$1\" \"\$2\"" sh "$current_dir" "$new_dir" > "$tmp_raw"; then
        rm -f "$tmp_raw" 2>/dev/null || true
        info "Различий между текущим профилем и состоянием системы нет"
        return 0
    fi

    has_real_diff="$(
        awk '
            BEGIN { in_meta = 0; real = 0 }
            /^diff -ruN / {
                in_meta = ($0 ~ /EXPORT-META\.txt/)
                next
            }
            {
                if ($0 ~ /^[+-]/ && $0 !~ /^--- / && $0 !~ /^\+\+\+ /) {
                    if (in_meta == 1) {
                        if ($0 !~ /GENERATED_AT_UTC=/) real = 1
                    } else {
                        real = 1
                    }
                }
            }
            END { print real }
        ' "$tmp_raw"
    )"

    if [ "${has_real_diff:-0}" = "0" ]; then
        rm -f "$tmp_raw" 2>/dev/null || true
        info "Отличия есть только в GENERATED_AT_UTC (EXPORT-META.txt) — по контенту различий нет"
        rm -f "$diff_file" 2>/dev/null || true
        return 0
    fi

    cp "$tmp_raw" "$diff_file" 2>/dev/null || cp "$tmp_raw" "$diff_file"
    rm -f "$tmp_raw" 2>/dev/null || true
    info "Обнаружены отличия профиля от состояния системы"
    cat "$diff_file"
    return 1
}

main() {
    while [ "$#" -gt 0 ]; do
        case "$1" in
            --diff-only)
                DIFF_ONLY=1
                ;;
            --profile)
                shift
                [ "$#" -gt 0 ] || die "--profile требует имя"
                TARGET_PROFILE="$1"
                ;;
            -h|--help)
                cat <<EOF
Usage: $(basename "$0") [--diff-only] [--profile <name>]

  --diff-only   Show profile diff against system state without replacing profile.
  --profile     Restore into selected profile directory (default: active profile).
EOF
                exit 0
                ;;
            *)
                die "Неизвестный аргумент: $1"
                ;;
        esac
        shift || true
    done

    [ -x "$MATERIALIZE_SCRIPT" ] || chmod +x "$MATERIALIZE_SCRIPT" 2>/dev/null || true
    [ -f "$MATERIALIZE_SCRIPT" ] || die "Не найден materialize script: $MATERIALIZE_SCRIPT"

    if [ -n "${TARGET_PROFILE:-}" ]; then
        profile_name="$(sanitize_name "$TARGET_PROFILE")"
        [ -n "$profile_name" ] || die "Некорректное имя профиля: $TARGET_PROFILE"
        parent_dir="$(dirname -- "$PROFILE_DIR")"
        PROFILE_DIR="$parent_dir/$profile_name"
    else
        parent_dir="$(dirname -- "$PROFILE_DIR")"
        profile_name="$(basename -- "$PROFILE_DIR")"
    fi
    mkdir -p "$parent_dir"

    tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/xfree-profile-restore.XXXXXX")"
    cleanup() {
        rm -rf "$tmp_dir"
    }
    trap cleanup EXIT HUP INT TERM

    temp_profile_dir="$tmp_dir/$profile_name"
    diff_file="$tmp_dir/profile.diff"

    if [ "$DIFF_ONLY" = "1" ]; then
        info "Показываю различия профиля и состояния системы"
    else
        info "Восстанавливаю профиль из состояния системы"
    fi
    info "Profile: $PROFILE_DIR"
    info "State root: $STATE_ROOT"

    "$MATERIALIZE_SCRIPT" \
        --state-root "$STATE_ROOT" \
        --output "$temp_profile_dir" \
        --name "$profile_name" \
        --mode full \
        --no-strict-iface-export-contract

    show_profile_diff "$PROFILE_DIR" "$temp_profile_dir" "$diff_file" || true

    if [ "$DIFF_ONLY" = "1" ]; then
        success "Предпросмотр завершён, профиль не изменён"
        exit 0
    fi

    if [ -e "$PROFILE_DIR" ]; then
        rm -rf "$PROFILE_DIR"
    fi
    mv "$temp_profile_dir" "$PROFILE_DIR"

    success "Профиль восстановлен из состояния системы"
}

main "$@"
