#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
XFREE_TOOLBOX_ROOT="${XFREE_TOOLBOX_ROOT:-$ROOT_DIR}"

. "$ROOT_DIR/lib/common.sh"
# Intentional override from install-from-cloud / automation (survives env clear below).
_apply_profile_dir_explicit="${XFREE_APPLY_PROFILE_DIR:-}"
# Parent shells (install-from-cloud load_base_config, menu modules) may leave
# XFREE_PROFILE=default via config.sh `:=`; clear before re-read.
common_profile_env_clear_overrides
load_base_config "$ROOT_DIR"
if [ -n "${_apply_profile_dir_explicit:-}" ] && [ -d "$_apply_profile_dir_explicit" ]; then
    PROFILE_DIR="$_apply_profile_dir_explicit"
else
    PROFILE_DIR="$(common_profile_dir "$ROOT_DIR")"
fi
export PROFILE_DIR
INTERFACES_DIR="${INTERFACES_DIR:-$PROFILE_DIR/iface-routing/interfaces}"
export INTERFACES_DIR
# Обновление/применение шаблона всегда zapret (nfqws1). Zapret2 — только экспертное меню.
export ZAPRET_ENGINE=zapret
APPLY_LOG_FILE="${XFREE_APPLY_TEMPLATE_LOG_FILE:-${XFREE_BG_TASK_LOG_FILE:-${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}/apply-template.log}}"
APPLY_LOG_FIFO=""
APPLY_LOG_TEE_PID=""

PREPARE_SCRIPT="${PREPARE_SCRIPT:-$ROOT_DIR/templates/prepare-template.sh}"
AWG_ENSURE_SCRIPT="${AWG_ENSURE_SCRIPT:-$ROOT_DIR/awg-ingress/ensure-awg.sh}"
AWG_SETUP_SCRIPT="${AWG_SETUP_SCRIPT:-$ROOT_DIR/awg-ingress/setup-server.sh}"
AWG_APPLY_PEERS_SCRIPT="${AWG_APPLY_PEERS_SCRIPT:-$ROOT_DIR/awg-ingress/apply-peers.sh}"
AWG_SYNC_STATE_SCRIPT="${AWG_SYNC_STATE_SCRIPT:-$ROOT_DIR/awg-ingress/sync-state-from-uci.sh}"
APPLY_INTERFACE_SCRIPT="${APPLY_INTERFACE_SCRIPT:-$ROOT_DIR/iface-routing/apply-interfaces.sh}"
APPLY_ROUTING_SCRIPT="${APPLY_ROUTING_SCRIPT:-$ROOT_DIR/iface-routing/apply-routing.sh}"
APPLY_DNS_AND_IFACE_SCRIPT="${APPLY_DNS_AND_IFACE_SCRIPT:-$ROOT_DIR/lib/apply-dns-and-iface-routing.sh}"
ZAPRET_BOOTSTRAP_SCRIPT="${ZAPRET_BOOTSTRAP_SCRIPT:-$ROOT_DIR/zapret/bootstrap-runtime.sh}"
ZAPRET_APPLY_SCRIPT="${ZAPRET_APPLY_SCRIPT:-$ROOT_DIR/zapret/apply.sh}"
# shellcheck disable=SC1090
. "$ROOT_DIR/zapret/lib.sh"
HTTPS_DNS_APPLY_SCRIPT="${HTTPS_DNS_APPLY_SCRIPT:-$ROOT_DIR/https-dns-proxy/apply.sh}"
DNS_REDIRECT_APPLY_SCRIPT="${DNS_REDIRECT_APPLY_SCRIPT:-$ROOT_DIR/dns-routing/apply.sh}"
DNS_HOSTS_APPLY_SCRIPT="${DNS_HOSTS_APPLY_SCRIPT:-$ROOT_DIR/dns-routing/apply-hosts.sh}"

DO_PREPARE=1
DO_INGRESS=1
DO_INTERFACES=1
DO_ROUTING=1
DO_ZAPRET=1
DO_HTTPS_DNS=1
DO_DNS_REDIRECT=1
DO_DNS_HOSTS=1
PREPARE_WARNINGS_OK=1
LISTS_RUNTIME=0
RT_IFACE=0
RT_DNS=0
RT_ZAPRET_SECTIONS=""

apply_cleanup() {
    [ -n "${APPLY_LOG_FIFO:-}" ] && rm -f "$APPLY_LOG_FIFO" 2>/dev/null || true
    if [ -n "${APPLY_LOG_TEE_PID:-}" ]; then
        kill "$APPLY_LOG_TEE_PID" 2>/dev/null || true
        wait "$APPLY_LOG_TEE_PID" 2>/dev/null || true
    fi
}

apply_log_stream_start() {
    # bg-task-run уже пишет stdout в XFREE_BG_TASK_LOG_FILE (тот же APPLY_LOG_FILE).
    # Внутренний tee -a + echo на stdout родителя давал каждую строку в лог дважды.
    if [ "${XFREE_BG_TASK:-0}" = "1" ]; then
        return 0
    fi

    log_dir="$(dirname -- "$APPLY_LOG_FILE")"
    mkdir -p "$log_dir" 2>/dev/null || true
    : > "$APPLY_LOG_FILE" 2>/dev/null || true

    APPLY_LOG_FIFO="$(mktemp -u "${TMPDIR:-/tmp}/xfree-apply-template-log.XXXXXX")"
    if ! mkfifo "$APPLY_LOG_FIFO" 2>/dev/null; then
        return 0
    fi

    tee -a "$APPLY_LOG_FILE" <"$APPLY_LOG_FIFO" &
    APPLY_LOG_TEE_PID=$!
    exec >"$APPLY_LOG_FIFO" 2>&1
}

APPLY_EXIT_STATUS="failed"
trap apply_cleanup EXIT INT TERM HUP
apply_log_stream_start
info "apply-template: log=$APPLY_LOG_FILE pid=$$"

usage() {
    cat <<EOF
Usage: $(basename "$0") [options]

Apply profile to system. Обновить и Пересоздать — один пайплайн; отличаются
режимом копирования (списки vs шаблон целиком). prepare всегда: материализует
только незакрытые TEMPLATE.

Порядок (меню / WPS / install-from-cloud):
  0) toolbox upgrade + upstream download (без drift/zapret runtime)
  1) copy: sync = только списки (живой config/ сохраняется);
           instantiate --force = шаблон целиком
  2) https-dns-proxy (install + copy-config)
  3) dns-redirect (dns-routing/apply)
  4) zapret bootstrap (один раз)
  5) awg-ingress ensure (пакеты; restart+uplink только при установке)
  6) маркеры TEMPLATE — WARP/Proton (zapret skip, если шаг 4 уже был)
  7) awg-ingress setup-server + peers, hosts,
     apply-interfaces, apply-routing

Options:
  --prepare-strict         Fail on prepare warnings
  --skip-ingress           Skip AWG ingress setup
  --skip-interfaces        Skip interface apply loop
  --skip-routing           Skip apply-routing step
  --skip-zapret            Skip zapret install/copy step
  --skip-https-dns-proxy   Skip https-dns-proxy install/copy step
  --skip-dns-redirect      Skip dns-redirect apply step
  --skip-dns-hosts         Skip dns-routing/apply-hosts step
  --lists-runtime          Only apply list targets already in profile (no prepare/AWG/full template)
  --rt-iface               With --lists-runtime: dns+iface wrapper (lib/apply-dns-and-iface-routing.sh)
  --rt-dns                 With --lists-runtime: https-dns-proxy + dns-routing/apply
  --rt-zapret-sections CSV With --lists-runtime: zapret keys that triggered deploy (full profile→runtime)
  -h, --help               Show help
EOF
}

apply_lists_runtime_zapret_sections() {
    sections_csv="$1"
    [ -n "${sections_csv:-}" ] || return 0
    if ! profile_has_zapret; then
        warn "apply-template: zapret пропущен (нет zapret/ в профиле)"
        return 0
    fi

    info "apply-template: lists-runtime -> zapret (триггер секций: $(printf '%s' "$sections_csv" | tr ',' ' '); deploy: zapret_apply_profile_to_runtime)"
    run_with_visible_log zapret_apply_profile_to_runtime \
        || die "Не удалось применить zapret к runtime (zapret_apply_profile_to_runtime)"
    zapret_clear_pending_sections_queue
}

# Живой вывод на stdout (меню/pipe) + копия в файл для диагностики при ошибке.
run_with_visible_log() {
    out_file="$(mktemp "${TMPDIR:-/tmp}/xfree-apply-template-log.XXXXXX")"
    fifo="$(mktemp -u "${TMPDIR:-/tmp}/xfree-apply-template-fifo.XXXXXX")"
    cmd_rc=0

    if ! mkfifo "$fifo" 2>/dev/null; then
        if "$@" >"$out_file" 2>&1; then
            [ -s "$out_file" ] && cat "$out_file"
            rm -f "$out_file"
            return 0
        fi
        [ -s "$out_file" ] && cat "$out_file" >&2
        rm -f "$out_file"
        return 1
    fi

    tee "$out_file" <"$fifo" &
    tee_pid=$!
    set +e
    "$@" >"$fifo" 2>&1
    cmd_rc=$?
    set -e
    wait "$tee_pid" 2>/dev/null || true
    rm -f "$fifo"

    if [ "$cmd_rc" -eq 0 ]; then
        rm -f "$out_file"
        return 0
    fi
    # Live tee already printed the log; recat made Proton/WARP failure look like a second --all.
    rm -f "$out_file"
    return 1
}

list_interfaces() {
    [ -d "$INTERFACES_DIR" ] || return 0
    common_list_domain_interfaces "$INTERFACES_DIR"
}

profile_has_zapret() {
    [ -d "$PROFILE_DIR/zapret" ]
}

apply_zapret_bootstrap_from_profile() {
    step_label="$1"
    skip_if_pipeline="${2:-0}"
    bootstrap_extra=""
    if ! profile_has_zapret; then
        info "apply-template: $step_label -> zapret пропущен (нет zapret/ в профиле)"
        return 0
    fi
    if [ "$skip_if_pipeline" = "1" ] && [ "${XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE:-0}" = "1" ]; then
        info "apply-template: $step_label -> zapret bootstrap пропущен (уже применён в этом пайплайне)"
        return 0
    fi
    [ -f "$ZAPRET_BOOTSTRAP_SCRIPT" ] || die "Не найден zapret bootstrap script: $ZAPRET_BOOTSTRAP_SCRIPT"
    if [ "$skip_if_pipeline" = "1" ]; then
        bootstrap_extra="--skip-if-pipeline-applied"
    fi
    info "apply-template: $step_label -> zapret bootstrap (profile -> state/runtime)${bootstrap_extra:+ $bootstrap_extra}"
    # shellcheck disable=SC2086
    run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
        XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE="${XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE:-0}" \
        sh "$ZAPRET_BOOTSTRAP_SCRIPT" $bootstrap_extra \
        || die "Не удалось bootstrap zapret"
    export XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE=1
}

profile_has_https_dns_proxy() {
    [ -f "$PROFILE_DIR/https-dns-proxy/https-dns-proxy" ]
}

profile_has_dns_redirect() {
    [ -d "$PROFILE_DIR/dns-routing/dns" ] || return 1
    find "$PROFILE_DIR/dns-routing/dns" -type f -path '*/fqdn.d/*.lst' 2>/dev/null | sed -n '1p' | grep -q .
}

profile_apply_dns_hosts_needed() {
    hosts_root="$PROFILE_DIR/dns-routing/hosts"
    if [ -d "$hosts_root" ]; then
        find "$hosts_root" -type f 2>/dev/null | sed -n '1p' | grep -q . && return 0
    fi
    [ -f /etc/dnsmasq.d/hosts/additional.hosts ] && return 0
    uci -q show dhcp.@dnsmasq[0].addnhosts 2>/dev/null \
        | grep -Fq "'/etc/dnsmasq.d/hosts/additional.hosts'" && return 0
    return 1
}

# Как пункт «8» в awg-ingress/menu: peers из profiles/.../awg-ingress/peers -> UCI.
profile_awg_has_peer_dirs() {
    peers_root="$PROFILE_DIR/awg-ingress/peers"
    [ -d "$peers_root" ] || return 1
    for d in "$peers_root"/*; do
        [ -d "$d" ] || continue
        return 0
    done
    return 1
}

apply_https_dns_proxy_from_profile() {
    if ! profile_has_https_dns_proxy; then
        info "apply-template: шаг https-dns-proxy пропущен (нет конфига в профиле)"
        return 0
    fi
    [ -f "$HTTPS_DNS_APPLY_SCRIPT" ] || die "Не найден https-dns-proxy apply script: $HTTPS_DNS_APPLY_SCRIPT"
    info "apply-template: шаг https-dns-proxy -> install + copy-config"
    run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
        sh "$HTTPS_DNS_APPLY_SCRIPT" --yes --best-effort-install \
        || die "Не удалось применить https-dns-proxy (install/copy)"
}

apply_dns_redirect_from_profile() {
    if ! profile_has_dns_redirect; then
        info "apply-template: шаг dns-redirect пропущен (нет DNS списков в профиле)"
        return 0
    fi
    [ -f "$DNS_REDIRECT_APPLY_SCRIPT" ] || die "Не найден dns-redirect apply script: $DNS_REDIRECT_APPLY_SCRIPT"
    info "apply-template: шаг dns-redirect -> dns-routing/apply"
    run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
        sh "$DNS_REDIRECT_APPLY_SCRIPT" \
        || die "Не удалось применить dns-redirect"
}

apply_dns_hosts_from_profile() {
    if ! profile_apply_dns_hosts_needed; then
        info "apply-template: шаг dns-hosts пропущен (нет hosts в профиле и нечего снимать)"
        return 0
    fi
    [ -f "$DNS_HOSTS_APPLY_SCRIPT" ] || die "Не найден dns hosts apply script: $DNS_HOSTS_APPLY_SCRIPT"
    info "apply-template: шаг dns-hosts -> dns-routing/apply-hosts"
    run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
        sh "$DNS_HOSTS_APPLY_SCRIPT" --yes \
        || die "Не удалось применить dns hosts override"
}

apply_awg_ensure_from_profile() {
    AWG_ENSURE_DID_RESTART=0
    [ -f "$AWG_ENSURE_SCRIPT" ] || die "Не найден AWG ensure script: $AWG_ENSURE_SCRIPT"
    if ! command -v awg >/dev/null 2>&1; then
        AWG_ENSURE_DID_RESTART=1
    fi
    info "apply-template: шаг awg-ensure -> ensure-awg.sh --install-if-missing"
    run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
        sh "$AWG_ENSURE_SCRIPT" --install-if-missing \
        || die "Не удалось установить AWG (ensure-awg)"
    # network restart только если пакеты ставились. Иначе zapret уже жив — не сбрасывать skip-флаг.
    if [ "$AWG_ENSURE_DID_RESTART" = "1" ]; then
        info "apply-template: жду uplink/DNS после AWG…"
        common_wait_network_after_restart "${XFREE_NETWORK_WAIT_SEC:-90}" || \
            warn "apply-template: сеть не готова после AWG — prepare/WARP могут упасть"
    fi
}

apply_awg_setup_from_profile() {
    [ -f "$AWG_SETUP_SCRIPT" ] || die "Не найден AWG setup script: $AWG_SETUP_SCRIPT"
    info "apply-template: шаг awg-setup -> awg-ingress/setup-server"
    run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
        sh "$AWG_SETUP_SCRIPT" || die "Не удалось применить AWG ingress"
    if [ -f "$AWG_APPLY_PEERS_SCRIPT" ] && profile_awg_has_peer_dirs; then
        info "apply-template: шаг awg-setup -> awg-ingress/apply-peers"
        run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
            sh "$AWG_APPLY_PEERS_SCRIPT" || die "Не удалось применить AWG ingress peers"
    fi
    if [ -f "$AWG_SYNC_STATE_SCRIPT" ]; then
        info "apply-template: шаг awg-setup -> sync AWG state из UCI"
        run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
            sh "$AWG_SYNC_STATE_SCRIPT" || warn "Не удалось синхронизировать AWG state из UCI"
    fi
}

apply_prepare_from_profile() {
    [ -f "$PREPARE_SCRIPT" ] || die "Не найден prepare script: $PREPARE_SCRIPT"
    info "apply-template: шаг маркеры TEMPLATE"
    if [ "$PREPARE_WARNINGS_OK" = "1" ]; then
        run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
            XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE="${XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE:-0}" \
            sh "$PREPARE_SCRIPT" \
            || die "Не удалось материализовать маркеры TEMPLATE"
    else
        run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
            XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE="${XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE:-0}" \
            sh "$PREPARE_SCRIPT" --iface-routing --awg-ingress \
            || die "Не удалось материализовать маркеры TEMPLATE"
    fi
}

apply_interfaces_from_profile() {
    [ -f "$APPLY_INTERFACE_SCRIPT" ] || die "Не найден apply-interfaces script: $APPLY_INTERFACE_SCRIPT"
    interfaces="$(list_interfaces || true)"
    if [ -z "${interfaces:-}" ]; then
        warn "apply-template: интерфейсы не найдены, шаг apply-interfaces пропущен"
        return 0
    fi
    info "apply-template: шаг interfaces -> apply-interfaces (--all)"
    run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
        sh "$APPLY_INTERFACE_SCRIPT" --all || die "Не удалось применить интерфейсы"
}

apply_routing_from_profile() {
    if [ "$LISTS_RUNTIME" = "1" ]; then
        [ -f "$APPLY_DNS_AND_IFACE_SCRIPT" ] || die "Не найден apply-dns-and-iface-routing: $APPLY_DNS_AND_IFACE_SCRIPT"
        info "apply-template: lists-runtime -> lib/apply-dns-and-iface-routing"
        run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
            sh "$APPLY_DNS_AND_IFACE_SCRIPT" --profile-dir "$PROFILE_DIR" \
            || die "Не удалось применить DNS-redirect и маршрутизацию по спискам"
        return 0
    fi
    [ -f "$APPLY_ROUTING_SCRIPT" ] || die "Не найден apply-routing script: $APPLY_ROUTING_SCRIPT"
    info "apply-template: шаг routing -> iface-routing/apply-routing"
    run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" \
        sh "$APPLY_ROUTING_SCRIPT" || die "Не удалось применить маршрутизацию по спискам"
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --prepare-strict) PREPARE_WARNINGS_OK=0 ;;
        --skip-ingress) DO_INGRESS=0 ;;
        --skip-interfaces) DO_INTERFACES=0 ;;
        --skip-routing) DO_ROUTING=0 ;;
        --skip-zapret) DO_ZAPRET=0 ;;
        --skip-https-dns-proxy) DO_HTTPS_DNS=0 ;;
        --skip-dns-redirect) DO_DNS_REDIRECT=0 ;;
        --skip-dns-hosts) DO_DNS_HOSTS=0 ;;
        --lists-runtime)
            LISTS_RUNTIME=1
            DO_PREPARE=0
            DO_INGRESS=0
            DO_INTERFACES=0
            DO_ROUTING=0
            DO_ZAPRET=0
            DO_HTTPS_DNS=0
            DO_DNS_REDIRECT=0
            DO_DNS_HOSTS=0
            ;;
        --rt-iface)
            LISTS_RUNTIME=1
            RT_IFACE=1
            ;;
        --rt-dns)
            LISTS_RUNTIME=1
            RT_DNS=1
            ;;
        --rt-zapret-sections)
            shift
            [ "$#" -gt 0 ] || die "Не указано значение для --rt-zapret-sections"
            RT_ZAPRET_SECTIONS="$1"
            LISTS_RUNTIME=1
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift || true
done

if [ "$LISTS_RUNTIME" = "1" ]; then
    DO_PREPARE=0
    DO_INGRESS=0
    DO_INTERFACES=0
    DO_ROUTING=0
    DO_ZAPRET=0
    DO_HTTPS_DNS=0
    DO_DNS_REDIRECT=0
    DO_DNS_HOSTS=0
    [ "$RT_IFACE" = "1" ] && DO_ROUTING=1
    if [ "$RT_DNS" = "1" ]; then
        DO_HTTPS_DNS=1
        DO_DNS_REDIRECT=1
    fi
    # Wrapper at routing step already runs dns-routing/apply.
    if [ "$RT_IFACE" = "1" ]; then
        DO_DNS_REDIRECT=0
    fi
    if [ -z "${RT_ZAPRET_SECTIONS:-}" ] && [ "$RT_IFACE" != "1" ] && [ "$RT_DNS" != "1" ]; then
        die "Для --lists-runtime укажите --rt-iface, --rt-dns и/или --rt-zapret-sections"
    fi
    info "apply-template: режим lists-runtime (только выбранные runtime-шаги)"
fi

active_profile="$(common_active_profile_name "$ROOT_DIR")"
info "apply-template: активный профиль: $active_profile"
info "apply-template: PROFILE_DIR=$PROFILE_DIR"

if [ "$LISTS_RUNTIME" != "1" ]; then
    unset XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE 2>/dev/null || true
fi

# Один пайплайн: https-dns → dns-redirect → zapret → awg-ensure → prepare → rest.
# Copy снаружи. zapret один раз (до AWG). Конфиги WARP/Proton — после DNS+zapret.
if [ "$DO_HTTPS_DNS" = "1" ]; then
    apply_https_dns_proxy_from_profile
fi

if [ "$DO_DNS_REDIRECT" = "1" ]; then
    apply_dns_redirect_from_profile
fi

if [ "$DO_ZAPRET" = "1" ]; then
    apply_zapret_bootstrap_from_profile "zapret"
fi

if [ "$DO_INGRESS" = "1" ]; then
    apply_awg_ensure_from_profile
fi

if [ "$DO_PREPARE" = "1" ]; then
    apply_prepare_from_profile
fi

if [ "$DO_INGRESS" = "1" ]; then
    apply_awg_setup_from_profile
fi

if [ "$DO_DNS_HOSTS" = "1" ]; then
    apply_dns_hosts_from_profile
fi

if [ "$DO_INTERFACES" = "1" ]; then
    apply_interfaces_from_profile
fi

if [ "$DO_ROUTING" = "1" ]; then
    apply_routing_from_profile
fi

if [ -n "${RT_ZAPRET_SECTIONS:-}" ]; then
    apply_lists_runtime_zapret_sections "$RT_ZAPRET_SECTIONS" \
        || die "Не удалось применить секции zapret к runtime"
fi

if [ "$LISTS_RUNTIME" != "1" ]; then
    _usb_watch_lib="$ROOT_DIR/system/hardware/usb-power-watch-lib.sh"
    if [ -f "$_usb_watch_lib" ]; then
        # shellcheck disable=SC1090
        . "$_usb_watch_lib"
        export USB_WATCH_ROOT_DIR="$ROOT_DIR"
        if usb_watch_enable_connectivity_watch_default; then
            info "apply-template: connectivity-watch включён (cron, probe WAN/VPN, recovery)"
        else
            warn "apply-template: connectivity-watch не включён — Мониторинг канала → Включить периодическую проверку канала"
        fi
    else
        warn "apply-template: usb-power-watch-lib.sh не найден — connectivity-watch не включён"
    fi
    _auto_update_lib="$ROOT_DIR/system/auto-update-lib.sh"
    if [ -f "$_auto_update_lib" ]; then
        # shellcheck disable=SC1090
        . "$_auto_update_lib"
        export AUTO_UPDATE_ROOT_DIR="$ROOT_DIR"
        export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
        if auto_update_enable_default; then
            info "apply-template: автообновление включено (cron)"
        else
            warn "apply-template: автообновление не включено — Система → Включить автообновление"
        fi
    else
        warn "apply-template: auto-update-lib.sh не найден — автообновление не включено"
    fi
fi

if [ "$LISTS_RUNTIME" = "1" ]; then
    success "apply-template: списки применены к runtime"
else
    _applied_name="$(basename -- "$PROFILE_DIR")"
    if [ -n "${_applied_name:-}" ]; then
        common_write_applied_profile "$_applied_name" || \
            warn "apply-template: не удалось записать applied-profile.env ($_applied_name)"
        common_set_active_profile_in_config "$ROOT_DIR" "$_applied_name" || \
            warn "apply-template: не удалось обновить config.sh ($_applied_name)"
        common_profile_env_clear_dir_override
    fi
    success "apply-template: профиль применён к системе"
fi
APPLY_EXIT_STATUS="done"
