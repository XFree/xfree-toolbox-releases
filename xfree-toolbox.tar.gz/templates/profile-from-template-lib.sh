#!/bin/sh
# shellcheck shell=sh
# Shared copy/sync helpers: profile-templates/<t> -> profiles/<p>
set -eu

xfree_pt_die() {
  printf '%s\n' "$*" >&2
  exit 1
}

xfree_pt_info() {
  printf '%s\n' "$*"
}

# Top-level module trees copied on full instantiate (not upstreams).
xfree_pt_instantiate_module_names() {
  printf '%s\n' \
    iface-routing \
    dns-routing \
    zapret \
    awg-ingress \
    https-dns-proxy \
    vpn \
    vk-turn
}

xfree_pt_copy_tree() {
  src="$1"
  dst="$2"
  [ -d "$src" ] || return 0
  mkdir -p "$dst"
  cp -a "$src/." "$dst/"
}

xfree_pt_remove_path() {
  path="$1"
  [ -e "$path" ] || return 0
  rm -rf "$path"
}

# Готовый materialized-профиль: EXPORT-META + хотя бы один модульный каталог.
xfree_pt_profile_is_materialized() {
  profile_dir="$1"
  name=""

  [ -d "$profile_dir" ] || return 1
  [ -f "$profile_dir/EXPORT-META.txt" ] || return 1
  while IFS= read -r name; do
    [ -n "$name" ] || continue
    [ -d "$profile_dir/$name" ] && return 0
  done <<EOF
$(xfree_pt_instantiate_module_names)
EOF
  return 1
}

# Zapret2 — opt-in (экспертное меню). Instantiate/sync шаблона всегда nfqws1.
xfree_pt_zapret_keep_nfqws1() {
  zdir="$1/zapret"
  [ -d "$zdir" ] || return 0
  rm -f "$zdir/zapret.template.v2" "$zdir/engine.conf"
}

# Full copy from template into empty/overwritten profile directory.
xfree_pt_copy_full_template_to_profile() {
  template_dir="$1"
  profile_dir="$2"

  [ -d "$template_dir" ] || xfree_pt_die "Шаблон не найден: $template_dir"

  mkdir -p "$profile_dir"
  name=""
  while IFS= read -r name; do
    [ -n "$name" ] || continue
    xfree_pt_remove_path "$profile_dir/$name"
    [ -d "$template_dir/$name" ] || continue
    xfree_pt_copy_tree "$template_dir/$name" "$profile_dir/$name"
  done <<EOF
$(xfree_pt_instantiate_module_names)
EOF

  if [ -f "$template_dir/TEMPLATE" ]; then
    mkdir -p "$profile_dir"
    cp -f "$template_dir/TEMPLATE" "$profile_dir/TEMPLATE"
  else
    xfree_pt_remove_path "$profile_dir/TEMPLATE"
  fi
  xfree_pt_zapret_keep_nfqws1 "$profile_dir"

  xfree_pt_remove_path "$profile_dir/upstreams"
}

xfree_pt_write_profile_meta_instantiate() {
  profile_dir="$1"
  profile_name="$2"
  template_name="$3"
  recreated="$4"

  mkdir -p "$profile_dir"
  {
    printf 'EXPORT_NAME=%s\n' "$profile_name"
    printf 'TEMPLATE_REF=%s\n' "$template_name"
    printf 'CREATED_FROM_TEMPLATE=1\n'
    if [ "$recreated" = "1" ]; then
      printf 'RECREATED_FROM_TEMPLATE=1\n'
    fi
  } >"$profile_dir/EXPORT-META.txt"
}

# Copy entire module tree from template; optional stash root holds prepare artifacts to restore.
xfree_pt_sync_module_tree() {
  src_mod="$1"
  dst_mod="$2"
  [ -d "$src_mod" ] || {
    xfree_pt_remove_path "$dst_mod"
    return 0
  }
  xfree_pt_remove_path "$dst_mod"
  xfree_pt_copy_tree "$src_mod" "$dst_mod"
}

xfree_pt_stash_copy_file() {
  src="$1"
  stash_root="$2"
  relpath="$3"
  [ -f "$src" ] || return 0
  dst="$stash_root/$relpath"
  mkdir -p "$(dirname -- "$dst")"
  cp -f "$src" "$dst"
}

xfree_pt_stash_copy_tree() {
  src="$1"
  stash_root="$2"
  relpath="$3"
  [ -d "$src" ] || return 0
  dst="$stash_root/$relpath"
  xfree_pt_remove_path "$dst"
  xfree_pt_copy_tree "$src" "$dst"
}

xfree_pt_restore_stash_tree() {
  stash_root="$1"
  dst_root="$2"
  relpath="$3"
  src="$stash_root/$relpath"
  [ -d "$src" ] || return 0
  dst="$dst_root/$relpath"
  mkdir -p "$(dirname -- "$dst")"
  xfree_pt_copy_tree "$src" "$dst"
}

xfree_pt_restore_stash_files() {
  stash_root="$1"
  dst_root="$2"
  relpath_prefix="${3:-}"
  if [ -n "$relpath_prefix" ]; then
    stash_dir="$stash_root/$relpath_prefix"
  else
    stash_dir="$stash_root"
  fi
  [ -d "$stash_dir" ] || return 0
  find "$stash_dir" -type f 2>/dev/null | while IFS= read -r f; do
    [ -n "$f" ] || continue
    rel="${f#"$stash_dir"/}"
    if [ -n "$relpath_prefix" ]; then
      dst="$dst_root/$relpath_prefix/$rel"
    else
      dst="$dst_root/$rel"
    fi
    mkdir -p "$(dirname -- "$dst")"
    cp -f "$f" "$dst"
  done
}

# Live iface: source.conf already has a key and UCI was generated.
xfree_pt_iface_config_is_materialized() {
  cfg="$1"
  [ -f "$cfg/network.uci" ] || return 1
  [ -f "$cfg/source.conf" ] || return 1
  grep -q '^PrivateKey=' "$cfg/source.conf" 2>/dev/null
}

xfree_pt_tree_has_template_tokens() {
  tree="$1"
  [ -d "$tree" ] || return 1
  grep -R -q -E '\*\*\*RECREATE\*\*\*|\*\*\*PROMPT\*\*\*|\*\*\*GENERATE\*\*\*' "$tree" 2>/dev/null
}

# Sync iface-routing from template without wiping extra profile interfaces.
# Template-owned ifaces: replace lists; keep live config/ (source.conf, meta, UCI).
# Unprepared template ifaces: take the template tree (TEMPLATE + placeholders).
# Extra ifaces (not in the template): leave the whole tree intact.
# Recreate still uses xfree_pt_copy_full_template_to_profile (full module replace).
xfree_pt_sync_iface_routing() {
  src_root="$1/iface-routing"
  dst_root="$2/iface-routing"
  stash="$3"
  src_ifaces="$src_root/interfaces"
  dst_ifaces="$dst_root/interfaces"
  src_iface=""
  dst_iface=""
  name=""
  secret=""
  materialized_list="$stash/materialized-ifaces"

  [ -d "$src_root" ] || return 0

  mkdir -p "$dst_root" "$dst_ifaces" "$(dirname -- "$materialized_list")"
  : >"$materialized_list"

  # Do not plant (and drop leftover) parent TEMPLATE on a live profile:
  # apply-template/prepare would treat the profile as unprepared and rewrite
  # iface/AWG configs. New/unprepared ifaces still bring their own config/TEMPLATE.
  xfree_pt_remove_path "$dst_root/TEMPLATE"
  xfree_pt_remove_path "$dst_ifaces/TEMPLATE"

  [ -d "$src_ifaces" ] || return 0

  for src_iface in "$src_ifaces"/*; do
    [ -d "$src_iface" ] || continue
    name="$(basename -- "$src_iface")"
    dst_iface="$dst_ifaces/$name"
    if [ -d "$dst_iface" ] && xfree_pt_iface_config_is_materialized "$dst_iface/config"; then
      printf '%s\n' "$name" >>"$materialized_list"
      xfree_pt_stash_copy_tree \
        "$dst_iface/config" \
        "$stash" \
        "iface-routing/interfaces/$name/config"
    elif [ -d "$dst_iface" ]; then
      for secret in source.conf network.uci; do
        if [ -f "$dst_iface/config/$secret" ]; then
          xfree_pt_stash_copy_file \
            "$dst_iface/config/$secret" \
            "$stash" \
            "iface-routing/interfaces/$name/config/$secret"
        fi
      done
    fi
    xfree_pt_remove_path "$dst_iface"
    xfree_pt_copy_tree "$src_iface" "$dst_iface"
  done

  xfree_pt_restore_stash_files "$stash/iface-routing" "$dst_root" "interfaces"

  while IFS= read -r name; do
    [ -n "$name" ] || continue
    xfree_pt_remove_path "$dst_ifaces/$name/config/TEMPLATE"
    xfree_pt_remove_path "$dst_ifaces/$name/TEMPLATE"
  done <"$materialized_list"
}

xfree_pt_sync_awg_ingress() {
  src_root="$1/awg-ingress"
  dst_root="$2/awg-ingress"
  stash="$3"
  awg_dst="$2/awg-ingress"
  awg_stash="$stash/awg-ingress"

  if [ -d "$awg_dst" ]; then
    xfree_pt_stash_copy_tree "$awg_dst/migration" "$awg_stash" "migration"
    find "$awg_dst" -type f \
      \( -name 'private.key' -o -name 'public.key' -o -name 'client.conf' \) 2>/dev/null \
      | while IFS= read -r f; do
          [ -n "$f" ] || continue
          rel="${f#"$awg_dst"/}"
          xfree_pt_stash_copy_file "$f" "$awg_stash" "$rel"
        done
    find "$awg_dst" -type f \( -name 'server.env' -o -name 'peer.env' \) 2>/dev/null \
      | while IFS= read -r f; do
          [ -n "$f" ] || continue
          key_dir="$(dirname -- "$f")"
          [ -f "$key_dir/private.key" ] || continue
          rel="${f#"$awg_dst"/}"
          xfree_pt_stash_copy_file "$f" "$awg_stash" "$rel"
        done
  fi

  xfree_pt_sync_module_tree "$src_root" "$dst_root"
  xfree_pt_restore_stash_tree "$awg_stash" "$dst_root" "migration"
  xfree_pt_restore_stash_files "$awg_stash" "$dst_root"
  # Restored keys/env: do not leave TEMPLATE so prepare does not rematerialize.
  if [ -d "$dst_root" ] && ! xfree_pt_tree_has_template_tokens "$dst_root"; then
    xfree_pt_remove_path "$dst_root/TEMPLATE"
  fi
}

xfree_pt_sync_dns_routing() {
  # Full replace: template is the only delivery path (no ORIGIN=manual keep).
  xfree_pt_sync_module_tree "$1/dns-routing" "$2/dns-routing"
}

xfree_pt_sync_zapret() {
  src_root="$1/zapret"
  dst_root="$2/zapret"
  dst_sections="$dst_root/sections"
  stash_manual=""
  name=""
  origin_lib="${ROOT_DIR:-}/zapret/lib/section-origin.sh"

  if [ -f "$origin_lib" ]; then
    # shellcheck disable=SC1090
    . "$origin_lib"
  fi

  if [ -d "$dst_sections" ] && command -v zapret_section_dir_is_manual >/dev/null 2>&1; then
    stash_manual="$(mktemp -d "${TMPDIR:-/tmp}/xfree-pt-zapret-manual.XXXXXX")" || xfree_pt_die "Не удалось создать temp для zapret manual"
    for dst_section in "$dst_sections"/*; do
      [ -d "$dst_section" ] || continue
      zapret_section_dir_is_manual "$dst_section" || continue
      name="$(basename -- "$dst_section")"
      xfree_pt_copy_tree "$dst_section" "$stash_manual/$name"
    done
  fi

  xfree_pt_sync_module_tree "$src_root" "$dst_root"
  xfree_pt_zapret_keep_nfqws1 "$2"

  if [ -n "$stash_manual" ] && [ -d "$stash_manual" ]; then
    mkdir -p "$dst_root/sections"
    for dst_section in "$stash_manual"/*; do
      [ -d "$dst_section" ] || continue
      name="$(basename -- "$dst_section")"
      xfree_pt_remove_path "$dst_root/sections/$name"
      xfree_pt_copy_tree "$dst_section" "$dst_root/sections/$name"
    done
    rm -rf "$stash_manual"
  fi
}

xfree_pt_sync_https_dns_proxy() {
  xfree_pt_sync_module_tree "$1/https-dns-proxy" "$2/https-dns-proxy"
}

xfree_pt_sync_vk_turn() {
  xfree_pt_sync_module_tree "$1/vk-turn" "$2/vk-turn"
}

xfree_pt_sync_vpn() {
  src_root="$1/vpn"
  dst_root="$2/vpn"
  stash="$3"
  vpn_stash="$stash/vpn"

  if [ -d "$2/vpn/proton/sessions" ]; then
    xfree_pt_stash_copy_tree "$2/vpn/proton/sessions" "$vpn_stash" "proton/sessions"
  fi
  if [ -d "$2/vpn/warp" ]; then
    find "$2/vpn/warp" -type f 2>/dev/null | while IFS= read -r f; do
      [ -n "$f" ] || continue
      rel="${f#"$2/vpn"/}"
      xfree_pt_stash_copy_file "$f" "$vpn_stash" "$rel"
    done
  fi

  xfree_pt_sync_module_tree "$src_root" "$dst_root"
  xfree_pt_restore_stash_tree "$vpn_stash" "$dst_root" "proton/sessions"
  xfree_pt_restore_stash_files "$vpn_stash" "$dst_root" "warp"
}

xfree_pt_sync_profile_template_marker() {
  # $1=template_dir (unused; keep signature for callers)
  # Sync must not plant a profile-level TEMPLATE: prepare-template treats it as
  # "rematerialize AWG/ifaces". Per-iface and awg-ingress TEMPLATE cover gaps.
  :
  _profile_dir="$2"
  xfree_pt_remove_path "$_profile_dir/TEMPLATE"
}

# Portable sync: module trees from template; prepare outputs (keys, source.conf, …) preserved.
# iface-routing: only interfaces that exist in the template are replaced; extra
# profile interfaces are left intact. Zapret: toolbox sections are replaced from
# the template; ORIGIN=manual sections are restored after sync. Live config/ is
# kept; recreate (--force) may wipe extras.
xfree_pt_sync_template_to_profile() {
  template_dir="$1"
  profile_dir="$2"

  [ -d "$template_dir" ] || xfree_pt_die "Шаблон не найден: $template_dir"
  [ -d "$profile_dir" ] || xfree_pt_die "Профиль не найден: $profile_dir"

  stash="$(mktemp -d "${TMPDIR:-/tmp}/xfree-pt-sync.XXXXXX")" || xfree_pt_die "Не удалось создать temp для sync"
  # shellcheck disable=SC2064
  trap 'rm -rf "$stash"' EXIT INT HUP

  xfree_pt_sync_iface_routing "$template_dir" "$profile_dir" "$stash"
  xfree_pt_sync_awg_ingress "$template_dir" "$profile_dir" "$stash"
  xfree_pt_sync_dns_routing "$template_dir" "$profile_dir"
  xfree_pt_sync_zapret "$template_dir" "$profile_dir"
  xfree_pt_sync_https_dns_proxy "$template_dir" "$profile_dir"
  xfree_pt_sync_vk_turn "$template_dir" "$profile_dir"
  xfree_pt_sync_vpn "$template_dir" "$profile_dir" "$stash"
  xfree_pt_sync_profile_template_marker "$template_dir" "$profile_dir"

  rm -rf "$stash"
  trap - EXIT INT HUP
}

xfree_pt_write_profile_meta_sync() {
  profile_dir="$1"
  profile_name="$2"
  template_name="$3"

  meta="$profile_dir/EXPORT-META.txt"
  tmp_meta="${meta}.xfree-pt.$$"
  mkdir -p "$profile_dir"
  if [ -f "$meta" ]; then
    grep -v '^TEMPLATE_REF=' "$meta" 2>/dev/null \
      | grep -v '^UPDATED_FROM_TEMPLATE=' \
      | grep -v '^EXPORT_NAME=' >"$tmp_meta" || true
  else
    : >"$tmp_meta"
  fi
  {
    cat "$tmp_meta"
    printf 'EXPORT_NAME=%s\n' "$profile_name"
    printf 'TEMPLATE_REF=%s\n' "$template_name"
    printf 'UPDATED_FROM_TEMPLATE=1\n'
  } >"$meta"
  rm -f "$tmp_meta"
}
