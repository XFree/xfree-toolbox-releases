#!/bin/sh
# shellcheck shell=sh
# Shared pipeline: «Обновить и применить», «Пересоздать и применить»,
# install-from-cloud --apply-template (после toolbox), WPS-sync.
# Order: toolbox upgrade → upstream download (только datasets, без drift/zapret runtime)
#        → copy (lists | full template) → apply-template (prepare один раз).
# Нет отдельного preflight с применением списков в profiles/ и runtime.
# install-from-cloud без XFREE_APPLY_INNER=1 только ставит toolbox и вызывает этот пайплайн.
set -eu

templates_pipeline_read_template_ref() {
	_meta="$1"
	[ -f "$_meta" ] || return 1
	awk -F= '
		/^[[:space:]]*TEMPLATE_REF=/ {
			v=$2
			sub(/^[[:space:]]*/, "", v)
			sub(/[[:space:]]*$/, "", v)
			gsub(/^"/, "", v); gsub(/"$/, "", v)
			gsub(/^'\''/, "", v); gsub(/'\''$/, "", v)
			print v
			exit
		}
	' "$_meta" 2>/dev/null
}

templates_pipeline_profile_ready_for_sync() {
	_root="$1"
	template_name="$2"
	profile_name="${3:-$template_name}"
	profile_dir="$(common_profile_resolve_dir "$_root" "$profile_name" 2>/dev/null || true)"
	[ -n "$profile_dir" ] && [ -d "$profile_dir" ]
}

# Создать EXPORT-META.txt, если профиль materialized, но meta ещё не было (явный template из меню).
templates_pipeline_ensure_export_meta() {
	_root="$1"
	_template="$2"
	_profile="$3"
	_pt_lib="$_root/templates/profile-from-template-lib.sh"

	[ -f "$_root/lib/common.sh" ] || return 1
	# shellcheck disable=SC1091
	. "$_root/lib/common.sh"

	_profile_dir="$(common_profile_resolve_dir "$_root" "$_profile" 2>/dev/null || true)"
	[ -n "$_profile_dir" ] && [ -d "$_profile_dir" ] || return 1

	if [ -f "$_profile_dir/EXPORT-META.txt" ]; then
		return 0
	fi

	[ -f "$_pt_lib" ] || return 1
	# shellcheck disable=SC1091
	. "$_pt_lib"
	xfree_pt_write_profile_meta_sync "$_profile_dir" "$_profile" "$_template"
	return 0
}

# stdout: template<TAB>profile (режим apply всегда sync)
templates_resolve_active_sync_targets() {
	_root="$1"
	[ -f "$_root/lib/common.sh" ] || return 1
	# shellcheck disable=SC1091
	. "$_root/lib/common.sh"

	profile_name="$(common_active_profile_name "$_root" 2>/dev/null || true)"
	[ -n "$profile_name" ] || return 1

	profile_dir="$(common_profile_dir "$_root" "$profile_name" 2>/dev/null || true)"
	[ -n "$profile_dir" ] && [ -d "$profile_dir" ] || return 1

	_meta="$profile_dir/EXPORT-META.txt"
	template_name="$(templates_pipeline_read_template_ref "$_meta")"
	[ -n "$template_name" ] || return 1

	templates_pipeline_profile_ready_for_sync "$_root" "$template_name" "$profile_name" \
		|| return 1

	printf '%s\t%s\n' "$template_name" "$profile_name"
}

templates_pipeline_ensure_ui_tmp() {
	UI_TMP_ROOT="${UI_TMP_ROOT:-${TMPDIR:-/tmp}/xfree-pipeline.$$}"
	export UI_TMP_ROOT
	mkdir -p "$UI_TMP_ROOT"
}

# Перед upstream (GitHub/OpenCCK): дождаться маршрута и DNS (без ifdown/wwan).
# Вызывается до upgrade и снова после — self-update может рестартнуть https-dns-proxy.
templates_pipeline_prepare_uplink() {
	_root="$1"
	_wait="${2:-${XFREE_PIPELINE_UPLINK_WAIT_SEC:-120}}"

	[ "${XFREE_BG_TASK:-0}" = "1" ] || return 0
	[ -f "$_root/lib/common.sh" ] || return 0

	# shellcheck disable=SC1091
	. "$_root/lib/common.sh"

	printf '[*] pipeline: ожидание маршрута, uplink (TEST_URL) и DNS (до %ss, без переподнятия wwan)…\n' "$_wait" >&2

	if common_wait_network_after_restart "$_wait" codeload.github.com; then
		printf '[*] pipeline: сеть готова (маршрут + uplink + DNS codeload.github.com)\n' >&2
		return 0
	fi

	printf '[!] pipeline: нет маршрута/uplink/DNS (codeload.github.com) — upstream download не пройдёт\n' >&2
	printf '[!] pipeline: uplink настраивается в profile-generator, не при WPS-sync\n' >&2
	return 1
}

templates_upgrade_toolbox_if_needed() {
	if [ "${SKIP_SELF_UPDATE:-0}" = "1" ]; then
		printf '[*] pipeline: toolbox upgrade пропущен (--no-self-update)\n' >&2
		return 0
	fi
	_root="$1"
	_su="$_root/system/self-update.sh"
	[ -f "$_su" ] || return 0

	_rc=0
	sh "$_su" --silent --check-only --preserve-profiles >/dev/null 2>&1 || _rc=$?
	case "$_rc" in
		0)
			printf '[*] pipeline: toolbox актуален\n' >&2
			return 0
			;;
		10) ;;
		*)
			printf '[!] toolbox check: exit %s (продолжаем без upgrade)\n' "$_rc" >&2
			return 0
			;;
	esac

	printf '[*] pipeline: toolbox upgrade (self-update)…\n' >&2
	sh "$_su" --silent --preserve-profiles || return 1
	export XFREE_PIPELINE_UPGRADED=1
	printf '[*] pipeline: toolbox upgrade готов\n' >&2
}

templates_ensure_router_commands() {
	_root="$1"
	_cmd="$_root/system/router-commands.sh"
	[ -f "$_cmd" ] || return 0
	sh "$_cmd" --install >/dev/null 2>&1 || true
}

templates_ensure_deploy_hooks() {
	_root="$1"
	_hooks="$_root/system/hardware/install-button-hooks.sh"
	if [ -f "$_hooks" ]; then
		sh "$_hooks" --ensure --quiet "$_root" >/dev/null 2>&1 || true
	fi
	_uw="$_root/system/hardware/usb-power-watch-upgrade.sh"
	if [ -f "$_uw" ]; then
		sh "$_uw" --on-deploy --quiet "$_root" >>/tmp/xfree-postinst.log 2>&1 || true
	fi
}

templates_run_upstream_preflight_core() {
	_root="$1"
	_headless="${2:-1}"

	templates_pipeline_ensure_ui_tmp

	_handlers="$_root/upstreams/menu.handlers.sh"
	[ -f "$_handlers" ] || {
		printf '[-] upstream preflight: не найден %s\n' "$_handlers" >&2
		return 1
	}

	if [ "$_headless" = "1" ]; then
		export XFREE_PIPELINE_HEADLESS=1
	else
		unset XFREE_PIPELINE_HEADLESS 2>/dev/null || true
	fi

	export ROOT_DIR="$_root"
	[ -f "$_root/lib/upstreams.sh" ] && . "$_root/lib/upstreams.sh"
	UPSTREAMS_MODULE_DIR="$_root/upstreams"
	# shellcheck disable=SC1090
	. "$_handlers"

	# Только download + индекс. Drift в profiles/templates и zapret runtime — не здесь:
	# copy берёт списки из шаблона, apply-template применяет runtime один раз.
	# HTTP (OpenCCK/GitHub) опционален: в пакете уже есть datasets — сбой refresh не валит пайплайн.
	if ! update_selected_modules; then
		printf '[!] pipeline: обновление upstream не удалось — продолжаю со списками из пакета\n' >&2
	fi
}

templates_invoke_install_from_cloud_apply() {
	_root="$1"
	_template="$2"
	_profile="$3"
	_silent="${4:-0}"
	_log_title="${5:-}"
	_apply_mode="${6:-sync}"
	_force="${7:-0}"

	_ifc="$_root/system/install-from-cloud.sh"
	[ -f "$_ifc" ] || {
		printf '[-] не найден install-from-cloud.sh: %s\n' "$_ifc" >&2
		return 1
	}
	[ -x "$_ifc" ] || chmod +x "$_ifc" 2>/dev/null || true

	set -- --apply-template "$_template" --apply-mode "$_apply_mode" --apply-profile "$_profile"
	[ "$_force" = "1" ] && set -- "$@" --force
	[ "$_silent" = "1" ] && set -- "$@" --silent --preserve-profiles
	[ "${SKIP_SELF_UPDATE:-0}" = "1" ] && set -- "$@" --no-self-update
	export XFREE_APPLY_INNER=1

	if [ -n "$_log_title" ] && [ "${TEMPLATES_PIPELINE_UI_LOG:-0}" = "1" ]; then
		# Прямой запуск (как wget): Proton/instantiate prepare на /dev/tty, не ui_run_log.
		_handlers="$_root/templates/menu.handlers.sh"
		if [ -f "$_handlers" ]; then
			# shellcheck disable=SC1091
			. "$_handlers"
			templates_run_install_from_cloud_apply "$_template" "$_apply_mode" "$_force" "$_profile" "$_log_title"
			return $?
		fi
	fi

	printf '[*] pipeline: install-from-cloud apply (inner: copy + apply-template)…\n' >&2
	sh "$_ifc" "$@"
}

# $1=root $2=headless_upstream(0|1)
templates_run_upgrade_and_upstream_preflight() {
	_root="$1"
	_headless="${2:-1}"

	printf '[*] pipeline: toolbox upgrade + upstream lists…\n' >&2
	templates_pipeline_prepare_uplink "$_root" || return 1
	templates_upgrade_toolbox_if_needed "$_root" || return 1
	# Self-update / init.d bounce: снова проба (маршрут + uplink + DNS), потом HTTP.
	templates_pipeline_prepare_uplink "$_root" || return 1
	templates_ensure_router_commands "$_root"
	templates_ensure_deploy_hooks "$_root"
	printf '[*] pipeline: upstream lists (download, без apply runtime)…\n' >&2
	templates_run_upstream_preflight_core "$_root" "$_headless" || return 1
	printf '[*] pipeline: toolbox + upstream lists готовы\n' >&2
}

# $1=root $2=template $3=profile $4=silent(0|1) $5=headless_upstream(0|1)
# $6=log_title $7=apply_mode(sync|instantiate) $8=force(0|1)
templates_apply_update_pipeline() {
	_root="$1"
	_template="$2"
	_profile="$3"
	_silent="${4:-1}"
	_headless="${5:-1}"
	_log_title="${6:-Обновить и применить: $_template}"
	_apply_mode="${7:-sync}"
	_force="${8:-0}"

	# --force = меню «Пересоздать и применить» (instantiate --force), не sync.
	if [ "$_force" = "1" ]; then
		_apply_mode="instantiate"
	fi

	if [ "$_apply_mode" = "sync" ]; then
		templates_pipeline_ensure_export_meta "$_root" "$_template" "$_profile" \
			|| return 1
	fi
	printf '[*] pipeline: шаблон=%s профиль=%s режим=%s force=%s\n' \
		"$_template" "$_profile" "$_apply_mode" "$_force" >&2
	templates_run_upgrade_and_upstream_preflight "$_root" "$_headless" || return 1
	templates_invoke_install_from_cloud_apply \
		"$_root" "$_template" "$_profile" "$_silent" "$_log_title" \
		"$_apply_mode" "$_force"
}

# $1=root $2=template $3=profile $4=silent(0|1) $5=headless_upstream(0|1) $6=log_title
templates_sync_update_apply_pipeline() {
	templates_apply_update_pipeline "$1" "$2" "$3" "$4" "$5" "$6" sync 0
}

# Прямой запуск из install-from-cloud (не source из меню/тестов: там $0 другой).
case "${0##*/}" in
	update-and-apply-pipeline.sh)
		templates_apply_update_pipeline "$@"
		;;
esac
