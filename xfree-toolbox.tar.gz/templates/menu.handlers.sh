#!/bin/sh
# Hand-written handlers for cli.run in templates/menu.yaml.
# shellcheck shell=sh

INSTANTIATE_SCRIPT="$SCRIPT_DIR/instantiate-profile-from-template.sh"
RESTORE_SCRIPT="$SCRIPT_DIR/restore-profile-from-state.sh"
PREPARE_SCRIPT="$SCRIPT_DIR/prepare-template.sh"
DELETE_PROFILE_SCRIPT="$SCRIPT_DIR/delete-profile.sh"
STATE_EXPORT_TEMPLATE_SCRIPT="$ROOT_DIR/ci/state-export-to-template.sh"
INSTALL_FROM_CLOUD_SCRIPT="$ROOT_DIR/system/install-from-cloud.sh"
UPDATE_APPLY_PIPELINE="$SCRIPT_DIR/update-and-apply-pipeline.sh"

run_script() {
    script="$1"
    shift || true
    [ -f "$script" ] || {
        ui_msgbox "Ошибка" "Скрипт не найден:\n$script"
        return 0
    }
    [ -x "$script" ] || chmod +x "$script" 2>/dev/null || true
    ui_run_script "$script" "$@" || true
}

run_log() {
    ui_run_log "$@"
}

run_log_bg() {
    task_name="$1"
    title="$2"
    shift 2
    ui_run_background_task "$title" "$task_name" "$@" || true
}

# Синхронный выбор режима Proton до фонового prepare (нет TTY в bg-task-run).
# По умолчанию — гостевая генерация (--acquire-guest). Вставка .conf — opt-in.
# Нельзя оборачивать paste в ui_run_log: живой лог пишет на /dev/tty и блокирует nano/vi/cat.
templates_proton_preflight_if_needed() {
    profile_dir="$1"
    [ -n "${profile_dir:-}" ] || return 0
    [ -f "$PREPARE_SCRIPT" ] || return 0

    if [ -n "${PROTON_MANUAL_CONF_FILE:-}" ] && [ -f "${PROTON_MANUAL_CONF_FILE:-}" ] && [ -s "${PROTON_MANUAL_CONF_FILE:-}" ]; then
        return 0
    fi

    if ! PROFILE_DIR="$profile_dir" "$PREPARE_SCRIPT" \
        --profile-dir "$profile_dir" \
        --proton-preflight-check-only; then
        return 0
    fi

    choice="$(ui_menu "Proton: режим .conf" "Для Proton-интерфейса с TEMPLATE нет web-сессии.

Гостевая генерация — как WARP: новая credentialless-сессия при prepare
(--acquire-guest). Обновление guest-.conf тоже минтит новую сессию.

Вставка — готовый .conf с TTY (nano/vi/cat), только если нужен импорт." 20 92 6 \
        "guest" "Гостевая генерация на роутере (по умолчанию)" \
        "paste" "Вставить готовый .conf (TTY)" \
        "0" "Отмена" || true)"
    [ -n "${choice:-}" ] || return 1
    case "$choice" in
        guest)
            return 0
            ;;
        paste)
            if ! ui_confirm "Proton: ввод .conf" \
"Откроется ввод Proton .conf на TTY (nano / vi / cat+Ctrl+D).

Продолжить?"; then
                return 1
            fi
            if ! PROFILE_DIR="$profile_dir" "$PREPARE_SCRIPT" \
                --profile-dir "$profile_dir" \
                --proton-preflight-only; then
                ui_msgbox "Proton preflight" \
"Не удалось импортировать Proton .conf.

Проверьте полный .conf и повторите подготовку профиля или ввод через iface-routing → Proton."
                return 1
            fi
            return 0
            ;;
        0|"")
            return 1
            ;;
        *)
            return 1
            ;;
    esac
}

run_log_textbox() {
    title="$1"
    shift
    UI_RUN_WITH_OUTPUT_MODE=textbox ui_run_with_output "$title" "$@"
}

# Быстрый copy-only без «пустого живого» экрана; при ошибке — полный run_log.
templates_run_copy_only() {
    template_name="$1"
    profile_name="$2"
    shift 2

    _copy_log="${TMPDIR:-/tmp}/xfree-template-copy-$$.log"
    : > "$_copy_log"
    # shellcheck disable=SC2068
    if common_exec_streaming "$INSTANTIATE_SCRIPT" \
        --template "$template_name" \
        --profile "$profile_name" \
        "$@" \
        --copy-only >>"$_copy_log" 2>&1; then
        rm -f "$_copy_log"
        return 0
    fi

    run_log "Копирование шаблона → профиль" \
        "$INSTANTIATE_SCRIPT" \
        --template "$template_name" \
        --profile "$profile_name" \
        "$@" \
        --copy-only
    rm -f "$_copy_log"
    return 1
}

pick_template_name() {
    templates="$(common_list_profile_template_dirnames "$ROOT_DIR" || true)"
    if [ -z "${templates:-}" ]; then
        ui_msgbox "Шаблоны" "Каталог profile-templates/ пуст или не найден.

Положите шаблон в:
$(common_profile_templates_dir "$ROOT_DIR")/<имя>/"
        return 1
    fi
    choice="$(ui_select_from_lines "Шаблон" "Выберите шаблон из profile-templates/:" "$templates" 22 90 12 || true)"
    [ -n "${choice:-}" ] || return 1
    case "$choice" in
        *[!A-Za-z0-9._-]*|'') return 1 ;;
    esac
    printf '%s\n' "$choice"
}

# Профиль profiles/<имя> существует → можно --apply-mode sync (EXPORT-META допишется при необходимости).
templates_profile_ready_for_sync() {
    template_name="$1"
    profile_name="${2:-$template_name}"
    # shellcheck disable=SC1091
    . "$UPDATE_APPLY_PIPELINE"
    templates_pipeline_profile_ready_for_sync "$ROOT_DIR" "$template_name" "$profile_name"
}

# Прокси на system/install-from-cloud.sh --apply-template (APPLY_ONLY на установленном toolbox).
# Прямой sh (как wget), не ui_run_log: instantiate/prepare и Proton .conf нужен живой /dev/tty.
templates_run_install_from_cloud_apply() {
    template_name="$1"
    apply_mode="${2:-instantiate}"
    force="${3:-0}"
    profile_name="${4:-$template_name}"
    log_title="${5:-install-from-cloud: $template_name}"

    [ -f "$INSTALL_FROM_CLOUD_SCRIPT" ] || {
        ui_msgbox "Ошибка" "Не найден install-from-cloud.sh:
$INSTALL_FROM_CLOUD_SCRIPT"
        return 1
    }
    [ -x "$INSTALL_FROM_CLOUD_SCRIPT" ] || chmod +x "$INSTALL_FROM_CLOUD_SCRIPT" 2>/dev/null || true

    set -- --apply-template "$template_name" --apply-profile "$profile_name"
    # --force = «Пересоздать»: не уходить в --apply-mode sync.
    if [ "$force" = "1" ]; then
        apply_mode="instantiate"
    fi
    if [ "$apply_mode" = "sync" ]; then
        set -- "$@" --apply-mode sync
    fi
    if [ "$force" = "1" ]; then
        set -- "$@" --force
    fi
    export XFREE_APPLY_INNER=1

    _capture_log="${UI_RUN_WITH_OUTPUT_BATCH_LOG:-}"
    if [ -n "$_capture_log" ]; then
        # Пишем в batch-лог и одновременно стримим на tty (как ui_run_with_output:
        # tail -f файла — на OpenWrt pipe+tee часто буферизуется целиком).
        _run_log="$(mktemp "${TMPDIR:-/tmp}/xfree-ifc-apply.XXXXXX")"
        : > "$_run_log"
        printf '\n=== %s ===\n\n' "$log_title" >/dev/tty 2>/dev/null || true
        _tail_pid=""
        if [ -c /dev/tty ] || [ -w /dev/tty ]; then
            tail -n 0 -f "$_run_log" >/dev/tty 2>/dev/null &
            _tail_pid=$!
        fi
        set +e
        common_exec_streaming sh "$INSTALL_FROM_CLOUD_SCRIPT" "$@" >>"$_run_log" 2>&1
        _rc=$?
        set -e
        if [ -n "${_tail_pid:-}" ]; then
            sleep 1
            kill "$_tail_pid" 2>/dev/null || true
            wait "$_tail_pid" 2>/dev/null || true
        fi
        {
            printf '=== %s ===\n' "$log_title"
            cat "$_run_log"
            printf '\n'
        } >> "$_capture_log"
        rm -f "$_run_log"
        if [ "$_rc" -ne 0 ]; then
            UI_RUN_WITH_OUTPUT_BATCH_WORST_RC=1
            export UI_RUN_WITH_OUTPUT_BATCH_WORST_RC
        fi
        return "$_rc"
    fi

    set +e
    sh "$INSTALL_FROM_CLOUD_SCRIPT" "$@"
    _rc=$?
    set -e
    return "$_rc"
}

templates_apply_template_pipeline() {
    template_name="$1"
    apply_mode="$2"
    force="${3:-0}"
    log_title="$4"
    templates_run_install_from_cloud_apply "$template_name" "$apply_mode" "$force" "$template_name" "$log_title"
}

templates_invoke_install_from_cloud_apply() {
    template_name="$1"
    apply_mode="$2"
    force="${3:-0}"
    log_title="$4"
    templates_apply_template_pipeline "$template_name" "$apply_mode" "$force" "$log_title"
}

# Обновить upstream-источники (download). Без drift/zapret runtime — это шаг apply-template.
templates_run_upstream_preflight() {
    [ -f "$UPDATE_APPLY_PIPELINE" ] || {
        ui_msgbox "Ошибка" "Не найден:\n$UPDATE_APPLY_PIPELINE"
        return 1
    }
    # shellcheck disable=SC1091
    . "$UPDATE_APPLY_PIPELINE"
    templates_run_upgrade_and_upstream_preflight "$ROOT_DIR" 0
}

pick_profile_name() {
    prompt="${1:-Выберите профиль из profiles/:}"
    profiles="$(common_list_profile_dirnames "$ROOT_DIR" || true)"
    if [ -z "${profiles:-}" ]; then
        ui_msgbox "Профиль" "Каталог profiles/ пуст или не найден."
        return 1
    fi
    choice="$(ui_select_from_lines "Профиль" "$prompt" "$profiles" 22 90 12 || true)"
    [ -n "${choice:-}" ] || return 1
    case "$choice" in
        *[!A-Za-z0-9._-]*|'') return 1 ;;
    esac
    printf '%s\n' "$choice"
}

sanitize_name_input() {
    raw="${1:-}"
    common_sanitize_profile_name "$raw" 2>/dev/null
}

instantiate_profile_from_template_menu() {
    if ui_bg_task_redirect_if_running "Создание профиля из шаблона"; then
        return 0
    fi

    template_name="$(pick_template_name)" || return 0

    mode="$(ui_menu "Создать профиль из шаблона" "Шаблон: $template_name

Выберите режим:" 18 90 8 \
        "recreate" "Пересоздать существующий (copy + prepare)" \
        "new" "Новый профиль (задать имя)" \
        "0" "Отмена" || true)"
    [ -n "${mode:-}" ] || return 0
    case "$mode" in
        0) return 0 ;;
        recreate)
            profile_name="$(pick_profile_name "Пересоздать какой профиль?

Будет полностью перезаписан profiles/<имя> из шаблона и выполнен prepare.")" || return 0
            profile_dir="$(common_profile_resolve_dir "$ROOT_DIR" "$profile_name")"
            if ! ui_confirm "Пересоздать профиль" \
"Шаблон: profile-templates/$template_name
Профиль: profiles/$profile_name

Каталог профиля будет удалён и создан заново из шаблона (включая source.conf.meta).
Затем prepare-template (WARP/Proton/AWG — регенерация по meta/маркерам).

Продолжить?"; then
                return 0
            fi
            templates_run_copy_only "$template_name" "$profile_name" --force --recreated || return 0
            templates_proton_preflight_if_needed "$profile_dir" || return 0
            run_log_bg instantiate-profile-prepare \
                "Профиль $profile_name: маркеры TEMPLATE" \
                "$INSTANTIATE_SCRIPT" \
                --template "$template_name" \
                --profile "$profile_name" \
                --prepare-only
            offer_switch_active_profile "$profile_name"
            ;;
        new)
            raw_name="$(ui_inputbox "Новый профиль" "Имя нового профиля (profiles/<имя>):" "myprofile" || true)"
            [ -n "${raw_name:-}" ] || return 0
            profile_name="$(sanitize_name_input "$raw_name")" || {
                ui_msgbox "Новый профиль" "Некорректное имя: $raw_name"
                return 0
            }
            profile_dir="$(common_profile_resolve_dir "$ROOT_DIR" "$profile_name")"
            force_flag=""
            if [ -e "$profile_dir" ]; then
                if ! ui_confirm "Профиль существует" \
"profiles/$profile_name уже существует.

Перезаписать (--force) и выполнить prepare?"; then
                    return 0
                fi
                force_flag="--force"
            fi
            if ! ui_confirm "Создать профиль" \
"Шаблон: profile-templates/$template_name
Профиль: profiles/$profile_name

Copy из шаблона + prepare-template.

Продолжить?"; then
                return 0
            fi
            if [ -n "${force_flag:-}" ]; then
                templates_run_copy_only "$template_name" "$profile_name" --force || return 0
            else
                templates_run_copy_only "$template_name" "$profile_name" || return 0
            fi
            templates_proton_preflight_if_needed "$profile_dir" || return 0
            run_log_bg instantiate-profile-prepare \
                "Профиль $profile_name: маркеры TEMPLATE" \
                "$INSTANTIATE_SCRIPT" \
                --template "$template_name" \
                --profile "$profile_name" \
                --prepare-only
            offer_switch_active_profile "$profile_name"
            ;;
        *) return 0 ;;
    esac
}

templates_set_active_profile() {
    common_set_active_profile_in_config "$ROOT_DIR" "$1" || return 1
    common_profile_env_clear_overrides
    load_base_config "$ROOT_DIR"
}

offer_switch_active_profile() {
    profile_name="$1"
    current="$(common_active_profile_name "$ROOT_DIR")"
    [ "$profile_name" = "$current" ] && return 0
    if ui_confirm "Активный профиль" "Переключить активный профиль на «$profile_name»?"; then
        templates_set_active_profile "$profile_name"
        ui_msgbox "Активный профиль" "Активный профиль переключён на:

$profile_name"
    fi
}

pick_profile_name_or_empty() {
    profiles="$(common_list_profile_dirnames "$ROOT_DIR" || true)"
    if [ -z "${profiles:-}" ]; then
        ui_msgbox "Профили" "Каталог profiles/ пуст.

Сначала создайте профиль из шаблона (п. 1)."
        return 1
    fi
    pick_profile_name "$1"
}

sync_and_apply_profile_menu() {
    if ui_bg_task_redirect_if_running "Применение профиля"; then
        return 0
    fi

    template_name="$(pick_template_name)" || return 0
    profile_name="$(pick_profile_name_or_empty "Какой профиль обновить и применить?

Шаблон: profile-templates/$template_name
(если нет EXPORT-META.txt — будет создана связь с выбранным шаблоном)")" || return 0

    if ! templates_profile_ready_for_sync "$template_name" "$profile_name"; then
        ui_msgbox "Обновить и применить" \
"Профиль profiles/$profile_name не найден.

Сначала создайте профиль (пункт «Создать профиль из шаблона») или выберите существующий."
        return 0
    fi

    if ! ui_confirm "Обновить и применить" \
"Шаблон: profile-templates/$template_name
Профиль: profiles/$profile_name

Тот же пайплайн, что «Пересоздать». Копирование: только списки
(живой source.conf / meta / UCI не затираются). prepare всегда:
материализует лишь новые TEMPLATE, уже готовые интерфейсы не трогает.

Порядок:
toolbox + upstream-списки → copy (списки) →
https-dns-proxy → dns-redirect → zapret → AWG → prepare →
интерфейсы, маршрутизация.

Продолжить?"; then
        return 0
    fi

    ui_run_with_output_batch_begin
    TEMPLATES_PIPELINE_UI_LOG=1
    export TEMPLATES_PIPELINE_UI_LOG
    # shellcheck disable=SC1091
    . "$UPDATE_APPLY_PIPELINE"
    if ! templates_sync_update_apply_pipeline \
        "$ROOT_DIR" "$template_name" "$profile_name" 0 0 \
        "Обновить и применить: $template_name"; then
        ui_run_with_output_batch_end "Обновить и применить: $template_name"
        return 0
    fi
    ui_run_with_output_batch_end "Обновить и применить: $template_name"
}

recreate_and_apply_profile_menu() {
    if ui_bg_task_redirect_if_running "Применение профиля"; then
        return 0
    fi

    template_name="$(pick_template_name)" || return 0
    profile_name="$(pick_profile_name_or_empty "Какой профиль пересоздать и применить?

Шаблон: profile-templates/$template_name
Каталог профиля будет полностью заменён шаблоном (включая source.conf / meta).")" || return 0

    if ! ui_confirm "Пересоздать и применить" \
"Шаблон: profile-templates/$template_name
Профиль: profiles/$profile_name

Тот же пайплайн, что «Обновить». Копирование: шаблон целиком
(включая source.conf.meta / TEMPLATE). prepare материализует ключи.

Порядок:
toolbox + upstream-списки → copy (шаблон целиком) →
https-dns-proxy → dns-redirect → zapret → AWG → prepare →
интерфейсы, маршрутизация.

Продолжить?"; then
        return 0
    fi

    ui_run_with_output_batch_begin
    TEMPLATES_PIPELINE_UI_LOG=1
    export TEMPLATES_PIPELINE_UI_LOG
    # shellcheck disable=SC1091
    . "$UPDATE_APPLY_PIPELINE"
    if ! templates_apply_update_pipeline \
        "$ROOT_DIR" "$template_name" "$profile_name" 0 0 \
        "Пересоздать и применить: $template_name" instantiate 1; then
        ui_run_with_output_batch_end "Пересоздать и применить: $template_name"
        return 0
    fi
    ui_run_with_output_batch_end "Пересоздать и применить: $template_name"
}

import_state_to_template_menu() {
    if [ ! -f "$STATE_EXPORT_TEMPLATE_SCRIPT" ]; then
        ui_msgbox "Шаблон из state" "Скрипт недоступен на роутере:
$STATE_EXPORT_TEMPLATE_SCRIPT

Импорт state → profile-templates/ выполняется на хосте (WSL/CI):
ci/state-export-to-template.sh

Каталог ci/ не входит в tar/apk toolbox на роутере."
        return 0
    fi
    if ! ui_confirm "Шаблон из state" \
"Импорт operator-store/state (или legacy state-export) в profile-templates/<имя>.

Будет выполнен scrub (режим template): Proton session из export удаляется, маркеры TEMPLATE.

В интерактивном режиме выберите export root и цель: существующий шаблон, имя из EXPORT_NAME или своё."; then
        return 0
    fi
    run_log "Импорт state → profile-templates/" \
        "$STATE_EXPORT_TEMPLATE_SCRIPT"
}

restore_profile_from_state_menu() {
    target_profile="$(pick_profile_name_or_empty "Какой профиль восстановить из состояния системы?")" || return 0

    current_profile="$(common_active_profile_name "$ROOT_DIR")"
    if [ "$target_profile" != "$current_profile" ]; then
        if ui_confirm "Активный профиль" \
"Сейчас активен: $current_profile
Восстановить: profiles/$target_profile

Переключить активный профиль на «$target_profile»?"; then
            templates_set_active_profile "$target_profile"
        fi
    fi

    run_log_textbox "Diff: profiles/$target_profile и materialized layout из состояния системы" \
        "$RESTORE_SCRIPT" --profile "$target_profile" --diff-only

    if ui_confirm "Восстановить профиль из состояния системы" \
"Будет выполнено восстановление профиля '$target_profile' из состояния системы.

Будет полностью перезаписан каталог:
- profiles/$target_profile

Продолжить?"; then
        run_log "Восстановление профиля '$target_profile' из состояния системы" \
            "$RESTORE_SCRIPT" --profile "$target_profile"
    fi
}

delete_profile_menu() {
    profile_name="$(pick_profile_name "Удалить какой профиль?

Будет удалён каталог profiles/<имя> (шаблоны не затрагиваются).")" || return 0

    active="$(common_active_profile_name "$ROOT_DIR")"
    applied="$(common_applied_profile_name 2>/dev/null || true)"
    if [ "$profile_name" = "$active" ]; then
        ui_msgbox "Удалить профиль" \
"Нельзя удалить активный профиль «$profile_name».

Сначала переключите активный профиль:
главное меню → «Выбрать активный профиль»."
        return 0
    fi
    if [ -n "${applied:-}" ] && [ "$profile_name" = "$applied" ]; then
        ui_msgbox "Удалить профиль" \
"Нельзя удалить применённый к системе профиль «$profile_name».

Сначала примените другой профиль:
Шаблоны и профили → «Обновить и применить» или «Пересоздать и применить»."
        return 0
    fi

    if ! ui_confirm "Удалить профиль" \
"Будет безвозвратно удалён каталог:

  profiles/$profile_name

profile-templates/ не затрагивается.
Активный профиль останется: $active

Продолжить?"; then
        return 0
    fi

    [ -f "$DELETE_PROFILE_SCRIPT" ] || {
        ui_msgbox "Ошибка" "Скрипт не найден:
$DELETE_PROFILE_SCRIPT"
        return 0
    }
    [ -x "$DELETE_PROFILE_SCRIPT" ] || chmod +x "$DELETE_PROFILE_SCRIPT" 2>/dev/null || true

    if sh "$DELETE_PROFILE_SCRIPT" --profile "$profile_name"; then
        ui_msgbox "Удалить профиль" "Удалён: profiles/$profile_name"
    else
        ui_msgbox "Удалить профиль" "Не удалось удалить profiles/$profile_name

См. вывод в консоли / логе."
    fi
}

templates_gen_menu_hint() {
	current_profile="$(common_active_profile_name "$ROOT_DIR")"
	printf "Выберите действие\n\nАктивный профиль: %s\nШаблоны: %s\nРежим меню: %s" \
		"$current_profile" "$(common_profile_templates_dir "$ROOT_DIR")" "$(_menu_mode_label)"
}
