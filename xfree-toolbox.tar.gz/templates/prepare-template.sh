#!/bin/sh
# shellcheck shell=sh
set -eu

# Resolve script path even when invoked via PREPARE_SCRIPT=/tmp/xfree-prepare-template.sh
# (profile-generator cloud install keeps a host-synced copy outside the toolbox tree).
_prepare_self="$0"
if command -v readlink >/dev/null 2>&1; then
  _linked="$(readlink -f "$0" 2>/dev/null || true)"
  [ -n "$_linked" ] && _prepare_self="$_linked"
fi
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$_prepare_self")" && pwd -P)"

# Prefer explicit root; do not assume SCRIPT_DIR/.. is the toolbox (fails for /tmp copies).
xfree_prepare_resolve_root() {
  if [ -n "${XFREE_ROOT_DIR:-}" ] && [ -f "${XFREE_ROOT_DIR}/lib/common.sh" ]; then
    CDPATH= cd -- "$XFREE_ROOT_DIR" && pwd -P
    return 0
  fi
  if [ -n "${XFREE_TOOLBOX_TARGET_DIR:-}" ] && [ -f "${XFREE_TOOLBOX_TARGET_DIR}/lib/common.sh" ]; then
    CDPATH= cd -- "$XFREE_TOOLBOX_TARGET_DIR" && pwd -P
    return 0
  fi
  if [ -f "$SCRIPT_DIR/../lib/common.sh" ]; then
    CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P
    return 0
  fi
  if [ -f "${TARGET_DIR:-/root/xfree-toolbox}/lib/common.sh" ]; then
    CDPATH= cd -- "${TARGET_DIR:-/root/xfree-toolbox}" && pwd -P
    return 0
  fi
  if [ -f "/root/xfree-toolbox/lib/common.sh" ]; then
    printf '%s\n' "/root/xfree-toolbox"
    return 0
  fi
  return 1
}

ROOT_DIR="$(xfree_prepare_resolve_root)" || {
  printf '[-] Не найден корень xfree-toolbox (lib/common.sh); SCRIPT_DIR=%s XFREE_ROOT_DIR=%s\n' \
    "$SCRIPT_DIR" "${XFREE_ROOT_DIR:-}" >&2
  exit 1
}

. "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/iface-routing/lib/proton-template-session.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/proton-manual-conf-capture.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/templates/lib/template-markers.sh"
load_base_config "$ROOT_DIR"

PROFILE_DIR_ARG="${PROFILE_DIR:-}"
PROFILE_DIR_EXPLICIT=0
PROFILE_DIR=""
INTERFACES_DIR_OVERRIDE="${INTERFACES_DIR:-}"
STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
IFACE_REGENERATE_SCRIPT="${IFACE_REGENERATE_SCRIPT:-$ROOT_DIR/iface-routing/regenerate-interface-config.sh}"
PROTON_IMPORT_CONF_SCRIPT="${PROTON_IMPORT_CONF_SCRIPT:-$ROOT_DIR/iface-routing/vpn/proton/import-conf.sh}"
UPDATE_INTERFACE_CONFIG_SCRIPT="${UPDATE_INTERFACE_CONFIG_SCRIPT:-$ROOT_DIR/iface-routing/update-interface-config.sh}"
AWG_STATUS_SCRIPT="${AWG_STATUS_SCRIPT:-$ROOT_DIR/awg-ingress/status.sh}"
AWG_ENSURE_SCRIPT="${AWG_ENSURE_SCRIPT:-$ROOT_DIR/awg-ingress/ensure-awg.sh}"
ZAPRET_BOOTSTRAP_SCRIPT="${ZAPRET_BOOTSTRAP_SCRIPT:-$ROOT_DIR/zapret/bootstrap-runtime.sh}"
AWG_PREPARE_ENABLED=1
IFACE_PREPARE_ENABLED=1
PROTON_MANUAL_IMPORT_ENABLED=0
PROTON_MANUAL_IMPORT_EXPLICIT=""
PROTON_PREFLIGHT_ONLY=0
PROTON_PREFLIGHT_CHECK_ONLY=0
PREPARE_HOST_ONLY=0
PREPARE_WARNINGS=0
PREPARE_WARNING_DETAILS=""

usage() {
  cat <<EOF
Usage: $0 [--iface-routing] [--awg-ingress] [--describe] [--proton-manual-import] [--no-proton-manual-import] [--profile-dir DIR]

Prepare current template data for later apply.

By default it processes both:
- active profile iface-routing template markers
- active profile awg-ingress template markers

Options:
  --profile-dir DIR
      Use explicit profile directory instead of active profile selection.
  --proton-manual-import
      Opt-in: paste/import Proton .conf when there is no web session (TTY or
      PROTON_MANUAL_CONF_FILE). Default is guest generate (--acquire-guest).
  --no-proton-manual-import
      Do not import .conf even if PROTON_MANUAL_CONF_FILE is set (guest generate).
  --proton-preflight-only
      Only run Proton preflight (manual .conf import; implies --proton-manual-import).
  --proton-preflight-check-only
      Exit 0 if a proton TEMPLATE iface has no web session (guest generate by default).
  --host-only
      Prepare only what is possible off-router (Proton/WARP iface configs, AWG server/peer keys).
      Keep TEMPLATE markers where router-specific fields remain (e.g. AWG PEER_ENDPOINT).

Environment:
  XFREE_PREPARE_HOST_ONLY=1
      Same as --host-only.
  PROTON_MANUAL_CONF_FILE
      Opt-in path to a ready Proton .conf (on this host/router). When set and
      non-empty, preflight imports it via import-conf --from-file without TTY
      (profile-generator copy-from-store). Without this flag, prepare generates
      a guest session (--acquire-guest), like WARP register.
  PROTON_MANUAL_CONF_EDITOR
      Editor for manual Proton .conf when session is unavailable: nano, vi, or cat.
      Default: nano if in PATH, else vi, else stdin (cat + Ctrl+D on empty line).
      Та же реализация (lib/proton-manual-conf-capture.sh), что и ui_capture_tty_multiline_to_file
      в lib/ui.sh (меню Proton: вставка .conf с TTY).
EOF
}

has_private_key_line() {
  file="$1"
  [ -f "$file" ] || return 1
  grep -q '^PrivateKey=' "$file" 2>/dev/null
}

meta_get() {
  file="$1"
  key="$2"
  [ -f "$file" ] || return 0
  awk -F= -v want="$key" '
    $1 == want {
      v = substr($0, index($0, "=") + 1)
      sub(/^[[:space:]]+/, "", v)
      sub(/[[:space:]]+$/, "", v)
      gsub(/^\047|\047$/, "", v)
      print v
      exit
    }
  ' "$file"
}

can_capture_terminal_input() {
  proton_manual_conf_tty_ok
}

proton_manual_conf_file_ok() {
  [ -n "${PROTON_MANUAL_CONF_FILE:-}" ] || return 1
  [ -f "$PROTON_MANUAL_CONF_FILE" ] || return 1
  [ -s "$PROTON_MANUAL_CONF_FILE" ] || return 1
  return 0
}

capture_proton_conf_to_file() {
  target_file="$1"
  if proton_manual_conf_file_ok; then
    if ! cp -f "$PROTON_MANUAL_CONF_FILE" "$target_file"; then
      return 1
    fi
    prepare_msg_tty "[*] Proton .conf из PROTON_MANUAL_CONF_FILE — без интерактивного ввода."
    return 0
  fi
  if ! proton_manual_conf_capture_to_file "$target_file" "Proton .conf для интерфейса $iface (prepare-template)" "После сохранения подготовка продолжится."; then
    return 1
  fi
  prepare_msg_tty "[*] Ввод Proton .conf принят. Дальше: импорт и применение (подождите следующее сообщение)."
  return 0
}

proton_session_resolved_for_meta() {
  _source_meta="$1"
  _profile_sessions_dir="$PROFILE_DIR/vpn/proton/sessions"
  _operator_sessions_dir="${PROTON_SESSIONS_DIR:-}"
  _session_name="$(meta_get "$_source_meta" "SESSION_NAME")"
  _session_dir="$(meta_get "$_source_meta" "SESSION_DIR")"
  _resolve_out="$(mktemp "${TMPDIR:-/tmp}/xfree-proton-resolve.XXXXXX")"
  if proton_resolve_session_for_template_restore \
      "$_profile_sessions_dir" \
      "$_operator_sessions_dir" \
      "${_session_name:-}" \
      "${_session_dir:-}" >"$_resolve_out" 2>/dev/null; then
    rm -f "$_resolve_out"
    return 0
  fi
  rm -f "$_resolve_out"
  return 1
}

# Proton iface with TEMPLATE markers, ещё не materialized (как в prepare_iface_templates).
prepare_proton_iface_needs_template_work() {
  _iface="$1"
  _config_dir="$2"
  _iface_dir="$3"
  _source_meta="$4"
  _network_uci="$_config_dir/network.uci"
  _source_conf="$_config_dir/source.conf"
  _marker="$_config_dir/TEMPLATE"
  _iface_marker="$_iface_dir/TEMPLATE"

  [ -f "$_marker" ] || [ -f "$_iface_marker" ] || return 1
  if [ -f "$_network_uci" ] && has_private_key_line "$_source_conf"; then
    return 1
  fi
  [ "$(meta_get "$_source_meta" "GENERATOR_KIND")" = "proton" ] || return 1
  return 0
}

# exit 0 — есть proton-iface с TEMPLATE без web-сессии (гостевая генерация или opt-in paste)
prepare_proton_unresolved_ifaces_p() {
  [ -d "$INTERFACES_DIR" ] || return 1

  _iface_list_file="$(mktemp "${TMPDIR:-/tmp}/xfree-proton-preflight-list.XXXXXX")"
  find "$INTERFACES_DIR" -mindepth 3 -maxdepth 3 -type f -path '*/config/iface.conf' 2>/dev/null | sort >"$_iface_list_file"
  while IFS= read -r _iface_conf; do
    [ -n "$_iface_conf" ] || continue
    _config_dir="$(dirname -- "$_iface_conf")"
    _iface_dir="$(dirname -- "$_config_dir")"
    _iface="$(basename -- "$_iface_dir")"
    _source_meta="$_config_dir/source.conf.meta"
    prepare_proton_iface_needs_template_work "$_iface" "$_config_dir" "$_iface_dir" "$_source_meta" || continue
    [ -f "$_source_meta" ] || continue
    proton_session_resolved_for_meta "$_source_meta" && continue
    if proton_restore_is_guest_identity \
        "$(meta_get "$_source_meta" "SESSION_AUTH_MODE")" \
        "$(meta_get "$_source_meta" "SESSION_NAME")"; then
      continue
    fi
    rm -f "$_iface_list_file"
    return 0
  done <"$_iface_list_file"
  rm -f "$_iface_list_file"
  return 1
}

# exit 0 — нужен ручной .conf (только если import включён)
prepare_proton_preflight_required_p() {
  [ "$PROTON_MANUAL_IMPORT_ENABLED" = "1" ] || return 1
  prepare_proton_unresolved_ifaces_p
}

prepare_proton_preflight_sync() {
  [ "$PROTON_MANUAL_IMPORT_ENABLED" = "1" ] || {
    if prepare_proton_unresolved_ifaces_p; then
      info "prepare-template: Proton — нет web-сессии, будет generate --acquire-guest (как WARP). Ручной .conf: --proton-manual-import или PROTON_MANUAL_CONF_FILE."
    else
      info "prepare-template: Proton preflight — ручной .conf не требуется (сессии найдены, guest identity, или нет proton TEMPLATE)"
    fi
    return 0
  }
  [ -d "$INTERFACES_DIR" ] || return 0

  if ! prepare_proton_preflight_required_p; then
    info "prepare-template: Proton preflight — ручной .conf не требуется (сессии найдены или нет proton TEMPLATE)"
    return 0
  fi

  if proton_manual_conf_file_ok; then
    info "prepare-template: Proton preflight — берём .conf из PROTON_MANUAL_CONF_FILE (без TTY)"
  elif [ "${XFREE_BG_TASK:-0}" = "1" ]; then
    die "Proton: включён ручной .conf, но prepare запущен в фоне — сначала выполните синхронно: $0 --proton-preflight-only (SSH -t или пункт меню «Подготовить профиль»), либо задайте PROTON_MANUAL_CONF_FILE"
  elif ! can_capture_terminal_input; then
    die "Proton: нужен интерактивный терминал для ввода .conf (SSH -t / меню) либо PROTON_MANUAL_CONF_FILE с готовым .conf"
  fi

  prepare_msg_tty "[*] prepare-template: Proton preflight — нет сессии для одного или нескольких интерфейсов, запрошу .conf заранее…"

  _iface_list_file="$(mktemp "${TMPDIR:-/tmp}/xfree-proton-preflight-list.XXXXXX")"
  find "$INTERFACES_DIR" -mindepth 3 -maxdepth 3 -type f -path '*/config/iface.conf' 2>/dev/null | sort >"$_iface_list_file"
  while IFS= read -r _iface_conf; do
    [ -n "$_iface_conf" ] || continue
    _config_dir="$(dirname -- "$_iface_conf")"
    _iface_dir="$(dirname -- "$_config_dir")"
    _iface="$(basename -- "$_iface_dir")"
    _source_meta="$_config_dir/source.conf.meta"
    prepare_proton_iface_needs_template_work "$_iface" "$_config_dir" "$_iface_dir" "$_source_meta" || continue
    [ -f "$_source_meta" ] || continue
    proton_session_resolved_for_meta "$_source_meta" && continue
    if proton_restore_is_guest_identity \
        "$(meta_get "$_source_meta" "SESSION_AUTH_MODE")" \
        "$(meta_get "$_source_meta" "SESSION_NAME")"; then
      continue
    fi

    warn "prepare-template: Proton preflight — интерфейс $_iface без сессии, запрашиваю .conf"
    if ! apply_manual_proton_conf_for_iface "$_iface" "$_config_dir" "$_source_meta"; then
      die "Proton preflight: не удалось импортировать .conf для $_iface (${PREPARE_LAST_REASON:-unknown})"
    fi
    success "prepare-template: Proton preflight — $_iface подготовлен из ручного .conf"
    _marker="$_config_dir/TEMPLATE"
    _iface_marker="$_iface_dir/TEMPLATE"
    [ -f "$_marker" ] && rm -f "$_marker" 2>/dev/null || true
    [ -f "$_iface_marker" ] && rm -f "$_iface_marker" 2>/dev/null || true
  done <"$_iface_list_file"
  rm -f "$_iface_list_file"
  return 0
}

apply_manual_proton_conf_for_iface() {
  iface="$1"
  config_dir="$2"
  source_meta="$3"

  if [ ! -f "$PROTON_IMPORT_CONF_SCRIPT" ]; then
    PREPARE_LAST_REASON="не найден import-conf.sh: $PROTON_IMPORT_CONF_SCRIPT"
    return 1
  fi
  if [ ! -f "$UPDATE_INTERFACE_CONFIG_SCRIPT" ]; then
    PREPARE_LAST_REASON="не найден update-interface-config.sh: $UPDATE_INTERFACE_CONFIG_SCRIPT"
    return 1
  fi
  if ! proton_manual_conf_file_ok && ! can_capture_terminal_input; then
    PREPARE_LAST_REASON="нет PROTON_MANUAL_CONF_FILE и нет интерактивного TTY для ввода .conf (SSH -t или меню)"
    return 1
  fi

  profile_mode="$(meta_get "$source_meta" "PROFILE_MODE")"
  variant_id="$(meta_get "$source_meta" "VARIANT_ID")"
  awg_version="$(meta_get "$source_meta" "AWG_VERSION")"
  server_country="$(meta_get "$source_meta" "SERVER_COUNTRY")"

  proton_mode_flag="--local"
  [ "$profile_mode" = "raw" ] && proton_mode_flag="--raw"
  proton_country="${server_country:-NL}"
  proton_version="${awg_version:-2.0}"
  proton_variant="${variant_id:-1}"

  tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/xfree-proton-manual.XXXXXX")"
  tmp_input="$tmp_dir/manual-proton.conf"
  tmp_conf_dir="$tmp_dir/generated"
  mkdir -p "$tmp_conf_dir"

  if ! capture_proton_conf_to_file "$tmp_input"; then
    rm -rf "$tmp_dir"
    PREPARE_LAST_REASON="manual input cancelled"
    return 1
  fi

  if [ ! -s "$tmp_input" ]; then
    rm -rf "$tmp_dir"
    PREPARE_LAST_REASON="manual input is empty"
    return 1
  fi

  prepare_msg_tty "[*] Proton (ручной импорт): import-conf.sh для $iface…"
  if ! run_with_visible_log env CONF_DIR="$tmp_conf_dir" "$PROTON_IMPORT_CONF_SCRIPT" \
      "$proton_mode_flag" \
      --country "$proton_country" \
      --version "$proton_version" \
      --variant "$proton_variant" \
      --from-file "$tmp_input" \
      --name "restore-$iface"; then
    rm -rf "$tmp_dir"
    PREPARE_LAST_REASON="manual import failed: ${PREPARE_LAST_REASON:-unknown error}"
    return 1
  fi

  generated_conf="$(find "$tmp_conf_dir" -mindepth 1 -maxdepth 1 -type f -name '*.conf' | sort | head -n 1)"
  if [ -z "${generated_conf:-}" ]; then
    rm -rf "$tmp_dir"
    PREPARE_LAST_REASON="manual import did not produce .conf"
    return 1
  fi

  prepare_msg_tty "[*] Proton (ручной импорт): update-interface-config для $iface…"
  if ! run_with_visible_log "$UPDATE_INTERFACE_CONFIG_SCRIPT" --iface "$iface" --source "$generated_conf"; then
    rm -rf "$tmp_dir"
    PREPARE_LAST_REASON="failed to apply imported .conf: ${PREPARE_LAST_REASON:-unknown error}"
    return 1
  fi

  network_uci="$config_dir/network.uci"
  source_conf="$config_dir/source.conf"
  if [ ! -f "$network_uci" ] || ! has_private_key_line "$source_conf"; then
    rm -rf "$tmp_dir"
    PREPARE_LAST_REASON="materialization check failed after manual import"
    return 1
  fi

  prepare_msg_tty "[*] Proton (ручной импорт): интерфейс $iface обновлён."
  rm -rf "$tmp_dir"
  return 0
}

profile_tree_has_template_tokens() {
  template_tree_has_placeholder_tokens "$1"
}

profile_has_pending_template_markers() {
  template_profile_has_pending_markers "$PROFILE_DIR" "$INTERFACES_DIR" "$PROFILE_DIR/awg-ingress"
}

profile_cleanup_stale_template_markers() {
  template_profile_cleanup_stale_markers "$PROFILE_DIR" "$INTERFACES_DIR" "$PROFILE_DIR/awg-ingress" info
}

record_prepare_warning() {
  message="$1"
  PREPARE_WARNINGS=$((PREPARE_WARNINGS + 1))
  PREPARE_WARNING_DETAILS="${PREPARE_WARNING_DETAILS}- ${message}
"
  warn "$message"
}

prepare_msg_tty() {
  # SSH без -t: /dev/tty может существовать, но запись в него падает (set -e).
  if [ -t 1 ] && printf '%s\n' "$1" >/dev/tty 2>/dev/null; then
    return 0
  fi
  printf '%s\n' "$1" >&2
}

run_with_visible_log() {
  out_file="$(mktemp "${TMPDIR:-/tmp}/xfree-prepare-log.XXXXXX")"
  fifo="$(mktemp -u "${TMPDIR:-/tmp}/xfree-prepare-fifo.XXXXXX")"
  cmd_rc=0

  if ! mkfifo "$fifo" 2>/dev/null; then
    if common_exec_streaming "$@" >"$out_file" 2>&1; then
      [ -s "$out_file" ] && cat "$out_file"
      rm -f "$out_file"
      return 0
    fi
    [ -s "$out_file" ] && cat "$out_file" >&2
    short_reason="$(sed '/^$/d' "$out_file" | tail -n 3 | tr '\n' ' ' | sed 's/[[:space:]]\{1,\}/ /g; s/[[:space:]]*$//')"
    rm -f "$out_file"
    [ -n "$short_reason" ] || short_reason="unknown error"
    PREPARE_LAST_REASON="$short_reason"
    return 1
  fi

  tee "$out_file" <"$fifo" &
  tee_pid=$!

  set +e
  common_exec_streaming "$@" >"$fifo" 2>&1
  cmd_rc=$?
  set -e

  wait "$tee_pid" 2>/dev/null || true
  rm -f "$fifo"

  if [ "$cmd_rc" -eq 0 ]; then
    rm -f "$out_file"
    return 0
  fi

  # Live tee already printed the log; do not dump it again (looks like a second apply).
  short_reason="$(sed '/^$/d' "$out_file" | tail -n 3 | tr '\n' ' ' | sed 's/[[:space:]]\{1,\}/ /g; s/[[:space:]]*$//')"
  rm -f "$out_file"
  [ -n "$short_reason" ] || short_reason="unknown error"
  PREPARE_LAST_REASON="$short_reason"
  return 1
}

run_sh_script_with_crlf_fallback() {
  script="$1"
  shift || true

  if run_with_visible_log sh "$script" "$@"; then
    return 0
  fi

  case "${PREPARE_LAST_REASON:-}" in
    *"illegal option -"*)
      warn "Обнаружена shell-несовместимость в $script, пробую повторно с CRLF->LF нормализацией"
      script_dir="$(CDPATH= cd -- "$(dirname -- "$script")" && pwd -P)"
      script_base="$(basename -- "$script")"
      tmp_script="$script_dir/.${script_base}.shfix.$$"
      awk '{ sub(/\r$/, ""); print }' "$script" > "$tmp_script"
      chmod +x "$tmp_script" 2>/dev/null || true
      if run_with_visible_log sh "$tmp_script" "$@"; then
        rm -f "$tmp_script"
        return 0
      fi
      rm -f "$tmp_script"
      ;;
  esac

  return 1
}

# На роутере: zapret до WARP/iface — иначе prepare не достучится до Cloudflare.
prepare_router_network_and_index() {
  [ "$PREPARE_HOST_ONLY" = "1" ] && return 0
  command -v opkg >/dev/null 2>&1 || command -v apk >/dev/null 2>&1 || return 0
  [ -f "$ROOT_DIR/lib/pkgmgr.sh" ] || return 0
  # shellcheck disable=SC1090
  . "$ROOT_DIR/lib/pkgmgr.sh"
  prepare_msg_tty "[*] prepare-template: сеть + индексы пакетов перед AWG/zapret…"
  common_wait_network_after_restart "${XFREE_NETWORK_WAIT_SEC:-90}" github.com || \
    record_prepare_warning "prepare-template: сеть не готова перед AWG/zapret (маршрут/uplink/DNS)"
  pm_update_index_optional
}

prepare_zapret_runtime_bootstrap() {
  [ "$PREPARE_HOST_ONLY" = "1" ] && return 0
  [ "$IFACE_PREPARE_ENABLED" = "1" ] || return 0
  [ -d "$PROFILE_DIR/zapret" ] || return 0

  [ -f "$ZAPRET_BOOTSTRAP_SCRIPT" ] || die "Не найден zapret bootstrap script: $ZAPRET_BOOTSTRAP_SCRIPT"
  prepare_msg_tty "[*] prepare-template: zapret (ensure + apply) перед iface-routing…"
  PROFILE_DIR="$PROFILE_DIR" \
    ZAPRET_ENGINE=zapret \
    XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE="${XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE:-0}" \
    sh "$ZAPRET_BOOTSTRAP_SCRIPT" --skip-if-pipeline-applied \
    || die "Не удалось bootstrap zapret перед iface-routing"
}

prepare_iface_templates() {
  [ -d "$INTERFACES_DIR" ] || {
    info "iface-routing: каталог интерфейсов не найден, пропускаю"
    return 0
  }
  [ -f "$IFACE_REGENERATE_SCRIPT" ] || die "Не найден regenerate script: $IFACE_REGENERATE_SCRIPT"
  iface_warnings_before="$PREPARE_WARNINGS"
  iface_prepare_needed=0

  [ -f "$INTERFACES_DIR/TEMPLATE" ] && iface_prepare_needed=1
  [ -f "$PROFILE_DIR/iface-routing/TEMPLATE" ] && iface_prepare_needed=1

  iface_list_file="$(mktemp "${TMPDIR:-/tmp}/xfree-iface-list.XXXXXX")"
  find "$INTERFACES_DIR" -mindepth 3 -maxdepth 3 -type f -path '*/config/iface.conf' 2>/dev/null | sort > "$iface_list_file"
  while IFS= read -r iface_conf; do
        [ -n "$iface_conf" ] || continue

        config_dir="$(dirname -- "$iface_conf")"
        iface_dir="$(dirname -- "$config_dir")"
        iface="$(basename -- "$iface_dir")"
        source_conf="$config_dir/source.conf"
        network_uci="$config_dir/network.uci"
        source_meta="$config_dir/source.conf.meta"
        marker="$config_dir/TEMPLATE"
        iface_marker="$iface_dir/TEMPLATE"
        generator_kind="$(meta_get "$source_meta" "GENERATOR_KIND")"

        if [ ! -f "$marker" ] && [ ! -f "$iface_marker" ]; then
          continue
        fi
        iface_prepare_needed=1

        if [ ! -f "$source_meta" ]; then
          warn "iface-routing template: пропускаю $iface, отсутствует source.conf.meta"
          continue
        fi

        case "$generator_kind" in
          warp|proton)
            ;;
          "")
            record_prepare_warning "iface-routing template: не удалось подготовить $iface: в source.conf.meta отсутствует GENERATOR_KIND"
            continue
            ;;
          *)
            record_prepare_warning "iface-routing template: не удалось подготовить $iface: автовосстановление не поддерживает GENERATOR_KIND=$generator_kind"
            continue
            ;;
        esac

        if [ -f "$network_uci" ] && has_private_key_line "$source_conf"; then
          info "iface-routing template: $iface уже подготовлен"
          [ -f "$marker" ] && rm -f "$marker" 2>/dev/null || true
          [ -f "$iface_marker" ] && rm -f "$iface_marker" 2>/dev/null || true
          continue
        fi

        info "iface-routing template: подготавливаю $iface"
        prepare_msg_tty "[*] iface-routing template: подготавливаю $iface (regenerate-interface-config)…"
        if ! run_with_visible_log env \
            PROFILE_DIR="$PROFILE_DIR" \
            INTERFACES_DIR="$INTERFACES_DIR" \
            PROTON_SESSIONS_DIR="${PROTON_SESSIONS_DIR:-}" \
            "$IFACE_REGENERATE_SCRIPT" --iface "$iface" --force; then
          record_prepare_warning "iface-routing template: не удалось подготовить $iface: ${PREPARE_LAST_REASON:-unknown error}"
          continue
        fi

        [ -f "$marker" ] && rm -f "$marker" 2>/dev/null || true
        [ -f "$iface_marker" ] && rm -f "$iface_marker" 2>/dev/null || true
      done < "$iface_list_file"
  rm -f "$iface_list_file"

  if [ "$iface_prepare_needed" != "1" ]; then
    info "iface-routing: маркеров TEMPLATE нет — пропуск"
    return 0
  fi

  if [ "$PREPARE_WARNINGS" -eq "$iface_warnings_before" ]; then
    profile_cleanup_stale_template_markers
  fi

  if [ "$PREPARE_WARNINGS" -gt 0 ]; then
    warn "iface-routing: маркеры TEMPLATE с предупреждениями: $PREPARE_WARNINGS"
  else
    info "iface-routing: маркеры TEMPLATE закрыты"
  fi
}

prepare_awg_template() {
  AWG_SCRIPT_DIR="$ROOT_DIR/awg-ingress"
  [ -d "$AWG_SCRIPT_DIR" ] || die "Не найден awg-ingress dir: $AWG_SCRIPT_DIR"
  [ -f "$AWG_STATUS_SCRIPT" ] || die "Не найден AWG status script: $AWG_STATUS_SCRIPT"
  [ -f "$AWG_ENSURE_SCRIPT" ] || die "Не найден AWG ensure script: $AWG_ENSURE_SCRIPT"
  AWG_PROFILE_DIR="${PROFILE_DIR}/awg-ingress"
  [ -d "$AWG_PROFILE_DIR" ] || {
    info "AWG ingress: каталог профиля не найден, пропускаю"
    return 0
  }

  inherited_template=0
  [ -f "$PROFILE_DIR/TEMPLATE" ] && inherited_template=1
  [ -f "$AWG_PROFILE_DIR/TEMPLATE" ] && inherited_template=1

  awg_profile_needs_prepare=0
  if [ -f "$AWG_PROFILE_DIR/server/server.env" ] && \
     rg -n '\*\*\*RECREATE\*\*\*' "$AWG_PROFILE_DIR/server/server.env" >/dev/null 2>&1; then
    awg_profile_needs_prepare=1
  fi
  if [ "$awg_profile_needs_prepare" = "0" ] && [ -d "$AWG_PROFILE_DIR/peers" ] && \
     rg -n '\*\*\*RECREATE\*\*\*|\*\*\*PROMPT\*\*\*' "$AWG_PROFILE_DIR/peers" >/dev/null 2>&1; then
    awg_profile_needs_prepare=1
  fi

  if [ "$inherited_template" != "1" ] && [ "$awg_profile_needs_prepare" != "1" ]; then
    info "AWG ingress: маркеров TEMPLATE нет — пропуск"
    return 0
  fi
  if [ "$inherited_template" != "1" ] && [ "$awg_profile_needs_prepare" = "1" ]; then
    info "AWG ingress: marker не найден, но обнаружены template-токены (***RECREATE***/***PROMPT***), выполняю подготовку"
  fi

  prepare_msg_tty "[*] prepare-template: этап AWG ingress (ensure/install и materialization — может занять несколько минут)…"
  info "AWG ingress template: проверяю/устанавливаю AWG"
  prepare_msg_tty "[*] AWG ingress: ensure-awg.sh --install-if-missing…"
  if ! run_sh_script_with_crlf_fallback "$AWG_ENSURE_SCRIPT" --install-if-missing; then
    if [ "$PREPARE_HOST_ONLY" = "1" ] && command -v awg >/dev/null 2>&1; then
      info "AWG ingress: ensure-awg не удался (не OpenWrt?), использую awg из PATH (host-only)"
    else
      record_prepare_warning "AWG ingress template: не удалось проверить/установить AWG: ${PREPARE_LAST_REASON:-unknown error}"
      prepare_msg_tty "[!] AWG ingress: ensure-awg не удался — этап пропущен (см. лог)."
      return 0
    fi
  fi

  tmp_state_root="$(mktemp -d "${TMPDIR:-/tmp}/xfree-awg-template.XXXXXX")"

  mkdir -p "$tmp_state_root/awg-ingress/state"
  if [ "$inherited_template" = "1" ] || [ "$awg_profile_needs_prepare" = "1" ]; then
    : > "$tmp_state_root/awg-ingress/TEMPLATE"
  fi
  [ -f "$AWG_PROFILE_DIR/TEMPLATE" ] && cp -f "$AWG_PROFILE_DIR/TEMPLATE" "$tmp_state_root/awg-ingress/TEMPLATE"
  [ -d "$AWG_PROFILE_DIR/server" ] && cp -a "$AWG_PROFILE_DIR/server" "$tmp_state_root/awg-ingress/state/server"
  [ -d "$AWG_PROFILE_DIR/peers" ] && cp -a "$AWG_PROFILE_DIR/peers" "$tmp_state_root/awg-ingress/state/peers"
  [ -f "$AWG_PROFILE_DIR/peers.tsv" ] && cp -f "$AWG_PROFILE_DIR/peers.tsv" "$tmp_state_root/awg-ingress/state/peers.tsv"

  if [ "$PREPARE_HOST_ONLY" = "1" ]; then
    awg_prepare_fn="awgingress_prepare_template_state_host"
    prepare_msg_tty "[*] AWG ingress: host-only (server + ключи peers; endpoint — на роутере)…"
  else
    awg_prepare_fn="awgingress_prepare_template_state"
    prepare_msg_tty "[*] AWG ingress: awgingress_prepare_template_state (временный state)…"
  fi

  if ! run_with_visible_log env PROFILE_DIR="$PROFILE_DIR" XFREE_STATE_ROOT="$tmp_state_root" \
      sh -c '
        . "$0"
        '"$awg_prepare_fn"'
      ' "$AWG_SCRIPT_DIR/lib.sh"; then
    record_prepare_warning "AWG ingress template: не удалось подготовить профиль: ${PREPARE_LAST_REASON:-unknown error}"
    prepare_msg_tty "[!] AWG ingress: materialization не удалась — этап пропущен (см. лог)."
    rm -rf "$tmp_state_root"
    return 0
  fi

  mkdir -p "$AWG_PROFILE_DIR"
  rm -rf "$AWG_PROFILE_DIR/server" "$AWG_PROFILE_DIR/peers"
  cp -a "$tmp_state_root/awg-ingress/state/server" "$AWG_PROFILE_DIR/server" 2>/dev/null || true
  cp -a "$tmp_state_root/awg-ingress/state/peers" "$AWG_PROFILE_DIR/peers" 2>/dev/null || true
  if [ "$PREPARE_HOST_ONLY" != "1" ]; then
    if [ -f "$tmp_state_root/awg-ingress/state/peers.tsv" ]; then
      cp -f "$tmp_state_root/awg-ingress/state/peers.tsv" "$AWG_PROFILE_DIR/peers.tsv"
    else
      rm -f "$AWG_PROFILE_DIR/peers.tsv"
    fi
  fi

  rm -rf "$tmp_state_root"

  if [ "$PREPARE_HOST_ONLY" = "1" ]; then
    if profile_tree_has_template_tokens "$AWG_PROFILE_DIR"; then
      mkdir -p "$AWG_PROFILE_DIR"
      : > "$AWG_PROFILE_DIR/TEMPLATE"
      info "AWG ingress: оставляю TEMPLATE — на роутере нужен endpoint (***PROMPT***)"
    else
      [ -f "$AWG_PROFILE_DIR/TEMPLATE" ] && rm -f "$AWG_PROFILE_DIR/TEMPLATE" 2>/dev/null || true
    fi
    success "AWG ingress host-подготовка завершена (полная materialization — на роутере)"
  else
    [ -f "$AWG_PROFILE_DIR/TEMPLATE" ] && rm -f "$AWG_PROFILE_DIR/TEMPLATE" 2>/dev/null || true
    info "AWG ingress: маркеры TEMPLATE закрыты"
  fi
}

show_description() {
  file="$ROOT_DIR/TEMPLATE-PREP.md"
  [ -f "$file" ] || die "Не найдено описание: $file"
  cat "$file"
}

if [ "$#" -gt 0 ]; then
  AWG_PREPARE_ENABLED=0
  IFACE_PREPARE_ENABLED=0
fi

while [ "$#" -gt 0 ]; do
  case "$1" in
    --iface-routing)
      IFACE_PREPARE_ENABLED=1
      ;;
    --awg-ingress)
      AWG_PREPARE_ENABLED=1
      ;;
    --describe)
      show_description
      exit 0
      ;;
    --proton-manual-import)
      PROTON_MANUAL_IMPORT_ENABLED=1
      PROTON_MANUAL_IMPORT_EXPLICIT=on
      ;;
    --no-proton-manual-import)
      PROTON_MANUAL_IMPORT_ENABLED=0
      PROTON_MANUAL_IMPORT_EXPLICIT=off
      ;;
    --proton-preflight-only)
      PROTON_PREFLIGHT_ONLY=1
      IFACE_PREPARE_ENABLED=1
      PROTON_MANUAL_IMPORT_ENABLED=1
      ;;
    --proton-preflight-check-only)
      PROTON_PREFLIGHT_CHECK_ONLY=1
      IFACE_PREPARE_ENABLED=1
      ;;
    --host-only)
      PREPARE_HOST_ONLY=1
      ;;
    --profile-dir)
      shift
      [ "$#" -gt 0 ] || die "Не указано значение для --profile-dir"
      PROFILE_DIR_ARG="$1"
      PROFILE_DIR_EXPLICIT=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Неизвестный аргумент: $1"
      ;;
  esac
  shift
done

# Explicit --profile-dir wins even if config.sh still has another active profile
# (instantiate default-with-proton while XFREE_PROFILE=default).
if [ "$PROFILE_DIR_EXPLICIT" = "1" ] && [ -n "$PROFILE_DIR_ARG" ]; then
  export XFREE_APPLY_PROFILE_DIR="$PROFILE_DIR_ARG"
fi
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "$PROFILE_DIR_ARG")"
INTERFACES_DIR="${INTERFACES_DIR_OVERRIDE:-$PROFILE_DIR/iface-routing/interfaces}"

[ "${XFREE_PREPARE_HOST_ONLY:-0}" = "1" ] && PREPARE_HOST_ONLY=1

if [ "${PROTON_MANUAL_IMPORT_EXPLICIT:-}" != "off" ] && proton_manual_conf_file_ok; then
  PROTON_MANUAL_IMPORT_ENABLED=1
fi

[ "$IFACE_PREPARE_ENABLED" = "1" ] || [ "$AWG_PREPARE_ENABLED" = "1" ] || \
  [ "$PROTON_PREFLIGHT_ONLY" = "1" ] || [ "$PROTON_PREFLIGHT_CHECK_ONLY" = "1" ] || \
  die "Не выбраны модули для подготовки"

if [ "$PROTON_PREFLIGHT_CHECK_ONLY" = "1" ]; then
  if prepare_proton_unresolved_ifaces_p; then
    exit 0
  fi
  exit 1
fi

if [ "$PROTON_PREFLIGHT_ONLY" = "1" ]; then
  prepare_proton_preflight_sync
  exit 0
fi

ACTIVE_PROFILE_NAME="$(common_active_profile_name "$ROOT_DIR")"
info "prepare-template: активный профиль: $ACTIVE_PROFILE_NAME"
if [ "$PREPARE_HOST_ONLY" = "1" ]; then
  info "prepare-template: режим host-only (частичная подготовка; TEMPLATE остаётся для полей роутера)"
fi
info "prepare-template: PROFILE_DIR=$PROFILE_DIR"
if [ "$IFACE_PREPARE_ENABLED" = "1" ]; then
  info "prepare-template: iface-routing dir=$INTERFACES_DIR"
fi
if [ "$AWG_PREPARE_ENABLED" = "1" ]; then
  info "prepare-template: awg-ingress dir=$PROFILE_DIR/awg-ingress"
fi

# On router: WARP/iface generators need awg/wg — install AWG before iface-routing.
# host-only: iface (Proton sessions on PC) first, then AWG keys without router install.
if [ "$PREPARE_HOST_ONLY" = "1" ]; then
  if [ "$IFACE_PREPARE_ENABLED" = "1" ]; then
    prepare_proton_preflight_sync
    prepare_iface_templates
  fi
  if [ "$AWG_PREPARE_ENABLED" = "1" ]; then
    prepare_awg_template
  fi
else
  prepare_router_network_and_index
  # zapret один раз; из apply-template — skip (уже шаг после DNS).
  if [ "$IFACE_PREPARE_ENABLED" = "1" ]; then
    prepare_zapret_runtime_bootstrap
  fi
  if [ "$AWG_PREPARE_ENABLED" = "1" ]; then
    prepare_awg_template
  fi
  if [ "$IFACE_PREPARE_ENABLED" = "1" ]; then
    prepare_msg_tty "[*] prepare-template: жду HTTPS api.cloudflareclient.com после zapret (перед WARP)…"
    common_wait_network_after_restart "${XFREE_NETWORK_WAIT_SEC:-60}" api.cloudflareclient.com https || \
      record_prepare_warning "prepare-template: HTTPS api.cloudflareclient.com недоступен после zapret"
    if prepare_proton_unresolved_ifaces_p; then
      prepare_msg_tty "[*] prepare-template: жду HTTPS account.protonvpn.com перед guest-сессией…"
      common_wait_network_after_restart "${XFREE_NETWORK_WAIT_SEC:-60}" account.protonvpn.com https || \
        record_prepare_warning "prepare-template: HTTPS account.protonvpn.com недоступен перед guest-сессией"
    fi
    prepare_proton_preflight_sync
    prepare_iface_templates
  fi
fi

profile_cleanup_stale_template_markers

if [ "$PREPARE_WARNINGS" -gt 0 ]; then
  warn "маркеры TEMPLATE: предупреждения ($PREPARE_WARNINGS)"
  printf '%s' "$PREPARE_WARNING_DETAILS" >&2
else
  if profile_has_pending_template_markers; then
    mkdir -p "$PROFILE_DIR"
    : > "$PROFILE_DIR/TEMPLATE"
    if [ "$PREPARE_HOST_ONLY" = "1" ]; then
      info "host-only: TEMPLATE оставлен — на роутере apply дозаполнит endpoint AWG"
    else
      warn "в профиле остались маркеры TEMPLATE / токены"
    fi
  else
    [ -f "$PROFILE_DIR/TEMPLATE" ] && rm -f "$PROFILE_DIR/TEMPLATE" 2>/dev/null || true
  fi
fi
