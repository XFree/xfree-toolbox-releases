#!/bin/sh
# shellcheck shell=sh
# Sync portable lists/configs from profile-templates/<t> -> profiles/<p> (no prepare).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/profile-from-template-lib.sh"

load_base_config "$ROOT_DIR"

TEMPLATE_NAME=""
PROFILE_NAME=""

usage() {
  cat <<EOF
Usage: $(basename "$0") --template <id> --profile <name>

Updates an existing profile from a template: **lists-only copy**
(dns/zapret/fqdn trees; live iface config/ kept). Recreate uses
instantiate --force (full template copy) instead.
Does not run prepare-template or apply-template.

If profile-templates/<id> is gone, <id> may match TEMPLATE_ALIAS in another
template's EXPORT-META.txt. The profile is updated from that directory and
TEMPLATE_REF is rewritten to its name. Two templates with the same alias
and no directory is an error. An existing directory wins over any alias.

  -h, --help
EOF
  exit 2
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --template)
      shift
      [ "$#" -gt 0 ] || xfree_pt_die "Не указано значение для --template"
      TEMPLATE_NAME="$1"
      ;;
    --profile)
      shift
      [ "$#" -gt 0 ] || xfree_pt_die "Не указано значение для --profile"
      PROFILE_NAME="$1"
      ;;
    -h | --help) usage ;;
    *)
      xfree_pt_die "Неизвестный аргумент: $1"
      ;;
  esac
  shift || true
done

[ -n "$TEMPLATE_NAME" ] && [ -n "$PROFILE_NAME" ] || usage

TEMPLATE_NAME="$(common_sanitize_profile_name "$TEMPLATE_NAME")" || xfree_pt_die "Некорректное имя шаблона"
PROFILE_NAME="$(common_sanitize_profile_name "$PROFILE_NAME")" || xfree_pt_die "Некорректное имя профиля"

_pt_rc=0
_pt_canonical="$(common_profile_template_resolve_id "$ROOT_DIR" "$TEMPLATE_NAME")" || _pt_rc=$?
if [ "$_pt_rc" -eq 2 ]; then
  xfree_pt_die "Неоднозначный алиас шаблона: $TEMPLATE_NAME"
fi
if [ "$_pt_rc" -ne 0 ] || [ -z "$_pt_canonical" ]; then
  xfree_pt_die "Шаблон не найден: $TEMPLATE_NAME"
fi
if [ "$_pt_canonical" != "$TEMPLATE_NAME" ]; then
  xfree_pt_info "[*] Каталог profile-templates/$TEMPLATE_NAME отсутствует; алиас -> $_pt_canonical (TEMPLATE_REF будет записан как $_pt_canonical)"
fi
TEMPLATE_NAME="$_pt_canonical"

template_dir="$(common_profile_template_resolve_dir "$ROOT_DIR" "$TEMPLATE_NAME")"
profile_dir="$(common_profile_resolve_dir "$ROOT_DIR" "$PROFILE_NAME")"

[ -d "$template_dir" ] || xfree_pt_die "Шаблон не найден: $template_dir"
[ -d "$profile_dir" ] || xfree_pt_die "Профиль не найден: $profile_dir"

xfree_pt_info "[*] Sync portable: $TEMPLATE_NAME -> profiles/$PROFILE_NAME"
xfree_pt_info "[*] Источник шаблона: $template_dir"
xfree_pt_sync_template_to_profile "$template_dir" "$profile_dir"
xfree_pt_write_profile_meta_sync "$profile_dir" "$PROFILE_NAME" "$TEMPLATE_NAME"
xfree_pt_info "[+] Обновлено (без prepare): $profile_dir"
