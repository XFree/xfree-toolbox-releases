#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
TB=/root/xfree-toolbox
echo "=== summary lines warp* ==="
IFACE_LUCI_FOREGROUND=1 sh "$TB/iface-routing/luci-rpc.sh" summary 2>/dev/null | grep -E '^IFACE=(warp|warp3|proton)' || true
echo
echo "=== warp3 files ==="
ls -la "$TB/profiles/default/iface-routing/interfaces/warp3/config/" 2>/dev/null || ls -la /etc/xfree-toolbox/iface-routing/state/interfaces/warp3/config/ 2>/dev/null || true
for d in \
  "$TB/profiles/default/iface-routing/interfaces/warp3" \
  /etc/xfree-toolbox/iface-routing/state/interfaces/warp3 \
  /etc/xfree-toolbox/iface-routing/generated/interfaces/warp3
do
  echo "-- $d"
  [ -d "$d" ] && du -sh "$d" && ls -la "$d" "$d/config" 2>/dev/null | head -20 || echo "(нет)"
done
echo
echo "=== traffic_path_runtime_iface warp3 ==="
. "$TB/diagnostics/lib/traffic-path.sh"
TRAFFIC_PATH_ROOT="$TB"
traffic_path_init_paths
traffic_path_runtime_iface warp3 2>/dev/null || true
echo
echo "=== compare warp ==="
traffic_path_runtime_iface warp 2>/dev/null || true
REMOTE
