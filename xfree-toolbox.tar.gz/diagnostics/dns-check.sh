#!/bin/sh
# shellcheck shell=sh
# Диагностика DNS: запросы к базовым именам, время отклика, лог последнего прогона.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/cmd-timeout.sh"
. "$ROOT_DIR/lib/system-logs.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/https-dns-proxy/lib/doh-probe.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/dns-check.sh"

PRINT_ONLY=0
DNS_ROOT=""

usage() {
	cat <<EOF
Usage: $(basename "$0") [options]

Запросы A к базовым именам по всем секциям DNS активного профиля
(не через 127.0.0.1#53). В отчёте помечен основной (DNS_REDIRECT=1, catch-all).
Пишет последний отчёт в $(system_logs_dns_check_log).

Options:
  --print-only     список секций и имён, без drill
  --dns-root DIR   каталог dns-routing/dns (по умолчанию — активный профиль)
  -h, --help
EOF
}

while [ "$#" -gt 0 ]; do
	case "$1" in
		--print-only) PRINT_ONLY=1 ;;
		--dns-root)
			[ "$#" -ge 2 ] || die "--dns-root: нужен путь"
			DNS_ROOT="$2"
			shift
			;;
		-h | --help)
			usage
			exit 0
			;;
		*) die "Неизвестный аргумент: $1" ;;
	esac
	shift
done

LOG="$(system_logs_dns_check_log)"
mkdir -p "$(dirname -- "$LOG")" 2>/dev/null || true

STAMP="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"

if [ -z "$DNS_ROOT" ]; then
	DNS_ROOT="$(common_profile_dir "$ROOT_DIR")/dns-routing/dns"
fi

dns_check_main() {
	printf '=== Диагностика DNS %s ===\n' "$STAMP"
	printf 'Лог: %s\n' "$LOG"
	printf '\n'

	if [ ! -d "$DNS_ROOT" ]; then
		printf 'Нет каталога секций DNS:\n  %s\n' "$DNS_ROOT"
		printf '\n[*] Итог проверки: FAIL no-sections\n'
		return 2
	fi

	_prim="$(dns_check_primary_summary "$DNS_ROOT" || true)"
	if [ -n "$_prim" ]; then
		printf 'Основной DNS (catch-all): %s\n' "$_prim"
	else
		printf 'Основной DNS (catch-all): не задан (нет DNS_REDIRECT=1)\n'
	fi
	printf '\n'

	if [ "$PRINT_ONLY" -eq 1 ]; then
		printf 'Секции:\n'
		dns_check_list_resolvers "$DNS_ROOT" | while IFS='|' read -r _addr _port _lab _primf; do
			_mark=""
			[ "$_primf" = "1" ] && _mark=" [основной]"
			printf '  %s#%s  %s%s\n' "$_addr" "$_port" "$_lab" "$_mark"
		done
		printf '\nИмена:\n'
		dns_check_hosts | while read -r _h; do
			printf '  %s\n' "$_h"
		done
		printf '\n[*] Итог проверки: print-only (без drill)\n'
		return 0
	fi

	if ! command -v drill >/dev/null 2>&1; then
		printf 'Нет утилиты drill. Установите базовые пакеты (меню Система).\n'
		printf '\n[*] Итог проверки: FAIL no-drill\n'
		return 2
	fi

	_ok=0
	_fail=0
	_slow_ms=0
	_slow_where=""
	_res_f="${TMPDIR:-/tmp}/xfree-dns-check-resolvers.$$"
	_hosts_f="${TMPDIR:-/tmp}/xfree-dns-check-hosts.$$"
	if ! dns_check_list_resolvers "$DNS_ROOT" >"$_res_f"; then
		printf 'В профиле нет секций DNS с DNS_TARGET:\n  %s\n' "$DNS_ROOT"
		printf '\n[*] Итог проверки: FAIL no-sections\n'
		rm -f "$_res_f" "$_hosts_f" 2>/dev/null || true
		return 2
	fi
	dns_check_hosts >"$_hosts_f"

	while IFS='|' read -r _addr _port _lab _primf; do
		[ -n "$_port" ] || continue
		dns_check_format_section_header "$_addr" "$_port" "$_lab" "$_primf"
		while read -r _host; do
			[ -n "$_host" ] || continue
			_q=""
			_q="$(dns_check_query_one "$_addr" "$_port" "$_host")" || true
			_st="${_q%% *}"
			_qr="${_q#* }"
			_rcode="${_qr%% *}"
			_qr="${_qr#* }"
			_msec="${_qr%% *}"
			_a="${_qr#* }"
			dns_check_format_row "$_host" "$_st" "$_rcode" "$_msec" "$_a"
			if [ "$_st" = "OK" ]; then
				_ok=$((_ok + 1))
			else
				_fail=$((_fail + 1))
			fi
			case "$_msec" in
				'' | *[!0-9]*) ;;
				*)
					if [ "$_msec" -gt "$_slow_ms" ]; then
						_slow_ms="$_msec"
						_slow_where="${_host} @ ${_lab} ${_addr}#${_port}"
					fi
					;;
			esac
		done <"$_hosts_f"
		printf '\n'
	done <"$_res_f"

	rm -f "$_res_f" "$_hosts_f" 2>/dev/null || true

	_total=$((_ok + _fail))
	if [ "$_fail" -eq 0 ] && [ "$_total" -gt 0 ]; then
		printf '[*] Итог проверки: %s/%s OK' "$_ok" "$_total"
		if [ "$_slow_ms" -gt 0 ]; then
			printf '; самый медленный %s %sms' "$_slow_where" "$_slow_ms"
		fi
		printf '\n'
		return 0
	fi
	printf '[*] Итог проверки: FAIL %s/%s (ok=%s fail=%s)\n' "$_fail" "$_total" "$_ok" "$_fail"
	return 1
}

_rcf="${TMPDIR:-/tmp}/xfree-dns-check-rc.$$"
{
	set +e
	dns_check_main
	echo $? >"$_rcf"
	set -e
} | tee "$LOG"
_rc="$(tr -d ' \n\r' <"$_rcf" 2>/dev/null || echo 1)"
rm -f "$_rcf" 2>/dev/null || true
exit "$_rc"
