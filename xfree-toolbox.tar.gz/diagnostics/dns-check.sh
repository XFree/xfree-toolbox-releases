#!/bin/sh
# shellcheck shell=sh
# Диагностика DNS: запросы к базовым именам, время отклика, лог последнего прогона.
# LuCI: --bg-start / --status (uhttpd script_timeout ~60s — полный drill дольше).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/cmd-timeout.sh"
. "$ROOT_DIR/lib/system-logs.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/https-dns-proxy/lib/doh-probe.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/dns-check.sh"

PRINT_ONLY=0
MODE=run
DNS_ROOT=""

DNS_CHECK_PID_FILE="${XFREE_DNS_CHECK_PID_FILE:-${TMPDIR:-/tmp}/xfree-dns-check.pid}"

usage() {
	cat <<EOF
Usage: $(basename "$0") [options]

Запросы A к базовым именам по секциям DNS активного профиля
(не через 127.0.0.1#53) + эталоны Google: 8.8.8.8 (без DoH) и dns.google DoH
(127.0.0.1#5062). Хосты внутри секции — параллельно. Основной (DNS_REDIRECT=1)
помечен. Пишет последний отчёт в $(system_logs_dns_check_log).

Options:
  --print-only     список секций и имён, без drill
  --last           показать последний лог (быстро, для LuCI)
  --status         STATUS running|idle + последний лог (без запуска)
  --bg-start       запустить drill в фоне (если ещё не бежит) + --status
  --dns-root DIR   каталог dns-routing/dns (по умолчанию — активный профиль)
  -h, --help
EOF
}

while [ "$#" -gt 0 ]; do
	case "$1" in
		--print-only) PRINT_ONLY=1 ;;
		--last) MODE=last ;;
		--status) MODE=status ;;
		--bg-start) MODE=bg-start ;;
		--dns-root)
			[ "$#" -ge 2 ] || die "--dns-root: нужен путь"
			DNS_ROOT="$2"
			shift
			;;
		-h | --help)
			usage
			exit 0
			;;
		*) die "Неизвестный аргумент: $1" ;;
	esac
	shift
done

LOG="$(system_logs_dns_check_log)"
mkdir -p "$(dirname -- "$LOG")" 2>/dev/null || true

STAMP="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"

if [ -z "$DNS_ROOT" ]; then
	DNS_ROOT="$(common_profile_dir "$ROOT_DIR")/dns-routing/dns"
fi

dns_check_pid_running() {
	_pid=""
	[ -f "$DNS_CHECK_PID_FILE" ] || return 1
	_pid="$(tr -d ' \n\r' <"$DNS_CHECK_PID_FILE" 2>/dev/null || true)"
	[ -n "$_pid" ] || return 1
	kill -0 "$_pid" 2>/dev/null || return 1
	return 0
}

dns_check_emit_banner() {
	if dns_check_pid_running; then
		_pid="$(tr -d ' \n\r' <"$DNS_CHECK_PID_FILE" 2>/dev/null || true)"
		printf 'STATUS: running pid=%s\n' "$_pid"
		printf 'Проверка идёт (фон). Обновление вывода — автоматически.\n'
	else
		rm -f "$DNS_CHECK_PID_FILE" 2>/dev/null || true
		printf 'STATUS: idle\n'
	fi
	printf 'Лог: %s\n\n' "$LOG"
	if [ -f "$LOG" ]; then
		cat "$LOG"
	else
		printf '<нет сохранённого отчёта — нажмите «Обновить»>\n'
	fi
}

dns_check_bg_start() {
	if dns_check_pid_running; then
		return 0
	fi
	rm -f "$DNS_CHECK_PID_FILE" 2>/dev/null || true
	(
		# Child: full sync run (writes LOG via tee). PID file cleared on exit.
		_rc=0
		sh "$SCRIPT_DIR/dns-check.sh" ${DNS_ROOT:+--dns-root "$DNS_ROOT"} || _rc=$?
		rm -f "$DNS_CHECK_PID_FILE" 2>/dev/null || true
		exit "$_rc"
	) >/dev/null 2>&1 &
	echo $! >"$DNS_CHECK_PID_FILE"
	# Tiny pause so first status can already see a truncated/new log header.
	sleep 0.2 2>/dev/null || sleep 1
}

dns_check_main() {
	printf '=== Диагностика DNS %s ===\n' "$STAMP"
	printf 'Лог: %s\n' "$LOG"
	printf '\n'

	if [ ! -d "$DNS_ROOT" ]; then
		printf 'Нет каталога секций DNS (эталоны Google всё равно будут проверены):\n  %s\n' "$DNS_ROOT"
		printf '\n'
	fi

	_prim="$(dns_check_primary_summary "$DNS_ROOT" || true)"
	if [ -n "$_prim" ]; then
		printf 'Основной DNS (catch-all): %s\n' "$_prim"
	else
		printf 'Основной DNS (catch-all): не задан (нет DNS_REDIRECT=1)\n'
	fi
	printf '\n'

	if [ "$PRINT_ONLY" -eq 1 ]; then
		printf 'Секции:\n'
		dns_check_list_resolvers "$DNS_ROOT" | while IFS='|' read -r _addr _port _lab _primf; do
			_mark=""
			[ "$_primf" = "1" ] && _mark=" [основной]"
			printf '  %s#%s  %s%s\n' "$_addr" "$_port" "$_lab" "$_mark"
		done
		printf '\nИмена:\n'
		dns_check_hosts | while read -r _h; do
			printf '  %s\n' "$_h"
		done
		printf '\n[*] Итог проверки: print-only (без drill)\n'
		return 0
	fi

	if ! command -v drill >/dev/null 2>&1; then
		printf 'Нет утилиты drill. Установите базовые пакеты (меню Система).\n'
		printf '\n[*] Итог проверки: FAIL no-drill\n'
		return 2
	fi

	_ok=0
	_fail=0
	_slow_ms=0
	_slow_where=""
	_res_f="${TMPDIR:-/tmp}/xfree-dns-check-resolvers.$$"
	_hosts_f="${TMPDIR:-/tmp}/xfree-dns-check-hosts.$$"
	if ! dns_check_list_resolvers "$DNS_ROOT" >"$_res_f"; then
		printf 'Нет resolvers для проверки.\n'
		printf '\n[*] Итог проверки: FAIL no-sections\n'
		rm -f "$_res_f" "$_hosts_f" 2>/dev/null || true
		return 2
	fi
	dns_check_hosts >"$_hosts_f"

	while IFS='|' read -r _addr _port _lab _primf; do
		[ -n "$_port" ] || continue
		dns_check_run_section_parallel "$_addr" "$_port" "$_lab" "$_primf" "$_hosts_f"
		_ok=$((_ok + DNS_CHECK_SEC_OK))
		_fail=$((_fail + DNS_CHECK_SEC_FAIL))
		if [ "${DNS_CHECK_SEC_SLOW_MS:-0}" -gt "$_slow_ms" ] 2>/dev/null; then
			_slow_ms="$DNS_CHECK_SEC_SLOW_MS"
			_slow_where="$DNS_CHECK_SEC_SLOW_WHERE"
		fi
	done <"$_res_f"

	rm -f "$_res_f" "$_hosts_f" 2>/dev/null || true

	_total=$((_ok + _fail))
	if [ "$_fail" -eq 0 ] && [ "$_total" -gt 0 ]; then
		printf '[*] Итог проверки: %s/%s OK' "$_ok" "$_total"
		if [ "$_slow_ms" -gt 0 ]; then
			printf '; самый медленный %s %sms' "$_slow_where" "$_slow_ms"
		fi
		printf '\n'
		return 0
	fi
	printf '[*] Итог проверки: FAIL %s/%s (ok=%s fail=%s)\n' "$_fail" "$_total" "$_ok" "$_fail"
	return 1
}

case "$MODE" in
last|status)
	dns_check_emit_banner
	exit 0
	;;
bg-start)
	dns_check_bg_start
	dns_check_emit_banner
	exit 0
	;;
esac

_rcf="${TMPDIR:-/tmp}/xfree-dns-check-rc.$$"
{
	set +e
	dns_check_main
	echo $? >"$_rcf"
	set -e
} | tee "$LOG"
_rc="$(tr -d ' \n\r' <"$_rcf" 2>/dev/null || echo 1)"
rm -f "$_rcf" 2>/dev/null || true
exit "$_rc"
