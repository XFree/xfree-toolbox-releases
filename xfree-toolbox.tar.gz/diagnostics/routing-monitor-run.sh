#!/bin/sh
# shellcheck shell=sh
# Периодическая или разовая проверка iface-routing: пишет state/monitor/*.status|.log
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="${COMMON_SH:-$ROOT_DIR/lib/common.sh}"
[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
# shellcheck disable=SC1090
. "$COMMON_SH"

common_load_project_config "$ROOT_DIR" 2>/dev/null || true

IR_ROOT="${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}"
MONITOR_DIR="${ROUTING_MONITOR_DIR:-$IR_ROOT/state/monitor}"
STATUS_FILE="$MONITOR_DIR/routing-check.status"
LOG_FILE="$MONITOR_DIR/routing-check.log"
CHECK_SCRIPT="${CHECK_ROUTING_SCRIPT:-$ROOT_DIR/iface-routing/check-routing.sh}"

mkdir -p "$MONITOR_DIR" 2>/dev/null || true

TS="$(date -u +'%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date +'%Y-%m-%dT%H:%M:%SZ')"

[ -f "$CHECK_SCRIPT" ] || {
    printf 'FAIL %s missing_check_script=%s\n' "$TS" "$CHECK_SCRIPT" >"$STATUS_FILE.tmp"
    mv -f "$STATUS_FILE.tmp" "$STATUS_FILE" 2>/dev/null || true
    printf '%s\n' "check-routing не найден: $CHECK_SCRIPT" >"$LOG_FILE"
    exit 0
}
[ -x "$CHECK_SCRIPT" ] || chmod +x "$CHECK_SCRIPT" 2>/dev/null || true

set +e
"$CHECK_SCRIPT" --all >"$LOG_FILE.tmp" 2>&1
rc="$?"
set -e

mv -f "$LOG_FILE.tmp" "$LOG_FILE" 2>/dev/null || cat "$LOG_FILE.tmp" >"$LOG_FILE"

case "$rc" in
    0) state="OK" ;;
    1) state="WARN" ;;
    *) state="FAIL" ;;
esac

printf '%s %s exit=%s\n' "$state" "$TS" "$rc" >"$STATUS_FILE.tmp"
mv -f "$STATUS_FILE.tmp" "$STATUS_FILE"

# Обёртка для cron всегда 0 — детали в .status/.log
exit 0
