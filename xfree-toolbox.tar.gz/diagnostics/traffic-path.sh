#!/bin/sh
# Config (+ light runtime) path for a site: DNS / VPN iface / Zapret.
# Usage:
#   traffic-path.sh summary
#   traffic-path.sh trace <fqdn|url>
# Env overrides for tests: XFREE_STATE_ROOT, TRAFFIC_PATH_* paths, TRAFFIC_PATH_ROOT.
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
export TRAFFIC_PATH_ROOT="$ROOT_DIR"

# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/traffic-path.sh"
traffic_path_init_paths

usage() {
	printf 'Usage: %s summary | trace <fqdn|url> | suggest [prefix] [limit]\n' "$(basename -- "$0")" >&2
}

cmd="${1:-}"
case "$cmd" in
summary)
	traffic_path_emit_summary
	printf '\n'
	;;
trace)
	shift || true
	fqdn="${1:-}"
	[ -n "$fqdn" ] || {
		usage
		printf '{"code":1,"stderr":"fqdn required"}\n'
		exit 1
	}
	traffic_path_emit_trace "$fqdn"
	printf '\n'
	;;
suggest)
	shift || true
	q="${1:-}"
	lim="${2:-40}"
	traffic_path_emit_suggest "$q" "$lim"
	printf '\n'
	;;
-h|--help|help|"")
	usage
	exit 1
	;;
*)
	usage
	printf '{"code":1,"stderr":"unknown action"}\n'
	exit 1
	;;
esac
