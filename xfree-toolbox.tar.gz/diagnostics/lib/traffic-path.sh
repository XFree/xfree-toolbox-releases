#!/bin/sh
# Traffic path: FQDN → DNS / iface VPN / zapret (+ light runtime checks).
# Sourced by diagnostics/traffic-path.sh and tests. No whiptail.
# shellcheck shell=sh

traffic_path_json_q() {
	printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

traffic_path_normalize_fqdn() {
	printf '%s\n' "$1" | awk '{
		line=$0
		sub(/\r$/, "", line)
		sub(/^[[:space:]]+/, "", line)
		sub(/[[:space:]]+$/, "", line)
		sub(/^https?:\/\//, "", line)
		sub(/\/.*/, "", line)
		sub(/:.*/, "", line)
		gsub(/^\*\./, "", line)
		gsub(/^\./, "", line)
		line=tolower(line)
		if (line != "") print line
	}'
}

traffic_path_init_paths() {
	ROOT_DIR="${TRAFFIC_PATH_ROOT:-${ROOT_DIR:-}}"
	if [ -z "${ROOT_DIR:-}" ]; then
		ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/../.." 2>/dev/null && pwd -P)" || ROOT_DIR=""
	fi

	STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
	IFACE_ROOT="${XFREE_IFACE_ROUTING_ROOT:-$STATE_ROOT/iface-routing}"
	DNS_ROOT="${XFREE_DNS_ROUTING_ROOT:-$STATE_ROOT/dns-routing}"
	ZAPRET_ROOT="${XFREE_ZAPRET_ROOT:-$STATE_ROOT/zapret}"

	TRAFFIC_PATH_IFACE_GEN="${TRAFFIC_PATH_IFACE_GEN:-$IFACE_ROOT/generated/interfaces}"
	TRAFFIC_PATH_IFACE_STATE="${TRAFFIC_PATH_IFACE_STATE:-$IFACE_ROOT/state/interfaces}"
	TRAFFIC_PATH_DNS_MAP="${TRAFFIC_PATH_DNS_MAP:-$DNS_ROOT/generated/dns-redirects.map}"
	TRAFFIC_PATH_ZAPRET_SECTIONS="${TRAFFIC_PATH_ZAPRET_SECTIONS:-$ZAPRET_ROOT/state/sections}"
	TRAFFIC_PATH_ZAPRET_GEN="${TRAFFIC_PATH_ZAPRET_GEN:-$ZAPRET_ROOT/generated}"
	TRAFFIC_PATH_ZAPRET_IPSET="${TRAFFIC_PATH_ZAPRET_IPSET:-/opt/zapret/ipset}"
	TRAFFIC_PATH_MONITOR_STATUS="${TRAFFIC_PATH_MONITOR_STATUS:-$STATE_ROOT/monitor/routing-check.status}"
	TRAFFIC_PATH_USB_WATCH_STATE="${TRAFFIC_PATH_USB_WATCH_STATE:-$STATE_ROOT/system/usb-power-watch.state}"
	TRAFFIC_PATH_DNS_CHECK_LOG="${TRAFFIC_PATH_DNS_CHECK_LOG:-$STATE_ROOT/system/dns-check.log}"

	if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/lib/iface-vpn-dns-cover.sh" ]; then
		# shellcheck disable=SC1090
		. "$ROOT_DIR/lib/iface-vpn-dns-cover.sh"
	fi
	if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/diagnostics/lib/dns-check.sh" ]; then
		# shellcheck disable=SC1090
		. "$ROOT_DIR/diagnostics/lib/dns-check.sh"
	fi
}

# KEY='val' / KEY=val from usb-power-watch.state (no full watch lib).
traffic_path_kv_get() {
	file="$1"
	key="$2"
	default="${3:-}"
	[ -f "$file" ] || {
		printf '%s' "$default"
		return 0
	}
	awk -F= -v k="$key" -v d="$default" '
		BEGIN { found=0 }
		{
			line=$0
			sub(/\r$/, "", line)
			sub(/^[[:space:]]+/, "", line)
			if (line ~ /^#/ || line == "") next
			split(line, a, "=")
			name=a[1]
			sub(/[[:space:]]+$/, "", name)
			if (name != k) next
			val=substr(line, index(line, "=") + 1)
			gsub(/^[[:space:]]+|[[:space:]]+$/, "", val)
			gsub(/^'\''|'\''$/, "", val)
			print val
			found=1
			exit
		}
		END { if (!found) print d }
	' "$file"
}

traffic_path_sanitize_iface() {
	printf '%s' "${1:-}" | tr -c 'A-Za-z0-9_' '_'
}

# Unix epoch → router local wall time (busybox date -d/@ or -r).
traffic_path_unix_to_local() {
	epoch="$1"
	out=""
	case "$epoch" in
	''|*[!0-9]*) return 1 ;;
	esac
	[ "$epoch" -gt 0 ] 2>/dev/null || return 1
	out="$(date -d "@$epoch" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
	[ -n "$out" ] || out="$(date -r "$epoch" '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || true)"
	[ -n "$out" ] || return 1
	printf '%s' "$out"
}

# Compact hs label for tip/status (ok|stale|none|down|?).
traffic_path_hs_label() {
	case "${1:-}" in
	ok) printf 'ok' ;;
	stale) printf 'stale' ;;
	none) printf 'none' ;;
	down) printf 'down' ;;
	unknown) printf '?' ;;
	'') printf '—' ;;
	*) printf '%s' "$1" ;;
	esac
}

traffic_path_action_label() {
	case "${1:-}" in
	''|none) printf 'none' ;;
	*) printf '%s' "$1" ;;
	esac
}

# Proton guest/web marker from source.conf.meta; cert in router TZ when possible.
traffic_path_iface_proton_fields() {
	iface="$1"
	meta="${TRAFFIC_PATH_IFACE_STATE:-}/$iface/config/source.conf.meta"
	auth=""
	sess=""
	cert=""
	unix=""
	kind=""

	[ -f "$meta" ] || {
		printf '%s\n' "" "" ""
		return 0
	}
	kind="$(traffic_path_kv_get "$meta" "GENERATOR_KIND" "")"
	[ "$kind" = "proton" ] || {
		printf '%s\n' "" "" ""
		return 0
	}
	auth="$(traffic_path_kv_get "$meta" "SESSION_AUTH_MODE" "")"
	[ -n "$auth" ] || auth="?"
	sess="$(traffic_path_kv_get "$meta" "SESSION_NAME" "")"
	[ -n "$sess" ] || sess="?"
	unix="$(traffic_path_kv_get "$meta" "CERT_EXPIRATION_UNIX" "")"
	if cert="$(traffic_path_unix_to_local "$unix" 2>/dev/null)"; then
		:
	else
		cert="$(traffic_path_kv_get "$meta" "CERT_EXPIRATION_UTC" "")"
		[ -n "$cert" ] || cert="?"
	fi
	printf '%s\n%s\n%s\n' "$auth" "$sess" "$cert"
}

# Monitor health for a VPN iface: ok | warn | fail | unknown
traffic_path_tunnel_health() {
	iface="$1"
	tok="$(traffic_path_sanitize_iface "$iface")"
	f="${TRAFFIC_PATH_USB_WATCH_STATE:-}"
	last="$(traffic_path_kv_get "$f" "TUNNEL_LAST_$tok" "")"
	ping="$(traffic_path_kv_get "$f" "TUNNEL_PING_$tok" "")"
	case "$last" in
	ok)
		case "$ping" in
		fail) printf 'warn' ;;
		*) printf 'ok' ;;
		esac
		;;
	fail|exhausted)
		printf 'fail'
		;;
	*)
		case "$ping" in
		ok) printf 'ok' ;;
		fail) printf 'fail' ;;
		*) printf 'unknown' ;;
		esac
		;;
	esac
}

# WAN / uplink probe: LAST_PROBE_EVAL 0=full 1=fail 2=partial
traffic_path_wan_health() {
	f="${TRAFFIC_PATH_USB_WATCH_STATE:-}"
	ev="$(traffic_path_kv_get "$f" "LAST_PROBE_EVAL" "")"
	case "$ev" in
	0) printf 'ok' ;;
	1) printf 'fail' ;;
	2) printf 'warn' ;;
	*) printf 'unknown' ;;
	esac
}

traffic_path_wan_channel_label() {
	case "${1:-}" in
	0) printf 'FULL' ;;
	1) printf 'FAIL' ;;
	2) printf 'PARTIAL' ;;
	*) printf '' ;;
	esac
}

traffic_path_wan_runtime_json() {
	f="${TRAFFIC_PATH_USB_WATCH_STATE:-}"
	health="$(traffic_path_wan_health)"
	ev="$(traffic_path_kv_get "$f" "LAST_PROBE_EVAL" "")"
	tick="$(traffic_path_kv_get "$f" "LAST_TICK" "")"
	base="$(traffic_path_kv_get "$f" "LAST_PROBE_BASE" "")"
	alt="$(traffic_path_kv_get "$f" "LAST_PROBE_ALT" "")"
	alt_en="$(traffic_path_kv_get "$f" "LAST_PROBE_ALT_ENABLED" "")"
	channel="$(traffic_path_wan_channel_label "$ev")"
	ok=true
	case "$health" in
	fail) ok=false ;;
	esac
	printf '{"ok":%s,"health":"%s","probeEval":"%s","channel":"%s","lastTick":"%s","probeBase":"%s","probeAlt":"%s","probeAltEnabled":"%s"}' \
		"$ok" "$(traffic_path_json_q "$health")" "$(traffic_path_json_q "$ev")" \
		"$(traffic_path_json_q "$channel")" \
		"$(traffic_path_json_q "$tick")" "$(traffic_path_json_q "$base")" \
		"$(traffic_path_json_q "$alt")" "$(traffic_path_json_q "$alt_en")"
}

# Longest-suffix / first file-order match among iface generated FQDN lists.
# Prints: iface_id|match_kind|matched_base
traffic_path_match_iface() {
	fqdn="$1"
	gen_root="${TRAFFIC_PATH_IFACE_GEN:-}"
	[ -n "$fqdn" ] || return 1
	[ -d "$gen_root" ] || return 1

	best_iface=""
	best_kind=""
	best_base=""
	best_len=-1

	for lst in "$gen_root"/*/fqdn.generated.lst; do
		[ -f "$lst" ] || continue
		iface="$(basename "$(dirname "$lst")")"
		while IFS= read -r base || [ -n "$base" ]; do
			base="$(printf '%s' "$base" | tr 'A-Z' 'a-z' | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
			[ -n "$base" ] || continue
			kind=""
			if [ "$fqdn" = "$base" ]; then
				kind="exact"
			else
				case "$fqdn" in
					*."$base") kind="subdomain" ;;
					*) continue ;;
				esac
			fi
			blen="${#base}"
			if [ "$blen" -gt "$best_len" ]; then
				best_len="$blen"
				best_iface="$iface"
				best_kind="$kind"
				best_base="$base"
			fi
		done < "$lst"
	done

	[ -n "$best_iface" ] || return 1
	printf '%s|%s|%s\n' "$best_iface" "$best_kind" "$best_base"
}

# DNS map: domain|target|dns_id|list — exact then parent walk (dnsmasq server=/a.b/).
# Prints: domain|target|dns_id|list|match_kind
traffic_path_match_dns() {
	fqdn="$1"
	map="${TRAFFIC_PATH_DNS_MAP:-}"
	[ -n "$fqdn" ] || return 1
	[ -f "$map" ] || return 1

	cand="$fqdn"
	while [ -n "$cand" ]; do
		row="$(awk -F'|' -v d="$cand" '$1==d { print; exit }' "$map")"
		if [ -n "$row" ]; then
			kind="exact"
			[ "$cand" = "$fqdn" ] || kind="subdomain"
			printf '%s|%s\n' "$row" "$kind"
			return 0
		fi
		case "$cand" in
			*.*) cand="${cand#*.}" ;;
			*) break ;;
		esac
	done
	return 1
}

# Longest matching base from a list file for fqdn (exact/suffix). Empty if none.
traffic_path_list_match_base() {
	fqdn="$1"
	lst="$2"
	awk -v d="$fqdn" '
		{
			line=tolower($0); sub(/\r$/,"",line); sub(/#.*/, "", line)
			gsub(/^[ \t]+|[ \t]+$/, "", line); gsub(/^\*\./, "", line)
			if (line=="") next
			if (d==line) { if (length(line)>bestlen) { best=line; bestlen=length(line) }; next }
			n=length(line)
			if (length(d)>n+1 && substr(d, length(d)-n, 1)=="." && substr(d, length(d)-n+1)==line) {
				if (n>bestlen) { best=line; bestlen=n }
			}
		}
		END { if (best!="") print best }
	' "$lst"
}

# Strategy summary from section.text (--dpi-desync=… joined by +).
traffic_path_zapret_strategy() {
	text="$1/config/section.text"
	[ -f "$text" ] || return 0
	awk -F= '/--dpi-desync=/ {
		v=$2; gsub(/[ \t\r].*/, "", v)
		if (v!="" && !seen[v]++) {
			if (n++) printf "+"
			printf "%s", v
		}
	}' "$text"
}

# Active NFQWS_OPT text (UCI on router; file/env for tests).
traffic_path_zapret_nfqws_opt_text() {
	if [ -n "${TRAFFIC_PATH_ZAPRET_NFQWS_OPT_FILE:-}" ] && [ -f "$TRAFFIC_PATH_ZAPRET_NFQWS_OPT_FILE" ]; then
		cat "$TRAFFIC_PATH_ZAPRET_NFQWS_OPT_FILE"
		return 0
	fi
	if [ -n "${TRAFFIC_PATH_ZAPRET_NFQWS_OPT:-}" ]; then
		printf '%s\n' "$TRAFFIC_PATH_ZAPRET_NFQWS_OPT"
		return 0
	fi
	if command -v uci >/dev/null 2>&1; then
		uci get zapret.config.NFQWS_OPT 2>/dev/null || true
		return 0
	fi
	return 0
}

# nft mark/queue plumbing for nfqws (table inet zapret). Override: TRAFFIC_PATH_ZAPRET_MARK_OK=0|1
traffic_path_zapret_mark_queue_present() {
	case "${TRAFFIC_PATH_ZAPRET_MARK_OK:-}" in
	1|true|yes|YES) return 0 ;;
	0|false|no|NO) return 1 ;;
	esac
	command -v nft >/dev/null 2>&1 || return 1
	nft list table inet zapret 2>/dev/null | grep -qE 'queue|0x20000000|0x40000000'
}

# Map HOST_FILE basename → enabled state section id (requires section.conf).
# Shared HOST_FILE (e.g. zapret-hosts-google.txt across youtube_*) → first ENABLED=1.
traffic_path_zapret_section_by_hostfile() {
	hf="$1"
	sec_root="${TRAFFIC_PATH_ZAPRET_SECTIONS:-}"
	[ -n "$hf" ] && [ -d "$sec_root" ] || return 1
	for conf in "$sec_root"/*/config/section.conf; do
		[ -f "$conf" ] || continue
		got="$(awk -F"'" '/^ZAPRET_SECTION_HOST_FILE=/ { print $2; exit }' "$conf")"
		[ "$got" = "$hf" ] || continue
		en="$(awk -F"'" '/^ZAPRET_SECTION_ENABLED=/ { print $2; exit }' "$conf")"
		case "${en:-1}" in
			0|off|OFF|false|no) continue ;;
		esac
		basename "$(dirname "$(dirname "$conf")")"
		return 0
	done
	return 1
}

# Zapret match — штатные стадии (не Fallback):
#   1) applied state: sections with section.conf + fqdn.d
#   2) system: hostlists/domains actually wired in NFQWS_OPT (what nfqws loads)
# Orphan files under /opt/zapret/ipset that are NOT in NFQWS_OPT do not match.
# Prints: section_id|matched_base|strategy
traffic_path_match_zapret() {
	fqdn="$1"
	sec_root="${TRAFFIC_PATH_ZAPRET_SECTIONS:-}"
	[ -n "$fqdn" ] || return 1

	seen="|"
	opt_text=""
	opt_text="$(traffic_path_zapret_nfqws_opt_text 2>/dev/null || true)"

	# --- 1) applied state lists (section.conf required) ---
	if [ -d "$sec_root" ]; then
		for dir in "$sec_root"/*; do
			[ -d "$dir" ] || continue
			id="$(basename "$dir")"
			conf="$dir/config/section.conf"
			[ -f "$conf" ] || continue
			en="$(awk -F"'" '/^ZAPRET_SECTION_ENABLED=/ { print $2; exit }' "$conf")"
			case "${en:-1}" in
				0|off|OFF|false|no) continue ;;
			esac
			best_base=""
			if [ -d "$dir/fqdn.d" ]; then
				for lst in "$dir/fqdn.d"/*.lst; do
					[ -f "$lst" ] || continue
					base="$(traffic_path_list_match_base "$fqdn" "$lst")"
					[ -n "$base" ] || continue
					if [ -z "$best_base" ] || [ "${#base}" -gt "${#best_base}" ]; then
						best_base="$base"
					fi
				done
			fi
			[ -n "$best_base" ] || continue
			case "$seen" in *"|$id|"*) continue ;; esac
			seen="${seen}${id}|"
			strat="$(traffic_path_zapret_strategy "$dir")"
			printf '%s|%s|%s\n' "$id" "$best_base" "$strat"
		done
	fi

	# --- 2) system: NFQWS_OPT --hostlist=PATH ---
	hl_tmp=""
	hl_tmp="$(mktemp 2>/dev/null || mktemp -t xfree-zapret-hl)"
	printf '%s\n' "$opt_text" | grep -oE -- '--hostlist=[^[:space:]]+' | sed 's/^--hostlist=//' >"$hl_tmp" || true
	while IFS= read -r hostf || [ -n "$hostf" ]; do
		[ -n "$hostf" ] && [ -f "$hostf" ] && [ -s "$hostf" ] || continue
		base="$(traffic_path_list_match_base "$fqdn" "$hostf")"
		[ -n "$base" ] || continue
		hf_base="$(basename -- "$hostf")"
		id="$(traffic_path_zapret_section_by_hostfile "$hf_base" 2>/dev/null || true)"
		[ -n "$id" ] || id="${hf_base%.txt}"
		case "$seen" in *"|$id|"*) continue ;; esac
		seen="${seen}${id}|"
		strat=""
		if [ -d "${sec_root:-}/$id" ]; then
			strat="$(traffic_path_zapret_strategy "$sec_root/$id")"
		fi
		printf '%s|%s|%s\n' "$id" "$base" "$strat"
	done <"$hl_tmp"
	rm -f "$hl_tmp"

	# --- 3) system: NFQWS_OPT --hostlist-domains=a,b ---
	dom_tmp=""
	dom_tmp="$(mktemp 2>/dev/null || mktemp -t xfree-zapret-dom)"
	printf '%s\n' "$opt_text" | grep -oE -- '--hostlist-domains=[^[:space:]]+' | sed 's/^--hostlist-domains=//' | tr ',' '\n' >"$dom_tmp" || true
	best_dom=""
	while IFS= read -r dom || [ -n "$dom" ]; do
		dom="$(printf '%s' "$dom" | tr 'A-Z' 'a-z' | tr -d '\r')"
		[ -n "$dom" ] || continue
		case "$fqdn" in
		"$dom" | *."$dom")
			if [ -z "$best_dom" ] || [ "${#dom}" -gt "${#best_dom}" ]; then
				best_dom="$dom"
			fi
			;;
		esac
	done <"$dom_tmp"
	rm -f "$dom_tmp"
	if [ -n "$best_dom" ]; then
		id="hostlist-domains"
		case "$seen" in *"|$id|"*) ;;
		*)
			printf '%s|%s|%s\n' "$id" "$best_dom" ""
			;;
		esac
	fi
}

traffic_path_iface_conf_get() {
	iface="$1"
	key="$2"
	conf="${TRAFFIC_PATH_IFACE_STATE:-}/$iface/config/iface.conf"
	[ -f "$conf" ] || conf="${TRAFFIC_PATH_IFACE_GEN:-}/$iface/iface.conf"
	[ -f "$conf" ] || return 1
	awk -F"'" -v k="$key" '$0 ~ "^"k"=" { print $2; exit }' "$conf"
}

traffic_path_runtime_iface() {
	iface="$1"
	vpn_dev="$(traffic_path_iface_conf_get "$iface" "VPN_DEV" 2>/dev/null || true)"
	[ -n "$vpn_dev" ] || vpn_dev="$iface"
	mark="$(traffic_path_iface_conf_get "$iface" "MARK_HEX" 2>/dev/null || true)"
	table="$(traffic_path_iface_conf_get "$iface" "ROUTE_TABLE_NAME" 2>/dev/null || true)"
	[ -n "$table" ] || table="$iface"
	set4="$(traffic_path_iface_conf_get "$iface" "NFT_FQDN4_SET_NAME" 2>/dev/null || true)"

	iface_up=false
	rule_present=false
	set_present=false
	ok=true
	detail=""

	if command -v ip >/dev/null 2>&1; then
		if ip link show "$vpn_dev" >/dev/null 2>&1; then
			if ip -o link show "$vpn_dev" 2>/dev/null | grep -q 'state UP\|UP,'; then
				iface_up=true
			elif ip link show "$vpn_dev" 2>/dev/null | grep -q 'UP'; then
				iface_up=true
			fi
		fi
		if [ -n "$mark" ] && ip rule show 2>/dev/null | grep -F "fwmark $mark" | grep -q "$table"; then
			rule_present=true
		elif [ -z "$mark" ]; then
			rule_present=true
			detail="no MARK_HEX in iface.conf"
		fi
	else
		detail="ip unavailable"
		ok=false
	fi

	if [ -n "$set4" ] && command -v nft >/dev/null 2>&1; then
		if nft list set inet fw4 "$set4" >/dev/null 2>&1 || nft list set inet filter "$set4" >/dev/null 2>&1; then
			set_present=true
		fi
	elif [ -z "$set4" ]; then
		set_present=true
	fi

	if [ "$iface_up" != true ]; then
		ok=false
		[ -n "$detail" ] || detail="iface down"
	fi
	if [ "$rule_present" != true ] && [ -n "$mark" ]; then
		ok=false
		detail="${detail:+$detail; }fwmark rule missing"
	fi

	tok="$(traffic_path_sanitize_iface "$iface")"
	f="${TRAFFIC_PATH_USB_WATCH_STATE:-}"
	mon_last="$(traffic_path_kv_get "$f" "TUNNEL_LAST_$tok" "")"
	mon_ping="$(traffic_path_kv_get "$f" "TUNNEL_PING_$tok" "")"
	mon_hs="$(traffic_path_kv_get "$f" "TUNNEL_HS_$tok" "")"
	mon_act="$(traffic_path_kv_get "$f" "TUNNEL_LAST_ACTION_$tok" "")"
	mon_hs_lbl="$(traffic_path_hs_label "$mon_hs")"
	mon_act_lbl="$(traffic_path_action_label "$mon_act")"
	case "$mon_ping" in
	ok) mon_ping_lbl='ok' ;;
	fail) mon_ping_lbl='FAIL' ;;
	*) mon_ping_lbl='—' ;;
	esac
	_pf="$(traffic_path_iface_proton_fields "$iface")"
	proton_auth="$(printf '%s\n' "$_pf" | sed -n '1p')"
	proton_sess="$(printf '%s\n' "$_pf" | sed -n '2p')"
	cert_local="$(printf '%s\n' "$_pf" | sed -n '3p')"
	# Compact probe line; proton/sess/cert are separate JSON fields for the tip.
	mon_line="ping=${mon_ping_lbl} hs=${mon_hs_lbl} last=${mon_act_lbl}"
	health="$(traffic_path_tunnel_health "$iface")"
	# Link down always fails the chip; monitor can still be unknown.
	if [ "$iface_up" != true ]; then
		health=fail
	elif [ "$health" = unknown ] && [ "$ok" != true ]; then
		health=warn
	fi

	printf '{"ok":%s,"ifaceUp":%s,"rulePresent":%s,"nftSetPresent":%s,"vpnDev":"%s","detail":"%s","health":"%s","monitorLast":"%s","monitorPing":"%s","monitorHs":"%s","monitorAction":"%s","monitorLine":"%s","protonAuth":"%s","protonSess":"%s","certLocal":"%s"}' \
		"$ok" "$iface_up" "$rule_present" "$set_present" \
		"$(traffic_path_json_q "$vpn_dev")" "$(traffic_path_json_q "$detail")" \
		"$(traffic_path_json_q "$health")" "$(traffic_path_json_q "$mon_last")" \
		"$(traffic_path_json_q "$mon_ping")" \
		"$(traffic_path_json_q "$mon_hs")" "$(traffic_path_json_q "$mon_act")" \
		"$(traffic_path_json_q "$mon_line")" \
		"$(traffic_path_json_q "$proton_auth")" "$(traffic_path_json_q "$proton_sess")" \
		"$(traffic_path_json_q "$cert_local")"
}

# First map target (addr#port) for dns_id — matches dns-check section header.
traffic_path_dns_map_target() {
	dns_id="$1"
	map="${TRAFFIC_PATH_DNS_MAP:-}"
	[ -n "$dns_id" ] && [ -f "$map" ] || return 1
	awk -F'|' -v id="$dns_id" 'NF >= 3 && $3 == id && $2 != "" { print $2; exit }' "$map"
}

# DNS_HOST from profile dns.conf (log headers use HOST, map uses ID).
traffic_path_dns_host_label() {
	dns_id="$1"
	ap=""
	conf=""
	[ -n "$dns_id" ] || return 1
	ap="$(cat "${STATE_ROOT:-/etc/xfree-toolbox}/active-profile" 2>/dev/null || true)"
	[ -n "$ap" ] || ap="default"
	if [ -n "${ROOT_DIR:-}" ]; then
		conf="$ROOT_DIR/profiles/$ap/dns-routing/dns/$dns_id/config/dns.conf"
	fi
	[ -f "$conf" ] || return 1
	awk -F"'" '/^DNS_HOST=/ { print $2; exit }' "$conf"
}

traffic_path_runtime_dns() {
	dns_id="$1"
	ok=true
	detail=""
	target=""
	host_lab=""
	chk=""
	chk_ok=""
	chk_fail=""
	chk_min=""
	chk_max=""
	chk_when=""
	chk_lab=""
	chk_tgt=""
	chk_sum=""
	# Lightweight UCI presence (not a resolve test).
	if command -v uci >/dev/null 2>&1; then
		if ! uci -q show https-dns-proxy 2>/dev/null | grep -q .; then
			ok=false
			detail="https-dns-proxy uci empty"
		fi
	fi

	target="$(traffic_path_dns_map_target "$dns_id" 2>/dev/null || true)"
	host_lab="$(traffic_path_dns_host_label "$dns_id" 2>/dev/null || true)"

	if [ -f "${TRAFFIC_PATH_DNS_CHECK_LOG:-}" ]; then
		chk="$(dns_check_lookup_section_summary \
			"$TRAFFIC_PATH_DNS_CHECK_LOG" "$dns_id" "$target" "$host_lab" 2>/dev/null || true)"
	fi
	if [ -n "$chk" ]; then
		IFS='|' read -r chk_ok chk_fail chk_min chk_max chk_when chk_lab chk_tgt chk_sum <<EOF
$chk
EOF
		case "$chk_fail" in
			''|0) ;;
			*)
				ok=false
				[ -n "$detail" ] || detail="dns-check fail"
				;;
		esac
		# Per-probe hosts for tip: [{"h":"ya.ru","ok":true,"ms":1,"rcode":"NOERROR"},…]
		hosts_json="["
		hosts_sep=""
		if [ -n "$chk_tgt" ]; then
			while IFS='|' read -r _hh _hst _hrc _hms; do
				[ -n "$_hh" ] || continue
				_hok=false
				[ "$_hst" = "OK" ] && _hok=true
				hosts_json="${hosts_json}${hosts_sep}{\"h\":\"$(traffic_path_json_q "$_hh")\",\"ok\":${_hok},\"ms\":${_hms:-0},\"rcode\":\"$(traffic_path_json_q "${_hrc:-}")\"}"
				hosts_sep=","
			done <<EOF
$(dns_check_section_hosts_by_target "$TRAFFIC_PATH_DNS_CHECK_LOG" "$chk_tgt" 2>/dev/null || true)
EOF
		fi
		hosts_json="${hosts_json}]"
		printf '{"ok":%s,"dnsId":"%s","detail":"%s","checkOk":%s,"checkFail":%s,"checkMinMs":%s,"checkMaxMs":%s,"checkWhen":"%s","checkLabel":"%s","checkTarget":"%s","checkSummary":"%s","checkHosts":%s}' \
			"$ok" "$(traffic_path_json_q "$dns_id")" "$(traffic_path_json_q "$detail")" \
			"${chk_ok:-0}" "${chk_fail:-0}" "${chk_min:-0}" "${chk_max:-0}" \
			"$(traffic_path_json_q "$chk_when")" "$(traffic_path_json_q "$chk_lab")" \
			"$(traffic_path_json_q "$chk_tgt")" "$(traffic_path_json_q "$chk_sum")" \
			"$hosts_json"
		return 0
	fi

	printf '{"ok":%s,"dnsId":"%s","detail":"%s"}' \
		"$ok" "$(traffic_path_json_q "$dns_id")" "$(traffic_path_json_q "$detail")"
}

traffic_path_runtime_zapret() {
	section="$1"
	dir="${TRAFFIC_PATH_ZAPRET_SECTIONS:-}/$section"
	ok=true
	mark_ok=false
	in_opt=false
	state_lists=false
	detail=""
	hf=""
	opt_text=""
	p=""
	b=""

	if traffic_path_zapret_mark_queue_present; then
		mark_ok=true
	fi

	if [ -d "$dir/fqdn.d" ]; then
		for lst in "$dir/fqdn.d"/*.lst; do
			[ -f "$lst" ] && [ -s "$lst" ] || continue
			state_lists=true
			break
		done
	fi

	if [ -f "$dir/config/section.conf" ]; then
		hf="$(awk -F"'" '/^ZAPRET_SECTION_HOST_FILE=/ { print $2; exit }' "$dir/config/section.conf")"
	fi
	# Same default as zapret_load_section_conf when HOST_FILE omitted.
	[ -n "$hf" ] || hf="xfree-${section}-hosts.txt"
	opt_text="$(traffic_path_zapret_nfqws_opt_text 2>/dev/null || true)"
	if [ -n "$hf" ] && printf '%s\n' "$opt_text" | grep -F -- "--hostlist=" | grep -Fq -- "$hf"; then
		in_opt=true
	fi
	if [ "$section" = "hostlist-domains" ] && printf '%s\n' "$opt_text" | grep -q -- '--hostlist-domains='; then
		in_opt=true
	fi
	if [ "$in_opt" != true ] && [ -n "$opt_text" ]; then
		hl_rt="$(mktemp 2>/dev/null || mktemp -t xfree-zapret-rt)"
		printf '%s\n' "$opt_text" | grep -oE -- '--hostlist=[^[:space:]]+' | sed 's/^--hostlist=//' >"$hl_rt" || true
		while IFS= read -r p || [ -n "$p" ]; do
			[ -n "$p" ] || continue
			b="$(basename -- "$p")"
			if [ "$b" = "$section" ] || [ "${b%.txt}" = "$section" ] || [ "$b" = "${section}.txt" ] \
				|| [ "$b" = "$hf" ] || [ "$b" = "xfree-${section}-hosts.txt" ]; then
				in_opt=true
				break
			fi
		done <"$hl_rt"
		rm -f "$hl_rt"
	fi

	if [ "$mark_ok" != true ]; then
		ok=false
		detail="nft mark/queue missing"
	fi
	if [ "$in_opt" != true ] && [ "$state_lists" != true ]; then
		ok=false
		detail="${detail:+$detail; }not in NFQWS_OPT/state"
	elif [ "$in_opt" != true ] && [ "$state_lists" = true ]; then
		ok=false
		detail="${detail:+$detail; }state lists not wired in NFQWS_OPT"
	fi

	printf '{"ok":%s,"markQueue":%s,"hostlistInOpt":%s,"stateLists":%s,"detail":"%s"}' \
		"$ok" "$mark_ok" "$in_opt" "$state_lists" "$(traffic_path_json_q "$detail")"
}

traffic_path_list_nodes_json() {
	# nodes array content (no brackets)
	first=1
	gen_root="${TRAFFIC_PATH_IFACE_GEN:-}"
	if [ -d "$gen_root" ]; then
		for d in "$gen_root"/*; do
			[ -d "$d" ] || continue
			id="$(basename "$d")"
			[ "$first" -eq 1 ] || printf ','
			first=0
			rt="$(traffic_path_runtime_iface "$id")"
			printf '{"id":"iface:%s","kind":"iface","label":"%s","runtime":%s}' \
				"$(traffic_path_json_q "$id")" "$(traffic_path_json_q "$id")" "$rt"
		done
	fi

	map="${TRAFFIC_PATH_DNS_MAP:-}"
	if [ -f "$map" ]; then
		dns_tmp="$(mktemp)"
		awk -F'|' 'NF>=3 && $3!="" { print $3 }' "$map" | sort -u > "$dns_tmp"
		while IFS= read -r dns_id; do
			[ -n "$dns_id" ] || continue
			[ "$first" -eq 1 ] || printf ','
			first=0
			rt="$(traffic_path_runtime_dns "$dns_id")"
			printf '{"id":"dns:%s","kind":"dns","label":"%s","runtime":%s}' \
				"$(traffic_path_json_q "$dns_id")" "$(traffic_path_json_q "$dns_id")" "$rt"
		done < "$dns_tmp"
		rm -f "$dns_tmp"
	fi

	sec_root="${TRAFFIC_PATH_ZAPRET_SECTIONS:-}"
	if [ -d "$sec_root" ]; then
		for d in "$sec_root"/*; do
			[ -d "$d" ] || continue
			id="$(basename "$d")"
			conf="$d/config/section.conf"
			# Empty state shells without section.conf are not applied sections.
			[ -f "$conf" ] || continue
			en="$(awk -F"'" '/^ZAPRET_SECTION_ENABLED=/ { print $2; exit }' "$conf")"
			en="${en:-1}"
			case "$en" in
				0|off|OFF|false|no) continue ;;
			esac
			[ "$first" -eq 1 ] || printf ','
			first=0
			rt="$(traffic_path_runtime_zapret "$id")"
			printf '{"id":"zapret:%s","kind":"zapret","label":"%s","runtime":%s}' \
				"$(traffic_path_json_q "$id")" "$(traffic_path_json_q "$id")" "$rt"
		done
	fi
}

traffic_path_emit_summary() {
	monitor=""
	if [ -f "${TRAFFIC_PATH_MONITOR_STATUS:-}" ]; then
		monitor="$(tr '\n' ' ' < "$TRAFFIC_PATH_MONITOR_STATUS" | sed 's/[[:space:]]*$//')"
	fi
	printf '{"code":0,"action":"summary","nodes":['
	traffic_path_list_nodes_json
	printf '],"wan":%s,"monitorStatus":"%s"}' \
		"$(traffic_path_wan_runtime_json)" \
		"$(traffic_path_json_q "$monitor")"
}

# Stream active FQDNs (one per line, lowercased): iface generated + DNS map + enabled zapret.
traffic_path_suggest_stream() {
	gen_root="${TRAFFIC_PATH_IFACE_GEN:-}"
	map="${TRAFFIC_PATH_DNS_MAP:-}"
	zroot="${TRAFFIC_PATH_ZAPRET_SECTIONS:-}"
	f=""
	d=""
	conf=""
	en=""
	hf=""

	if [ -n "$gen_root" ] && [ -d "$gen_root" ]; then
		for f in "$gen_root"/*/fqdn.generated.lst; do
			[ -f "$f" ] || continue
			awk '
				{
					line=$0
					sub(/\r$/, "", line)
					sub(/#.*/, "", line)
					gsub(/^[[:space:]]+|[[:space:]]+$/, "", line)
					if (line == "") next
					print tolower(line)
				}
			' "$f"
		done
	fi

	if [ -n "$map" ] && [ -f "$map" ]; then
		awk -F'|' '
			{
				line=$1
				sub(/\r$/, "", line)
				gsub(/^[[:space:]]+|[[:space:]]+$/, "", line)
				if (line == "" || line ~ /^#/) next
				print tolower(line)
			}
		' "$map"
	fi

	if [ -n "$zroot" ] && [ -d "$zroot" ]; then
		for d in "$zroot"/*; do
			[ -d "$d" ] || continue
			conf="$d/config/section.conf"
			[ -f "$conf" ] || continue
			en="$(awk -F"'" '/^ZAPRET_SECTION_ENABLED=/ { print $2; exit }' "$conf")"
			[ -n "$en" ] || en=1
			case "$en" in
			0|false|off|no) continue ;;
			esac
			hf="$(awk -F"'" '/^ZAPRET_SECTION_HOST_FILE=/ { print $2; exit }' "$conf")"
			if [ -n "$hf" ] && [ -f "${TRAFFIC_PATH_ZAPRET_GEN:-}/sections/$(basename "$d")/$hf" ]; then
				awk '
					{
						line=$0
						sub(/\r$/, "", line)
						sub(/#.*/, "", line)
						gsub(/^[[:space:]]+|[[:space:]]+$/, "", line)
						if (line == "") next
						print tolower(line)
					}
				' "${TRAFFIC_PATH_ZAPRET_GEN:-}/sections/$(basename "$d")/$hf"
			elif [ -d "$d/fqdn.d" ]; then
				for f in "$d"/fqdn.d/*.lst; do
					[ -f "$f" ] || continue
					awk '
						{
							line=$0
							sub(/\r$/, "", line)
							sub(/#.*/, "", line)
							gsub(/^[[:space:]]+|[[:space:]]+$/, "", line)
							if (line == "") next
							print tolower(line)
						}
					' "$f"
				done
			fi
		done
	fi
}

# Prefix suggest over active FQDNs. q may be empty; limit default 40 (max 8000).
traffic_path_emit_suggest() {
	q="$(printf '%s' "${1:-}" | tr 'A-Z' 'a-z' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
	limit="${2:-40}"
	case "$limit" in
	''|*[!0-9]*) limit=40 ;;
	esac
	[ "$limit" -gt 0 ] 2>/dev/null || limit=40
	[ "$limit" -le 8000 ] || limit=8000

	# Ensure zapret generated root (applied merge); state fqdn.d is the prior stage.
	if [ -z "${TRAFFIC_PATH_ZAPRET_GEN:-}" ]; then
		STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
		TRAFFIC_PATH_ZAPRET_GEN="${STATE_ROOT}/zapret/generated"
	fi

	# One pass: sort -u → filter prefix → emit JSON array + totals.
	traffic_path_suggest_stream | sort -u | awk -v q="$q" -v lim="$limit" '
		BEGIN {
			n = 0
			total = 0
			first = 1
			qq = q
			gsub(/\\/, "\\\\", qq)
			gsub(/"/, "\\\"", qq)
			printf "{\"code\":0,\"action\":\"suggest\",\"q\":\"%s\",\"limit\":%d,\"items\":[", qq, lim + 0
		}
		{
			if (q != "" && index($0, q) != 1) next
			total++
			if (n >= lim) next
			dom = $0
			gsub(/\\/, "\\\\", dom)
			gsub(/"/, "\\\"", dom)
			if (!first) printf ","
			printf "\"%s\"", dom
			first = 0
			n++
		}
		END {
			trunc = (total > lim) ? "true" : "false"
			printf "],\"truncated\":%s,\"total\":%d}", trunc, total
		}
	'
}

traffic_path_emit_trace() {
	raw="$1"
	fqdn="$(traffic_path_normalize_fqdn "$raw")"
	if [ -z "$fqdn" ]; then
		printf '{"code":1,"stderr":"fqdn required"}'
		return 0
	fi

	iface_row=""
	dns_row=""
	zapret_ids=""
	highlight=""
	runtime_ok=true

	iface_row="$(traffic_path_match_iface "$fqdn" || true)"
	dns_row="$(traffic_path_match_dns "$fqdn" || true)"
	zapret_ids="$(traffic_path_match_zapret "$fqdn" || true)"

	printf '{"code":0,"action":"trace","query":{"fqdn":"%s"},"layers":[' \
		"$(traffic_path_json_q "$fqdn")"

	layer_first=1
	# iface
	if [ -n "$iface_row" ]; then
		iface="${iface_row%%|*}"
		rest="${iface_row#*|}"
		kind="${rest%%|*}"
		base="${rest#*|}"
		rt="$(traffic_path_runtime_iface "$iface")"
		echo "$rt" | grep -q '"ok":true' || runtime_ok=false
		[ "$layer_first" -eq 1 ] || printf ','
		layer_first=0
		printf '{"id":"iface","status":"match","matchKind":"%s","scope":{"iface":"%s","base":"%s"},"runtime":%s}' \
			"$(traffic_path_json_q "$kind")" "$(traffic_path_json_q "$iface")" \
			"$(traffic_path_json_q "$base")" "$rt"
		highlight="${highlight:+$highlight,}iface:$iface"
		egress="tunnel:$iface"
	else
		[ "$layer_first" -eq 1 ] || printf ','
		layer_first=0
		printf '{"id":"iface","status":"none","matchKind":"none","scope":{},"runtime":{"ok":true}}'
		egress="wan"
	fi

	# dns
	if [ -n "$iface_row" ]; then
		[ "$layer_first" -eq 1 ] || printf ','
		layer_first=0
		printf '{"id":"dns","status":"skipped","matchKind":"none","scope":{"reason":"iface-covered"},"runtime":{"ok":true}}'
	elif [ -n "$dns_row" ]; then
		# row = domain|target|dns_id|list|kind
		kind="${dns_row##*|}"
		body="${dns_row%|*}"
		domain="$(printf '%s' "$body" | cut -d'|' -f1)"
		target="$(printf '%s' "$body" | cut -d'|' -f2)"
		dns_id="$(printf '%s' "$body" | cut -d'|' -f3)"
		list="$(printf '%s' "$body" | cut -d'|' -f4)"
		rt="$(traffic_path_runtime_dns "$dns_id")"
		echo "$rt" | grep -q '"ok":true' || runtime_ok=false
		[ "$layer_first" -eq 1 ] || printf ','
		layer_first=0
		printf '{"id":"dns","status":"match","matchKind":"%s","scope":{"dnsId":"%s","target":"%s","listFile":"%s","mappedDomain":"%s"},"runtime":%s}' \
			"$(traffic_path_json_q "$kind")" "$(traffic_path_json_q "$dns_id")" \
			"$(traffic_path_json_q "$target")" "$(traffic_path_json_q "$list")" \
			"$(traffic_path_json_q "$domain")" "$rt"
		highlight="${highlight:+$highlight,}dns:$dns_id"
	else
		[ "$layer_first" -eq 1 ] || printf ','
		layer_first=0
		printf '{"id":"dns","status":"default","matchKind":"none","scope":{},"runtime":{"ok":true}}'
	fi

	# zapret — rows: id|base|strategy
	if [ -n "$zapret_ids" ]; then
		secs_json=""
		hits_json=""
		sf=1
		z_rt_ok=true
		z_ids_plain=""
		z_mark=false
		z_in_opt=false
		z_detail=""
		while IFS= read -r zrow || [ -n "$zrow" ]; do
			[ -n "$zrow" ] || continue
			sid="${zrow%%|*}"
			zrest="${zrow#*|}"
			zbase="${zrest%%|*}"
			zstrat="${zrest#*|}"
			[ "$zstrat" = "$zrest" ] && zstrat=""
			[ "$sf" -eq 1 ] || secs_json="$secs_json,"
			[ "$sf" -eq 1 ] || hits_json="$hits_json,"
			sf=0
			secs_json="$secs_json\"$(traffic_path_json_q "$sid")\""
			hits_json="$hits_json{\"id\":\"$(traffic_path_json_q "$sid")\",\"base\":\"$(traffic_path_json_q "$zbase")\",\"strategy\":\"$(traffic_path_json_q "$zstrat")\"}"
			highlight="${highlight:+$highlight,}zapret:$sid"
			z_ids_plain="${z_ids_plain:+$z_ids_plain }$sid"
			zr="$(traffic_path_runtime_zapret "$sid")"
			echo "$zr" | grep -q '"ok":true' || z_rt_ok=false
			echo "$zr" | grep -q '"markQueue":true' && z_mark=true
			echo "$zr" | grep -q '"hostlistInOpt":true' && z_in_opt=true
			zd="$(printf '%s' "$zr" | sed -n 's/.*"detail":"\([^"]*\)".*/\1/p')"
			[ -n "$zd" ] && z_detail="${z_detail:+$z_detail; }$zd"
		done <<EOF
$zapret_ids
EOF
		[ "$z_rt_ok" = true ] || runtime_ok=false
		[ "$layer_first" -eq 1 ] || printf ','
		layer_first=0
		printf '{"id":"zapret","status":"match","matchKind":"list","scope":{"sections":[%s],"hits":[%s]},"runtime":{"ok":%s,"markQueue":%s,"hostlistInOpt":%s,"detail":"%s"}}' \
			"$secs_json" "$hits_json" "$z_rt_ok" "$z_mark" "$z_in_opt" "$(traffic_path_json_q "$z_detail")"
		zapret_ids="$z_ids_plain"
	else
		z_mark=false
		traffic_path_zapret_mark_queue_present && z_mark=true
		[ "$layer_first" -eq 1 ] || printf ','
		layer_first=0
		printf '{"id":"zapret","status":"none","matchKind":"none","scope":{"sections":[],"hits":[]},"runtime":{"ok":true,"markQueue":%s,"hostlistInOpt":false,"detail":""}}' \
			"$z_mark"
	fi

	# egress (+ uplink/tunnel monitor health)
	[ "$layer_first" -eq 1 ] || printf ','
	if [ "$egress" = "wan" ]; then
		eg_rt="$(traffic_path_wan_runtime_json)"
		echo "$eg_rt" | grep -q '"ok":true' || runtime_ok=false
	else
		eg_iface="${egress#tunnel:}"
		eg_rt="$(traffic_path_runtime_iface "$eg_iface")"
		echo "$eg_rt" | grep -q '"ok":true' || runtime_ok=false
	fi
	printf '{"id":"egress","status":"inferred","scope":{"path":"%s"},"runtime":%s}' \
		"$(traffic_path_json_q "$egress")" "$eg_rt"

	# headline
	hl=""
	if [ -n "$iface_row" ]; then
		hl="${iface_row%%|*}"
	elif [ -n "$dns_row" ]; then
		hl="dns:$(printf '%s' "${dns_row%|*}" | cut -d'|' -f3)"
	else
		hl="wan"
	fi
	if [ -n "$zapret_ids" ]; then
		zjoin="$(printf '%s' "$zapret_ids" | tr ' \n' ',' | sed 's/,,*/,/g; s/^,//; s/,$//')"
		hl="$hl + zapret($zjoin)"
	fi
	if [ -n "$iface_row" ]; then
		hl="$hl; DNS skipped"
	fi

	printf '],"summary":{"headline":"%s","highlight":[%s],"runtimeOk":%s,"egress":"%s","wan":%s}}' \
		"$(traffic_path_json_q "$hl")" \
		"$(printf '%s' "$highlight" | awk -F',' '{
			for (i=1;i<=NF;i++) {
				if (i>1) printf ","
				gsub(/^[ \t]+|[ \t]+$/, "", $i)
				if ($i!="") {
					gsub(/\\/, "\\\\", $i); gsub(/"/, "\\\"", $i)
					printf "\"%s\"", $i
				}
			}
		}')" \
		"$runtime_ok" \
		"$(traffic_path_json_q "$egress")" \
		"$(traffic_path_wan_runtime_json)"
}
