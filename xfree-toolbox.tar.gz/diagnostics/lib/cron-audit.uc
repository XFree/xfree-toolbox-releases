#!/usr/bin/env ucode
// Аудит /etc/crontabs/root: классификация задач на [xfree] и [external].
// Использование:
//   ucode cron-audit.uc [--json] [path_to_crontab]
import * as fs from "fs";

function is_xfree_line(line) {
	return match(line, /(xfree-toolbox|xfree-mgmt-hub|usb-power-watch|connectivity-watch|routing-monitor|auto-update)/) != null;
}

let json_mode = false;
let file = "/etc/crontabs/root";

for (let i = 0; i < length(ARGV); i++) {
	let a = ARGV[i];
	if (a == "--json") {
		json_mode = true;
	} else if (substr(a, 0, 1) != "-") {
		file = a;
	}
}

let xfree_lines = [];
let ext_lines = [];
let exists = false;

let fh = fs.open(file, "r");
if (fh) {
	exists = true;
	for (let raw = fh.read("line"); raw != null && length(raw) > 0; raw = fh.read("line")) {
		let line = replace(raw, /[\r\n]+$/, "");
		if (match(line, /^[[:space:]]*$/) || match(line, /^[[:space:]]*#/))
			continue;
		if (is_xfree_line(line))
			push(xfree_lines, line);
		else
			push(ext_lines, line);
	}
	fh.close();
}

if (json_mode) {
	printf("%J\n", {
		ok: exists,
		file: file,
		xfree: xfree_lines,
		external: ext_lines,
		counts: {
			xfree: length(xfree_lines),
			external: length(ext_lines)
		}
	});
	exit(0);
}

printf("=== crontab (%s) ===\n", file);
if (!exists) {
	printf("<нет %s>\n", file);
	exit(0);
}
for (let l in xfree_lines)
	printf("  [xfree] %s\n", l);
for (let l in ext_lines)
	printf("  [external] %s\n", l);
printf("  Итого: xfree=%d, external=%d\n", length(xfree_lines), length(ext_lines));
