#!/bin/sh
# shellcheck shell=sh
# DNS diagnostic: query basic FQDNs via profile dns-routing sections, log last run.

dns_check_now_ms() {
	if [ -r /proc/uptime ]; then
		awk '{ printf "%d\n", ($1 + 0) * 1000 }' /proc/uptime 2>/dev/null && return 0
	fi
	printf '%s000\n' "$(date +%s 2>/dev/null || echo 0)"
}

dns_check_hosts() {
	_raw="${XFREE_DNS_CHECK_HOSTS:-ya.ru google.com youtube.com github.com cloudflare.com example.com}"
	# shellcheck disable=SC2086
	set -- $_raw
	for _h in "$@"; do
		[ -n "$_h" ] || continue
		printf '%s\n' "$_h"
	done
}

dns_check_redirect_enabled() {
	case "${1:-0}" in
		1 | yes | true | on | ON | YES | TRUE) return 0 ;;
		*) return 1 ;;
	esac
}

# $1=DNS_TARGET (addr#port). stdout: addr|port
dns_check_parse_target() {
	_t="${1:-}"
	[ -n "$_t" ] || return 1
	case "$_t" in
		*\#*)
			printf '%s|%s\n' "${_t%%#*}" "${_t##*#}"
			;;
		*)
			printf '%s|53\n' "$_t"
			;;
	esac
}

# $1=dns-routing/dns root. Lines: addr|port|label|primary (1/0)
dns_check_list_resolvers() {
	_root="${1:-}"
	[ -n "$_root" ] && [ -d "$_root" ] || return 1
	_out=""
	for _conf in "$_root"/*/config/dns.conf; do
		[ -f "$_conf" ] || continue
		_line="$(
			unset DNS_ID DNS_HOST DNS_TARGET DNS_REDIRECT DNS_RESOLVER_URL \
				DNS_BOOTSTRAP_DNS DNS_LISTEN_ADDR DNS_LISTEN_PORT DNS_KIND \
				2>/dev/null || true
			_cf="${TMPDIR:-/tmp}/xfree-dns-check-sec.$$"
			tr -d '\r' < "$_conf" > "$_cf" || exit 0
			# shellcheck disable=SC1090
			. "$_cf" || {
				rm -f "$_cf"
				exit 0
			}
			rm -f "$_cf"
			[ -n "${DNS_TARGET:-}" ] || exit 0
			_ap="$(dns_check_parse_target "$DNS_TARGET")" || exit 0
			_addr="${_ap%%|*}"
			_port="${_ap#*|}"
			[ -n "$_addr" ] && [ -n "$_port" ] || exit 0
			_lab="${DNS_HOST:-${DNS_ID:-$DNS_TARGET}}"
			_prim=0
			if dns_check_redirect_enabled "${DNS_REDIRECT:-0}"; then
				_prim=1
			fi
			printf '%s|%s|%s|%s\n' "$_addr" "$_port" "$_lab" "$_prim"
		)" || _line=""
		[ -n "$_line" ] || continue
		_out="${_out}${_line}
"
	done
	[ -n "$_out" ] || return 1
	printf '%s' "$_out" | sort -t '|' -k4,4nr -k2,2n 2>/dev/null || printf '%s' "$_out"
}

dns_check_primary_summary() {
	dns_check_list_resolvers "$1" | while IFS='|' read -r _addr _port _lab _prim; do
		[ "$_prim" = "1" ] || continue
		printf '%s  %s#%s\n' "$_lab" "$_addr" "$_port"
	done
}

dns_check_format_section_header() {
	_addr="$1"
	_port="$2"
	_lab="$3"
	_prim="$4"
	if [ "$_prim" = "1" ]; then
		printf 'Секция %s  %s#%s  [основной]\n' "$_lab" "$_addr" "$_port"
	else
		printf 'Секция %s  %s#%s\n' "$_lab" "$_addr" "$_port"
	fi
}

dns_check_fill_msec() {
	_msec="$1"
	_t0="$2"
	_t1="$3"
	case "$_msec" in
		'' | '-' | *[!0-9]*)
			_d=$((_t1 - _t0))
			if [ "$_d" -lt 0 ]; then
				_d=0
			fi
			printf '%s\n' "$_d"
			;;
		*)
			printf '%s\n' "$_msec"
			;;
	esac
}

# $1=addr $2=port $3=qname  stdout: OK|FAIL <rcode-or-reason> <msec> <a>
dns_check_query_one() {
	_addr="$1"
	_port="$2"
	_qname="$3"
	_t0="$(dns_check_now_ms)"
	_line=""
	_rc=0
	_line="$(https_dns_proxy_drill_query_timed "$_addr" "$_port" "$_qname")" || _rc=$?
	_t1="$(dns_check_now_ms)"
	_st="${_line%% *}"
	_rest="${_line#* }"
	_rcode="?"
	_msec="-"
	_a="-"
	for _tok in $_rest; do
		case "$_tok" in
			rcode=*) _rcode="${_tok#rcode=}" ;;
			msec=*) _msec="${_tok#msec=}" ;;
			a=*) _a="${_tok#a=}" ;;
			timeout) _rcode="timeout" ;;
			no-drill) _rcode="no-drill" ;;
			no-port) _rcode="no-port" ;;
			refused) _rcode="refused" ;;
			drill=*) _rcode="$_tok" ;;
		esac
	done
	_msec="$(dns_check_fill_msec "$_msec" "$_t0" "$_t1")"
	if [ "$_st" != "OK" ] && [ "$_st" != "FAIL" ]; then
		_st="FAIL"
	fi
	printf '%s %s %s %s\n' "$_st" "$_rcode" "$_msec" "$_a"
	return "$_rc"
}

dns_check_format_row() {
	_host="$1"
	_st="$2"
	_rcode="$3"
	_msec="$4"
	_a="$5"
	printf '  %-18s %-4s %-12s %6sms  A=%s\n' "$_host" "$_st" "$_rcode" "$_msec" "$_a"
}
