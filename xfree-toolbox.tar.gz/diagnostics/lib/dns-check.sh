#!/bin/sh
# shellcheck shell=sh
# DNS diagnostic: query basic FQDNs via profile dns-routing sections, log last run.

dns_check_now_ms() {
	if [ -r /proc/uptime ]; then
		awk '{ printf "%d\n", ($1 + 0) * 1000 }' /proc/uptime 2>/dev/null && return 0
	fi
	printf '%s000\n' "$(date +%s 2>/dev/null || echo 0)"
}

dns_check_hosts() {
	_raw="${XFREE_DNS_CHECK_HOSTS:-ya.ru google.com youtube.com github.com cloudflare.com example.com}"
	# shellcheck disable=SC2086
	set -- $_raw
	for _h in "$@"; do
		[ -n "$_h" ] || continue
		printf '%s\n' "$_h"
	done
}

dns_check_redirect_enabled() {
	case "${1:-0}" in
		1 | yes | true | on | ON | YES | TRUE) return 0 ;;
		*) return 1 ;;
	esac
}

# $1=DNS_TARGET (addr#port). stdout: addr|port
dns_check_parse_target() {
	_t="${1:-}"
	[ -n "$_t" ] || return 1
	case "$_t" in
		*\#*)
			printf '%s|%s\n' "${_t%%#*}" "${_t##*#}"
			;;
		*)
			printf '%s|53\n' "$_t"
			;;
	esac
}

# Reference baselines always probed in diagnostics (deduped by addr#port).
# Google plain UDP + Google DoH via local https-dns-proxy (listen 5062).
dns_check_reference_resolvers() {
	printf '%s\n' '8.8.8.8|53|8.8.8.8|0'
	printf '%s\n' '127.0.0.1|5062|dns.google|0'
}

# $1=dns-routing/dns root. Lines: addr|port|label|primary (1/0)
# Always merges reference Google resolvers (plain + DoH) if missing.
dns_check_list_resolvers() {
	_root="${1:-}"
	_out=""
	_seen="|"
	if [ -n "$_root" ] && [ -d "$_root" ]; then
		for _conf in "$_root"/*/config/dns.conf; do
			[ -f "$_conf" ] || continue
			_line="$(
				unset DNS_ID DNS_HOST DNS_TARGET DNS_REDIRECT DNS_RESOLVER_URL \
					DNS_BOOTSTRAP_DNS DNS_LISTEN_ADDR DNS_LISTEN_PORT DNS_KIND \
					2>/dev/null || true
				_cf="${TMPDIR:-/tmp}/xfree-dns-check-sec.$$"
				tr -d '\r' < "$_conf" > "$_cf" || exit 0
				# shellcheck disable=SC1090
				. "$_cf" || {
					rm -f "$_cf"
					exit 0
				}
				rm -f "$_cf"
				[ -n "${DNS_TARGET:-}" ] || exit 0
				_ap="$(dns_check_parse_target "$DNS_TARGET")" || exit 0
				_addr="${_ap%%|*}"
				_port="${_ap#*|}"
				[ -n "$_addr" ] && [ -n "$_port" ] || exit 0
				_lab="${DNS_HOST:-${DNS_ID:-$DNS_TARGET}}"
				_prim=0
				if dns_check_redirect_enabled "${DNS_REDIRECT:-0}"; then
					_prim=1
				fi
				printf '%s|%s|%s|%s\n' "$_addr" "$_port" "$_lab" "$_prim"
			)" || _line=""
			[ -n "$_line" ] || continue
			_key="${_line%%|*}|$(printf '%s' "$_line" | cut -d'|' -f2)"
			case "$_seen" in
				*"|$_key|"*) continue ;;
			esac
			_seen="${_seen}${_key}|"
			_out="${_out}${_line}
"
		done
	fi
	while IFS='|' read -r _addr _port _lab _prim; do
		[ -n "$_addr" ] && [ -n "$_port" ] || continue
		_key="${_addr}|${_port}"
		case "$_seen" in
			*"|$_key|"*) continue ;;
		esac
		_seen="${_seen}${_key}|"
		_out="${_out}${_addr}|${_port}|${_lab}|${_prim:-0}
"
	done <<EOF
$(dns_check_reference_resolvers)
EOF
	[ -n "$_out" ] || return 1
	printf '%s' "$_out" | sort -t '|' -k4,4nr -k2,2n 2>/dev/null || printf '%s' "$_out"
}

# Run all hosts for one resolver in parallel; print rows in hosts-file order.
# Sets globals: DNS_CHECK_SEC_OK DNS_CHECK_SEC_FAIL DNS_CHECK_SEC_SLOW_MS DNS_CHECK_SEC_SLOW_WHERE
dns_check_run_section_parallel() {
	_addr="$1"
	_port="$2"
	_lab="$3"
	_prim="$4"
	_hosts_f="$5"
	_jobdir=""
	_idx=0
	_host=""
	_q=""
	_st=""
	_rcode=""
	_msec=""
	_a=""
	_qr=""

	DNS_CHECK_SEC_OK=0
	DNS_CHECK_SEC_FAIL=0
	DNS_CHECK_SEC_SLOW_MS=0
	DNS_CHECK_SEC_SLOW_WHERE=""

	dns_check_format_section_header "$_addr" "$_port" "$_lab" "$_prim"
	_jobdir="${TMPDIR:-/tmp}/xfree-dns-check-jobs.$$.$(printf '%s_%s' "$_addr" "$_port" | tr -c 'A-Za-z0-9._-' '_')"
	rm -rf "$_jobdir" 2>/dev/null || true
	mkdir -p "$_jobdir" || return 1

	_idx=0
	while read -r _host; do
		[ -n "$_host" ] || continue
		printf '%s\n' "$_host" >"$_jobdir/$_idx.host"
		(
			_q=""
			_q="$(dns_check_query_one "$_addr" "$_port" "$_host")" || true
			printf '%s\n' "$_q" >"$_jobdir/$_idx.res"
		) &
		_idx=$((_idx + 1))
	done <"$_hosts_f"
	wait

	_i=0
	while [ "$_i" -lt "$_idx" ]; do
		_host="$(cat "$_jobdir/$_i.host" 2>/dev/null || true)"
		_q="$(cat "$_jobdir/$_i.res" 2>/dev/null || true)"
		[ -n "$_host" ] || {
			_i=$((_i + 1))
			continue
		}
		_st="${_q%% *}"
		_qr="${_q#* }"
		_rcode="${_qr%% *}"
		_qr="${_qr#* }"
		_msec="${_qr%% *}"
		_a="${_qr#* }"
		[ -n "$_st" ] || _st="FAIL"
		[ -n "$_rcode" ] || _rcode="?"
		[ -n "$_msec" ] || _msec="0"
		[ -n "$_a" ] || _a="-"
		dns_check_format_row "$_host" "$_st" "$_rcode" "$_msec" "$_a"
		if [ "$_st" = "OK" ]; then
			DNS_CHECK_SEC_OK=$((DNS_CHECK_SEC_OK + 1))
		else
			DNS_CHECK_SEC_FAIL=$((DNS_CHECK_SEC_FAIL + 1))
		fi
		case "$_msec" in
			'' | *[!0-9]*) ;;
			*)
				if [ "$_msec" -gt "$DNS_CHECK_SEC_SLOW_MS" ]; then
					DNS_CHECK_SEC_SLOW_MS="$_msec"
					DNS_CHECK_SEC_SLOW_WHERE="${_host} @ ${_lab} ${_addr}#${_port}"
				fi
				;;
		esac
		_i=$((_i + 1))
	done
	rm -rf "$_jobdir" 2>/dev/null || true
	printf '\n'
}

dns_check_primary_summary() {
	dns_check_list_resolvers "$1" | while IFS='|' read -r _addr _port _lab _prim; do
		[ "$_prim" = "1" ] || continue
		printf '%s  %s#%s\n' "$_lab" "$_addr" "$_port"
	done
}

dns_check_format_section_header() {
	_addr="$1"
	_port="$2"
	_lab="$3"
	_prim="$4"
	if [ "$_prim" = "1" ]; then
		printf 'Секция %s  %s#%s  [основной]\n' "$_lab" "$_addr" "$_port"
	else
		printf 'Секция %s  %s#%s\n' "$_lab" "$_addr" "$_port"
	fi
}

dns_check_fill_msec() {
	_msec="$1"
	_t0="$2"
	_t1="$3"
	case "$_msec" in
		'' | '-' | *[!0-9]*)
			_d=$((_t1 - _t0))
			if [ "$_d" -lt 0 ]; then
				_d=0
			fi
			printf '%s\n' "$_d"
			;;
		*)
			printf '%s\n' "$_msec"
			;;
	esac
}

# $1=addr $2=port $3=qname  stdout: OK|FAIL <rcode-or-reason> <msec> <a>
dns_check_query_one() {
	_addr="$1"
	_port="$2"
	_qname="$3"
	_t0="$(dns_check_now_ms)"
	_line=""
	_rc=0
	_line="$(https_dns_proxy_drill_query_timed "$_addr" "$_port" "$_qname")" || _rc=$?
	_t1="$(dns_check_now_ms)"
	_st="${_line%% *}"
	_rest="${_line#* }"
	_rcode="?"
	_msec="-"
	_a="-"
	for _tok in $_rest; do
		case "$_tok" in
			rcode=*) _rcode="${_tok#rcode=}" ;;
			msec=*) _msec="${_tok#msec=}" ;;
			a=*) _a="${_tok#a=}" ;;
			timeout) _rcode="timeout" ;;
			no-drill) _rcode="no-drill" ;;
			no-port) _rcode="no-port" ;;
			refused) _rcode="refused" ;;
			drill=*) _rcode="$_tok" ;;
		esac
	done
	_msec="$(dns_check_fill_msec "$_msec" "$_t0" "$_t1")"
	if [ "$_st" != "OK" ] && [ "$_st" != "FAIL" ]; then
		_st="FAIL"
	fi
	printf '%s %s %s %s\n' "$_st" "$_rcode" "$_msec" "$_a"
	return "$_rc"
}

dns_check_format_row() {
	_host="$1"
	_st="$2"
	_rcode="$3"
	_msec="$4"
	_a="$5"
	printf '  %-18s %-4s %-12s %6sms  A=%s\n' "$_host" "$_st" "$_rcode" "$_msec" "$_a"
}

# Parse last dns-check.log → lines: target|label|ok|fail|minMs|maxMs|stamp
# Matching tip/runtime uses target (addr#port) and/or label (DNS_HOST / DNS_ID).
dns_check_summarize_last_log() {
	_log="${1:-}"
	[ -n "$_log" ] && [ -f "$_log" ] || return 1
	awk '
		BEGIN { stamp = ""; label = ""; target = ""; ok = 0; fail = 0; minms = -1; maxms = -1 }
		function flush() {
			if (label == "" || target == "") return
			printf "%s|%s|%d|%d|%d|%d|%s\n", target, label, ok, fail, (minms < 0 ? 0 : minms), (maxms < 0 ? 0 : maxms), stamp
			label = ""; target = ""; ok = 0; fail = 0; minms = -1; maxms = -1
		}
		/^=== Диагностика DNS / {
			flush()
			stamp = $0
			sub(/^=== Диагностика DNS[[:space:]]+/, "", stamp)
			sub(/[[:space:]]*===$/, "", stamp)
			next
		}
		/^Секция[[:space:]]+/ {
			flush()
			line = $0
			sub(/^Секция[[:space:]]+/, "", line)
			sub(/[[:space:]]+\[основной\][[:space:]]*$/, "", line)
			n = split(line, parts, /[[:space:]][[:space:]]+/)
			if (n < 2) {
				# single-space fallback: last token is target
				n = split(line, parts, /[[:space:]]+/)
				if (n < 2) next
				target = parts[n]
				label = parts[1]
				for (i = 2; i < n; i++) label = label " " parts[i]
			} else {
				label = parts[1]
				target = parts[2]
				sub(/[[:space:]]+$/, "", target)
			}
			next
		}
		/^[[:space:]]+[A-Za-z0-9_.-]+[[:space:]]+(OK|FAIL)[[:space:]]/ {
			if (label == "") next
			st = ""
			ms = ""
			for (i = 1; i <= NF; i++) {
				if ($i == "OK" || $i == "FAIL") st = $i
				else if ($i ~ /^[0-9]+ms$/) {
					ms = $i
					sub(/ms$/, "", ms)
				}
			}
			if (st == "OK") ok++
			else if (st == "FAIL") fail++
			else next
			if (ms != "") {
				m = ms + 0
				if (minms < 0 || m < minms) minms = m
				if (maxms < 0 || m > maxms) maxms = m
			}
			next
		}
		END { flush() }
	' "$_log"
}

# Compact human line: "4/6 OK · 2–24ms" or "нет данных"
dns_check_format_summary_line() {
	_ok="${1:-0}"
	_fail="${2:-0}"
	_min="${3:-0}"
	_max="${4:-0}"
	_total=$((_ok + _fail))
	if [ "$_total" -le 0 ]; then
		printf 'нет данных\n'
		return 0
	fi
	if [ "$_min" = "$_max" ]; then
		printf '%s/%s OK · %sms\n' "$_ok" "$_total" "$_min"
	else
		printf '%s/%s OK · %s–%sms\n' "$_ok" "$_total" "$_min" "$_max"
	fi
}

# $1=log $2=dns_id $3=target(addr#port, optional) $4=host_label(optional)
# stdout: ok|fail|minMs|maxMs|stamp|label|target|summary
dns_check_lookup_section_summary() {
	_log="${1:-}"
	_id="${2:-}"
	_want_target="${3:-}"
	_want_host="${4:-}"
	_tmp=""
	_best=""
	_score=0
	_ok=0
	_fail=0
	_min=0
	_max=0
	_stamp=""
	_lab=""
	_t=""
	_sum=""
	_row_score=0

	[ -n "$_log" ] && [ -n "$_id" ] || return 1
	_tmp="$(mktemp 2>/dev/null || mktemp -t xfree-dns-check-sum)"
	if ! dns_check_summarize_last_log "$_log" >"$_tmp" 2>/dev/null; then
		rm -f "$_tmp"
		return 1
	fi

	while IFS='|' read -r _t _lab _ok _fail _min _max _stamp; do
		[ -n "$_t" ] || continue
		_row_score=0
		if [ -n "$_want_target" ] && [ "$_t" = "$_want_target" ]; then
			_row_score=3
		elif [ "$_lab" = "$_id" ]; then
			_row_score=2
		elif [ -n "$_want_host" ] && [ "$_lab" = "$_want_host" ]; then
			_row_score=2
		else
			continue
		fi
		if [ "$_row_score" -gt "$_score" ]; then
			_score="$_row_score"
			_best="${_ok}|${_fail}|${_min}|${_max}|${_stamp}|${_lab}|${_t}"
		fi
	done <"$_tmp"
	rm -f "$_tmp"

	[ -n "$_best" ] || return 1
	IFS='|' read -r _ok _fail _min _max _stamp _lab _t <<EOF
$_best
EOF
	_sum="$(dns_check_format_summary_line "$_ok" "$_fail" "$_min" "$_max")"
	printf '%s|%s|%s|%s|%s|%s|%s|%s\n' "$_ok" "$_fail" "$_min" "$_max" "$_stamp" "$_lab" "$_t" "$_sum"
}

# $1=log $2=target(addr#port). stdout: host|OK|FAIL|rcode|ms (one row per probe)
dns_check_section_hosts_by_target() {
	_log="${1:-}"
	_want="${2:-}"
	[ -n "$_log" ] && [ -f "$_log" ] && [ -n "$_want" ] || return 1
	awk -v want="$_want" '
		BEGIN { insec = 0 }
		/^Секция[[:space:]]+/ {
			line = $0
			sub(/^Секция[[:space:]]+/, "", line)
			sub(/[[:space:]]+\[основной\][[:space:]]*$/, "", line)
			target = ""
			n = split(line, parts, /[[:space:]][[:space:]]+/)
			if (n >= 2) {
				target = parts[2]
				sub(/[[:space:]]+$/, "", target)
			} else {
				n = split(line, parts, /[[:space:]]+/)
				if (n >= 2) target = parts[n]
			}
			insec = (target == want) ? 1 : 0
			next
		}
		/^=== / { insec = 0; next }
		insec && /^[[:space:]]+[A-Za-z0-9_.-]+[[:space:]]+(OK|FAIL)[[:space:]]/ {
			host = ""
			st = ""
			rcode = ""
			ms = ""
			for (i = 1; i <= NF; i++) {
				if (host == "" && $i !~ /^(OK|FAIL)$/ && $i !~ /^[0-9]+ms$/ && $i !~ /^A=/)
					host = $i
				else if ($i == "OK" || $i == "FAIL") st = $i
				else if (st != "" && rcode == "" && $i !~ /^[0-9]+ms$/ && $i !~ /^A=/)
					rcode = $i
				else if ($i ~ /^[0-9]+ms$/) {
					ms = $i
					sub(/ms$/, "", ms)
				}
			}
			if (host != "" && st != "")
				printf "%s|%s|%s|%s\n", host, st, rcode, (ms == "" ? "0" : ms)
			next
		}
	' "$_log"
}
