#!/bin/sh
# Hand-written handlers for cli.run component=custom in diagnostics/menu.yaml.
# shellcheck shell=sh

IR_ROOT="${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}"
MONITOR_DIR="${ROUTING_MONITOR_DIR:-$IR_ROOT/state/monitor}"
STATUS_F="$MONITOR_DIR/routing-check.status"
LOG_F="$MONITOR_DIR/routing-check.log"
DIAG_DIR="${XFREE_DIAGNOSTICS_DIR:-$ROOT_DIR/diagnostics}"
RUN_SH="$DIAG_DIR/routing-monitor-run.sh"
INSTALL_SH="$DIAG_DIR/routing-monitor-install.sh"
REMOVE_SH="$DIAG_DIR/routing-monitor-remove.sh"
CHECK_SH="$ROOT_DIR/iface-routing/check-routing.sh"
LED_TEST_SH="$ROOT_DIR/system/hardware/led-test.sh"

run_log() { ui_menu_invoke_with_output "$@"; }

run_log_safe() {
	script="$1"
	shift
	[ -f "$script" ] || {
		ui_msgbox "Туннели" "Не найден скрипт:\n$script"
		return 0
	}
	[ -x "$script" ] || chmod +x "$script" 2>/dev/null || true
	ui_menu_invoke_with_output "$(basename -- "$script" 2>/dev/null || basename "$script")" sh "$script" "$@" || true
	return 0
}

show_last_status() {
	if [ ! -f "$STATUS_F" ] && [ ! -f "$LOG_F" ]; then
		ui_msgbox "Туннели" "Нет файлов мониторинга:\n$STATUS_F"
		return 0
	fi
	tmp="$(mktemp)"
	{
		echo "=== $STATUS_F ==="
		cat "$STATUS_F" 2>/dev/null || echo "<нет>"
		echo
		echo "=== $LOG_F (последний прогон) ==="
		cat "$LOG_F" 2>/dev/null || echo "<нет>"
	} >"$tmp"
	ui_show_textbox "Туннели: последний контроль" "$tmp" 28 110
	rm -f "$tmp"
}

interval_menu() {
	choice="$(ui_menu "Интервал cron туннелей" "Рекомендация: 15 минут (баланс нагрузки). 5 — чаще; 60 — раз в час." 16 90 6 \
		"15" "Каждые 15 минут (по умолчанию)" \
		"5" "Каждые 5 минут" \
		"30" "Каждые 30 минут" \
		"60" "Каждый час (:00)" \
		"0" "Назад" || true)"
	[ -n "${choice:-}" ] || return 0
	[ "$choice" = "0" ] && return 0
	case "$choice" in
		5|15|30|60) ;;
		*) return 0 ;;
	esac
	run_log "Установка периодического контроля ($choice мин)" sh "$INSTALL_SH" --minutes "$choice"
}

diagnostics_run_monitor_now() {
	run_log_safe "$RUN_SH"
}

diagnostics_disable_cron() {
	run_log_safe "$REMOVE_SH"
}

diagnostics_remove_monitor_files() {
	if ui_confirm "Туннели" "Удалить cron и файлы\n$STATUS_F\n$LOG_F\nи routing-monitor.conf?"; then
		ui_menu_invoke_with_output "Удаление мониторинга" env REMOVE_MONITOR_FILES=1 sh "$REMOVE_SH"
	fi
}

diagnostics_led_test() {
	if ui_confirm "Диагностика: LED" \
"Что произойдет во время теста:

1) Снимется текущее состояние всех LED (trigger/brightness).
2) Все лампы кратко погаснут (blackout).
3) Каждый LED из /sys/class/leds будет мигать по очереди (~5 с на лампу).
4) Затем будет короткая проверка парного мигания WAN↔WPS (если поддерживается платой).
5) В конце исходные состояния LED восстановятся и служба led будет перезапущена.

Смотрите на индикаторы на корпусе роутера.
Если на плате нет некоторых LED в sysfs, они будут пропущены.

Запустить тест?"; then
		run_log_safe "$LED_TEST_SH"
	fi
}

system_logs_menu() {
	# shellcheck disable=SC1091
	. "$ROOT_DIR/lib/background-tasks.sh"
	# shellcheck disable=SC1091
	. "$ROOT_DIR/lib/ui-background-tasks.sh"
	# shellcheck disable=SC1091
	. "$ROOT_DIR/lib/system-logs.sh"

	_catalog="${UI_TMP_ROOT:-/tmp}/xfree-system-logs-catalog.$$"

	while true; do
		system_logs_build_catalog "$_catalog" >/dev/null 2>&1 || true

		if [ ! -s "$_catalog" ]; then
			ui_msgbox "Логи системы" "Пока нет файлов логов toolbox.

Появятся после:
  • диагностики DNS (меню Диагностика)
  • фоновой задачи (apply-template, recovery digest, …)
  • cron мониторинга uplink или маршрутизации
  • recovery planner (ENABLED=1)

Каталоги:
  $(system_logs_bg_root)/
  $(system_logs_state_root)/system/"
			return 0
		fi

		set --
		while IFS="$(printf '\t')" read -r _key _path _live _title; do
			[ -n "$_key" ] || continue
			_blurb="$(system_logs_entry_blurb "$_path" "$_title" 2>/dev/null || printf '%s' "$_title")"
			set -- "$@" "$_key" "$_blurb"
		done <"$_catalog"

		choice="$(ui_menu "Логи системы" \
"Фоновые задачи и постоянные логи toolbox. ► в названии — задача выполняется." \
24 100 14 "$@" "0" "Назад" || true)"
		[ -n "${choice:-}" ] || return 0
		[ "$choice" = "0" ] && return 0

		_lookup="$(system_logs_catalog_lookup "$_catalog" "$choice")"
		[ -n "$_lookup" ] || continue
		_path="${_lookup%%	*}"
		_rest="${_lookup#*	}"
		_live="${_rest%%	*}"
		_title="${_rest#*	}"

		_task_pid=""
		if [ "$_live" = "1" ] && bg_tasks_is_running; then
			_task_pid="${BG_TASK_PID:-}"
		fi
		system_logs_view_path "$_title" "$_path" "$_live" "$_task_pid"
	done
}
