#!/bin/sh
# shellcheck shell=sh
# Текстовый статус мониторинга туннелей для LuCI (без whiptail).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"

MONITOR_DIR="${XFREE_MONITOR_DIR:-/etc/xfree-toolbox/monitor}"
STATUS_F="$MONITOR_DIR/routing-check.status"
LOG_F="$MONITOR_DIR/routing-check.log"
CHECK_SH="$ROOT_DIR/iface-routing/check-routing.sh"

RUN_CHECK=0
while [ "$#" -gt 0 ]; do
	case "$1" in
		--check) RUN_CHECK=1 ;;
		-h|--help)
			printf 'Usage: %s [--check]\n' "$(basename "$0")"
			exit 0
			;;
		*)
			echo "Unknown argument: $1" >&2
			exit 1
			;;
	esac
	shift
done

if [ "$RUN_CHECK" -eq 1 ]; then
	[ -f "$CHECK_SH" ] || die "нет $CHECK_SH"
	echo "=== Проверка туннелей (check-routing) ==="
	echo
	sh "$CHECK_SH" || true
	echo
fi

echo "=== $STATUS_F ==="
if [ -f "$STATUS_F" ]; then
	cat "$STATUS_F"
else
	echo "<нет статуса — включите периодическую проверку или запустите с --check>"
fi
echo
echo "=== $LOG_F ==="
if [ -f "$LOG_F" ]; then
	# last ~80 lines keep LuCI console readable
	tail -n 80 "$LOG_F" 2>/dev/null || cat "$LOG_F"
else
	echo "<нет лога>"
fi
