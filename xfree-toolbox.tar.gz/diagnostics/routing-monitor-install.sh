#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1090
. "$COMMON_SH"

common_load_project_config "$ROOT_DIR"

IR_ROOT="${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}"
MONITOR_DIR="${ROUTING_MONITOR_DIR:-$IR_ROOT/state/monitor}"
RUN_ABS="$(CDPATH= cd -- "$SCRIPT_DIR" && pwd -P)/routing-monitor-run.sh"
CONF_FILE="$MONITOR_DIR/routing-monitor.conf"
MARKER='# xfree-toolbox-routing-monitor'

usage() {
    cat <<EOF
Usage: $(basename "$0") [--minutes <5|15|30|60>]

Разовая установка задачи cron: периодический запуск diagnostics/routing-monitor-run.sh.
По умолчанию интервал 15 минут (компромисс для домашних роутеров: частые проверки
без постоянной нагрузки; 5 — агрессивнее; 60 — каждый час в :00).

Файлы: $MONITOR_DIR/routing-check.status и routing-check.log
EOF
}

INTERVAL="${ROUTING_MONITOR_INTERVAL_MIN:-15}"
while [ "$#" -gt 0 ]; do
    case "$1" in
        --minutes|--interval)
            shift
            INTERVAL="${1:-15}"
            [ "$#" -gt 0 ] && shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "[-] Неизвестный аргумент: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

case "$INTERVAL" in
    ''|*[!0-9]*) INTERVAL=15 ;;
esac

case "$INTERVAL" in
    5)  CRON_BODY='*/5 * * * *' ;;
    15) CRON_BODY='*/15 * * * *' ;;
    30) CRON_BODY='*/30 * * * *' ;;
    60) CRON_BODY='0 * * * *' ;;
    *)
        echo "[-] Поддерживаются только 5, 15, 30 или 60 (минут). Задано: $INTERVAL" >&2
        exit 2
        ;;
esac

[ -x "$RUN_ABS" ] || chmod +x "$RUN_ABS" 2>/dev/null || true
mkdir -p "$MONITOR_DIR"

TS_ISO="$(date -u +'%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date +'%Y-%m-%dT%H:%M:%SZ')"
{
    echo "INTERVAL_MIN=$INTERVAL"
    echo "CRON_BODY=$CRON_BODY"
    echo "RUN_SCRIPT=$RUN_ABS"
    echo "MONITOR_DIR=$MONITOR_DIR"
    echo "INSTALLED_AT_UTC=$TS_ISO"
} >"$CONF_FILE"

CRON_LINE="$CRON_BODY /bin/sh $RUN_ABS"

tmp_ct="$(mktemp)"
cleanup_ct() {
    rm -f "$tmp_ct"
}
trap cleanup_ct EXIT INT TERM

# sed (не grep): пустой crontab не даёт лишнего падения пайпа
: >"$tmp_ct"
( crontab -l 2>/dev/null || true ) | grep -vF '# xfree-toolbox-routing-monitor' | grep -vF 'routing-monitor-run.sh' >>"$tmp_ct" || true
{
    cat "$tmp_ct"
    echo "$MARKER"
    echo "$CRON_LINE"
} | crontab -

/etc/init.d/cron enabled 2>/dev/null && /etc/init.d/cron restart >/dev/null 2>&1 || true

echo "[+] Routing monitor cron установлен: каждые $INTERVAL мин (cron: $CRON_BODY)"
echo "    Статус: $MONITOR_DIR/routing-check.status"
echo "    Лог последнего прогона: $MONITOR_DIR/routing-check.log"
