#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1090
. "$COMMON_SH"

common_load_project_config "$ROOT_DIR"

IR_ROOT="${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}"
MONITOR_DIR="${ROUTING_MONITOR_DIR:-$IR_ROOT/state/monitor}"

tmp_ct="$(mktemp)"
trap 'rm -f "$tmp_ct"' EXIT INT TERM

( crontab -l 2>/dev/null || true ) | sed '\#^# xfree-toolbox-routing-monitor$#d;/routing-monitor-run\.sh/d' >"$tmp_ct"
crontab "$tmp_ct"

/etc/init.d/cron enabled 2>/dev/null && /etc/init.d/cron restart >/dev/null 2>&1 || true

rm -f "$MONITOR_DIR/routing-monitor.conf" 2>/dev/null || true
# status/log оставляем по умолчанию (можно удалить вручную); по запросу — чистка:
if [ "${REMOVE_MONITOR_FILES:-0}" = "1" ]; then
    rm -f "$MONITOR_DIR/routing-check.status" "$MONITOR_DIR/routing-check.log" 2>/dev/null || true
fi

echo "[+] Задачи cron routing-monitor удалены (строки с routing-monitor-run.sh)."
echo "    Конфиг: $MONITOR_DIR/routing-monitor.conf (удалён при наличии)."
