#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo "=== df -h ==="
df -h
echo
echo "=== overlay / flash ==="
df -h /overlay / 2>/dev/null || true
echo
echo "=== top dirs on overlay (du) ==="
du -sh /overlay/upper/* 2>/dev/null | sort -hr | head -25
echo
echo "=== /root ==="
du -sh /root/* /root/.[!.]* 2>/dev/null | sort -hr | head -20
echo
echo "=== xfree-toolbox ==="
du -sh /root/xfree-toolbox/* 2>/dev/null | sort -hr | head -20
echo
echo "=== profiles / vpn conf ==="
du -sh /root/xfree-toolbox/profiles 2>/dev/null || true
du -sh /root/xfree-toolbox/profiles/*/vpn/*/* 2>/dev/null | sort -hr | head -20
echo
echo "=== /tmp ==="
du -sh /tmp/* 2>/dev/null | sort -hr | head -15
echo
echo "=== logs / opkg / apk ==="
du -sh /var/log /tmp/log /overlay/upper/var/log 2>/dev/null || true
du -sh /overlay/upper/usr/lib/opkg /overlay/upper/lib/apk /overlay/upper/etc/apk 2>/dev/null || true
ls -lah /tmp/xfree-background-tasks 2>/dev/null | head -20 || true
du -sh /tmp/xfree-background-tasks 2>/dev/null || true
echo
echo "=== large files > 1M under /overlay ==="
find /overlay/upper -type f -size +1M 2>/dev/null | head -40 | while read -r f; do
  ls -lh "$f" 2>/dev/null
done
echo
echo "=== count warp/proton conf ==="
find /root/xfree-toolbox/profiles -name '*.conf' 2>/dev/null | wc -l
find /root/xfree-toolbox/profiles -name '*.conf' 2>/dev/null | head -5
REMOTE
