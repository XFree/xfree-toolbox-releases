#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
BASE=build/openwrt/luci-app-xfree-toolbox/htdocs/luci-static/resources
scp "${SCP_OPTS[@]}" \
  diagnostics/lib/dns-check.sh \
  diagnostics/lib/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/lib/"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/traffic-map.js" \
  "$BASE/xfree-toolbox/xfree-dashboard.css" \
  "$SSH_TARGET:/www/luci-static/resources/xfree-toolbox/"
scp "${SCP_OPTS[@]}" \
  "$BASE/view/xfree-toolbox/shell.js" \
  "$SSH_TARGET:/www/luci-static/resources/view/xfree-toolbox/shell.js"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
chmod 644 /root/xfree-toolbox/diagnostics/lib/dns-check.sh \
  /root/xfree-toolbox/diagnostics/lib/traffic-path.sh \
  /www/luci-static/resources/xfree-toolbox/traffic-map.js \
  /www/luci-static/resources/xfree-toolbox/xfree-dashboard.css \
  /www/luci-static/resources/view/xfree-toolbox/shell.js
grep -n "checkHosts\|v=20261004n\|dns_check_section_hosts" \
  /www/luci-static/resources/view/xfree-toolbox/shell.js \
  /www/luci-static/resources/xfree-toolbox/traffic-map.js \
  /root/xfree-toolbox/diagnostics/lib/dns-check.sh \
  /root/xfree-toolbox/diagnostics/lib/traffic-path.sh | head -20
# Quick RPC shape check if log present
if [ -f /etc/xfree-toolbox/system/dns-check.log ]; then
  sh /root/xfree-toolbox/diagnostics/traffic-path.sh summary 2>/dev/null \
    | tr ',' '\n' | grep -E 'checkHosts|checkSummary|checkFail' | head -20 || true
fi
REMOTE
