#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
BASE=build/openwrt/luci-app-xfree-toolbox/htdocs/luci-static/resources
scp "${SCP_OPTS[@]}" \
  iface-routing/luci-rpc.sh \
  "$SSH_TARGET:$TB/iface-routing/luci-rpc.sh"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/luci-routes.js" \
  "$BASE/xfree-toolbox/luci-ui.js" \
  "$BASE/xfree-toolbox/vpn-panel.js" \
  "$BASE/xfree-toolbox/xfree-dashboard.css" \
  "$SSH_TARGET:/www/luci-static/resources/xfree-toolbox/"
scp "${SCP_OPTS[@]}" \
  "$BASE/view/xfree-toolbox/shell.js" \
  "$SSH_TARGET:/www/luci-static/resources/view/xfree-toolbox/shell.js"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
chmod +x /root/xfree-toolbox/iface-routing/luci-rpc.sh
chmod 644 /www/luci-static/resources/xfree-toolbox/luci-routes.js \
  /www/luci-static/resources/xfree-toolbox/luci-ui.js \
  /www/luci-static/resources/xfree-toolbox/vpn-panel.js \
  /www/luci-static/resources/xfree-toolbox/xfree-dashboard.css \
  /www/luci-static/resources/view/xfree-toolbox/shell.js
/etc/init.d/rpcd reload 2>/dev/null || true
VER=/usr/share/ucode/luci/version.uc
BUST=$(date +%s)
if grep -q "xfreebust" "$VER" 2>/dev/null; then
  sed -i "s/xfreebust[0-9]*/xfreebust${BUST}/" "$VER"
else
  sed -i "s/export const revision = '\\([^']*\\)'/export const revision = '\\1-xfreebust${BUST}'/" "$VER"
fi
rm -f /tmp/luci-indexcache* 2>/dev/null || true
rm -rf /tmp/luci-modulecache 2>/dev/null || true
/etc/init.d/uhttpd reload 2>/dev/null || /etc/init.d/uhttpd restart || true
echo '=== summary sample ==='
ubus call xfree-toolbox ifaceMenu '{"action":"summary","arg":""}' 2>&1 | head -c 2200
echo
echo '=== markers ==='
grep -n "health=\|CONF=\|_pickSelect\|v=20261005f\|xfree-vpn-kv" \
  /root/xfree-toolbox/iface-routing/luci-rpc.sh \
  /www/luci-static/resources/xfree-toolbox/vpn-panel.js \
  /www/luci-static/resources/view/xfree-toolbox/shell.js \
  /www/luci-static/resources/xfree-toolbox/xfree-dashboard.css 2>/dev/null | head -40
REMOTE
