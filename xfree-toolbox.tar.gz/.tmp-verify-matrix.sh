#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"

ssh "${SSH_OPTS[@]}" "$SSH_TARGET" 'sh -s' <<'REMOTE'
set -eu
TB=/root/xfree-toolbox
export ROOT_DIR="$TB"
. "$TB/lib/common.sh"
. "$TB/lib/upstreams.sh"
. "$TB/lib/selection/upstream-selection.sh"
selection_upstream_init_all "$TB"

_cat=$(selection_catalog_prepare "$TB")
selection_zapret_disable_flags 2>/dev/null || true

_cols=$(mktemp); _present=$(mktemp); _checked=$(mktemp); _tmp=$(mktemp)
: > "$_cols"; : > "$_present"
selection_iface_list_scope_ids > "$_tmp" 2>/dev/null || :
while IFS= read -r id || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope iface "$id" "$id" all "$_cols" "$_present"
done < "$_tmp"
: > "$_tmp"
dns_routing_list_instances_tsv > "$_tmp" 2>/dev/null || true
while IFS='|' read -r idx id host t u || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope dns "$id" "${host:-$id}" fqdn_only "$_cols" "$_present"
done < "$_tmp"
: > "$_tmp"
for d in "$SELECTION_ZAPRET_SECTIONS"/*; do
  [ -d "$d" ] || continue
  printf '%s\n' "$(basename "$d")" >> "$_tmp"
done
while IFS= read -r id || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope zapret "$id" "$id" all "$_cols" "$_present"
done < "$_tmp"

selection_matrix_resolve_checked "$_cat/files.tsv" "$_cols" "$_present" "$_checked" \
  "${SELECTION_ZAPRET_DV4:-0}" "${SELECTION_ZAPRET_DV6:-0}"

fail=0
cmp_one() {
  target="$1"; scope="$2"; mode="$3"; fqdn="$4"; pfx="$5"
  key="${target}:${scope}"
  dv4=0; dv6=0
  if [ "$target" = zapret ]; then
    dv4="${SELECTION_ZAPRET_DV4:-0}"
    dv6="${SELECTION_ZAPRET_DV6:-0}"
  fi
  exp=$(mktemp); got=$(mktemp)
  upstreams_build_enabled_tags_tsv "$target" "$_cat/files.tsv" "$fqdn" "$pfx" "$mode" \
    "$dv4" "$dv6" | sort -u > "$exp"
  awk -F'|' -v k="$key" '$1==k{print $2}' "$_checked" | sort -u > "$got"
  if ! cmp -s "$exp" "$got"; then
    echo "FAIL $key"
    echo "  only_exp:"; comm -23 "$exp" "$got" | head -5
    echo "  only_got:"; comm -13 "$exp" "$got" | head -5
    fail=$((fail+1))
  else
    echo "OK $key n=$(wc -l < "$got")"
  fi
  rm -f "$exp" "$got"
}

selection_iface_list_scope_ids > "$_tmp" 2>/dev/null || :
while IFS= read -r id || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  cmp_one iface "$id" all \
    "$SELECTION_INTERFACES_DIR/$id/fqdn.d" \
    "$SELECTION_INTERFACES_DIR/$id/prefixes.d"
done < "$_tmp"

: > "$_tmp"
dns_routing_list_instances_tsv > "$_tmp" 2>/dev/null || true
n=0
while IFS='|' read -r idx id host t u || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  n=$((n+1))
  [ "$n" -le 3 ] || continue
  cmp_one dns "$id" fqdn_only "$SELECTION_DNS_DIR/$id/fqdn.d" ""
done < "$_tmp"

for id in cust1 youtube_1 discord cdn-host udp-dns; do
  [ -d "$SELECTION_ZAPRET_SECTIONS/$id" ] || continue
  cmp_one zapret "$id" all \
    "$SELECTION_ZAPRET_SECTIONS/$id/fqdn.d" \
    "$SELECTION_ZAPRET_SECTIONS/$id/prefixes.d"
done

start=$(cut -d' ' -f1 /proc/uptime)
selection_upstream_json_matrix >/tmp/mx-out.json
end=$(cut -d' ' -f1 /proc/uptime)
bytes=$(wc -c < /tmp/mx-out.json)
awk -v s="$start" -v e="$end" -v b="$bytes" 'BEGIN{printf "matrix_fn=%.3fs bytes=%d\n", e-s, b}'

rm -f "$_cols" "$_present" "$_checked" "$_tmp"
echo "fails=$fail"
[ "$fail" -eq 0 ]
REMOTE
