#!/bin/sh
# Bust LuCI require.js cache after SCP of static assets (bluehome).
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
. ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"

# Append unique suffix to luciversion so ?v= changes for all modules.
# Keep original revision prefix; only touch a local override marker.
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
VER=/usr/share/ucode/luci/version.uc
BUST=$(date +%s)
# Replace trailing quote of revision export with -xfreeBust
if grep -q "xfreebust" "$VER" 2>/dev/null; then
  sed -i "s/xfreebust[0-9]*/xfreebust${BUST}/" "$VER"
else
  sed -i "s/export const revision = '\\([^']*\\)'/export const revision = '\\1-xfreebust${BUST}'/" "$VER"
fi
rm -f /tmp/luci-indexcache* 2>/dev/null || true
rm -rf /tmp/luci-modulecache 2>/dev/null || true
/etc/init.d/uhttpd reload 2>/dev/null || /etc/init.d/uhttpd restart || true
echo "version.uc:"
cat "$VER"
echo "sample v=:"
wget -qO- http://127.0.0.1/cgi-bin/luci/admin/services/xfree-toolbox 2>/dev/null | grep -oE 'v=[^"'\'' ]+' | sort -u | head
REMOTE
