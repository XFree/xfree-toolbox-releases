#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
DEST=/www/luci-static/resources
BASE=build/openwrt/luci-app-xfree-toolbox/htdocs/luci-static/resources
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
scp "${SCP_OPTS[@]}" \
  "$BASE/view/xfree-toolbox/shell.js" \
  "$SSH_TARGET:$DEST/view/xfree-toolbox/shell.js"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/traffic-map.js" \
  "$SSH_TARGET:$DEST/xfree-toolbox/traffic-map.js"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/overview-panel.js" \
  "$SSH_TARGET:$DEST/xfree-toolbox/overview-panel.js"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/luci-ui.js" \
  "$SSH_TARGET:$DEST/xfree-toolbox/luci-ui.js"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/xfree-dashboard.css" \
  "$SSH_TARGET:$DEST/xfree-toolbox/xfree-dashboard.css"
scp "${SCP_OPTS[@]}" \
  diagnostics/lib/traffic-path.sh \
  diagnostics/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/"
# traffic-path.sh goes to diagnostics/; lib needs lib/
scp "${SCP_OPTS[@]}" \
  diagnostics/lib/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/lib/traffic-path.sh"
scp "${SCP_OPTS[@]}" \
  diagnostics/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/traffic-path.sh"
scp "${SCP_OPTS[@]}" \
  build/openwrt/xfree-toolbox/files/usr/libexec/rpcd/xfree-toolbox \
  "$SSH_TARGET:/usr/libexec/rpcd/xfree-toolbox"
scp "${SCP_OPTS[@]}" \
  iface-routing/vpn/lib/proton-guest-renew.sh \
  "$SSH_TARGET:$TB/iface-routing/vpn/lib/proton-guest-renew.sh" 2>/dev/null || true
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
chmod +x /usr/libexec/rpcd/xfree-toolbox /root/xfree-toolbox/diagnostics/traffic-path.sh
rm -f /tmp/luci-indexcache* 2>/dev/null || true
rm -rf /tmp/luci-modulecache 2>/dev/null || true
/etc/init.d/rpcd reload
/etc/init.d/uhttpd reload 2>/dev/null || true
echo '--- suggest youtube ---'
ubus call xfree-toolbox trafficPath '{"action":"suggest","fqdn":"youtu","limit":"8"}' 2>&1 | head -c 800
echo
echo '--- markers ---'
grep -nE 'suggest|_ensureSuggest|_closeFloatPopover|disconnectedCallback|20261004e' \
  /www/luci-static/resources/xfree-toolbox/traffic-map.js \
  /www/luci-static/resources/view/xfree-toolbox/shell.js \
  /usr/libexec/rpcd/xfree-toolbox \
  /root/xfree-toolbox/diagnostics/traffic-path.sh | head -40
REMOTE
