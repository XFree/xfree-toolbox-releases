#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE' || true
set +e
echo "=== query via specific resolvers ==="
for q in account.protonvpn.com protonvpn.com proton.me api.protonvpn.ch; do
  echo "--- $q @127.0.0.1 ---"
  nslookup "$q" 127.0.0.1 2>&1 | head -12
  echo "--- $q @8.8.8.8 ---"
  nslookup "$q" 8.8.8.8 2>&1 | head -12
  echo "--- $q @1.1.1.1 ---"
  nslookup "$q" 1.1.1.1 2>&1 | head -12
  echo "--- $q @77.88.8.8 ---"
  nslookup "$q" 77.88.8.8 2>&1 | head -12
done
echo "=== dnsmasq conf snippets mentioning proton ==="
grep -RniE 'proton|account\.proton' /etc/dnsmasq.conf /var/etc/dnsmasq.conf* /etc/dnsmasq.d 2>/dev/null | head -80
echo "=== xfree dns-routing confdir listing ==="
ls -la /etc/dnsmasq.d/xfree-toolbox-routing 2>/dev/null | head -40
grep -RniE 'proton|server=|address=|nftset=' /etc/dnsmasq.d/xfree-toolbox-routing 2>/dev/null | head -100
echo "=== hosts / nft dns redirects sample ==="
grep -RniE 'proton' /etc/hosts /tmp/hosts 2>/dev/null | head -20
echo "=== dig via DoH proxies (tcp dig if any) ==="
command -v dig
for port in 5054 5055 5056 5057 5058 5059 5060 5061 5062; do
  echo "--- account.protonvpn.com @127.0.0.1#$port ---"
  nslookup account.protonvpn.com 127.0.0.1#$port 2>&1 | head -10
done
echo "=== which dhcp.server lines are active ==="
uci show dhcp.@dnsmasq[0].server 2>/dev/null
echo "=== nft/dns redirect related ==="
nft list ruleset 2>/dev/null | grep -iE 'dns|53|redirect' | head -40
echo "=== done2 ==="
REMOTE
