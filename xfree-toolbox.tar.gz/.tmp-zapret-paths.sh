#!/bin/sh
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
. ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
. /root/xfree-toolbox/lib/common.sh 2>/dev/null || true
# show what traffic-path resolves
sh -c '
  ROOT_DIR=/root/xfree-toolbox
  . "$ROOT_DIR/diagnostics/lib/traffic-path.sh"
  traffic_path_init_paths
  echo STATE_ROOT=$STATE_ROOT
  echo ZAPRET_ROOT=$ZAPRET_ROOT
  echo TRAFFIC_PATH_ZAPRET_SECTIONS=$TRAFFIC_PATH_ZAPRET_SECTIONS
  echo DNS_MAP=$TRAFFIC_PATH_DNS_MAP
  ls -la "$TRAFFIC_PATH_ZAPRET_SECTIONS" 2>&1 | head -40
  echo ---
  ls "$TRAFFIC_PATH_ZAPRET_SECTIONS" 2>/dev/null
'
echo === find googlevideo ===
find /root/xfree-toolbox /opt/zapret -type d -name googlevideo 2>/dev/null | head
find /root/xfree-toolbox /opt/zapret -name '*googlevideo*' 2>/dev/null | head -20
REMOTE
