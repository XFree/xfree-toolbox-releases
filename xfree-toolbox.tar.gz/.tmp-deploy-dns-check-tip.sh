#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
BASE=build/openwrt/luci-app-xfree-toolbox/htdocs/luci-static/resources
scp "${SCP_OPTS[@]}" \
  diagnostics/lib/dns-check.sh \
  "$SSH_TARGET:$TB/diagnostics/lib/dns-check.sh"
scp "${SCP_OPTS[@]}" \
  diagnostics/lib/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/lib/traffic-path.sh"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/traffic-map.js" \
  "$SSH_TARGET:/www/luci-static/resources/xfree-toolbox/traffic-map.js"
scp "${SCP_OPTS[@]}" \
  "$BASE/view/xfree-toolbox/shell.js" \
  "$SSH_TARGET:/www/luci-static/resources/view/xfree-toolbox/shell.js"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
chmod +x /root/xfree-toolbox/diagnostics/lib/dns-check.sh /root/xfree-toolbox/diagnostics/lib/traffic-path.sh
chmod 644 /www/luci-static/resources/xfree-toolbox/traffic-map.js \
  /www/luci-static/resources/view/xfree-toolbox/shell.js
echo '=== sample runtime for cloudflare-dns-no-doh ==='
/root/xfree-toolbox/diagnostics/traffic-path.sh summary | tr '}' '\n' | grep -A1 'dns:cloudflare-dns-no-doh' | head -5
echo '=== yandex / common.dot ==='
/root/xfree-toolbox/diagnostics/traffic-path.sh summary | tr '}' '\n' | grep -E 'checkSummary|dns:common|dns:cloudflare-dns-no-doh' | head -20
grep -n 'v=20261004k\|checkSummary\|dnsCheckHealth' \
  /www/luci-static/resources/view/xfree-toolbox/shell.js \
  /www/luci-static/resources/xfree-toolbox/traffic-map.js | head -20
REMOTE
