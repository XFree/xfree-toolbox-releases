#!/usr/bin/env python3
import sys
from pathlib import Path

sys.path.insert(
    0,
    str(Path(__file__).resolve().parent / "build/openwrt/luci-app-xfree-toolbox/tests/playwright"),
)
from playwright.sync_api import sync_playwright
from test_dashboard_smoke import luci_login, resolve_config

base, user, password = resolve_config("bluehome")
with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": 1280, "height": 900})
    luci_login(page, base, user, password)
    page.goto(
        f"{base}/cgi-bin/luci/admin/services/xfree-toolbox",
        wait_until="networkidle",
        timeout=45000,
    )
    page.wait_for_selector(".tm-breadcrumb", timeout=15000)
    idle = page.evaluate(
        """() => {
        const h = document.querySelector('.tm-head');
        const bc = document.querySelector('.tm-breadcrumb');
        const muted = [...document.querySelectorAll('.tm-head .muted')].map(e => e.textContent);
        return {
          cls: bc.className,
          text: bc.textContent.replace(/\\s+/g, ' ').trim(),
          muted,
          order: [...h.children].map(e => e.tagName + '.' + ((e.className || '').split(' ')[0] || ''))
        };
      }"""
    )
    print("idle", idle)
    page.fill(".tm-trace-input", "discord.com")
    page.locator(".tm-trace-btn").click()
    page.wait_for_function(
        "() => !!document.querySelector('.tm-breadcrumb.is-active')", timeout=25000
    )
    print(
        "active",
        page.evaluate(
            "() => document.querySelector('.tm-breadcrumb').textContent.replace(/\\s+/g,' ').trim()"
        ),
    )
    browser.close()
