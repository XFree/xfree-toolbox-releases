#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"

ssh "${SSH_OPTS[@]}" "$SSH_TARGET" 'sh -s' <<'REMOTE'
set -eu
TB=/root/xfree-toolbox
export ROOT_DIR="$TB"
. "$TB/lib/common.sh"
. "$TB/lib/upstreams.sh"
. "$TB/lib/selection/upstream-selection.sh"
selection_upstream_init_all "$TB"

now() { date +%s%N; }
ms() { awk -v a="$1" -v b="$2" 'BEGIN{printf "%d", (b-a)/1000000}'; }

t0=$(now)
_cat=$(selection_catalog_prepare "$TB")
t1=$(now)
echo "catalog_prepare: $(ms "$t0" "$t1") ms dir=$_cat"
echo "files=$(wc -l < "$_cat/files.tsv") entities=$(wc -l < "$_cat/entities.tsv")"

_cols=$(mktemp); _present=$(mktemp); _checked=$(mktemp); _tmp=$(mktemp)
: > "$_cols"; : > "$_present"

t0=$(now)
selection_iface_list_scope_ids > "$_tmp" 2>/dev/null || :
while IFS= read -r id || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope iface "$id" "$id" all "$_cols" "$_present"
done < "$_tmp"
t1=$(now)
echo "iface register: $(ms "$t0" "$t1") ms cols=$(wc -l < "$_cols") present=$(wc -l < "$_present")"

t0=$(now)
: > "$_tmp"
if command -v dns_routing_list_instances_tsv >/dev/null 2>&1; then
  dns_routing_list_instances_tsv > "$_tmp" 2>/dev/null || true
fi
while IFS='|' read -r idx id host t u || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope dns "$id" "${host:-$id}" fqdn_only "$_cols" "$_present"
done < "$_tmp"
t1=$(now)
echo "dns register: $(ms "$t0" "$t1") ms cols=$(wc -l < "$_cols") present=$(wc -l < "$_present")"

t0=$(now)
: > "$_tmp"
if [ -d "${SELECTION_ZAPRET_SECTIONS:-}" ]; then
  for d in "$SELECTION_ZAPRET_SECTIONS"/*; do
    [ -d "$d" ] || continue
    id=$(basename "$d")
    if selection_zapret_section_on_p "$d/config/section.conf"; then lab="[ON] $id"; else lab="[OFF] $id"; fi
    printf '%s\t%s\n' "$id" "$lab" >> "$_tmp"
  done
fi
while IFS="$(printf '\t')" read -r id lab || [ -n "${id:-}" ]; do
  [ -n "${id:-}" ] || continue
  selection_matrix_register_scope zapret "$id" "$lab" all "$_cols" "$_present"
done < "$_tmp"
t1=$(now)
echo "zapret register: $(ms "$t0" "$t1") ms cols=$(wc -l < "$_cols") present=$(wc -l < "$_present")"

selection_zapret_disable_flags 2>/dev/null || true
t0=$(now)
selection_matrix_resolve_checked "$_cat/files.tsv" "$_cols" "$_present" "$_checked" \
  "${SELECTION_ZAPRET_DV4:-0}" "${SELECTION_ZAPRET_DV6:-0}"
t1=$(now)
echo "resolve_checked: $(ms "$t0" "$t1") ms checked=$(wc -l < "$_checked")"

t0=$(now)
selection_json_emit_matrix "$_cat/entities.tsv" "$_cols" "$_checked" > /tmp/xfree-matrix-profile.json
t1=$(now)
echo "emit_matrix: $(ms "$t0" "$t1") ms bytes=$(wc -c < /tmp/xfree-matrix-profile.json)"

t0=$(now)
ubus call xfree-toolbox upstreamSelection '{"action":"matrix","target":"-","scope":"-","mode":"-","tags_json":""}' > /tmp/xfree-matrix-ubus.json
t1=$(now)
echo "full ubus: $(ms "$t0" "$t1") ms bytes=$(wc -c < /tmp/xfree-matrix-ubus.json)"

echo "--- columns ---"
awk -F'|' '{print $1}' "$_cols"
rm -f "$_cols" "$_present" "$_checked" "$_tmp"
REMOTE
