#!/usr/bin/env python3
import sys
import time
from pathlib import Path

sys.path.insert(
    0,
    str(Path(__file__).resolve().parent / "build/openwrt/luci-app-xfree-toolbox/tests/playwright"),
)
from playwright.sync_api import sync_playwright
from test_dashboard_smoke import luci_login, resolve_config

base, user, password = resolve_config("bluehome")

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page()
    luci_login(page, base, user, password)
    page.goto(
        f"{base}/cgi-bin/luci/admin/services/xfree-toolbox",
        wait_until="networkidle",
        timeout=45000,
    )
    page.wait_for_selector(".tm-trace-input", timeout=15000)

    page.evaluate(
        """() => {
        window.__tm = { paints: 0, inputs: 0, vals: [], maps: 0 };
        const wrap = (el, name) => {
          if (!el || !el.requestPaint) return;
          const orig = el.requestPaint.bind(el);
          el.requestPaint = function () {
            window.__tm.paints++;
            const v = (document.querySelector('.tm-trace-input') || {}).value || '';
            window.__tm.vals.push(name + ':' + v);
            return orig();
          };
        };
        wrap(document.querySelector('xfree-traffic-map'), 'map');
        wrap(document.querySelector('xfree-overview'), 'ov');
        const inp = document.querySelector('.tm-trace-input');
        inp.addEventListener('input', (e) => {
          window.__tm.inputs++;
          window.__tm.vals.push('dominput:' + e.target.value);
        });
        const ov = document.querySelector('xfree-overview');
        const mo = new MutationObserver(() => {
          window.__tm.maps = document.querySelectorAll('xfree-traffic-map').length;
          window.__tm.vals.push('mut:' + ((document.querySelector('.tm-trace-input')||{}).value||''));
        });
        if (ov) mo.observe(ov, { childList: true, subtree: true });
      }"""
    )

    page.click(".tm-trace-input")
    page.keyboard.type("abc", delay=80)
    time.sleep(0.4)
    print("after type", page.evaluate("() => ({ val: document.querySelector('.tm-trace-input').value, tm: window.__tm })"))

    page.evaluate(
        """() => {
        const inp = document.querySelector('.tm-trace-input');
        inp.focus();
        inp.value = 'typed.net';
        inp.dispatchEvent(new Event('input', { bubbles: true }));
      }"""
    )
    time.sleep(0.2)
    print(
        "after dispatch",
        page.evaluate(
            "() => ({ val: document.querySelector('.tm-trace-input').value, tm: window.__tm })"
        ),
    )

    # Check LuCI handler attributes
    print(
        "attrs",
        page.evaluate(
            """() => {
        const inp = document.querySelector('.tm-trace-input');
        return {
          oninput: typeof inp.oninput,
          onkeydown: typeof inp.onkeydown,
          listeners: !!inp._listeners,
          outer: inp.outerHTML
        };
      }"""
        ),
    )
    browser.close()
