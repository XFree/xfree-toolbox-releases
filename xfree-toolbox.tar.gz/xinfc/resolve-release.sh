#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
XINFC_SCRIPT_DIR="$SCRIPT_DIR"

PKGMGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
[ -f "$PKGMGR_SH" ] || {
  echo "[!] Не найден pkgmgr.sh: $PKGMGR_SH" >&2
  exit 1
}
. "$PKGMGR_SH"
# shellcheck source=xinfc/lib/board.sh
. "$SCRIPT_DIR/lib/board.sh"

REPO_OWNER="Caian"
REPO_NAME="xinfc"
RELEASES_URL="https://github.com/${REPO_OWNER}/${REPO_NAME}/releases"
MODE="url"

while [ "$#" -gt 0 ]; do
  case "$1" in
    --url) MODE="url" ;;
    --summary) MODE="summary" ;;
    --emit-shell) MODE="emit-shell" ;;
    -h|--help)
      cat <<'EOF'
Использование:
  resolve-release.sh [--url|--summary|--emit-shell]

Определяет URL последнего tarball xinfc для текущей платы (см. xinfc/boards.tsv).
EOF
      exit 0
      ;;
    *) echo "[!] Неизвестный аргумент: $1" >&2; exit 1 ;;
  esac
  shift
done

resolve_release() {
  if ! xinfc_board_supported; then
    die "Плата не поддерживается для xinfc NFC: $(xinfc_board_name) (нет записи в xinfc/boards.tsv)"
  fi

  SLUG="$(xinfc_board_release_slug)"
  [ -n "$SLUG" ] || die "Не задан release_slug для платы $(xinfc_board_name)"

  ASSET_SUFFIX="openwrt_${SLUG}.tar.gz"

  # Match any release tag (v2024-01-29, v1.2, …) and asset name with version infix.
  xinfc_find_asset_line() {
    printf '%s' "$1" \
      | tr '"' '\n' \
      | grep 'releases/download/' \
      | grep "${ASSET_SUFFIX}\$" \
      | head -n1
  }

  REL_LINE=""
  API_URL="https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/releases"
  if _api="$(http_fetch_text "$API_URL" 2>/dev/null || true)" && [ -n "${_api:-}" ]; then
    REL_LINE="$(xinfc_find_asset_line "$_api" || true)"
  fi
  if [ -z "${REL_LINE:-}" ]; then
    HTML="$(http_fetch_text "$RELEASES_URL")"
    [ -n "${HTML:-}" ] || die "Не удалось получить релизы $RELEASES_URL (и API $API_URL)"
    REL_LINE="$(xinfc_find_asset_line "$HTML" || true)"
  fi

  [ -n "${REL_LINE:-}" ] || die "Не найден архив xinfc_*_${ASSET_SUFFIX} на GitHub releases"

  case "$REL_LINE" in
    http://*|https://*) XINFC_URL="$REL_LINE" ;;
    /*) XINFC_URL="https://github.com${REL_LINE}" ;;
    *) die "Некорректная ссылка на релиз: $REL_LINE" ;;
  esac

  XINFC_ARCHIVE="$(basename "$XINFC_URL")"
  XINFC_TAG="$(printf '%s' "$XINFC_URL" | sed -n 's#.*/releases/download/\([^/]*\)/.*#\1#p')"
  [ -n "${XINFC_TAG:-}" ] || die "Не удалось извлечь тег релиза из $XINFC_URL"
  XINFC_VERSION="${XINFC_TAG#v}"

  case "$MODE" in
    url) printf '%s\n' "$XINFC_URL" ;;
    summary)
      printf '[*] Board        : %s\n' "$(xinfc_board_name)"
      printf '[*] Release slug : %s\n' "$SLUG"
      printf '[*] Tag          : %s\n' "$XINFC_TAG"
      printf '[*] Archive      : %s\n' "$XINFC_ARCHIVE"
      printf '[*] URL          : %s\n' "$XINFC_URL"
      ;;
    emit-shell)
      cat <<EOF
XINFC_BOARD='$(xinfc_board_name)'
XINFC_RELEASE_SLUG='${SLUG}'
XINFC_TAG='${XINFC_TAG}'
XINFC_VERSION='${XINFC_VERSION}'
XINFC_ARCHIVE='${XINFC_ARCHIVE}'
XINFC_URL='${XINFC_URL}'
EOF
      ;;
  esac
}

resolve_release
