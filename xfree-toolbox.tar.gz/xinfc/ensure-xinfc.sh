#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
XINFC_SCRIPT_DIR="$SCRIPT_DIR"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"
# shellcheck source=xinfc/lib/board.sh
. "$SCRIPT_DIR/lib/board.sh"
# shellcheck source=xinfc/lib/install-state.sh
. "$SCRIPT_DIR/lib/install-state.sh"

XINFC_INSTALL_SCRIPT="${XINFC_INSTALL_SCRIPT:-$SCRIPT_DIR/install.sh}"
INSTALL_IF_MISSING=0

usage() {
  cat <<EOF
Usage: $0 [--install-if-missing]

Проверяет зависимости и наличие xinfc-wsc; при --install-if-missing ставит из GitHub.

Options:
  --install-if-missing   Установить xinfc-wsc, если бинарник отсутствует
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --install-if-missing) INSTALL_IF_MISSING=1 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный аргумент: $1" ;;
  esac
  shift
done

xinfc_ensure_runtime_deps() {
  if ! xinfc_board_supported; then
    die "Плата не поддерживается для xinfc NFC: $(xinfc_board_name)"
  fi

  pm_print
  pm_update_index_optional

  if ! command -v i2cdetect >/dev/null 2>&1; then
    info "Устанавливаю i2c-tools..."
    pm_install i2c-tools || die "Не удалось установить i2c-tools"
  fi

  if ! command -v i2cdetect >/dev/null 2>&1; then
    die "i2c-tools установлен, но i2cdetect недоступен"
  fi

  if [ ! -e "/dev/i2c-$(xinfc_board_i2c_bus)" ] && [ ! -e "/dev/i2c-$(xinfc_board_i2c_bus | sed 's/^0*//')" ]; then
    warn "Устройство I2C bus $(xinfc_board_i2c_bus) не найдено в /dev — запись NFC может не сработать"
  fi

  _lib_ok=0
  if [ -f /usr/lib/libstdc++.so.6 ] || [ -f /lib/libstdc++.so.6 ]; then
    _lib_ok=1
  fi
  if [ "$_lib_ok" = "0" ]; then
    info "Устанавливаю libstdcpp (для xinfc-wsc)..."
    pm_install libstdcpp6 2>/dev/null || pm_install libstdcpp 2>/dev/null \
      || pm_install libstdc++6 2>/dev/null \
      || warn "Не удалось установить libstdcpp — xinfc-wsc может не запуститься"
  fi
}

run_xinfc_install() {
  reason="$1"
  [ -f "$XINFC_INSTALL_SCRIPT" ] || die "Не найден install script: $XINFC_INSTALL_SCRIPT"
  info "$reason"
  sh "$XINFC_INSTALL_SCRIPT" --yes
  xinfc_core_installed || die "xinfc-wsc не появился после установки (ожидался $XINFC_BIN)"
}

xinfc_ensure_runtime_deps

if xinfc_core_installed; then
  xinfc_install_state_summary || true
  success "xinfc готов"
  exit 0
fi

xinfc_install_state_summary || true
warn "xinfc-wsc не установлен"

if [ "$INSTALL_IF_MISSING" != "1" ]; then
  exit 1
fi

http_need_tools
run_xinfc_install "xinfc-wsc отсутствует, запускаю установку"
new_ver="$(xinfc_get_installed_version 2>/dev/null || true)"
[ -n "$new_ver" ] && success "xinfc установлен (${new_ver})" || success "xinfc установлен"
exit 0
