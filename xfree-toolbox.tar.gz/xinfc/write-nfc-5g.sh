#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
XINFC_SCRIPT_DIR="$SCRIPT_DIR"

. "$ROOT_DIR/lib/common.sh"
# shellcheck source=xinfc/lib/board.sh
. "$SCRIPT_DIR/lib/board.sh"
# shellcheck source=xinfc/lib/install-state.sh
. "$SCRIPT_DIR/lib/install-state.sh"
# shellcheck source=xinfc/lib/wireless-5g-ap.sh
. "$SCRIPT_DIR/lib/wireless-5g-ap.sh"

YES=0

usage() {
  cat <<'EOF'
Использование:
  write-nfc-5g.sh [--yes]

Записывает в NFC-метку параметры 5 GHz AP из UCI wireless (mode=ap на radio 5g).
Перед записью вызывает ensure-xinfc.sh --install-if-missing.
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1; export YES=1 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный аргумент: $1" ;;
  esac
  shift
done

main() {
  if ! xinfc_board_supported; then
    die "Запись NFC недоступна на этой плате: $(xinfc_board_name) (см. xinfc/boards.tsv)"
  fi

  sh "$SCRIPT_DIR/ensure-xinfc.sh" --install-if-missing

  _cred_file="$(mktemp /tmp/xinfc-ap-cred.XXXXXX)"
  trap 'rm -f "$_cred_file" 2>/dev/null || true' EXIT INT TERM
  if ! xinfc_wireless_ap_credentials >"$_cred_file" 2>/dev/null; then
    die "Не найден Wi‑Fi AP на 5 GHz в /etc/config/wireless (wifi-iface mode=ap на radio 5g)"
  fi

  _iface="$(sed -n '1p' "$_cred_file")"
  _ssid="$(sed -n '2p' "$_cred_file")"
  _key="$(sed -n '3p' "$_cred_file")"
  _enc="$(sed -n '4p' "$_cred_file")"
  _disabled="$(sed -n '5p' "$_cred_file")"

  _wsc_enc="$(xinfc_map_encryption_for_wsc "$_enc" 2>/dev/null || true)"
  [ -n "$_wsc_enc" ] || die "Шифрование wireless.$_iface.encryption=$_enc не поддерживается xinfc-wsc"

  _ssid_len="$(printf '%s' "$_ssid" | wc -c | tr -d ' ')"
  _key_len="$(printf '%s' "$_key" | wc -c | tr -d ' ')"
  [ "$_ssid_len" -ge 2 ] && [ "$_ssid_len" -le 28 ] || die "SSID должен быть 2–28 символов (сейчас $_ssid_len)"
  [ "$_key_len" -ge 8 ] && [ "$_key_len" -le 63 ] || die "Пароль Wi‑Fi должен быть 8–63 символа (сейчас $_key_len)"

  _bus="$(xinfc_board_i2c_bus)"
  _addr="$(xinfc_board_i2c_addr)"

  info "Плата:     $(xinfc_board_name)"
  info "I2C:       bus=$_bus addr=$_addr"
  info "UCI:       wireless.$_iface"
  info "SSID:      $_ssid"
  info "Encryption: $_enc → $_wsc_enc"
  if [ "$_disabled" = "1" ]; then
    warn "Точка доступа wireless.$_iface отключена (disabled=1) — в метку всё равно пишутся сохранённые SSID/пароль"
  fi

  if [ "$YES" != "1" ]; then
    confirm_or_exit "Записать эти параметры Wi‑Fi в NFC-метку?"
  fi

  info "Запись NFC..."
  if "$XINFC_BIN" "$_bus" "$_addr" "$_ssid" "$_key" "$_wsc_enc"; then
    success "NFC-метка записана (5 GHz AP: $_ssid)"
    exit 0
  fi

  die "xinfc-wsc завершился с ошибкой"
}

main "$@"
