#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
XINFC_SCRIPT_DIR="$SCRIPT_DIR"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"
# shellcheck source=xinfc/lib/install-state.sh
. "$SCRIPT_DIR/lib/install-state.sh"

RESOLVER_SH="$SCRIPT_DIR/resolve-release.sh"
YES=0
KEEP=0

usage() {
  cat <<'EOF'
Использование:
  install.sh [--yes] [--keep]

Скачивает последний релиз Caian/xinfc для платы и устанавливает xinfc-wsc в /usr/bin.
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --keep) KEEP=1 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный аргумент: $1" ;;
  esac
  shift
done

main() {
  pm_print
  http_need_tools
  http_print
  confirm_or_exit "Скачать и установить xinfc-wsc из последнего релиза GitHub?"

  TMP_ENV="$(mktemp)"
  WORKDIR=""
  trap 'rm -f "$TMP_ENV" >/dev/null 2>&1 || true; [ "$KEEP" -eq 1 ] || [ -z "$WORKDIR" ] || rm -rf "$WORKDIR" >/dev/null 2>&1 || true' EXIT INT TERM

  sh "$RESOLVER_SH" --emit-shell >"$TMP_ENV"
  # shellcheck disable=SC1090
  . "$TMP_ENV"

  : "${XINFC_URL:?}"
  : "${XINFC_ARCHIVE:?}"
  : "${XINFC_TAG:?}"

  WORKDIR="$(mktemp -d /tmp/xinfc-inst.XXXXXX)"
  TARFILE="$WORKDIR/$XINFC_ARCHIVE"

  info "Тег релиза:  $XINFC_TAG"
  info "Архив:       $XINFC_ARCHIVE"
  info "URL:         $XINFC_URL"

  http_download_file "$XINFC_URL" "$TARFILE"

  info "Распаковка tarball..."
  ( cd "$WORKDIR" && tar -xzf "$TARFILE" )

  BIN_SRC=""
  for candidate in "$WORKDIR"/xinfc/xinfc-wsc "$WORKDIR"/xinfc-wsc; do
    [ -f "$candidate" ] || continue
    BIN_SRC="$candidate"
    break
  done
  [ -n "$BIN_SRC" ] || die "В архиве не найден xinfc-wsc"

  info "Установка: $XINFC_BIN"
  install -m 0755 "$BIN_SRC" "$XINFC_BIN"

  xinfc_core_installed || die "xinfc-wsc не запускается после установки"
  _ver="$(xinfc_get_installed_version 2>/dev/null || true)"
  if [ -n "$_ver" ]; then
    success "xinfc-wsc установлен (version $_ver)"
  else
    success "xinfc-wsc установлен"
  fi
}

main "$@"
