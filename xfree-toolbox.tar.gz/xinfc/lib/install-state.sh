#!/bin/sh
# shellcheck shell=sh

XINFC_BIN="${XINFC_BIN:-/usr/bin/xinfc-wsc}"

xinfc_core_installed() {
  [ -x "$XINFC_BIN" ] || return 1
  "$XINFC_BIN" 2>&1 | grep -q 'xinfc' || return 1
  return 0
}

xinfc_get_installed_version() {
  if ! xinfc_core_installed; then
    return 1
  fi
  _ver="$("$XINFC_BIN" 2>&1 | sed -n 's/.*xinfc version \([^ )]*\).*/\1/p' | head -n1)"
  [ -n "$_ver" ] || _ver="$("$XINFC_BIN" 2>&1 | sed -n 's/.*version \([0-9][0-9-]*\).*/\1/p' | head -n1)"
  [ -n "$_ver" ] || return 1
  printf '%s\n' "$_ver"
}

xinfc_install_state_summary() {
  if xinfc_core_installed; then
    _ver="$(xinfc_get_installed_version 2>/dev/null || true)"
    if [ -n "$_ver" ]; then
      info "xinfc-wsc: $XINFC_BIN (version $_ver)"
    else
      info "xinfc-wsc: $XINFC_BIN"
    fi
    return 0
  fi
  warn "xinfc-wsc не найден ($XINFC_BIN)"
  return 1
}
