#!/bin/sh
# shellcheck shell=sh
# Pick LAN AP on 5 GHz from UCI wireless.

xinfc_wireless_5g_radio() {
  _sec=""
  for _sec in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-device/\1/p' | cut -d. -f2); do
    _band="$(uci -q get "wireless.$_sec.band" 2>/dev/null || true)"
    [ "$_band" = "5g" ] && printf '%s\n' "$_sec" && return 0
  done
  if uci -q get wireless.radio1 >/dev/null 2>&1; then
    printf '%s\n' "radio1"
    return 0
  fi
  return 1
}

# Prints wifi-iface section name (e.g. default_radio1).
xinfc_wireless_pick_5g_ap_section() {
  _radio="$(xinfc_wireless_5g_radio 2>/dev/null || true)"
  [ -n "$_radio" ] || return 1

  _sec=""
  for _sec in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-iface/\1/p' | cut -d. -f2); do
    _dev="$(uci -q get "wireless.$_sec.device" 2>/dev/null || true)"
    _mode="$(uci -q get "wireless.$_sec.mode" 2>/dev/null || true)"
    [ "$_dev" = "$_radio" ] || continue
    [ "$_mode" = "ap" ] || continue
    printf '%s\n' "$_sec"
    return 0
  done
  return 1
}

xinfc_wireless_ap_credentials() {
  _sec="${1:-$(xinfc_wireless_pick_5g_ap_section 2>/dev/null || true)}"
  [ -n "$_sec" ] || return 1

  _ssid="$(uci -q get "wireless.$_sec.ssid" 2>/dev/null || true)"
  _key="$(uci -q get "wireless.$_sec.key" 2>/dev/null || true)"
  _enc="$(uci -q get "wireless.$_sec.encryption" 2>/dev/null || true)"
  _disabled="$(uci -q get "wireless.$_sec.disabled" 2>/dev/null || true)"

  [ -n "$_ssid" ] || return 1
  [ -n "$_key" ] || return 1
  [ -n "$_enc" ] || _enc="psk2+ccmp"

  printf '%s\n' "$_sec"
  printf '%s\n' "$_ssid"
  printf '%s\n' "$_key"
  printf '%s\n' "$_enc"
  printf '%s\n' "${_disabled:-0}"
}

xinfc_map_encryption_for_wsc() {
  _enc="$1"
  case "$_enc" in
    psk2+ccmp|psk2+tkip|psk2|psk+tkip|psk+ccmp|psk|wpa2|wpa|none)
      printf '%s\n' "$_enc"
      ;;
    psk2+ccmp+tkip)
      printf '%s\n' "psk2+ccmp"
      ;;
    *)
      return 1
      ;;
  esac
}
