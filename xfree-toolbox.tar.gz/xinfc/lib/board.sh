#!/bin/sh
# shellcheck shell=sh
# NFC board profile: I2C bus/addr and GitHub release asset slug.

_xinfc_board_db() {
  if [ -n "${XINFC_BOARD_DB:-}" ] && [ -f "$XINFC_BOARD_DB" ]; then
    printf '%s\n' "$XINFC_BOARD_DB"
    return 0
  fi
  _dir="${XINFC_SCRIPT_DIR:-}"
  if [ -z "$_dir" ]; then
    _dir="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
  fi
  if [ -f "$_dir/boards.tsv" ]; then
    printf '%s\n' "$_dir/boards.tsv"
    return 0
  fi
  return 1
}

xinfc_board_name() {
  if [ -r /tmp/sysinfo/board_name ]; then
    tr -d '\r\n' < /tmp/sysinfo/board_name
    return 0
  fi
  printf '%s' "unknown"
}

xinfc_board_family_key() {
  _b="$1"
  case "$_b" in
    cudy_wr3000s-v1*) _b="cudy,wr3000s-v1${_b#cudy_wr3000s-v1}" ;;
    cudy_wr3000e-v1*) _b="cudy,wr3000e-v1${_b#cudy_wr3000e-v1}" ;;
    cudy_wr3000p-v1*) _b="cudy,wr3000p-v1${_b#cudy_wr3000p-v1}" ;;
  esac
  case "$_b" in
    *-ubootmod) _b="${_b%-ubootmod}" ;;
    *-stock) _b="${_b%-stock}" ;;
  esac
  printf '%s\n' "$_b"
}

# Prints: i2c_bus TAB i2c_addr TAB release_slug
xinfc_board_lookup_row() {
  _board="${1:-$(xinfc_board_name)}"
  _db="${2:-$(_xinfc_board_db 2>/dev/null || true)}"
  [ -f "$_db" ] || return 1
  [ -n "$_board" ] || return 1
  [ "$_board" != "unknown" ] || return 1

  awk -F'\t' -v board="$_board" '
    function norm(b,    t) {
      t = b
      if (t ~ /^cudy_wr3000s-v1/) sub(/^cudy_wr3000s-v1/, "cudy,wr3000s-v1", t)
      if (t ~ /^cudy_wr3000e-v1/) sub(/^cudy_wr3000e-v1/, "cudy,wr3000e-v1", t)
      if (t ~ /^cudy_wr3000p-v1/) sub(/^cudy_wr3000p-v1/, "cudy,wr3000p-v1", t)
      sub(/-ubootmod$/, "", t)
      sub(/-stock$/, "", t)
      return t
    }
    function row_match(key, b) {
      return key == b || norm(key) == norm(b)
    }
    $1 !~ /^#/ && $1 != "" && row_match($1, board) {
      print $2 "\t" $3 "\t" $4
      exit 0
    }
  ' "$_db"
}

xinfc_board_supported() {
  xinfc_board_lookup_row "$@" >/dev/null 2>&1
}

xinfc_board_i2c_bus() {
  _row="$(xinfc_board_lookup_row "$@" 2>/dev/null || true)"
  [ -n "$_row" ] || return 1
  printf '%s\n' "${_row%%	*}"
}

xinfc_board_i2c_addr() {
  _row="$(xinfc_board_lookup_row "$@" 2>/dev/null || true)"
  [ -n "$_row" ] || return 1
  _rest="${_row#*	}"
  printf '%s\n' "${_rest%%	*}"
}

xinfc_board_release_slug() {
  _row="$(xinfc_board_lookup_row "$@" 2>/dev/null || true)"
  [ -n "$_row" ] || return 1
  _rest="${_row#*	}"
  _rest="${_rest#*	}"
  printf '%s\n' "$_rest"
}
