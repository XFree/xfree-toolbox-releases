#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo '=== NFQWS_OPT full (truncated) ==='
uci get zapret.config.NFQWS_OPT 2>/dev/null | head -c 4000
echo
echo '=== hostlist= paths in OPT ==='
uci get zapret.config.NFQWS_OPT 2>/dev/null | grep -oE -- '--hostlist=[^[:space:]]+' | sort -u
echo '=== hostlist-domains ==='
uci get zapret.config.NFQWS_OPT 2>/dev/null | grep -oE -- '--hostlist-domains=[^[:space:]]+' | sort -u
echo '=== cmdline nfqws hostlist ==='
ps w | grep nfqws | grep -v grep | tr ' ' '\n' | grep -E 'hostlist|qnum|fwmark' | head -40
echo '=== /etc/config/zapret size ==='
wc -c /etc/config/zapret
grep -c hostlist /etc/config/zapret || true
echo '=== last apply? deployed sig youtube_29 ==='
cat /etc/xfree-toolbox/zapret/state/sections/youtube_29/.xfree-deployed-profile.sig 2>&1 || true
ls /etc/xfree-toolbox/zapret/generated/ 2>&1 | head
REMOTE
