#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
ROOT_DIR=/root/xfree-toolbox
. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/zapret/lib.sh"

echo "profile_dir=$(zapret_profile_dir)"
echo "profile_root=$(zapret_profile_root)"
echo "sections_root=$(zapret_sections_root)"
echo "state_dir=$ZAPRET_STATE_DIR"

src="$(zapret_sections_root)/youtube_29/fqdn.d"
dst="$ZAPRET_STATE_DIR/sections/youtube_29/fqdn.d"
echo "src=$src"
echo "dst=$dst"
echo "src listing:"
ls -la "$src"
echo "dst before:"
ls -la "$dst" || true
echo "same_path?"; [ "$src" = "$dst" ] && echo YES || echo NO

common_sync_dir_mirror "$src" "$dst"
echo "dst after sync:"
ls -la "$dst"
wc -l "$dst"/*.lst 2>/dev/null || echo 'still empty'

echo '=== build_merged dry ==='
out=/tmp/yt29-host.txt
# source apply's function via running generate snippet
. "$ROOT_DIR/zapret/apply.sh" 2>/dev/null || true
REMOTE
