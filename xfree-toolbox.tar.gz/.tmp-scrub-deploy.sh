#!/bin/sh
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
. ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
scp "${SCP_OPTS[@]}" zapret/lib.sh "$SSH_TARGET:/root/xfree-toolbox/zapret/lib.sh"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
ROOT_DIR=/root/xfree-toolbox
cd "$ROOT_DIR/zapret"
# shellcheck disable=SC1091
. ./lib.sh
echo "before orphans:"
ORDER="$(zapret_sections_order_file)"
STATE="$(zapret_state_sections_root)"
for d in "$STATE"/*; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  grep -qx "$id" "$ORDER" 2>/dev/null || echo "  $id"
done
zapret_scrub_unowned_sections
echo "after orphans:"
left=0
for d in "$STATE"/*; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  if ! grep -qx "$id" "$ORDER" 2>/dev/null; then
    if zapret_section_dir_is_manual "$d"; then
      echo "  keep-manual $id"
    else
      echo "  STILL $id"
      left=1
    fi
  fi
done
[ "$left" -eq 0 ]
echo "summary zapret labels:"
sh "$ROOT_DIR/diagnostics/traffic-path.sh" summary --json | sed 's/},{/},\n{/g' | grep 'zapret:' | head -40
REMOTE
