#!/bin/sh
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

vkturn_uninstall
