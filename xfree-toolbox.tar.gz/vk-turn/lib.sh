#!/bin/sh
# shellcheck shell=sh

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
. "$SCRIPT_DIR/config.sh"
AWG_INGRESS_LIB_SH="$ROOT_DIR/awg-ingress/lib.sh"
[ -f "$AWG_INGRESS_LIB_SH" ] || die "Не найден awg-ingress/lib.sh: $AWG_INGRESS_LIB_SH"
# shellcheck disable=SC1090
. "$AWG_INGRESS_LIB_SH"

vkturn_get_installed_version() {
    if [ -f "$VKTURN_VERSION_FILE" ]; then
        version="$(head -n1 "$VKTURN_VERSION_FILE" 2>/dev/null | tr -d '\r\n\t ')"
        [ -n "$version" ] && {
            printf '%s\n' "$version"
            return 0
        }
    fi

    if [ -x "$VKTURN_BIN" ]; then
        version="$(
            "$VKTURN_BIN" --version 2>/dev/null \
                | awk 'match($0,/v[0-9]+\.[0-9]+\.[0-9]+/){print substr($0,RSTART,RLENGTH); exit}'
        )"
        [ -n "$version" ] || version="$(
            "$VKTURN_BIN" -version 2>/dev/null \
                | awk 'match($0,/v[0-9]+\.[0-9]+\.[0-9]+/){print substr($0,RSTART,RLENGTH); exit}'
        )"
        [ -n "$version" ] && {
            vkturn_set_version "$version" 2>/dev/null || true
            printf '%s\n' "$version"
            return 0
        }
        printf '%s\n' "installed"
        return 0
    fi

    printf '%s\n' "not-installed"
}

vkturn_set_version() {
    echo "$1" > "$VKTURN_VERSION_FILE"
}

vkturn_fetch_latest() {
    curl -fsSL "https://github.com/$VKTURN_REPO/releases/latest" \
        | grep -Eo 'v[0-9]+\.[0-9]+\.[0-9]+' \
        | head -n1
}

vkturn_resolve_install_version() {
    requested="${1:-}"
    if [ -n "$requested" ]; then
        printf '%s\n' "$requested"
        return 0
    fi

    latest="$(vkturn_fetch_latest 2>/dev/null || true)"
    if [ -n "$latest" ]; then
        printf '%s\n' "$latest"
        return 0
    fi

    warn "Не удалось получить latest vk-turn release, использую default: $VKTURN_DEFAULT_VERSION"
    printf '%s\n' "$VKTURN_DEFAULT_VERSION"
}

vkturn_stop() {
    if [ -x "$VKTURN_INIT_SCRIPT" ]; then
        info "Останавливаю сервис $VKTURN_SERVICE_NAME"
        "$VKTURN_INIT_SCRIPT" stop || true
    fi
}

vkturn_start() {
    if [ -x "$VKTURN_INIT_SCRIPT" ]; then
        info "Запускаю сервис $VKTURN_SERVICE_NAME"
        "$VKTURN_INIT_SCRIPT" start || true
    fi
}

vkturn_install_server() {
    version="$(vkturn_resolve_install_version "${1:-}")"
    url="https://github.com/$VKTURN_REPO/releases/download/$version/$VKTURN_ASSET_NAME"

    vkturn_ensure_dirs
    vkturn_stop

    info "Скачиваю $url"
    http_fetch_file "$url" "$VKTURN_BIN" || die "Не удалось скачать бинарник"

    chmod +x "$VKTURN_BIN"
    vkturn_set_version "$version"

    vkturn_start
    success "Установлен vk-turn server версии $version"
}

vkturn_update_server() {
    latest="$(vkturn_fetch_latest)" || die "Не удалось получить последнюю версию"
    current="$(vkturn_get_installed_version)"

    info "Текущая версия: $current"
    info "Последняя версия: $latest"

    [ "$latest" = "$current" ] && {
        success "Обновление не требуется"
        return 0
    }

    vkturn_install_server "$latest"
}

vkturn_check_update() {
    latest="$(vkturn_fetch_latest)" || die "Не удалось получить последнюю версию"
    current="$(vkturn_get_installed_version)"

    echo "Текущая версия: $current"
    echo "Последняя версия: $latest"

    if [ "$latest" = "$current" ]; then
        success "Обновление не требуется"
    else
        warn "Доступно обновление: $current -> $latest"
    fi
}

vkturn_version_status() {
    echo "Установлено: $(vkturn_get_installed_version)"
    echo "Последняя: $(vkturn_fetch_latest 2>/dev/null || echo unknown)"
}

vkturn_configure_ingress() {
    awgingress_configure_ingress
}

vkturn_configure_firewall() {
    awgingress_configure_firewall
    info "Настраиваю firewall для $VKTURN_SERVICE_NAME"

    # UCI section names must be identifier-safe, so keep a dedicated section id.
    rule_section="${VKTURN_FIREWALL_RULE_SECTION:-vk_turn}"
    uci -q delete "firewall.$rule_section" || true
    uci set "firewall.$rule_section=rule"
    uci set "firewall.$rule_section.name=$VKTURN_FIREWALL_RULE_NAME"
    uci set "firewall.$rule_section.src=$VKTURN_WAN_IF"
    uci set "firewall.$rule_section.proto=udp"
    uci set "firewall.$rule_section.dest_port=$VKTURN_PORT"
    uci set "firewall.$rule_section.target=ACCEPT"

    uci commit firewall
    /etc/init.d/firewall restart

    success "Firewall для $VKTURN_SERVICE_NAME настроен"
}

vkturn_install_service() {
    vkturn_ensure_dirs
    info "Создаю сервис $VKTURN_SERVICE_NAME"

    cat > "$VKTURN_INIT_SCRIPT" <<EOF
#!/bin/sh /etc/rc.common

START=99
STOP=10
USE_PROCD=1

BIN="$VKTURN_BIN"
LISTEN_ADDR="0.0.0.0:$VKTURN_PORT"
CONNECT_ADDR="127.0.0.1:$VKTURN_INGRESS_PORT"
INGRESS_IF="$VKTURN_INGRESS_IF"

start_service() {
    [ -x "\$BIN" ] || return 1
    ip link show "\$INGRESS_IF" >/dev/null 2>&1 || return 1

    procd_open_instance
    procd_set_param command "\$BIN" \
        -listen "\$LISTEN_ADDR" \
        -connect "\$CONNECT_ADDR"

    procd_set_param respawn 3600 5 5
    procd_set_param stdout 1
    procd_set_param stderr 1
    procd_close_instance
}

service_triggers() {
    procd_add_interface_trigger "interface.*" "wan" /etc/init.d/vk-turn restart
    procd_add_interface_trigger "interface.*" "\$INGRESS_IF" /etc/init.d/vk-turn restart
}
EOF

    chmod +x "$VKTURN_INIT_SCRIPT"
    "$VKTURN_INIT_SCRIPT" enable
    "$VKTURN_INIT_SCRIPT" restart

    success "Сервис $VKTURN_SERVICE_NAME установлен и запущен"
}
vkturn_add_peer() {
    name="$1"
    endpoint="${2:-127.0.0.1:9000}"

    awgingress_add_peer "$name" "$endpoint"
    info "Для vk-turn на клиенте используйте сервер: ${VKTURN_ROUTER_HOST}:$VKTURN_PORT"
    info "Локальный endpoint AWG клиента: $endpoint"
}

vkturn_status() {
    echo "=== VERSION ==="
    vkturn_version_status
    echo
    echo "=== SERVICE ==="
    [ -x "$VKTURN_INIT_SCRIPT" ] && "$VKTURN_INIT_SCRIPT" status 2>/dev/null || echo "Service not installed"
    echo
    echo "=== PORTS ==="
    netstat -lpn 2>/dev/null | grep -E "$VKTURN_PORT|$VKTURN_INGRESS_PORT" || true
    echo
    echo "=== AWG ==="
    awg show "$VKTURN_INGRESS_IF" 2>/dev/null || true
    echo
    echo "=== AWG INGRESS PEERS ==="
    awgingress_peers_meta_list || true
}
