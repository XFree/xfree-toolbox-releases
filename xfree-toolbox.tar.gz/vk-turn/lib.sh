#!/bin/sh
# shellcheck shell=sh

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
. "$SCRIPT_DIR/config.sh"
AWG_INGRESS_LIB_SH="$ROOT_DIR/awg-ingress/lib.sh"
[ -f "$AWG_INGRESS_LIB_SH" ] || die "Не найден awg-ingress/lib.sh: $AWG_INGRESS_LIB_SH"
# shellcheck disable=SC1090
. "$AWG_INGRESS_LIB_SH"

vkturn_get_installed_version() {
    if [ -f "$VKTURN_VERSION_FILE" ]; then
        version="$(head -n1 "$VKTURN_VERSION_FILE" 2>/dev/null | tr -d '\r\n\t ')"
        [ -n "$version" ] && {
            printf '%s\n' "$version"
            return 0
        }
    fi

    if [ -x "$VKTURN_BIN" ]; then
        version="$(
            "$VKTURN_BIN" --version 2>/dev/null \
                | awk 'match($0,/v[0-9]+\.[0-9]+\.[0-9]+/){print substr($0,RSTART,RLENGTH); exit}'
        )"
        [ -n "$version" ] || version="$(
            "$VKTURN_BIN" -version 2>/dev/null \
                | awk 'match($0,/v[0-9]+\.[0-9]+\.[0-9]+/){print substr($0,RSTART,RLENGTH); exit}'
        )"
        [ -n "$version" ] && {
            printf '%s\n' "$version"
            return 0
        }
        printf '%s\n' "installed"
        return 0
    fi

    if [ -f "$VKTURN_INIT_SCRIPT" ]; then
        printf '%s\n' "service-only"
        return 0
    fi

    printf '%s\n' "not-installed"
}

vkturn_version_status() {
    installed="$(vkturn_get_installed_version)"
    if [ "$installed" = "not-installed" ]; then
        echo "Статус: не установлен"
    else
        echo "Статус: установлен ($installed) [устаревший транспорт]"
    fi
}

vkturn_stop() {
    if [ -x "$VKTURN_INIT_SCRIPT" ]; then
        info "Останавливаю сервис $VKTURN_SERVICE_NAME"
        "$VKTURN_INIT_SCRIPT" stop || true
    fi
}

vkturn_status() {
    echo "=== VERSION ==="
    vkturn_version_status
    echo
    echo "=== SERVICE ==="
    [ -x "$VKTURN_INIT_SCRIPT" ] && "$VKTURN_INIT_SCRIPT" status 2>/dev/null || echo "Service not installed"
    echo
    echo "=== PORTS ==="
    netstat -lpn 2>/dev/null | grep -E "$VKTURN_PORT|$VKTURN_INGRESS_PORT" || true
    echo
    echo "=== AWG ==="
    awg show "$VKTURN_INGRESS_IF" 2>/dev/null || true
}

vkturn_uninstall() {
    info "Удаляю VK-Turn proxy..."
    if [ -x "$VKTURN_INIT_SCRIPT" ]; then
        "$VKTURN_INIT_SCRIPT" stop 2>/dev/null || true
        "$VKTURN_INIT_SCRIPT" disable 2>/dev/null || true
        rm -f "$VKTURN_INIT_SCRIPT"
    fi
    rm -rf "$VKTURN_DIR"
    rm -rf "$VKTURN_STATE_ROOT"

    firewall_changed=0
    if uci -q get firewall.vk_turn >/dev/null 2>&1; then
        uci -q delete firewall.vk_turn || true
        firewall_changed=1
    fi
    rules="$(uci show firewall 2>/dev/null | grep -E "\.name='?Allow-vk-turn'?" | cut -d'.' -f2 | cut -d'=' -f1 || true)"
    for r in $rules; do
        if [ -n "$r" ]; then
            uci -q delete "firewall.$r" || true
            firewall_changed=1
        fi
    done
    if [ "$firewall_changed" -eq 1 ]; then
        uci commit firewall 2>/dev/null || true
        /etc/init.d/firewall restart 2>/dev/null || true
        info "Удалено правило firewall для vk-turn"
    fi
    success "VK-Turn proxy полностью удалён и очищен с роутера"
}
