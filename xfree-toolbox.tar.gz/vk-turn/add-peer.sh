#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

NAME="${1:-}"
ENDPOINT="${2:-127.0.0.1:9000}"

[ -n "$NAME" ] || die "Использование: $0 <peer-name> [local-awg-endpoint]"

vkturn_add_peer "$NAME" "$ENDPOINT"
