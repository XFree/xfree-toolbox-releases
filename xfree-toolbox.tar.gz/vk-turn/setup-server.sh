#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

ENSURE_SCRIPT="${ENSURE_SCRIPT:-$SCRIPT_DIR/ensure-vk-turn.sh}"
version="${1:-}"

[ -f "$ENSURE_SCRIPT" ] || die "Не найден ensure script: $ENSURE_SCRIPT"
[ -x "$ENSURE_SCRIPT" ] || chmod +x "$ENSURE_SCRIPT" 2>/dev/null || true
"$ENSURE_SCRIPT" --install-if-missing
if [ -n "$version" ]; then
    vkturn_install_server "$version"
fi
awgingress_configure_ingress
vkturn_configure_firewall
vkturn_install_service

success "VK-TURN server настроен"
