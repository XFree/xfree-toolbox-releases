#!/bin/sh
# Hand-written handlers for cli.run component=custom in vk-turn/menu.yaml.
# shellcheck shell=sh

# shellcheck disable=SC1090
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

vkturn_run() {
	title="$1"
	shift
	ui_run_with_output "$title" "$@"
}

vkturn_menu_choice_1() {
	vkturn_run "Setup server" "$SCRIPT_DIR/setup-server.sh"
}

vkturn_menu_choice_2() {
	vkturn_run "Проверка обновления" "$SCRIPT_DIR/check-update.sh"
}

vkturn_menu_choice_3() {
	vkturn_run "Update" "$SCRIPT_DIR/update.sh"
}

vkturn_menu_choice_4() {
	vkturn_run "Status" "$SCRIPT_DIR/status.sh"
}

vkturn_menu_choice_6() {
	vkturn_run "Firewall" "$SCRIPT_DIR/configure-firewall.sh"
}

vkturn_menu_choice_7() {
	vkturn_run "Init service" "$SCRIPT_DIR/install-service.sh"
}

vkturn_menu_choice_8() {
	peers_lines="$(awgingress_list_peer_choices | awk -F "$(printf '\t')" '{print $1}' || true)"
	[ -n "${peers_lines:-}" ] || {
		ui_msgbox "VK-TURN" "Не найдены peers в AWG ingress state.\nСначала создайте peer в меню AWG ingress."
		return 0
	}

	peer="$(ui_select_from_lines "VK-TURN" "Выберите готовый AWG peer для wireguard-turn-android" "$peers_lines" 22 90 12 || true)"
	[ -n "${peer:-}" ] || return 0

	vkturn_run "wireguard-turn-android config" \
		"$SCRIPT_DIR/export-wireguard-turn-android.sh" \
		--peer "$peer"
}

vkturn_menu_choice_9() {
	vkturn_run "Install" "$SCRIPT_DIR/install.sh"
}
