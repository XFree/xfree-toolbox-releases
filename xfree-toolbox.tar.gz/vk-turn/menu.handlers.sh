#!/bin/sh
# Hand-written handlers for cli.run component=custom in vk-turn/menu.yaml.
# shellcheck shell=sh

# shellcheck disable=SC1090
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

vkturn_run() {
	title="$1"
	shift
	ui_run_with_output "$title" "$@"
}

vkturn_menu_choice_1() {
	vkturn_run "Статус VK-Turn" "$SCRIPT_DIR/status.sh"
}

vkturn_menu_choice_2() {
	if ui_yesno "VK-TURN" "Полностью удалить устаревший VK-Turn proxy с роутера (служба, файлы, firewall)?"; then
		vkturn_run "Удаление VK-Turn" "$SCRIPT_DIR/uninstall.sh"
	fi
}
