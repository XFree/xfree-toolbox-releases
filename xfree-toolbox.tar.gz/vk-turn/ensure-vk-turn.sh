#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

INSTALL_IF_MISSING=0

usage() {
  cat <<EOF
Usage: $0 [--install-if-missing]

Check vk-turn server installation state.

Options:
  --install-if-missing   Install vk-turn server binary if it is missing
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --install-if-missing)
      INSTALL_IF_MISSING=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Неизвестный аргумент: $1"
      ;;
  esac
  shift
done

current="$(vkturn_get_installed_version)"
if [ "$current" != "not-installed" ]; then
  success "vk-turn установлен: $current"
  exit 0
fi

warn "vk-turn не установлен"
if [ "$INSTALL_IF_MISSING" != "1" ]; then
  exit 1
fi

info "vk-turn отсутствует, запускаю установку latest"
vkturn_install_server
current="$(vkturn_get_installed_version)"
[ "$current" != "not-installed" ] || die "vk-turn не появился после установки"
success "vk-turn установлен: $current"
