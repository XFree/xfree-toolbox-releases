#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

PEER=""
WG_ENDPOINT="127.0.0.1:${VKTURN_WGT_LOCAL_PORT}"
TURN_IP_PORT=""
ENABLE_TURN="${VKTURN_WGT_ENABLE_TURN}"
USE_UDP="${VKTURN_WGT_USE_UDP}"
MODE="${VKTURN_WGT_MODE}"
PEER_TYPE="${VKTURN_WGT_PEER_TYPE}"
STREAM_NUM="${VKTURN_WGT_STREAM_NUM}"
LOCAL_PORT="${VKTURN_WGT_LOCAL_PORT}"
STREAMS_PER_CRED="${VKTURN_WGT_STREAMS_PER_CRED}"
VK_LINK=""
OUTPUT=""

usage() {
    cat <<EOF
Usage: $0 --peer <slug|name> [options]

Generate wireguard-turn-android config from existing AWG peer.

Options:
  --peer <slug|name>       Existing AWG peer in state/profile (required)
  --wg-endpoint <host:port>  WireGuard Endpoint inside config (default: $WG_ENDPOINT)
  --turn-ipport <host:port>  #@wgt:IPPort (default: AWG_INGRESS_ROUTER_HOST:VKTURN_PORT)
  --enable-turn <true|false> (default: $ENABLE_TURN)
  --use-udp <true|false>     (default: $USE_UDP)
  --mode <vk_link|wb>        (default: $MODE)
  --peer-type <proxy_v2|proxy_v1|wireguard> (default: $PEER_TYPE)
  --stream-num <n>           (default: $STREAM_NUM)
  --local-port <n>           (default: $LOCAL_PORT)
  --streams-per-cred <n>     (default: $STREAMS_PER_CRED)
  --vk-link <url>            Optional #@wgt:VKLink value
  --output <path>            Write result to file (optional)
  -h, --help
EOF
}

validate_bool() {
    value="$1"
    case "$value" in
        true|false) return 0 ;;
    esac
    return 1
}

validate_number() {
    value="$1"
    case "$value" in
        ''|*[!0-9]*) return 1 ;;
        *) return 0 ;;
    esac
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --peer) shift; [ "$#" -gt 0 ] || die "--peer требует значение"; PEER="$1" ;;
        --wg-endpoint) shift; [ "$#" -gt 0 ] || die "--wg-endpoint требует значение"; WG_ENDPOINT="$1" ;;
        --turn-ipport) shift; [ "$#" -gt 0 ] || die "--turn-ipport требует значение"; TURN_IP_PORT="$1" ;;
        --enable-turn) shift; [ "$#" -gt 0 ] || die "--enable-turn требует значение"; ENABLE_TURN="$1" ;;
        --use-udp) shift; [ "$#" -gt 0 ] || die "--use-udp требует значение"; USE_UDP="$1" ;;
        --mode) shift; [ "$#" -gt 0 ] || die "--mode требует значение"; MODE="$1" ;;
        --peer-type) shift; [ "$#" -gt 0 ] || die "--peer-type требует значение"; PEER_TYPE="$1" ;;
        --stream-num) shift; [ "$#" -gt 0 ] || die "--stream-num требует значение"; STREAM_NUM="$1" ;;
        --local-port) shift; [ "$#" -gt 0 ] || die "--local-port требует значение"; LOCAL_PORT="$1" ;;
        --streams-per-cred) shift; [ "$#" -gt 0 ] || die "--streams-per-cred требует значение"; STREAMS_PER_CRED="$1" ;;
        --vk-link) shift; [ "$#" -gt 0 ] || die "--vk-link требует значение"; VK_LINK="$1" ;;
        --output) shift; [ "$#" -gt 0 ] || die "--output требует значение"; OUTPUT="$1" ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
    shift || true
done

[ -n "$PEER" ] || die "Не указан --peer"
validate_bool "$ENABLE_TURN" || die "--enable-turn должен быть true или false"
validate_bool "$USE_UDP" || die "--use-udp должен быть true или false"
validate_number "$STREAM_NUM" || die "--stream-num должен быть числом"
validate_number "$LOCAL_PORT" || die "--local-port должен быть числом"
validate_number "$STREAMS_PER_CRED" || die "--streams-per-cred должен быть числом"

case "$MODE" in
    vk_link|wb) ;;
    *) die "--mode должен быть vk_link или wb" ;;
esac

case "$PEER_TYPE" in
    proxy_v2|proxy_v1|wireguard) ;;
    *) die "--peer-type должен быть proxy_v2, proxy_v1 или wireguard" ;;
esac

slug="$(awgingress_resolve_peer_slug "$PEER")" || die "Не найден peer: $PEER"
awgingress_load_peer_state "$slug"

# Keep Endpoint aligned with LocalPort default/override.
WG_ENDPOINT="127.0.0.1:${LOCAL_PORT}"

if [ -z "$TURN_IP_PORT" ]; then
    awg_endpoint="${PEER_ENDPOINT_STATE:-}"
    endpoint_host=""
    if [ -n "$awg_endpoint" ]; then
        case "$awg_endpoint" in
            \[*\]:*)
                endpoint_host="${awg_endpoint%%\]:*}"
                endpoint_host="${endpoint_host#\[}"
                ;;
            *:*)
                endpoint_host="${awg_endpoint%:*}"
                ;;
            *)
                endpoint_host="$awg_endpoint"
                ;;
        esac
    fi

    if [ -n "$endpoint_host" ]; then
        TURN_IP_PORT="${endpoint_host}:${VKTURN_PORT}"
    elif [ -n "${AWG_INGRESS_ROUTER_HOST:-}" ]; then
        TURN_IP_PORT="${AWG_INGRESS_ROUTER_HOST}:${VKTURN_PORT}"
    else
        TURN_IP_PORT="127.0.0.1:${VKTURN_PORT}"
    fi
fi

base_conf="$(awgingress_render_peer_config "$slug" "$WG_ENDPOINT")"
[ -n "$base_conf" ] || die "Не удалось сгенерировать базовый WG config"

tmp_out="$(mktemp)"
cleanup() {
    rm -f "$tmp_out"
}
trap cleanup EXIT HUP INT TERM

{
    printf '%s\n' "$base_conf"
    printf '\n'
    printf '# [Peer] TURN extensions for wireguard-turn-android\n'
    printf '#@wgt:EnableTURN = %s\n' "$ENABLE_TURN"
    printf '#@wgt:UseUDP = %s\n' "$USE_UDP"
    printf '#@wgt:IPPort = %s\n' "$TURN_IP_PORT"
    printf '#@wgt:Mode = %s\n' "$MODE"
    printf '#@wgt:PeerType = %s\n' "$PEER_TYPE"
    printf '#@wgt:StreamNum = %s\n' "$STREAM_NUM"
    printf '#@wgt:LocalPort = %s\n' "$LOCAL_PORT"
    printf '#@wgt:StreamsPerCred = %s\n' "$STREAMS_PER_CRED"
    if [ -n "$VK_LINK" ]; then
        printf '#@wgt:VKLink = %s\n' "$VK_LINK"
    fi
} > "$tmp_out"

if [ -n "$OUTPUT" ]; then
    mkdir -p "$(dirname -- "$OUTPUT")"
    cp -f "$tmp_out" "$OUTPUT"
    chmod 600 "$OUTPUT" 2>/dev/null || true
    success "Готово: $OUTPUT"
else
    cat "$tmp_out"
fi
