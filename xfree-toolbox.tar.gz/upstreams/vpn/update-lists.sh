#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"

# Корень репозитория: каталог, где есть lib/common.sh (модуль: upstreams/vpn/).
d="$SCRIPT_DIR"
ROOT_DIR=""
while [ "$d" != "/" ]; do
    if [ -f "$d/lib/common.sh" ]; then
        ROOT_DIR="$d"
        break
    fi
    d="$(dirname "$d")"
done
if [ -z "${ROOT_DIR:-}" ]; then
    echo "[!] Не найден корень проекта (lib/common.sh) от $SCRIPT_DIR" >&2
    exit 1
fi

COMMON_SH="$ROOT_DIR/lib/common.sh"
PROTON_API_SH="$ROOT_DIR/iface-routing/vpn/lib/proton-api.sh"

[ -f "$COMMON_SH" ] || {
  echo "[!] Не найден common.sh: $COMMON_SH" >&2
  exit 1
}
[ -f "$PROTON_API_SH" ] || {
  echo "[!] Не найден proton-api.sh: $PROTON_API_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"
# POST /api/auth/refresh для web-cookies здесь не используется:
# списки Proton всегда через новую гостевую сессию (как generate --acquire-guest).
# Постоянная сессия — только generate.sh / меню Proton.
PROTON_REFRESH_BEFORE_AUTH="${PROTON_REFRESH_BEFORE_AUTH:-0}"
export PROTON_REFRESH_BEFORE_AUTH
. "$PROTON_API_SH"

CONF_FILE="$SCRIPT_DIR/upstream.conf"
# Путь к bundles на dev-хосте (ci/store/…/vpn/proton/sessions); до source upstream.conf.
if [ -n "${XFREE_DEV_PROTON_SESSIONS_DIR:-}" ]; then
    PROTON_SESSIONS_DIR="$XFREE_DEV_PROTON_SESSIONS_DIR"
    export PROTON_SESSIONS_DIR
fi
[ -f "$CONF_FILE" ] && . "$CONF_FILE"

# Как в iface-routing proton-api: по умолчанию только бесплатные (Tier=0).
PROTON_USE_FREE_ONLY="${PROTON_USE_FREE_ONLY:-1}"
case "$PROTON_USE_FREE_ONLY" in
    1|yes|YES|true|TRUE) PROTON_USE_FREE_ONLY=1 ;;
    0|no|NO|false|FALSE) PROTON_USE_FREE_ONLY=0 ;;
    *) PROTON_USE_FREE_ONLY=1 ;;
esac
export PROTON_USE_FREE_ONLY

case "${PROTON_UPSTREAM_RESOLVE_HOSTS:-1}" in
    1|yes|YES|true|TRUE) PROTON_UPSTREAM_RESOLVE_HOSTS=1 ;;
    0|no|NO|false|FALSE) PROTON_UPSTREAM_RESOLVE_HOSTS=0 ;;
    *) PROTON_UPSTREAM_RESOLVE_HOSTS=1 ;;
esac
export PROTON_UPSTREAM_RESOLVE_HOSTS

# Дефолт из upstream.conf: …/vpn/upstream/
UPSTREAM_DIR="${UPSTREAM_DIR:-$SCRIPT_DIR/upstream}"
TMP_DIR="${TMP_DIR:-/tmp/proton-upstream.$$}"

QUIET=0

cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT INT TERM

usage() {
  cat <<'EOF'
Usage:
  update-lists.sh [--quiet] [--acquire-guest]

  Всегда гостевая credentialless-сессия (как generate.sh --acquire-guest).
  --acquire-guest принимается для совместимости (это единственный режим).
  Постоянная сессия (--session) — только generate.sh / меню Proton.
EOF
}

PROTON_SESSION="${PROTON_SESSION:-}"

while [ "$#" -gt 0 ]; do
  case "$1" in
    --quiet)
      QUIET=1
      shift
      ;;
    --session)
      die "update-lists всегда гостевая; --session — у generate.sh (меню Proton)"
      ;;
    --acquire-guest)
      shift
      ;;
    *)
      die "Неизвестный аргумент: $1"
      ;;
  esac
done

require_cmd jq
say "[*] Proton: гостевая сессия для списков API (credentialless)"
[ -n "${PROTON_SESSIONS_DIR:-}" ] || die "Не задан PROTON_SESSIONS_DIR для гостевой сессии"
mkdir -p "$PROTON_SESSIONS_DIR" || die "Не удалось создать $PROTON_SESSIONS_DIR"
proton_guest_acquire_session "$PROTON_SESSIONS_DIR" >/dev/null
[ -n "${PROTON_SELECTED_SESSION_NAME:-}" ] || die "guest acquire не вернул имя сессии"
PROTON_SESSION="$PROTON_SELECTED_SESSION_NAME"
PROTON_REFRESH_BEFORE_AUTH=0

# Строки IPv4 без /32 (для объединения с API-списком).
proton_upstream_host_v4_lines() {
  host="$1"
  [ -n "$host" ] || return 0
  case "$host" in *[!A-Za-z0-9._-]*) return 0 ;; esac
  {
    if command -v getent >/dev/null 2>&1; then
      getent ahosts "$host" 2>/dev/null | awk '$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && $1 !~ /^127\./ { print $1 }' || true
    fi
    if command -v nslookup >/dev/null 2>&1; then
      nslookup "$host" 2>/dev/null | tr -d '\r' | grep -oE '[0-9]{1,3}(\.[0-9]{1,3}){3}' | awk '!/^127\./ && $0 != "0.0.0.0" { print }' || true
    fi
  } | sort -u
}

# Строки IPv6 без /128.
proton_upstream_host_v6_lines() {
  host="$1"
  [ -n "$host" ] || return 0
  case "$host" in *[!A-Za-z0-9._-]*) return 0 ;; esac
  command -v getent >/dev/null 2>&1 || return 0
  getent ahosts "$host" 2>/dev/null | awk '$1 ~ /:/ && $1 !~ /^fe80:/ && $1 !~ /^::1$/ && $1 !~ /^ff[0-9a-fA-F]*:/ { print $1 }' | sort -u || true
}

PROTON_UPSTREAM_RESOLVE_WARNED=0
proton_upstream_append_resolved_for_fqdn_file() {
  fqdn_path="$1"
  v4_plain_accum="$2"
  v6_plain_accum="$3"
  [ -f "$fqdn_path" ] || return 0
  if ! command -v getent >/dev/null 2>&1 && ! command -v nslookup >/dev/null 2>&1; then
    if [ "$PROTON_UPSTREAM_RESOLVE_WARNED" != 1 ] && [ "$QUIET" != 1 ]; then
      PROTON_UPSTREAM_RESOLVE_WARNED=1
      echo "[!] PROTON_UPSTREAM_RESOLVE_HOSTS=1, но нет getent/nslookup — DNS-дополнение prefixes пропущено" >&2
    fi
    return 0
  fi
  while IFS= read -r host; do
    [ -n "$host" ] || continue
    proton_upstream_host_v4_lines "$host" | sort -u >> "$v4_plain_accum"
    proton_upstream_host_v6_lines "$host" | sort -u >> "$v6_plain_accum"
  done < "$fqdn_path"
}

say "[*] Сессия: $(basename "$PROTON_SESSION")"

require_cmd jq
require_cmd sed
require_cmd grep
require_cmd sort
require_cmd tr
require_cmd awk
require_cmd wc

mkdir -p "$TMP_DIR/newroot/proton"
# Как allow-domains/upstream/others/<service>/: под upstream/ — proton/<CC>/
LIST_GROUP="proton"

PROTON_SELECTED_SESSION="$PROTON_SESSION"
export PROTON_SELECTED_SESSION

proton_load_session

# Сначала refresh cookies (если разрешён), затем проверка /users и остальной pipeline.
case "$PROTON_REFRESH_BEFORE_AUTH" in
    1|yes|YES|true|TRUE)
        say "[*] Обновление сессии (Proton API refresh)"
        proton_refresh_session >/dev/null || true
        ;;
esac

say "[*] Проверка авторизации"
proton_verify_auth >/dev/null

say "[*] Получение серверов"
proton_fetch_logicals >/dev/null

[ -s "$PROTON_LOGICALS_JSON" ] || die "Пустой ответ Proton"

if [ "$PROTON_USE_FREE_ONLY" = "1" ]; then
  say "[*] Генерация списков по странам (только бесплатные серверы, Tier=0)"
else
  say "[*] Генерация списков по странам (все tier)"
fi

jq -r '
  .LogicalServers[]
  | (.ExitCountry // "")
' "$PROTON_LOGICALS_JSON" \
| sed '/^$/d' \
| common_upper_ascii_stream \
| sort -u \
| while IFS= read -r CC; do
    [ -n "$CC" ] || continue

    slug="$(common_lower_ascii "$CC")"
    dir="$TMP_DIR/newroot/$LIST_GROUP/$slug"

    mkdir -p "$dir"
    rm -f "$dir/prefixes-ipv4.lst" "$dir/prefixes-ipv6.lst" "$dir/fqdn-${slug}.lst" 2>/dev/null || true

    ipv4_file="$dir/prefixes-ipv4-${slug}.lst"
    ipv6_file="$dir/prefixes-ipv6-${slug}.lst"
    fqdn_file="$dir/fqdn-${slug}.lst"
    tmp4_plain="$TMP_DIR/plain4.$slug.$$"
    tmp6_plain="$TMP_DIR/plain6.$slug.$$"
    tmp4_res="$TMP_DIR/res4.$slug.$$"
    tmp6_res="$TMP_DIR/res6.$slug.$$"
    tmp_fqdn="$TMP_DIR/fqdnraw.$slug.$$"

    rm -f "$tmp4_plain" "$tmp6_plain" "$tmp4_res" "$tmp6_res" "$tmp_fqdn"
    : > "$tmp4_res"
    : > "$tmp6_res"

    jq -r --arg cc "$CC" --argjson free_only "$PROTON_USE_FREE_ONLY" '
      .LogicalServers[]
      | select((.ExitCountry // "" | ascii_upcase) == ($cc | ascii_upcase))
      | select(if $free_only == 1 then ((.Tier // -1) == 0) else true end)
      | .Servers[]?
      | (
          (if (.EntryIP == null or .EntryIP == "") then empty else .EntryIP end)
          // (if (.ExitIP == null or .ExitIP == "") then empty else .ExitIP end)
          // empty
        )
    ' "$PROTON_LOGICALS_JSON" \
    | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' \
    | sort -u > "$tmp4_plain" || true

    jq -r --arg cc "$CC" --argjson free_only "$PROTON_USE_FREE_ONLY" '
      .LogicalServers[]
      | select((.ExitCountry // "" | ascii_upcase) == ($cc | ascii_upcase))
      | select(if $free_only == 1 then ((.Tier // -1) == 0) else true end)
      | .Servers[]?
      | (
          (if (.EntryIPv6 == null or .EntryIPv6 == "") then empty else .EntryIPv6 end)
          // (if (.ExitIPv6 == null or .ExitIPv6 == "") then empty else .ExitIPv6 end)
          // empty
        )
    ' "$PROTON_LOGICALS_JSON" \
    | grep ':' \
    | sort -fu > "$tmp6_plain" || true

    jq -r --arg cc "$CC" --argjson free_only "$PROTON_USE_FREE_ONLY" '
      .LogicalServers[]
      | select((.ExitCountry // "" | ascii_upcase) == ($cc | ascii_upcase))
      | select(if $free_only == 1 then ((.Tier // -1) == 0) else true end)
      | .Servers[]?
      | (.Name // .ServerName // .Domain // "")
      | strings
      | select(length > 0)
      | select(contains("."))
      | select(test("[A-Za-z]"))
      | select(test("^[a-zA-Z0-9._-]+$"))
    ' "$PROTON_LOGICALS_JSON" \
    | sort -fu > "$tmp_fqdn" || true

    if [ -s "$tmp_fqdn" ]; then
      sort -fu "$tmp_fqdn" > "$fqdn_file"
    else
      rm -f "$fqdn_file"
    fi

    case "$PROTON_UPSTREAM_RESOLVE_HOSTS" in
      1|yes|YES|true|TRUE)
        if [ -f "$fqdn_file" ]; then
          proton_upstream_append_resolved_for_fqdn_file "$fqdn_file" "$tmp4_res" "$tmp6_res"
          sort -u "$tmp4_res" -o "$tmp4_res" 2>/dev/null || : > "$tmp4_res"
          sort -u "$tmp6_res" -o "$tmp6_res" 2>/dev/null || : > "$tmp6_res"
        fi
        ;;
    esac

    cat "$tmp4_plain" "$tmp4_res" 2>/dev/null \
    | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' \
    | sort -u \
    | sed 's/$/\/32/' > "$ipv4_file" || true

    cat "$tmp6_plain" "$tmp6_res" 2>/dev/null \
    | grep ':' \
    | sort -fu \
    | sed 's/$/\/128/' > "$ipv6_file" || true

    rm -f "$tmp4_plain" "$tmp6_plain" "$tmp4_res" "$tmp6_res" "$tmp_fqdn"

    c4="$(wc -l < "$ipv4_file" | awk '{print $1}')"
    c6="$(wc -l < "$ipv6_file" | awk '{print $1}')"
    cfq=0
    [ -f "$fqdn_file" ] && cfq="$(wc -l < "$fqdn_file" | awk '{print $1}')"

    if [ "$c4" = "0" ] && [ "$c6" = "0" ]; then
      rm -rf "$dir"
    else
      if [ "$cfq" != "0" ]; then
        say "[*] $CC: IPv4=$c4, IPv6=$c6, fqdn=$cfq"
      else
        say "[*] $CC: IPv4=$c4, IPv6=$c6"
      fi
    fi
done

fqdn_preserve=""
if [ -f "$UPSTREAM_DIR/proton/fqdn-proton.lst" ]; then
  fqdn_preserve="$TMP_DIR/fqdn-proton.lst.preserve"
  cp -f "$UPSTREAM_DIR/proton/fqdn-proton.lst" "$fqdn_preserve"
fi

if [ "$UPSTREAM_DIR" = "$SCRIPT_DIR/upstream" ]; then
  mkdir -p "$UPSTREAM_DIR"
  rm -rf "$UPSTREAM_DIR/proton" "$UPSTREAM_DIR/exit" "$UPSTREAM_DIR/countries"
  for legacy in "$UPSTREAM_DIR/"[a-z][a-z]; do
    [ -d "$legacy" ] || continue
    bn="$(basename "$legacy")"
    case "$bn" in
      ??) rm -rf "$legacy" ;;
    esac
  done
  if [ -d "$TMP_DIR/newroot" ]; then
    for child in "$TMP_DIR/newroot"/*; do
      [ -e "$child" ] || continue
      bn="$(basename "$child")"
      rm -rf "$UPSTREAM_DIR/$bn"
      mv "$child" "$UPSTREAM_DIR/"
    done
    rmdir "$TMP_DIR/newroot" 2>/dev/null || true
  fi
else
  rm -rf "$UPSTREAM_DIR"
  mkdir -p "$(dirname "$UPSTREAM_DIR")"
  mv "$TMP_DIR/newroot" "$UPSTREAM_DIR"
fi

if [ -n "$fqdn_preserve" ] && [ -f "$fqdn_preserve" ]; then
  mkdir -p "$UPSTREAM_DIR/proton"
  cp -f "$fqdn_preserve" "$UPSTREAM_DIR/proton/fqdn-proton.lst"
fi

# Сводные только внутри proton/, чтобы не попали в find по странам.
PROTON_ROOT="$UPSTREAM_DIR/proton"
agg4="$PROTON_ROOT/prefixes-ipv4-proton.lst"
agg6="$PROTON_ROOT/prefixes-ipv6-proton.lst"
say "[*] Сводные prefixes (все страны): $agg4, $agg6"
mkdir -p "$PROTON_ROOT"
tmp4="${agg4}.tmp.$$"
tmp6="${agg6}.tmp.$$"
: > "$tmp4"
: > "$tmp6"
if [ -d "$PROTON_ROOT" ]; then
  find "$PROTON_ROOT" -mindepth 2 -maxdepth 2 -type f \( -name 'prefixes-ipv4-*.lst' -o -name 'prefixes-ipv4.lst' \) 2>/dev/null | sort | while IFS= read -r f; do
    [ -f "$f" ] || continue
    cat "$f"
  done | sort -u > "$tmp4"
  find "$PROTON_ROOT" -mindepth 2 -maxdepth 2 -type f \( -name 'prefixes-ipv6-*.lst' -o -name 'prefixes-ipv6.lst' \) 2>/dev/null | sort | while IFS= read -r f; do
    [ -f "$f" ] || continue
    cat "$f"
  done | sort -u > "$tmp6"
fi
mv -f "$tmp4" "$agg4"
mv -f "$tmp6" "$agg6"

# Старый канон: сводные в корне upstream/ — удалить, если остались.
rm -f "$UPSTREAM_DIR/prefixes-ipv4-proton.lst" "$UPSTREAM_DIR/prefixes-ipv6-proton.lst" 2>/dev/null || true

say "[✓] Готово: $UPSTREAM_DIR"
