#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"
COMMON_SH="$ROOT_DIR/lib/common.sh"

[ -f "$COMMON_SH" ] || {
  echo "[!] Не найден common.sh: $COMMON_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"

UPSTREAM_DIR="${UPSTREAM_DIR:-$SCRIPT_DIR/upstream}"

main() {
  say "[*] user: локальный upstream, обновление не требуется"

  DIR="$UPSTREAM_DIR/custom"
  FILE="$DIR/fqdn-custom.lst"

  mkdir -p "$DIR"

  if [ ! -f "$FILE" ]; then
    say "[*] Создаю пустой список: $FILE"
    : > "$FILE"
  else
    say "[*] Список уже существует: $FILE (не изменяется)"
  fi

  say "[*] Готово: $UPSTREAM_DIR"
}

main "$@"
