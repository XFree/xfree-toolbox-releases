#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
CODE_ROOT="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
# Tests/sandbox: XFREE_ROOT_DIR points at a temp toolbox tree so orphans are
# never deleted from the git working copy of profile-templates/.
ROOT_DIR="${XFREE_ROOT_DIR:-${XFREE_TOOLBOX_ROOT:-$CODE_ROOT}}"

_lib_root="$CODE_ROOT"
[ -f "$_lib_root/lib/common.sh" ] || _lib_root="$ROOT_DIR"
[ -f "$_lib_root/lib/common.sh" ] && . "$_lib_root/lib/common.sh"
[ -f "$_lib_root/lib/upstreams.sh" ] && . "$_lib_root/lib/upstreams.sh"
unset _lib_root

# profiles — все profiles/<name>/ (роутер); templates — все profile-templates/<name>/ (profile-generator).
# XFREE_UPSTREAM_DRIFT_TEMPLATE — необязательный фильтр одного шаблона (profile-generator п.6).
DRIFT_MODE="${XFREE_UPSTREAM_DRIFT_MODE:-profiles}"
case "$DRIFT_MODE" in
    profiles | templates) ;;
    *)
        printf '[!] Invalid XFREE_UPSTREAM_DRIFT_MODE=%s (expected profiles or templates)\n' "$DRIFT_MODE" >&2
        exit 2
        ;;
esac

DRIFT_TEMPLATE=""
if [ -n "${XFREE_UPSTREAM_DRIFT_TEMPLATE:-}" ]; then
    DRIFT_TEMPLATE="$(printf '%s' "$XFREE_UPSTREAM_DRIFT_TEMPLATE" | tr -cd 'A-Za-z0-9._-')"
    if [ -z "$DRIFT_TEMPLATE" ]; then
        printf '[!] Invalid XFREE_UPSTREAM_DRIFT_TEMPLATE=%s\n' "$XFREE_UPSTREAM_DRIFT_TEMPLATE" >&2
        exit 2
    fi
fi

IFACE_STATE_DIR="${IFACE_STATE_DIR:-${XFREE_IFACE_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/iface-routing}/state/interfaces}"
DNS_STATE_DIR="${DNS_STATE_DIR:-${XFREE_DNS_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/dns-routing}/state/dns}"
ZAPRET_STATE_SECTIONS_DIR="${ZAPRET_STATE_SECTIONS_DIR:-${XFREE_ZAPRET_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/zapret}/state/sections}"

TMP_DIR="${TMPDIR:-/tmp}/check-upstream-updates.$$"
ENTITIES_TSV="$TMP_DIR/entities.tsv"
FILES_TSV="$TMP_DIR/files.tsv"
STATE_CHANGES="$TMP_DIR/state-changes.tsv"
PROFILE_CHANGES="$TMP_DIR/profile-changes.tsv"
TEMPLATE_CHANGES="$TMP_DIR/template-changes.tsv"
WARNINGS_FILE="$TMP_DIR/warnings.txt"
ORPHANS_FILE="$TMP_DIR/orphans.txt"

HAS_STATE_CHANGES=0
HAS_PROFILE_CHANGES=0
HAS_TEMPLATE_CHANGES=0
HAS_WARNINGS=0
HAS_ORPHANS=0
DETAILS=0
DETAILS_MAX_LINES="${DETAILS_MAX_LINES:-20}"
WRITE_DRIFT_DIR=""

while [ "$#" -gt 0 ]; do
    case "$1" in
        --details)
            DETAILS=1
            ;;
        --details-max-lines)
            shift
            [ "$#" -gt 0 ] || {
                printf '[!] Missing value for --details-max-lines\n' >&2
                exit 2
            }
            DETAILS_MAX_LINES="$1"
            ;;
        --write-drift-dir)
            shift
            [ "$#" -gt 0 ] || {
                printf '[!] Missing value for --write-drift-dir\n' >&2
                exit 2
            }
            WRITE_DRIFT_DIR="$1"
            ;;
        *)
            printf '[!] Unknown argument: %s\n' "$1" >&2
            exit 2
            ;;
    esac
    shift
done

cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT INT TERM

mkdir -p "$TMP_DIR"
: > "$STATE_CHANGES"
: > "$PROFILE_CHANGES"
: > "$TEMPLATE_CHANGES"
: > "$WARNINGS_FILE"
: > "$ORPHANS_FILE"
upstreams_build_model_tsv "$ROOT_DIR" "$ENTITIES_TSV" "$FILES_TSV"

normalize_file() {
    src="$1"
    dst="$2"

    if [ -f "$src" ]; then
        tr -d '\r' < "$src" | sed '/^[[:space:]]*$/d' | sort -u > "$dst"
    else
        : > "$dst"
    fi
}

lookup_source_by_dest() {
    target_type="$1"
    kind="$2"
    dest_name="$3"
    requested_family=""
    original_name="$dest_name"

    if [ "$target_type" = "iface" ]; then
        case "$original_name" in
            *__ipv4.lst) requested_family="ipv4" ;;
            *__ipv6.lst) requested_family="ipv6" ;;
        esac
    fi

    if command -v upstreams_dematerialize_target_name >/dev/null 2>&1; then
        demat="$(upstreams_dematerialize_target_name "$target_type" "$kind" "$dest_name")"
        kind="${demat%%|*}"
        dest_name="${demat#*|}"
    fi

    awk -F'|' -v want_kind="$kind" -v want_dst="$dest_name" -v want_family="$requested_family" '
        function base(path,   n, a) {
            n = split(path, a, "/")
            return a[n]
        }
        function family_ok(path, fam, b) {
            if (fam == "") return 1
            b = base(path)
            if (fam == "ipv4") return (b ~ /^prefixes-ipv4-/ || b ~ /__ipv4(\.lst)?$/)
            if (fam == "ipv6") return (b ~ /^prefixes-ipv6-/ || b ~ /__ipv6(\.lst)?$/)
            return 1
        }
        $2 == want_kind && $4 == want_dst && family_ok($3, want_family) {
            print $3
            exit
        }
    ' "$FILES_TSV"
}

mark_warning() {
    HAS_WARNINGS=1
    printf '%s\n' "$1" >> "$WARNINGS_FILE"
}

# Materialized target without a resolvable upstream source → remove (orphan).
remove_orphan_target() {
    label_scope="$1"
    target_type="$2"
    entity="$3"
    dest_name="$4"
    target_path="$5"
    reason="$6"

    if [ -f "$target_path" ]; then
        rm -f "$target_path" || {
            mark_warning "[WARN] [$label_scope][$target_type:$entity] не удалось удалить сироту: $dest_name ($reason)"
            return 0
        }
    fi

    HAS_ORPHANS=1
    printf '[REMOVED] [%s][%s:%s] %s (%s)\n' \
        "$label_scope" "$target_type" "$entity" "$dest_name" "$reason" >> "$ORPHANS_FILE"
}

record_change() {
    scope="$1"
    container="$2"
    target_type="$3"
    entity="$4"
    kind="$5"
    dest_name="$6"
    src_path="$7"
    target_path="$8"

    case "$scope" in
        state)
            HAS_STATE_CHANGES=1
            printf '%s|%s|%s|%s|%s|%s\n' \
                "$target_type" "$entity" "$kind" "$dest_name" "$src_path" "$target_path" >> "$STATE_CHANGES"
            ;;
        profile)
            HAS_PROFILE_CHANGES=1
            printf '%s|%s|%s|%s|%s|%s|%s\n' \
                "$container" "$target_type" "$entity" "$kind" "$dest_name" "$src_path" "$target_path" >> "$PROFILE_CHANGES"
            ;;
        template)
            HAS_TEMPLATE_CHANGES=1
            printf '%s|%s|%s|%s|%s|%s|%s\n' \
                "$container" "$target_type" "$entity" "$kind" "$dest_name" "$src_path" "$target_path" >> "$TEMPLATE_CHANGES"
            ;;
    esac
}

check_one_file() {
    scope="$1"
    container="$2"
    target_type="$3"
    entity="$4"
    kind="$5"
    target_path="$6"

    [ -f "$target_path" ] || return 0

    dest_name="$(basename "$target_path")"
    src_path="$(lookup_source_by_dest "$target_type" "$kind" "$dest_name" || true)"

    label_scope="$scope"
    if [ -n "${container:-}" ]; then
        label_scope="$scope:$container"
    fi

    if [ -z "${src_path:-}" ]; then
        remove_orphan_target "$label_scope" "$target_type" "$entity" "$dest_name" "$target_path" \
            "upstream source not found"
        return 0
    fi

    if [ ! -f "$src_path" ]; then
        remove_orphan_target "$label_scope" "$target_type" "$entity" "$dest_name" "$target_path" \
            "upstream file missing: $src_path"
        return 0
    fi

    src_norm="$TMP_DIR/src.norm.$$"
    tgt_norm="$TMP_DIR/tgt.norm.$$"
    normalize_file "$src_path" "$src_norm"
    normalize_file "$target_path" "$tgt_norm"

    if ! cmp -s "$src_norm" "$tgt_norm"; then
        record_change "$scope" "$container" "$target_type" "$entity" "$kind" "$dest_name" "$src_path" "$target_path"
    fi
}

check_iface_tree() {
    scope="$1"
    container="$2"
    base_dir="$3"

    [ -d "$base_dir" ] || return 0

    for iface_dir in "$base_dir"/*; do
        [ -d "$iface_dir" ] || continue
        iface="$(basename "$iface_dir")"

        fqdn_dir="$iface_dir/fqdn.d"
        if [ -d "$fqdn_dir" ]; then
            for f in "$fqdn_dir"/*.lst; do
                [ -f "$f" ] || continue
                check_one_file "$scope" "$container" "iface" "$iface" "fqdn" "$f"
            done
        fi

        prefix_dir="$iface_dir/prefixes.d"
        if [ -d "$prefix_dir" ]; then
            for f in "$prefix_dir"/*.lst; do
                [ -f "$f" ] || continue
                check_one_file "$scope" "$container" "iface" "$iface" "prefix" "$f"
            done
        fi
    done
}

check_dns_tree() {
    scope="$1"
    container="$2"
    base_dir="$3"

    [ -d "$base_dir" ] || return 0

    for dns_dir in "$base_dir"/*; do
        [ -d "$dns_dir" ] || continue
        dns_id="$(basename "$dns_dir")"
        fqdn_dir="$dns_dir/fqdn.d"
        [ -d "$fqdn_dir" ] || continue

        for f in "$fqdn_dir"/*.lst; do
            [ -f "$f" ] || continue
            check_one_file "$scope" "$container" "dns" "$dns_id" "fqdn" "$f"
        done
    done
}

check_zapret_tree() {
    scope="$1"
    container="$2"
    base_dir="$3"

    [ -d "$base_dir" ] || return 0

    for section_dir in "$base_dir"/*; do
        [ -d "$section_dir" ] || continue
        section="$(basename "$section_dir")"

        fqdn_dir="$section_dir/fqdn.d"
        if [ -d "$fqdn_dir" ]; then
            for f in "$fqdn_dir"/*.lst; do
                [ -f "$f" ] || continue
                check_one_file "$scope" "$container" "zapret" "$section" "fqdn" "$f"
            done
        fi

        prefix_dir="$section_dir/prefixes.d"
        if [ -d "$prefix_dir" ]; then
            for f in "$prefix_dir"/*.lst; do
                [ -f "$f" ] || continue
                check_one_file "$scope" "$container" "zapret" "$section" "prefix" "$f"
            done
        fi
    done
}

check_materialized_root() {
    scope="$1"
    container="$2"
    root_path="$3"

    check_iface_tree "$scope" "$container" "$root_path/iface-routing/interfaces"
    check_dns_tree "$scope" "$container" "$root_path/dns-routing/dns"
    check_zapret_tree "$scope" "$container" "$root_path/zapret/sections"
}

check_all_profiles() {
    profiles_dir="$(common_profiles_dir "$ROOT_DIR")"
    names_file="$TMP_DIR/profile-names.list"
    common_list_profile_dirnames "$ROOT_DIR" > "$names_file"
    while IFS= read -r profile_name || [ -n "${profile_name:-}" ]; do
        [ -n "$profile_name" ] || continue
        check_materialized_root "profile" "$profile_name" "$profiles_dir/$profile_name"
    done < "$names_file"
}

check_all_templates() {
    templates_dir="$(common_profile_templates_dir "$ROOT_DIR")"
    if [ -n "$DRIFT_TEMPLATE" ]; then
        if [ ! -d "$templates_dir/$DRIFT_TEMPLATE" ]; then
            printf '[!] XFREE_UPSTREAM_DRIFT_TEMPLATE=%s: каталог не найден: %s/%s\n' \
                "$DRIFT_TEMPLATE" "$templates_dir" "$DRIFT_TEMPLATE" >&2
            exit 2
        fi
        check_materialized_root "template" "$DRIFT_TEMPLATE" "$templates_dir/$DRIFT_TEMPLATE"
        return 0
    fi
    names_file="$TMP_DIR/template-names.list"
    common_list_profile_template_dirnames "$ROOT_DIR" > "$names_file"
    while IFS= read -r template_name || [ -n "${template_name:-}" ]; do
        [ -n "$template_name" ] || continue
        check_materialized_root "template" "$template_name" "$templates_dir/$template_name"
    done < "$names_file"
}

print_changes_block() {
    title="$1"
    file="$2"
    with_container="$3"

    if [ ! -s "$file" ]; then
        printf '%s\n' "$title"
        printf '  - нет изменений\n'
        return 0
    fi

    printf '%s\n' "$title"
    if [ "$with_container" -eq 1 ]; then
        awk -F'|' '
            {
                printf "  - %s / %s/%s %s: %s\n", $1, $2, $3, $4, $5
            }
        ' "$file"
    else
        awk -F'|' '
            {
                printf "  - %s/%s %s: %s\n", $1, $2, $3, $4
            }
        ' "$file"
    fi
}

print_one_detail() {
    target_type="$1"
    entity="$2"
    kind="$3"
    dest_name="$4"
    src_path="$5"
    target_path="$6"
    label_prefix="${7:-}"

    src_norm="$TMP_DIR/detail-src.$$"
    target_norm="$TMP_DIR/detail-target.$$"
    added_tmp="$TMP_DIR/detail-added.$$"
    removed_tmp="$TMP_DIR/detail-removed.$$"

    normalize_file "$src_path" "$src_norm"
    normalize_file "$target_path" "$target_norm"

    awk '
        NR == FNR { seen[$0]=1; next }
        !($0 in seen) { print }
    ' "$target_norm" "$src_norm" > "$added_tmp"

    awk '
        NR == FNR { seen[$0]=1; next }
        !($0 in seen) { print }
    ' "$src_norm" "$target_norm" > "$removed_tmp"

    if [ -n "$label_prefix" ]; then
        printf '  - %s%s/%s %s: %s\n' "$label_prefix" "$target_type" "$entity" "$kind" "$dest_name"
    else
        printf '  - %s/%s %s: %s\n' "$target_type" "$entity" "$kind" "$dest_name"
    fi

    if [ -s "$added_tmp" ]; then
        printf '    + added in upstream (first %s):\n' "$DETAILS_MAX_LINES"
        sed -n "1,${DETAILS_MAX_LINES}p" "$added_tmp" | sed 's/^/      + /'
    else
        printf '    + added in upstream: none\n'
    fi

    if [ -s "$removed_tmp" ]; then
        printf '    - removed from upstream (first %s):\n' "$DETAILS_MAX_LINES"
        sed -n "1,${DETAILS_MAX_LINES}p" "$removed_tmp" | sed 's/^/      - /'
    else
        printf '    - removed from upstream: none\n'
    fi
}

print_details_block() {
    title="$1"
    file="$2"
    with_container="$3"

    [ "$DETAILS" -eq 1 ] || return 0
    [ -s "$file" ] || return 0

    echo
    printf '%s\n' "$title"
    if [ "$with_container" -eq 1 ]; then
        while IFS='|' read -r container target_type entity kind dest_name src_path target_path; do
            [ -n "${target_type:-}" ] || continue
            print_one_detail "$target_type" "$entity" "$kind" "$dest_name" "$src_path" "$target_path" "${container} / "
        done < "$file"
    else
        while IFS='|' read -r target_type entity kind dest_name src_path target_path; do
            [ -n "${target_type:-}" ] || continue
            print_one_detail "$target_type" "$entity" "$kind" "$dest_name" "$src_path" "$target_path" ""
        done < "$file"
    fi
}

print_report() {
    echo "Проверка upstream-изменений (режим: $DRIFT_MODE):"
    case "$DRIFT_MODE" in
        profiles)
            echo "  profiles: $(common_profiles_dir "$ROOT_DIR")"
            ;;
        templates)
            echo "  templates: $(common_profile_templates_dir "$ROOT_DIR")"
            if [ -n "$DRIFT_TEMPLATE" ]; then
                echo "  filter: $DRIFT_TEMPLATE"
            fi
            ;;
    esac
    echo

    if [ "$DRIFT_MODE" = "profiles" ]; then
        print_changes_block "Новые списки для примененного состояния (state):" "$STATE_CHANGES" 0
        echo
        print_changes_block "Новые списки для профилей (profiles):" "$PROFILE_CHANGES" 1
        print_details_block "Детальный diff для state:" "$STATE_CHANGES" 0
        print_details_block "Детальный diff для profiles:" "$PROFILE_CHANGES" 1
    else
        print_changes_block "Новые списки для шаблонов (profile-templates):" "$TEMPLATE_CHANGES" 1
        print_details_block "Детальный diff для templates:" "$TEMPLATE_CHANGES" 1
    fi

    if [ -s "$ORPHANS_FILE" ]; then
        echo
        echo "Удалены сироты (нет upstream source):"
        sed 's/^/  - /' "$ORPHANS_FILE"
    fi

    if [ -s "$WARNINGS_FILE" ]; then
        echo
        echo "Предупреждения:"
        sed 's/^/  - /' "$WARNINGS_FILE"
    fi

    orphan_n=0
    warn_n=0
    drift_n=0
    [ -s "$ORPHANS_FILE" ] && orphan_n="$(wc -l < "$ORPHANS_FILE" | tr -d ' ')"
    [ -s "$WARNINGS_FILE" ] && warn_n="$(wc -l < "$WARNINGS_FILE" | tr -d ' ')"
    if [ "$DRIFT_MODE" = "profiles" ]; then
        [ -s "$STATE_CHANGES" ] && drift_n=$((drift_n + $(wc -l < "$STATE_CHANGES" | tr -d ' ')))
        [ -s "$PROFILE_CHANGES" ] && drift_n=$((drift_n + $(wc -l < "$PROFILE_CHANGES" | tr -d ' ')))
    else
        [ -s "$TEMPLATE_CHANGES" ] && drift_n="$(wc -l < "$TEMPLATE_CHANGES" | tr -d ' ')"
    fi
    echo
    printf '[*] Итог проверки: к обновлению=%s, сирот удалено=%s, предупреждений=%s\n' \
        "$drift_n" "$orphan_n" "$warn_n"
}

if [ "$DRIFT_MODE" = "profiles" ]; then
    check_iface_tree "state" "" "$IFACE_STATE_DIR"
    check_dns_tree "state" "" "$DNS_STATE_DIR"
    check_zapret_tree "state" "" "$ZAPRET_STATE_SECTIONS_DIR"
    check_all_profiles
else
    check_all_templates
fi

if [ -n "${WRITE_DRIFT_DIR:-}" ]; then
    mkdir -p "$WRITE_DRIFT_DIR"
    if [ "$DRIFT_MODE" = "profiles" ]; then
        cp "$STATE_CHANGES" "$WRITE_DRIFT_DIR/state.tsv"
        cp "$PROFILE_CHANGES" "$WRITE_DRIFT_DIR/profile.tsv"
    else
        cp "$TEMPLATE_CHANGES" "$WRITE_DRIFT_DIR/template.tsv"
    fi
    if [ -s "$ORPHANS_FILE" ]; then
        cp "$ORPHANS_FILE" "$WRITE_DRIFT_DIR/orphans.txt"
    fi
fi

print_report

if [ "$DRIFT_MODE" = "profiles" ]; then
    if [ "$HAS_STATE_CHANGES" -eq 1 ] || [ "$HAS_PROFILE_CHANGES" -eq 1 ]; then
        exit 10
    fi
else
    if [ "$HAS_TEMPLATE_CHANGES" -eq 1 ]; then
        exit 10
    fi
fi

if [ "$HAS_WARNINGS" -eq 1 ]; then
    exit 11
fi

# Orphans already removed; exit 0 (informational section in report).
exit 0
