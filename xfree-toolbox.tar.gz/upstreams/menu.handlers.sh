#!/bin/sh
# Hand-written handlers for cli.run component=custom in upstreams/menu.yaml.
# shellcheck shell=sh

UPSTREAMS_MODULE_DIR="${ROOT_DIR:+$ROOT_DIR/upstreams}"

need_whiptail() {
	ui_have_whiptail || {
		ui_msgbox "Ошибка" "whiptail не установлен"
		return 1
	}
}

upstreams_pipeline_headless_p() {
	[ "${XFREE_PIPELINE_HEADLESS:-0}" = "1" ]
}

upstream_invoke_with_output() {
	_title="$1"
	shift
	if upstreams_pipeline_headless_p; then
		printf '[*] %s\n' "$_title" >&2
		"$@"
		return $?
	fi
	ui_menu_invoke_with_output "$_title" "$@"
}

upstream_ui_fail() {
	_title="$1"
	_msg="$2"
	if upstreams_pipeline_headless_p; then
		printf '[-] %s: %s\n' "$_title" "$_msg" >&2
		return 1
	fi
	ui_msgbox "$_title" "$_msg"
	return 1
}

build_enabled_modules_map() {
	map_file="$1"
	: > "$map_file"

	idx=0
	upstreams_list_modules_tsv "${UPSTREAMS_MODULE_DIR:-$SCRIPT_DIR}" | while IFS="$(printf '\t')" read -r name title desc script upstream_dir conf_file; do
		[ -n "$name" ] || continue
		idx=$((idx + 1))
		tag="$(printf 'M%03d' "$idx")"
		printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
			"$tag" "$name" "$title" "$desc" "$script" "$upstream_dir" "$conf_file" >> "$map_file"
	done
}

build_all_modules_map() {
	map_file="$1"
	: > "$map_file"

	idx=0
	upstreams_list_all_modules_tsv "${UPSTREAMS_MODULE_DIR:-$SCRIPT_DIR}" | while IFS="$(printf '\t')" read -r name title desc enabled script upstream_dir conf_file; do
		[ -n "$name" ] || continue
		idx=$((idx + 1))
		tag="$(printf 'M%03d' "$idx")"
		printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
			"$tag" "$name" "$title" "$desc" "$enabled" "$script" "$upstream_dir" "$conf_file" >> "$map_file"
	done
}

get_proton_module_conf() {
	map="$UI_TMP_ROOT/modules-all-for-proton.tsv"
	build_all_modules_map "$map"

	awk -F '\t' '$2 == "proton" { print $8; exit }' "$map"
}

get_proton_use_free_only() {
	conf_file="$(get_proton_module_conf || true)"
	val=1
	if [ -n "${conf_file:-}" ] && [ -f "$conf_file" ]; then
		v="$(awk -F= '
			/^[[:space:]]*PROTON_USE_FREE_ONLY=/ {
				v=$2
				sub(/^[[:space:]]*/, "", v)
				sub(/[[:space:]]*$/, "", v)
				gsub(/^"/, "", v); gsub(/"$/, "", v)
				gsub(/^'\''/, "", v); gsub(/'\''$/, "", v)
				print v
				exit
			}
		' "$conf_file" || true)"
		case "${v:-1}" in
			0|no|NO|false|FALSE) val=0 ;;
			*) val=1 ;;
		esac
	fi
	printf '%s\n' "$val"
}

set_proton_use_free_only() {
	val="$1"
	case "$val" in
		0|1) ;;
		*) return 1 ;;
	esac
	conf_file="$(get_proton_module_conf || true)"
	[ -n "${conf_file:-}" ] && [ -f "$conf_file" ] || return 0

	tmp_file="${conf_file}.tmp.$$"

	if grep -q '^[[:space:]]*PROTON_USE_FREE_ONLY=' "$conf_file" 2>/dev/null; then
		sed "s|^[[:space:]]*PROTON_USE_FREE_ONLY=.*|PROTON_USE_FREE_ONLY=\"$val\"|" "$conf_file" > "$tmp_file"
	else
		cat "$conf_file" > "$tmp_file"
		printf '\nPROTON_USE_FREE_ONLY="%s"\n' "$val" >> "$tmp_file"
	fi

	mv "$tmp_file" "$conf_file"
}

select_proton_tier_filter() {
	need_whiptail || return 0

	conf_file="$(get_proton_module_conf || true)"
	[ -n "${conf_file:-}" ] || {
		ui_msgbox "Upstreams" "Upstream proton не найден."
		return 0
	}

	pick="$(ui_menu "Proton — фильтр серверов" "Что включать в prefixes при update-lists?

Списки IP всегда через гостевую сессию (как WARP).
Гостевая / постоянная для .conf — меню Proton (генератор конфигов)." 20 78 6 \
		"1" "Только бесплатные (Tier=0)" \
		"0" "Все tier (free+paid)" || true)"
	[ -n "${pick:-}" ] || return 0

	set_proton_use_free_only "$pick" || return 0

	case "$pick" in
		1) ui_msgbox "Upstreams" "Сохранено: только бесплатные серверы (PROTON_USE_FREE_ONLY=1)." ;;
		*) ui_msgbox "Upstreams" "Сохранено: все tier (PROTON_USE_FREE_ONLY=0)." ;;
	esac
}

update_selected_modules() {
	if ! upstreams_pipeline_headless_p; then
		need_whiptail || return 0
	fi

	map="$UI_TMP_ROOT/modules-enabled.tsv"
	build_enabled_modules_map "$map"

	[ -s "$map" ] || {
		if upstreams_pipeline_headless_p; then
			printf '[*] Upstreams: нет активированных upstream-модулей\n' >&2
			return 0
		fi
		ui_msgbox "Upstreams" "Нет активированных upstream-модулей."
		return 0
	}

	if upstreams_pipeline_headless_p; then
		upd_n=0
		idx_ok=0
		idx_fail=0
		while IFS="$(printf '\t')" read -r tag name title desc script upstream_dir conf_file; do
			[ -n "$tag" ] || continue
			pretty="$(printf '%s' "$title" | tr -d '\r')"
			printf '[*] %s\n' "$pretty" >&2
			_upd_rc=0
			if [ "$name" = "proton" ]; then
				sh "$script" --acquire-guest || _upd_rc=$?
			else
				sh "$script" || _upd_rc=$?
			fi
			if [ "$_upd_rc" -ne 0 ]; then
				printf '[!] %s: обновление не удалось (оставляю списки из пакета)\n' "$pretty" >&2
			fi
			upd_n=$((upd_n + 1))
			printf '[*] Индекс: %s\n' "$pretty" >&2
			if [ -d "$upstream_dir" ] && upstreams_rebuild_module_index_for_data_dir "$upstream_dir"; then
				printf '[+] Индекс OK: %s\n' "$pretty" >&2
				idx_ok=$((idx_ok + 1))
			else
				printf '[!] Индекс FAILED: %s\n' "$pretty" >&2
				idx_fail=$((idx_fail + 1))
			fi
		done < "$map"
		printf '[*] Готово обновление: модулей=%s, индекс ok=%s, индекс fail=%s\n' \
			"$upd_n" "$idx_ok" "$idx_fail" >&2
		return 0
	fi

	cmds="$UI_TMP_ROOT/update_selected.sh"
	: > "$cmds"
	chmod +x "$cmds"

	{
		printf '#!/bin/sh\n'
		printf 'set -eu\n'
		printf '. %s\n' "'$ROOT_DIR/lib/upstreams.sh'"
		printf 'UPD_N=0\n'
		printf 'IDX_OK=0\n'
		printf 'IDX_FAIL=0\n'

		while IFS="$(printf '\t')" read -r tag name title desc script upstream_dir conf_file; do
			[ -n "$tag" ] || continue
			pretty="$(printf '%s' "$title" | tr -d '\r' | sed "s/'/'\\\\''/g")"
			printf 'printf "[*] %s\\n"\n' "$pretty"
			if [ "$name" = "proton" ]; then
				printf 'sh %s --acquire-guest || printf "%%s\\n" "[!] %s: обновление не удалось (оставляю списки из пакета)"\n' \
					"'$script'" "$pretty"
			else
				printf 'sh %s || printf "%%s\\n" "[!] %s: обновление не удалось (оставляю списки из пакета)"\n' \
					"'$script'" "$pretty"
			fi
			printf 'UPD_N=$((UPD_N + 1))\n'
			printf 'printf "[*] Индекс: %s\\n"\n' "$pretty"
			printf 'if [ -d %s ] && upstreams_rebuild_module_index_for_data_dir %s; then\n' \
				"'$upstream_dir'" "'$upstream_dir'"
			printf '  printf "[+] Индекс OK: %s\\n"\n' "$pretty"
			printf '  IDX_OK=$((IDX_OK + 1))\n'
			printf 'else\n'
			printf '  printf "[!] Индекс FAILED: %s\\n"\n' "$pretty"
			printf '  IDX_FAIL=$((IDX_FAIL + 1))\n'
			printf 'fi\n'
		done < "$map"

		printf 'printf "[*] Готово обновление: модулей=%%s, индекс ok=%%s, индекс fail=%%s\\n" "$UPD_N" "$IDX_OK" "$IDX_FAIL"\n'
	} > "$cmds"

	# В textbox — только строка «Готово обновление»; полный лог уже в консоли (batch/live).
	_prev_dlg_sum="${UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY-}"
	UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY=1
	export UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY
	ui_menu_invoke_with_output "Обновление активных upstream" sh "$cmds" || true
	if [ -n "${_prev_dlg_sum}" ]; then
		UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY="$_prev_dlg_sum"
		export UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY
	else
		unset UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY || true
	fi
}

reindex_upstream_sources() {
	map="$UI_TMP_ROOT/modules-all-for-index.tsv"
	build_all_modules_map "$map"

	[ -s "$map" ] || {
		if upstreams_pipeline_headless_p; then
			printf '[*] Upstreams: нет модулей для переиндексации\n' >&2
			return 0
		fi
		ui_msgbox "Upstreams" "Не найдено upstream-модулей для переиндексации."
		return 0
	}

	if upstreams_pipeline_headless_p; then
		idx_ok=0
		idx_fail=0
		idx_skip=0
		while IFS="$(printf '\t')" read -r tag name title desc enabled script upstream_dir conf_file; do
			[ -n "$tag" ] || continue
			pretty="$(printf '%s' "$title" | tr -d '\r')"
			printf '[*] Индекс: %s\n' "$pretty" >&2
			if [ ! -d "$upstream_dir" ]; then
				printf '[!] Индекс SKIP (нет каталога): %s\n' "$pretty" >&2
				idx_skip=$((idx_skip + 1))
				continue
			fi
			if upstreams_rebuild_module_index_for_data_dir "$upstream_dir"; then
				printf '[+] Индекс OK: %s\n' "$pretty" >&2
				idx_ok=$((idx_ok + 1))
			else
				printf '[!] Индекс FAILED: %s\n' "$pretty" >&2
				idx_fail=$((idx_fail + 1))
				return 1
			fi
		done < "$map"
		printf '[*] Готово индекс: ok=%s, fail=%s, skip=%s\n' "$idx_ok" "$idx_fail" "$idx_skip" >&2
		return 0
	fi

	cmds="$UI_TMP_ROOT/reindex_upstreams.sh"
	: > "$cmds"
	chmod +x "$cmds"

	{
		printf '#!/bin/sh\n'
		printf 'set -eu\n'
		printf '. %s\n' "'$ROOT_DIR/lib/upstreams.sh'"
		printf 'IDX_OK=0\n'
		printf 'IDX_FAIL=0\n'
		printf 'IDX_SKIP=0\n'

		while IFS="$(printf '\t')" read -r tag name title desc enabled script upstream_dir conf_file; do
			[ -n "$tag" ] || continue
			pretty="$(printf '%s' "$title" | tr -d '\r' | sed "s/'/'\\\\''/g")"
			printf 'printf "[*] Индекс: %s\\n"\n' "$pretty"
			# Не использовать «|| continue»: вне цикла ash даёт exit 2 при отсутствии каталога.
			printf 'if [ ! -d %s ]; then\n' "'$upstream_dir'"
			printf '  printf "[!] Индекс SKIP (нет каталога): %s\\n"\n' "$pretty"
			printf '  IDX_SKIP=$((IDX_SKIP + 1))\n'
			printf 'elif upstreams_rebuild_module_index_for_data_dir %s; then\n' "'$upstream_dir'"
			printf '  printf "[+] Индекс OK: %s\\n"\n' "$pretty"
			printf '  IDX_OK=$((IDX_OK + 1))\n'
			printf 'else\n'
			printf '  printf "[!] Индекс FAILED: %s\\n"\n' "$pretty"
			printf '  IDX_FAIL=$((IDX_FAIL + 1))\n'
			printf '  exit 1\n'
			printf 'fi\n'
		done < "$map"

		printf 'printf "[*] Готово индекс: ok=%%s, fail=%%s, skip=%%s\\n" "$IDX_OK" "$IDX_FAIL" "$IDX_SKIP"\n'
	} > "$cmds"

	ui_menu_invoke_with_output "Переиндексация upstream source-списков" sh "$cmds" || true
}

toggle_modules_enabled() {
	need_whiptail || return 0

	map="$UI_TMP_ROOT/modules-all.tsv"
	build_all_modules_map "$map"

	set --
	while IFS="$(printf '\t')" read -r tag name title desc enabled script upstream_dir conf_file; do
		[ -n "$tag" ] || continue

		pretty="$(printf '%s' "$title" | tr -d '\r')"
		desc_clean="$(printf '%s' "$desc" | tr -d '\r')"

		if [ -n "$desc_clean" ]; then
			pretty="$pretty — $desc_clean"
		fi

		state="OFF"
		[ "$enabled" = "1" ] && state="ON"

		set -- "$@" "$tag" "$pretty" "$state"
	done < "$map"

	[ "$#" -gt 0 ] || {
		ui_msgbox "Upstreams" "Не найдено ни одного upstream-модуля."
		return 0
	}

	checklist_rc=0
	selected="$(
		ui_checklist \
			"Выбор upstream" \
			"Отметьте upstream, которые должны быть включены" \
			20 100 12 \
			"$@"
	)" || checklist_rc=$?
	[ "$checklist_rc" -eq 0 ] || return 0

	selected_clean="$(printf '%s' "${selected:-}" | tr -d '"')"

	cmds="$UI_TMP_ROOT/toggle_modules.sh"
	: > "$cmds"
	chmod +x "$cmds"

	{
		printf '#!/bin/sh\n'
		printf 'set -eu\n'

		while IFS="$(printf '\t')" read -r tag name title desc enabled script upstream_dir conf_file; do
			[ -n "$tag" ] || continue

			new_enabled=0
			for selected_tag in $selected_clean; do
				if [ "$selected_tag" = "$tag" ]; then
					new_enabled=1
					break
				fi
			done

			printf 'conf_file=%s\n' "'$conf_file'"
			printf 'tmp_file=${conf_file}.tmp.$$ \n'
			printf 'printf "[*] %s -> %s\\n"\n' \
				"$(printf '%s' "$title" | tr -d '\r' | sed "s/'/'\\\\''/g")" \
				"$new_enabled"
			printf 'if grep -q %s "$conf_file" 2>/dev/null; then\n' "'^[[:space:]]*UPSTREAM_ENABLED='"
			printf '  sed %s "$conf_file" > "$tmp_file"\n' "'s/^[[:space:]]*UPSTREAM_ENABLED=.*/UPSTREAM_ENABLED=\"$new_enabled\"/'"
			printf 'else\n'
			printf '  cat "$conf_file" > "$tmp_file"\n'
			printf '  printf %s >> "$tmp_file"\n' "'\\nUPSTREAM_ENABLED=\"$new_enabled\"\\n'"
			printf 'fi\n'
			printf 'mv "$tmp_file" "$conf_file"\n'
		done < "$map"
	} > "$cmds"

	ui_menu_invoke_with_output "Изменение состояния upstream" sh "$cmds" || true
}

upstream_drift_mode() {
	case "${XFREE_UPSTREAM_DRIFT_MODE:-profiles}" in
		templates) printf '%s\n' "templates" ;;
		*) printf '%s\n' "profiles" ;;
	esac
}

upstream_drift_build_labels_file() {
	drift_mode="$1"
	prof_tsv="$2"
	tmpl_tsv="$3"
	sta_tsv="$4"
	labels_file="$5"

	: > "$labels_file"
	if [ "$drift_mode" = "templates" ]; then
		[ -s "$tmpl_tsv" ] || return 0
		awk -F'|' 'NF>=7 && $1 != "" && $2 != "" && $3 != "" {
			k = "t:" $1 ":" $2 ":" $3
			if (!seen[k]++) print "Шаблон " $1 " — " $2 "/" $3
		}' "$tmpl_tsv" >> "$labels_file"
		return 0
	fi
	if [ -s "$prof_tsv" ]; then
		awk -F'|' 'NF>=7 && $1 != "" && $2 != "" && $3 != "" {
			k = "p:" $1 ":" $2 ":" $3
			if (!seen[k]++) print "Профиль " $1 " — " $2 "/" $3
		}' "$prof_tsv" >> "$labels_file"
	fi
	if [ -s "$sta_tsv" ]; then
		awk -F'|' 'NF>=6 && $1 != "" && $2 != "" {
			k = "s:" $1 ":" $2
			if (!seen[k]++) print "State — " $1 "/" $2
		}' "$sta_tsv" >> "$labels_file"
	fi
}

upstream_drift_build_selected_clean() {
	drift_mode="$1"
	prof_tsv="$2"
	tmpl_tsv="$3"
	sta_tsv="$4"

	if [ "$drift_mode" = "templates" ]; then
		awk -F'|' 'NF>=7 && $1 != "" && $2 != "" && $3 != "" {
			k = "t:" $1 ":" $2 ":" $3
			if (!seen[k]++) printf "%s ", k
		}' "$tmpl_tsv" | sed 's/ $//'
		return 0
	fi
	{
		if [ -s "$prof_tsv" ]; then
			awk -F'|' 'NF>=7 && $1 != "" && $2 != "" && $3 != "" {
				k = "p:" $1 ":" $2 ":" $3
				if (!seen[k]++) printf "%s ", k
			}' "$prof_tsv"
		fi
		if [ -s "$sta_tsv" ]; then
			awk -F'|' 'NF>=6 && $1 != "" && $2 != "" {
				k = "s:" $1 ":" $2
				if (!seen[k]++) printf "%s ", k
			}' "$sta_tsv"
		fi
	} | sed 's/ $//'
}

upstream_drift_apply_runtime_for_keys() {
	selected_clean="$1"
	apply_template_sh="$2"

	[ -f "$apply_template_sh" ] || return 0

	iface_hit=0
	dns_hit=0
	zap_csv=""
	for k in $selected_clean; do
		case "$k" in
			s:iface:*|p:*:iface:*)
				iface_hit=1
				;;
			s:dns:*|p:*:dns:*)
				dns_hit=1
				;;
			p:*:zapret:*)
				sec="${k##*:}"
				[ -n "$sec" ] || continue
				if [ -z "${zap_csv:-}" ]; then
					zap_csv="$sec"
				else
					zap_csv="$zap_csv,$sec"
				fi
				;;
			s:zapret:*)
				sec="${k#s:zapret:}"
				[ -n "$sec" ] || continue
				if [ -z "${zap_csv:-}" ]; then
					zap_csv="$sec"
				else
					zap_csv="$zap_csv,$sec"
				fi
				;;
		esac
	done
	[ "$iface_hit" = 1 ] || [ "$dns_hit" = 1 ] || [ -n "${zap_csv:-}" ] || return 0

	set -- sh "$apply_template_sh" --lists-runtime
	[ "$iface_hit" = 1 ] && set -- "$@" --rt-iface
	[ "$dns_hit" = 1 ] && set -- "$@" --rt-dns
	if [ -n "${zap_csv:-}" ]; then
		set -- "$@" --rt-zapret-sections "$zap_csv"
	fi
	UI_RUN_WITH_OUTPUT_OK_CODES="0" \
		upstream_invoke_with_output "Применение списков к runtime" "$@"
}

upstream_drift_apply_snapshot() {
	drift_mode="$1"
	prof_tsv="$2"
	tmpl_tsv="$3"
	sta_tsv="$4"
	apply_script="$5"
	apply_template_sh="$6"

	selected_clean="$(upstream_drift_build_selected_clean "$drift_mode" "$prof_tsv" "$tmpl_tsv" "$sta_tsv")"
	if [ -z "${selected_clean:-}" ]; then
		upstream_ui_fail "Upstream" "Не удалось сформировать список целей для применения."
		return 1
	fi

	drift_copy_rc=0
	if [ "$drift_mode" = "templates" ]; then
		if [ -n "${XFREE_UPSTREAM_DRIFT_TEMPLATE:-}" ]; then
			_apply_title="Применение обновлений → шаблон ${XFREE_UPSTREAM_DRIFT_TEMPLATE}"
		else
			_apply_title="Применение обновлений → шаблоны"
		fi
		UI_RUN_WITH_OUTPUT_OK_CODES="0" \
			upstream_invoke_with_output "$_apply_title" \
				sh "$apply_script" --template-tsv "$tmpl_tsv" --apply-all || drift_copy_rc=$?
		unset _apply_title || true
	elif [ -s "$sta_tsv" ]; then
		UI_RUN_WITH_OUTPUT_OK_CODES="0" \
			upstream_invoke_with_output "Применение обновлений → профиль/state" \
				sh "$apply_script" --profile-tsv "$prof_tsv" --state-tsv "$sta_tsv" --apply-all || drift_copy_rc=$?
	else
		UI_RUN_WITH_OUTPUT_OK_CODES="0" \
			upstream_invoke_with_output "Применение обновлений → профиль" \
				sh "$apply_script" --profile-tsv "$prof_tsv" --apply-all || drift_copy_rc=$?
	fi

	if [ "$drift_copy_rc" -ne 0 ]; then
		upstream_ui_fail "Upstream" "Не удалось применить обновления ($drift_mode).

Проверьте лог выше: copy failed / нет upstream-файла / profile-templates не доступен для записи."
		return "$drift_copy_rc"
	fi

	if [ "$drift_mode" = "profiles" ]; then
		upstream_drift_apply_runtime_for_keys "$selected_clean" "$apply_template_sh"
	fi
	return 0
}

# $1 = profiles|templates; $2 = auto_apply (1 — без confirm, для prelude в templates menu)
check_active_list_updates_one_mode() {
	drift_mode="$1"
	auto_apply="${2:-0}"

	if ! upstreams_pipeline_headless_p; then
		need_whiptail || return 0
	fi

	check_script="$ROOT_DIR/upstreams/check-upstream-updates.sh"
	apply_script="$ROOT_DIR/upstreams/apply-upstream-drift.sh"
	apply_template_sh="$ROOT_DIR/templates/apply-template.sh"

	[ -f "$check_script" ] || {
		upstream_ui_fail "Ошибка" "Не найден скрипт проверки:
$check_script"
		return 1
	}
	[ -f "$apply_script" ] || {
		upstream_ui_fail "Ошибка" "Не найден скрипт копирования drift:
$apply_script"
		return 1
	}

	[ -x "$check_script" ] || chmod +x "$check_script" 2>/dev/null || true
	[ -x "$apply_script" ] || chmod +x "$apply_script" 2>/dev/null || true
	if [ "$drift_mode" = "profiles" ]; then
		[ -f "$apply_template_sh" ] || {
			upstream_ui_fail "Ошибка" "Не найден apply-template:
$apply_template_sh"
			return 1
		}
		[ -x "$apply_template_sh" ] || chmod +x "$apply_template_sh" 2>/dev/null || true
	fi

	drift_dir="$UI_TMP_ROOT/upstream-drift-${drift_mode}.$$"
	mkdir -p "$drift_dir"
	prof_tsv="$drift_dir/profile.tsv"
	tmpl_tsv="$drift_dir/template.tsv"
	sta_tsv="$drift_dir/state.tsv"

	rc=0
	_prev_drift_mode="${XFREE_UPSTREAM_DRIFT_MODE-}"
	_prev_ok_codes="${UI_RUN_WITH_OUTPUT_OK_CODES-}"
	export XFREE_UPSTREAM_DRIFT_MODE="$drift_mode"
	# export: на ash префикс VAR=val перед shell-функцией может не попасть внутрь.
	UI_RUN_WITH_OUTPUT_OK_CODES="0 10 11"
	export UI_RUN_WITH_OUTPUT_OK_CODES
	DETAILS_MAX_LINES="${DETAILS_MAX_LINES:-50}" \
		upstream_invoke_with_output "Проверка обновлений upstream ($drift_mode)" \
			sh "$check_script" --details --write-drift-dir "$drift_dir" || rc=$?
	if [ -n "${_prev_ok_codes}" ]; then
		UI_RUN_WITH_OUTPUT_OK_CODES="$_prev_ok_codes"
		export UI_RUN_WITH_OUTPUT_OK_CODES
	else
		unset UI_RUN_WITH_OUTPUT_OK_CODES || true
	fi
	if [ -n "${_prev_drift_mode:-}" ]; then
		export XFREE_UPSTREAM_DRIFT_MODE="$_prev_drift_mode"
	else
		unset XFREE_UPSTREAM_DRIFT_MODE || true
	fi
	# После UI exit 10 нормализуется в 0; сырой код — в LAST_RC / TSV.
	case "${UI_RUN_WITH_OUTPUT_LAST_RC:-$rc}" in
		0|10|11) rc="${UI_RUN_WITH_OUTPUT_LAST_RC:-$rc}" ;;
	esac

	has_drift=0
	if [ "$drift_mode" = "templates" ]; then
		[ -s "$tmpl_tsv" ] && has_drift=1
	else
		{ [ -s "$prof_tsv" ] || [ -s "$sta_tsv" ]; } && has_drift=1
	fi

	if [ "$has_drift" -eq 1 ]; then
		do_apply=0
		if [ "$auto_apply" = "1" ]; then
			do_apply=1
		else
			labels_file="$UI_TMP_ROOT/upstream-drift-labels-${drift_mode}.$$"
			upstream_drift_build_labels_file "$drift_mode" "$prof_tsv" "$tmpl_tsv" "$sta_tsv" "$labels_file"
			drift_targets="$(sed '/^$/d' "$labels_file" | head -30)"
			if [ "$(wc -l < "$labels_file" | tr -d ' ')" -gt 30 ]; then
				drift_targets="${drift_targets}
…"
			fi
			if [ "$drift_mode" = "templates" ]; then
				if [ -n "${XFREE_UPSTREAM_DRIFT_TEMPLATE:-}" ]; then
					confirm_suffix="Применить в шаблон ${XFREE_UPSTREAM_DRIFT_TEMPLATE}?"
				else
					confirm_suffix="Применить во все profile-templates/?"
				fi
			else
				confirm_suffix="Применить списки и runtime (где доступно)?"
			fi
			confirm_msg="Найдены изменения ($drift_mode):

${drift_targets}

${confirm_suffix}"
			if ui_confirm "Upstream" "$confirm_msg"; then
				do_apply=1
			fi
		fi
		if [ "$do_apply" = "1" ]; then
			upstream_drift_apply_snapshot \
				"$drift_mode" "$prof_tsv" "$tmpl_tsv" "$sta_tsv" \
				"$apply_script" "$apply_template_sh" || return 1
		fi
	fi

	case "$rc" in
		0|10|11)
			:
			;;
		*)
			if upstreams_pipeline_headless_p; then
				printf '[-] Проверка (%s) завершилась с кодом: %s\n' "$drift_mode" "$rc" >&2
				return 1
			fi
			ui_msgbox "Ошибка" "Проверка ($drift_mode) завершилась с кодом: $rc"
			;;
	esac
}

check_active_list_updates() {
	# $1 = auto_apply (0=confirm, 1=без confirm). По умолчанию 0 — пункт «Применить обновления».
	_auto_apply="${1:-0}"
	_wrap_batch=0
	[ "${UI_RUN_WITH_OUTPUT_BATCH_DEPTH:-0}" -eq 0 ] && _wrap_batch=1
	[ "$_wrap_batch" = "1" ] && ui_run_with_output_batch_begin

	# profile-generator: только шаблоны (XFREE_UPSTREAM_DRIFT_MODE=templates)
	if [ "${XFREE_UPSTREAM_DRIFT_MODE:-}" = "templates" ]; then
		check_active_list_updates_one_mode templates "$_auto_apply" || true
	else
		check_active_list_updates_one_mode profiles "$_auto_apply" || true
		check_active_list_updates_one_mode templates "$_auto_apply" || true
	fi

	if [ "$_wrap_batch" = "1" ]; then
		# Не пробрасываем non-zero наружу: иначе set -e в menu.gen.sh убивает всё меню.
		_prev_batch_sum="${UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY-}"
		UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY=1
		export UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY
		ui_run_with_output_batch_end "Применение обновлений upstream" || true
		if [ -n "${_prev_batch_sum}" ]; then
			UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY="$_prev_batch_sum"
			export UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY
		else
			unset UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY || true
		fi
	fi
	return 0
}

# Скачать upstream-источники и применить drift в profiles/ + profile-templates/.
# Без повторного confirm: сам пункт меню «Обновить и применить» — согласие.
upstreams_refresh_sources_and_lists() {
	ui_run_with_output_batch_begin
	update_selected_modules || true
	# auto_apply=1: не спрашивать «Применить в profile-templates/?»
	check_active_list_updates 1
	# Textbox: только «Готово обновление» / «Итог проверки» / «Готово применение»; детали — в консоли.
	_prev_batch_sum="${UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY-}"
	UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY=1
	export UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY
	ui_run_with_output_batch_end "Обновление upstream" || true
	if [ -n "${_prev_batch_sum}" ]; then
		UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY="$_prev_batch_sum"
		export UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY
	else
		unset UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY || true
	fi
	return 0
}

upstreams_update_and_apply() {
	upstreams_refresh_sources_and_lists
}
