#!/bin/sh
# shellcheck shell=sh
# Non-interactive upstreams actions for LuCI (ubus xfree-toolbox systemMenu / upstreams).
# No -u: jshn.sh references unset JSON_PREFIX.
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
UPSTREAMS_DIR="$ROOT_DIR/upstreams"

[ -f /usr/share/libubox/jshn.sh ] && . /usr/share/libubox/jshn.sh
# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/upstreams.sh" ] && . "$ROOT_DIR/lib/upstreams.sh"
# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/background-tasks.sh" ] && . "$ROOT_DIR/lib/background-tasks.sh"

ACTION="${1:-catalog}"
ARG="${2:-}"
PAYLOAD="${3:-}"

_json_error() {
	json_init
	json_add_int code 1
	json_add_string error "$1"
	json_dump
	exit 0
}

find_module_dir() {
	_target="${1:-}"
	[ -n "$_target" ] || return 1
	if [ -d "$UPSTREAMS_DIR/$_target" ]; then
		printf '%s\n' "$UPSTREAMS_DIR/$_target"
		return 0
	fi
	for _d in "$UPSTREAMS_DIR"/*; do
		[ -d "$_d" ] || continue
		if [ -f "$_d/upstream.conf" ]; then
			_n="$(awk -F= '/^[[:space:]]*UPSTREAM_NAME=/ { v=$2; gsub(/["'"'"']/, "", v); gsub(/^[[:space:]]+|[[:space:]]+$/, "", v); print v; exit }' "$_d/upstream.conf")"
			if [ "$_n" = "$_target" ]; then
				printf '%s\n' "$_d"
				return 0
			fi
		fi
	done
	return 1
}

action_catalog() {
	# Ensure any custom upstreams from persistent storage are restored
	upstreams_restore_custom_modules "$ROOT_DIR" 2>/dev/null || true

	json_init
	json_add_int code 0
	json_add_array modules

	_tmp="/tmp/upstreams-cat.$$.tmp"
	upstreams_list_all_modules_tsv "$UPSTREAMS_DIR" > "$_tmp" 2>/dev/null || true

	while IFS="$(printf '\t')" read -r name title desc enabled script upstream_dir conf_file; do
		[ -n "$name" ] || continue
		_id="${conf_file%/upstream.conf}"
		_id="${_id##*/}"
		custom=0
		if [ -f "$conf_file" ] && grep -q 'UPSTREAM_CUSTOM="*1"*' "$conf_file" 2>/dev/null; then
			custom=1
		fi

		cnt=0
		if [ -d "$upstream_dir" ]; then
			for _f in "$upstream_dir"/*.lst "$upstream_dir"/*/*.lst "$upstream_dir"/*/*/*.lst; do
				[ -f "$_f" ] && cnt=$((cnt + 1))
			done
		fi

		json_add_object ""
		json_add_string id "$_id"
		json_add_string name "$name"
		json_add_string title "$title"
		json_add_string desc "$desc"
		json_add_int enabled "$enabled"
		json_add_int custom "$custom"
		json_add_int listsCount "$cnt"
		json_close_object
	done < "$_tmp"
	rm -f "$_tmp"

	json_close_array
	json_dump
}

action_get_lists() {
	_mdir="$(find_module_dir "$ARG" || true)"
	[ -n "$_mdir" ] && [ -d "$_mdir" ] || _json_error "источник '$ARG' не найден"
	_upstream_dir="$_mdir/upstream"

	json_init
	json_add_int code 0
	json_add_string module "$(basename "$_mdir")"
	json_add_array lists

	if [ -d "$_upstream_dir" ]; then
		_ltmp="$(mktemp)"
		( cd "$_upstream_dir" && find . -name "*.lst" 2>/dev/null | sort ) > "$_ltmp"
		while IFS= read -r lpath; do
			[ -n "$lpath" ] || continue
			rel="${lpath#./}"
			fpath="$_upstream_dir/$rel"
			lines=0
			[ -f "$fpath" ] && lines=$(wc -l < "$fpath" 2>/dev/null || echo 0)
			json_add_object ""
			json_add_string path "$rel"
			json_add_int lines "$lines"
			json_close_object
		done < "$_ltmp"
		rm -f "$_ltmp"
	fi

	json_close_array
	json_dump
}

action_toggle() {
	_mdir="$(find_module_dir "$ARG" || true)"
	[ -n "$_mdir" ] && [ -d "$_mdir" ] || _json_error "источник '$ARG' не найден"

	_conf="$_mdir/upstream.conf"
	[ -f "$_conf" ] || _json_error "upstream.conf не найден в $_mdir"

	_cur=1
	if grep -q 'UPSTREAM_ENABLED="*0"*' "$_conf" 2>/dev/null; then
		_cur=0
	fi

	_new=0
	[ "$_cur" = "0" ] && _new=1
	if [ -n "$PAYLOAD" ]; then
		case "$PAYLOAD" in
			1|true|on) _new=1 ;;
			0|false|off) _new=0 ;;
		esac
	fi

	_tmp="${_conf}.tmp.$$"
	if grep -q '^[[:space:]]*UPSTREAM_ENABLED=' "$_conf" 2>/dev/null; then
		sed "s/^[[:space:]]*UPSTREAM_ENABLED=.*/UPSTREAM_ENABLED=\"$_new\"/" "$_conf" > "$_tmp"
	else
		cp "$_conf" "$_tmp"
		printf '\nUPSTREAM_ENABLED="%s"\n' "$_new" >> "$_tmp"
	fi
	mv "$_tmp" "$_conf"

	# Reindex sources so selection catalog reflects changes
	upstreams_reindex_sources "$ROOT_DIR" 2>/dev/null || true

	json_init
	json_add_int code 0
	json_add_string name "$(basename "$_mdir")"
	json_add_int enabled "$_new"
	json_dump
}

action_update_one() {
	_mdir="$(find_module_dir "$ARG" || true)"
	[ -n "$_mdir" ] && [ -d "$_mdir" ] || _json_error "источник '$ARG' не найден"
	_mod="$(basename "$_mdir")"

	_script="$_mdir/update-lists.sh"
	[ -f "$_script" ] || _json_error "скрипт update-lists.sh не найден в $_mod"

	printf '=== Обновление источника: %s ===\n' "$_mod"
	if [ "$_mod" = "vpn" ] || [ "$_mod" = "proton" ]; then
		sh "$_script" --acquire-guest || true
	else
		sh "$_script" || true
	fi

	_data_dir="$_mdir/upstream"
	if [ -d "$_data_dir" ]; then
		printf '[*] Переиндексация модуля: %s\n' "$_mod"
		upstreams_rebuild_module_index_for_data_dir "$_data_dir" || true
	fi

	printf '[*] Обновление общего индекса источников\n'
	upstreams_reindex_sources "$ROOT_DIR" 2>/dev/null || true
	printf '[+] Готово!\n'
}

action_create_custom() {
	# PAYLOAD is JSON: { "name": "...", "title": "...", "desc": "...", "domains": "..." }
	_raw_name=""
	_raw_title=""
	_raw_desc=""
	_raw_domains=""

	if [ -n "$PAYLOAD" ]; then
		json_load "$PAYLOAD" 2>/dev/null || true
		json_get_var _raw_name name 2>/dev/null || true
		json_get_var _raw_title title 2>/dev/null || true
		json_get_var _raw_desc desc 2>/dev/null || true
		json_get_var _raw_domains domains 2>/dev/null || true
	fi

	[ -n "$_raw_name" ] || _raw_name="$ARG"
	_mod_name="$(printf '%s' "$_raw_name" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9._-')"
	[ -n "$_mod_name" ] || _json_error "Недопустимое имя источника (разрешены буквы a-z, цифры, дефис)"

	_target_dir="$UPSTREAMS_DIR/$_mod_name"
	if [ -d "$_target_dir" ]; then
		_json_error "Источник с именем '$_mod_name' уже существует"
	fi

	[ -n "$_raw_title" ] || _raw_title="$_mod_name"
	[ -n "$_raw_desc" ] || _raw_desc="Пользовательский источник (не перезатирается при обновлении)"

	mkdir -p "$_target_dir/upstream/custom"

	# 1. upstream.conf
	cat > "$_target_dir/upstream.conf" <<EOF
UPSTREAM_NAME="$_mod_name"
UPSTREAM_TITLE="$_raw_title"
UPSTREAM_DESCRIPTION="$_raw_desc"
UPSTREAM_ENABLED="1"
UPSTREAM_CUSTOM="1"
EOF

	# 2. update-lists.sh (safe dummy: user data is never overwritten)
	cat > "$_target_dir/update-lists.sh" << 'EOF'
#!/bin/sh
# Custom user-owned upstream. Local only, never overwritten by remote updates.
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
UPSTREAM_DIR="${UPSTREAM_DIR:-$SCRIPT_DIR/upstream}"
mkdir -p "$UPSTREAM_DIR/custom"
echo "[*] $SCRIPT_DIR: пользовательский источник, внешнее обновление не требуется."
EOF
	chmod +x "$_target_dir/update-lists.sh"

	# 3. Initial .lst file
	_lst_file="$_target_dir/upstream/custom/fqdn-$_mod_name.lst"
	if [ -n "$_raw_domains" ]; then
		printf '%s\n' "$_raw_domains" | tr -d '\r' | grep -v '^[[:space:]]*$' > "$_lst_file" || : > "$_lst_file"
	else
		: > "$_lst_file"
	fi

	# 4. Rebuild indexes and persist to persistent storage
	upstreams_rebuild_module_index_for_data_dir "$_target_dir/upstream" || true
	upstreams_reindex_sources "$ROOT_DIR" 2>/dev/null || true
	upstreams_persist_custom_modules "$ROOT_DIR" 2>/dev/null || true

	json_init
	json_add_int code 0
	json_add_string name "$_mod_name"
	json_add_string message "Пользовательский источник '$_mod_name' успешно создан"
	json_dump
}

action_delete_custom() {
	_mod="$(printf '%s' "$ARG" | tr -cd 'A-Za-z0-9._-')"
	[ -n "$_mod" ] || _json_error "имя модуля не указано"

	case "$_mod" in
		allow-domains|rekryt-iplist|vpn|user)
			_json_error "Системный модуль '$_mod' удалять нельзя"
			;;
	esac

	_mdir="$UPSTREAMS_DIR/$_mod"
	[ -d "$_mdir" ] || _json_error "источник '$_mod' не найден"

	_conf="$_mdir/upstream.conf"
	if [ ! -f "$_conf" ] || ! grep -q 'UPSTREAM_CUSTOM="*1"*' "$_conf" 2>/dev/null; then
		_json_error "источник '$_mod' не помечен как пользовательский"
	fi

	rm -rf "$_mdir"
	_store="$(upstreams_custom_store_dir 2>/dev/null || true)"
	[ -n "$_store" ] && rm -rf "$_store/$_mod" 2>/dev/null || true
	upstreams_reindex_sources "$ROOT_DIR" 2>/dev/null || true

	json_init
	json_add_int code 0
	json_add_string message "Источник '$_mod' удалён"
	json_dump
}

action_get_list() {
	_rel="$ARG"
	[ -n "$_rel" ] || _json_error "путь к списку не указан"

	# Prevent path traversal
	case "$_rel" in
		..*|*/..*|*../*) _json_error "недопустимый путь" ;;
	esac

	_fpath="$UPSTREAMS_DIR/$_rel"
	if [ ! -f "$_fpath" ]; then
		case "$_rel" in
			svc__*|grp__*)
				_candidate="$(grep -h "^$_rel|" "$UPSTREAMS_DIR"/*/.index/lists.raw.tsv 2>/dev/null | head -n1 || true)"
				if [ -n "$_candidate" ]; then
					_c_mod="$(printf '%s' "$_candidate" | cut -d'|' -f2)"
					_c_rel="$(printf '%s' "$_candidate" | cut -d'|' -f8)"
					_fpath="$UPSTREAMS_DIR/$_c_mod/upstream/$_c_rel"
					_rel="$_c_mod/upstream/$_c_rel"
				fi
				;;
		esac
		if [ ! -f "$_fpath" ]; then
			_found="$(find "$UPSTREAMS_DIR" -type f \( -name "$_rel" -o -name "${_rel}.lst" -o -name "fqdn-${_rel}.lst" -o -name "prefixes-${_rel}.lst" \) 2>/dev/null | head -n1 || true)"
			if [ -n "$_found" ] && [ -f "$_found" ]; then
				_fpath="$_found"
				_rel="${_found#$UPSTREAMS_DIR/}"
			fi
		fi
	fi
	[ -f "$_fpath" ] || _json_error "файл не найден: $_rel"

	_mod_name="$(printf '%s' "$_rel" | cut -d/ -f1)"
	_conf="$UPSTREAMS_DIR/$_mod_name/upstream.conf"
	_is_custom=0
	if [ -f "$_conf" ] && grep -q 'UPSTREAM_CUSTOM="*1"*' "$_conf" 2>/dev/null; then
		_is_custom=1
	fi

	json_init
	json_add_int code 0
	json_add_string path "$_rel"
	json_add_string module "$_mod_name"
	json_add_int custom "$_is_custom"
	json_add_string content "$(cat "$_fpath" 2>/dev/null || true)"
	json_dump
}

action_save_list() {
	_rel="$ARG"
	[ -n "$_rel" ] || _json_error "путь к списку не указан"

	case "$_rel" in
		..*|*/..*|*../*) _json_error "недопустимый путь" ;;
	esac

	_fpath="$UPSTREAMS_DIR/$_rel"
	if [ ! -f "$_fpath" ]; then
		case "$_rel" in
			svc__*|grp__*)
				_candidate="$(grep -h "^$_rel|" "$UPSTREAMS_DIR"/*/.index/lists.raw.tsv 2>/dev/null | head -n1 || true)"
				if [ -n "$_candidate" ]; then
					_c_mod="$(printf '%s' "$_candidate" | cut -d'|' -f2)"
					_c_rel="$(printf '%s' "$_candidate" | cut -d'|' -f8)"
					_fpath="$UPSTREAMS_DIR/$_c_mod/upstream/$_c_rel"
					_rel="$_c_mod/upstream/$_c_rel"
				fi
				;;
		esac
		if [ ! -f "$_fpath" ]; then
			_found="$(find "$UPSTREAMS_DIR" -type f \( -name "$_rel" -o -name "${_rel}.lst" -o -name "fqdn-${_rel}.lst" -o -name "prefixes-${_rel}.lst" \) 2>/dev/null | head -n1 || true)"
			if [ -n "$_found" ] && [ -f "$_found" ]; then
				_fpath="$_found"
				_rel="${_found#$UPSTREAMS_DIR/}"
			fi
		fi
	fi

	_mod_name="$(printf '%s' "$_rel" | cut -d/ -f1)"
	_conf="$UPSTREAMS_DIR/$_mod_name/upstream.conf"
	if [ ! -f "$_conf" ] || ! grep -q 'UPSTREAM_CUSTOM="*1"*' "$_conf" 2>/dev/null; then
		_json_error "Предустановленные списки защищены от редактирования"
	fi

	_fpath="$UPSTREAMS_DIR/$_rel"
	_dir="$(dirname "$_fpath")"
	mkdir -p "$_dir"

	# PAYLOAD is the content to write
	printf '%s\n' "$PAYLOAD" | tr -d '\r' > "$_fpath"

	if [ -d "$UPSTREAMS_DIR/$_mod_name/upstream" ]; then
		upstreams_rebuild_module_index_for_data_dir "$UPSTREAMS_DIR/$_mod_name/upstream" 2>/dev/null || true
	fi
	upstreams_reindex_sources "$ROOT_DIR" 2>/dev/null || true
	if [ "$_mod_name" != "user" ]; then
		upstreams_persist_custom_modules "$ROOT_DIR" 2>/dev/null || true
	fi

	json_init
	json_add_int code 0
	json_add_string message "Список $_rel успешно сохранён"
	json_dump
}

action_create_list() {
	_mod="$ARG"
	_group=""
	_service=""
	_type="fqdn"
	_name=""
	_content=""

	if [ -n "$PAYLOAD" ]; then
		json_load "$PAYLOAD" 2>/dev/null || true
		json_get_var _p_mod module 2>/dev/null || true
		[ -n "$_p_mod" ] && _mod="$_p_mod"
		json_get_var _group group 2>/dev/null || true
		json_get_var _service service 2>/dev/null || true
		json_get_var _type type 2>/dev/null || true
		json_get_var _name name 2>/dev/null || true
		json_get_var _content content 2>/dev/null || true
	fi

	_mdir="$(find_module_dir "$_mod" || true)"
	[ -n "$_mdir" ] && [ -d "$_mdir" ] || _json_error "источник '$_mod' не найден"

	_mod_name="$(basename "$_mdir")"
	_conf="$_mdir/upstream.conf"
	if [ ! -f "$_conf" ] || ! grep -q 'UPSTREAM_CUSTOM="*1"*' "$_conf" 2>/dev/null; then
		_json_error "Создавать списки можно только в пользовательских источниках"
	fi

	_group_clean="$(printf '%s' "$_group" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9._-')"
	[ -n "$_group_clean" ] || _json_error "Укажите группу (разрешены a-z, 0-9, дефис)"

	_service_clean=""
	if [ -n "$_service" ]; then
		_service_clean="$(printf '%s' "$_service" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9._-')"
	fi

	_name_clean="$(printf '%s' "$_name" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9._-')"
	if [ -z "$_name_clean" ]; then
		if [ -n "$_service_clean" ]; then
			_name_clean="$_service_clean"
		else
			_name_clean="$_group_clean"
		fi
	fi
	[ -n "$_name_clean" ] || _json_error "Укажите имя списка (разрешены a-z, 0-9, дефис)"

	case "$_type" in
		ipv4|prefixes-ipv4|prefix-ipv4)
			_filename="prefixes-ipv4-${_name_clean}.lst"
			;;
		ipv6|prefixes-ipv6|prefix-ipv6)
			_filename="prefixes-ipv6-${_name_clean}.lst"
			;;
		prefix|prefixes)
			_filename="prefixes-${_name_clean}.lst"
			;;
		fqdn|domain|domains|*)
			_filename="fqdn-${_name_clean}.lst"
			;;
	esac

	if [ -n "$_service_clean" ]; then
		_rel_dir="$_group_clean/$_service_clean"
	else
		_rel_dir="$_group_clean"
	fi
	_rel_path="$_rel_dir/$_filename"

	_fpath="$_mdir/upstream/$_rel_path"
	if [ -f "$_fpath" ]; then
		_json_error "Список '$_rel_path' уже существует"
	fi

	mkdir -p "$_mdir/upstream/$_rel_dir"
	if [ -n "$_content" ]; then
		printf '%s\n' "$_content" | tr -d '\r' | grep -v '^[[:space:]]*$' > "$_fpath" || : > "$_fpath"
	else
		: > "$_fpath"
	fi

	upstreams_rebuild_module_index_for_data_dir "$_mdir/upstream" 2>/dev/null || true
	rm -rf /tmp/xfree-toolbox/upstreams-model 2>/dev/null || true
	upstreams_persist_custom_modules "$ROOT_DIR" 2>/dev/null || true

	json_init
	json_add_int code 0
	json_add_string path "$_rel_path"
	json_add_string message "Список '$_rel_path' успешно создан"
	json_dump
}

action_delete_list() {
	_rel="$ARG"
	[ -n "$_rel" ] || _json_error "путь к списку не указан"

	case "$_rel" in
		..*|*/..*|*../*) _json_error "недопустимый путь" ;;
	esac

	_mod_name="$(printf '%s' "$_rel" | cut -d/ -f1)"
	_conf="$UPSTREAMS_DIR/$_mod_name/upstream.conf"
	if [ ! -f "$_conf" ] || ! grep -q 'UPSTREAM_CUSTOM="*1"*' "$_conf" 2>/dev/null; then
		_json_error "Предустановленные списки нельзя удалять"
	fi

	_fpath="$UPSTREAMS_DIR/$_rel"
	[ -f "$_fpath" ] || _json_error "файл не найден: $_rel"

	rm -f "$_fpath"

	_pdir="$(dirname "$_fpath")"
	if [ "$_pdir" != "$UPSTREAMS_DIR/$_mod_name/upstream" ] && [ -d "$_pdir" ]; then
		rmdir "$_pdir" 2>/dev/null || true
	fi

	if [ -d "$UPSTREAMS_DIR/$_mod_name/upstream" ]; then
		upstreams_rebuild_module_index_for_data_dir "$UPSTREAMS_DIR/$_mod_name/upstream" 2>/dev/null || true
	fi
	rm -rf /tmp/xfree-toolbox/upstreams-model 2>/dev/null || true
	if [ "$_mod_name" != "user" ]; then
		_store="$(upstreams_custom_store_dir 2>/dev/null || true)"
		if [ -n "$_store" ] && [ -d "$_store/$_mod_name" ]; then
			rm -rf "$_store/$_mod_name"
			mkdir -p "$_store/$_mod_name"
			cp -a "$UPSTREAMS_DIR/$_mod_name/." "$_store/$_mod_name/" 2>/dev/null || true
		fi
	fi

	json_init
	json_add_int code 0
	json_add_string message "Список '$_rel' удалён"
	json_dump
}

action_start_bg() {
	_task_name="${ARG:-upstreams-action}"
	_log="/tmp/xfree-background-tasks/upstreams-action.log"
	mkdir -p /tmp/xfree-background-tasks

	if bg_tasks_is_running 2>/dev/null; then
		json_init
		json_add_int code 1
		json_add_int running 1
		json_add_string error "Другая фоновая задача уже выполняется: ${BG_TASK_NAME:-task}"
		json_dump
		return 0
	fi

	_runner="$ROOT_DIR/lib/bg-task-run.sh"
	[ -f "$_runner" ] || _json_error "missing: $_runner"

	case "$_task_name" in
		upstreamsUpdateApply)
			(
				export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
				sh "$_runner" "upstreams" --log "$_log" -- \
					sh "$ROOT_DIR/system/luci-rpc.sh" upstreamsUpdateApply
			) >/dev/null 2>&1 &
			;;
		upstreamsUpdateActive)
			(
				export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
				sh "$_runner" "upstreams" --log "$_log" -- \
					sh "$ROOT_DIR/system/luci-rpc.sh" upstreamsUpdateActive
			) >/dev/null 2>&1 &
			;;
		upstreamsApply)
			(
				export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
				sh "$_runner" "upstreams" --log "$_log" -- \
					sh "$ROOT_DIR/system/luci-rpc.sh" upstreamsApply
			) >/dev/null 2>&1 &
			;;
		upstreamsReindex)
			(
				export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
				sh "$_runner" "upstreams" --log "$_log" -- \
					sh "$ROOT_DIR/system/luci-rpc.sh" upstreamsReindex
			) >/dev/null 2>&1 &
			;;
		updateOne:*)
			_mod="${_task_name#updateOne:}"
			(
				export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
				sh "$_runner" "upstreams" --log "$_log" -- \
					sh "$SCRIPT_DIR/luci-rpc.sh" updateOne "$_mod"
			) >/dev/null 2>&1 &
			;;
		*)
			_json_error "Неизвестная задача для запуска в фоне: $_task_name"
			;;
	esac

	sleep 1
	action_bg_status
}

action_bg_status() {
	_log="/tmp/xfree-background-tasks/upstreams-action.log"
	_running=0
	_task=""
	_exit="0"
	_status="idle"

	if bg_tasks_is_running 2>/dev/null; then
		_running=1
		_task="${BG_TASK_NAME:-upstreams}"
		_status="running"
		[ -n "${BG_TASK_LOG_FILE:-}" ] && _log="$BG_TASK_LOG_FILE"
	elif bg_tasks_read_last_meta 2>/dev/null; then
		_task="${BG_TASK_LAST_NAME:-}"
		_status="${BG_TASK_LAST_STATUS:-done}"
		_exit="${BG_TASK_LAST_EXIT_CODE:-0}"
		[ -n "${BG_TASK_LAST_LOG_FILE:-}" ] && _log="$BG_TASK_LAST_LOG_FILE"
	fi

	_out=""
	if [ -f "$_log" ]; then
		_out="$(tail -n 250 "$_log" 2>/dev/null || true)"
	fi

	json_init
	json_add_int code 0
	json_add_int running "$_running"
	json_add_string status "$_status"
	json_add_string exitCode "$_exit"
	json_add_string task "$_task"
	json_add_string stdout "$_out"
	json_dump
}

case "$ACTION" in
	catalog|Catalog)
		action_catalog
		;;
	toggle|Toggle)
		action_toggle
		;;
	updateOne|UpdateOne)
		action_update_one
		;;
	createCustom|CreateCustom)
		action_create_custom
		;;
	deleteCustom|DeleteCustom)
		action_delete_custom
		;;
	getLists|GetLists)
		action_get_lists
		;;
	getList|GetList)
		action_get_list
		;;
	saveList|SaveList)
		action_save_list
		;;
	createList|CreateList)
		action_create_list
		;;
	deleteList|DeleteList)
		action_delete_list
		;;
	startBg|StartBg)
		action_start_bg
		;;
	bgStatus|BgStatus)
		action_bg_status
		;;
	*)
		_json_error "unknown action: $ACTION"
		;;
esac
