#!/bin/sh
# shellcheck shell=sh
# Copy upstream sources onto profile/state/template materialized paths for selected drift keys.
# Selection keys (entity-level, all files under entity):
#   s:<target_type>:<entity>              — state
#   p:<profile>:<target_type>:<entity>    — profiles/<profile>/…
#   t:<template>:<target_type>:<entity>   — profile-templates/<template>/…
# Or pass --apply-all to copy every row from the provided TSV snapshot(s).

set -eu

PROFILE_TSV=""
STATE_TSV=""
TEMPLATE_TSV=""
APPLY_ALL=0
COPY_COUNT=0
SKIP_MISSING_SRC=0
SKIP_UNMATCHED=0
COPY_FAILED=0

usage() {
    printf 'Usage: %s (--profile-tsv FILE | --template-tsv FILE) [--state-tsv FILE] (--apply-all | -- <key>...)\n' "$(basename "$0")" >&2
    printf '  key: s:<type>:<entity> | p:<profile>:<type>:<entity> | t:<template>:<type>:<entity>\n' >&2
    exit 2
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --profile-tsv)
            shift
            [ "$#" -gt 0 ] || usage
            PROFILE_TSV="$1"
            ;;
        --template-tsv)
            shift
            [ "$#" -gt 0 ] || usage
            TEMPLATE_TSV="$1"
            ;;
        --state-tsv)
            shift
            [ "$#" -gt 0 ] || usage
            STATE_TSV="$1"
            ;;
        --apply-all)
            APPLY_ALL=1
            ;;
        --)
            shift
            break
            ;;
        -*)
            usage
            ;;
        *)
            break
            ;;
    esac
    shift
done

[ -n "${PROFILE_TSV:-}${TEMPLATE_TSV:-}" ] || usage
[ -n "${PROFILE_TSV:-}" ] && [ ! -f "$PROFILE_TSV" ] && {
    printf '[!] profile tsv not found: %s\n' "$PROFILE_TSV" >&2
    exit 1
}
[ -n "${TEMPLATE_TSV:-}" ] && [ ! -f "$TEMPLATE_TSV" ] && {
    printf '[!] template tsv not found: %s\n' "$TEMPLATE_TSV" >&2
    exit 1
}

[ -n "${STATE_TSV:-}" ] || STATE_TSV=""
[ -n "${STATE_TSV:-}" ] && [ ! -f "$STATE_TSV" ] && STATE_TSV=""

if [ "$APPLY_ALL" -eq 0 ] && [ "$#" -eq 0 ]; then
    printf '[!] no selection keys (use --apply-all or keys after --)\n' >&2
    exit 1
fi

strip_cr() {
    printf '%s' "$1" | tr -d '\r'
}

key_matches_profile_row() {
    key="$1"
    container="$2"
    target_type="$3"
    entity="$4"

    case "$key" in
        p:"$container":"$target_type":"$entity") return 0 ;;
    esac
    return 1
}

key_matches_template_row() {
    key="$1"
    container="$2"
    target_type="$3"
    entity="$4"

    case "$key" in
        t:"$container":"$target_type":"$entity") return 0 ;;
    esac
    return 1
}

key_matches_state_row() {
    key="$1"
    target_type="$2"
    entity="$3"

    case "$key" in
        s:"$target_type":"$entity") return 0 ;;
    esac
    return 1
}

apply_copy_row() {
    scope_tag="$1"
    container="$2"
    target_type="$3"
    entity="$4"
    src_path="$5"
    target_path="$6"

    if [ ! -f "$src_path" ]; then
        printf '[!] skip (missing upstream): %s\n' "$src_path" >&2
        SKIP_MISSING_SRC=$((SKIP_MISSING_SRC + 1))
        return 0
    fi
    if [ ! -s "$src_path" ]; then
        printf '[!] skip (empty upstream, keep existing): %s\n' "$src_path" >&2
        SKIP_MISSING_SRC=$((SKIP_MISSING_SRC + 1))
        return 0
    fi

    d="$(dirname "$target_path")"
    if ! mkdir -p "$d" 2>/dev/null; then
        printf '[!] skip (mkdir failed): %s\n' "$d" >&2
        return 1
    fi
    if ! cp -f "$src_path" "$target_path" 2>/dev/null; then
        printf '[!] skip (copy failed): %s -> %s\n' "$src_path" "$target_path" >&2
        COPY_FAILED=$((COPY_FAILED + 1))
        return 1
    fi
    COPY_COUNT=$((COPY_COUNT + 1))
    if [ -n "${container:-}" ]; then
        printf '[*] %s:%s:%s:%s: %s -> %s\n' "$scope_tag" "$container" "$target_type" "$entity" "$src_path" "$target_path"
    else
        printf '[*] %s:%s:%s: %s -> %s\n' "$scope_tag" "$target_type" "$entity" "$src_path" "$target_path"
    fi
    return 0
}

apply_container_tsv() {
    scope_tag="$1"
    tsv_path="$2"
    shift 2

    [ -s "$tsv_path" ] || return 0

    while IFS='|' read -r container target_type entity kind dest_name src_path target_path || [ -n "${container:-}${target_type:-}" ]; do
        container="$(strip_cr "${container:-}")"
        target_type="$(strip_cr "${target_type:-}")"
        entity="$(strip_cr "${entity:-}")"
        src_path="$(strip_cr "${src_path:-}")"
        target_path="$(strip_cr "${target_path:-}")"

        [ -n "${target_type:-}" ] || continue
        [ -n "${entity:-}" ] || continue
        [ -n "${src_path:-}" ] || continue
        [ -n "${target_path:-}" ] || continue

        matched=0
        if [ "$APPLY_ALL" -eq 1 ]; then
            matched=1
        else
            for k in "$@"; do
                case "$scope_tag" in
                    p)
                        if key_matches_profile_row "$k" "$container" "$target_type" "$entity"; then
                            matched=1
                            break
                        fi
                        ;;
                    t)
                        if key_matches_template_row "$k" "$container" "$target_type" "$entity"; then
                            matched=1
                            break
                        fi
                        ;;
                esac
            done
        fi
        if [ "$matched" -eq 0 ]; then
            SKIP_UNMATCHED=$((SKIP_UNMATCHED + 1))
            continue
        fi

        apply_copy_row "$scope_tag" "$container" "$target_type" "$entity" "$src_path" "$target_path" || true
    done < "$tsv_path"
}

apply_state_tsv() {
    tsv_path="$1"
    shift

    [ -s "$tsv_path" ] || return 0

    while IFS='|' read -r target_type entity kind dest_name src_path target_path || [ -n "${target_type:-}${entity:-}" ]; do
        target_type="$(strip_cr "${target_type:-}")"
        entity="$(strip_cr "${entity:-}")"
        src_path="$(strip_cr "${src_path:-}")"
        target_path="$(strip_cr "${target_path:-}")"

        [ -n "${target_type:-}" ] || continue
        [ -n "${entity:-}" ] || continue
        [ -n "${src_path:-}" ] || continue
        [ -n "${target_path:-}" ] || continue

        matched=0
        if [ "$APPLY_ALL" -eq 1 ]; then
            matched=1
        else
            for k in "$@"; do
                if key_matches_state_row "$k" "$target_type" "$entity"; then
                    matched=1
                    break
                fi
            done
        fi
        if [ "$matched" -eq 0 ]; then
            SKIP_UNMATCHED=$((SKIP_UNMATCHED + 1))
            continue
        fi

        apply_copy_row "s" "" "$target_type" "$entity" "$src_path" "$target_path" || true
    done < "$tsv_path"
}

if [ "$APPLY_ALL" -eq 1 ]; then
    printf '[*] Применение upstream: все строки из snapshot TSV\n'
else
    printf '[*] Применение upstream по выбранным целям (%s ключей)\n' "$#"
fi

if [ -n "${PROFILE_TSV:-}" ]; then
    apply_container_tsv "p" "$PROFILE_TSV" "$@"
fi
if [ -n "${TEMPLATE_TSV:-}" ]; then
    apply_container_tsv "t" "$TEMPLATE_TSV" "$@"
fi
if [ -n "${STATE_TSV:-}" ] && [ -f "$STATE_TSV" ] && [ -s "$STATE_TSV" ]; then
    apply_state_tsv "$STATE_TSV" "$@"
fi

printf '[*] Готово применение: скопировано=%s, пропуск (нет upstream)=%s, пропуск (не выбрано)=%s, ошибок copy=%s\n' \
    "$COPY_COUNT" "$SKIP_MISSING_SRC" "$SKIP_UNMATCHED" "$COPY_FAILED"

if [ "$COPY_FAILED" -gt 0 ]; then
    printf '[!] Часть файлов не скопирована (права записи? см. copy failed выше)\n' >&2
    exit 1
fi

if [ "$COPY_COUNT" -eq 0 ]; then
  if [ "$SKIP_MISSING_SRC" -gt 0 ]; then
    printf '[!] Ни один файл не скопирован: upstream-источники отсутствуют (см. skip выше)\n' >&2
    exit 1
  fi
  if [ "$APPLY_ALL" -eq 1 ] || [ "$#" -gt 0 ]; then
    printf '[!] Ни один файл не скопирован: нет совпадений с ключами или пустой snapshot\n' >&2
    exit 1
  fi
fi

exit 0
