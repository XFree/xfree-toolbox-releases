#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
[ -f "$COMMON_SH" ] || {
  echo "[!] Не найден common.sh: $COMMON_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"

CONF_FILE="$SCRIPT_DIR/upstream.conf"
[ -f "$CONF_FILE" ] && . "$CONF_FILE"

UPSTREAM_DIR="${UPSTREAM_DIR:-$SCRIPT_DIR/upstream}"
UPSTREAM_ARCHIVE_URL="${UPSTREAM_ARCHIVE_URL:-https://codeload.github.com/itdoginfo/allow-domains/tar.gz/refs/heads/main}"
TMP_DIR="${TMP_DIR:-/tmp/allow-domains-update.$$}"

QUIET=0

cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT INT TERM

usage() {
  cat <<'EOF2'
Usage:
  update-lists.sh [--quiet]

Environment:
  UPSTREAM_DIR
  UPSTREAM_ARCHIVE_URL
  TMP_DIR
EOF2
}

fetch_required() {
  url="$1"
  dst="$2"
  http_fetch_file "$url" "$dst" || die "Не удалось скачать: $url"
}

normalize_name() {
  common_lower_ascii "$1"
}

norm_lines() {
  tr -d '\r' \
    | sed '/^[[:space:]]*$/d' \
    | sed '/^[[:space:]]*[#;]/d' \
    | sed 's/^[[:space:]]*//; s/[[:space:]]*$//'
}

norm_domains() {
  common_norm_domains_stream
}

norm_cidr4() {
  norm_lines | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$' | sort -u || true
}

norm_cidr6() {
  norm_lines | grep -Ei '^[0-9a-f:]+/[0-9]+$' | sort -fu || true
}

write_normalized_if_nonempty() {
  src="$1"
  dst="$2"
  mode="$3"

  [ -f "$src" ] || return 0
  [ -s "$src" ] || return 0

  tmp="${dst}.tmp"
  mkdir -p "$(dirname "$dst")"

  case "$mode" in
    fqdn)
      # Proton FQDNs belong on zapret user (user/vpn/proton), not Warp via block.
      norm_domains < "$src" | sh "$SCRIPT_DIR/strip-proton-fqdn.sh" > "$tmp"
      ;;
    cidr4) norm_cidr4   < "$src" > "$tmp" ;;
    cidr6) norm_cidr6   < "$src" > "$tmp" ;;
    *) die "Неизвестный mode=$mode" ;;
  esac

  if [ -s "$tmp" ]; then
    mv "$tmp" "$dst"
  else
    rm -f "$tmp"
  fi
}

append_unique_file() {
  src="$1"
  dst="$2"

  [ -f "$src" ] || return 0
  [ -s "$src" ] || return 0

  mkdir -p "$(dirname "$dst")"

  if [ -f "$dst" ]; then
    cat "$dst" "$src" | sort -u > "${dst}.tmp"
    mv "${dst}.tmp" "$dst"
  else
    cp "$src" "$dst"
  fi
}

dir_has_files() {
  dir="$1"
  [ -d "$dir" ] && [ -n "$(find "$dir" -maxdepth 1 -type f 2>/dev/null)" ]
}

create_category_entries() {
  categories_dir="$1"
  subnets4_dir="$2"
  subnets6_dir="$3"
  newroot="$4"

  for category_file in "$categories_dir"/*.lst; do
    [ -f "$category_file" ] || continue

    category_raw="$(basename "$category_file" .lst)"
    category="$(normalize_name "$category_raw")"
    category_dir="$newroot/$category"

    write_normalized_if_nonempty \
      "$category_file" \
      "$category_dir/fqdn-$category.lst" \
      fqdn

    if [ -n "$subnets4_dir" ] && [ -f "$subnets4_dir/$category_raw.lst" ]; then
      write_normalized_if_nonempty \
        "$subnets4_dir/$category_raw.lst" \
        "$category_dir/prefixes-ipv4-$category.lst" \
        cidr4
    fi

    if [ -n "$subnets6_dir" ] && [ -f "$subnets6_dir/$category_raw.lst" ]; then
      write_normalized_if_nonempty \
        "$subnets6_dir/$category_raw.lst" \
        "$category_dir/prefixes-ipv6-$category.lst" \
        cidr6
    fi

    if dir_has_files "$category_dir"; then
      say "[*] Категория: $category"
    else
      rm -rf "$category_dir"
    fi
  done
}

create_others_service_entries() {
  services_dir="$1"
  subnets4_dir="$2"
  subnets6_dir="$3"
  newroot="$4"

  others_dir="$newroot/others"
  others_fqdn="$others_dir/fqdn-others.lst"
  others_cidr4="$others_dir/prefixes-ipv4-others.lst"
  others_cidr6="$others_dir/prefixes-ipv6-others.lst"

  for service_file in "$services_dir"/*.lst; do
    [ -f "$service_file" ] || continue

    service_raw="$(basename "$service_file" .lst)"
    service="$(normalize_name "$service_raw")"
    service_dir="$others_dir/$service"

    service_fqdn="$service_dir/fqdn-$service.lst"
    service_cidr4="$service_dir/prefixes-ipv4-$service.lst"
    service_cidr6="$service_dir/prefixes-ipv6-$service.lst"

    write_normalized_if_nonempty \
      "$service_file" \
      "$service_fqdn" \
      fqdn

    if [ -n "$subnets4_dir" ] && [ -f "$subnets4_dir/$service_raw.lst" ]; then
      write_normalized_if_nonempty \
        "$subnets4_dir/$service_raw.lst" \
        "$service_cidr4" \
        cidr4
    fi

    if [ -n "$subnets6_dir" ] && [ -f "$subnets6_dir/$service_raw.lst" ]; then
      write_normalized_if_nonempty \
        "$subnets6_dir/$service_raw.lst" \
        "$service_cidr6" \
        cidr6
    fi

    if dir_has_files "$service_dir"; then
      append_unique_file "$service_fqdn" "$others_fqdn"
      append_unique_file "$service_cidr4" "$others_cidr4"
      append_unique_file "$service_cidr6" "$others_cidr6"
      say "[*] Сервис: others/$service"
    else
      rm -rf "$service_dir"
    fi
  done

  if dir_has_files "$others_dir"; then
    say "[*] Категория: others"
  else
    rm -rf "$others_dir"
  fi
}

convert_upstream() {
  mkdir -p "$TMP_DIR/extract" "$TMP_DIR/newroot"

  tar -xzf "$TMP_DIR/src.tar.gz" -C "$TMP_DIR/extract"

  root="$(find "$TMP_DIR/extract" -mindepth 1 -maxdepth 1 -type d | head -n 1)"
  [ -n "${root:-}" ] || die "Не удалось определить корень архива"

  [ -d "$root/Services" ] || die "В архиве отсутствует каталог Services"
  [ -d "$root/Categories" ] || die "В архиве отсутствует каталог Categories"
  [ -d "$root/Subnets/IPv4" ] || die "В архиве отсутствует каталог Subnets/IPv4"

  services_dir="$root/Services"
  categories_dir="$root/Categories"
  subnets4_dir="$root/Subnets/IPv4"
  subnets6_dir=""

  if [ -d "$root/Subnets/IPv6" ]; then
    subnets6_dir="$root/Subnets/IPv6"
    say "[*] Найден каталог Subnets/IPv6"
  else
    say "[*] Каталог Subnets/IPv6 отсутствует, IPv6-списки пропущены"
  fi

  say "[*] Конвертирую категории"
  create_category_entries "$categories_dir" "$subnets4_dir" "$subnets6_dir" "$TMP_DIR/newroot"

  say "[*] Конвертирую сервисы в others"
  create_others_service_entries "$services_dir" "$subnets4_dir" "$subnets6_dir" "$TMP_DIR/newroot"

  new_n="$(find "$TMP_DIR/newroot" -type f -name '*.lst' 2>/dev/null | wc -l | tr -d '[:space:]')"
  case "$new_n" in
    ''|*[!0-9]*) new_n=0 ;;
  esac
  if [ "$new_n" -eq 0 ]; then
    warn "allow-domains: пустой результат конвертации. Прежние списки не трогаю."
    return 1
  fi

  say "[*] Обновляю upstream ($new_n списков)"
  rm -rf "$UPSTREAM_DIR"
  mkdir -p "$(dirname "$UPSTREAM_DIR")"
  mv "$TMP_DIR/newroot" "$UPSTREAM_DIR"
}

main() {
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --quiet)
        QUIET=1
        shift
        ;;
      -h|--help)
        usage
        exit 0
        ;;
      *)
        die "Неизвестный аргумент: $1"
        ;;
    esac
  done

  mkdir -p "$TMP_DIR"

  say "[*] Скачиваю allow-domains"
  fetch_required "$UPSTREAM_ARCHIVE_URL" "$TMP_DIR/src.tar.gz"

  say "[*] Обновляю upstream"
  if convert_upstream; then
    say "[*] Готово: $UPSTREAM_DIR"
  fi
}

main "$@"
