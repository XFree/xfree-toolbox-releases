#!/bin/sh
# shellcheck shell=sh
# Drop Proton VPN/Mail FQDNs from allow-domains streams (keep protondb.com).
# Guest API (account.protonvpn.com) stays on zapret WAN, not Warp via block.
set -eu

awk '
{
	d = $0
	gsub(/\r/, "", d)
	if (d == "") next
	ld = tolower(d)
	if (ld ~ /(^|\.)proton\.me$/) next
	if (ld ~ /(^|\.)protonvpn\.com$/) next
	if (ld ~ /(^|\.)protonvpn\.net$/) next
	if (ld ~ /(^|\.)protonmail\.com$/) next
	if (ld ~ /(^|\.)protonmail\.ch$/) next
	print d
}
'
