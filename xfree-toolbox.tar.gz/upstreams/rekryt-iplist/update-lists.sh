#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

COMMON_SH="$ROOT_DIR/lib/common.sh"
[ -f "$COMMON_SH" ] || {
  echo "[!] Не найден common.sh: $COMMON_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"

CONF_FILE="$SCRIPT_DIR/upstream.conf"
[ -f "$CONF_FILE" ] && . "$CONF_FILE"

UPSTREAM_DIR="${UPSTREAM_DIR:-$SCRIPT_DIR/upstream}"
REPO_ARCHIVE_URL="${REPO_ARCHIVE_URL:-https://codeload.github.com/rekryt/iplist/tar.gz/refs/heads/master}"
OPENCCK_BASE_URL="${OPENCCK_BASE_URL:-https://iplist.opencck.org/}"
TMP_DIR="${TMP_DIR:-/tmp/rekryt-iplist-update.$$}"
UPSTREAM_LIST_MODE="${UPSTREAM_LIST_MODE:-fqdn}"

QUIET=0

cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT INT TERM

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

usage() {
  cat <<'EOF'
Usage:
  update-lists.sh [--quiet]

Environment:
  UPSTREAM_DIR
  REPO_ARCHIVE_URL
  REPO_ARCHIVE_FILE   (local tar.gz; skip GitHub download)
  OPENCCK_BASE_URL
  OPENCCK_DOMAINS_JSON_FILE / OPENCCK_CIDR4_JSON_FILE  (local JSON; skip HTTP)
  OPENCCK_CONNECT_TIMEOUT OPENCCK_MAX_TIME OPENCCK_SPEED_TIME
  OPENCCK_SPEED_LIMIT OPENCCK_FETCH_RETRY
  TMP_DIR
  UPSTREAM_LIST_MODE (fqdn | fqdn+prefixes)
EOF
}

list_mode_is_prefixes() {
  [ "$UPSTREAM_LIST_MODE" = "fqdn+prefixes" ]
}

validate_list_mode() {
  case "$UPSTREAM_LIST_MODE" in
    fqdn|fqdn+prefixes) ;;
    *)
      die "Некорректный UPSTREAM_LIST_MODE=$UPSTREAM_LIST_MODE (ожидается fqdn или fqdn+prefixes)"
      ;;
  esac
}

fetch_required() {
  url="$1"
  dst="$2"
  http_fetch_file "$url" "$dst" || die "Не удалось скачать: $url"
}

# OpenCCK JSON is small but DPI often stalls first bytes; GitHub defaults
# (speed-time 15s / 32 KiB/s) abort that. Override only for this API.
http_fetch_opencck() {
  url="$1"
  dst="$2"
  HTTP_CONNECT_TIMEOUT="${OPENCCK_CONNECT_TIMEOUT:-60}"
  HTTP_MAX_TIME="${OPENCCK_MAX_TIME:-180}"
  HTTP_SPEED_TIME="${OPENCCK_SPEED_TIME:-90}"
  HTTP_SPEED_LIMIT="${OPENCCK_SPEED_LIMIT:-1024}"
  HTTP_FETCH_RETRY="${OPENCCK_FETCH_RETRY:-3}"
  export HTTP_CONNECT_TIMEOUT HTTP_MAX_TIME HTTP_SPEED_TIME HTTP_SPEED_LIMIT HTTP_FETCH_RETRY
  http_fetch_file "$url" "$dst"
}

json_file_is_object() {
  json_file="$1"
  [ -f "$json_file" ] && [ -s "$json_file" ] || return 1

  if have_cmd jq; then
    jq -e 'type == "object"' "$json_file" >/dev/null 2>&1
    return $?
  fi

  if have_cmd jsonfilter; then
    jsonfilter -i "$json_file" -e '@' >/dev/null 2>&1 || return 1
  fi

  grep -q '^[[:space:]]*{' "$json_file"
}

keep_existing_upstream() {
  reason="$1"
  [ -n "$reason" ] && warn "$reason"
  warn "Прежние списки rekryt-iplist не трогаю."
  warn "Повторите обновление source-списков, когда iplist.opencck.org откроется (часто после zapret)."
}

lst_count_in_dir() {
  dir="$1"
  [ -d "$dir" ] || {
    printf '0\n'
    return 0
  }
  find "$dir" -type f -name '*.lst' 2>/dev/null | wc -l | tr -d '[:space:]'
}

normalize_name() {
  common_lower_ascii "$1"
}

norm_lines() {
  tr -d '\r' \
    | sed '/^[[:space:]]*$/d' \
    | sed '/^[[:space:]]*[#;]/d' \
    | sed 's/^[[:space:]]*//; s/[[:space:]]*$//'
}

norm_domains() {
  norm_lines | common_lower_ascii_stream | sort -u
}

norm_cidr4() {
  norm_lines | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$' | sort -u || true
}

append_unique_file() {
  src="$1"
  dst="$2"

  [ -f "$src" ] || return 0
  [ -s "$src" ] || return 0

  mkdir -p "$(dirname "$dst")"

  if [ -f "$dst" ]; then
    cat "$dst" "$src" | sort -u > "${dst}.tmp"
    mv "${dst}.tmp" "$dst"
  else
    cp "$src" "$dst"
  fi
}

write_service_file_if_nonempty() {
  src="$1"
  dst="$2"

  [ -f "$src" ] || return 0
  [ -s "$src" ] || return 0

  mkdir -p "$(dirname "$dst")"
  cp "$src" "$dst"
}

dir_has_files() {
  dir="$1"
  [ -d "$dir" ] && [ -n "$(find "$dir" -maxdepth 1 -type f 2>/dev/null)" ]
}

download_repo_archive() {
  mkdir -p "$TMP_DIR"
  if [ -n "${REPO_ARCHIVE_FILE:-}" ]; then
    [ -f "$REPO_ARCHIVE_FILE" ] || die "REPO_ARCHIVE_FILE не найден: $REPO_ARCHIVE_FILE"
    say "[*] Беру локальный архив rekryt/iplist"
    cp "$REPO_ARCHIVE_FILE" "$TMP_DIR/repo.tar.gz"
    return 0
  fi
  say "[*] Скачиваю rekryt/iplist"
  fetch_required "$REPO_ARCHIVE_URL" "$TMP_DIR/repo.tar.gz"
}

extract_repo_archive() {
  mkdir -p "$TMP_DIR/extract" "$TMP_DIR/newroot" "$TMP_DIR/api" "$TMP_DIR/work"
  tar -xzf "$TMP_DIR/repo.tar.gz" -C "$TMP_DIR/extract"

  REPO_ROOT="$(find "$TMP_DIR/extract" -mindepth 1 -maxdepth 1 -type d | head -n 1)"
  [ -n "${REPO_ROOT:-}" ] || die "Не удалось определить корень архива"

  CONFIG_DIR="$REPO_ROOT/config"
  [ -d "$CONFIG_DIR" ] || die "В архиве отсутствует каталог config"
}

fetch_global_json() {
  data="$1"
  wildcard="$2"
  dst="$3"
  local_file=""

  url="${OPENCCK_BASE_URL}?format=json&data=${data}"
  [ "$wildcard" = "1" ] && url="${url}&wildcard=1"

  say "[*] API request: data=$data wildcard=$wildcard url=$url"

  mkdir -p "$(dirname -- "$dst")"

  case "$data" in
    domains) local_file="${OPENCCK_DOMAINS_JSON_FILE:-}" ;;
    cidr4) local_file="${OPENCCK_CIDR4_JSON_FILE:-}" ;;
  esac

  if [ -n "$local_file" ]; then
    if [ ! -f "$local_file" ]; then
      printf '[!] API source error: data=%s local file missing %s\n' "$data" "$local_file" >&2
      rm -f "$dst"
      return 1
    fi
    cp -f "$local_file" "$dst"
  elif ! http_fetch_opencck "$url" "$dst"; then
    printf '[!] API source error: data=%s url=%s\n' "$data" "$url" >&2
    rm -f "$dst"
    return 1
  fi

  if [ ! -s "$dst" ]; then
    printf '[!] API source empty: data=%s url=%s\n' "$data" "$url" >&2
    rm -f "$dst"
    return 1
  fi

  if ! json_file_is_object "$dst"; then
    printf '[!] API source is not a JSON object: data=%s url=%s\n' "$data" "$url" >&2
    rm -f "$dst"
    return 1
  fi

  return 0
}

json_map_get_list() {
  json_file="$1"
  key="$2"

  if [ ! -f "$json_file" ] || [ ! -s "$json_file" ]; then
    return 0
  fi

  if have_cmd jq; then
    jq -r --arg k "$key" '.[$k][]? // empty' "$json_file" 2>/dev/null || true
    return 0
  fi

  if have_cmd jsonfilter; then
    escaped_key=$(printf '%s' "$key" | sed 's/\\/\\\\/g; s/"/\\"/g')
    jsonfilter -i "$json_file" -e "@[\"$escaped_key\"][@]" 2>/dev/null || true
    return 0
  fi

  die "Нужен jq или jsonfilter"
}

process_service() {
  group="$1"
  service="$2"
  domains_json="$3"
  cidr4_json="$4"

  group_norm="$(normalize_name "$group")"
  service_norm="$(normalize_name "$service")"

  work_dir="$TMP_DIR/work/$group_norm/$service_norm"
  mkdir -p "$work_dir"

  service_domains="$work_dir/fqdn.lst"
  service_cidr4="$work_dir/cidr4.lst"

  json_map_get_list "$domains_json" "$service" | norm_domains > "$service_domains" || true
  if list_mode_is_prefixes; then
    json_map_get_list "$cidr4_json" "$service" | norm_cidr4 > "$service_cidr4" || true
  fi

  [ -s "$service_domains" ] || rm -f "$service_domains"
  if list_mode_is_prefixes; then
    [ -s "$service_cidr4" ] || rm -f "$service_cidr4"
  else
    rm -f "$service_cidr4"
  fi

  group_dir="$TMP_DIR/newroot/$group_norm"
  service_dir="$group_dir/$service_norm"

  write_service_file_if_nonempty \
    "$service_domains" \
    "$service_dir/fqdn-$service_norm.lst"

  if list_mode_is_prefixes; then
    write_service_file_if_nonempty \
      "$service_cidr4" \
      "$service_dir/prefixes-ipv4-$service_norm.lst"
  fi

  append_unique_file \
    "$service_domains" \
    "$group_dir/fqdn-$group_norm.lst"

  if list_mode_is_prefixes; then
    append_unique_file \
      "$service_cidr4" \
      "$group_dir/prefixes-ipv4-$group_norm.lst"
  fi

  if dir_has_files "$service_dir"; then
    say "[*] $group_norm/$service_norm"
  else
    rm -rf "$service_dir"
  fi
}

process_all_services() {
  domains_json="$1"
  cidr4_json="$2"

  find "$CONFIG_DIR" -mindepth 1 -maxdepth 1 -type d | sort | while read -r group_dir; do
    group="$(basename "$group_dir")"

    find "$group_dir" -maxdepth 1 -type f -name '*.json' | sort | while read -r json_file; do
      service="$(basename "$json_file" .json)"
      process_service "$group" "$service" "$domains_json" "$cidr4_json"
    done
  done
}

cleanup_empty_groups() {
  find "$TMP_DIR/newroot" -mindepth 1 -maxdepth 1 -type d | while read -r group_dir; do
    if ! dir_has_files "$group_dir"; then
      if ! find "$group_dir" -mindepth 2 -type f | grep -q . 2>/dev/null; then
        rm -rf "$group_dir"
      fi
    fi
  done
}

newroot_list_count() {
  lst_count_in_dir "$TMP_DIR/newroot"
}

replace_upstream() {
  new_n="$(newroot_list_count)"
  old_n="$(lst_count_in_dir "$UPSTREAM_DIR")"
  case "$new_n" in
    ''|*[!0-9]*) new_n=0 ;;
  esac
  case "$old_n" in
    ''|*[!0-9]*) old_n=0 ;;
  esac
  if [ "$new_n" -eq 0 ]; then
    return 1
  fi
  if [ "$old_n" -ge 4 ]; then
    min_n=$((old_n / 4))
    [ "$min_n" -lt 1 ] && min_n=1
    if [ "$new_n" -lt "$min_n" ]; then
      warn "новый набор rekryt-iplist слишком маленький ($new_n списков, было $old_n)."
      return 1
    fi
  fi
  say "[*] Обновляю upstream ($new_n списков)"
  rm -rf "$UPSTREAM_DIR"
  mkdir -p "$(dirname "$UPSTREAM_DIR")"
  mv "$TMP_DIR/newroot" "$UPSTREAM_DIR"
}

main() {
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --quiet)
        QUIET=1
        shift
        ;;
      -h|--help)
        usage
        exit 0
        ;;
      *)
        die "Неизвестный аргумент: $1"
        ;;
    esac
  done

  validate_list_mode

  case "$UPSTREAM_LIST_MODE" in
    fqdn)
      say "[*] Режим загрузки rekryt-iplist: fqdn (prefixes отключены)"
      ;;
    fqdn+prefixes)
      say "[*] Режим загрузки rekryt-iplist: fqdn+prefixes"
      ;;
  esac

  download_repo_archive
  extract_repo_archive

  domains_json="$TMP_DIR/api/domains.json"
  cidr4_json="$TMP_DIR/api/cidr4.json"

  if ! fetch_global_json domains 1 "$domains_json"; then
    keep_existing_upstream "OpenCCK API не вернул домены ($OPENCCK_BASE_URL)."
    return 0
  fi
  if list_mode_is_prefixes; then
    fetch_global_json cidr4 0 "$cidr4_json" || true
  else
    rm -f "$cidr4_json"
  fi

  say "[*] Обрабатываю сервисы из config/"
  process_all_services "$domains_json" "$cidr4_json"
  cleanup_empty_groups

  if replace_upstream; then
    say "[*] Готово: $UPSTREAM_DIR"
    return 0
  fi

  keep_existing_upstream "OpenCCK API не дал полноценный набор доменов ($OPENCCK_BASE_URL)."
}

main "$@"
