#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
# summary nodes for zapret
ubus call xfree-toolbox trafficPath '{"action":"summary"}' 2>/dev/null | tr ',' '\n' | grep -E 'zapret:|markQueue|hostlistInOpt|stateLists|detail|ok' | head -80
echo '=== per-section runtime via CLI ==='
. /root/xfree-toolbox/diagnostics/lib/traffic-path.sh
traffic_path_init_paths
for s in youtube_29 user cust1 discord cdn-host; do
  printf '%s -> ' "$s"
  traffic_path_runtime_zapret "$s"
  echo
done
echo '=== NFQWS_OPT hostlists for these ==='
uci get zapret.config.NFQWS_OPT | grep -oE -- '--hostlist=[^[:space:]]+' | sort -u
echo '=== discord/cdn state lists nonempty? ==='
for s in discord cdn-host youtube_29; do
  n=$(find /etc/xfree-toolbox/zapret/state/sections/$s/fqdn.d -name '*.lst' -type f 2>/dev/null | wc -l)
  lines=$(cat /etc/xfree-toolbox/zapret/state/sections/$s/fqdn.d/*.lst 2>/dev/null | wc -l)
  echo "$s lst_files=$n lines=$lines"
done
REMOTE
