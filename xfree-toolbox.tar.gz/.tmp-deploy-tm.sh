#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
scp "${SCP_OPTS[@]}" \
  diagnostics/lib/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/lib/traffic-path.sh"
scp "${SCP_OPTS[@]}" \
  diagnostics/traffic-path.sh \
  "$SSH_TARGET:$TB/diagnostics/traffic-path.sh"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
chmod +x /root/xfree-toolbox/diagnostics/traffic-path.sh
echo '=== active profile / zapret roots ==='
ap="$(cat /etc/xfree-toolbox/active-profile 2>/dev/null || echo default)"
echo "active=$ap"
ls -d /root/xfree-toolbox/profiles/"$ap"/zapret 2>/dev/null || echo 'no profile zapret'
echo '=== state youtube sections (sample) ==='
ls /etc/xfree-toolbox/zapret/state/sections 2>/dev/null | grep -E 'youtube|google' | head -20
echo '=== hostfiles ==='
for f in zapret-hosts-google.txt xfree-google-hosts.txt; do
  p="/opt/zapret/ipset/$f"
  if [ -f "$p" ]; then
    echo "$f lines=$(wc -l <"$p") youtube=$(grep -c youtube "$p" || true)"
  else
    echo "$f MISSING"
  fi
done
echo '=== traffic-path cdn.youtube.com ==='
/root/xfree-toolbox/diagnostics/traffic-path.sh trace cdn.youtube.com | head -c 2500
echo
echo '=== ubus ==='
ubus call xfree-toolbox trafficPath '{"action":"trace","fqdn":"cdn.youtube.com"}' 2>&1 | head -c 2500
echo
REMOTE
