#!/usr/bin/env python3
import sys
from pathlib import Path

sys.path.insert(
    0,
    str(
        Path(__file__).resolve().parent
        / "build/openwrt/luci-app-xfree-toolbox/tests/playwright"
    ),
)
from playwright.sync_api import sync_playwright
from test_dashboard_smoke import luci_login, resolve_config

base, user, password = resolve_config("bluehome")
shot = Path(__file__).resolve().parent / ".tmp-luci-shots/08-after-bust.png"

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": 1280, "height": 900})
    urls = []
    page.on(
        "response",
        lambda r: urls.append(r.url)
        if ("traffic-map.js" in r.url or "shell.js" in r.url or "xfree-dashboard.css" in r.url)
        else None,
    )
    luci_login(page, base, user, password)
    page.goto(
        f"{base}/cgi-bin/luci/admin/services/xfree-toolbox",
        wait_until="networkidle",
        timeout=45000,
    )
    page.wait_for_timeout(1000)
    for u in urls:
        print(u)
    print(
        "hasRouter",
        page.evaluate("() => !!document.querySelector('.tm-hub-node.is-router')"),
    )
    page.fill(".tm-trace-input", "www.youtube.com")
    page.locator(".tm-trace-btn").click()
    page.wait_for_function(
        """() => {
            const m = document.querySelector('xfree-traffic-map');
            return m && m._busy === false && m._trace;
        }""",
        timeout=25000,
    )
    page.wait_for_timeout(400)
    print(
        "active",
        page.evaluate(
            "() => [...document.querySelectorAll('.tm-chip.is-active')]"
            ".map(e => e.innerText.replace(/\\s+/g,' ').trim())"
        ),
    )
    page.locator("#xfree-toolbox-shell").screenshot(path=str(shot))
    print("shot", shot)
    browser.close()
