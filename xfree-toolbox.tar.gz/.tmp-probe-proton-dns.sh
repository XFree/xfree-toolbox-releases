#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
echo "SSH_TARGET=$SSH_TARGET"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE' || true
set +e
echo "=== host / date ==="
cat /proc/sys/kernel/hostname 2>/dev/null; date
uname -a 2>/dev/null | head -1
echo "=== default route ==="
ip route show default 2>/dev/null | head -5
echo "=== nslookup account.protonvpn.com ==="
nslookup account.protonvpn.com 2>&1 | head -40
echo "=== nslookup ya.ru ==="
nslookup ya.ru 2>&1 | head -20
echo "=== getent / busybox resolve ==="
getent hosts account.protonvpn.com 2>&1
busybox nslookup account.protonvpn.com 2>&1 | head -40
echo "=== curl -vI https://account.protonvpn.com/ ==="
curl -vI --connect-timeout 10 --max-time 20 https://account.protonvpn.com/ 2>&1 | tail -50
echo "=== curl -I https://ya.ru ==="
curl -sI --connect-timeout 8 --max-time 15 https://ya.ru 2>&1 | head -15
echo "=== find dns-check / traffic-path ==="
find /usr /opt /etc/xfree-toolbox -name 'dns-check.sh' -o -name 'traffic-path.sh' 2>/dev/null | head -20
echo "=== dns-check ==="
DC=""
for p in \
  /usr/libexec/xfree-toolbox/diagnostics/dns-check.sh \
  /opt/xfree-toolbox/diagnostics/dns-check.sh \
  /etc/xfree-toolbox/diagnostics/dns-check.sh
do
  [ -x "$p" ] && DC="$p" && break
done
if [ -n "$DC" ]; then
  "$DC" account.protonvpn.com 2>&1 | tail -80
else
  echo "dns-check.sh not found"
fi
echo "=== resolv.conf ==="
cat /etc/resolv.conf 2>&1 | head -20
echo "=== dns processes ==="
ps w | grep -E 'dnsmasq|https-dns|stubby|unbound|https_dns' | grep -v grep | head -20
echo "=== zapret proton lists ==="
grep -rl 'protonvpn.com' /opt/zapret/ipset 2>/dev/null | head -20
ls /etc/xfree-toolbox/zapret/state/sections/user/fqdn.d 2>/dev/null | head -30
echo "=== uci dhcp dns servers (sample) ==="
uci show dhcp 2>/dev/null | grep -E 'server|noresolv|resolvfile|dns' | head -40
echo "=== done ==="
REMOTE
