#!/bin/sh
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
. ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"

ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo "=== luci.js matches ==="
grep -n "urlArgs\|distrevision\|luciversion\|'?v='\|\"?v=\"\|cachemark\|vv =" /www/luci-static/resources/luci.js | head -50
echo "=== runtime.uc env ==="
sed -n '170,230p' /usr/share/ucode/luci/runtime.uc
echo "=== dispatcher snippets ==="
grep -n "distrevision\|luciversion\|revision\|script" /usr/share/ucode/luci/dispatcher.uc | head -50
echo "=== version.lua ==="
cat /usr/lib/lua/luci/version.lua
echo "=== openwrt_release ==="
cat /etc/openwrt_release
echo "=== decode timestamp ==="
date -d @1790953379 2>/dev/null || date -u -r 1790953379 2>/dev/null || true
echo "=== probe html without auth redirect bits ==="
# get login page luci.js v=
wget -qO- http://127.0.0.1/cgi-bin/luci 2>/dev/null | grep -oE 'luci\.js\?v=[^"'\'' ]+' | head
REMOTE
