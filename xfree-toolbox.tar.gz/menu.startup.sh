#!/bin/sh
# Root menu startup (before main loop). Sourced from menu.gen.sh.
# shellcheck shell=sh

RESTART_FLAG="/tmp/xfree-toolbox-menu-restart.flag"
XFREE_LAUNCHER_NAME="${XFREE_LAUNCHER_NAME:-xft}"
RUNNING_JOB_KIND=""
RUNNING_JOB_PID=""
RUNNING_JOB_LOG=""

detect_running_job() {
    bg_tasks_is_running || return 1
    RUNNING_JOB_KIND="${BG_TASK_NAME:-unknown-task}"
    RUNNING_JOB_PID="${BG_TASK_PID:-}"
    RUNNING_JOB_LOG="${BG_TASK_LOG_FILE:-}"
    return 0
}

show_running_job_log_tty() {
    [ -n "${RUNNING_JOB_KIND:-}" ] || return 0
    printf '\n[!] Обнаружен активный процесс: %s (pid=%s)\n' "$RUNNING_JOB_KIND" "$RUNNING_JOB_PID" >&2
    if [ -f "${RUNNING_JOB_LOG:-}" ]; then
        printf '[*] Лог: %s\n' "$RUNNING_JOB_LOG" >&2
        tail -n 40 "$RUNNING_JOB_LOG" 2>/dev/null || true
        printf '\n' >&2
    fi
}

show_running_job_log_ui() {
    [ -n "${RUNNING_JOB_KIND:-}" ] || return 0
    if [ ! -f "${RUNNING_JOB_LOG:-}" ]; then
        ui_msgbox "Активная задача" "Найдена активная задача: $RUNNING_JOB_KIND (pid=$RUNNING_JOB_PID)

Лог не найден: ${RUNNING_JOB_LOG:-<unknown>}"
        return 0
    fi
    ui_menu_invoke_with_output \
        "Активная задача: $RUNNING_JOB_KIND (pid=$RUNNING_JOB_PID)" \
        sh -c '
            log_file="$1"
            task_pid="$2"
            root="${3:-}"

            tail -n 220 -f "$log_file" &
            tail_pid=$!

            while kill -0 "$task_pid" 2>/dev/null; do
                sleep 1
            done

            sleep 1
            kill "$tail_pid" 2>/dev/null || true
            wait "$tail_pid" 2>/dev/null || true

            _rc=0
            if [ -n "$root" ] && [ -f "$root/lib/background-tasks.sh" ]; then
                # shellcheck disable=SC1090
                . "$root/lib/background-tasks.sh"
                if bg_tasks_read_last_meta 2>/dev/null; then
                    _rc="$(bg_tasks_resolve_exit_code \
                        "${BG_TASK_LAST_STATUS:-}" \
                        "${BG_TASK_LAST_EXIT_CODE:-0}" \
                        "$log_file")"
                else
                    _rc="$(bg_tasks_exit_code_from_log "$log_file" 0)"
                fi
            fi
            exit "$_rc"
        ' sh "$RUNNING_JOB_LOG" "$RUNNING_JOB_PID" "$ROOT_DIR"
}

ensure_button_hooks_at_startup() {
    _script="$ROOT_DIR/system/hardware/install-button-hooks.sh"
    [ -f "$_script" ] || return 0
    sh "$_script" --ensure --quiet --root "$ROOT_DIR" 2>/dev/null || true
}

ensure_startup_packages() {
    _ensure="$ROOT_DIR/system/ensure-base-packages.sh"
    [ -f "$_ensure" ] || die "Не найден ensure-base-packages.sh: $_ensure"
    [ -x "$_ensure" ] || chmod +x "$_ensure" 2>/dev/null || true
    sh "$_ensure" --yes --root "$ROOT_DIR" || die "Не удалось установить базовые пакеты."
}

run_startup_migrations() {
    if [ -f "$ROOT_DIR/system/fix-crlf.sh" ]; then
        [ -x "$ROOT_DIR/system/fix-crlf.sh" ] || chmod +x "$ROOT_DIR/system/fix-crlf.sh" 2>/dev/null || true
        "$ROOT_DIR/system/fix-crlf.sh" "$ROOT_DIR" >/dev/null 2>&1 || true
    fi

    for script in \
        "$ROOT_DIR/system/migrate-state-root.sh" \
        "$ROOT_DIR/system/migrate-state-root-v2.sh" \
        "$ROOT_DIR/system/hardware/usb-power-watch-upgrade.sh"
    do
        [ -f "$script" ] || continue
        [ -x "$script" ] || chmod +x "$script" 2>/dev/null || true
        case "$script" in
            *usb-power-watch-upgrade.sh)
                sh "$script" --migrate-conf "$ROOT_DIR" >/dev/null 2>&1 || true
                ;;
            *)
                "$script" || true
                ;;
        esac
    done

    # Spare only: rewrite absolute/missing upstream indexes (not a full reindex).
    # Normal rebuild is on update-lists / «Переиндексировать source-списки».
    if [ -f "$ROOT_DIR/lib/upstreams.sh" ]; then
        # shellcheck disable=SC1090
        . "$ROOT_DIR/lib/upstreams.sh"
        upstreams_repair_bad_indexes "$ROOT_DIR" >/dev/null 2>&1 || true
    fi
}

show_startup_migration_summary() {
    # Без WARN — тихо (не показываем «OK / изменений не потребовалось»).
    # При WARN — ровно одно окно с отчётом проверки.
    check_report="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/migration-check.txt"

    [ -s "$check_report" ] || return 0
    grep -q '^\[WARN\]' "$check_report" 2>/dev/null || return 0

    if ui_have_whiptail; then
        ui_show_textbox "Миграция xfree-toolbox: предупреждения" "$check_report" 28 110
    else
        printf '\nПроверка миграции нашла предупреждения:\n'
        cat "$check_report"
        printf '\n'
    fi
}

ensure_launcher_command() {
    _lib="$ROOT_DIR/system/router-commands-lib.sh"
    launcher="$XFREE_LAUNCHER_NAME"

    [ -n "$launcher" ] || return 0
    [ -f "$_lib" ] || return 0
    # shellcheck disable=SC1091
    . "$_lib"

    if router_cmd_ensure_all "$ROOT_DIR" "$launcher"; then
        return 0
    fi

    marker="/tmp/xfree-toolbox-router-commands-warning.flag"
    [ -f "$marker" ] && return 0
    printf '%s\n' "1" >"$marker" 2>/dev/null || true

    printf '\n[!] Команды toolbox не в PATH или указывают не на эту установку:\n' >&2
    printf '    %s, usb-modem-power-cycle\n' "$launcher" >&2
    printf '[*] Система → «Установить команды в PATH» или:\n' >&2
    printf '    sh %s/system/router-commands.sh --install\n\n' "$ROOT_DIR" >&2
}

profile_name_count() {
    text="$1"
    [ -n "${text:-}" ] || {
        printf '0\n'
        return 0
    }
    printf '%s\n' "$text" | grep -c .
}

join_lines_comma() {
    # stdin: по строке на имя → «a, b, c»; пустой ввод → «(нет)»
    out=""
    while IFS= read -r line; do
        [ -n "$line" ] || continue
        if [ -z "$out" ]; then
            out="$line"
        else
            out="$out, $line"
        fi
    done
    [ -n "$out" ] || out="(нет)"
    printf '%s' "$out"
}

maybe_show_missing_profile_guidance_at_startup() {
    current="$(current_profile_name)"
    current_dir="$(current_profile_dir)"
    [ -d "$current_dir" ] && return 0

    state_root="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
    templates_human="$(common_list_profile_template_dirnames "$ROOT_DIR" 2>/dev/null | join_lines_comma)"
    profiles_human="$(list_profile_names 2>/dev/null | join_lines_comma)"
    instantiate_cmd="sh templates/instantiate-profile-from-template.sh --template default --profile $current"
    restore_cmd="sh templates/restore-profile-from-state.sh --profile $current"

    if common_state_root_looks_populated "$state_root"; then
        msg="Активный профиль в config: $current
Каталог отсутствует: $current_dir

В $state_root есть файлы конфигурации модулей (после apply или переноса legacy).
Каталог profiles/ в пакет деплоя не входит — его создают на роутере.

Уже есть в profiles/: $profiles_human
Шаблоны (profile-templates/): $templates_human

Дальнейшие шаги (выполните в shell на роутере, без автозапуска из меню):

  1) Восстановить profiles/$current из state:
     cd $ROOT_DIR
     $restore_cmd

  2) Или создать эталон из шаблона (если нужен шаблон, а не снимок state):
     cd $ROOT_DIR
     $instantiate_cmd
     (шаблон default замените на имя из profile-templates/)

После появления каталога: Шаблоны и профили → «Применить шаблон на роутер»."
    else
        state_note="отсутствует или в нём нет каталогов модулей"
        if [ ! -d "$state_root" ]; then
            state_note="каталог отсутствует"
        fi
        msg="Активный профиль в config: $current
Каталог отсутствует: $current_dir

Каталог state ($state_root) $state_note.
profiles/ в архив деплоя не поставляется — создайте рабочий профиль из шаблона.

Шаблоны (profile-templates/): $templates_human

  • Меню → Шаблоны и профили → «Создать / пересоздать профиль из шаблона»
    (выберите шаблон, имя профиля: $current)

  • Или в shell:
    cd $ROOT_DIR
    $instantiate_cmd
    (шаблон default замените при необходимости)

Затем: Шаблоны и профили → «Применить шаблон на роутер»."
    fi

    if ui_have_whiptail; then
        ui_show_textbox_text "Профиль не найден — что сделать" "$msg" 28 110
    else
        printf '\n%s\n\n' "$msg"
    fi
}

maybe_restore_working_profile_from_applied() {
    applied="$(common_applied_profile_name 2>/dev/null || true)"
    [ -n "${applied:-}" ] || return 0

    applied_dir="$(common_profile_resolve_dir "$ROOT_DIR" "$applied" 2>/dev/null || true)"
    if [ -z "${applied_dir:-}" ] || [ ! -d "$applied_dir" ]; then
        common_clear_applied_profile 2>/dev/null || true
        return 0
    fi

    current="$(current_profile_name)"
    [ "$current" = "$applied" ] && return 0

    set_active_profile_in_config "$applied"
}

maybe_prompt_profile_at_startup() {
    profiles="$(list_profile_names || true)"
    [ -n "$profiles" ] || return 0

    n="$(profile_name_count "$profiles")"
    current="$(current_profile_name)"
    current_dir="$(current_profile_dir)"

    # Активный из config указывает на существующий каталог — не показываем выбор при нескольких профилях.
    if [ -d "$current_dir" ]; then
        return 0
    fi

    # Каталога нет: сначала могли предложить restore выше; если всё ещё нет — выбрать из сборки.
    if [ "$n" -ge 2 ] 2>/dev/null; then
        choice="$(ui_select_from_lines "Активный профиль" "Каталог активного профиля отсутствует в этой сборке.

Текущий в config: $current
Ожидался каталог: $current_dir

Выберите профиль из доступных в profiles/:" "$profiles" 22 90 12 || true)"
        [ -n "${choice:-}" ] || return 0

        case "$choice" in
            *[!A-Za-z0-9._-]*|'')
                ui_msgbox "Активный профиль" "Некорректное имя профиля: $choice"
                return 0
                ;;
        esac

        set_active_profile_in_config "$choice"
        load_base_config "$ROOT_DIR"
        return 0
    fi

    if [ "$n" -eq 1 ] 2>/dev/null; then
        only_one="$(printf '%s\n' "$profiles" | head -n1)"
        if ui_confirm "Активный профиль" "В config указан профиль «$current», но каталога нет.

В сборке только один профиль: $only_one

Переключить активный профиль на «$only_one»?"; then
            set_active_profile_in_config "$only_one"
            load_base_config "$ROOT_DIR"
        fi
    fi
}

root_menu_run_startup() {
	# UI нужен сразу: при активной фоновой задаче сначала показываем её
	# (и ждём завершения), и только потом — обычный старт.
	ui_init
	ui_trap_cleanup_on_exit

	if detect_running_job; then
		if ! ui_have_whiptail; then
			show_running_job_log_tty
		fi
		show_running_job_log_ui
	fi

	ensure_button_hooks_at_startup
	run_startup_migrations
	ensure_startup_packages
	ensure_launcher_command
	show_startup_migration_summary
	maybe_restore_working_profile_from_applied
	if [ -x "$ROOT_DIR/system/sync-runtime-status.sh" ]; then
		XFREE_TOOLBOX_ROOT="$ROOT_DIR" sh "$ROOT_DIR/system/sync-runtime-status.sh" >/dev/null 2>&1 || true
	fi
	maybe_show_missing_profile_guidance_at_startup
	maybe_prompt_profile_at_startup
}
