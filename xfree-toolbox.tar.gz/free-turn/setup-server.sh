#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

version="${1:-}"

info "=== Начало настройки FreeTurn сервера ==="

# 1. Отключаем старый vk-turn чтобы освободить ресурсы и не дублировать сервисы
freeturn_disable_vk_turn

# 2. Устанавливаем бинарник FreeTurn (с автоопределением архитектуры роутера)
freeturn_install_server "$version"

# 3. Настраиваем AWG Ingress бэкенд
awgingress_configure_ingress

# 4. Настраиваем firewall (Allow-free-turn на порт FREETURN_PORT)
freeturn_configure_firewall

# 5. Устанавливаем и запускаем init-сервис
freeturn_install_service

echo
success "=== FreeTurn server успешно установлен и запущен! ==="
echo
echo "Параметры для подключения клиентов (второго роутера или Android):"
echo "  Сервер (Peer)     : ${FREETURN_ROUTER_HOST}:${FREETURN_PORT}"
echo "  Профиль обфускации: ${FREETURN_OBF_PROFILE:-rtpopus3}"
echo "  Ключ обфускации   : $(freeturn_get_obf_key)"
echo "  Режим             : ${FREETURN_MODE:-udp}"
echo
echo "Пример команды запуска клиента на втором роутере:"
echo "  /opt/free-turn-proxy/client \\"
echo "    -listen 127.0.0.1:${FREETURN_LOCAL_PORT:-9000} \\"
echo "    -peer ${FREETURN_ROUTER_HOST}:${FREETURN_PORT} \\"
echo "    -links \"<ВАША_ССЫЛКА_НА_ЗВОНОК_ВК>\" \\"
echo "    -mode udp \\"
echo "    -obf-profile ${FREETURN_OBF_PROFILE:-rtpopus3} \\"
echo "    -obf-key $(freeturn_get_obf_key) \\"
echo "    -n 8"
echo
