#!/bin/sh
# shellcheck shell=sh

if [ -n "${FREETURN_SCRIPT_DIR:-}" ]; then
    FREETURN_LIB_DIR="$FREETURN_SCRIPT_DIR"
elif [ -n "${ROOT_DIR:-}" ] && [ -f "${ROOT_DIR}/free-turn/config.sh" ]; then
    FREETURN_LIB_DIR="${ROOT_DIR}/free-turn"
else
    FREETURN_LIB_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
fi
ROOT_DIR="$(CDPATH= cd -- "$FREETURN_LIB_DIR/.." && pwd -P)"
. "$FREETURN_LIB_DIR/config.sh"
AWG_INGRESS_LIB_SH="$ROOT_DIR/awg-ingress/lib.sh"
[ -f "$AWG_INGRESS_LIB_SH" ] || die "Не найден awg-ingress/lib.sh: $AWG_INGRESS_LIB_SH"
# shellcheck disable=SC1090
. "$AWG_INGRESS_LIB_SH"

freeturn_detect_asset_name() {
    if [ -n "${FREETURN_ASSET_NAME:-}" ]; then
        printf '%s\n' "$FREETURN_ASSET_NAME"
        return 0
    fi

    raw_arch=""
    if [ -f /etc/openwrt_release ]; then
        # shellcheck disable=SC1091
        . /etc/openwrt_release
        raw_arch="${OPENWRT_ARCH:-${DISTRIB_ARCH:-}}"
    fi

    if [ -z "$raw_arch" ] && command -v opkg >/dev/null 2>&1; then
        raw_arch="$(opkg print-architecture 2>/dev/null | awk '$1=="arch" && $2!="all" && $2!="noarch" {print $2, $3}' | sort -k2,2n | tail -n1 | awk '{print $1}' || true)"
    fi

    if [ -z "$raw_arch" ]; then
        raw_arch="$(uname -m 2>/dev/null || true)"
    fi

    case "$raw_arch" in
        aarch64*|arm64*)
            printf '%s\n' "server-linux-arm64"
            return 0
            ;;
        x86_64*|amd64*)
            printf '%s\n' "server-linux-amd64"
            return 0
            ;;
        i[3-6]86*|x86)
            printf '%s\n' "server-linux-386"
            return 0
            ;;
        armv7*|arm_cortex-a7*|arm_cortex-a9*|arm_cortex-a15*|arm_arm1176jzf-s*|arm_mpcore*)
            printf '%s\n' "server-linux-armv7"
            return 0
            ;;
        mips64el*|mips64le*)
            printf '%s\n' "server-linux-mips64le-softfloat"
            return 0
            ;;
        mipsel*|mipsle*)
            printf '%s\n' "server-linux-mipsle-softfloat"
            return 0
            ;;
        mips*)
            printf '%s\n' "server-linux-mips-softfloat"
            return 0
            ;;
        riscv64*)
            printf '%s\n' "server-linux-riscv64"
            return 0
            ;;
    esac

    # Fallback по умолчанию для популярных роутеров ARM64
    warn "Не удалось точно определить архитектуру ($raw_arch), использую server-linux-arm64"
    printf '%s\n' "server-linux-arm64"
}

freeturn_get_installed_version() {
    if [ -f "$FREETURN_VERSION_FILE" ]; then
        version="$(head -n1 "$FREETURN_VERSION_FILE" 2>/dev/null | tr -d '\r\n\t ')"
        [ -n "$version" ] && {
            printf '%s\n' "$version"
            return 0
        }
    fi

    if [ -x "$FREETURN_BIN" ]; then
        version="$(
            "$FREETURN_BIN" --version 2>/dev/null \
                | awk 'match($0,/v[0-9]+\.[0-9]+\.[0-9]+/){print substr($0,RSTART,RLENGTH); exit}'
        )"
        [ -n "$version" ] || version="$(
            "$FREETURN_BIN" -version 2>/dev/null \
                | awk 'match($0,/v[0-9]+\.[0-9]+\.[0-9]+/){print substr($0,RSTART,RLENGTH); exit}'
        )"
        [ -n "$version" ] && {
            freeturn_set_version "$version" 2>/dev/null || true
            printf '%s\n' "$version"
            return 0
        }
        printf '%s\n' "installed"
        return 0
    fi

    printf '%s\n' "not-installed"
}

freeturn_set_version() {
    echo "$1" > "$FREETURN_VERSION_FILE"
}

freeturn_fetch_latest() {
    curl -fsSL "https://github.com/$FREETURN_REPO/releases/latest" \
        | grep -Eo 'v[0-9]+\.[0-9]+\.[0-9]+' \
        | head -n1
}

freeturn_resolve_install_version() {
    requested="${1:-}"
    if [ -n "$requested" ]; then
        printf '%s\n' "$requested"
        return 0
    fi

    latest="$(freeturn_fetch_latest 2>/dev/null || true)"
    if [ -n "$latest" ]; then
        printf '%s\n' "$latest"
        return 0
    fi

    warn "Не удалось получить latest release FreeTurn, использую default: $FREETURN_DEFAULT_VERSION"
    printf '%s\n' "$FREETURN_DEFAULT_VERSION"
}

freeturn_ensure_obf_key() {
    freeturn_ensure_dirs
    if [ -f "$FREETURN_OBF_KEY_FILE" ]; then
        key="$(tr -d '\r\n\t ' < "$FREETURN_OBF_KEY_FILE" 2>/dev/null || true)"
        if [ "${#key}" -eq 64 ]; then
            printf '%s\n' "$key"
            return 0
        fi
    fi

    key=""
    if [ -x "$FREETURN_BIN" ]; then
        key="$("$FREETURN_BIN" -gen-obf-key 2>/dev/null | tr -d '\r\n\t ' || true)"
    fi

    if [ "${#key}" -ne 64 ] && command -v openssl >/dev/null 2>&1; then
        key="$(openssl rand -hex 32 2>/dev/null | tr -d '\r\n\t ' || true)"
    fi

    if [ "${#key}" -ne 64 ] && [ -r /dev/urandom ]; then
        if command -v od >/dev/null 2>&1; then
            key="$(od -An -tx1 -N32 /dev/urandom 2>/dev/null | tr -d ' \r\n\t' | head -c 64 || true)"
        elif command -v hexdump >/dev/null 2>&1; then
            key="$(hexdump -n 32 -e '32/1 "%02x"' /dev/urandom 2>/dev/null | tr -d ' \r\n\t' | head -c 64 || true)"
        fi
    fi

    [ "${#key}" -eq 64 ] || die "Не удалось сгенерировать 32-байтный hex ключ обфускации"

    printf '%s\n' "$key" > "$FREETURN_OBF_KEY_FILE"
    chmod 600 "$FREETURN_OBF_KEY_FILE" 2>/dev/null || true
    echo "[*] Сгенерирован новый ключ обфускации: $FREETURN_OBF_KEY_FILE" >&2
    printf '%s\n' "$key"
}

freeturn_get_obf_key() {
    if [ -f "$FREETURN_OBF_KEY_FILE" ]; then
        tr -d '\r\n\t ' < "$FREETURN_OBF_KEY_FILE"
    else
        freeturn_ensure_obf_key
    fi
}

freeturn_stop() {
    if [ -x "$FREETURN_INIT_SCRIPT" ]; then
        info "Останавливаю сервис $FREETURN_SERVICE_NAME"
        "$FREETURN_INIT_SCRIPT" stop 2>/dev/null || true
    fi
}

freeturn_start() {
    if [ -x "$FREETURN_INIT_SCRIPT" ]; then
        info "Запускаю сервис $FREETURN_SERVICE_NAME"
        "$FREETURN_INIT_SCRIPT" start || true
    fi
}

freeturn_disable_vk_turn() {
    info "Проверяю и отключаю старый vk-turn..."
    if [ -x "/etc/init.d/vk-turn" ]; then
        info "Останавливаю и отключаю сервис vk-turn"
        /etc/init.d/vk-turn stop 2>/dev/null || true
        /etc/init.d/vk-turn disable 2>/dev/null || true
    fi

    # Удаление firewall-правила старого vk-turn
    firewall_changed=0
    if uci -q get firewall.vk_turn >/dev/null 2>&1; then
        uci -q delete firewall.vk_turn || true
        firewall_changed=1
    fi
    # Также проверим по имени правила Allow-vk-turn
    rules="$(uci show firewall 2>/dev/null | grep -E "\.name='?Allow-vk-turn'?" | cut -d'.' -f2 | cut -d'=' -f1 || true)"
    for r in $rules; do
        if [ -n "$r" ]; then
            uci -q delete "firewall.$r" || true
            firewall_changed=1
        fi
    done

    if [ "$firewall_changed" -eq 1 ]; then
        uci commit firewall 2>/dev/null || true
        /etc/init.d/firewall restart 2>/dev/null || true
        info "Удалено правило firewall для vk-turn"
    fi
    success "Старый vk-turn отключен"
}

freeturn_check_disk_space() {
    min_kb="${1:-25600}"
    target_dir="${2:-$FREETURN_DIR}"
    [ -d "$target_dir" ] || target_dir="$(dirname "$target_dir")"
    [ -d "$target_dir" ] || target_dir="/opt"
    [ -d "$target_dir" ] || target_dir="/"

    avail_kb="$(df -k "$target_dir" 2>/dev/null | tail -n 1 | awk '{print $4}')"
    case "$avail_kb" in
        ''|*[!0-9]*) return 0 ;;
    esac

    if [ "$avail_kb" -lt "$min_kb" ]; then
        avail_mb=$((avail_kb / 1024))
        req_mb=$((min_kb / 1024))
        die "Недостаточно свободного места на диске ($target_dir): свободно ${avail_mb} МБ, требуется минимум ${req_mb} МБ"
    fi
}

freeturn_install_server() {
    version="$(freeturn_resolve_install_version "${1:-}")"
    asset="$(freeturn_detect_asset_name)"
    url="https://github.com/$FREETURN_REPO/releases/download/$version/$asset"

    freeturn_ensure_dirs
    freeturn_stop
    freeturn_check_disk_space 25600 "$FREETURN_DIR"

    info "Скачиваю $asset ($version) из $url"
    if ! http_fetch_file "$url" "$FREETURN_BIN"; then
        rm -f "$FREETURN_BIN"
        die "Не удалось скачать серверный бинарник: $url"
    fi

    chmod +x "$FREETURN_BIN"
    freeturn_set_version "$version"
    freeturn_ensure_obf_key >/dev/null

    success "Установлен FreeTurn server ($asset) версии $version"
}

freeturn_detect_client_asset_name() {
    server_asset="$(freeturn_detect_asset_name)"
    printf 'client-%s\n' "${server_asset#server-}"
}

freeturn_client_get_installed_version() {
    if [ -f "$FREETURN_CLIENT_VERSION_FILE" ]; then
        version="$(head -n1 "$FREETURN_CLIENT_VERSION_FILE" 2>/dev/null | tr -d '\r\n\t ')"
        [ -n "$version" ] && {
            printf '%s\n' "$version"
            return 0
        }
    fi

    if [ -x "$FREETURN_CLIENT_BIN" ]; then
        version="$(
            "$FREETURN_CLIENT_BIN" --version 2>/dev/null \
                | awk 'match($0,/v[0-9]+\.[0-9]+\.[0-9]+/){print substr($0,RSTART,RLENGTH); exit}'
        )"
        [ -n "$version" ] || version="$(
            "$FREETURN_CLIENT_BIN" -version 2>/dev/null \
                | awk 'match($0,/v[0-9]+\.[0-9]+\.[0-9]+/){print substr($0,RSTART,RLENGTH); exit}'
        )"
        [ -n "$version" ] && {
            echo "$version" > "$FREETURN_CLIENT_VERSION_FILE" 2>/dev/null || true
            printf '%s\n' "$version"
            return 0
        }
        printf '%s\n' "installed"
        return 0
    fi

    printf '%s\n' "not-installed"
}

freeturn_install_client() {
    version="$(freeturn_resolve_install_version "${1:-}")"
    asset="$(freeturn_detect_client_asset_name)"
    url="https://github.com/$FREETURN_REPO/releases/download/$version/$asset"

    freeturn_ensure_dirs
    freeturn_check_disk_space 25600 "$FREETURN_DIR"

    info "Скачиваю $asset ($version) из $url"
    if ! http_fetch_file "$url" "$FREETURN_CLIENT_BIN"; then
        rm -f "$FREETURN_CLIENT_BIN"
        die "Не удалось скачать клиентский бинарник: $url"
    fi

    chmod +x "$FREETURN_CLIENT_BIN"
    echo "$version" > "$FREETURN_CLIENT_VERSION_FILE"

    success "Установлен FreeTurn client ($asset) версии $version"
}

freeturn_uninstall_client() {
    rm -f "$FREETURN_CLIENT_BIN" "$FREETURN_CLIENT_VERSION_FILE"
    if [ ! -f "$FREETURN_BIN" ]; then
        rm -rf "$FREETURN_DIR"
    fi
    success "FreeTurn client удален"
}

freeturn_configure_ingress() {
    awgingress_configure_ingress
}

freeturn_configure_firewall() {
    awgingress_configure_firewall
    info "Настраиваю firewall для $FREETURN_SERVICE_NAME"

    rule_section="${FREETURN_FIREWALL_RULE_SECTION:-free_turn}"
    uci -q delete "firewall.$rule_section" || true
    uci set "firewall.$rule_section=rule"
    uci set "firewall.$rule_section.name=$FREETURN_FIREWALL_RULE_NAME"
    uci set "firewall.$rule_section.src=$FREETURN_WAN_IF"
    uci set "firewall.$rule_section.proto=udp"
    uci set "firewall.$rule_section.dest_port=$FREETURN_PORT"
    uci set "firewall.$rule_section.target=ACCEPT"

    uci commit firewall
    /etc/init.d/firewall restart

    success "Firewall для $FREETURN_SERVICE_NAME настроен (порт $FREETURN_PORT/udp)"
}

freeturn_install_service() {
    freeturn_ensure_dirs
    info "Создаю сервис $FREETURN_SERVICE_NAME"

    obf_key="$(freeturn_get_obf_key)"
    obf_profile="${FREETURN_OBF_PROFILE:-rtpopus3}"
    obf_timing="${FREETURN_OBF_TIMING:-0}"
    mode="${FREETURN_MODE:-udp}"

    cat > "$FREETURN_INIT_SCRIPT" <<EOF
#!/bin/sh /etc/rc.common

START=99
STOP=10
USE_PROCD=1

BIN="$FREETURN_BIN"
LISTEN_ADDR="0.0.0.0:$FREETURN_PORT"
CONNECT_ADDR="127.0.0.1:$FREETURN_INGRESS_PORT"
INGRESS_IF="$FREETURN_INGRESS_IF"
MODE="$mode"
OBF_PROFILE="$obf_profile"
OBF_KEY="$obf_key"
OBF_TIMING="$obf_timing"

start_service() {
    [ -x "\$BIN" ] || return 1
    ip link show "\$INGRESS_IF" >/dev/null 2>&1 || return 1

    procd_open_instance
    procd_set_param command "\$BIN" \\
        -listen "\$LISTEN_ADDR" \\
        -connect "\$CONNECT_ADDR" \\
        -mode "\$MODE"

    if [ "\$OBF_PROFILE" != "none" ] && [ -n "\$OBF_KEY" ]; then
        procd_append_param command -obf-profile "\$OBF_PROFILE"
        procd_append_param command -obf-key "\$OBF_KEY"
    fi

    if [ "\$OBF_TIMING" != "0" ] && [ -n "\$OBF_TIMING" ]; then
        procd_append_param command -obf-timing "\$OBF_TIMING"
    fi

    procd_set_param respawn 3600 5 5
    procd_set_param stdout 1
    procd_set_param stderr 1
    procd_close_instance
}

service_triggers() {
    procd_add_interface_trigger "interface.*" "wan" /etc/init.d/free-turn restart
    procd_add_interface_trigger "interface.*" "\$INGRESS_IF" /etc/init.d/free-turn restart
}
EOF

    chmod +x "$FREETURN_INIT_SCRIPT"
    "$FREETURN_INIT_SCRIPT" enable 2>/dev/null || true
    "$FREETURN_INIT_SCRIPT" restart 2>/dev/null || "$FREETURN_INIT_SCRIPT" start 2>/dev/null || true

    success "Сервис $FREETURN_SERVICE_NAME установлен и запущен"
}

freeturn_status() {
    echo "=== FREETURN VERSION ==="
    echo "Установлено : $(freeturn_get_installed_version)"
    echo "Архитектура : $(freeturn_detect_asset_name)"
    echo "Последняя   : $(freeturn_fetch_latest 2>/dev/null || echo unknown)"
    echo
    echo "=== OBFUSCATION CONFIG ==="
    echo "Profile: ${FREETURN_OBF_PROFILE:-rtpopus3}"
    echo "Key:     $([ -f "$FREETURN_OBF_KEY_FILE" ] && cat "$FREETURN_OBF_KEY_FILE" || echo 'не создан')"
    echo "Port:    $FREETURN_PORT (UDP)"
    echo "Backend: 127.0.0.1:$FREETURN_INGRESS_PORT ($FREETURN_INGRESS_IF)"
    echo
    echo "=== PROCD SERVICE ==="
    if [ -x "$FREETURN_INIT_SCRIPT" ]; then
        "$FREETURN_INIT_SCRIPT" status 2>/dev/null || echo "Service status command not available"
    else
        echo "Сервис не установлен ($FREETURN_INIT_SCRIPT)"
    fi
    echo
    echo "=== LISTENING PORTS ==="
    netstat -lpn 2>/dev/null | grep -E "$FREETURN_PORT|$FREETURN_INGRESS_PORT" || true
    echo
    echo "=== AWG INGRESS ==="
    awg show "$FREETURN_INGRESS_IF" 2>/dev/null || true
    echo
    echo "=== AWG INGRESS PEERS ==="
    awgingress_peers_meta_list || true
}

freeturn_set_port() {
    new_port="${1:-}"
    case "$new_port" in
        ''|*[!0-9]*)
            die "Некорректный номер порта: '$new_port' (должно быть число от 1 до 65535)"
            ;;
    esac
    if [ "$new_port" -lt 1 ] || [ "$new_port" -gt 65535 ]; then
        die "Порт вне допустимого диапазона 1-65535: $new_port"
    fi

    freeturn_ensure_dirs
    printf '%s\n' "$new_port" > "$FREETURN_PORT_FILE"
    info "Сохранён новый порт FreeTurn: $new_port"

    FREETURN_PORT="$new_port"

    # 1. Обновляем Firewall правило Allow-free-turn
    freeturn_configure_firewall

    # 2. Если сервис установлен, обновляем procd init-скрипт и перезапускаем
    if [ -x "$FREETURN_INIT_SCRIPT" ] || [ -f "$FREETURN_BIN" ]; then
        freeturn_stop
        freeturn_install_service
        freeturn_start
    fi

    success "Внешний порт FreeTurn успешно изменён на $new_port"
}

freeturn_uninstall() {
    info "Удаляю FreeTurn proxy..."
    if [ -x "$FREETURN_INIT_SCRIPT" ]; then
        "$FREETURN_INIT_SCRIPT" stop 2>/dev/null || true
        "$FREETURN_INIT_SCRIPT" disable 2>/dev/null || true
        rm -f "$FREETURN_INIT_SCRIPT"
    fi
    rm -f "$FREETURN_BIN" "$FREETURN_VERSION_FILE"
    if [ ! -f "$FREETURN_CLIENT_BIN" ]; then
        rm -rf "$FREETURN_DIR"
    fi
    rm -rf "$FREETURN_STATE_DIR"

    firewall_changed=0
    if uci -q get firewall.free_turn >/dev/null 2>&1; then
        uci -q delete firewall.free_turn || true
        firewall_changed=1
    fi
    rules="$(uci show firewall 2>/dev/null | grep -E "\.name='?Allow-free-turn'?" | cut -d'.' -f2 | cut -d'=' -f1 || true)"
    for r in $rules; do
        if [ -n "$r" ]; then
            uci -q delete "firewall.$r" || true
            firewall_changed=1
        fi
    done
    if [ "$firewall_changed" -eq 1 ]; then
        uci commit firewall 2>/dev/null || true
        /etc/init.d/firewall restart 2>/dev/null || true
        info "Удалено правило firewall для free-turn"
    fi
    success "FreeTurn proxy полностью удалён и очищен"
}
