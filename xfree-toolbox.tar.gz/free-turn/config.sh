#!/bin/sh
# shellcheck shell=sh

if [ -z "${ROOT_DIR:-}" ] || [ ! -f "${ROOT_DIR}/lib/common.sh" ]; then
    SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
else
    SCRIPT_DIR="$ROOT_DIR/free-turn"
fi
FREETURN_SCRIPT_DIR="$SCRIPT_DIR"
FREETURN_ROOT_DIR="$ROOT_DIR"

. "$ROOT_DIR/lib/common.sh"
common_load_project_config "$ROOT_DIR"

AWG_INGRESS_CONFIG_SH="$ROOT_DIR/awg-ingress/config.sh"
[ -f "$AWG_INGRESS_CONFIG_SH" ] || die "Не найден awg-ingress/config.sh: $AWG_INGRESS_CONFIG_SH"
# shellcheck disable=SC1090
. "$AWG_INGRESS_CONFIG_SH"
SCRIPT_DIR="$FREETURN_SCRIPT_DIR"
ROOT_DIR="$FREETURN_ROOT_DIR"

FREETURN_REPO="hackdiaz-dev/free-turn-proxy"
FREETURN_DEFAULT_VERSION="v4.1.0"
FREETURN_ASSET_NAME="${FREETURN_ASSET_NAME:-}"

FREETURN_DIR="/opt/free-turn-proxy"
FREETURN_BIN="$FREETURN_DIR/server"
FREETURN_VERSION_FILE="$FREETURN_DIR/version"
FREETURN_CLIENT_BIN="$FREETURN_DIR/client"
FREETURN_CLIENT_VERSION_FILE="$FREETURN_DIR/client-version"

FREETURN_SERVICE_NAME="free-turn"
FREETURN_FIREWALL_RULE_SECTION="free_turn"
FREETURN_INIT_SCRIPT="/etc/init.d/$FREETURN_SERVICE_NAME"
FREETURN_WAN_IF="wan"

FREETURN_STATE_ROOT="${FREETURN_STATE_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/free-turn}"
FREETURN_STATE_DIR="$FREETURN_STATE_ROOT/state"
FREETURN_OBF_KEY_FILE="$FREETURN_STATE_DIR/obf.key"
FREETURN_CLIENTS_FILE="$FREETURN_STATE_DIR/clients.json"
FREETURN_PORT_FILE="$FREETURN_STATE_DIR/port"

FREETURN_INGRESS_IF="$AWG_INGRESS_IF"
FREETURN_INGRESS_PORT="$AWG_INGRESS_PORT"
FREETURN_ROUTER_HOST="${FREETURN_ROUTER_HOST:-${AWG_INGRESS_ROUTER_HOST:-}}"
if [ -z "$FREETURN_ROUTER_HOST" ] && [ -n "${AWG_INGRESS_PEER_ENDPOINT:-}" ]; then
    case "$AWG_INGRESS_PEER_ENDPOINT" in
        \[*\]:*)
            FREETURN_ROUTER_HOST="${AWG_INGRESS_PEER_ENDPOINT%%\]:*}"
            FREETURN_ROUTER_HOST="${FREETURN_ROUTER_HOST#\[}"
            ;;
        *:*)
            FREETURN_ROUTER_HOST="${AWG_INGRESS_PEER_ENDPOINT%:*}"
            ;;
        *)
            FREETURN_ROUTER_HOST="$AWG_INGRESS_PEER_ENDPOINT"
            ;;
    esac
fi

FREETURN_FIREWALL_RULE_NAME="Allow-free-turn"

# Параметры протокола и обфускации FreeTurn
FREETURN_MODE="${FREETURN_MODE:-udp}"
FREETURN_OBF_PROFILE="${FREETURN_OBF_PROFILE:-rtpopus3}"
FREETURN_OBF_TIMING="${FREETURN_OBF_TIMING:-0}"

FREETURN_PORT="${FREETURN_PORT:-}"
if [ -z "$FREETURN_PORT" ]; then
    if [ -f "$FREETURN_PORT_FILE" ]; then
        FREETURN_PORT="$(tr -d '\r\n\t ' < "$FREETURN_PORT_FILE" 2>/dev/null || true)"
    fi
    if [ -z "${FREETURN_PORT:-}" ] && command -v uci >/dev/null 2>&1; then
        FREETURN_PORT="$(uci -q get firewall.free_turn.dest_port 2>/dev/null || true)"
    fi
    FREETURN_PORT="${FREETURN_PORT:-56000}"
fi

freeturn_ensure_dirs() {
    mkdir -p "$FREETURN_DIR" "$FREETURN_STATE_DIR"
}
