#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/config.sh"
. "$SCRIPT_DIR/lib.sh"

PEER=""
LOCAL_PORT="9000"
PEER_HOST_PORT=""
OUTPUT=""

usage() {
    cat <<EOF
Usage: $0 --peer <slug|name> [options]

Generate FreeTurn client launch config, WireGuard config and freeturn:// URI from existing AWG peer.

Options:
  --peer <slug|name>         Existing AWG peer in state/profile (required)
  --peer-host <host[:port]>  FreeTurn server host:port (default: ${FREETURN_ROUTER_HOST}:${FREETURN_PORT})
  --local-port <port>        Local client listening port (default: $LOCAL_PORT)
  --output <path>            Write WireGuard config to file
  -h, --help
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --peer) shift; [ "$#" -gt 0 ] || die "--peer требует значение"; PEER="$1" ;;
        --peer-host) shift; [ "$#" -gt 0 ] || die "--peer-host требует значение"; PEER_HOST_PORT="$1" ;;
        --local-port) shift; [ "$#" -gt 0 ] || die "--local-port требует значение"; LOCAL_PORT="$1" ;;
        --output) shift; [ "$#" -gt 0 ] || die "--output требует значение"; OUTPUT="$1" ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
    shift || true
done

[ -n "$PEER" ] || die "Не указан --peer"

slug="$(awgingress_resolve_peer_slug "$PEER")" || die "Не найден peer: $PEER"
awgingress_load_peer_state "$slug"

if [ -z "$PEER_HOST_PORT" ]; then
    awg_endpoint="${PEER_ENDPOINT_STATE:-}"
    endpoint_host=""
    if [ -n "$awg_endpoint" ]; then
        case "$awg_endpoint" in
            \[*\]:*)
                endpoint_host="${awg_endpoint%%\]:*}"
                endpoint_host="${endpoint_host#\[}"
                ;;
            *:*)
                endpoint_host="${awg_endpoint%:*}"
                ;;
            *)
                endpoint_host="$awg_endpoint"
                ;;
        esac
    fi

    if [ -n "$endpoint_host" ]; then
        PEER_HOST_PORT="${endpoint_host}:${FREETURN_PORT}"
    elif [ -n "${AWG_INGRESS_ROUTER_HOST:-}" ]; then
        PEER_HOST_PORT="${AWG_INGRESS_ROUTER_HOST}:${FREETURN_PORT}"
    else
        PEER_HOST_PORT="127.0.0.1:${FREETURN_PORT}"
    fi
fi

obf_key="$(freeturn_get_obf_key)"
obf_profile="${FREETURN_OBF_PROFILE:-rtpopus3}"

# 1. Формируем WireGuard конфиг с локальным Endpoint (127.0.0.1:LOCAL_PORT)
wg_endpoint="127.0.0.1:${LOCAL_PORT}"
base_wg_conf="$(awgingress_render_peer_config "$slug" "$wg_endpoint")"

# 2. Формируем freeturn:// URI для Android приложения (turn-proxy-android v5)
# Формат: {"v":1,"provider":"vk","peer":"host:port","transport":"tcp","mode":"udp","obf":"rtpopus3","key":"...","wg":"..."}
escaped_wg_conf="$(printf '%s' "$base_wg_conf" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' | awk '{printf "%s\\n", $0}' ORS='\\n')"
json_payload="{\"v\":1,\"provider\":\"vk\",\"peer\":\"${PEER_HOST_PORT}\",\"transport\":\"tcp\",\"mode\":\"${FREETURN_MODE:-udp}\",\"obf\":\"${obf_profile}\",\"key\":\"${obf_key}\",\"wg\":\"${escaped_wg_conf}\"}"

b64_payload=""
if command -v base64 >/dev/null 2>&1; then
    b64_payload="$(printf '%s' "$json_payload" | base64 | tr -d '\r\n ' | tr '+/' '-_' | tr -d '=')"
elif command -v openssl >/dev/null 2>&1; then
    b64_payload="$(printf '%s' "$json_payload" | openssl base64 -e 2>/dev/null | tr -d '\r\n ' | tr '+/' '-_' | tr -d '=')"
fi

echo "================================================================="
echo " FreeTurn Client Connection Details (Peer: $PEER)"
echo "================================================================="
echo
echo "1. Параметры запуска FreeTurn Client на ВТОРОМ РОУТЕРЕ (или ПК):"
echo "-----------------------------------------------------------------"
echo "  /opt/free-turn-proxy/client \\"
echo "    -listen 127.0.0.1:${LOCAL_PORT} \\"
echo "    -peer ${PEER_HOST_PORT} \\"
echo "    -links \"<ССЫЛКА_НА_ЗВОНОК_ВК>\" \\"
echo "    -mode ${FREETURN_MODE:-udp} \\"
echo "    -obf-profile ${obf_profile} \\"
echo "    -obf-key ${obf_key} \\"
echo "    -n 8"
echo
if [ -n "$b64_payload" ]; then
    echo "2. Share URI для FreeTurn Android приложения (FreeTurn v5):"
    echo "-----------------------------------------------------------------"
    echo "  freeturn://${b64_payload}"
    echo
fi
echo "3. WireGuard / AmneziaWG клиентский конфиг (Endpoint -> 127.0.0.1:${LOCAL_PORT}):"
echo "-----------------------------------------------------------------"
if [ -n "$OUTPUT" ]; then
    mkdir -p "$(dirname -- "$OUTPUT")"
    printf '%s\n' "$base_wg_conf" > "$OUTPUT"
    chmod 600 "$OUTPUT" 2>/dev/null || true
    echo "Сохранен в файл: $OUTPUT"
else
    printf '%s\n' "$base_wg_conf"
fi
echo "================================================================="
