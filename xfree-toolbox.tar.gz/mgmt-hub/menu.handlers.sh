#!/bin/sh
# Hand-written handlers for mgmt-hub/menu.yaml (experimental overlay client).
# shellcheck shell=sh

MGMT_HUB_APPLY="${MGMT_HUB_APPLY:-$SCRIPT_DIR/router/apply-client.sh}"
MGMT_HUB_FETCH="${MGMT_HUB_FETCH:-$SCRIPT_DIR/router/fetch-client.sh}"
MGMT_HUB_CONFIGURE="${MGMT_HUB_CONFIGURE:-$SCRIPT_DIR/router/configure.sh}"

mgmt_hub_run() {
	title="$1"
	shift
	ui_menu_invoke_with_output "$title" "$@"
}

mgmt_hub_menu_choice_1() {
	mgmt_hub_run "Хаб управления: статус" sh "$MGMT_HUB_APPLY" --status
}

mgmt_hub_menu_choice_2() {
	mgmt_hub_run "Хаб управления: подключить" sh "$SCRIPT_DIR/router/ensure-client.sh"
}

mgmt_hub_menu_choice_3() {
	mgmt_hub_run "Хаб управления: выключить" sh "$MGMT_HUB_APPLY" --disable
}

mgmt_hub_menu_choice_4() {
	mgmt_hub_run "Хаб управления: подключить" sh "$SCRIPT_DIR/router/ensure-client.sh"
}

mgmt_hub_menu_choice_5() {
	url="$(ui_inputbox "Хаб управления" "URL дашборда (http://host:8080)" "" || true)"
	[ -n "${url:-}" ] || return 0
	store_id="$(ui_inputbox "Хаб управления" "store id роутера" "ax6s_26346095" || true)"
	[ -n "${store_id:-}" ] || return 0
	token="$(ui_inputbox "Хаб управления" "Токен (MGMT_HUB_TOKEN), пусто = без токена" "" || true)" || true
	mgmt_hub_run "Хаб управления: сохранить URL" sh "$MGMT_HUB_CONFIGURE" \
		--url "$url" --store-id "$store_id" --token "${token:-}"
}
