#!/usr/bin/env bash
# Seal each store client.conf to that router's SSH host key and upload the
# public blobs to the factory share the routers already wget.
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd -P)"
PY="${MGMT_HUB_PYTHON:-$ROOT/mgmt-hub/.venv/bin/python}"
OUT="${MGMT_SEAL_OUT:-$ROOT/ci/store/.mgmt-public}"
# shellcheck source=ci/lib/webdav.sh
source "$ROOT/ci/lib/webdav.sh"

[[ -x "$PY" ]] || {
  echo "[-] нет $PY" >&2
  exit 1
}
mkdir -p "$OUT"
PYTHONPATH="$ROOT/mgmt-hub/src${PYTHONPATH:+:$PYTHONPATH}" \
  "$PY" -m mgmt_hub.seal --store "$ROOT/ci/store" --out "$OUT"

if grep -l -a 'PrivateKey' "$OUT"/*.bin >/dev/null 2>&1; then
  echo "[-] sealed blob contains PrivateKey" >&2
  exit 1
fi

webdav_load_env "$ROOT"
webdav_check_auth
remote="${WEBDAV_FACTORY_REMOTE_DIR:-share/openwrt/factory}/mgmt"
n=0
for blob in "$OUT"/*.bin; do
  [[ -f "$blob" ]] || continue
  webdav_upload_file "$blob" "$remote" "$(basename "$blob")"
  n=$((n + 1))
done
echo "[ok] uploaded $n sealed client configs"
