#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1090
. "$ROOT_DIR/lib/ui.sh"

ui_have_whiptail || {
	echo "[!] whiptail не установлен" >&2
	exit 1
}

exec sh "$SCRIPT_DIR/menu.gen.sh" "${1:-ui}"
