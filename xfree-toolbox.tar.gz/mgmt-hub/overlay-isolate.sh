#!/bin/bash
# Isolate overlay iface: routers cannot reach hub services or the operator LAN.
# Hub-initiated SSH/LuCI still works (OUTPUT + ESTABLISHED).
# One exception: TCP MGMT_HUB_DESIRED_PORT (default 8079) on the overlay address,
# so a router can read desired.env while its own xft_mgmt iface is up.
# Dashboard :8080 stays dropped.
# shellcheck shell=bash
set -euo pipefail

overlay_isolate_ipt() {
  if command -v iptables >/dev/null 2>&1; then
    iptables "$@"
    return
  fi
  iptables-legacy "$@"
}

overlay_isolate_ensure_chain() {
  local name="$1"
  overlay_isolate_ipt -nL "$name" >/dev/null 2>&1 || overlay_isolate_ipt -N "$name"
  overlay_isolate_ipt -F "$name"
}

overlay_isolate_ensure_jump() {
  local hook="$1"
  local spec="$2"
  local chain="$3"
  # spec is like "-i awg0" or "-o awg0"
  # shellcheck disable=SC2086
  overlay_isolate_ipt -C "$hook" $spec -j "$chain" >/dev/null 2>&1 && return 0
  # shellcheck disable=SC2086
  overlay_isolate_ipt -I "$hook" $spec -j "$chain"
}

overlay_isolate_ipt6() {
  if command -v ip6tables >/dev/null 2>&1; then
    ip6tables "$@"
    return
  fi
  ip6tables-legacy "$@" 2>/dev/null || return 0
}

overlay_isolate_ensure_chain6() {
  local name="$1"
  overlay_isolate_ipt6 -nL "$name" >/dev/null 2>&1 || overlay_isolate_ipt6 -N "$name" || return 0
  overlay_isolate_ipt6 -F "$name"
}

overlay_isolate_ensure_jump6() {
  local hook="$1"
  local spec="$2"
  local chain="$3"
  # shellcheck disable=SC2086
  overlay_isolate_ipt6 -C "$hook" $spec -j "$chain" >/dev/null 2>&1 && return 0
  # shellcheck disable=SC2086
  overlay_isolate_ipt6 -I "$hook" $spec -j "$chain" || true
}

overlay_isolate_apply() {
  local iface="${1:-awg0}"
  desired_port="${MGMT_HUB_DESIRED_PORT:-8079}"
  overlay_isolate_ensure_chain XFREE_MGMT_IN
  overlay_isolate_ipt -A XFREE_MGMT_IN -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
  overlay_isolate_ipt -A XFREE_MGMT_IN -p tcp --dport "$desired_port" -j ACCEPT
  overlay_isolate_ipt -A XFREE_MGMT_IN -j DROP
  overlay_isolate_ensure_jump INPUT "-i $iface" XFREE_MGMT_IN

  overlay_isolate_ensure_chain XFREE_MGMT_FWD
  overlay_isolate_ipt -A XFREE_MGMT_FWD -j DROP
  overlay_isolate_ensure_jump FORWARD "-i $iface" XFREE_MGMT_FWD
  overlay_isolate_ensure_jump FORWARD "-o $iface" XFREE_MGMT_FWD

  overlay_isolate_ensure_chain6 XFREE_MGMT_IN6
  overlay_isolate_ipt6 -A XFREE_MGMT_IN6 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT || true
  overlay_isolate_ipt6 -A XFREE_MGMT_IN6 -j DROP || true
  overlay_isolate_ensure_jump6 INPUT "-i $iface" XFREE_MGMT_IN6

  overlay_isolate_ensure_chain6 XFREE_MGMT_FWD6
  overlay_isolate_ipt6 -A XFREE_MGMT_FWD6 -j DROP || true
  overlay_isolate_ensure_jump6 FORWARD "-i $iface" XFREE_MGMT_FWD6
  overlay_isolate_ensure_jump6 FORWARD "-o $iface" XFREE_MGMT_FWD6

  sysctl -w "net.ipv4.conf.${iface}.forwarding=0" >/dev/null 2>&1 || true
  sysctl -w "net.ipv6.conf.${iface}.forwarding=0" >/dev/null 2>&1 || true
  sysctl -w "net.ipv6.conf.${iface}.disable_ipv6=1" >/dev/null 2>&1 || true
  echo "[ok] overlay isolate $iface (peers cannot reach LAN, hub services, or each other)"
}

if [[ "${1:-}" == "apply" ]]; then
  overlay_isolate_apply "${2:-${MGMT_HUB_IF:-awg0}}"
fi
