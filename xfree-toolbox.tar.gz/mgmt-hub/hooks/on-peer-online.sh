#!/bin/sh
# Default hub hook: overlay peer came online. Pull a light probe if the last one is stale.
# Env: STORE_ID OVERLAY_IP SSH_USER SSH_KEY DATA_DIR STALE_S
set -eu

STORE_ID="${STORE_ID:-}"
OVERLAY_IP="${OVERLAY_IP:-}"
SSH_USER="${SSH_USER:-root}"
SSH_KEY="${SSH_KEY:-}"
DATA_DIR="${DATA_DIR:-/var/lib/xfree-mgmt-hub}"
HOOK_DIR="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"

[ -n "$STORE_ID" ] && [ -n "$OVERLAY_IP" ] || {
  echo "[-] on-peer-online: missing STORE_ID or OVERLAY_IP" >&2
  exit 1
}

exec sh "$HOOK_DIR/pull-probe.sh"
