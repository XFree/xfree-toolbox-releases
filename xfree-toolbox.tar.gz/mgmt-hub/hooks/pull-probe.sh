#!/bin/sh
# Pull the same router inventory as ci/probe-router-keys.sh (hub-initiated SSH).
# Env: STORE_ID OVERLAY_IP SSH_USER SSH_KEY DATA_DIR PROBE_INVENTORY_SH
set -eu

STORE_ID="${STORE_ID:-}"
OVERLAY_IP="${OVERLAY_IP:-}"
SSH_USER="${SSH_USER:-root}"
SSH_KEY="${SSH_KEY:-}"
DATA_DIR="${DATA_DIR:-/var/lib/xfree-mgmt-hub}"
HOOK_DIR="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"

[ -n "$STORE_ID" ] && [ -n "$OVERLAY_IP" ] && [ -f "$SSH_KEY" ] || {
  echo "[-] pull-probe: need STORE_ID, OVERLAY_IP, SSH_KEY" >&2
  exit 1
}

INV=""
for cand in \
  "${PROBE_INVENTORY_SH:-}" \
  "$HOOK_DIR/../../ci/ssh-toolbox/openwrt/router-inventory.sh" \
  /app/probe/router-inventory.sh
do
  if [ -n "$cand" ] && [ -f "$cand" ]; then
    INV="$cand"
    break
  fi
done
[ -n "$INV" ] || {
  echo "[-] pull-probe: router-inventory.sh not found" >&2
  exit 1
}

OUT_DIR="$DATA_DIR/observations/$STORE_ID"
mkdir -p "$OUT_DIR"
chmod 700 "$OUT_DIR" 2>/dev/null || true

TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

ssh -o IdentitiesOnly=yes -o BatchMode=yes -o ConnectTimeout=12 \
  -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=/dev/null \
  -i "$SSH_KEY" "${SSH_USER}@${OVERLAY_IP}" sh -s <"$INV" >"$TMP"

cp "$TMP" "$OUT_DIR/probe.env"
chmod 600 "$OUT_DIR/probe.env" 2>/dev/null || true
STORE_OBS="$DATA_DIR/store/$STORE_ID/observations"
mkdir -p "$STORE_OBS"
cp "$TMP" "$STORE_OBS/$STORE_ID.overlay-probe.env"
chmod 600 "$STORE_OBS/$STORE_ID.overlay-probe.env" 2>/dev/null || true
date +%s >"$OUT_DIR/probed_at"
chmod 600 "$OUT_DIR/probed_at" 2>/dev/null || true
echo "[ok] overlay probe $STORE_ID <- $OVERLAY_IP ($INV)"
