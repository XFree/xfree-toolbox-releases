/* Open an XFTMGMT1 blob with the Dropbear ed25519 host private key. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "vendor/monocypher.h"
#include "vendor/sha512.h"

static int read_file(const char *path, uint8_t **out, size_t *len) {
    FILE *fp = fopen(path, "rb");
    if (!fp) return 0;
    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); return 0; }
    long sz = ftell(fp);
    if (sz < 0 || sz > 1024 * 1024) { fclose(fp); return 0; }
    if (fseek(fp, 0, SEEK_SET) != 0) { fclose(fp); return 0; }
    uint8_t *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(fp); return 0; }
    if (sz && fread(buf, 1, (size_t)sz, fp) != (size_t)sz) { free(buf); fclose(fp); return 0; }
    fclose(fp);
    *out = buf;
    *len = (size_t)sz;
    return 1;
}

static int dropbear_seed(const uint8_t *blob, size_t len, uint8_t seed[32]) {
    static const uint8_t hdr[19] = {
        0, 0, 0, 0x0b, 's', 's', 'h', '-', 'e', 'd', '2', '5', '5', '1', '9', 0, 0, 0, 0x40};
    if (len < 19 + 64 || memcmp(blob, hdr, 19) != 0) return 0;
    memcpy(seed, blob + 19, 32);
    return 1;
}

static int unseal(const uint8_t *blob, size_t len, const uint8_t seed[32], uint8_t **plain, size_t *plain_len) {
    static const uint8_t magic[8] = {'X', 'F', 'T', 'M', 'G', 'M', 'T', '1'};
    if (len < 8 + 32 + 12 + 16 || memcmp(blob, magic, 8) != 0) return 0;
    const uint8_t *eph = blob + 8;
    const uint8_t *nonce = blob + 40;
    const uint8_t *boxed = blob + 52;
    size_t boxed_len = len - 52;
    if (boxed_len < 16) return 0;
    size_t ct_len = boxed_len - 16;
    const uint8_t *ct = boxed;
    const uint8_t *mac = boxed + ct_len;

    uint8_t dig[64];
    sha512(seed, 32, dig);
    uint8_t secret[32];
    crypto_eddsa_trim_scalar(secret, dig);
    uint8_t shared[32];
    crypto_x25519(shared, secret, eph);

    uint8_t *out = malloc(ct_len + 1);
    if (!out) return 0;
    crypto_aead_ctx ctx;
    crypto_aead_init_ietf(&ctx, shared, nonce);
    if (crypto_aead_read(&ctx, out, mac, magic, 8, ct, ct_len) != 0) {
        free(out);
        crypto_wipe(shared, sizeof shared);
        crypto_wipe(secret, sizeof secret);
        return 0;
    }
    crypto_wipe(shared, sizeof shared);
    crypto_wipe(secret, sizeof secret);
    *plain = out;
    *plain_len = ct_len;
    return 1;
}

int main(int argc, char **argv) {
    if (argc == 2 && strcmp(argv[1], "--self-test") == 0) {
        uint8_t out[64];
        sha512((const uint8_t *)"abc", 3, out);
        for (int i = 0; i < 64; i++) printf("%02x", out[i]);
        printf("\n");
        return 0;
    }
    if (argc != 3) {
        fprintf(stderr, "usage: unseal <dropbear-ed25519-host-key> <blob>\n");
        return 2;
    }
    uint8_t *key = 0, *blob = 0, *plain = 0;
    size_t key_len = 0, blob_len = 0, plain_len = 0;
    if (!read_file(argv[1], &key, &key_len) || !read_file(argv[2], &blob, &blob_len)) {
        fprintf(stderr, "unseal: cannot read input\n");
        return 1;
    }
    uint8_t seed[32];
    if (!dropbear_seed(key, key_len, seed)) {
        fprintf(stderr, "unseal: host key is not dropbear ed25519\n");
        free(key);
        free(blob);
        return 1;
    }
    if (!unseal(blob, blob_len, seed, &plain, &plain_len)) {
        fprintf(stderr, "unseal: host key does not open this file\n");
        crypto_wipe(seed, sizeof seed);
        free(key);
        free(blob);
        return 1;
    }
    crypto_wipe(seed, sizeof seed);
    if (fwrite(plain, 1, plain_len, stdout) != plain_len) return 1;
    crypto_wipe(plain, plain_len);
    free(plain);
    free(key);
    free(blob);
    return 0;
}
