#!/bin/sh
# Download router client.conf from the mgmt-hub HTTP API.
# Usage: fetch-client.sh [--url URL] [--token TOKEN] [--store-id ID] [--out FILE]
# shellcheck shell=sh
set -eu

STATE_DIR="${MGMT_HUB_STATE_DIR:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/mgmt-hub}"
HUB_ENV="$STATE_DIR/hub.env"
OUT="${MGMT_HUB_CONF_OUT:-$STATE_DIR/client.conf}"
URL="${MGMT_HUB_URL:-}"
TOKEN="${MGMT_HUB_TOKEN:-}"
STORE_ID="${MGMT_HUB_STORE_ID:-}"

die() {
  echo "[-] $*" >&2
  exit 1
}

load_hub_env() {
  [ -f "$HUB_ENV" ] || return 0
  # shellcheck disable=SC1090
  set -a
  . "$HUB_ENV"
  set +a
  [ -n "$URL" ] || URL="${MGMT_HUB_URL:-}"
  [ -n "$TOKEN" ] || TOKEN="${MGMT_HUB_TOKEN:-}"
  [ -n "$STORE_ID" ] || STORE_ID="${MGMT_HUB_STORE_ID:-}"
}

usage() {
  echo "Usage: $0 [--url URL] [--token TOKEN] [--store-id ID] [--out FILE]" >&2
}

http_get() {
  _url="$1"
  _out="$2"
  if command -v wget >/dev/null 2>&1; then
    wget -q -O "$_out" "$_url"
    return
  fi
  if command -v uclient-fetch >/dev/null 2>&1; then
    uclient-fetch -q -O "$_out" "$_url"
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -fsS -o "$_out" "$_url"
    return
  fi
  die "need wget, uclient-fetch or curl"
}

load_hub_env

while [ "$#" -gt 0 ]; do
  case "$1" in
    --url) URL="${2:-}"; shift 2 ;;
    --token) TOKEN="${2:-}"; shift 2 ;;
    --store-id) STORE_ID="${2:-}"; shift 2 ;;
    --out) OUT="${2:-}"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) die "unknown arg: $1" ;;
  esac
done

[ -n "$URL" ] || die "set MGMT_HUB_URL or --url (example: http://hub.example.org:8080)"
[ -n "$STORE_ID" ] || die "set MGMT_HUB_STORE_ID or --store-id"
URL="${URL%/}"
mkdir -p "$(dirname "$OUT")" "$STATE_DIR"

query=""
if [ -n "$TOKEN" ]; then
  query="?token=$TOKEN"
fi
tmp="$OUT.tmp"
http_get "$URL/api/routers/$STORE_ID/client.conf$query" "$tmp" || {
  rm -f "$tmp"
  die "download failed"
}

grep -q '\[Interface\]' "$tmp" || {
  rm -f "$tmp"
  die "response is not a WireGuard/AWG client.conf"
}
grep -q '0.0.0.0/0' "$tmp" && {
  rm -f "$tmp"
  die "refusing client.conf with 0.0.0.0/0"
}
grep -q '::/0' "$tmp" && {
  rm -f "$tmp"
  die "refusing client.conf with ::/0"
}

mv "$tmp" "$OUT"
chmod 600 "$OUT" 2>/dev/null || true
echo "[ok] saved $OUT"
