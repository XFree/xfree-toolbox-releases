#!/bin/sh
# Same ROUTER_ID as ci/probe-router-keys.sh: sha256("v1|board|model|mac")[:20].
# shellcheck shell=sh
set -eu

_mgmt_mac_digits() {
    printf '%s' "${1:-}" | tr 'A-Z' 'a-z' | tr -cd '0-9a-f'
}

_mgmt_first_mac() {
    for _iface in "$@"; do
        [ -n "$_iface" ] || continue
        if ip link show dev "$_iface" >/dev/null 2>&1; then
            cat "/sys/class/net/$_iface/address" 2>/dev/null && return 0
        fi
    done
    return 0
}

_mgmt_factory_mac() {
    if command -v ubus >/dev/null 2>&1 && command -v jsonfilter >/dev/null 2>&1; then
        ubus call system board 2>/dev/null | jsonfilter -e '@.macaddr' 2>/dev/null || true
        return 0
    fi
    if [ -f /etc/board.json ] && command -v jsonfilter >/dev/null 2>&1; then
        jsonfilter -i /etc/board.json -e '@.network.lan.macaddr' 2>/dev/null || true
    fi
}

mgmt_router_id() {
    _board="$(cat /tmp/sysinfo/board_name 2>/dev/null || true)"
    _model="$(cat /tmp/sysinfo/model 2>/dev/null || true)"
    [ -n "$_model" ] || _model="$_board"
    _factory="$(_mgmt_factory_mac)"
    _lan="$(uci -q get network.lan.macaddr 2>/dev/null || true)"
    [ -n "$_lan" ] || _lan="$(_mgmt_first_mac br-lan eth0)"
    _wan="$(uci -q get network.wan.macaddr 2>/dev/null || true)"
    [ -n "$_wan" ] || _wan="$(_mgmt_first_mac "$(uci -q get network.wan.device 2>/dev/null || true)" wan eth1)"
    _mac=""
    for _raw in "$_factory" "$_lan" "$_wan"; do
        _digits="$(_mgmt_mac_digits "$_raw")"
        if [ -n "$_digits" ]; then
            _mac="$_digits"
            break
        fi
    done
    _canonical="v1|${_board}|${_model}|${_mac}"
    if command -v sha256sum >/dev/null 2>&1; then
        _digest="$(printf '%s' "$_canonical" | sha256sum | awk '{print $1}')"
    else
        echo "[-] нет sha256sum, ROUTER_ID не посчитать" >&2
        return 1
    fi
    printf 'rtr-%s\n' "$(printf '%s' "$_digest" | cut -c1-20)"
}

case "${0##*/}" in
    router-id.sh) mgmt_router_id ;;
esac
