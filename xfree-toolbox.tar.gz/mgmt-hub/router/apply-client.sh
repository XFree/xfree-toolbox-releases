#!/bin/sh
# Apply / disable / show management AWG client on OpenWrt. Overlay only — never default-route.
# Usage:
#   apply-client.sh --conf /path/to/client.conf
#   apply-client.sh --enable
#   apply-client.sh --disable
#   apply-client.sh --status
# shellcheck shell=sh
set -eu

CONF=""
DO_ENABLE=0
DO_DISABLE=0
DO_STATUS=0
IFACE="${MGMT_HUB_IFACE:-xft_mgmt}"
ZONE="${MGMT_HUB_ZONE:-xft_mgmt}"
STATE_DIR="${MGMT_HUB_STATE_DIR:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/mgmt-hub}"
SAVED_CONF="$STATE_DIR/client.conf"
ROUTER_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

usage() {
  echo "Usage: $0 --conf <client.conf> | --enable | --disable | --status" >&2
}

die() {
  echo "[-] $*" >&2
  exit 1
}

parse_conf_value() {
  _file="$1"
  _key="$2"
  awk -v key="$_key" '
    $0 ~ /^\[Peer\]/ { in_sec=0 }
    $0 ~ /^\[Interface\]/ { in_sec=1; next }
    in_sec && index($0, key) == 1 && $0 ~ "^" key "[[:space:]]*=" {
      sub(/^[^=]+=[[:space:]]*/, "")
      print
      exit
    }
  ' "$_file"
}

parse_peer_value() {
  _file="$1"
  _key="$2"
  awk -v key="$_key" '
    $0 ~ /^\[Peer\]/ { in_sec=1; next }
    $0 ~ /^\[/ && $0 !~ /^\[Peer\]/ { in_sec=0 }
    in_sec && index($0, key) == 1 && $0 ~ "^" key "[[:space:]]*=" {
      sub(/^[^=]+=[[:space:]]*/, "")
      print
      exit
    }
  ' "$_file"
}

uci_get() {
  uci -q get "$1" 2>/dev/null || true
}

save_applied_conf() {
  mkdir -p "$STATE_DIR"
  if [ "$1" != "$SAVED_CONF" ]; then
    cp "$1" "$SAVED_CONF"
  fi
  chmod 600 "$SAVED_CONF" 2>/dev/null || true
}

# IPv4 literal only. Connected LAN route wins; otherwise /32 via wan.
pin_hub_endpoint() {
  _host="$1"
  uci -q delete network.mgmt_hub_endpoint || true
  case "$_host" in
    *[!.0-9]*|'') return 0 ;;
  esac
  _lan_dev="$(uci_get network.lan.device)"
  [ -n "$_lan_dev" ] || _lan_dev="$(uci_get network.lan.ifname)"
  [ -n "$_lan_dev" ] || _lan_dev="br-lan"
  if command -v ip >/dev/null 2>&1; then
    _route="$(ip -4 route get "$_host" 2>/dev/null || true)"
    case "$_route" in
      *" dev ${_lan_dev} "*) return 0 ;;
    esac
  fi
  uci set network.mgmt_hub_endpoint=route
  uci set network.mgmt_hub_endpoint.interface=wan
  uci set network.mgmt_hub_endpoint.target="$_host"
  uci set network.mgmt_hub_endpoint.netmask=255.255.255.255
}

apply_conf() {
  [ -n "$1" ] && [ -f "$1" ] || die "missing client.conf"
  grep -q '0.0.0.0/0' "$1" && die "client.conf contains 0.0.0.0/0 — refuse to apply"
  grep -q '::/0' "$1" && die "client.conf contains ::/0 — refuse to apply"
  command -v uci >/dev/null 2>&1 || die "uci not found (run on OpenWrt)"

  private_key="$(parse_conf_value "$1" "PrivateKey")"
  address="$(parse_conf_value "$1" "Address")"
  jc="$(parse_conf_value "$1" "Jc")"
  jmin="$(parse_conf_value "$1" "Jmin")"
  jmax="$(parse_conf_value "$1" "Jmax")"
  s1="$(parse_conf_value "$1" "S1")"
  s2="$(parse_conf_value "$1" "S2")"
  h1="$(parse_conf_value "$1" "H1")"
  h2="$(parse_conf_value "$1" "H2")"
  h3="$(parse_conf_value "$1" "H3")"
  h4="$(parse_conf_value "$1" "H4")"
  public_key="$(parse_peer_value "$1" "PublicKey")"
  allowed_ips="$(parse_peer_value "$1" "AllowedIPs")"
  endpoint="$(parse_peer_value "$1" "Endpoint")"
  keepalive="$(parse_peer_value "$1" "PersistentKeepalive")"
  keepalive="${keepalive:-25}"

  [ -n "$private_key" ] || die "PrivateKey missing"
  [ -n "$public_key" ] || die "Peer PublicKey missing"
  [ -n "$endpoint" ] || die "Endpoint missing"
  [ -n "$allowed_ips" ] || die "AllowedIPs missing"
  [ -n "$address" ] || die "Address missing"
  _leaky="$(
    printf '%s\n' "$allowed_ips" | tr ',' '\n' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | grep -v '^$' | grep -vE '^10\.77\.0\.[0-9]+(/[0-9]+)?$' || true
  )"
  [ -z "$_leaky" ] || die "AllowedIPs must stay in overlay 10.77.0.0/24, got $allowed_ips"

  endpoint_host="${endpoint%:*}"
  endpoint_port="${endpoint##*:}"
  addr_ip="${address%%/*}"

  # Previous toolbox builds used iface/zone name mgmt.
  if [ "$IFACE" != "mgmt" ]; then
    _legacy_proto="$(uci_get network.mgmt.proto)"
    if [ "$_legacy_proto" = "amneziawg" ]; then
      if command -v ifdown >/dev/null 2>&1; then
        ifdown mgmt 2>/dev/null || true
      fi
      uci -q delete network.mgmt || true
      _n=0
      while [ "$_n" -lt 16 ]; do
        uci -q delete "network.@amneziawg_mgmt[0]" >/dev/null 2>&1 || break
        _n=$((_n + 1))
      done
      uci -q delete firewall.mgmt || true
    fi
  fi

  uci -q delete "network.$IFACE" || true
  n=0
  while [ "$n" -lt 16 ]; do
    uci -q delete "network.@amneziawg_${IFACE}[0]" >/dev/null 2>&1 || break
    n=$((n + 1))
  done

  uci set "network.$IFACE=interface"
  uci set "network.$IFACE.proto=amneziawg"
  uci set "network.$IFACE.private_key=$private_key"
  uci set "network.$IFACE.defaultroute=0"
  uci add_list "network.$IFACE.addresses=$addr_ip"
  [ -n "$jc" ] && uci set "network.$IFACE.awg_jc=$jc"
  [ -n "$jmin" ] && uci set "network.$IFACE.awg_jmin=$jmin"
  [ -n "$jmax" ] && uci set "network.$IFACE.awg_jmax=$jmax"
  [ -n "$s1" ] && uci set "network.$IFACE.awg_s1=$s1"
  [ -n "$s2" ] && uci set "network.$IFACE.awg_s2=$s2"
  [ -n "$h1" ] && uci set "network.$IFACE.awg_h1=$h1"
  [ -n "$h2" ] && uci set "network.$IFACE.awg_h2=$h2"
  [ -n "$h3" ] && uci set "network.$IFACE.awg_h3=$h3"
  [ -n "$h4" ] && uci set "network.$IFACE.awg_h4=$h4"

  uci add network "amneziawg_$IFACE"
  uci set "network.@amneziawg_${IFACE}[-1].description=mgmt-hub"
  uci set "network.@amneziawg_${IFACE}[-1].public_key=$public_key"
  uci set "network.@amneziawg_${IFACE}[-1].endpoint_host=$endpoint_host"
  uci set "network.@amneziawg_${IFACE}[-1].endpoint_port=$endpoint_port"
  uci set "network.@amneziawg_${IFACE}[-1].persistent_keepalive=$keepalive"
  uci set "network.@amneziawg_${IFACE}[-1].route_allowed_ips=1"
  uci add_list "network.@amneziawg_${IFACE}[-1].allowed_ips=$allowed_ips"

  # Pin IPv4 hub via WAN so Proton/WARP cannot steal the handshake.
  # Skip when the host is already on LAN (lab: operator PC on br-lan).
  pin_hub_endpoint "$endpoint_host"

  uci -q delete "firewall.$ZONE" || true
  uci set "firewall.$ZONE=zone"
  uci set "firewall.$ZONE.name=$ZONE"
  uci set "firewall.$ZONE.network=$IFACE"
  uci set "firewall.$ZONE.input=ACCEPT"
  uci set "firewall.$ZONE.output=ACCEPT"
  uci set "firewall.$ZONE.forward=REJECT"
  uci set "firewall.$ZONE.masq=0"

  uci commit network
  uci commit firewall

  save_applied_conf "$1"

  if [ -x /etc/init.d/firewall ]; then
    /etc/init.d/firewall reload || true
  fi
  if [ -f "$ROUTER_DIR/connect.sh" ]; then
    sh "$ROUTER_DIR/connect.sh" --install-cron || true
  fi

  echo "[ok] mgmt hub client applied on $IFACE ($addr_ip -> $endpoint)"
  echo "Туннель сам не держится. Поднять сейчас:"
  echo "  sh $ROUTER_DIR/connect.sh"
}

disable_client() {
  command -v uci >/dev/null 2>&1 || die "uci not found (run on OpenWrt)"
  if command -v ifdown >/dev/null 2>&1; then
    ifdown "$IFACE" 2>/dev/null || true
  fi
  uci -q delete "network.$IFACE" || true
  n=0
  while [ "$n" -lt 16 ]; do
    uci -q delete "network.@amneziawg_${IFACE}[0]" >/dev/null 2>&1 || break
    n=$((n + 1))
  done
  uci -q delete network.mgmt_hub_endpoint || true
  uci -q delete "firewall.$ZONE" || true
  uci commit network
  uci commit firewall
  if [ -x /etc/init.d/firewall ]; then
    /etc/init.d/firewall reload || true
  fi
  if [ -f "$ROUTER_DIR/connect.sh" ]; then
    sh "$ROUTER_DIR/connect.sh" --remove-cron || true
  fi
  echo "[ok] mgmt hub client disabled ($IFACE)"
}

show_status() {
  echo "mgmt-hub (experimental)"
  echo "iface: $IFACE"
  echo "state_dir: $STATE_DIR"
  if [ -f "$SAVED_CONF" ]; then
    echo "saved_conf: $SAVED_CONF"
  else
    echo "saved_conf: (none)"
  fi
  if ! command -v uci >/dev/null 2>&1; then
    echo "uci: missing"
    return 0
  fi
  proto="$(uci_get "network.$IFACE.proto")"
  if [ -z "$proto" ]; then
    echo "status: disabled"
    return 0
  fi
  echo "status: enabled"
  echo "proto: $proto"
  echo "defaultroute: $(uci_get "network.$IFACE.defaultroute")"
  echo "addresses: $(uci_get "network.$IFACE.addresses")"
  echo "endpoint: $(uci_get "network.@amneziawg_${IFACE}[0].endpoint_host"):$(uci_get "network.@amneziawg_${IFACE}[0].endpoint_port")"
  echo "allowed_ips: $(uci_get "network.@amneziawg_${IFACE}[0].allowed_ips")"
  if ! command -v awg >/dev/null 2>&1; then
    echo "awg: missing — install AmneziaWG (xft → VPN-сервер → Установка AWG)"
  fi
  if command -v ifstatus >/dev/null 2>&1; then
    echo "--- ifstatus ---"
    ifstatus "$IFACE" 2>/dev/null || echo "(interface down)"
  fi
  if command -v awg >/dev/null 2>&1; then
    echo "--- awg ---"
    awg show "$IFACE" 2>/dev/null || true
  fi
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --conf)
      CONF="${2:-}"
      DO_ENABLE=1
      shift 2
      ;;
    --enable)
      DO_ENABLE=1
      shift
      ;;
    --disable)
      DO_DISABLE=1
      shift
      ;;
    --status)
      DO_STATUS=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "unknown arg: $1"
      ;;
  esac
done

if [ "$DO_STATUS" -eq 1 ]; then
  show_status
  exit 0
fi
if [ "$DO_DISABLE" -eq 1 ]; then
  disable_client
  exit 0
fi
if [ "$DO_ENABLE" -eq 1 ]; then
  [ -n "$CONF" ] || CONF="$SAVED_CONF"
  apply_conf "$CONF"
  exit 0
fi

usage
exit 1
