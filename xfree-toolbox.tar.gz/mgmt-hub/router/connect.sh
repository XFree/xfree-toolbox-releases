#!/bin/sh
# Bring the management overlay up from the router.
# The hub cannot dial us. This script ifups iface xft_mgmt, then ifdowns it
# unless this session is manual or the hub file says hold=1.
#
# One-liner on a router that already has the toolbox:
#   sh /root/xfree-toolbox/mgmt-hub/router/connect.sh
#
# Tear it down:
#   sh /root/xfree-toolbox/mgmt-hub/router/connect.sh --down
#
# shellcheck shell=sh
set -eu

IFACE="${MGMT_HUB_IFACE:-xft_mgmt}"
STATE_DIR="${MGMT_HUB_STATE_DIR:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/mgmt-hub}"
SCHEDULE="$STATE_DIR/schedule.env"
HUB_ENV="$STATE_DIR/hub.env"
HUB_IP="${MGMT_HUB_OVERLAY_IP:-10.77.0.1}"
DESIRED_PORT="${MGMT_HUB_DESIRED_PORT:-8079}"
MARKER="# xfree-mgmt-hub-session"

interval_s=14400
manual=0
last_session_at=0

self_path() {
  _resolved=""
  if command -v readlink >/dev/null 2>&1; then
    _resolved="$(readlink -f "$0" 2>/dev/null || true)"
  fi
  if [ -n "$_resolved" ]; then
    printf '%s' "$_resolved"
    return 0
  fi
  _dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
  printf '%s/%s' "$_dir" "$(basename -- "$0")"
}

SELF="$(self_path)"

usage() {
  cat <<EOF
Usage: sh $SELF [--up|--down|--session|--install-cron|--remove-cron]

Однострочник (toolbox уже на роутере):
  sh $SELF

Поднимает iface $IFACE и держит его, пока не будет --down.
Плановые окна (cron, раз в час, не чаще interval_s) гасят iface,
если на хабе hold=0 и сессия не ручная.
EOF
}

load_schedule() {
  interval_s=14400
  manual=0
  last_session_at=0
  [ -f "$SCHEDULE" ] || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      interval_s=*) interval_s=${line#interval_s=} ;;
      manual=*) manual=${line#manual=} ;;
      last_session_at=*) last_session_at=${line#last_session_at=} ;;
    esac
  done <"$SCHEDULE"
  case "$interval_s" in
    ''|*[!0-9]*) interval_s=14400 ;;
  esac
  case "$manual" in
    1) manual=1 ;;
    *) manual=0 ;;
  esac
  case "$last_session_at" in
    ''|*[!0-9]*) last_session_at=0 ;;
  esac
}

write_schedule() {
  mkdir -p "$STATE_DIR"
  tmp="$SCHEDULE.tmp"
  {
    echo "interval_s=$interval_s"
    echo "manual=$manual"
    echo "last_session_at=$last_session_at"
  } >"$tmp"
  mv "$tmp" "$SCHEDULE"
}

store_id() {
  _id=""
  [ -f "$HUB_ENV" ] || {
    printf '%s' ""
    return 0
  }
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      MGMT_HUB_STORE_ID=*)
        _id=${line#MGMT_HUB_STORE_ID=}
        _id=${_id#\'}
        _id=${_id%\'}
        _id=${_id#\"}
        _id=${_id%\"}
        ;;
    esac
  done <"$HUB_ENV"
  printf '%s' "$_id"
}

fetch_desired() {
  _url="http://${HUB_IP}:${DESIRED_PORT}/$1"
  if [ -n "${MGMT_HUB_DESIRED_URL:-}" ]; then
    _url="$MGMT_HUB_DESIRED_URL"
  fi
  if command -v wget >/dev/null 2>&1; then
    wget -q -T 5 -O - "$_url" 2>/dev/null && return 0
  fi
  if command -v uclient-fetch >/dev/null 2>&1; then
    uclient-fetch -q -T 5 -O - "$_url" 2>/dev/null && return 0
  fi
  return 1
}

field_value() {
  _body="$1"
  _key="$2"
  printf '%s\n' "$_body" | sed -n "s/^${_key}=//p" | head -n 1
}

rewrite_crontab() {
  _mode="$1"
  command -v crontab >/dev/null 2>&1 || {
    echo "[!] crontab нет, расписание не записано"
    return 0
  }
  _tmp="$(mktemp)"
  {
    crontab -l 2>/dev/null || true
  } | grep -vF "$MARKER" | grep -vF "$SELF --session" >"$_tmp" || true
  {
    cat "$_tmp"
    if [ "$_mode" = "install" ]; then
      echo "$MARKER"
      echo "0 * * * * /bin/sh $SELF --session"
    fi
  } | crontab -
  rm -f "$_tmp"
  if [ "$_mode" = "install" ]; then
    echo "[ok] cron: раз в час sh $SELF --session (окно не чаще ${interval_s}s)"
  else
    echo "[ok] cron сессии снят"
  fi
}

iface_up() {
  if command -v ifup >/dev/null 2>&1; then
    ifup "$IFACE" || true
  else
    echo "[!] ifup нет, iface $IFACE не поднят"
  fi
}

iface_down() {
  if command -v ifdown >/dev/null 2>&1; then
    ifdown "$IFACE" 2>/dev/null || true
  fi
}

cmd_up() {
  load_schedule
  manual=1
  write_schedule
  rewrite_crontab install
  iface_up
  echo "[ok] соединение $IFACE поднято (manual=1), пока не будет --down"
  echo "Однострочник:"
  echo "  sh $SELF"
  echo "Разорвать:"
  echo "  sh $SELF --down"
}

cmd_down() {
  load_schedule
  manual=0
  write_schedule
  iface_down
  echo "[ok] $IFACE погашен"
  echo "Если на хабе включено удержание, следующее окно cron снова поднимет $IFACE."
  echo "Снять удержание — галочка на карточке в дашборде хаба."
}

session_due() {
  if [ "$interval_s" -eq 0 ] || [ "$last_session_at" -eq 0 ]; then
    return 0
  fi
  _now="$(date +%s 2>/dev/null || echo 0)"
  case "$_now" in
    ''|*[!0-9]*) return 0 ;;
  esac
  _elapsed=$((_now - last_session_at))
  [ "$_elapsed" -ge "$interval_s" ]
}

cmd_session() {
  load_schedule
  if [ "$manual" = "1" ]; then
    echo "[ok] manual=1, плановое окно не гасит $IFACE"
    exit 0
  fi
  if ! session_due; then
    echo "[ok] рано для окна (interval_s=$interval_s)"
    exit 0
  fi
  _now="$(date +%s 2>/dev/null || echo 0)"
  case "$_now" in
    ''|*[!0-9]*) _now=0 ;;
  esac
  last_session_at="$_now"
  write_schedule
  iface_up

  _id="$(store_id)"
  _tries="${MGMT_CONNECT_WAIT_TRIES:-18}"
  _pause="${MGMT_CONNECT_WAIT_SLEEP:-5}"
  case "$_tries" in
    ''|*[!0-9]*) _tries=18 ;;
  esac
  case "$_pause" in
    ''|*[!0-9]*) _pause=5 ;;
  esac
  _n=0
  _body=""
  _hold=0
  while [ "$_n" -lt "$_tries" ]; do
    if [ -n "$_id" ]; then
      _body="$(fetch_desired "$_id" || true)"
      _next="$(field_value "$_body" probe_interval_s)"
      case "$_next" in
        ''|*[!0-9]*) ;;
        *)
          if [ "$_next" != "$interval_s" ]; then
            interval_s="$_next"
            write_schedule
          fi
          ;;
      esac
      _hold_raw="$(field_value "$_body" hold)"
      if [ "$_hold_raw" = "1" ]; then
        _hold=1
        break
      fi
    fi
    _n=$((_n + 1))
    if [ "$_n" -lt "$_tries" ] && [ "$_pause" != "0" ]; then
      sleep "$_pause"
    fi
  done

  if [ "$_hold" = "1" ]; then
    echo "[ok] хаб hold=1, $IFACE остаётся"
    exit 0
  fi
  iface_down
  echo "[ok] окно пробы закрыто, $IFACE погашен"
}

mode="${1:---up}"
case "$mode" in
  --up|"")
    cmd_up
    ;;
  --down)
    cmd_down
    ;;
  --session)
    cmd_session
    ;;
  --install-cron)
    load_schedule
    rewrite_crontab install
    ;;
  --remove-cron)
    rewrite_crontab remove
    ;;
  -h|--help)
    usage
    ;;
  *)
    usage >&2
    exit 1
    ;;
esac
