#!/bin/sh
# Connect this router to the management hub.
# If xft_mgmt is already applied, only bring the tunnel up.
# Otherwise download this router's sealed client.conf (public file, opens
# only with this machine's Dropbear host key), apply it, then connect.
# shellcheck shell=sh
set -eu

DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
IFACE="${MGMT_HUB_IFACE:-xft_mgmt}"
STATE_DIR="${MGMT_HUB_STATE_DIR:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/mgmt-hub}"
SEAL_BASE="${MGMT_SEAL_BASE:-https://xfree-cloud.duckdns.org/public.php/dav/files/L982AaEEYAHYtTj/mgmt}"
HOST_KEY="${MGMT_HOST_KEY:-/etc/dropbear/dropbear_ed25519_host_key}"

die() {
    echo "[-] $*" >&2
    exit 1
}

http_get() {
    _url="$1"
    _out="$2"
    if command -v wget >/dev/null 2>&1; then
        wget -q -O "$_out" "$_url"
        return
    fi
    if command -v uclient-fetch >/dev/null 2>&1; then
        uclient-fetch -q -O "$_out" "$_url"
        return
    fi
    die "нужен wget или uclient-fetch"
}

unseal_bin() {
    _arch="$(uname -m 2>/dev/null || true)"
    case "$_arch" in
        aarch64|arm64) printf '%s\n' "$DIR/unseal.aarch64" ;;
        *) die "нет unseal для архитектуры ${_arch:-unknown}" ;;
    esac
}

iface_ready() {
    _proto="$(uci -q get "network.$IFACE.proto" 2>/dev/null || true)"
    [ "$_proto" = "amneziawg" ]
}

connect_now() {
    echo "[*] поднимаю $IFACE"
    sh "$DIR/connect.sh"
    echo "[*] хаб снимет пробу после handshake, если она устарела"
}

if iface_ready; then
    echo "[*] ключ уже применён"
    connect_now
    exit 0
fi

# shellcheck disable=SC1091
. "$DIR/router-id.sh"
router_id="$(mgmt_router_id)"
[ -n "$router_id" ] || die "не удалось вычислить ROUTER_ID"
echo "[*] ключа нет, забираю свой файл $router_id"

umask 077
blob="$STATE_DIR/client.sealed"
conf="$STATE_DIR/client.conf.partial"
mkdir -p "$STATE_DIR"
rm -f "$blob" "$conf"
http_get "${SEAL_BASE%/}/$router_id.bin" "$blob" || die "не скачался $router_id.bin"
[ -s "$blob" ] || die "пустой файл $router_id.bin"

bin="$(unseal_bin)"
[ -x "$bin" ] || die "нет $bin"
"$bin" "$HOST_KEY" "$blob" >"$conf" || die "host key не открывает файл (роутер не пробовали или ключ хоста сменился)"
grep -q 'PrivateKey' "$conf" || die "в файле нет PrivateKey"
rm -f "$blob"
sh "$DIR/apply-client.sh" --conf "$conf"
rm -f "$conf"
connect_now
