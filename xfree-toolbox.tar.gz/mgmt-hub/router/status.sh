#!/bin/sh
# LuCI report + CLI: mgmt-hub overlay status.
# shellcheck shell=sh
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
exec sh "$SCRIPT_DIR/apply-client.sh" --status
