#!/bin/sh
# Save hub URL / token / store-id for fetch-client.sh (experimental).
# Usage: configure.sh [--url URL] [--token TOKEN] [--store-id ID]
# shellcheck shell=sh
set -eu

STATE_DIR="${MGMT_HUB_STATE_DIR:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/mgmt-hub}"
HUB_ENV="$STATE_DIR/hub.env"
URL=""
TOKEN=""
STORE_ID=""
SET_URL=0
SET_TOKEN=0
SET_STORE=0

die() {
  echo "[-] $*" >&2
  exit 1
}

usage() {
  echo "Usage: $0 [--url URL] [--token TOKEN] [--store-id ID]" >&2
}

load_existing() {
  [ -f "$HUB_ENV" ] || return 0
  # shellcheck disable=SC1090
  set -a
  . "$HUB_ENV"
  set +a
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --url) URL="${2:-}"; SET_URL=1; shift 2 ;;
    --token) TOKEN="${2:-}"; SET_TOKEN=1; shift 2 ;;
    --store-id) STORE_ID="${2:-}"; SET_STORE=1; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) die "unknown arg: $1" ;;
  esac
done

load_existing
[ "$SET_URL" -eq 1 ] || URL="${MGMT_HUB_URL:-$URL}"
[ "$SET_TOKEN" -eq 1 ] || TOKEN="${MGMT_HUB_TOKEN:-$TOKEN}"
[ "$SET_STORE" -eq 1 ] || STORE_ID="${MGMT_HUB_STORE_ID:-$STORE_ID}"

mkdir -p "$STATE_DIR"
umask 077
cat >"$HUB_ENV" <<EOF
MGMT_HUB_URL='$URL'
MGMT_HUB_TOKEN='$TOKEN'
MGMT_HUB_STORE_ID='$STORE_ID'
EOF
chmod 600 "$HUB_ENV"
echo "[ok] wrote $HUB_ENV"
echo "url: ${URL:-<empty>}"
echo "store_id: ${STORE_ID:-<empty>}"
if [ -n "$TOKEN" ]; then
  echo "token: set"
else
  echo "token: <empty>"
fi
