#!/usr/bin/env python3
from pathlib import Path

p = Path("dist/xfree-toolbox-0.1.6-r15.apk")
data = p.read_bytes()
print("magic", data[:16])
print("size", len(data))
print("dns.google count", data.count(b"dns.google"))
print("user__group__xft count", data.count(b"user__group__xft"))
print("cloudflare-dns-no-doh count", data.count(b"cloudflare-dns-no-doh"))
pos = 0
n = 0
while n < 12:
    i = data.find(b"user__group__xft", pos)
    if i < 0:
        break
    ctx = data[max(0, i - 100) : i + 50]
    print("---", n, "---")
    print(ctx)
    pos = i + 1
    n += 1

# tar VERSION in tar.gz for comparison
import tarfile

with tarfile.open("dist/xfree-toolbox.tar.gz", "r:gz") as tf:
    ver = tf.extractfile("./VERSION") or tf.extractfile("VERSION")
    print("tar VERSION", ver.read().decode().strip() if ver else None)
    xft = [n for n in tf.getnames() if "user__group__xft" in n]
    print("tar xft paths:")
    for n in xft:
        print(" ", n)
