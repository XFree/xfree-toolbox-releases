#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
# regenerate only (no restart yet) and show hostlist counts
export XFREE_APPLY_PROFILE_DIR=/root/xfree-toolbox/profiles/default
/root/xfree-toolbox/zapret/apply.sh --yes --generate-only 2>&1 | tee /tmp/zapret-regen.log | grep -E 'Секция|hostlist|error|ERROR|FAIL|готово|generate' | head -60
echo '=== after generate: profile ipset google ==='
wc -l /root/xfree-toolbox/profiles/default/zapret/ipset/zapret-hosts-google.txt \
  /root/xfree-toolbox/profiles/default/zapret/ipset/xfree-discord-hosts.txt \
  /root/xfree-toolbox/profiles/default/zapret/ipset/xfree-cdn-host-hosts.txt \
  /root/xfree-toolbox/profiles/default/zapret/ipset/zapret-hosts-user.txt 2>&1
echo '=== state youtube_29 ==='
ls /etc/xfree-toolbox/zapret/state/sections/youtube_29/fqdn.d/ 2>&1
ls /etc/xfree-toolbox/zapret/state/sections/youtube_29/config/ 2>&1
echo '=== NFQWS hostlist lines in profile zapret ==='
grep -c 'hostlist=' /root/xfree-toolbox/profiles/default/zapret/zapret || true
grep -E 'hostlist=' /root/xfree-toolbox/profiles/default/zapret/zapret | head -20
REMOTE
