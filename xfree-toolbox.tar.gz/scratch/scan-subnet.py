import socket
from concurrent.futures import ThreadPoolExecutor

def check_ip(ip):
    for port in [80, 22, 443]:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.3)
        try:
            s.connect((ip, port))
            s.close()
            return (ip, port)
        except Exception:
            s.close()
    return None

ips = [f"10.205.201.{i}" for i in range(1, 255)]
with ThreadPoolExecutor(max_workers=50) as ex:
    results = ex.map(check_ip, ips)

found = [r for r in results if r]
print("Found responsive hosts:", found)
