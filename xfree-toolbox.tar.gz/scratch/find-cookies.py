import sqlite3
import os
import glob
import shutil

cookie_paths = glob.glob(os.path.expanduser('~') + r'\AppData\Local\Google\Chrome\User Data\*\Network\Cookies') + glob.glob(os.path.expanduser('~') + r'\AppData\Local\Microsoft\Edge\User Data\*\Network\Cookies')

for cp in cookie_paths:
    try:
        tmp = os.path.expanduser('~') + r'\AppData\Local\Temp\ck_tmp.db'
        shutil.copy2(cp, tmp)
        conn = sqlite3.connect(tmp)
        c = conn.cursor()
        c.execute("SELECT host_key, name, path FROM cookies WHERE host_key LIKE '%10.200%' OR host_key LIKE '%192.168%'")
        rows = c.fetchall()
        if rows:
            print(cp)
            for r in rows:
                print(" ", r)
        conn.close()
    except Exception as e:
        pass
