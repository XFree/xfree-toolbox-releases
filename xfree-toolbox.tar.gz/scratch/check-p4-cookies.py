import sqlite3
import os
import shutil

cp = os.path.expanduser('~') + r'\AppData\Local\Google\Chrome\User Data\Profile 4\Network\Cookies'
tmp = os.path.expanduser('~') + r'\AppData\Local\Temp\p4_ck.db'
shutil.copy2(cp, tmp)
conn = sqlite3.connect(tmp)
c = conn.cursor()
c.execute("SELECT host_key, name, length(encrypted_value) FROM cookies WHERE host_key LIKE '%10.200%'")
for row in c.fetchall():
    print(row)
conn.close()
