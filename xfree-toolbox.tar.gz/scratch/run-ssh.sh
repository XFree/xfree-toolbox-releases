#!/usr/bin/env bash
set -e
PROJECT_ROOT="/mnt/d/tools/routers/openwrt/xfree-utils"
source "$PROJECT_ROOT/ci/ssh-toolbox/router-key-env.sh"
source "$PROJECT_ROOT/ci/ssh-toolbox/router-keys-lib.sh"
source "$PROJECT_ROOT/ci/lib/router-key-select.sh"
source "$PROJECT_ROOT/ci/lib/router-ssh-session.sh"

router_ssh_session_parse_common_option_value "--key" "bluehome"
ROUTER_KEY_EXPLICIT=1
router_ssh_session_bootstrap "$PROJECT_ROOT"

ssh "${SSH_OPTS[@]}" "$SSH_TARGET" "$@"
