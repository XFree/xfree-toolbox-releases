import glob
import os
import sqlite3
import shutil

for hp in glob.glob(os.path.expanduser('~') + r'\AppData\Local\**\History', recursive=True):
    try:
        tmp = os.path.expanduser('~') + r'\AppData\Local\Temp\h_any.db'
        shutil.copy2(hp, tmp)
        conn = sqlite3.connect(tmp)
        c = conn.cursor()
        c.execute("SELECT url, title, last_visit_time FROM urls WHERE url LIKE '%192.168%' OR url LIKE '%10.200%' OR url LIKE '%xfree%' OR url LIKE '%luci%' ORDER BY last_visit_time DESC LIMIT 5")
        rows = c.fetchall()
        if rows:
            print(hp)
            for r in rows:
                print(" ", r)
        conn.close()
    except Exception:
        pass
