#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils

patch_file() {
	f="$1"
	[ -f "$f" ] || return 0
	perl -i -pe '
		s/default-with-proton-ai/warp-proton/g;
		s/default-with-proton/warp-proton/g;
		s#profile-templates/default/#profile-templates/warp/#g;
		s#profile-templates/default\b#profile-templates/warp#g;
	' "$f"
	echo "patched $f"
}

# Tests / agents / docs that pin template directory names
for f in \
	templates/tests/test-zapret-lists-on-xbox-dns.sh \
	templates/tests/test-apply-template-step-order.sh \
	templates/tests/test-update-and-apply-pipeline.sh \
	iface-routing/vpn/tests/test-warp-meta-policy.sh \
	iface-routing/tests/test-probe-geoblock.sh \
	zapret/tests/test-zapret2.sh \
	diagnostics/tests/test-dns-check.sh \
	upstreams/tests/test-orphan-purge.sh \
	upstreams/tests/test-apply-drift-keys.sh \
	https-dns-proxy/tests/test-doh-upstreams.sh \
	https-dns-proxy/test-doh-upstreams.sh \
	system/tests/test-install-templates-replace.sh \
	agents/dev/dns-routing/AGENT.md \
	docs/wiki/Home.md \
	awg-ingress/README.md \
	profile-generator/README.md \
	profile-generator/lib/store-router-setup.sh \
	ci/state-export-to-template.sh
do
	patch_file "$f"
done

# Fix loops that still list three names after naive replace (warp-proton twice)
# and check_template calls.
perl -i -pe '
	s/for tmpl in warp warp-proton warp-proton;/for tmpl in warp warp-proton;/g;
	s/for tpl in warp warp-proton warp-proton;/for tpl in warp warp-proton;/g;
	s/check_template warp-proton\ncheck_template warp-proton/check_template warp-proton/g;
' templates/tests/test-zapret-lists-on-xbox-dns.sh \
	iface-routing/vpn/tests/test-warp-meta-policy.sh \
	iface-routing/tests/test-probe-geoblock.sh 2>/dev/null || true

# test-update-and-apply-pipeline: live resolve of alias default -> warp,
# and default-with-proton alias -> warp-proton when dir gone.
# After naive replace, "live dir wins" may say warp-proton for warp-proton name — fix end assertion.
if grep -q "common_profile_template_resolve_id \"\$ROOT_DIR\" warp-proton" templates/tests/test-update-and-apply-pipeline.sh; then
	perl -i -pe '
		s/_id="\$\(common_profile_template_resolve_id "\$ROOT_DIR" warp-proton\)"/_id="\$(common_profile_template_resolve_id "\$ROOT_DIR" default-with-proton)"/;
		s/\[ "\$_id" = "warp-proton" \] && pass '\''alias: live dir wins over cross-alias'\''/[ "\$_id" = "warp-proton" ] && pass '\''alias: old name resolves to warp-proton'\''/;
	' templates/tests/test-update-and-apply-pipeline.sh
fi

# Add explicit alias resolution smoke if missing
if ! grep -q "resolve_id.*default\"" templates/tests/test-update-and-apply-pipeline.sh; then
	cat >> templates/tests/test-update-and-apply-pipeline.sh <<'EOF'

_id="$(common_profile_template_resolve_id "$ROOT_DIR" default)"
[ "$_id" = "warp" ] && pass 'alias: default resolves to warp' \
	|| fail "alias default: got ${_id:-}"
_id="$(common_profile_template_resolve_id "$ROOT_DIR" default-with-proton)"
[ "$_id" = "warp-proton" ] && pass 'alias: default-with-proton resolves to warp-proton' \
	|| fail "alias default-with-proton: got ${_id:-}"
_id="$(common_profile_template_resolve_id "$ROOT_DIR" default-with-proton-ai)"
[ "$_id" = "warp-proton" ] && pass 'alias: default-with-proton-ai resolves to warp-proton' \
	|| fail "alias default-with-proton-ai: got ${_id:-}"
EOF
fi

# store-router-setup default toolbox template
perl -i -pe 's/XFREE_TOOLBOX_TEMPLATE:-default/XFREE_TOOLBOX_TEMPLATE:-warp/g; s/toolbox_template:-default/toolbox_template:-warp/g' \
	profile-generator/lib/store-router-setup.sh

# state-export --as-default help text
perl -i -pe 's/--template default/--template warp/g; s/as-default/as-warp/g if 0' ci/state-export-to-template.sh || true

echo DONE
