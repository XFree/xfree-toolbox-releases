#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils

python3 - <<'PY'
from pathlib import Path

# zapret lists test
p = Path('templates/tests/test-zapret-lists-on-xbox-dns.sh')
t = p.read_text(encoding='utf-8')
t = t.replace('check_template default\ncheck_template warp-proton\ncheck_template warp-proton',
              'check_template warp\ncheck_template warp-proton')
t = t.replace('for tmpl in default warp-proton warp-proton;', 'for tmpl in warp warp-proton;')
t = t.replace('for tmpl in warp-proton warp-proton;', 'for tmpl in warp-proton;')
t = t.replace('for tmpl in default;', 'for tmpl in warp;')
# path leftovers
t = t.replace('profile-templates/default/', 'profile-templates/warp/')
p.write_text(t, encoding='utf-8', newline='\n')
print('fixed', p)

for rel in (
    'iface-routing/tests/test-probe-geoblock.sh',
    'iface-routing/vpn/tests/test-warp-meta-policy.sh',
):
    p = Path(rel)
    t = p.read_text(encoding='utf-8')
    t = t.replace('for tpl in default warp-proton warp-proton;', 'for tpl in warp warp-proton;')
    t = t.replace('for tpl in warp warp-proton warp-proton;', 'for tpl in warp warp-proton;')
    t = t.replace('for tpl in warp-proton warp-proton;', 'for tpl in warp-proton;')
    t = t.replace('template default warp', 'template warp')
    t = t.replace('profile-templates/default/', 'profile-templates/warp/')
    p.write_text(t, encoding='utf-8', newline='\n')
    print('fixed', p)

p = Path('templates/tests/test-update-and-apply-pipeline.sh')
t = p.read_text(encoding='utf-8')
# remove duplicate first resolve block if both exist
old = '''_id="$(common_profile_template_resolve_id "$ROOT_DIR" default-with-proton)"
[ "$_id" = "warp-proton" ] && pass 'alias: old name resolves to warp-proton' \\
	|| fail "alias live: got ${_id:-}"

'''
if t.count('common_profile_template_resolve_id "$ROOT_DIR" default-with-proton"') >= 2 and old in t:
    t = t.replace(old, '', 1)
    p.write_text(t, encoding='utf-8', newline='\n')
    print('deduped pipeline alias asserts')
else:
    print('pipeline alias asserts left as-is; count=',
          t.count('common_profile_template_resolve_id "$ROOT_DIR" default-with-proton"'))

p = Path('docs/wiki/Home.md')
t = p.read_text(encoding='utf-8')
t = t.replace(
    'Шаблоны: `default` (Warp), `warp-proton` (Warp+Proton), `warp-proton` (все AI через Proton)',
    'Шаблоны: `warp` (алиас `default`), `warp-proton` (алиасы `default-with-proton` / `default-with-proton-ai`)',
)
p.write_text(t, encoding='utf-8', newline='\n')
print('fixed', p)

p = Path('agents/dev/dns-routing/AGENT.md')
t = p.read_text(encoding='utf-8')
t = t.replace(
    'xbox rewrite set only on `default`; `warp-proton` and `warp-proton` leave xbox-dns empty',
    'xbox rewrite set only on `warp`; `warp-proton` leaves xbox-dns empty',
)
p.write_text(t, encoding='utf-8', newline='\n')
print('fixed', p)

p = Path('profile-generator/README.md')
t = p.read_text(encoding='utf-8')
t = t.replace('писалось и в `default`, и в `warp-proton`',
              'писалось и в `warp`, и в `warp-proton`')
p.write_text(t, encoding='utf-8', newline='\n')
print('fixed', p)
PY

# state-export: ensure --as-default maps to warp
if grep -n "as-default\|TEMPLATE_NAME=default\|template default" ci/state-export-to-template.sh | head -20; then
	:
fi
