#!/bin/sh
# shellcheck shell=sh
# Текстовый статус мониторинга uplink (без whiptail).
# Usage: status.sh [--out FILE]
# Как system/modem/diagnostics.sh — вызывается из menu.handlers в подпроцессе.

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
HARDWARE_DIR="$ROOT_DIR/system/hardware"

OUT_FILE=""
while [ $# -gt 0 ]; do
    case "$1" in
        --out)
            shift
            OUT_FILE="${1:-}"
            [ -n "$OUT_FILE" ] || {
                echo "status.sh: --out requires a path" >&2
                exit 1
            }
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--out FILE]"
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            exit 1
            ;;
    esac
done

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
export USB_WATCH_ROOT_DIR="$ROOT_DIR"
export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
# shellcheck disable=SC1091
. "$HARDWARE_DIR/usb-power-watch-lib.sh"

USB_POWER_SH="$HARDWARE_DIR/usb-power.sh"

_emit() {
    if [ -n "$OUT_FILE" ]; then
        printf '%s\n' "$*" >>"$OUT_FILE"
    else
        printf '%s\n' "$*"
    fi
}

_emit_block() {
    if [ -n "$OUT_FILE" ]; then
        cat >>"$OUT_FILE"
    else
        cat
    fi
}

[ -n "$OUT_FILE" ] && : >"$OUT_FILE"

set +e
usb_watch_maybe_reset_after_reboot || true
usb_watch_menu_ensure_vars 2>/dev/null || true

{
    usb_watch_format_status 2>&1
    printf '\n=== Последний probe (state) ===\n'
    printf '  eval (0=full 1=fail 2=partial): %s\n' "$(usb_watch_state_get LAST_PROBE_EVAL '?')"
    printf '  base OK: %s  alt OK: %s\n' \
        "$(usb_watch_state_get LAST_PROBE_BASE '?')" \
        "$(usb_watch_state_get LAST_PROBE_ALT '?')"
    printf '  CONNECTIVITY_DEGRADED: %s\n' "$(usb_watch_state_get CONNECTIVITY_DEGRADED 0)"
    printf '\n=== USB power ===\n'
    case "${USB_WATCH_POWER_CYCLE:-auto}" in
        off|0|n|no|false)
            printf 'POWER_CYCLE=off — перечень бэкендов пропущен.\n'
            ;;
        *)
            if [ -f "$USB_POWER_SH" ]; then
                sh "$USB_POWER_SH" status 2>&1
            else
                printf 'usb-power.sh не найден: %s\n' "$USB_POWER_SH"
            fi
            ;;
    esac
} | _emit_block

exit 0
