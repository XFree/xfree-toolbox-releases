#!/bin/sh
# shellcheck shell=sh
# Вычисление статуса хоста DNS-пробы для uplink-monitor/luci-rpc.sh.

uplink_dns_fail_hosts_from_summary() {
	_summary="$1"
	case "$_summary" in
	*FAIL:*)
		printf '%s' "$_summary" | sed -n 's/.*(FAIL:[[:space:]]*//;s/)[[:space:]]*$//;p' | tr ',' ' '
		;;
	esac
}

uplink_dns_host_status() {
	_dns_last="$1"
	_dns_summary="$2"
	_h="$3"
	_dns_fail_hosts="$(uplink_dns_fail_hosts_from_summary "$_dns_summary")"
	_h_status="unknown"
	if [ "$_dns_last" = "1" ]; then
		_h_status="ok"
	elif [ "$_dns_last" = "0" ]; then
		_h_status="ok"
		for _fh in $_dns_fail_hosts; do
			if [ "$_fh" = "$_h" ]; then
				_h_status="fail"
				break
			fi
		done
		# Summary пустой/битый при LAST_DNS_PROBE=0 — не маскируем FAIL зелёными карточками.
		if [ -z "$_dns_fail_hosts" ]; then
			_h_status="fail"
		fi
	fi
	printf '%s' "$_h_status"
}
