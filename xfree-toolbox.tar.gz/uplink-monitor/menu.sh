#!/bin/sh
# shellcheck shell=sh
# Entry: delegates to menu.gen.sh (edit uplink-monitor/menu.yaml, run tools/menu-compose-build.sh --with-cli)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1090
. "$ROOT_DIR/lib/ui.sh"

ui_have_whiptail || {
	echo "[!] whiptail не установлен" >&2
	exit 1
}

# `sh` so WSL /mnt/d does not depend on +x or a shebang (CRLF shebang → exec: not found).
exec sh "$SCRIPT_DIR/menu.gen.sh" "${1:-ui}"
