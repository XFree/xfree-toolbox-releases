#!/bin/sh
# Hand-written handlers for uplink-monitor/menu.yaml.
# shellcheck shell=sh

export USB_WATCH_ROOT_DIR="${ROOT_DIR:-$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)}"
export XFREE_TOOLBOX_ROOT="${XFREE_TOOLBOX_ROOT:-$USB_WATCH_ROOT_DIR}"

UPLINK_MONITOR_LIB=1
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib-ui.sh"
# Tunnel check-routing cron lives in diagnostics/; handlers are shared.
# shellcheck disable=SC1091
. "$ROOT_DIR/diagnostics/menu.handlers.sh"

run_uplink_log() { ui_menu_invoke_with_output "$@"; }

_uplink_handler_run() {
	ui_prepare_tty 2>/dev/null || true
	"$@" || true
	ui_prepare_tty 2>/dev/null || true
}

uplink_monitor_choice_1() { _uplink_handler_run show_status_box; }
uplink_monitor_choice_2() { _uplink_handler_run settings_menu; }
uplink_monitor_choice_3() { _uplink_handler_run probe_once; }
uplink_monitor_choice_4() { _uplink_handler_run cycle_now_confirm; }
uplink_monitor_choice_5() { _uplink_handler_run test_detailed_confirm; }
uplink_monitor_choice_6() { _uplink_handler_run install_cron_confirm; }
uplink_monitor_choice_7() { _uplink_handler_run remove_cron_confirm; }
