#!/bin/sh
# shellcheck shell=sh
# Non-interactive uplink / tunnel menu actions for LuCI (ubus xfree-toolbox uplinkMenu).
# Prints plain text to stdout; exit code = result. Usage: luci-rpc.sh <action> [arg]
# No -u: jshn.sh (getConfig/saveConfig) references unset JSON_PREFIX.
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"

export USB_WATCH_ROOT_DIR="$ROOT_DIR"
export XFREE_TOOLBOX_ROOT="$ROOT_DIR"

HARDWARE_DIR="$ROOT_DIR/system/hardware"
# shellcheck disable=SC1091
. "$HARDWARE_DIR/usb-power-watch-lib.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/led/led-lib.sh"
# shellcheck disable=SC1091
. "$HARDWARE_DIR/internet-status-led-lib.sh"
# shellcheck disable=SC1091
. "$HARDWARE_DIR/lib-board.sh"

USB_WATCH_CRON="$HARDWARE_DIR/usb-power-watch-cron.sh"
USB_WATCH_LED_CYCLE="$HARDWARE_DIR/usb-power-watch-led-cycle.sh"
USB_POWER_SH="$HARDWARE_DIR/usb-power.sh"
STATUS_SH="$SCRIPT_DIR/status.sh"
TUNNELS_STATUS_SH="$ROOT_DIR/diagnostics/tunnels-status.sh"
CHECK_SH="$ROOT_DIR/iface-routing/check-routing.sh"
RUN_SH="$ROOT_DIR/diagnostics/routing-monitor-run.sh"
INSTALL_SH="$ROOT_DIR/diagnostics/routing-monitor-install.sh"
REMOVE_SH="$ROOT_DIR/diagnostics/routing-monitor-remove.sh"
LED_TEST_SH="$HARDWARE_DIR/led-test.sh"
MGMT_ENSURE_SH="$ROOT_DIR/mgmt-hub/router/ensure-client.sh"
DNS_CHECK_SH="$ROOT_DIR/diagnostics/dns-check.sh"

run_sh() {
	local script="$1"
	shift

	[ -f "$script" ] || die "missing: $script"
	[ -x "$script" ] || chmod +x "$script" 2>/dev/null || true
	sh "$script" "$@"
}

if [ -f "$ROOT_DIR/lib/background-tasks.sh" ]; then
	# shellcheck disable=SC1091
	. "$ROOT_DIR/lib/background-tasks.sh"
fi

uplink_emit_task_status() {
	_running=0
	_task=""
	_pid=""
	_log=""
	_last_status=""
	_last_exit=""

	if bg_tasks_is_running 2>/dev/null; then
		_running=1
		_task="${BG_TASK_NAME:-}"
		_pid="${BG_TASK_PID:-}"
		_log="${BG_TASK_LOG_FILE:-}"
	elif bg_tasks_read_last_meta 2>/dev/null; then
		_task="${BG_TASK_LAST_NAME:-}"
		_log="${BG_TASK_LAST_LOG_FILE:-}"
		_last_status="${BG_TASK_LAST_STATUS:-}"
		_last_exit="${BG_TASK_LAST_EXIT_CODE:-}"
	fi

	if [ "$_running" -eq 1 ]; then
		printf 'STATUS=running\n'
	elif [ -n "$_last_status" ] || [ -n "$_task" ]; then
		printf 'STATUS=idle\n'
	else
		printf 'STATUS=none\n'
	fi
	[ -n "$_task" ] && printf 'TASK=%s\n' "$_task"
	[ -n "$_pid" ] && printf 'PID=%s\n' "$_pid"
	[ -n "$_log" ] && printf 'LOG=%s\n' "$_log"
	[ -n "$_last_status" ] && printf 'LAST_STATUS=%s\n' "$_last_status"
	[ -n "$_last_exit" ] && printf 'LAST_EXIT=%s\n' "$_last_exit"
	if [ -n "$_log" ] && [ -f "$_log" ]; then
		printf '%s\n' '---'
		tail -n 120 "$_log" 2>/dev/null || true
	fi
}

uplink_start_bg() {
	_task="$1"
	shift
	_runner="$ROOT_DIR/lib/bg-task-run.sh"
	_log="${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}/${_task}.log"

	[ -f "$_runner" ] || die "нет $_runner (фоновые задачи)"
	if bg_tasks_is_running 2>/dev/null; then
		printf '=== Задача уже выполняется ===\n'
		printf 'STATUS=already_running\n'
		uplink_emit_task_status
		return 0
	fi

	printf '=== Запуск в фоне: %s ===\n' "$_task"
	printf 'Лог: %s\n\n' "$_log"
	(
		export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
		sh "$_runner" "$_task" --log "$_log" -- env UPLINK_LUCI_FOREGROUND=1 "$@"
	) >/dev/null 2>&1 &
	sleep 1
	uplink_emit_task_status
}

uplink_want_bg() {
	[ "${UPLINK_LUCI_FOREGROUND:-}" = "1" ] && return 1
	case "$ACTION" in
	probe|tunnelsCheck|tunnelsStatusNow|ledTest|mgmtConnect|usbCycle|usbTest)
		return 0
		;;
	esac
	return 1
}

uplink_try_bg() {
	_task="$1"
	shift
	if uplink_want_bg; then
		uplink_start_bg "$_task" "$@"
		return 0
	fi
	return 1
}

action_settings() {
	local conf

	usb_watch_menu_ensure_vars 2>/dev/null || true
	conf="$(usb_watch_conf_path)"
	echo "=== Настройки uplink (текущий conf) ==="
	echo "Файл: $conf"
	echo
	echo "Редактирование полей (INTERVAL, FAIL_MAX, USB, VPN…) пока в CLI:"
	echo "  xft → Мониторинг канала → Настройки проверки и USB"
	echo
	echo "--- conf ---"
	if [ -f "$conf" ]; then
		cat "$conf"
	else
		echo "<нет файла — будет создан при включении cron>"
	fi
	echo
	echo "--- сводка ---"
	usb_watch_format_status 2>/dev/null || true
}

action_probe() {
	usb_watch_menu_ensure_vars 2>/dev/null || true
	usb_watch_normalize_probe_interval 2>/dev/null || true
	export USB_WATCH_LED_CYCLE_SH="$USB_WATCH_LED_CYCLE"

	echo "=== Проверка uplink сейчас (полный цикл, как cron-тик) ==="
	echo "Интерфейс : $(usb_watch_probe_iface_label)"
	echo "База      : $USB_WATCH_TEST_URL"
	echo "Доп.      : ${USB_WATCH_TEST_URL_ALT:-выкл.}"
	echo "FAIL      : $(usb_watch_state_get FAIL_COUNT 0)/$USB_WATCH_FAIL_MAX  bounce_max=${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}"
	echo "POWER_CYCLE: $(usb_watch_power_cycle_eligible_label 2>/dev/null | tr '\n' ' ' | sed 's/[[:space:]]*$//')"
	echo
	echo "--- тик ---"
	set +e
	usb_watch_handle_probe_tick
	_rc=$?
	set -e
	echo
	if [ "$_rc" != "0" ]; then
		echo "Тик завершился с USB power-cycle / settle (rc=$_rc)."
		echo
	fi
	echo "=== Состояние после тика ==="
	printf "  eval (0=full 1=fail 2=partial): %s\n" "$(usb_watch_state_get LAST_PROBE_EVAL ?)"
	printf "  FAIL_COUNT: %s / %s\n" "$(usb_watch_state_get FAIL_COUNT 0)" "$USB_WATCH_FAIL_MAX"
	printf "  base OK: %s  alt OK: %s  DNS: %s (%s)\n" \
		"$(usb_watch_state_get LAST_PROBE_BASE ?)" \
		"$(usb_watch_state_get LAST_PROBE_ALT ?)" \
		"$(usb_watch_state_get LAST_DNS_PROBE ?)" \
		"$(usb_watch_state_get LAST_DNS_PROBE_SUMMARY '?')"
	if command -v usb_watch_dns_probe_detail_report >/dev/null 2>&1; then
		echo
		usb_watch_dns_probe_detail_report
	fi
	if command -v usb_watch_tunnel_format_status_lines >/dev/null 2>&1; then
		usb_watch_tunnel_format_status_lines
	fi
	echo
	echo "Лог: $(usb_watch_run_log_path)"
}

# LuCI dashboard: structured settings + runtime (JSON via jshn).
action_get_config() {
	local cron_on=0
	local eval_lbl="?"
	local tunnels_txt=""

	set +u
	# shellcheck disable=SC1091
	. /usr/share/libubox/jshn.sh

	usb_watch_conf_ensure 2>/dev/null || true
	usb_watch_menu_ensure_vars 2>/dev/null || true
	usb_watch_normalize_probe_interval 2>/dev/null || true

	# tunnel probe helpers live in a separate lib
	# shellcheck disable=SC1091
	. "$HARDWARE_DIR/usb-watch-tunnel-probe.sh" 2>/dev/null || true

	if usb_watch_cron_installed; then
		cron_on=1
	fi

	case "$(usb_watch_state_get LAST_PROBE_EVAL ?)" in
	0) eval_lbl="full" ;;
	1) eval_lbl="fail" ;;
	2) eval_lbl="partial" ;;
	esac

	if command -v usb_watch_tunnel_format_status_lines >/dev/null 2>&1; then
		tunnels_txt="$(usb_watch_tunnel_format_status_lines 2>/dev/null || true)"
	fi

	json_init
	json_add_int code 0
	json_add_object settings
	json_add_string ENABLED "${USB_WATCH_ENABLED:-0}"
	json_add_string TEST_URL "${USB_WATCH_TEST_URL:-}"
	json_add_string TEST_URL_ALT "${USB_WATCH_TEST_URL_ALT:-}"
	json_add_string PROBE_IFACE "${USB_WATCH_PROBE_IFACE_RAW:-${USB_WATCH_PROBE_IFACE:-auto}}"
	json_add_string POWER_CYCLE "${USB_WATCH_POWER_CYCLE:-auto}"
	json_add_string INTERVAL_MIN "${USB_WATCH_INTERVAL_MIN:-3}"
	json_add_string PROBE_INTERVAL_SEC "${USB_WATCH_PROBE_INTERVAL_SEC:-20}"
	json_add_string FAIL_MAX "${USB_WATCH_FAIL_MAX:-3}"
	json_add_string CYCLE_MAX "${USB_WATCH_CYCLE_MAX:-3}"
	json_add_string OFF_SEC "${USB_WATCH_OFF_SEC:-8}"
	json_add_string ON_SEC "${USB_WATCH_ON_SEC:-5}"
	json_add_string SETTLE_SEC "${USB_WATCH_SETTLE_SEC:-90}"
	json_add_string LED_STATUS "${USB_WATCH_LED_STATUS:-1}"
	json_add_string TUNNEL_PROBE_ENABLED "${USB_WATCH_TUNNEL_PROBE_ENABLED:-1}"
	json_add_string TUNNEL_PROBE_SETTLE_SEC "${USB_WATCH_TUNNEL_PROBE_SETTLE_SEC:-15}"
	json_add_string TUNNEL_ICMP_FAIL_MAX "${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-3}"
	json_add_string TUNNEL_BOUNCE_MAX "${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}"
	json_add_string TUNNEL_BOUNCE_RETRY_MIN "${USB_WATCH_TUNNEL_BOUNCE_RETRY_MIN:-20}"
	json_add_string PROTON_GUEST_RENEW "${USB_WATCH_PROTON_GUEST_RENEW:-expiry}"
	json_add_string PROTON_GUEST_RENEW_SKEW_SEC "${USB_WATCH_PROTON_GUEST_RENEW_SKEW_SEC:-600}"
	json_add_string PROTON_GUEST_RENEW_COOLDOWN_SEC "${USB_WATCH_PROTON_GUEST_RENEW_COOLDOWN_SEC:-1800}"
	json_add_string DNS_PROBE_ENABLED "${USB_WATCH_DNS_PROBE_ENABLED:-1}"
	json_add_string DNS_PROBE_HOSTS "${USB_WATCH_DNS_PROBE_HOSTS:-ya.ru google.com chatgpt.com instagram.com kino.watch roblox.com}"
	json_add_string DNS_PROBE_HOST "${USB_WATCH_DNS_PROBE_HOSTS:-ya.ru google.com chatgpt.com instagram.com kino.watch roblox.com}"
	json_add_string DNS_PROBE_SERVER "${USB_WATCH_DNS_PROBE_SERVER:-127.0.0.1}"
	json_close_object

	json_add_object runtime
	json_add_int cron "$cron_on"
	json_add_string probe_iface_label "$(usb_watch_probe_iface_label 2>/dev/null || echo '?')"
	json_add_string power_cycle_label "$(usb_watch_power_cycle_eligible_label 2>/dev/null | tr '\n' ' ' | sed 's/[[:space:]]*$//' || true)"
	json_add_string fail_count "$(usb_watch_state_get FAIL_COUNT 0)"
	json_add_string cycle_count "$(usb_watch_state_get CYCLE_COUNT 0)"
	json_add_string cycle_lock "$(usb_watch_state_get CYCLE_LOCK 0)"
	json_add_string exhaust_lvl "$(usb_watch_state_get EXHAUST_LVL 0)"
	json_add_string last_tick "$(usb_watch_state_get LAST_TICK '')"
	json_add_string last_probe_eval "$(usb_watch_state_get LAST_PROBE_EVAL ?)"
	json_add_string last_probe_eval_label "$eval_lbl"
	json_add_string last_probe_base "$(usb_watch_state_get LAST_PROBE_BASE ?)"
	json_add_string last_probe_alt "$(usb_watch_state_get LAST_PROBE_ALT ?)"
	_dns_last="$(usb_watch_state_get LAST_DNS_PROBE ?)"
	json_add_string last_dns_probe "$_dns_last"
	json_add_string dns_probe_summary "$(usb_watch_state_get LAST_DNS_PROBE_SUMMARY '')"
	_dns_status="off"
	if [ "${USB_WATCH_DNS_PROBE_ENABLED:-1}" = "1" ]; then
		case "$_dns_last" in
		1) _dns_status="ok" ;;
		0) _dns_status="fail" ;;
		*) _dns_status="unknown" ;;
		esac
	fi
	json_add_string dns_probe_status "$_dns_status"

	_lib_tp=""
	if [ -f "$HARDWARE_DIR/../../diagnostics/lib/traffic-path.sh" ]; then
		_lib_tp="$HARDWARE_DIR/../../diagnostics/lib/traffic-path.sh"
	elif [ -f "/root/xfree-toolbox/diagnostics/lib/traffic-path.sh" ]; then
		_lib_tp="/root/xfree-toolbox/diagnostics/lib/traffic-path.sh"
	fi
	if [ -n "$_lib_tp" ]; then
		TRAFFIC_PATH_ROOT="$(cd "$(dirname "$_lib_tp")/../.." && pwd -P)"
		export TRAFFIC_PATH_ROOT
		# shellcheck disable=SC1090
		. "$_lib_tp" 2>/dev/null || true
		traffic_path_init_paths 2>/dev/null || true
	fi

	json_add_array dns_hosts
	for _h in ${USB_WATCH_DNS_PROBE_HOSTS:-ya.ru google.com chatgpt.com instagram.com kino.watch roblox.com}; do
		[ -n "$_h" ] || continue
		json_add_object
		json_add_string host "$_h"
		_d_info="default"
		if command -v traffic_path_match_dns >/dev/null 2>&1; then
			_m_dns="$(traffic_path_match_dns "$_h" 2>/dev/null || true)"
			if [ -n "$_m_dns" ]; then
				_dns_id="$(printf '%s' "$_m_dns" | cut -d'|' -f3)"
				[ -n "$_dns_id" ] && _d_info="$_dns_id"
			fi
		fi
		json_add_string dns "$_d_info"

		_r_info="WAN"
		if command -v traffic_path_match_iface >/dev/null 2>&1; then
			_m_iface="$(traffic_path_match_iface "$_h" 2>/dev/null || true)"
			if [ -n "$_m_iface" ]; then
				_iface_id="$(printf '%s' "$_m_iface" | cut -d'|' -f1)"
				[ -n "$_iface_id" ] && _r_info="VPN ($_iface_id)"
			fi
		fi
		json_add_string route "$_r_info"

		_h_status="unknown"
		if [ "$_dns_last" = "1" ]; then
			_h_status="ok"
		elif [ "$_dns_last" = "0" ]; then
			case "$_dns_summary" in
				*"$_h"*) _h_status="fail" ;;
				*) _h_status="ok" ;;
			esac
		fi
		json_add_string status "$_h_status"
		json_close_object
	done
	json_close_array

	json_add_string degraded "$(usb_watch_state_get CONNECTIVITY_DEGRADED 0)"
	json_add_string conf_path "$(usb_watch_conf_path)"
	json_add_string state_path "$(usb_watch_state_path)"
	json_add_string log_path "$(usb_watch_run_log_path 2>/dev/null || true)"
	json_add_string tunnels_text "$tunnels_txt"
	json_close_object
	json_dump
}

# SETTINGS_JSON='{"ENABLED":"1",...}' — only whitelisted keys.
action_save_config() {
	local conf json key val idx t
	local reinstall_cron=0
	local old_interval

	set +u
	# shellcheck disable=SC1091
	. /usr/share/libubox/jshn.sh

	json="${SETTINGS_JSON:-${ARG:-}}"
	[ -n "$json" ] || {
		json_init
		json_add_int code 1
		json_add_string stderr "settings_json required"
		json_dump
		return
	}

	usb_watch_conf_ensure 2>/dev/null || true
	usb_watch_menu_ensure_vars 2>/dev/null || true
	conf="$(usb_watch_conf_path)"
	old_interval="${USB_WATCH_INTERVAL_MIN:-3}"

	json_load "$json" || {
		json_init
		json_add_int code 1
		json_add_string stderr "invalid settings_json"
		json_dump
		return
	}

	for key in ENABLED TEST_URL TEST_URL_ALT PROBE_IFACE POWER_CYCLE \
		INTERVAL_MIN PROBE_INTERVAL_SEC FAIL_MAX CYCLE_MAX OFF_SEC ON_SEC SETTLE_SEC \
		LED_STATUS TUNNEL_PROBE_ENABLED TUNNEL_PROBE_SETTLE_SEC TUNNEL_ICMP_FAIL_MAX \
		TUNNEL_BOUNCE_MAX TUNNEL_BOUNCE_RETRY_MIN PROTON_GUEST_RENEW PROTON_GUEST_RENEW_SKEW_SEC \
		PROTON_GUEST_RENEW_COOLDOWN_SEC DNS_PROBE_ENABLED DNS_PROBE_HOSTS DNS_PROBE_HOST DNS_PROBE_SERVER; do
		json_get_var val "$key" || continue
		val="$(printf '%s' "$val" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
		case "$key" in
		ENABLED|LED_STATUS|TUNNEL_PROBE_ENABLED|DNS_PROBE_ENABLED)
			case "$val" in 1|true|on|yes) val=1 ;; *) val=0 ;; esac
			;;
		INTERVAL_MIN)
			case "$val" in ''|*[!0-9]*) val=3 ;; esac
			[ "$val" -ge 1 ] 2>/dev/null || val=3
			[ "$val" -le 60 ] 2>/dev/null || val=60
			[ "$val" != "$old_interval" ] && reinstall_cron=1
			;;
		PROBE_INTERVAL_SEC|FAIL_MAX|CYCLE_MAX|OFF_SEC|ON_SEC|SETTLE_SEC|\
		TUNNEL_PROBE_SETTLE_SEC|TUNNEL_ICMP_FAIL_MAX|TUNNEL_BOUNCE_MAX|TUNNEL_BOUNCE_RETRY_MIN|\
		PROTON_GUEST_RENEW_SKEW_SEC|PROTON_GUEST_RENEW_COOLDOWN_SEC)
			case "$val" in ''|*[!0-9]*) continue ;; esac
			;;
		PROBE_IFACE)
			[ -n "$val" ] || val=auto
			;;
		POWER_CYCLE)
			case "$val" in auto|on|off|1|0) ;; *) val=auto ;; esac
			;;
		PROTON_GUEST_RENEW)
			case "$val" in expiry|tunnel-fail|both|off) ;; *) val=expiry ;; esac
			;;
		DNS_PROBE_HOSTS|DNS_PROBE_HOST)
			val="$(printf '%s' "$val" | tr '\n\r\t,' ' ' | sed -E 's/[[:space:]]+/ /g; s/^[[:space:]]+//; s/[[:space:]]+$//')"
			[ -n "$val" ] || val="ya.ru google.com chatgpt.com instagram.com kino.watch roblox.com"
			# Always keep DNS_PROBE_HOSTS in conf
			usb_watch_conf_set "$conf" "DNS_PROBE_HOSTS" "$val"
			key="DNS_PROBE_HOSTS"
			;;
		DNS_PROBE_SERVER)
			[ -n "$val" ] || val=127.0.0.1
			;;
		TEST_URL|TEST_URL_ALT)
			# URLs / empty alt
			;;
		esac
		usb_watch_conf_set "$conf" "$key" "$val"
	done

	usb_watch_menu_ensure_vars 2>/dev/null || true
	usb_watch_normalize_probe_interval 2>/dev/null || true

	if [ "$reinstall_cron" -eq 1 ] && usb_watch_cron_installed; then
		sh "$USB_WATCH_CRON" install >/dev/null 2>&1 || true
	fi

	json_init
	json_add_int code 0
	json_add_string stdout "saved"
	json_add_string conf "$conf"
	json_dump
}

ACTION="${1:-}"
ARG="${2:-}"

case "$ACTION" in
status)
	run_sh "$STATUS_SH"
	;;
settings)
	action_settings
	;;
getConfig)
	action_get_config
	;;
saveConfig)
	action_save_config
	;;
taskStatus)
	uplink_emit_task_status
	;;
probe)
	uplink_try_bg "uplink-probe" sh "$SCRIPT_DIR/luci-rpc.sh" probe && exit 0
	action_probe
	;;
cronOn)
	usb_watch_menu_ensure_vars 2>/dev/null || true
	usb_watch_normalize_probe_interval 2>/dev/null || true
	usb_watch_conf_set "$(usb_watch_conf_path)" ENABLED 1
	run_sh "$USB_WATCH_CRON" install
	;;
cronOff)
	run_sh "$USB_WATCH_CRON" remove
	;;
usbCycle)
	uplink_try_bg "usb-cycle" sh "$SCRIPT_DIR/luci-rpc.sh" usbCycle && exit 0
	usb_watch_menu_ensure_vars 2>/dev/null || true
	run_sh "$USB_WATCH_LED_CYCLE" "${USB_WATCH_OFF_SEC:-8}" "${USB_WATCH_ON_SEC:-5}" 1
	;;
usbTest)
	uplink_try_bg "usb-test" sh "$SCRIPT_DIR/luci-rpc.sh" usbTest && exit 0
	usb_watch_menu_ensure_vars 2>/dev/null || true
	run_sh "$USB_POWER_SH" test "${USB_WATCH_OFF_SEC:-8}" "${USB_WATCH_ON_SEC:-5}"
	;;
tunnelsCheck)
	uplink_try_bg "tunnels-check" sh "$SCRIPT_DIR/luci-rpc.sh" tunnelsCheck && exit 0
	run_sh "$CHECK_SH" --all
	;;
tunnelsStatusNow)
	uplink_try_bg "tunnels-status" sh "$SCRIPT_DIR/luci-rpc.sh" tunnelsStatusNow && exit 0
	run_sh "$RUN_SH"
	;;
tunnelsCronOn)
	case "${ARG:-15}" in
	5|15|30|60) ;;
	*) ARG=15 ;;
	esac
	run_sh "$INSTALL_SH" --minutes "$ARG"
	;;
tunnelsCronOff)
	run_sh "$REMOVE_SH"
	;;
tunnelsRemove)
	export REMOVE_MONITOR_FILES=1
	run_sh "$REMOVE_SH"
	;;
tunnelsLast)
	run_sh "$TUNNELS_STATUS_SH"
	;;
ledTest)
	uplink_try_bg "led-test" sh "$SCRIPT_DIR/luci-rpc.sh" ledTest && exit 0
	run_sh "$LED_TEST_SH"
	;;
mgmtConnect)
	uplink_try_bg "mgmt-connect" sh "$SCRIPT_DIR/luci-rpc.sh" mgmtConnect && exit 0
	run_sh "$MGMT_ENSURE_SH"
	;;
dnsHostsGet)
	run_sh "$DNS_CHECK_SH" --get-hosts
	;;
dnsHostsSave)
	run_sh "$DNS_CHECK_SH" --set-hosts "$ARG"
	;;
dnsHostsReset)
	run_sh "$DNS_CHECK_SH" --reset-hosts
	;;
dnsPrimarySet)
	run_sh "$DNS_CHECK_SH" --set-primary "$ARG"
	;;
dnsPrimaryClear)
	run_sh "$DNS_CHECK_SH" --clear-primary "$ARG"
	;;
systemLogs)
	echo "=== Системный журнал (logread) ==="
	logread 2>/dev/null | tail -n 150 || dmesg | tail -n 150
	;;
watchdogLogs)
	echo "=== Журнал мониторинга канала (uplink-monitor) ==="
	_log="$(usb_watch_run_log_path 2>/dev/null || true)"
	if [ -n "$_log" ] && [ -f "$_log" ]; then
		tail -n 150 "$_log"
	elif [ -f /etc/xfree-toolbox/system/usb-power-watch.log ]; then
		tail -n 150 /etc/xfree-toolbox/system/usb-power-watch.log
	elif [ -f /tmp/usb-watch.log ]; then
		tail -n 150 /tmp/usb-watch.log
	elif [ -f /var/log/usb-watch.log ]; then
		tail -n 150 /var/log/usb-watch.log
	else
		echo "Лог-файл мониторинга пока пуст или не создан."
	fi
	;;
testDoh)
	echo "=== Проверка DoH-инстансов (https-dns-proxy 5060/5061) ==="
	if [ -f "$ROOT_DIR/https-dns-proxy/test-doh-upstreams.sh" ]; then
		if [ "${ARG:-}" = "ab" ] || [ "${ARG:-}" = "--ab" ]; then
			sh "$ROOT_DIR/https-dns-proxy/test-doh-upstreams.sh" --yes --ab
		else
			sh "$ROOT_DIR/https-dns-proxy/test-doh-upstreams.sh" --yes --no-ab
		fi
	else
		echo "Скрипт test-doh-upstreams.sh не найден."
	fi
	;;
*)
	echo "unknown uplinkMenu action: ${ACTION:-?}" >&2
	exit 1
	;;
esac
