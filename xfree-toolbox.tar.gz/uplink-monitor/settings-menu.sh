#!/bin/sh
# shellcheck shell=sh
# Подменю настроек uplink — отдельный процесс (как вложенное меню в modem/diagnostics).
# Usage: settings-menu.sh ui

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/ui.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
common_load_project_config "$ROOT_DIR"
ui_init
ui_trap_cleanup_on_exit
set +e

export USB_WATCH_ROOT_DIR="$ROOT_DIR"
export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
export UPLINK_MONITOR_LIB=1
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib-ui.sh"

case "${1:-ui}" in
    ui) settings_menu ;;
    *) echo "Usage: $0 [ui]" >&2; exit 1 ;;
esac
