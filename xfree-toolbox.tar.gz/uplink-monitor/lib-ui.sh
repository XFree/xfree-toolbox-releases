#!/bin/sh
# shellcheck shell=sh
# Мониторинг uplink: probe, LED, recovery VPN, опц. USB power-cycle.
# Режим библиотеки: UPLINK_MONITOR_LIB=1 (menu.handlers) — без set -eu и без повторного ui_init.

if [ "${UPLINK_MONITOR_LIB:-0}" = "1" ] && [ "${UPLINK_LIB_UI_LOADED:-0}" = "1" ]; then
    return 0 2>/dev/null || exit 0
fi
[ "${UPLINK_MONITOR_LIB:-0}" = "1" ] && UPLINK_LIB_UI_LOADED=1

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
HARDWARE_DIR="$ROOT_DIR/system/hardware"
MODEM_LIB="$ROOT_DIR/system/modem/lib.sh"

if [ "${UPLINK_MONITOR_LIB:-0}" = "1" ]; then
    :
else
    set -eu
    # shellcheck disable=SC1091
    . "$ROOT_DIR/lib/common.sh"
    load_base_config "$ROOT_DIR"
    # shellcheck disable=SC1091
    . "$ROOT_DIR/lib/ui.sh"
    ui_init
    ui_trap_cleanup_on_exit
fi

export USB_WATCH_ROOT_DIR="${USB_WATCH_ROOT_DIR:-$ROOT_DIR}"
export XFREE_TOOLBOX_ROOT="${XFREE_TOOLBOX_ROOT:-$ROOT_DIR}"

# shellcheck disable=SC1091
. "$HARDWARE_DIR/usb-power-watch-lib.sh"
[ -f "$MODEM_LIB" ] && . "$MODEM_LIB" || true

USB_POWER_SH="$HARDWARE_DIR/usb-power.sh"
USB_WATCH_RUN="$HARDWARE_DIR/usb-power-watch-run.sh"
USB_WATCH_CRON="$HARDWARE_DIR/usb-power-watch-cron.sh"
USB_WATCH_LED_CYCLE="$HARDWARE_DIR/usb-power-watch-led-cycle.sh"

run_log() { ui_menu_invoke_with_output "$@"; }

# Отмена в dialog inputbox → пустая строка; не показывать «Ошибка валидации».
usb_watch_read_uint_input() {
    val="$(ui_inputbox_or_back "$1" "$2" "$3")" || return 1
    [ -n "$val" ] || return 1
    printf '%s\n' "$val"
}

show_status_box() {
    usb_watch_maybe_reset_after_reboot || true
    usb_watch_menu_ensure_vars 2>/dev/null || true
    report="${UI_TMP_ROOT:-/tmp}/usb-power-watch-status.$$"
    {
        set +e
        usb_watch_format_status 2>&1
        printf '\n=== Последний probe (state) ===\n'
        printf '  eval (0=full 1=fail 2=partial): %s\n' "$(usb_watch_state_get LAST_PROBE_EVAL '?')"
        printf '  base OK: %s  alt OK: %s\n' \
            "$(usb_watch_state_get LAST_PROBE_BASE '?')" \
            "$(usb_watch_state_get LAST_PROBE_ALT '?')"
        printf '  CONNECTIVITY_DEGRADED: %s\n' "$(usb_watch_state_get CONNECTIVITY_DEGRADED 0)"
        printf '\n=== USB power ===\n'
        case "${USB_WATCH_POWER_CYCLE:-auto}" in
            off|0|n|no|false)
                printf 'POWER_CYCLE=off — перечень бэкендов пропущен.\n'
                ;;
            *)
                if [ -f "$USB_POWER_SH" ]; then
                    sh "$USB_POWER_SH" status 2>&1
                else
                    printf 'usb-power.sh не найден: %s\n' "$USB_POWER_SH"
                fi
                ;;
        esac
    } >"$report" 2>&1
    if [ ! -s "$report" ]; then
        printf 'Не удалось собрать статус (пустой отчёт).\n' >"$report"
    fi
    ui_show_textbox "Мониторинг uplink" "$report" 28 "${UI_WIDTH:-78}" || true
    rm -f "$report" 2>/dev/null || true
}

edit_test_url() {
    usb_watch_menu_ensure_vars
    choice="$(ui_menu "Базовый адрес (проверка uplink)" \
"Базовый probe uplink. При сбое растёт FAIL_COUNT → USB power-cycle.
Доп. адрес (п.3) на cycle не влияет — только LED. Текущий: $USB_WATCH_TEST_URL" 20 78 9 \
        "1" "https://ya.ru/ (белые списки РФ)" \
        "2" "http://192.168.8.1/ (HiLink, только модем)" \
        "3" "Ввести URL / IP вручную" \
        "0" "Назад" || true)"
    [ -n "${choice:-}" ] || return 0
    case "$choice" in
        0) return 0 ;;
        1) val="https://ya.ru/" ;;
        2) val="http://192.168.8.1/" ;;
        3)
            val="$(ui_inputbox_or_back "Базовый адрес" \
"URL (https://…) или host/IP — проверка ping (хост из URL)." \
"$USB_WATCH_TEST_URL")" || return 0
            [ -n "$val" ] || return 0
            ;;
        *) return 0 ;;
    esac
    usb_watch_conf_set "$(usb_watch_conf_path)" TEST_URL "$val"
    ui_msgbox "Сохранено" "TEST_URL=$val"
}

edit_probe_iface() {
    usb_watch_menu_ensure_vars
    modem_lib_guess_hilink_device 2>/dev/null || true
    _l2="${MODEM_HILINK_DEVICE:-}"
    _hint="Интерфейс проверки uplink (ping -I). Не путать с таймерами USB power-cycle.
auto: default route → wan/wwan/lte (lte только на USB-платформах из known-routers.tsv).
Сейчас: $(usb_watch_probe_iface_label)"
    if [ -n "$_l2" ]; then
        choice="$(ui_menu "Интерфейс проверки uplink" "$_hint" 24 78 13 \
            "1" "auto — default route / wan→wwan→lte" \
            "2" "lte (USB-модем, UCI network.lte)" \
            "3" "wan (Ethernet / PPPoE)" \
            "4" "wwan (Wi‑Fi STA / network.wwan)" \
            "5" "Ввести UCI-имя или eth*/wwan* вручную" \
            "6" "L2 $_l2 (HiLink, cdc_ether)" \
            "0" "Назад" || true)"
    else
        choice="$(ui_menu "Интерфейс проверки uplink" "$_hint" 22 78 11 \
            "1" "auto — default route / wan→wwan→lte" \
            "2" "lte (USB-модем, UCI network.lte)" \
            "3" "wan (Ethernet / PPPoE)" \
            "4" "wwan (Wi‑Fi STA / network.wwan)" \
            "5" "Ввести UCI-имя или eth*/wwan* вручную" \
            "0" "Назад" || true)"
    fi
    [ -n "${choice:-}" ] || return 0
    case "$choice" in
        0) return 0 ;;
        1) val="auto" ;;
        2) val="lte" ;;
        3) val="wan" ;;
        4) val="wwan" ;;
        5)
            val="$(ui_inputbox_or_back "Интерфейс" \
"UCI (wan, wwan, lte) или L2 (eth1, wwan0). Пусто = auto." \
"${USB_WATCH_PROBE_IFACE_RAW:-$USB_WATCH_PROBE_IFACE}")" || return 0
            [ -n "$val" ] || val="auto"
            ;;
        6)
            val="$_l2"
            ;;
        *) return 0 ;;
    esac
    usb_watch_conf_set "$(usb_watch_conf_path)" PROBE_IFACE "$val"
    usb_watch_menu_ensure_vars
    ui_msgbox "Сохранено" "PROBE_IFACE=$val

$(usb_watch_probe_iface_label)"
}

edit_test_url_alt() {
    usb_watch_menu_ensure_vars
    choice="$(ui_menu "Доп. адрес (проверка uplink)" \
"Только LED «полный интернет» (не USB power-cycle). База OK + доп. FAIL → PARTIAL.
Текущий: ${USB_WATCH_TEST_URL_ALT:-—}" 22 78 10 \
        "1" "https://github.com/" \
        "2" "https://api.github.com/" \
        "3" "Выключить доп. проверку" \
        "4" "Ввести URL вручную" \
        "0" "Назад" || true)"
    [ -n "${choice:-}" ] || return 0
    case "$choice" in
        0) return 0 ;;
        1) val="https://github.com/" ;;
        2) val="https://api.github.com/" ;;
        3) val="-" ;;
        4)
            val="$(ui_inputbox_or_back "Доп. адрес" \
"URL вне белых списков. Пусто или «-» — выключить." \
"$USB_WATCH_TEST_URL_ALT")" || return 0
            [ -n "$val" ] || val="-"
            ;;
        *) return 0 ;;
    esac
    usb_watch_conf_set "$(usb_watch_conf_path)" TEST_URL_ALT "$val"
    if [ "$val" = "-" ]; then
        ui_msgbox "Сохранено" "TEST_URL_ALT выключен"
    else
        ui_msgbox "Сохранено" "TEST_URL_ALT=$val"
    fi
}

edit_interval() {
    usb_watch_menu_ensure_vars
    choice="$(ui_menu "Период cron — проверка uplink (мин)" \
"Как часто запускается сессия проверки uplink (длина сессии).
Внутри — probe чаще (п.5). Не пауза после USB power-cycle (п.8).
Любое целое 1–60 (60 = раз в час). Текущий: ${USB_WATCH_INTERVAL_MIN} мин" 22 78 10 \
        "1" "3 мин (по умолчанию)" \
        "2" "5 мин" \
        "3" "10 мин" \
        "4" "15 мин" \
        "5" "30 мин" \
        "6" "60 мин (раз в час)" \
        "7" "Своё значение (1–60)" \
        "0" "Назад" || true)"
    [ -n "${choice:-}" ] || return 0
    case "$choice" in
        0) return 0 ;;
        1) val=3 ;;
        2) val=5 ;;
        3) val=10 ;;
        4) val=15 ;;
        5) val=30 ;;
        6) val=60 ;;
        7)
            val="$(usb_watch_read_uint_input "Интервал (мин)" \
"Целое от 1 до 60. Пример: 3, 7, 12." \
"$USB_WATCH_INTERVAL_MIN")" || return 0
            ;;
        *) return 0 ;;
    esac
    if ! usb_watch_interval_valid "$val"; then
        ui_msgbox "Ошибка" "Нужно целое число от 1 до 60 (60 = раз в час)."
        return 0
    fi
    usb_watch_conf_set "$(usb_watch_conf_path)" INTERVAL_MIN "$val"
    ui_msgbox "Сохранено" "INTERVAL_MIN=$val мин

Переустановите cron (Мониторинг канала → «Включить периодическую проверку канала»)."
}

edit_probe_interval() {
    usb_watch_menu_ensure_vars
    usb_watch_normalize_probe_interval
    _max=$(( USB_WATCH_INTERVAL_MIN * 60 ))
    val="$(usb_watch_read_uint_input "Интервал probe uplink (сек)" \
"Пауза между проверками URL внутри cron-сессии (проверка uplink).
FAIL_MAX — подряд сбои probe, не минуты cron и не SETTLE после USB cycle.
Диапазон 3–${_max} (не больше периода ${USB_WATCH_INTERVAL_MIN} мин).
Текущий: $USB_WATCH_PROBE_INTERVAL_SEC" \
"$USB_WATCH_PROBE_INTERVAL_SEC")" || return 0
    if ! usb_watch_probe_interval_valid "$val"; then
        ui_msgbox "Ошибка" "Нужно целое от 3 до 3600 сек."
        return 0
    fi
    _max=$(( USB_WATCH_INTERVAL_MIN * 60 ))
    [ "$_max" -lt 3 ] && _max=3
    if [ "$val" -gt "$_max" ] 2>/dev/null; then
        ui_msgbox "Ошибка" "Не больше периода cron: ${_max} с (${USB_WATCH_INTERVAL_MIN} мин)."
        return 0
    fi
    usb_watch_conf_set "$(usb_watch_conf_path)" PROBE_INTERVAL_SEC "$val"
    _est=$(( (USB_WATCH_INTERVAL_MIN * 60 + val - 1) / val ))
    ui_msgbox "Сохранено" "PROBE_INTERVAL_SEC=$val с

В одной сессии (~${USB_WATCH_INTERVAL_MIN} мин) ожидается до ${_est} probe."
}

edit_fail_max() {
    usb_watch_menu_ensure_vars
    val="$(usb_watch_read_uint_input "Порог сбоев uplink" \
"Общий мониторинг uplink: сколько подряд FAIL базового probe =
подтверждённый outage. Один FAIL интернет не считает пропавшим.

Реакции на outage (не отдельные пороги):
• сброс VPN bounce (после возврата probe в full — restart);
• USB power-cycle модема — если POWER_CYCLE это разрешает.

Считаются сбои probe, не «раз в N минут» cron.
Текущий: $USB_WATCH_FAIL_MAX" \
"$USB_WATCH_FAIL_MAX")" || return 0
    case "$val" in
        *[!0-9]*)
            ui_msgbox "Ошибка" "Нужно целое число ≥ 1"
            return 0
            ;;
    esac
    [ "$val" -ge 1 ] 2>/dev/null || {
        ui_msgbox "Ошибка" "Нужно целое число ≥ 1"
        return 0
    }
    usb_watch_conf_set "$(usb_watch_conf_path)" FAIL_MAX "$val"
    ui_msgbox "Сохранено" "FAIL_MAX=$val (общий порог outage uplink)"
}

edit_off_sec() {
    usb_watch_menu_ensure_vars
    val="$(usb_watch_read_uint_input "USB power-cycle: USB OFF" \
"Секунд с ВЫКЛЮЧЕННЫМ USB во время одной перезагрузки модема.
Текущий: $USB_WATCH_OFF_SEC" \
"$USB_WATCH_OFF_SEC")" || return 0
    case "$val" in
        *[!0-9]*)
            ui_msgbox "Ошибка" "Нужно целое число секунд"
            return 0
            ;;
    esac
    usb_watch_conf_set "$(usb_watch_conf_path)" OFF_SEC "$val"
    ui_msgbox "Сохранено" "OFF_SEC=$val"
}

edit_cycle_max() {
    usb_watch_menu_ensure_vars
    val="$(usb_watch_read_uint_input "USB power-cycle: макс. попыток" \
"Сколько раз подряд можно перезагрузить USB без успешной проверки.
После лимита — блокировка до OK или сброса в меню.
Текущий: $USB_WATCH_CYCLE_MAX" \
"$USB_WATCH_CYCLE_MAX")" || return 0
    case "$val" in
        *[!0-9]*)
            ui_msgbox "Ошибка" "Нужно целое число ≥ 1"
            return 0
            ;;
    esac
    [ "$val" -ge 1 ] 2>/dev/null || {
        ui_msgbox "Ошибка" "Нужно целое число ≥ 1"
        return 0
    }
    usb_watch_conf_set "$(usb_watch_conf_path)" CYCLE_MAX "$val"
    ui_msgbox "Сохранено" "CYCLE_MAX=$val"
}

edit_settle_sec() {
    usb_watch_menu_ensure_vars
    val="$(usb_watch_read_uint_input "USB power-cycle: пауза после" \
"Секунд без обычного probe после USB power-cycle (подъём lte, DHCP).
Не связано с периодом cron (проверка uplink). Текущий: $USB_WATCH_SETTLE_SEC" \
"$USB_WATCH_SETTLE_SEC")" || return 0
    case "$val" in
        *[!0-9]*)
            ui_msgbox "Ошибка" "Нужно целое число секунд"
            return 0
            ;;
    esac
    usb_watch_conf_set "$(usb_watch_conf_path)" SETTLE_SEC "$val"
    ui_msgbox "Сохранено" "SETTLE_SEC=$val"
}

edit_on_sec() {
    usb_watch_menu_ensure_vars
    val="$(usb_watch_read_uint_input "USB power-cycle: USB ON" \
"Секунд с ВКЛЮЧЁННЫМ USB внутри USB power-cycle (модем виден, ждём перед ifup).
Текущий: $USB_WATCH_ON_SEC" \
"$USB_WATCH_ON_SEC")" || return 0
    case "$val" in
        *[!0-9]*)
            ui_msgbox "Ошибка" "Нужно целое число секунд"
            return 0
            ;;
    esac
    usb_watch_conf_set "$(usb_watch_conf_path)" ON_SEC "$val"
    ui_msgbox "Сохранено" "ON_SEC=$val"
}

reset_cycle_lock_confirm() {
    usb_watch_menu_ensure_vars
    if ! ui_confirm "USB power-cycle: сброс блокировки" \
"Обнулить CYCLE_COUNT, CYCLE_LOCK, FAIL_COUNT, уровень auto-retry и счётчики VPN bounce.

Используйте после замены SIM / ручного ifup lte / ручного restart VPN.

Сейчас: cycles=$(usb_watch_state_get CYCLE_COUNT 0)/$USB_WATCH_CYCLE_MAX, lock=$(usb_watch_state_get CYCLE_EXHAUSTED 0), auto-ур.=$(usb_watch_state_get EXHAUST_AUTO_LEVEL 0)"; then
        return 0
    fi
    usb_watch_reset_cycle_lock
    ui_msgbox "Сброшено" "Блокировка power-cycle и VPN bounce снята.

То же после перезагрузки роутера или при успешном probe базового URL / VPN ping."
}

reset_monitor_storage_confirm() {
    usb_watch_menu_ensure_vars
    _extra=""
    if _polluted="$(usb_watch_conf_runtime_keys_present 2>/dev/null)" && [ -n "$_polluted" ]; then
        _extra="
В conf сейчас лишнее: $_polluted"
    fi
    if ! ui_confirm "Сброс состояния" \
"1) Удалить из usb-power-watch.conf все ключи состояния (FAIL_COUNT, LAST_*, NET_LED_MODE, …) — останутся только настройки.
2) Обнулить usb-power-watch.state (счётчики fail/cycle, LAST_*).

ENABLED, TEST_URL, INTERVAL_MIN и паузы не трогаются.${_extra}

Продолжить?"; then
        return 0
    fi
    _rm="$(usb_watch_reset_monitor_storage)"
    ui_msgbox "Сброшено" "Удалено из conf: ${_rm} строк(и) состояния.
Файл state пересоздан (счётчики 0).

Конфиг: $(usb_watch_conf_path)
Состояние: $(usb_watch_state_path)"
}

toggle_enabled() {
    usb_watch_menu_ensure_vars
    if [ "$USB_WATCH_ENABLED" = "1" ]; then
        new=0
        label="выключен"
    else
        new=1
        label="включён"
    fi
    usb_watch_conf_set "$(usb_watch_conf_path)" ENABLED "$new"
    if [ "$new" = "0" ]; then
        sh -c '
            . "'"$ROOT_DIR"'/lib/led/led-lib.sh"
            . "'"$HARDWARE_DIR"'/internet-status-led-lib.sh"
            internet_status_led_disable 2>/dev/null || true
        '
    fi
    ui_msgbox "Мониторинг" "ENABLED=$new ($label)

ENABLED=1 сам по себе не запускает опрос — нужен пункт «Включить периодическую проверку канала» (п.6).
При выключении мониторинга или снятии cron LED возвращаются к UCI."
}

probe_once() {
    # Same bootstrap as usb-power-watch-run.sh (cron): common.sh + config so tunnel
    # probe resolves PROFILE_DIR/iface-routing/interfaces (proton/warp). Without this,
    # subprocess reported «нет интерфейсов в профиле» while status/cron showed OK.
    UI_RUN_WITH_OUTPUT_MODE=textbox run_log "Проверка сейчас" sh -c '
        . "'"$ROOT_DIR"'/lib/common.sh"
        load_base_config "'"$ROOT_DIR"'"
        export USB_WATCH_ROOT_DIR="'"$ROOT_DIR"'"
        export XFREE_TOOLBOX_ROOT="'"$ROOT_DIR"'"
        . "'"$HARDWARE_DIR"'/usb-power-watch-lib.sh"
        . "'"$ROOT_DIR"'/lib/led/led-lib.sh"
        . "'"$HARDWARE_DIR"'/internet-status-led-lib.sh"
        . "'"$HARDWARE_DIR"'/lib-board.sh"
        export USB_WATCH_LED_CYCLE_SH="'"$USB_WATCH_LED_CYCLE"'"
        usb_watch_menu_ensure_vars
        usb_watch_normalize_probe_interval 2>/dev/null || true

        echo "=== Проверка uplink сейчас (полный цикл, как cron-тик) ==="
        echo "Интерфейс : $(usb_watch_probe_iface_label)"
        echo "База      : $USB_WATCH_TEST_URL"
        echo "Доп.      : ${USB_WATCH_TEST_URL_ALT:-выкл.}"
        echo "FAIL      : $(usb_watch_state_get FAIL_COUNT 0)/$USB_WATCH_FAIL_MAX  bounce_max=${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}"
        echo "POWER_CYCLE: $(usb_watch_power_cycle_eligible_label | tr "\n" " " | sed "s/[[:space:]]*$//")"
        echo ""
        echo "--- тик ---"
        set +e
        usb_watch_handle_probe_tick
        _rc=$?
        set -e
        echo ""
        if [ "$_rc" != "0" ]; then
            echo "Тик завершился с USB power-cycle / settle (rc=$_rc)."
            echo ""
        fi
        echo "=== Состояние после тика ==="
        printf "  eval (0=full 1=fail 2=partial): %s\n" "$(usb_watch_state_get LAST_PROBE_EVAL ?)"
        printf "  FAIL_COUNT: %s / %s\n" "$(usb_watch_state_get FAIL_COUNT 0)" "$USB_WATCH_FAIL_MAX"
        printf "  base OK: %s  alt OK: %s\n" \
            "$(usb_watch_state_get LAST_PROBE_BASE ?)" \
            "$(usb_watch_state_get LAST_PROBE_ALT ?)"
        if command -v usb_watch_tunnel_format_status_lines >/dev/null 2>&1; then
            usb_watch_tunnel_format_status_lines
        fi
        echo ""
        echo "Лог: $(usb_watch_run_log_path)"
        exit 0
    '
}

cycle_now_confirm() {
    usb_watch_menu_ensure_vars
    if ui_confirm "USB power-cycle" \
"Паузы: OFF=${USB_WATCH_OFF_SEC} с, ON=${USB_WATCH_ON_SEC} с.
LED: red:fault ↔ blue:wan (0.5 с), затем ожидание интернета до ${USB_WATCH_SETTLE_SEC} с.
Бэкенд: xhci-mtk / gpio / uhubctl.

Модем пропадёт из lsusb на время OFF.
Продолжить?"; then
        run_log "USB power-cycle" sh "$USB_WATCH_LED_CYCLE" "$USB_WATCH_OFF_SEC" "$USB_WATCH_ON_SEC" 1
    fi
}

test_detailed_confirm() {
    usb_watch_menu_ensure_vars
    if ui_confirm "Тест USB (подробный)" \
"lsusb, regulator, dmesg; паузы OFF=${USB_WATCH_OFF_SEC} ON=${USB_WATCH_ON_SEC}.

Продолжить?"; then
        run_log "USB power TEST" sh "$USB_POWER_SH" test "$USB_WATCH_OFF_SEC" "$USB_WATCH_ON_SEC"
    fi
}

install_cron_confirm() {
    usb_watch_menu_ensure_vars
    usb_watch_normalize_probe_interval
    _plan="$(usb_watch_uplink_operational_summary 2>/dev/null || true)"
    if ui_confirm "Установить cron" \
"Мониторинг uplink (probe, LED, recovery VPN; USB cycle только при модеме):

${_plan}

Cron: каждые ${USB_WATCH_INTERVAL_MIN} мин → usb-power-watch-run.sh

LED: blue:wan-online / red:fault — backup UCI, trigger=none.
При «Снять cron» — UCI и LED как до установки.

ENABLED→1 (сейчас: ${USB_WATCH_ENABLED}).

Продолжить?"; then
        usb_watch_conf_set "$(usb_watch_conf_path)" ENABLED 1
        run_log "Cron: мониторинг uplink" sh "$USB_WATCH_CRON" install
    fi
}

remove_cron_confirm() {
    if ui_confirm "Снять cron" \
"Удалить задачу usb-power-watch из crontab.

Индикаторы и правила LuCI (blue:wan-online / fault / blue:wan)
восстановятся из backup (как до установки cron)."; then
        run_log "Cron: удаление" sh "$USB_WATCH_CRON" remove
    fi
}

edit_tunnel_icmp_fail_max() {
    usb_watch_menu_ensure_vars
    val="$(ui_inputbox "VPN: порог FAIL до restart" \
"Сколько подряд FAIL ICMP туннеля (при uplink full) до ifdown/ifup —
как FAIL_MAX для uplink/USB. Пауза между проверками = интервал probe.
Текущий: ${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-3}" \
"${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-3}")" || return 0
    case "$val" in
        ''|*[!0-9]*)
            ui_msgbox "Ошибка" "Нужно целое число ≥ 1"
            return 0
            ;;
    esac
    [ "$val" -ge 1 ] 2>/dev/null || {
        ui_msgbox "Ошибка" "Нужно целое число ≥ 1"
        return 0
    }
    usb_watch_conf_set "$(usb_watch_conf_path)" TUNNEL_ICMP_FAIL_MAX "$val"
    ui_msgbox "Сохранено" "TUNNEL_ICMP_FAIL_MAX=$val"
}

edit_tunnel_bounce_max() {
    usb_watch_menu_ensure_vars
    val="$(ui_inputbox "VPN: макс. restart (как CYCLE_MAX)" \
"Сколько ifdown/ifup подряд после подтверждённого FAIL туннеля
(после TUNNEL_ICMP_FAIL_MAX). Дальше — только лог/probe (paused).
Текущий: ${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}" \
"${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}")" || return 0
    case "$val" in
        ''|*[!0-9]*)
            ui_msgbox "Ошибка" "Нужно целое число ≥ 1"
            return 0
            ;;
    esac
    [ "$val" -ge 1 ] 2>/dev/null || {
        ui_msgbox "Ошибка" "Нужно целое число ≥ 1"
        return 0
    }
    usb_watch_conf_set "$(usb_watch_conf_path)" TUNNEL_BOUNCE_MAX "$val"
    ui_msgbox "Сохранено" "TUNNEL_BOUNCE_MAX=$val"
}

edit_tunnel_settle_sec() {
    usb_watch_menu_ensure_vars
    val="$(ui_inputbox "VPN bounce: пауза после reload" \
"Секунд ждать handshake/маршрут после ifup перед повторным ping.
Текущий: ${USB_WATCH_TUNNEL_PROBE_SETTLE_SEC:-15}" \
"${USB_WATCH_TUNNEL_PROBE_SETTLE_SEC:-15}")" || return 0
    case "$val" in
        ''|*[!0-9]*)
            ui_msgbox "Ошибка" "Нужно целое число ≥ 0"
            return 0
            ;;
    esac
    usb_watch_conf_set "$(usb_watch_conf_path)" TUNNEL_PROBE_SETTLE_SEC "$val"
    ui_msgbox "Сохранено" "TUNNEL_PROBE_SETTLE_SEC=$val"
}

proton_guest_renew_ui_lib() {
    _lib="$ROOT_DIR/iface-routing/vpn/lib/proton-guest-renew.sh"
    [ -f "$_lib" ] || return 1
    # shellcheck disable=SC1090
    . "$_lib"
}

edit_proton_guest_renew() {
    usb_watch_menu_ensure_vars
    _cur="$(printf '%s' "${USB_WATCH_PROTON_GUEST_RENEW:-expiry}" | tr '[:upper:]' '[:lower:]' | tr -d '\r')"
    case "$_cur" in
        expiry|tunnel-fail|both|off) ;;
        expired|on-expiry|cert|ttl) _cur=expiry ;;
        fail|probe-fail|on-fail) _cur=tunnel-fail ;;
        all|on) _cur=both ;;
        *) _cur=expiry ;;
    esac
    USB_WATCH_PROTON_GUEST_RENEW="$_cur"
    UI_MENU_DEFAULT_ITEM="$_cur"
    export UI_MENU_DEFAULT_ITEM
    choice="$(ui_menu "Proton: пересоздание .conf" \
"Глобальный режим (не привязан к одному iface).
Guest: новая сессия + .conf (как WARP). Web: только с ещё живыми AUTH/REFRESH cookies (не просто файлы).
Импортированный .conf без сессии не пересоздаётся.
По умолчанию: expiry (пересборка guest-.conf до истечения сертификата, skew 10 мин). Сейчас: $_cur" 18 78 8 \
        "off" "Выкл." \
        "expiry" "По сроку сертификата (expiry)" \
        "tunnel-fail" "При отказе туннеля (tunnel-fail)" \
        "both" "Оба режима (both)" \
        "0" "Назад" || true)"
    unset UI_MENU_DEFAULT_ITEM
    choice="$(printf '%s' "${choice:-}" | tr -d '\r' | tr '[:upper:]' '[:lower:]')"
    [ -n "${choice:-}" ] || return 0
    case "$choice" in
        0) return 0 ;;
        off|1) val="off" ;;
        expiry|expired|2) val="expiry" ;;
        tunnel-fail|3) val="tunnel-fail" ;;
        both|4) val="both" ;;
        *) return 0 ;;
    esac
    usb_watch_conf_set "$(usb_watch_conf_path)" PROTON_GUEST_RENEW "$val"
    USB_WATCH_PROTON_GUEST_RENEW="$val"
    usb_watch_menu_ensure_vars
    ui_msgbox "Сохранено" "PROTON_GUEST_RENEW=${USB_WATCH_PROTON_GUEST_RENEW:-$val}

Пункт 16 в списке настроек должен показать ($USB_WATCH_PROTON_GUEST_RENEW)."
}

run_proton_guest_renew_now() {
    usb_watch_menu_ensure_vars
    proton_guest_renew_ui_lib || {
        ui_msgbox "Ошибка" "Не найдена библиотека proton-guest-renew.sh"
        return 0
    }
    _list="$(proton_guest_renew_list_guest_ifaces || true)"
    [ -n "$_list" ] || {
        ui_msgbox "Proton" "Нет guest-интерфейсов и нет Proton с ещё живой web-сессией (непросроченные AUTH/REFRESH cookies)."
        return 0
    }
    _n="$(printf '%s\n' "$_list" | sed '/^$/d' | wc -l | tr -d ' ')"
    target=""
    if [ "$_n" = "1" ]; then
        target="$(printf '%s\n' "$_list" | sed '/^$/d' | head -n1)"
        ui_confirm "Пересоздать Proton .conf" "Интерфейс: $target

Guest: новая сессия и новый .conf (как WARP). Web: refresh API; мёртвые cookies — skip." || return 0
    else
        set --
        while IFS= read -r _if; do
            [ -n "$_if" ] || continue
            set -- "$@" "$_if" "$(proton_guest_renew_marker_line "$_if")"
        done <<EOF
$_list
EOF
        set -- "$@" "0" "Назад"
        target="$(ui_menu "Какой Proton .conf пересоздать" "Метка: auth / session / срок cert" 18 78 12 "$@" || true)"
        [ -n "${target:-}" ] && [ "$target" != "0" ] || return 0
    fi
    run_log "Proton renew $target" sh "$ROOT_DIR/iface-routing/vpn/proton/renew-guest-iface.sh" --iface "$target"
}

settings_menu() {
    while true; do
        usb_watch_menu_ensure_vars
        usb_watch_normalize_probe_interval
        choice="$(ui_menu "Настройки мониторинга" \
"1–5 uplink · 6–11 USB · 14–18 VPN / Proton · cron ${USB_WATCH_INTERVAL_MIN}м" 30 78 20 \
            "1" "Проверка uplink: интерфейс (lte / L2 / auto)" \
            "2" "Проверка uplink: базовый адрес (ya.ru / свой)" \
            "3" "Проверка uplink: доп. адрес (полный интернет)" \
            "4" "Проверка uplink: период cron (${USB_WATCH_INTERVAL_MIN} мин)" \
            "5" "Проверка uplink: интервал probe (${USB_WATCH_PROBE_INTERVAL_SEC} с)" \
            "6" "Порог outage uplink (${USB_WATCH_FAIL_MAX}): USB + recovery" \
            "7" "USB power-cycle: макс. попыток (${USB_WATCH_CYCLE_MAX})" \
            "8" "USB power-cycle: пауза после (${USB_WATCH_SETTLE_SEC} с)" \
            "9" "USB power-cycle: выкл. USB ${USB_WATCH_OFF_SEC} с (OFF)" \
            "10" "USB power-cycle: вкл. USB, ждать ${USB_WATCH_ON_SEC} с (ON)" \
            "11" "USB power-cycle: сброс блокировки" \
            "12" "Сброс состояния и очистка conf" \
            "13" "Вкл/выкл мониторинг (сейчас: ${USB_WATCH_ENABLED})" \
            "14" "VPN: порог FAIL до restart (${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-3})" \
            "15" "VPN: макс. restart (${USB_WATCH_TUNNEL_BOUNCE_MAX:-3})" \
            "16" "VPN: settle после restart (${USB_WATCH_TUNNEL_PROBE_SETTLE_SEC:-15} с)" \
            "17" "Proton: авто-пересоздание .conf (${USB_WATCH_PROTON_GUEST_RENEW:-expiry})" \
            "18" "Proton: пересоздать .conf сейчас" \
            "0" "Назад" || true)"
        [ -n "${choice:-}" ] || return 0
        case "$choice" in
            0) return 0 ;;
            1) edit_probe_iface ;;
            2) edit_test_url ;;
            3) edit_test_url_alt ;;
            4) edit_interval ;;
            5) edit_probe_interval ;;
            6) edit_fail_max ;;
            7) edit_cycle_max ;;
            8) edit_settle_sec ;;
            9) edit_off_sec ;;
            10) edit_on_sec ;;
            11) reset_cycle_lock_confirm ;;
            12) reset_monitor_storage_confirm ;;
            13) toggle_enabled ;;
            14) edit_tunnel_icmp_fail_max ;;
            15) edit_tunnel_bounce_max ;;
            16) edit_tunnel_settle_sec ;;
            17) edit_proton_guest_renew ;;
            18) run_proton_guest_renew_now ;;
        esac
    done
}
