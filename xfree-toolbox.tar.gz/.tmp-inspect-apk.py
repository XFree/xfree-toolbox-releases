#!/usr/bin/env python3
import gzip
import io
import tarfile
from pathlib import Path

apk = Path("dist/xfree-toolbox-0.1.6-r15.apk")
data = apk.read_bytes()
offset = 0
streams = []
while offset < len(data):
    if data[offset : offset + 2] != b"\x1f\x8b":
        nxt = data.find(b"\x1f\x8b", offset + 1)
        if nxt < 0:
            break
        offset = nxt
        continue
    bio = io.BytesIO(data[offset:])
    try:
        with gzip.GzipFile(fileobj=bio) as gz:
            payload = gz.read()
        streams.append(payload)
        offset += bio.tell()
    except Exception:
        offset += 1

print(f"apk streams: {len(streams)} sizes={[len(s) for s in streams]}")
for i, s in enumerate(streams):
    try:
        tf = tarfile.open(fileobj=io.BytesIO(s), mode="r:")
    except Exception as e:
        print(f"stream[{i}] not tar: {e}")
        continue
    names = tf.getnames()
    hits = [
        n
        for n in names
        if "user__group__xft" in n
        or n.endswith("VERSION")
        or ("dns.google" in n and n.endswith(".lst"))
        or n.endswith("BUILD-META.txt")
        or n.endswith(".PKGINFO")
    ]
    print(f"stream[{i}] members={len(names)} hits={len(hits)}")
    for h in hits[:50]:
        print(" ", h)
        if h.endswith("VERSION") or h.endswith("BUILD-META.txt") or h.endswith(".PKGINFO"):
            f = tf.extractfile(h)
            if f:
                print(f.read().decode(errors="replace")[:500])
