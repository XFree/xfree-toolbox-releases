#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
ROOT_DIR=/root/xfree-toolbox
export ROOT_DIR
. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/zapret/lib.sh"

echo "sections=$(zapret_sections_root)"
src="$(zapret_sections_root)/youtube_29/fqdn.d"
dst="$ZAPRET_STATE_DIR/sections/youtube_29/fqdn.d"
echo "profile lst:"; ls -la "$src" || echo MISSING_PROFILE
# Check if generate wiped PROFILE
if [ ! -f "$src/user__service__zapret__google__fqdn.lst" ]; then
  echo 'PROFILE LIST MISSING — restore from? checking backups'
  ls /etc/xfree-toolbox/backups/zapret/*google* 2>/dev/null | tail -5 || true
fi

# Instrument: wrap sync
echo '=== sync once ==='
common_sync_dir_mirror "$src" "$dst"
echo "state after:"; ls -la "$dst"

echo '=== call real apply generate with debug around youtube_29 ==='
# Patch: run generate_zapret_targets by invoking apply with a tracer
# Insert debug by running the loop body for youtube_29 only via sh -c from apply functions

# Source apply.sh functions only - apply.sh executes main at end, so don't source it.
# Instead run apply with strace? too heavy.

# Manual: replicate exact generate steps for youtube_29
section=youtube_29
zapret_load_section_conf "$section"
echo "ENABLED=$ZAPRET_SECTION_ENABLED HOST_FILE=$ZAPRET_SECTION_HOST_FILE"
section_dir="$(zapret_sections_root)/$section"
state_section_dir="$ZAPRET_STATE_DIR/sections/$section"
echo "section_dir=$section_dir"
echo "state_section_dir=$state_section_dir"
mkdir -p "$state_section_dir/config" "$state_section_dir/fqdn.d"
common_sync_dir_mirror "$section_dir/config" "$state_section_dir/config"
common_sync_dir_mirror "$section_dir/fqdn.d" "$state_section_dir/fqdn.d"
echo "after sync state fqdn:"; ls -la "$state_section_dir/fqdn.d"
echo "after sync profile fqdn:"; ls -la "$section_dir/fqdn.d"

# Inline build_merged without trap bug
tmp=$(mktemp)
for f in "$state_section_dir/fqdn.d"/*.lst; do
  [ -f "$f" ] || continue
  echo "norm $f"
  cat "$f" | common_norm_domains_stream >> "$tmp"
done
echo "tmp lines=$(wc -l <"$tmp")"
head -2 "$tmp"
rm -f "$tmp"

# Now run the ACTUAL build_merged_file from apply by extracting it
# Critical: does trap in build_merged wipe something?

# Show type of find on this device
echo '=== find vs ls after DISABLED section sync simulation ==='
# Simulate what happens for youtube_28 (disabled) then youtube_29
# For disabled: sync still runs, then continue
for section in youtube_28 youtube_29; do
  zapret_load_section_conf "$section"
  section_dir="$(zapret_sections_root)/$section"
  state_section_dir="$ZAPRET_STATE_DIR/sections/$section"
  mkdir -p "$state_section_dir/config" "$state_section_dir/fqdn.d" "$state_section_dir/prefixes.d" "$state_section_dir/fqdn.exclude.d"
  echo ">> $section ENABLED=$ZAPRET_SECTION_ENABLED"
  echo "   profile fqdn count: $(ls "$section_dir/fqdn.d"/*.lst 2>/dev/null | wc -l)"
  common_sync_dir_mirror "$section_dir/config" "$state_section_dir/config"
  common_sync_dir_mirror "$section_dir/fqdn.d" "$state_section_dir/fqdn.d"
  common_sync_dir_mirror "$section_dir/prefixes.d" "$state_section_dir/prefixes.d"
  common_sync_dir_mirror "$section_dir/fqdn.exclude.d" "$state_section_dir/fqdn.exclude.d"
  echo "   state fqdn count: $(ls "$state_section_dir/fqdn.d"/*.lst 2>/dev/null | wc -l)"
  echo "   profile fqdn count after: $(ls "$section_dir/fqdn.d"/*.lst 2>/dev/null | wc -l)"
done
REMOTE
