#!/bin/sh
# Telemt MTProxy status and update checker.
# Outputs key=value properties or human-readable diagnostics.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1090
[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"

CHECK_UPDATES=0
JSON_OUTPUT=0
HUMAN=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --check-updates) CHECK_UPDATES=1 ;;
    --json) JSON_OUTPUT=1 ;;
    --human) HUMAN=1 ;;
    -h|--help)
      echo "Usage: $0 [--check-updates] [--json] [--human]"
      exit 0
      ;;
    *)
      break
      ;;
  esac
  shift
done

# 1. Process status & PID
running=0
pid=""
if command -v pidof >/dev/null 2>&1; then
  pid="$(pidof telemt 2>/dev/null || true)"
elif command -v pgrep >/dev/null 2>&1; then
  pid="$(pgrep -x telemt 2>/dev/null || true)"
fi
if [ -n "$pid" ]; then
  running=1
fi

# 2. Service autostart
enabled=0
if [ -x /etc/init.d/telemt ]; then
  if /etc/init.d/telemt enabled >/dev/null 2>&1; then
    enabled=1
  fi
fi

# 3. Installed package versions
core_installed=0
core_ver=""
if command -v telemt >/dev/null 2>&1; then
  core_installed=1
  core_ver="$(telemt --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || true)"
fi
if [ -z "$core_ver" ]; then
  if command -v apk >/dev/null 2>&1; then
    core_ver="$(apk info -d telemt 2>/dev/null | grep -E '^telemt-[0-9]' | sed 's/^telemt-//' | cut -d- -f1 || true)"
    [ -n "$core_ver" ] && core_installed=1
  elif command -v opkg >/dev/null 2>&1; then
    core_ver="$(opkg list-installed 2>/dev/null | grep '^telemt ' | awk '{print $3}' || true)"
    [ -n "$core_ver" ] && core_installed=1
  fi
fi

luci_installed=0
luci_ver=""
if command -v apk >/dev/null 2>&1; then
  luci_ver="$(apk list -I luci-app-telemt 2>/dev/null | awk '/^luci-app-telemt-[0-9]/ { sub(/^luci-app-telemt-/, ""); print $1; exit }' || true)"
  [ -z "$luci_ver" ] && luci_ver="$(apk info -d luci-app-telemt 2>/dev/null | awk '/^luci-app-telemt-[0-9]/ { sub(/^luci-app-telemt-/, ""); print $1; exit }' || true)"
  [ -n "$luci_ver" ] && luci_installed=1
elif command -v opkg >/dev/null 2>&1; then
  luci_ver="$(opkg list-installed 2>/dev/null | grep '^luci-app-telemt ' | awk '{print $3}' || true)"
  [ -z "$luci_ver" ] && luci_ver="$(opkg status luci-app-telemt 2>/dev/null | awk '/^Version: / { print $2; exit }' || true)"
  [ -n "$luci_ver" ] && luci_installed=1
fi

# 4. Configuration (port, secret, host, tls domain)
port=""
tls_domain=""

if command -v uci >/dev/null 2>&1 && [ -f /etc/config/telemt ]; then
  port="$(uci get telemt.general.public_port 2>/dev/null || uci get telemt.general.port 2>/dev/null || uci get telemt.main.port 2>/dev/null || uci get telemt.@telemt[0].port 2>/dev/null || true)"
  tls_domain="$(uci get telemt.general.domain 2>/dev/null || true)"
fi

if [ -z "$port" ] && [ -f /var/etc/telemt.toml ]; then
  port="$(awk -F= '/^[[:space:]]*public_port[[:space:]]*=/ { gsub(/[[:space:]]/, "", $2); print $2; exit }' /var/etc/telemt.toml 2>/dev/null || true)"
  [ -z "$port" ] && port="$(awk -F= '/^[[:space:]]*port[[:space:]]*=/ { gsub(/[[:space:]]/, "", $2); print $2; exit }' /var/etc/telemt.toml 2>/dev/null || true)"
fi
if [ -z "$port" ] && [ -f /etc/telemt.toml ]; then
  port="$(grep -E '^[[:space:]]*port[[:space:]]*=' /etc/telemt.toml 2>/dev/null | head -n1 | tr -dc '0-9' || true)"
fi
[ -z "$port" ] && port="8443"

if [ -z "$tls_domain" ] && [ -f /var/etc/telemt.toml ]; then
  tls_domain="$(awk -F= '/^[[:space:]]*tls_domain[[:space:]]*=/ { gsub(/[[:space:]"]/, "", $2); print $2; exit }' /var/etc/telemt.toml 2>/dev/null || true)"
fi

# Host / WAN resolution for TG link
host=""
if command -v uci >/dev/null 2>&1 && [ -f /etc/config/telemt ]; then
  host="$(uci get telemt.general.external_ip 2>/dev/null || true)"
fi
if [ -z "$host" ] && [ -f /var/etc/telemt.toml ]; then
  host="$(awk -F= '/^[[:space:]]*public_host[[:space:]]*=/ { gsub(/[[:space:]"]/, "", $2); print $2; exit }' /var/etc/telemt.toml 2>/dev/null || true)"
fi
if [ -z "$host" ] && command -v ubus >/dev/null 2>&1; then
  host="$(ubus call network.interface.wan status 2>/dev/null | awk -F'"' '/"address":/ { print $4; exit }' || true)"
fi
if [ -z "$host" ] && command -v uci >/dev/null 2>&1; then
  host="$(uci get system.@system[0].hostname 2>/dev/null || true)"
fi
if [ -z "$host" ]; then
  host="$(hostname 2>/dev/null || echo 'router.lan')"
fi

# Hex encode TLS domain once for client fake-TLS secrets
domain_hex=""
if [ -n "$tls_domain" ]; then
  if command -v hexdump >/dev/null 2>&1; then
    domain_hex="$(printf '%s' "$tls_domain" | hexdump -ve '1/1 "%.2x"' 2>/dev/null || true)"
  fi
fi

mask_secret() {
  local s="$1"
  local slen="${#s}"
  if [ "$slen" -gt 8 ]; then
    printf '%s****%s' "$(printf '%s' "$s" | cut -c 1-4)" "$(printf '%s' "$s" | cut -c "$((slen - 3))"-"$slen")"
  else
    printf '****'
  fi
}

make_tg_link() {
  local s="$1"
  [ -z "$s" ] || [ -z "$port" ] || [ -z "$host" ] && return 0
  local cl_sec="$s"
  case "$s" in
    ee*) ;;
    *)
      [ -n "$domain_hex" ] && cl_sec="ee${s}${domain_hex}"
      ;;
  esac
  printf 'tg://proxy?server=%s&port=%s&secret=%s' "$host" "$port" "$cl_sec"
}

user_count=0

# Parse users from UCI
if command -v uci >/dev/null 2>&1 && [ -f /etc/config/telemt ]; then
  for sec_name in $(uci show telemt 2>/dev/null | grep '=user$' | cut -d. -f2 | cut -d= -f1); do
    u_en="$(uci get "telemt.${sec_name}.enabled" 2>/dev/null || echo 1)"
    u_sec="$(uci get "telemt.${sec_name}.secret" 2>/dev/null || true)"
    [ -z "$u_sec" ] && continue
    u_disp_name="$(uci get "telemt.${sec_name}.name" 2>/dev/null || true)"
    [ -z "$u_disp_name" ] && u_disp_name="$sec_name"
    u_comm="$(uci get "telemt.${sec_name}.comment" 2>/dev/null || true)"

    user_count=$((user_count + 1))
    eval "u_${user_count}_name=\"\$u_disp_name\""
    eval "u_${user_count}_enabled=\"\$u_en\""
    eval "u_${user_count}_secret=\"\$u_sec\""
    eval "u_${user_count}_secret_masked=\"\$(mask_secret \"\$u_sec\")\""
    eval "u_${user_count}_link=\"\$(make_tg_link \"\$u_sec\")\""
    eval "u_${user_count}_comment=\"\$u_comm\""
  done
fi

# Fallback to toml files if UCI had no users
if [ "$user_count" -eq 0 ] && [ -f /var/etc/telemt.toml ]; then
  u_toml_lines="$(awk '
    BEGIN { in_users = 0 }
    /^\[users\]/ { in_users = 1; next }
    /^\[/ { in_users = 0 }
    in_users && /^[[:space:]]*[a-zA-Z0-9_-]+[[:space:]]*=/ {
      split($0, a, "=")
      gsub(/[[:space:]]/, "", a[1])
      gsub(/[[:space:]"]/, "", a[2])
      if (length(a[1]) > 0 && length(a[2]) > 0) {
        print a[1] "|" a[2]
      }
    }
  ' /var/etc/telemt.toml 2>/dev/null || true)"

  for line in $u_toml_lines; do
    t_name="$(printf '%s' "$line" | cut -d'|' -f1)"
    t_sec="$(printf '%s' "$line" | cut -d'|' -f2)"
    [ -z "$t_sec" ] && continue

    user_count=$((user_count + 1))
    eval "u_${user_count}_name=\"\$t_name\""
    eval "u_${user_count}_enabled=\"1\""
    eval "u_${user_count}_secret=\"\$t_sec\""
    eval "u_${user_count}_secret_masked=\"\$(mask_secret \"\$t_sec\")\""
    eval "u_${user_count}_link=\"\$(make_tg_link \"\$t_sec\")\""
    eval "u_${user_count}_comment=\"\""
  done
fi

if [ "$user_count" -eq 0 ] && [ -f /etc/telemt.toml ]; then
  single_sec="$(grep -E '^[[:space:]]*secret[[:space:]]*=' /etc/telemt.toml 2>/dev/null | head -n1 | cut -d= -f2- | tr -d ' "' || true)"
  if [ -n "$single_sec" ]; then
    user_count=1
    u_1_name="default"
    u_1_enabled="1"
    u_1_secret="$single_sec"
    u_1_secret_masked="$(mask_secret "$single_sec")"
    u_1_link="$(make_tg_link "$single_sec")"
    u_1_comment=""
  fi
fi

# Backward-compatibility fallback: pick first active user for legacy secret and tg_link
secret=""
secret_masked=""
tg_link=""
i=1
while [ "$i" -le "$user_count" ]; do
  eval "c_en=\"\$u_${i}_enabled\""
  eval "c_sec=\"\$u_${i}_secret\""
  eval "c_mask=\"\$u_${i}_secret_masked\""
  eval "c_link=\"\$u_${i}_link\""
  if [ "$c_en" = "1" ] && [ -n "$c_sec" ]; then
    secret="$c_sec"
    secret_masked="$c_mask"
    tg_link="$c_link"
    break
  fi
  i=$((i + 1))
done

if [ -z "$secret" ] && [ "$user_count" -gt 0 ]; then
  eval "secret=\"\$u_1_secret\""
  eval "secret_masked=\"\$u_1_secret_masked\""
  eval "tg_link=\"\$u_1_link\""
fi

# 5. Remote updates resolution (optional)
core_latest=""
core_upd=0
luci_latest=""
luci_upd=0
upd_avail=0

if [ "$CHECK_UPDATES" = "1" ] && [ -f "$SCRIPT_DIR/resolve-telemt-release.sh" ]; then
  updates_env="$(sh "$SCRIPT_DIR/resolve-telemt-release.sh" --check-updates 2>/dev/null || true)"
  if [ -n "$updates_env" ]; then
    c_lat="$(printf '%s\n' "$updates_env" | grep '^core_latest_ver=' | cut -d= -f2- | tr -d '"')"
    l_lat="$(printf '%s\n' "$updates_env" | grep '^luci_latest_ver=' | cut -d= -f2- | tr -d '"')"
    c_u="$(printf '%s\n' "$updates_env" | grep '^core_update_available=' | cut -d= -f2- | tr -d '"')"
    l_u="$(printf '%s\n' "$updates_env" | grep '^luci_update_available=' | cut -d= -f2- | tr -d '"')"
    tot_u="$(printf '%s\n' "$updates_env" | grep '^update_available=' | cut -d= -f2- | tr -d '"')"

    [ -n "$c_lat" ] && core_latest="$c_lat"
    [ -n "$l_lat" ] && luci_latest="$l_lat"
    [ "$c_u" = "1" ] && core_upd=1
    [ "$l_u" = "1" ] && luci_upd=1
    [ "$tot_u" = "1" ] && upd_avail=1
  fi
fi

# 6. Output formatting
if [ "$JSON_OUTPUT" = "1" ]; then
  printf '{\n'
  printf '  "running": %s,\n' "$([ "$running" = "1" ] && echo "true" || echo "false")"
  printf '  "pid": "%s",\n' "$pid"
  printf '  "enabled": %s,\n' "$([ "$enabled" = "1" ] && echo "true" || echo "false")"
  printf '  "core_installed": %s,\n' "$([ "$core_installed" = "1" ] && echo "true" || echo "false")"
  printf '  "core_version": "%s",\n' "$core_ver"
  printf '  "core_latest_version": "%s",\n' "$core_latest"
  printf '  "core_update_available": %s,\n' "$([ "$core_upd" = "1" ] && echo "true" || echo "false")"
  printf '  "luci_installed": %s,\n' "$([ "$luci_installed" = "1" ] && echo "true" || echo "false")"
  printf '  "luci_version": "%s",\n' "$luci_ver"
  printf '  "luci_latest_version": "%s",\n' "$luci_latest"
  printf '  "luci_update_available": %s,\n' "$([ "$luci_upd" = "1" ] && echo "true" || echo "false")"
  printf '  "update_available": %s,\n' "$([ "$upd_avail" = "1" ] && echo "true" || echo "false")"
  printf '  "port": "%s",\n' "$port"
  printf '  "secret": "%s",\n' "$secret"
  printf '  "secret_masked": "%s",\n' "$secret_masked"
  printf '  "host": "%s",\n' "$host"
  printf '  "tg_link": "%s",\n' "$tg_link"
  printf '  "user_count": %s,\n' "$user_count"
  printf '  "users": ['
  i=1
  while [ "$i" -le "$user_count" ]; do
    eval "p_name=\"\$u_${i}_name\""
    eval "p_en=\"\$u_${i}_enabled\""
    eval "p_sec=\"\$u_${i}_secret\""
    eval "p_mask=\"\$u_${i}_secret_masked\""
    eval "p_link=\"\$u_${i}_link\""
    eval "p_comm=\"\$u_${i}_comment\""
    [ "$i" -gt 1 ] && printf ','
    printf '\n    {"name": "%s", "enabled": %s, "secret": "%s", "secret_masked": "%s", "link": "%s", "comment": "%s"}' \
      "$p_name" "$([ "$p_en" = "1" ] && echo "true" || echo "false")" "$p_sec" "$p_mask" "$p_link" "$p_comm"
    i=$((i + 1))
  done
  [ "$user_count" -gt 0 ] && printf '\n  '
  printf ']\n'
  printf '}\n'
  exit 0
fi

# Standard KEY=VALUE lines
printf 'running=%s\n' "$running"
printf 'pid=%s\n' "$pid"
printf 'enabled=%s\n' "$enabled"
printf 'core_installed=%s\n' "$core_installed"
printf 'core_version=%s\n' "$core_ver"
printf 'core_latest_version=%s\n' "$core_latest"
printf 'core_update_available=%s\n' "$core_upd"
printf 'luci_installed=%s\n' "$luci_installed"
printf 'luci_version=%s\n' "$luci_ver"
printf 'luci_latest_version=%s\n' "$luci_latest"
printf 'luci_update_available=%s\n' "$luci_upd"
printf 'update_available=%s\n' "$upd_avail"
printf 'port=%s\n' "$port"
printf 'secret=%s\n' "$secret"
printf 'secret_masked=%s\n' "$secret_masked"
printf 'host=%s\n' "$host"
printf 'tg_link=%s\n' "$tg_link"
printf 'user_count=%s\n' "$user_count"

i=1
while [ "$i" -le "$user_count" ]; do
  eval "p_name=\"\$u_${i}_name\""
  eval "p_en=\"\$u_${i}_enabled\""
  eval "p_sec=\"\$u_${i}_secret\""
  eval "p_mask=\"\$u_${i}_secret_masked\""
  eval "p_link=\"\$u_${i}_link\""
  eval "p_comm=\"\$u_${i}_comment\""
  printf 'user_%s_name=%s\n' "$i" "$p_name"
  printf 'user_%s_enabled=%s\n' "$i" "$p_en"
  printf 'user_%s_secret=%s\n' "$i" "$p_sec"
  printf 'user_%s_secret_masked=%s\n' "$i" "$p_mask"
  printf 'user_%s_link=%s\n' "$i" "$p_link"
  printf 'user_%s_comment=%s\n' "$i" "$p_comm"
  i=$((i + 1))
done

if [ "$HUMAN" = "1" ]; then
  echo ""
  echo "--- Telemt MTProxy Status ---"
  if [ "$running" = "1" ]; then
    echo "  Статус: Работает (PID: $pid, порт: $port)"
  elif [ "$core_installed" = "1" ]; then
    echo "  Статус: Остановлен (порт: $port)"
  else
    echo "  Статус: Не установлен"
  fi
  echo "  Core (демон) : ${core_ver:-не установлен}$([ "$core_upd" = "1" ] && echo " -> доступно $core_latest" || true)"
  echo "  LuCI (веб-UI): ${luci_ver:-не установлен}$([ "$luci_upd" = "1" ] && echo " -> доступно $luci_latest" || true)"
  [ -n "$tg_link" ] && echo "  Ссылка TG    : $tg_link"
  if [ "$user_count" -gt 0 ]; then
    echo "  Пользователи ($user_count):"
    i=1
    while [ "$i" -le "$user_count" ]; do
      eval "p_name=\"\$u_${i}_name\""
      eval "p_en=\"\$u_${i}_enabled\""
      eval "p_mask=\"\$u_${i}_secret_masked\""
      eval "p_link=\"\$u_${i}_link\""
      echo "    - $p_name ($([ "$p_en" = "1" ] && echo "включен" || echo "отключен")): $p_mask"
      [ -n "$p_link" ] && echo "      $p_link"
      i=$((i + 1))
    done
  fi
fi
