#!/bin/sh
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." 2>/dev/null && pwd -P)"
COMMON_CANDIDATES="
$ROOT_DIR/lib/common.sh
$SCRIPT_DIR/../lib/common.sh
$SCRIPT_DIR/lib/common.sh
$SCRIPT_DIR/common.sh
"
COMMON_SH=""
for p in $COMMON_CANDIDATES; do
  [ -f "$p" ] && COMMON_SH="$p" && break
done
[ -n "$COMMON_SH" ] || {
  printf '[-] common.sh not found near %s\n' "$0" >&2
  exit 1
}
# shellcheck disable=SC1090
. "$COMMON_SH"
# shellcheck disable=SC1090
. "$SCRIPT_DIR/config.sh"
# shellcheck disable=SC1090
. "$SCRIPT_DIR/lib-install-pkg.sh"

PKG_MGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
[ -f "$PKG_MGR_SH" ] || die "Не найден pkgmgr.sh: $PKG_MGR_SH"
# shellcheck disable=SC1090
. "$PKG_MGR_SH"

DOWNLOADER="$SCRIPT_DIR/download-telemt-release.sh"
[ -x "$DOWNLOADER" ] || [ -f "$DOWNLOADER" ] || die "Downloader not found: $DOWNLOADER"

RESOLVER="$SCRIPT_DIR/resolve-telemt-release.sh"
[ -x "$RESOLVER" ] || [ -f "$RESOLVER" ] || die "Resolver not found: $RESOLVER"

LUCI_TAG=""
DIR="$TELEMT_DOWNLOAD_DIR"
KEEP=0
DEBUG="${DEBUG:-1}"
SHOW_REASON=0
FORCE=0

while [ $# -gt 0 ]; do
  case "$1" in
    --luci-tag|--tag)
      shift
      [ $# -gt 0 ] || die "--luci-tag requires value"
      LUCI_TAG="$1"
      ;;
    --dir|--download-dir)
      shift
      [ $# -gt 0 ] || die "$1 requires value"
      DIR="$1"
      ;;
    --keep) KEEP=1 ;;
    --force) FORCE=1 ;;
    --show-reason) SHOW_REASON=1 ;;
    --no-debug) DEBUG=0 ;;
    *) die "Unknown argument: $1" ;;
  esac
  shift
done

info "Скачиваю релиз Telemt"
if [ "$SHOW_REASON" = "1" ]; then
  "$DOWNLOADER" ${LUCI_TAG:+--luci-tag "$LUCI_TAG"} --dir "$DIR" --show-reason
  resolver_out="$("$RESOLVER" --emit-shell ${LUCI_TAG:+--luci-tag "$LUCI_TAG"} --show-reason)" \
    || die "Не удалось определить порядок установки Telemt"
else
  "$DOWNLOADER" ${LUCI_TAG:+--luci-tag "$LUCI_TAG"} --dir "$DIR"
  resolver_out="$("$RESOLVER" --emit-shell ${LUCI_TAG:+--luci-tag "$LUCI_TAG"})" \
    || die "Не удалось определить порядок установки Telemt"
fi

eval "$resolver_out"

[ -n "$TELEMT_FILES" ] || die "Резолвер не вернул список пакетов для установки"

case "$PM" in
  apk) PKG_EXT="apk" ;;
  opkg) PKG_EXT="ipk" ;;
  *) die "Неизвестный менеджер пакетов: $PM" ;;
esac

pm_update_index_optional

pkg_name_from_file() {
  case "$(basename -- "$1")" in
    telemt_*) printf '%s\n' "telemt" ;;
    luci-app-telemt_*) printf '%s\n' "luci-app-telemt" ;;
    *) printf '%s\n' "" ;;
  esac
}

install_one() {
  f="$1"
  [ -f "$f" ] || die "Файл пакета не найден: $f"
  info "Устанавливаю: $(basename -- "$f")"
  if [ "$PM" = "apk" ] && [ "$FORCE" != "1" ]; then
    pkg="$(pkg_name_from_file "$f")"
    if [ -n "${pkg:-}" ] && command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed "$pkg"; then
      say "[=] Уже установлен: $pkg (пропуск; для переустановки используйте --force)"
      return 0
    fi
  fi
  telemt_pm_install_file "$f" || die "Не удалось установить: $f"
}

info "Устанавливаю пакеты ($PKG_EXT), порядок: core → luci"
found=0
installed_count=0
for file in $TELEMT_FILES; do
  [ -n "$file" ] || continue
  found=1
  install_one "$DIR/$file"
  installed_count=$((installed_count + 1))
done

[ "$found" = "1" ] || die "Пакеты для установки не найдены в: $DIR"

if [ "$installed_count" -gt 0 ] 2>/dev/null; then
  if [ -x /etc/init.d/telemt ]; then
    info "Перезапускаю telemt после установки"
    /etc/init.d/telemt restart || warn "Не удалось перезапустить telemt"
  else
    warn "init script telemt не найден; включите сервис вручную после настройки UCI"
  fi
fi

if [ "$KEEP" != "1" ]; then
  info "Очищаю каталог загрузки: $DIR"
  rm -f "$DIR"/*."$PKG_EXT" 2>/dev/null || true
fi

success "Установка Telemt завершена (core $CORE_TAG, luci $LUCI_TAG)"
