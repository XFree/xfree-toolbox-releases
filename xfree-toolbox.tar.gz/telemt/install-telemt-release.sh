#!/bin/sh
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." 2>/dev/null && pwd -P)"
COMMON_CANDIDATES="
$ROOT_DIR/lib/common.sh
$SCRIPT_DIR/../lib/common.sh
$SCRIPT_DIR/lib/common.sh
$SCRIPT_DIR/common.sh
"
COMMON_SH=""
for p in $COMMON_CANDIDATES; do
  [ -f "$p" ] && COMMON_SH="$p" && break
done
[ -n "$COMMON_SH" ] || {
  printf '[-] common.sh not found near %s\n' "$0" >&2
  exit 1
}
# shellcheck disable=SC1090
. "$COMMON_SH"
# shellcheck disable=SC1090
. "$SCRIPT_DIR/config.sh"
# shellcheck disable=SC1090
. "$SCRIPT_DIR/lib-install-pkg.sh"

PKG_MGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
[ -f "$PKG_MGR_SH" ] || die "Не найден pkgmgr.sh: $PKG_MGR_SH"
# shellcheck disable=SC1090
. "$PKG_MGR_SH"

DOWNLOADER="$SCRIPT_DIR/download-telemt-release.sh"
[ -x "$DOWNLOADER" ] || [ -f "$DOWNLOADER" ] || die "Downloader not found: $DOWNLOADER"

RESOLVER="$SCRIPT_DIR/resolve-telemt-release.sh"
[ -x "$RESOLVER" ] || [ -f "$RESOLVER" ] || die "Resolver not found: $RESOLVER"

LUCI_TAG=""
CORE_TAG=""
DIR="$TELEMT_DOWNLOAD_DIR"
KEEP=0
DEBUG="${DEBUG:-1}"
SHOW_REASON=0
FORCE=0
UPGRADE=0

while [ $# -gt 0 ]; do
  case "$1" in
    --luci-tag|--tag)
      shift
      [ $# -gt 0 ] || die "--luci-tag requires value"
      LUCI_TAG="$1"
      ;;
    --core-tag)
      shift
      [ $# -gt 0 ] || die "--core-tag requires value"
      CORE_TAG="$1"
      ;;
    --dir|--download-dir)
      shift
      [ $# -gt 0 ] || die "$1 requires value"
      DIR="$1"
      ;;
    --keep) KEEP=1 ;;
    --force) FORCE=1 ;;
    --upgrade) UPGRADE=1 ;;
    --show-reason) SHOW_REASON=1 ;;
    --no-debug) DEBUG=0 ;;
    *) die "Unknown argument: $1" ;;
  esac
  shift
done

info "Скачиваю релиз Telemt"
dl_args=""
[ -n "$LUCI_TAG" ] && dl_args="$dl_args --luci-tag $LUCI_TAG"
[ -n "$CORE_TAG" ] && dl_args="$dl_args --core-tag $CORE_TAG"
[ "$SHOW_REASON" = "1" ] && dl_args="$dl_args --show-reason"

"$DOWNLOADER" $dl_args --dir "$DIR"
resolver_out="$("$RESOLVER" --emit-shell $dl_args)" \
  || die "Не удалось определить порядок установки Telemt"

eval "$resolver_out"

[ -n "$TELEMT_FILES" ] || die "Резолвер не вернул список пакетов для установки"

case "$PM" in
  apk) PKG_EXT="apk" ;;
  opkg) PKG_EXT="ipk" ;;
  *) die "Неизвестный менеджер пакетов: $PM" ;;
esac

pm_update_index_optional

pkg_name_from_file() {
  case "$(basename -- "$1")" in
    telemt_*) printf '%s\n' "telemt" ;;
    luci-app-telemt_*) printf '%s\n' "luci-app-telemt" ;;
    *) printf '%s\n' "" ;;
  esac
}

pkg_installed_version() {
  pkg="$1"
  if [ "$PM" = "apk" ]; then
    apk info -d "$pkg" 2>/dev/null | grep -E "^${pkg}-[0-9]" | sed "s/^${pkg}-//" | cut -d- -f1 || true
  else
    opkg list-installed 2>/dev/null | grep "^${pkg} " | awk '{print $3}' || true
  fi
}

install_one() {
  f="$1"
  [ -f "$f" ] || die "Файл пакета не найден: $f"
  pkg="$(pkg_name_from_file "$f")"
  file_ver="$(printf '%s' "$(basename -- "$f")" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || true)"
  
  info "Устанавливаю: $(basename -- "$f")"
  if [ -n "${pkg:-}" ] && [ "$FORCE" != "1" ] && [ "$UPGRADE" != "1" ]; then
    if command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed "$pkg"; then
      cur_ver="$(pkg_installed_version "$pkg")"
      if [ -n "$file_ver" ] && [ "$cur_ver" = "$file_ver" ]; then
        say "[=] Уже установлена актуальная версия: $pkg ($cur_ver) (пропуск; для переустановки используйте --force)"
        return 0
      elif [ -n "$cur_ver" ]; then
        info "Обновление $pkg: $cur_ver -> ${file_ver:-новая версия}"
      fi
    fi
  fi
  telemt_pm_install_file "$f" || die "Не удалось установить: $f"
}

# Защита от разрыва RPC-соединения: если скрипт запущен через LuCI/rpcd,
# прямой restart rpcd в post-install обрубает HTTP-сессию в браузере.
# Перехватываем restart на время установки и откладываем его на 3 секунды.
rpcd_shimmed=0
if [ -f /etc/init.d/rpcd ] && [ ! -f /tmp/rpcd.orig.telemt ]; then
  cp /etc/init.d/rpcd /tmp/rpcd.orig.telemt 2>/dev/null || true
  if [ -f /tmp/rpcd.orig.telemt ]; then
    cat <<'RPCD_SHIM' > /etc/init.d/rpcd
#!/bin/sh
case "$1" in
  restart|reload)
    ( sleep 3; /tmp/rpcd.orig.telemt restart >/dev/null 2>&1 ) &
    exit 0
    ;;
  *)
    exec /tmp/rpcd.orig.telemt "$@"
    ;;
esac
RPCD_SHIM
    chmod 0755 /etc/init.d/rpcd 2>/dev/null || true
    rpcd_shimmed=1
  fi
fi

restore_rpcd() {
  if [ "$rpcd_shimmed" = "1" ] && [ -f /tmp/rpcd.orig.telemt ]; then
    cp /tmp/rpcd.orig.telemt /etc/init.d/rpcd 2>/dev/null || true
    chmod 0755 /etc/init.d/rpcd 2>/dev/null || true
    rm -f /tmp/rpcd.orig.telemt 2>/dev/null || true
    rpcd_shimmed=0
  fi
}
trap restore_rpcd EXIT INT TERM

info "Устанавливаю пакеты ($PKG_EXT), порядок: core → luci"
found=0
installed_count=0
for file in $TELEMT_FILES; do
  [ -n "$file" ] || continue
  found=1
  install_one "$DIR/$file"
  installed_count=$((installed_count + 1))
done

restore_rpcd
trap - EXIT INT TERM

[ "$found" = "1" ] || die "Пакеты для установки не найдены в: $DIR"

if [ "$installed_count" -gt 0 ] 2>/dev/null; then
  if [ -f /etc/init.d/telemt ]; then
    if grep -q 'respawn 3600 30 0' /etc/init.d/telemt 2>/dev/null; then
      info "Патчу respawn в /etc/init.d/telemt (3600 60 5 вместо бесконечного)"
      sed -i 's/respawn 3600 30 0/respawn 3600 60 5/' /etc/init.d/telemt 2>/dev/null || true
    fi
  fi
  if [ -x /etc/init.d/telemt ]; then
    info "Перезапускаю telemt после установки"
    /etc/init.d/telemt restart || warn "Не удалось перезапустить telemt"
  else
    warn "init script telemt не найден; включите сервис вручную после настройки UCI"
  fi
fi

if [ "$KEEP" != "1" ]; then
  info "Очищаю каталог загрузки: $DIR"
  rm -f "$DIR"/*."$PKG_EXT" 2>/dev/null || true
fi

success "Установка Telemt завершена (core $CORE_TAG, luci $LUCI_TAG)"
