#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"

PKG_MGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
[ -f "$PKG_MGR_SH" ] && . "$PKG_MGR_SH"

TELEMT_INSTALL_RELEASE_SCRIPT="${TELEMT_INSTALL_RELEASE_SCRIPT:-$SCRIPT_DIR/install-telemt-release.sh}"
INSTALL_IF_MISSING=0

usage() {
  cat <<EOF
Usage: $0 [--install-if-missing]

Check Telemt installation state (core package telemt + luci-app-telemt).

Options:
  --install-if-missing   Install Telemt if core or LuCI package is missing
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --install-if-missing)
      INSTALL_IF_MISSING=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Неизвестный аргумент: $1"
      ;;
  esac
  shift
done

pm_label() {
  case "${PM:-}" in
    apk) printf 'apk' ;;
    opkg) printf 'opkg' ;;
    *)
      if command -v apk >/dev/null 2>&1; then
        printf 'apk'
      elif command -v opkg >/dev/null 2>&1; then
        printf 'opkg'
      else
        printf '—'
      fi
      ;;
  esac
}

core_ok=0
luci_ok=0
mgr="$(pm_label)"

if command -v telemt >/dev/null 2>&1; then
  core_ok=1
elif command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed telemt 2>/dev/null; then
  core_ok=1
fi

if command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed luci-app-telemt 2>/dev/null; then
  luci_ok=1
elif command -v apk >/dev/null 2>&1 && apk info -e luci-app-telemt >/dev/null 2>&1; then
  luci_ok=1
elif command -v opkg >/dev/null 2>&1 && opkg list-installed 2>/dev/null | grep -q '^luci-app-telemt '; then
  luci_ok=1
fi

if [ "$core_ok" = "1" ]; then
  telemt_bin="$(command -v telemt 2>/dev/null || true)"
  if [ -n "$telemt_bin" ]; then
    info "Пакет telemt (демон MTProxy): установлен ($telemt_bin)"
    telemt_version="$("$telemt_bin" --version 2>/dev/null | head -n1 || true)"
    [ -n "$telemt_version" ] && info "Версия демона: $telemt_version"
  else
    info "Пакет telemt (демон MTProxy): установлен ($mgr)"
  fi
else
  warn "Пакет telemt (демон MTProxy): не установлен ($mgr)"
fi

if [ "$luci_ok" = "1" ]; then
  info "Пакет luci-app-telemt (веб-интерфейс LuCI): установлен ($mgr)"
else
  warn "Пакет luci-app-telemt (веб-интерфейс LuCI): не установлен ($mgr)"
fi

if [ "$core_ok" = "1" ] && [ "$luci_ok" = "1" ]; then
  success "Telemt установлен полностью (демон + LuCI)"
  exit 0
fi

missing=""
[ "$core_ok" = "0" ] && missing="telemt (демон MTProxy)"
[ "$luci_ok" = "0" ] && {
  [ -n "$missing" ] && missing="${missing}, "
  missing="${missing}luci-app-telemt (LuCI)"
}
warn "Telemt не установлен или неполный: отсутствует $missing"

if [ "$INSTALL_IF_MISSING" != "1" ]; then
  exit 1
fi

[ -f "$TELEMT_INSTALL_RELEASE_SCRIPT" ] || die "Не найден install script: $TELEMT_INSTALL_RELEASE_SCRIPT"
info "Запускаю установку (сначала telemt, затем luci-app-telemt)"
"$TELEMT_INSTALL_RELEASE_SCRIPT"
command -v telemt >/dev/null 2>&1 || die "Бинарник telemt не появился после установки"
if command -v pm_is_installed >/dev/null 2>&1; then
  pm_is_installed luci-app-telemt || warn "Пакет luci-app-telemt всё ещё не виден в $mgr"
fi
success "Установка Telemt завершена"
