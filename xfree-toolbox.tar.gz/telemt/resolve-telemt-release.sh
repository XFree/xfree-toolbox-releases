#!/bin/sh
set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd -P)"
COMMON_CANDIDATES="
$SCRIPT_DIR/../lib/common.sh
$SCRIPT_DIR/lib/common.sh
$SCRIPT_DIR/common.sh
"
COMMON_SH=""
for p in $COMMON_CANDIDATES; do
  [ -f "$p" ] && COMMON_SH="$p" && break
done
[ -n "$COMMON_SH" ] || {
  printf '[-] common.sh not found near %s\n' "$0" >&2
  exit 1
}
# shellcheck disable=SC1090
. "$COMMON_SH"
# shellcheck disable=SC1090
. "$SCRIPT_DIR/config.sh"

MODE="summary"
EXPLICIT_LUCI_TAG=""
EXPLICIT_CORE_TAG=""
SHOW_REASON=0
DEBUG="${DEBUG:-1}"
TELEMT_SELECT_REASON=""

usage() {
  cat <<USAGE
Usage:
  $(common_basename) [--summary|--urls|--emit-shell|--list-tags|--list-compatible-tags|--check-updates] [options]

Options:
  --summary
  --urls
  --emit-shell
  --list-tags
  --list-compatible-tags
  --check-updates
  --luci-tag <X.Y.Z>
  --core-tag <X.Y.Z>
  --show-reason
  --no-debug
USAGE
}

note() {
  case "$MODE" in
    emit-shell|urls) info_err "$*" ;;
    *) info "$*" ;;
  esac
}

while [ $# -gt 0 ]; do
  case "$1" in
    --summary) MODE="summary" ;;
    --urls) MODE="urls" ;;
    --emit-shell) MODE="emit-shell" ;;
    --list-tags|--list-compatible-tags) MODE="list-tags" ;;
    --check-updates) MODE="check-updates" ;;
    --luci-tag|--tag)
      shift
      [ $# -gt 0 ] || die "--luci-tag requires value"
      EXPLICIT_LUCI_TAG="$1"
      ;;
    --core-tag)
      shift
      [ $# -gt 0 ] || die "--core-tag requires value"
      EXPLICIT_CORE_TAG="$1"
      ;;
    --show-reason) SHOW_REASON=1 ;;
    --no-debug) DEBUG=0 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown argument: $1" ;;
  esac
  shift
done

http_get() {
  url="$1"
  curl --http1.1 -fsSL --connect-timeout 10 --max-time 30 -A "Mozilla/5.0" "$url"
}

http_exists() {
  url="$1"
  curl --http1.1 -fsI --connect-timeout 10 --max-time 20 -A "Mozilla/5.0" "$url" >/dev/null 2>&1
}

load_openwrt_release() {
  [ -f /etc/openwrt_release ] || die "/etc/openwrt_release not found"
  # shellcheck disable=SC1091
  . /etc/openwrt_release

  OWRT_VER="$DISTRIB_RELEASE"
  OWRT_ARCH_RAW="$(printf '%s' "${DISTRIB_ARCH:-}" | tr -d '\r')"

  [ -n "$OWRT_VER" ] || die "Could not detect OpenWrt release"
  [ -n "$OWRT_ARCH_RAW" ] || die "Could not detect OpenWrt arch"

  debug "Detected OpenWrt release: $OWRT_VER"
  debug "Detected OpenWrt arch: $OWRT_ARCH_RAW"
}

select_pkg_ext() {
  if command -v apk >/dev/null 2>&1; then
    PKG_EXT="apk"
    PKG_MGR="apk"
    LUCI_ARCH_SUFFIX="noarch"
  else
    PKG_EXT="ipk"
    PKG_MGR="opkg"
    LUCI_ARCH_SUFFIX="all"
  fi
}

telemt_arch_candidates() {
  arch="$1"
  case "$arch" in
    x86_64)
      printf '%s\n' "x86_64"
      ;;
    *cortex-a53*)
      printf '%s\n' "aarch64_cortex-a53"
      printf '%s\n' "aarch64_generic"
      ;;
    aarch64*|*filogic*|*mediatek*)
      printf '%s\n' "aarch64_generic"
      printf '%s\n' "aarch64_cortex-a53"
      ;;
    *)
      printf '%s\n' "$arch"
      ;;
  esac
}

select_telemt_arch() {
  TELEMT_ARCH=""
  for candidate in $(telemt_arch_candidates "$OWRT_ARCH_RAW"); do
    [ -n "$candidate" ] || continue
    TELEMT_ARCH="$candidate"
    debug "Selected telemt arch candidate: $TELEMT_ARCH"
    return 0
  done
  die "Could not select telemt arch for: $OWRT_ARCH_RAW"
}

extract_page_semver_tags() {
  html_file="$1"
  grep -oE '>[0-9]+\.[0-9]+\.[0-9]+<' "$html_file" \
    | tr -d '<>' \
    | sed '/^$/d' \
    | sort -u
}

extract_next_tags_url() {
  html_file="$1"
  current_url="$2"
  owner="$3"
  repo="$4"

  next_rel="$(grep -oE 'href="/[^"]+/tags\?after=[0-9.]+"' "$html_file" \
    | sed 's/^href="//' \
    | sed 's/"$//' \
    | grep "/${owner}/${repo}/tags?after=" \
    | sort -u \
    | tail -n1)"

  [ -n "$next_rel" ] || return 1

  next_url="https://github.com${next_rel}"
  [ "$next_url" = "$current_url" ] && return 1
  printf '%s\n' "$next_url"
}

fetch_repo_tags() {
  owner="$1"
  repo="$2"
  base_url="https://github.com/${owner}/${repo}"
  url="${base_url}/tags"
  page=1
  seen_urls=""
  tmp_dir="$(mktemp -d)" || die "mktemp failed"
  trap 'rm -rf "$tmp_dir"' EXIT INT TERM

  while [ -n "$url" ]; do
    case " $seen_urls " in
      *" $url "*)
        debug "Stopping pagination: already visited $url"
        break
        ;;
    esac
    seen_urls="$seen_urls $url"

    debug "Fetching tags page $page (${owner}/${repo}): $url"
    html_file="$tmp_dir/page_${page}.html"
    if ! http_get "$url" > "$html_file"; then
      die "Failed to fetch tags page: $url"
    fi

    extract_page_semver_tags "$html_file"

    next_url="$(extract_next_tags_url "$html_file" "$url" "$owner" "$repo" 2>/dev/null || true)"
    if [ -n "$next_url" ]; then
      url="$next_url"
      page=$((page + 1))
      if [ "$page" -gt 20 ]; then
        debug "Stopping pagination: page limit reached"
        break
      fi
    else
      url=""
    fi
  done | sort -V | uniq

  rm -rf "$tmp_dir"
  trap - EXIT INT TERM
}

luci_asset_file() {
  tag="$1"
  printf 'luci-app-telemt_%s_%s.%s\n' "$tag" "$LUCI_ARCH_SUFFIX" "$PKG_EXT"
}

core_asset_file() {
  tag="$1"
  arch="$2"
  printf 'telemt_%s_%s.%s\n' "$tag" "$arch" "$PKG_EXT"
}

luci_asset_url() {
  tag="$1"
  file="$(luci_asset_file "$tag")"
  printf 'https://github.com/%s/%s/releases/download/%s/%s\n' \
    "$TELEMT_LUCI_REPO_OWNER" "$TELEMT_LUCI_REPO_NAME" "$tag" "$file"
}

core_asset_url() {
  tag="$1"
  arch="$2"
  file="$(core_asset_file "$tag" "$arch")"
  printf 'https://github.com/%s/%s/releases/download/%s/%s\n' \
    "$TELEMT_CORE_REPO_OWNER" "$TELEMT_CORE_REPO_NAME" "$tag" "$file"
}

tag_has_luci_asset() {
  tag="$1"
  url="$(luci_asset_url "$tag")"
  debug "Probe luci asset: $url"
  http_exists "$url"
}

tag_has_core_asset() {
  tag="$1"
  arch="$2"
  url="$(core_asset_url "$tag" "$arch")"
  debug "Probe core asset: $url"
  http_exists "$url"
}

pick_core_arch_for_tag() {
  tag="$1"
  for candidate in $(telemt_arch_candidates "$OWRT_ARCH_RAW"); do
    [ -n "$candidate" ] || continue
    if tag_has_core_asset "$tag" "$candidate"; then
      TELEMT_ARCH="$candidate"
      return 0
    fi
  done
  return 1
}

major_minor_of() {
  ver="$1"
  printf '%s.%s\n' "$(printf '%s' "$ver" | cut -d. -f1)" "$(printf '%s' "$ver" | cut -d. -f2)"
}

select_luci_tag() {
  tags="$1"

  if [ -n "$EXPLICIT_LUCI_TAG" ]; then
    candidate="$EXPLICIT_LUCI_TAG"
    TELEMT_SELECT_REASON="manual-explicit-luci-tag"
  else
    candidate=""
    for tag in $(printf '%s\n' "$tags" | sort -Vr); do
      [ -n "$tag" ] || continue
      if tag_has_luci_asset "$tag"; then
        candidate="$tag"
        TELEMT_SELECT_REASON="latest-luci-with-platform-asset"
        break
      fi
    done
    [ -n "$candidate" ] || die "No luci-app-telemt release with .$PKG_EXT asset for this platform"
  fi

  printf '%s\n' "$tags" | grep -qx "$candidate" || die "LuCI tag not found: $candidate"
  tag_has_luci_asset "$candidate" || die "LuCI assets not ready: $candidate"

  LUCI_TAG="$candidate"
  LUCI_VER="$LUCI_TAG"
  note "Выбран LuCI-тег: $LUCI_TAG"
}

select_core_tag() {
  core_tags="$1"
  luci_mm="$(major_minor_of "$LUCI_VER")"
  luci_major="$(printf '%s' "$luci_mm" | cut -d. -f1)"
  luci_minor="$(printf '%s' "$luci_mm" | cut -d. -f2)"

  if [ -n "$EXPLICIT_CORE_TAG" ]; then
    candidate="$EXPLICIT_CORE_TAG"
    TELEMT_SELECT_REASON="manual-explicit-core-tag"
  else
    candidate=""
    # Ищем самый свежий patch core строго с тем же major.minor, что у LuCI (гарантия совместимости конфигов и рантайма)
    for tag in $(printf '%s\n' "$core_tags" | sort -V); do
      [ -n "$tag" ] || continue
      tag_major="$(printf '%s' "$tag" | cut -d. -f1)"
      tag_minor="$(printf '%s' "$tag" | cut -d. -f2)"
      [ "$tag_major" = "$luci_major" ] || continue
      [ "$tag_minor" = "$luci_minor" ] || continue
      pick_core_arch_for_tag "$tag" || continue
      candidate="$tag"
    done
    [ -n "$candidate" ] || die "No telemt_wrt release for major.minor ${luci_major}.${luci_minor} with arch asset for $OWRT_ARCH_RAW"
    TELEMT_SELECT_REASON="core-latest-patch-same-major-minor"
  fi

  printf '%s\n' "$core_tags" | grep -qx "$candidate" || die "Core tag not found: $candidate"

  CORE_TAG="$candidate"
  CORE_VER="$CORE_TAG"
  note "Выбран core-тег: $CORE_TAG (major.minor = ${luci_major}.${luci_minor}, совместим с LuCI $LUCI_VER)"
}

resolve_packages() {
  core_file="$(core_asset_file "$CORE_TAG" "$TELEMT_ARCH")"
  luci_file="$(luci_asset_file "$LUCI_TAG")"
  core_url="$(core_asset_url "$CORE_TAG" "$TELEMT_ARCH")"
  luci_url="$(luci_asset_url "$LUCI_TAG")"

  TELEMT_FILES="$core_file $luci_file"
  TELEMT_URLS="$core_url $luci_url"
}

get_installed_core_ver() {
  if command -v telemt >/dev/null 2>&1; then
    ver="$(telemt --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1 || true)"
    [ -n "$ver" ] && { printf '%s\n' "$ver"; return 0; }
  fi
  if command -v apk >/dev/null 2>&1; then
    ver="$(apk info -d telemt 2>/dev/null | grep -E '^telemt-[0-9]' | sed 's/^telemt-//' | cut -d- -f1 || true)"
    [ -n "$ver" ] && { printf '%s\n' "$ver"; return 0; }
  fi
  if command -v opkg >/dev/null 2>&1; then
    ver="$(opkg list-installed 2>/dev/null | grep '^telemt ' | awk '{print $3}' || true)"
    [ -n "$ver" ] && { printf '%s\n' "$ver"; return 0; }
  fi
  printf ''
}

get_installed_luci_ver() {
  if command -v apk >/dev/null 2>&1; then
    ver="$(apk list -I luci-app-telemt 2>/dev/null | awk '/^luci-app-telemt-[0-9]/ { sub(/^luci-app-telemt-/, ""); print $1; exit }' || true)"
    [ -z "$ver" ] && ver="$(apk info -d luci-app-telemt 2>/dev/null | awk '/^luci-app-telemt-[0-9]/ { sub(/^luci-app-telemt-/, ""); print $1; exit }' || true)"
    [ -n "$ver" ] && { printf '%s\n' "$ver"; return 0; }
  fi
  if command -v opkg >/dev/null 2>&1; then
    ver="$(opkg list-installed 2>/dev/null | grep '^luci-app-telemt ' | awk '{print $3}' || true)"
    [ -z "$ver" ] && ver="$(opkg status luci-app-telemt 2>/dev/null | awk '/^Version: / { print $2; exit }' || true)"
    [ -n "$ver" ] && { printf '%s\n' "$ver"; return 0; }
  fi
  printf ''
}

version_is_newer() {
  latest="$1"
  installed="$2"
  [ -z "$latest" ] && return 1
  [ -z "$installed" ] && return 0
  [ "$latest" = "$installed" ] && return 1
  first="$(printf '%s\n%s\n' "$installed" "$latest" | sort -V | head -n1)"
  [ "$first" = "$installed" ] && [ "$latest" != "$installed" ]
}

check_updates() {
  installed_core="$(get_installed_core_ver)"
  installed_luci="$(get_installed_luci_ver)"

  core_upd=0
  luci_upd=0
  if version_is_newer "$CORE_VER" "$installed_core"; then
    core_upd=1
  fi
  if version_is_newer "$LUCI_VER" "$installed_luci"; then
    luci_upd=1
  fi

  total_upd=0
  if [ "$core_upd" = "1" ] || [ "$luci_upd" = "1" ]; then
    total_upd=1
  fi

  printf 'core_installed_ver="%s"\n' "$installed_core"
  printf 'core_latest_ver="%s"\n' "$CORE_VER"
  printf 'core_update_available="%s"\n' "$core_upd"
  printf 'luci_installed_ver="%s"\n' "$installed_luci"
  printf 'luci_latest_ver="%s"\n' "$LUCI_VER"
  printf 'luci_update_available="%s"\n' "$luci_upd"
  printf 'update_available="%s"\n' "$total_upd"

  if [ "$total_upd" = "1" ]; then
    info "Доступны обновления Telemt:"
    [ "$core_upd" = "1" ] && info "  - Core (демон MTProxy): ${installed_core:-[не установлен]} -> $CORE_VER"
    [ "$luci_upd" = "1" ] && info "  - LuCI (веб-интерфейс): ${installed_luci:-[не установлен]} -> $LUCI_VER"
  else
    info "Все компоненты Telemt актуальны (Core: $CORE_VER, LuCI: $LUCI_VER)"
  fi
}

print_summary() {
  info "LuCI repository : ${TELEMT_LUCI_REPO_OWNER}/${TELEMT_LUCI_REPO_NAME}"
  info "Core repository : ${TELEMT_CORE_REPO_OWNER}/${TELEMT_CORE_REPO_NAME}"
  info "Package manager : $PKG_MGR"
  info "OpenWrt release : $OWRT_VER"
  info "OpenWrt arch    : $OWRT_ARCH_RAW"
  info "Telemt arch     : $TELEMT_ARCH"
  info "Package ext     : .$PKG_EXT"
  info "LuCI tag        : $LUCI_TAG"
  info "Core tag        : $CORE_TAG"
  [ "$SHOW_REASON" = "1" ] && info "Select reason   : $TELEMT_SELECT_REASON"
  info "Status          : ready"
  info "Install order   : core → luci"
  info "Files:"
  for f in $TELEMT_FILES; do
    say "    - $f"
  done
  info "URLs:"
  for u in $TELEMT_URLS; do
    say "    - $u"
  done
}

emit_shell() {
  printf 'LUCI_TAG="%s"\n' "$LUCI_TAG"
  printf 'LUCI_VER="%s"\n' "$LUCI_VER"
  printf 'CORE_TAG="%s"\n' "$CORE_TAG"
  printf 'CORE_VER="%s"\n' "$CORE_VER"
  printf 'TELEMT_OPENWRT_RELEASE="%s"\n' "$OWRT_VER"
  printf 'TELEMT_OPENWRT_ARCH="%s"\n' "$OWRT_ARCH_RAW"
  printf 'TELEMT_ARCH="%s"\n' "$TELEMT_ARCH"
  printf 'TELEMT_PKG_EXT="%s"\n' "$PKG_EXT"
  printf 'TELEMT_LUCI_ARCH_SUFFIX="%s"\n' "$LUCI_ARCH_SUFFIX"
  printf 'TELEMT_SELECT_REASON="%s"\n' "$TELEMT_SELECT_REASON"
  printf 'TELEMT_LUCI_REPO_OWNER="%s"\n' "$TELEMT_LUCI_REPO_OWNER"
  printf 'TELEMT_LUCI_REPO_NAME="%s"\n' "$TELEMT_LUCI_REPO_NAME"
  printf 'TELEMT_CORE_REPO_OWNER="%s"\n' "$TELEMT_CORE_REPO_OWNER"
  printf 'TELEMT_CORE_REPO_NAME="%s"\n' "$TELEMT_CORE_REPO_NAME"
  printf 'TELEMT_FILES="%s"\n' "$TELEMT_FILES"
  printf 'TELEMT_URLS="%s"\n' "$TELEMT_URLS"
}

list_tags() {
  info "LuCI repository : ${TELEMT_LUCI_REPO_OWNER}/${TELEMT_LUCI_REPO_NAME}"
  info "Core repository : ${TELEMT_CORE_REPO_OWNER}/${TELEMT_CORE_REPO_NAME}"
  info "OpenWrt release  : $OWRT_VER"
  info "OpenWrt arch     : $OWRT_ARCH_RAW"
  info "Selected LuCI    : ${LUCI_TAG:-${EXPLICIT_LUCI_TAG:-latest}}"
  info "Selected core    : ${CORE_TAG:-(patch с тем же major.minor, что у LuCI)}"
  if [ "$SHOW_REASON" = "1" ] && [ -n "$TELEMT_SELECT_REASON" ]; then
    info "Select reason    : $TELEMT_SELECT_REASON"
  fi
  say ""
  say "--- LuCI tags ---"
  printf '%s\n' "$1"
  say ""
  say "--- Core tags (совместимый patch с тем же major.minor) ---"
  printf '%s\n' "$2"
}

main() {
  load_openwrt_release
  select_pkg_ext
  select_telemt_arch

  LUCI_TAGS="$(fetch_repo_tags "$TELEMT_LUCI_REPO_OWNER" "$TELEMT_LUCI_REPO_NAME")"
  [ -n "$LUCI_TAGS" ] || die "No tags found in luci-app-telemt"

  CORE_TAGS="$(fetch_repo_tags "$TELEMT_CORE_REPO_OWNER" "$TELEMT_CORE_REPO_NAME")"
  [ -n "$CORE_TAGS" ] || die "No tags found in telemt_wrt"

  select_luci_tag "$LUCI_TAGS"
  select_core_tag "$CORE_TAGS"
  resolve_packages

  case "$MODE" in
    summary) print_summary ;;
    urls) printf '%s\n' $TELEMT_URLS ;;
    emit-shell) emit_shell ;;
    list-tags) list_tags "$LUCI_TAGS" "$CORE_TAGS" ;;
    check-updates) check_updates ;;
    *) die "Unsupported mode: $MODE" ;;
  esac
}

main "$@"
