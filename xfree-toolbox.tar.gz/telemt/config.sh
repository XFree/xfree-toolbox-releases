#!/bin/sh
# shellcheck shell=sh

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
common_load_project_config "$ROOT_DIR"

TELEMT_LUCI_REPO_OWNER="${TELEMT_LUCI_REPO_OWNER:-afadillo-a11y}"
TELEMT_LUCI_REPO_NAME="${TELEMT_LUCI_REPO_NAME:-luci-app-telemt}"
TELEMT_CORE_REPO_OWNER="${TELEMT_CORE_REPO_OWNER:-afadillo-a11y}"
TELEMT_CORE_REPO_NAME="${TELEMT_CORE_REPO_NAME:-telemt_wrt}"

TELEMT_DOWNLOAD_DIR="${TELEMT_DOWNLOAD_DIR:-/tmp/telemt}"
TELEMT_STATE_ROOT="${TELEMT_STATE_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/telemt}"
