#!/bin/sh
# Hand-written handlers for cli.run component=custom in telemt/menu.yaml.
# shellcheck shell=sh

# shellcheck disable=SC1090
. "$SCRIPT_DIR/config.sh"

TELEMT_RESOLVE_RELEASE_SCRIPT="${TELEMT_RESOLVE_RELEASE_SCRIPT:-$SCRIPT_DIR/resolve-telemt-release.sh}"
TELEMT_DOWNLOAD_RELEASE_SCRIPT="${TELEMT_DOWNLOAD_RELEASE_SCRIPT:-$SCRIPT_DIR/download-telemt-release.sh}"
TELEMT_INSTALL_RELEASE_SCRIPT="${TELEMT_INSTALL_RELEASE_SCRIPT:-$SCRIPT_DIR/install-telemt-release.sh}"
TELEMT_ENSURE_SCRIPT="${TELEMT_ENSURE_SCRIPT:-$SCRIPT_DIR/ensure-telemt.sh}"
RUN_SH_SAFE_SCRIPT="${RUN_SH_SAFE_SCRIPT:-$SCRIPT_DIR/run-sh-safe.sh}"

telemt_run() {
	title="$1"
	shift
	ui_menu_chmod_first_if_needed "$@"
	ui_menu_invoke_with_output "$title" "$@"
}

telemt_menu_choice_1() {
	telemt_run "Проверка установки Telemt" "$RUN_SH_SAFE_SCRIPT" "$TELEMT_ENSURE_SCRIPT"
}

telemt_menu_choice_2() {
	telemt_run "Проверка/установка Telemt" "$RUN_SH_SAFE_SCRIPT" "$TELEMT_ENSURE_SCRIPT" --install-if-missing
}

telemt_menu_choice_3() {
	telemt_run "Информация о релизе Telemt" "$TELEMT_RESOLVE_RELEASE_SCRIPT" --summary --show-reason
}

telemt_menu_choice_4() {
	telemt_run "Теги Telemt" "$TELEMT_RESOLVE_RELEASE_SCRIPT" --list-compatible-tags --show-reason
}

telemt_menu_choice_5() {
	telemt_run "Скачивание Telemt" "$TELEMT_DOWNLOAD_RELEASE_SCRIPT" --show-reason --keep
}

telemt_menu_choice_6() {
	telemt_run "Установка Telemt" "$TELEMT_INSTALL_RELEASE_SCRIPT" --show-reason
}
