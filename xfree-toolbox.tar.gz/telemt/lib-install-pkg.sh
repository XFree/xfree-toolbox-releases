#!/bin/sh
# shellcheck shell=sh
# Helpers for telemt + luci-app-telemt install (shared /etc/config/telemt).

telemt_pkg_is_luci() {
  case "$(basename -- "$1")" in
    luci-app-telemt*) return 0 ;;
    *) return 1 ;;
  esac
}

telemt_core_pkg_installed() {
  command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed telemt 2>/dev/null
}

telemt_luci_pkg_installed() {
  command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed luci-app-telemt 2>/dev/null
}

telemt_is_config_overwrite_error() {
  log="$1"
  grep -q 'trying to overwrite etc/config/telemt' "$log" 2>/dev/null \
    || grep -q 'trying to overwrite /etc/config/telemt' "$log" 2>/dev/null
}

telemt_repack_luci_apk_without_config() {
  src="$1"
  dst="$2"
  work=""
  data=""
  members=""

  [ -f "$src" ] || return 1
  [ -n "$dst" ] || return 1
  tar -tf "$src" >/dev/null 2>&1 || return 1

  members="$(tar tf "$src")"
  for m in $members; do
    case "$m" in
      data.tar.gz|.data.tar.gz) data="$m" ;;
    esac
  done
  [ -n "$data" ] || return 1

  work="$(mktemp -d)" || return 1
  # shellcheck disable=SC2064
  trap 'rm -rf "$work"' EXIT INT TERM

  tar -C "$work" -xf "$src" || return 1

  if [ ! -f "$work/$data" ]; then
    return 1
  fi

  mkdir -p "$work/data_root"
  tar -xzf "$work/$data" -C "$work/data_root" || return 1

  if [ ! -f "$work/data_root/etc/config/telemt" ]; then
    cp "$src" "$dst"
    trap - EXIT INT TERM
    rm -rf "$work"
    return 0
  fi

  rm -f "$work/data_root/etc/config/telemt"
  tar -czf "$work/$data" -C "$work/data_root" . || return 1
  rm -rf "$work/data_root"

  rm -f "$dst"
  # shellcheck disable=SC2046
  tar -cf "$dst" -C "$work" $(tar tf "$src") || return 1

  trap - EXIT INT TERM
  rm -rf "$work"
  return 0
}

telemt_pm_install_file() {
  file="$1"
  [ -f "$file" ] || return 1

  case "$PM" in
    opkg)
      info "Установка пакета (opkg --force-overwrite): $(basename -- "$file")"
      opkg install --force-overwrite "$file"
      return $?
      ;;
    apk)
      info "Установка пакета (apk --force-overwrite): $(basename -- "$file")"
      extra_flags="--force-overwrite"
      [ "${FORCE:-0}" = "1" ] && extra_flags="$extra_flags --force-reinstall"
      # shellcheck disable=SC2086
      apk add --allow-untrusted --force-non-repository $extra_flags "$file"
      return $?
      ;;
    *)
      pm_install_file "$file"
      return $?
      ;;
  esac
}
