#!/bin/sh
# shellcheck shell=sh
# Helpers for telemt + luci-app-telemt install (shared /etc/config/telemt).

telemt_pkg_is_luci() {
  case "$(basename -- "$1")" in
    luci-app-telemt*) return 0 ;;
    *) return 1 ;;
  esac
}

telemt_core_pkg_installed() {
  command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed telemt 2>/dev/null
}

telemt_luci_pkg_installed() {
  command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed luci-app-telemt 2>/dev/null
}

telemt_is_config_overwrite_error() {
  log="$1"
  grep -q 'trying to overwrite etc/config/telemt' "$log" 2>/dev/null \
    || grep -q 'trying to overwrite /etc/config/telemt' "$log" 2>/dev/null
}

telemt_repack_luci_apk_without_config() {
  src="$1"
  dst="$2"
  work=""
  data=""
  members=""

  [ -f "$src" ] || return 1
  [ -n "$dst" ] || return 1
  tar -tf "$src" >/dev/null 2>&1 || return 1

  members="$(tar tf "$src")"
  for m in $members; do
    case "$m" in
      data.tar.gz|.data.tar.gz) data="$m" ;;
    esac
  done
  [ -n "$data" ] || return 1

  work="$(mktemp -d)" || return 1
  # shellcheck disable=SC2064
  trap 'rm -rf "$work"' EXIT INT TERM

  tar -C "$work" -xf "$src" || return 1

  if [ ! -f "$work/$data" ]; then
    return 1
  fi

  mkdir -p "$work/data_root"
  tar -xzf "$work/$data" -C "$work/data_root" || return 1

  if [ ! -f "$work/data_root/etc/config/telemt" ]; then
    cp "$src" "$dst"
    trap - EXIT INT TERM
    rm -rf "$work"
    return 0
  fi

  rm -f "$work/data_root/etc/config/telemt"
  tar -czf "$work/$data" -C "$work/data_root" . || return 1
  rm -rf "$work/data_root"

  rm -f "$dst"
  # shellcheck disable=SC2046
  tar -cf "$dst" -C "$work" $(tar tf "$src") || return 1

  trap - EXIT INT TERM
  rm -rf "$work"
  return 0
}

telemt_pm_install_file() {
  file="$1"
  err_log=""
  repacked=""

  [ -f "$file" ] || return 1

  if telemt_pkg_is_luci "$file" && telemt_core_pkg_installed; then
    case "$PM" in
      opkg)
        info "LuCI: opkg --force-overwrite (конфиг /etc/config/telemt остаётся от telemt core)"
        opkg install --force-overwrite "$file"
        return $?
        ;;
      apk)
        err_log="$(mktemp)" || return 1
        if pm_install_file "$file" 2>"$err_log"; then
          rm -f "$err_log"
          return 0
        fi

        if telemt_is_config_overwrite_error "$err_log" && telemt_luci_pkg_installed; then
          warn "luci-app-telemt уже установлен; /etc/config/telemt не перезаписан (владелец: telemt core)"
          rm -f "$err_log"
          return 0
        fi

        if telemt_is_config_overwrite_error "$err_log"; then
          info "LuCI: установка без etc/config/telemt (конфиг остаётся от telemt core)"
          repacked="$(mktemp /tmp/luci-app-telemt.XXXXXX.apk)" || {
            rm -f "$err_log"
            return 1
          }
          if telemt_repack_luci_apk_without_config "$file" "$repacked" \
            && pm_install_file "$repacked"; then
            rm -f "$err_log" "$repacked"
            return 0
          fi
          rm -f "$repacked"
        fi

        cat "$err_log" >&2
        rm -f "$err_log"
        return 1
        ;;
    esac
  fi

  # Default path: install as-is, but on error print stderr so user sees the reason.
  err_log="$(mktemp)" || return 1
  if pm_install_file "$file" 2>"$err_log"; then
    rm -f "$err_log"
    return 0
  fi
  cat "$err_log" >&2
  rm -f "$err_log"
  return 1
}
