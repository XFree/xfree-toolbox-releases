#!/usr/bin/env python3
from pathlib import Path

vp = Path(
    "build/openwrt/luci-app-xfree-toolbox/htdocs/luci-static/resources/xfree-toolbox/vpn-panel.js"
)
snippet_raw = Path(".tmp-warp-colo-cc.js").read_text(encoding="utf-8")
lines = []
for line in snippet_raw.splitlines():
    lines.append(line[1:] if line.startswith("\t") else line)
snippet = "\n".join(lines) + "\n"

text = vp.read_text(encoding="utf-8")
if "WARP_COLO_CC" in text:
    print("already has map")
    raise SystemExit(0)

needle = "function healthLabel(health) {\n\tvar h = String(health || '').toLowerCase();\n\n\tif (h === 'ok') return 'OK';\n\tif (h === 'warn') return 'WARN';\n\tif (h === 'fail') return 'FAIL';\n\treturn '—';\n}\n"
if needle not in text:
    raise SystemExit("marker not found")
text = text.replace(needle, needle + "\n" + snippet, 1)
vp.write_text(text, encoding="utf-8")
print("ok inserted", snippet.count("\n"), "lines")
