#!/bin/sh
# shellcheck shell=sh
# Tar update markers: WebDAV ETag/Last-Modified on router after install-from-cloud / self-update.

xfree_update_etag_file() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  printf '%s/.update-etag\n' "$_root"
}

xfree_update_lastmod_file() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  printf '%s/.update-lastmodified\n' "$_root"
}

xfree_read_local_version() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  _vf="$_root/VERSION"
  if [ -f "$_vf" ]; then
    head -n1 "$_vf" | tr -d '\r\n'
  else
    printf '%s' ""
  fi
}

# Sibling VERSION next to xfree-toolbox.tar.gz (GitHub raw / directory feeds).
# For single-file Nextcloud DAV tokens returns empty (no directory layout).
xfree_remote_version_url_from_tar() {
  _tar="${1:-}"
  [ -n "$_tar" ] || return 1
  case "$_tar" in
  */xfree-toolbox.tar.gz|*/"${ARCHIVE_NAME:-xfree-toolbox.tar.gz}")
    printf '%s\n' "${_tar%/*}/VERSION"
    return 0
    ;;
  */*.tar.gz)
    printf '%s\n' "${_tar%/*}/VERSION"
    return 0
    ;;
  *)
    return 1
    ;;
  esac
}

# Download tiny text (VERSION). Sets XFREE_REMOTE_VERSION. Returns 0 if non-empty.
xfree_fetch_remote_version_text() {
  _url="${1:-}"
  _tmp=""
  XFREE_REMOTE_VERSION=""
  [ -n "$_url" ] || return 1
  _tmp="$(mktemp "${TMPDIR:-/tmp}/xfree-remote-ver.XXXXXX" 2>/dev/null || mktemp)"
  if command -v curl >/dev/null 2>&1; then
    curl --http1.1 -fsSL -o "$_tmp" "$_url" 2>/dev/null \
      || curl --http1.1 -fsSL -k -o "$_tmp" "$_url" 2>/dev/null \
      || {
        rm -f "$_tmp" 2>/dev/null || true
        return 1
      }
  elif command -v wget >/dev/null 2>&1; then
    wget -q -T 20 -O "$_tmp" "$_url" 2>/dev/null \
      || wget --no-check-certificate -q -T 20 -O "$_tmp" "$_url" 2>/dev/null \
      || {
        rm -f "$_tmp" 2>/dev/null || true
        return 1
      }
  else
    rm -f "$_tmp" 2>/dev/null || true
    return 1
  fi
  XFREE_REMOTE_VERSION="$(head -n1 "$_tmp" 2>/dev/null | tr -d '\r\n\t ' || true)"
  rm -f "$_tmp" 2>/dev/null || true
  [ -n "$XFREE_REMOTE_VERSION" ] || return 1
  return 0
}

# Resolve published toolbox version for tar URL: sibling VERSION, else etag-cache, else peek tar.
# Sets XFREE_REMOTE_VERSION. Uses optional $2 = remote etag for cache key.
xfree_resolve_remote_tar_version() {
  _tar_url="${1:-}"
  _etag="${2:-}"
  _ver_url=""
  _cache="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/.remote-tar-version.cache"
  _cache_etag=""
  _cache_ver=""
  _tmp_tar=""
  XFREE_REMOTE_VERSION=""

  [ -n "$_tar_url" ] || return 1

  if _ver_url="$(xfree_remote_version_url_from_tar "$_tar_url" 2>/dev/null)"; then
    if xfree_fetch_remote_version_text "$_ver_url"; then
      return 0
    fi
  fi

  if [ -n "$_etag" ] && [ -f "$_cache" ]; then
    _cache_etag="$(sed -n '1p' "$_cache" | tr -d '\r\n')"
    _cache_ver="$(sed -n '2p' "$_cache" | tr -d '\r\n\t ')"
    if [ -n "$_cache_ver" ] && [ "$_cache_etag" = "$_etag" ]; then
      XFREE_REMOTE_VERSION="$_cache_ver"
      return 0
    fi
  fi

  # Fallback: extract VERSION from published tar (≈1 MB once per etag).
  _tmp_tar="$(mktemp "${TMPDIR:-/tmp}/xfree-tar-peek.XXXXXX" 2>/dev/null || mktemp)"
  if xfree_download_tar_archive "$_tmp_tar" "$_tar_url" 2>/dev/null; then
    for _ver_member in ./VERSION VERSION; do
      XFREE_REMOTE_VERSION="$(tar -xzOf "$_tmp_tar" "$_ver_member" 2>/dev/null | head -n1 | tr -d '\r\n\t ' || true)"
      [ -n "$XFREE_REMOTE_VERSION" ] && break
    done
  fi
  rm -f "$_tmp_tar" 2>/dev/null || true
  [ -n "$XFREE_REMOTE_VERSION" ] || return 1

  if [ -n "$_etag" ]; then
    mkdir -p "$(dirname "$_cache")" 2>/dev/null || true
    printf '%s\n%s\n' "$_etag" "$XFREE_REMOTE_VERSION" >"$_cache" 2>/dev/null || true
  fi
  return 0
}

xfree_read_local_etag() {
  _etag_file="$(xfree_update_etag_file "${1:-}")"
  if [ -f "$_etag_file" ]; then
    head -n1 "$_etag_file" | tr -d '\r\n'
  else
    printf '%s' ""
  fi
}

xfree_luci_update_etag_file() {
  _state="${1:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}}"
  printf '%s/.luci-update-etag\n' "$_state"
}

xfree_luci_update_lastmod_file() {
  _state="${1:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}}"
  printf '%s/.luci-update-lastmodified\n' "$_state"
}

xfree_read_local_luci_etag() {
  _f="$(xfree_luci_update_etag_file "${1:-}")"
  if [ -f "$_f" ]; then
    head -n1 "$_f" | tr -d '\r\n'
  else
    printf '%s' ""
  fi
}

# Parse ETag / Last-Modified from HTTP response headers (wget -S stderr or curl -D).
# Nextcloud public shares may expose OC-ETag instead of ETag.
xfree_parse_http_response_headers() {
  _hdr_text="$1"

  XFREE_HTTP_ETAG="$(printf '%s\n' "$_hdr_text" \
    | grep -iE '^[[:space:]]*(oc-)?etag:' \
    | head -n1 \
    | sed -e 's/^[[:space:]]*//' -e 's/^[^:]*:[[:space:]]*//' -e 's/\r$//')"

  XFREE_HTTP_LASTMOD="$(printf '%s\n' "$_hdr_text" \
    | grep -iE '^[[:space:]]*last-modified:' \
    | head -n1 \
    | sed -e 's/^[[:space:]]*//' -e 's/^[^:]*:[[:space:]]*//' -e 's/\r$//')"
}

# GNU wget (пакет wget-ssl → /usr/libexec/wget-ssl) умеет -S / --spider.
# OpenWrt 24: /usr/bin/wget → uclient-fetch (−S нет, −s = spider).
# stdout: путь бинаря; иначе return 1.
xfree_gnu_wget_bin() {
  if [ -x /usr/libexec/wget-ssl ]; then
    printf '%s\n' /usr/libexec/wget-ssl
    return 0
  fi
  _w="$(command -v wget 2>/dev/null || true)"
  [ -n "$_w" ] || return 1
  if "$_w" --version >/dev/null 2>&1; then
    printf '%s\n' "$_w"
    return 0
  fi
  return 1
}

# Download tar. ETag из GET — бонус GNU wget -S / curl -D; иначе stamp PROPFIND/HEAD.
xfree_download_tar_archive() {
  _dst="$1"
  _url="$2"
  _hdr_file=""
  _hdr_text=""
  _gnu=""

  [ -n "$_url" ] || return 1

  if command -v curl >/dev/null 2>&1; then
    _hdr_file="${_dst}.headers.$$"
    if ! curl --http1.1 -fsSL -D "$_hdr_file" -o "$_dst" "$_url" 2>/dev/null; then
      rm -f "$_hdr_file" 2>/dev/null || true
      return 1
    fi
    _hdr_text="$(cat "$_hdr_file" 2>/dev/null || true)"
    rm -f "$_hdr_file" 2>/dev/null || true
  elif _gnu="$(xfree_gnu_wget_bin)"; then
    _hdr_file="${_dst}.headers.$$"
    if "$_gnu" -S -O "$_dst" "$_url" 2>"$_hdr_file" \
      || "$_gnu" --no-check-certificate -S -O "$_dst" "$_url" 2>"$_hdr_file"; then
      _hdr_text="$(cat "$_hdr_file" 2>/dev/null || true)"
      rm -f "$_hdr_file" 2>/dev/null || true
    else
      rm -f "$_hdr_file" 2>/dev/null || true
      return 1
    fi
  elif command -v wget >/dev/null 2>&1; then
    if wget -O "$_dst" "$_url" 2>/dev/null \
      || wget --no-check-certificate -O "$_dst" "$_url" 2>/dev/null; then
      _hdr_text=""
    else
      return 1
    fi
  else
    return 1
  fi

  [ -s "$_dst" ] || return 1

  xfree_parse_http_response_headers "$_hdr_text"
  XFREE_DOWNLOAD_ETAG="${XFREE_HTTP_ETAG:-}"
  XFREE_DOWNLOAD_LASTMOD="${XFREE_HTTP_LASTMOD:-}"
  return 0
}

# HEAD: curl -I, иначе GNU wget -S --spider. uclient-fetch -S не вызываем.
xfree_fetch_remote_tar_props_head() {
  _url="$1"
  _hdr_file=""
  _hdr_text=""
  _gnu=""

  [ -n "$_url" ] || return 1

  if command -v curl >/dev/null 2>&1; then
    _hdr_file="${TMPDIR:-/tmp}/xfree-tar-head.$$"
    if ! curl --http1.1 -fsSI -D "$_hdr_file" -o /dev/null "$_url" 2>/dev/null; then
      rm -f "$_hdr_file" 2>/dev/null || true
      curl --http1.1 -fsSI -k -D "$_hdr_file" -o /dev/null "$_url" 2>/dev/null \
        || {
          rm -f "$_hdr_file" 2>/dev/null || true
          return 1
        }
    fi
    _hdr_text="$(cat "$_hdr_file" 2>/dev/null || true)"
    rm -f "$_hdr_file" 2>/dev/null || true
  elif _gnu="$(xfree_gnu_wget_bin)"; then
    _hdr_file="${TMPDIR:-/tmp}/xfree-tar-head.$$"
    if ! "$_gnu" -S --spider "$_url" 2>"$_hdr_file"; then
      if ! "$_gnu" --no-check-certificate -S --spider "$_url" 2>"$_hdr_file"; then
        rm -f "$_hdr_file" 2>/dev/null || true
        return 1
      fi
    fi
    _hdr_text="$(cat "$_hdr_file" 2>/dev/null || true)"
    rm -f "$_hdr_file" 2>/dev/null || true
  else
    return 1
  fi

  xfree_parse_http_response_headers "$_hdr_text"
  XFREE_REMOTE_ETAG="${XFREE_HTTP_ETAG:-}"
  XFREE_REMOTE_LASTMOD="${XFREE_HTTP_LASTMOD:-}"
  [ -n "${XFREE_REMOTE_ETAG:-}" ] || return 1
  return 0
}

# Fetch remote tar properties: PROPFIND first, then HEAD (curl / GNU wget).
# GitHub raw has no WebDAV — skip PROPFIND (it hangs / 405).
# Sets XFREE_REMOTE_ETAG and XFREE_REMOTE_LASTMOD; returns 0 on success.
xfree_fetch_remote_tar_props() {
  _url="$1"
  _xml=""

  [ -n "$_url" ] || return 1
  if command -v common_check_system_time >/dev/null 2>&1; then
    common_check_system_time
  fi

  case "$_url" in
    *://raw.githubusercontent.com/*|*://*.githubusercontent.com/*)
      xfree_fetch_remote_tar_props_head "$_url"
      return
      ;;
  esac

  if command -v curl >/dev/null 2>&1; then
    _xml="$(curl --http1.1 -fsS -X PROPFIND -H 'Depth: 0' "$_url" 2>/dev/null)" || _xml=""
  elif command -v wget >/dev/null 2>&1; then
    _xml="$(wget -qO- --method=PROPFIND --header='Depth: 0' "$_url" 2>/dev/null)" || _xml=""
  fi

  if [ -n "$_xml" ]; then
    XFREE_REMOTE_ETAG="$(printf '%s\n' "$_xml" \
      | grep -o '<d:getetag>[^<]*' \
      | head -n1 \
      | cut -d'>' -f2 \
      | sed 's/&quot;/"/g')"

    XFREE_REMOTE_LASTMOD="$(printf '%s\n' "$_xml" \
      | grep -o '<d:getlastmodified>[^<]*' \
      | head -n1 \
      | cut -d'>' -f2)"

    [ -n "${XFREE_REMOTE_ETAG:-}" ] && return 0
  fi

  xfree_fetch_remote_tar_props_head "$_url"
}

xfree_save_installed_tar_props() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  _etag="${2:-}"
  _lastmod="${3:-}"

  [ -n "$_etag" ] || return 1
  [ -d "$_root" ] || return 1

  mkdir -p "$_root" 2>/dev/null || true
  printf '%s\n' "$_etag" > "$(xfree_update_etag_file "$_root")"
  if [ -n "$_lastmod" ]; then
    printf '%s\n' "$_lastmod" > "$(xfree_update_lastmod_file "$_root")"
  fi
  return 0
}

# Source lib from installed tree (after tar payload replaces TARGET_DIR).
xfree_update_etag_load_lib() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  _lib="$_root/lib/update-etag.sh"
  [ -f "$_lib" ] || return 1
  # shellcheck disable=SC1090
  . "$_lib"
  return 0
}

# Best-effort: stamp router install after tar payload (install-from-cloud / self-update).
# Optional args 3/4: etag/lastmod from download (skip PROPFIND). Env fallback:
# XFREE_INSTALLED_TAR_ETAG, XFREE_INSTALLED_TAR_LASTMOD.
xfree_stamp_installed_tar_etag() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  _url="${2:-${UPDATE_URL:-${XFREE_UPDATE_URL:-}}}"
  _etag="${3:-${XFREE_INSTALLED_TAR_ETAG:-}}"
  _lastmod="${4:-${XFREE_INSTALLED_TAR_LASTMOD:-}}"

  [ -d "$_root" ] || return 0

  if [ -z "$_etag" ] && [ -n "$_url" ]; then
    if xfree_fetch_remote_tar_props "$_url"; then
      _etag="$XFREE_REMOTE_ETAG"
      _lastmod="${_lastmod:-$XFREE_REMOTE_LASTMOD}"
    fi
  fi

  if [ -z "$_etag" ]; then
    if command -v warn >/dev/null 2>&1; then
      warn "local ETag не сохранён (нет ETag в заголовках/PROPFIND; url=${_url:-<none>})"
    else
      printf '[!] local ETag не сохранён (нет ETag в заголовках/PROPFIND)\n' >&2
    fi
    return 0
  fi

  if xfree_save_installed_tar_props "$_root" "$_etag" "$_lastmod"; then
    if command -v log_file >/dev/null 2>&1; then
      log_file "[INFO] stamped local etag=$_etag"
    fi
    if command -v info >/dev/null 2>&1; then
      info "Сохранён local ETag: $_etag"
    fi
    return 0
  fi
  return 0
}
