#!/bin/sh
# shellcheck shell=sh
# Tar update markers: WebDAV ETag/Last-Modified on router after install-from-cloud / self-update.

xfree_update_etag_file() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  printf '%s/.update-etag\n' "$_root"
}

xfree_update_lastmod_file() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  printf '%s/.update-lastmodified\n' "$_root"
}

xfree_read_local_version() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  _vf="$_root/VERSION"
  if [ -f "$_vf" ]; then
    head -n1 "$_vf" | tr -d '\r\n'
  else
    printf '%s' ""
  fi
}

xfree_read_local_etag() {
  _etag_file="$(xfree_update_etag_file "${1:-}")"
  if [ -f "$_etag_file" ]; then
    head -n1 "$_etag_file" | tr -d '\r\n'
  else
    printf '%s' ""
  fi
}

# Parse ETag / Last-Modified from HTTP response headers (wget -S stderr or curl -D).
# Nextcloud public shares may expose OC-ETag instead of ETag.
xfree_parse_http_response_headers() {
  _hdr_text="$1"

  XFREE_HTTP_ETAG="$(printf '%s\n' "$_hdr_text" \
    | grep -iE '^[[:space:]]*(oc-)?etag:' \
    | head -n1 \
    | sed -e 's/^[[:space:]]*//' -e 's/^[^:]*:[[:space:]]*//' -e 's/\r$//')"

  XFREE_HTTP_LASTMOD="$(printf '%s\n' "$_hdr_text" \
    | grep -iE '^[[:space:]]*last-modified:' \
    | head -n1 \
    | sed -e 's/^[[:space:]]*//' -e 's/^[^:]*:[[:space:]]*//' -e 's/\r$//')"
}

# GNU wget (пакет wget-ssl → /usr/libexec/wget-ssl) умеет -S / --spider.
# OpenWrt 24: /usr/bin/wget → uclient-fetch (−S нет, −s = spider).
# stdout: путь бинаря; иначе return 1.
xfree_gnu_wget_bin() {
  if [ -x /usr/libexec/wget-ssl ]; then
    printf '%s\n' /usr/libexec/wget-ssl
    return 0
  fi
  _w="$(command -v wget 2>/dev/null || true)"
  [ -n "$_w" ] || return 1
  if "$_w" --version >/dev/null 2>&1; then
    printf '%s\n' "$_w"
    return 0
  fi
  return 1
}

# Download tar. ETag из GET — бонус GNU wget -S / curl -D; иначе stamp PROPFIND/HEAD.
xfree_download_tar_archive() {
  _dst="$1"
  _url="$2"
  _hdr_file=""
  _hdr_text=""
  _gnu=""

  [ -n "$_url" ] || return 1

  if command -v curl >/dev/null 2>&1; then
    _hdr_file="${_dst}.headers.$$"
    if ! curl --http1.1 -fsSL -D "$_hdr_file" -o "$_dst" "$_url" 2>/dev/null; then
      rm -f "$_hdr_file" 2>/dev/null || true
      return 1
    fi
    _hdr_text="$(cat "$_hdr_file" 2>/dev/null || true)"
    rm -f "$_hdr_file" 2>/dev/null || true
  elif _gnu="$(xfree_gnu_wget_bin)"; then
    _hdr_file="${_dst}.headers.$$"
    if "$_gnu" -S -O "$_dst" "$_url" 2>"$_hdr_file" \
      || "$_gnu" --no-check-certificate -S -O "$_dst" "$_url" 2>"$_hdr_file"; then
      _hdr_text="$(cat "$_hdr_file" 2>/dev/null || true)"
      rm -f "$_hdr_file" 2>/dev/null || true
    else
      rm -f "$_hdr_file" 2>/dev/null || true
      return 1
    fi
  elif command -v wget >/dev/null 2>&1; then
    if wget -O "$_dst" "$_url" 2>/dev/null \
      || wget --no-check-certificate -O "$_dst" "$_url" 2>/dev/null; then
      _hdr_text=""
    else
      return 1
    fi
  else
    return 1
  fi

  [ -s "$_dst" ] || return 1

  xfree_parse_http_response_headers "$_hdr_text"
  XFREE_DOWNLOAD_ETAG="${XFREE_HTTP_ETAG:-}"
  XFREE_DOWNLOAD_LASTMOD="${XFREE_HTTP_LASTMOD:-}"
  return 0
}

# HEAD: curl -I, иначе GNU wget -S --spider. uclient-fetch -S не вызываем.
xfree_fetch_remote_tar_props_head() {
  _url="$1"
  _hdr_file=""
  _hdr_text=""
  _gnu=""

  [ -n "$_url" ] || return 1

  if command -v curl >/dev/null 2>&1; then
    _hdr_file="${TMPDIR:-/tmp}/xfree-tar-head.$$"
    if ! curl --http1.1 -fsSI -D "$_hdr_file" -o /dev/null "$_url" 2>/dev/null; then
      rm -f "$_hdr_file" 2>/dev/null || true
      curl --http1.1 -fsSI -k -D "$_hdr_file" -o /dev/null "$_url" 2>/dev/null \
        || {
          rm -f "$_hdr_file" 2>/dev/null || true
          return 1
        }
    fi
    _hdr_text="$(cat "$_hdr_file" 2>/dev/null || true)"
    rm -f "$_hdr_file" 2>/dev/null || true
  elif _gnu="$(xfree_gnu_wget_bin)"; then
    _hdr_file="${TMPDIR:-/tmp}/xfree-tar-head.$$"
    if ! "$_gnu" -S --spider "$_url" 2>"$_hdr_file"; then
      if ! "$_gnu" --no-check-certificate -S --spider "$_url" 2>"$_hdr_file"; then
        rm -f "$_hdr_file" 2>/dev/null || true
        return 1
      fi
    fi
    _hdr_text="$(cat "$_hdr_file" 2>/dev/null || true)"
    rm -f "$_hdr_file" 2>/dev/null || true
  else
    return 1
  fi

  xfree_parse_http_response_headers "$_hdr_text"
  XFREE_REMOTE_ETAG="${XFREE_HTTP_ETAG:-}"
  XFREE_REMOTE_LASTMOD="${XFREE_HTTP_LASTMOD:-}"
  [ -n "${XFREE_REMOTE_ETAG:-}" ] || return 1
  return 0
}

# Fetch remote tar properties: PROPFIND first, then HEAD (curl / GNU wget).
# GitHub raw has no WebDAV — skip PROPFIND (it hangs / 405).
# Sets XFREE_REMOTE_ETAG and XFREE_REMOTE_LASTMOD; returns 0 on success.
xfree_fetch_remote_tar_props() {
  _url="$1"
  _xml=""

  [ -n "$_url" ] || return 1

  case "$_url" in
    *://raw.githubusercontent.com/*|*://*.githubusercontent.com/*)
      xfree_fetch_remote_tar_props_head "$_url"
      return
      ;;
  esac

  if command -v curl >/dev/null 2>&1; then
    _xml="$(curl --http1.1 -fsS -X PROPFIND -H 'Depth: 0' "$_url" 2>/dev/null)" || _xml=""
  elif command -v wget >/dev/null 2>&1; then
    _xml="$(wget -qO- --method=PROPFIND --header='Depth: 0' "$_url" 2>/dev/null)" || _xml=""
  fi

  if [ -n "$_xml" ]; then
    XFREE_REMOTE_ETAG="$(printf '%s\n' "$_xml" \
      | grep -o '<d:getetag>[^<]*' \
      | head -n1 \
      | cut -d'>' -f2 \
      | sed 's/&quot;/"/g')"

    XFREE_REMOTE_LASTMOD="$(printf '%s\n' "$_xml" \
      | grep -o '<d:getlastmodified>[^<]*' \
      | head -n1 \
      | cut -d'>' -f2)"

    [ -n "${XFREE_REMOTE_ETAG:-}" ] && return 0
  fi

  xfree_fetch_remote_tar_props_head "$_url"
}

xfree_save_installed_tar_props() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  _etag="${2:-}"
  _lastmod="${3:-}"

  [ -n "$_etag" ] || return 1
  [ -d "$_root" ] || return 1

  mkdir -p "$_root" 2>/dev/null || true
  printf '%s\n' "$_etag" > "$(xfree_update_etag_file "$_root")"
  if [ -n "$_lastmod" ]; then
    printf '%s\n' "$_lastmod" > "$(xfree_update_lastmod_file "$_root")"
  fi
  return 0
}

# Source lib from installed tree (after tar payload replaces TARGET_DIR).
xfree_update_etag_load_lib() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  _lib="$_root/lib/update-etag.sh"
  [ -f "$_lib" ] || return 1
  # shellcheck disable=SC1090
  . "$_lib"
  return 0
}

# Best-effort: stamp router install after tar payload (install-from-cloud / self-update).
# Optional args 3/4: etag/lastmod from download (skip PROPFIND). Env fallback:
# XFREE_INSTALLED_TAR_ETAG, XFREE_INSTALLED_TAR_LASTMOD.
xfree_stamp_installed_tar_etag() {
  _root="${1:-${TARGET_DIR:-/root/xfree-toolbox}}"
  _url="${2:-${UPDATE_URL:-${XFREE_UPDATE_URL:-}}}"
  _etag="${3:-${XFREE_INSTALLED_TAR_ETAG:-}}"
  _lastmod="${4:-${XFREE_INSTALLED_TAR_LASTMOD:-}}"

  [ -d "$_root" ] || return 0

  if [ -z "$_etag" ] && [ -n "$_url" ]; then
    if xfree_fetch_remote_tar_props "$_url"; then
      _etag="$XFREE_REMOTE_ETAG"
      _lastmod="${_lastmod:-$XFREE_REMOTE_LASTMOD}"
    fi
  fi

  if [ -z "$_etag" ]; then
    if command -v warn >/dev/null 2>&1; then
      warn "local ETag не сохранён (нет ETag в заголовках/PROPFIND; url=${_url:-<none>})"
    else
      printf '[!] local ETag не сохранён (нет ETag в заголовках/PROPFIND)\n' >&2
    fi
    return 0
  fi

  if xfree_save_installed_tar_props "$_root" "$_etag" "$_lastmod"; then
    if command -v log_file >/dev/null 2>&1; then
      log_file "[INFO] stamped local etag=$_etag"
    fi
    if command -v info >/dev/null 2>&1; then
      info "Сохранён local ETag: $_etag"
    fi
    return 0
  fi
  return 0
}
