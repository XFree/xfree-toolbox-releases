#!/bin/sh
# shellcheck shell=sh
# Generic macrotask + microtask queue with coalesce, debounce, and digest loop.
# API reference: docs/sdk/task-queue/
#
# Consumer defines hooks (after sourcing):
#   task_queue_hook_validate_job(job_type)
#   task_queue_hook_validate_micro(micro_type)
#   task_queue_hook_execute_task(job_type, reason)
#   task_queue_hook_execute_micro(micro_type, reason)
# Optional: task_queue_hook_log(msg) — default writes to TASK_QUEUE_LOG_FILE
#
# Configure paths via env before source (or TASK_QUEUE_ID + XFREE_STATE_ROOT).

TASK_QUEUE_LIB_SOURCED="${TASK_QUEUE_LIB_SOURCED:-}"
[ -n "$TASK_QUEUE_LIB_SOURCED" ] && return 0
TASK_QUEUE_LIB_SOURCED=1

_task_queue_lib_dir() {
    CDPATH= cd -- "$(dirname -- "$0")" && pwd -P
}

if [ -z "${TASK_QUEUE_TOOLBOX_ROOT:-}" ]; then
    _tqd="$(_task_queue_lib_dir)"
    TASK_QUEUE_TOOLBOX_ROOT="$(CDPATH= cd -- "$_tqd/.." && pwd -P)"
fi

if [ -f "${TASK_QUEUE_TOOLBOX_ROOT}/lib/log-ring.sh" ]; then
    # shellcheck disable=SC1091
    . "${TASK_QUEUE_TOOLBOX_ROOT}/lib/log-ring.sh"
fi

TASK_QUEUE_STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
TASK_QUEUE_ID="${TASK_QUEUE_ID:-default}"
TASK_QUEUE_CONF_FILE="${TASK_QUEUE_CONF_FILE:-$TASK_QUEUE_STATE_ROOT/system/task-queue-${TASK_QUEUE_ID}.conf}"
TASK_QUEUE_STATE_FILE="${TASK_QUEUE_STATE_FILE:-$TASK_QUEUE_STATE_ROOT/system/task-queue-${TASK_QUEUE_ID}.state}"
TASK_QUEUE_TASKS_FILE="${TASK_QUEUE_TASKS_FILE:-$TASK_QUEUE_STATE_ROOT/system/task-queue-${TASK_QUEUE_ID}.tasks}"
TASK_QUEUE_MICRO_FILE="${TASK_QUEUE_MICRO_FILE:-$TASK_QUEUE_STATE_ROOT/system/task-queue-${TASK_QUEUE_ID}.micro}"
TASK_QUEUE_LOG_FILE="${TASK_QUEUE_LOG_FILE:-$TASK_QUEUE_STATE_ROOT/system/task-queue-${TASK_QUEUE_ID}.log}"
TASK_QUEUE_LOG_TAG="${TASK_QUEUE_LOG_TAG:-xfree-task-queue}"

TASK_QUEUE_DEBOUNCE_SEC="${TASK_QUEUE_DEBOUNCE_SEC:-15}"
TASK_QUEUE_MAX_DELAY_SEC="${TASK_QUEUE_MAX_DELAY_SEC:-60}"
TASK_QUEUE_ENABLED="${TASK_QUEUE_ENABLED:-0}"
TASK_QUEUE_DIGEST_MAX_PASSES="${TASK_QUEUE_DIGEST_MAX_PASSES:-4}"

# Default hooks (consumer may redefine after source).
task_queue_hook_validate_job() {
    [ -n "${1:-}" ]
}

task_queue_hook_validate_micro() {
    [ -n "${1:-}" ]
}

task_queue_hook_execute_task() {
    task_queue_log "hook_execute_task: not implemented type=${1:-?}"
    return 1
}

task_queue_hook_execute_micro() {
    task_queue_log "hook_execute_micro: not implemented type=${1:-?}"
    return 1
}

task_queue_conf_get() {
    _cfg_file="$1"
    _cfg_key="$2"
    _cfg_default="${3:-}"
    [ -f "$_cfg_file" ] || {
        printf '%s' "$_cfg_default"
        return 0
    }
    _cfg_val="$(awk -F= -v want="$_cfg_key" '
        $1 == want {
            v = substr($0, index($0, "=") + 1)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
            gsub(/^\047|\047$/, "", v)
            print v
            exit
        }
    ' "$_cfg_file" 2>/dev/null || true)"
    _cfg_val="$(printf '%s' "${_cfg_val:-}" | tr -d '\r')"
    [ -n "${_cfg_val:-}" ] && printf '%s' "$_cfg_val" || printf '%s' "$_cfg_default"
}

task_queue_conf_kv_set() {
    _cfg_file="$1"
    _cfg_key="$2"
    _cfg_value="$3"
    mkdir -p "$(dirname -- "$_cfg_file")" 2>/dev/null || true
    _kv_tmp="${_cfg_file}.tmp.$$"
    if [ -f "$_cfg_file" ]; then
        awk -v key="$_cfg_key" -v value="$_cfg_value" '
            BEGIN { done = 0 }
            $0 ~ ("^[[:space:]]*" key "[[:space:]]*=") {
                print key "=\047" value "\047"
                done = 1
                next
            }
            { print }
            END {
                if (!done) print key "=\047" value "\047"
            }
        ' "$_cfg_file" >"$_kv_tmp"
    else
        printf '%s=\047%s\047\n' "$_cfg_key" "$_cfg_value" >"$_kv_tmp"
    fi
    mv -f "$_kv_tmp" "$_cfg_file"
}

task_queue_state_get() {
    task_queue_conf_get "$(task_queue_state_path)" "$1" "${2:-}"
}

task_queue_state_set() {
    task_queue_conf_kv_set "$(task_queue_state_path)" "$1" "$2"
}

task_queue_state_path() {
    printf '%s\n' "$TASK_QUEUE_STATE_FILE"
}

task_queue_conf_path() {
    printf '%s\n' "$TASK_QUEUE_CONF_FILE"
}

task_queue_conf_ensure() {
    _cfg_path="$(task_queue_conf_path)"
    mkdir -p "$(dirname -- "$_cfg_path")" 2>/dev/null || true
    [ -f "$_cfg_path" ] && return 0
    cat >"$_cfg_path" <<'EOF'
# Generic task queue (macrotask + microtask digest)
ENABLED=0
DEBOUNCE_SEC=15
MAX_DELAY_SEC=60
DIGEST_MAX_PASSES=4
EOF
}

task_queue_load_config() {
    task_queue_conf_ensure
    _cf="$(task_queue_conf_path)"
    case "$(task_queue_conf_get "$_cf" ENABLED 0)" in
        1|yes|true|on|ON) TASK_QUEUE_ENABLED=1 ;;
        *) TASK_QUEUE_ENABLED=0 ;;
    esac
    TASK_QUEUE_DEBOUNCE_SEC="$(task_queue_conf_get "$_cf" DEBOUNCE_SEC 15)"
    TASK_QUEUE_MAX_DELAY_SEC="$(task_queue_conf_get "$_cf" MAX_DELAY_SEC 60)"
    TASK_QUEUE_DIGEST_MAX_PASSES="$(task_queue_conf_get "$_cf" DIGEST_MAX_PASSES 4)"
    case "$TASK_QUEUE_DEBOUNCE_SEC" in
        ''|*[!0-9]*) TASK_QUEUE_DEBOUNCE_SEC=15 ;;
    esac
    case "$TASK_QUEUE_MAX_DELAY_SEC" in
        ''|*[!0-9]*) TASK_QUEUE_MAX_DELAY_SEC=60 ;;
    esac
    case "$TASK_QUEUE_DIGEST_MAX_PASSES" in
        ''|*[!0-9]*) TASK_QUEUE_DIGEST_MAX_PASSES=4 ;;
    esac
}

task_queue_log() {
    _log_msg="$1"
    _log_ts="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"
    _log_line="[$_log_ts] $_log_msg"
    _log_max="${TASK_QUEUE_LOG_MAX_LINES:-${LOG_RING_MAX_LINES:-100}}"
    printf '%s\n' "$_log_line"
    if command -v log_ring_append >/dev/null 2>&1; then
        log_ring_append "$TASK_QUEUE_LOG_FILE" "$_log_line" "$_log_max"
    else
        printf '%s\n' "$_log_line" >>"$TASK_QUEUE_LOG_FILE" 2>/dev/null || true
    fi
    if command -v logger >/dev/null 2>&1; then
        logger -t "$TASK_QUEUE_LOG_TAG" "$_log_msg" 2>/dev/null || true
    fi
}

task_queue_hook_log() {
    task_queue_log "$1"
}

task_queue_now_epoch() {
    if [ -n "${TASK_QUEUE_TEST_NOW_EPOCH:-}" ]; then
        printf '%s' "$TASK_QUEUE_TEST_NOW_EPOCH"
        return 0
    fi
    date +%s 2>/dev/null || echo 0
}

task_queue_test_action() {
    [ -n "${TASK_QUEUE_TEST_ACTIONS_FILE:-}" ] || return 0
    printf '%s\n' "$1" >>"$TASK_QUEUE_TEST_ACTIONS_FILE"
}

task_queue_sanitize_token() {
    printf '%s' "${1:-}" | tr '|' '_' | tr '\n' ' ' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'
}

task_queue_queue_nonempty() {
    _queue_file="$1"
    [ -f "$_queue_file" ] && [ -s "$_queue_file" ]
}

task_queue_tasks_nonempty() {
    task_queue_queue_nonempty "$TASK_QUEUE_TASKS_FILE"
}

task_queue_micro_nonempty() {
    task_queue_queue_nonempty "$TASK_QUEUE_MICRO_FILE"
}

task_queue_any_nonempty() {
    task_queue_tasks_nonempty || task_queue_micro_nonempty
}

task_queue_pop_head() {
    _queue_file="$1"
    [ -f "$_queue_file" ] || return 1
    [ -s "$_queue_file" ] || return 1
    head -n 1 "$_queue_file"
    _pop_rest="${_queue_file}.rest.$$"
    tail -n +2 "$_queue_file" >"$_pop_rest" 2>/dev/null || : >"$_pop_rest"
    if [ -s "$_pop_rest" ]; then
        mv -f "$_pop_rest" "$_queue_file"
    else
        rm -f "$_queue_file" "$_pop_rest" 2>/dev/null || true
    fi
    return 0
}

task_queue_enqueue_coalesced() {
    _queue_file="$1"
    _job_type="$2"
    _reason="$3"
    _seq_key="$4"
    _now="$5"

    mkdir -p "$(dirname -- "$_queue_file")" 2>/dev/null || true
    _seq="$(task_queue_state_get "$_seq_key" 0)"
    case "$_seq" in
        ''|*[!0-9]*) _seq=0 ;;
    esac
    _seq=$((_seq + 1))
    task_queue_state_set "$_seq_key" "$_seq"

    _q_tmp="${_queue_file}.tmp.$$"
    if [ -f "$_queue_file" ]; then
        awk -F'|' -v jt="$_job_type" 'NF && $2 != jt { print }' "$_queue_file" >"$_q_tmp" 2>/dev/null || : >"$_q_tmp"
    else
        : >"$_q_tmp"
    fi
    printf '%s|%s|%s|%s\n' "$_seq" "$_job_type" "$_reason" "$_now" >>"$_q_tmp"
    mv -f "$_q_tmp" "$_queue_file"
}

task_queue_bump_run_after() {
    _now="$1"
    _debounce_sec="$2"

    _first_epoch="$(task_queue_state_get FIRST_ENQUEUE_EPOCH 0)"
    case "$_first_epoch" in
        ''|*[!0-9]*) _first_epoch=0 ;;
    esac
    if [ "$_first_epoch" -le 0 ] 2>/dev/null; then
        task_queue_state_set FIRST_ENQUEUE_EPOCH "$_now"
        _first_epoch="$_now"
    fi

    _run_after=$((_now + _debounce_sec))
    _max_run=$((_first_epoch + TASK_QUEUE_MAX_DELAY_SEC))
    if [ "$_run_after" -gt "$_max_run" ] 2>/dev/null; then
        _run_after="$_max_run"
    fi
    task_queue_state_set RUN_AFTER_EPOCH "$_run_after"
}

task_queue_enqueue_task() {
    _job_type="$1"
    _reason="$2"
    _debounce_override="${3:-}"

    task_queue_hook_validate_job "$_job_type" || return 1
    _reason="$(task_queue_sanitize_token "$_reason")"
    [ -n "$_reason" ] || _reason='unspecified'

    task_queue_load_config
    _now="$(task_queue_now_epoch)"

    _debounce_sec="$TASK_QUEUE_DEBOUNCE_SEC"
    [ -n "$_debounce_override" ] && case "$_debounce_override" in
        *[!0-9]*) ;;
        *) _debounce_sec="$_debounce_override" ;;
    esac

    task_queue_enqueue_coalesced \
        "$TASK_QUEUE_TASKS_FILE" \
        "$_job_type" \
        "$_reason" \
        TASK_SEQ \
        "$_now"
    task_queue_bump_run_after "$_now" "$_debounce_sec"

    _enqueue_count="$(task_queue_state_get ENQUEUE_COUNT 0)"
    case "$_enqueue_count" in
        ''|*[!0-9]*) _enqueue_count=0 ;;
    esac
    _enqueue_count=$((_enqueue_count + 1))
    task_queue_state_set ENQUEUE_COUNT "$_enqueue_count"
    task_queue_state_set LAST_REASON "$_reason"

    if [ "$(task_queue_state_get EXECUTING 0)" = "1" ]; then
        task_queue_hook_log "enqueue task: $_job_type reason=$_reason (digest running; coalesced to tail)"
    else
        task_queue_hook_log "enqueue task: $_job_type reason=$_reason run_after=$(( $(task_queue_state_get RUN_AFTER_EPOCH 0) - _now ))s"
    fi
    return 0
}

task_queue_enqueue_micro() {
    _micro_type="$1"
    _reason="$2"

    task_queue_hook_validate_micro "$_micro_type" || return 1
    _reason="$(task_queue_sanitize_token "$_reason")"
    [ -n "$_reason" ] || _reason='unspecified'
    _now="$(task_queue_now_epoch)"

    task_queue_enqueue_coalesced \
        "$TASK_QUEUE_MICRO_FILE" \
        "$_micro_type" \
        "$_reason" \
        MICRO_SEQ \
        "$_now"
    task_queue_hook_log "enqueue micro: $_micro_type reason=$_reason"
    return 0
}

task_queue_reset_schedule_meta() {
    task_queue_state_set RUN_AFTER_EPOCH 0
    task_queue_state_set FIRST_ENQUEUE_EPOCH 0
}

task_queue_cancel() {
    rm -f "$TASK_QUEUE_TASKS_FILE" "$TASK_QUEUE_MICRO_FILE" 2>/dev/null || true
    task_queue_reset_schedule_meta
    task_queue_state_set PENDING_DIGEST 0
    task_queue_hook_log "cancel: task and micro queues cleared"
}

task_queue_ready_to_digest() {
    _force="$1"
    _now="$(task_queue_now_epoch)"

    task_queue_any_nonempty || return 1
    [ "$_force" = "1" ] && return 0

    _run_after="$(task_queue_state_get RUN_AFTER_EPOCH 0)"
    _first_epoch="$(task_queue_state_get FIRST_ENQUEUE_EPOCH 0)"
    case "$_run_after" in
        ''|*[!0-9]*) return 1 ;;
    esac
    case "$_first_epoch" in
        ''|*[!0-9]*) _first_epoch=0 ;;
    esac

    [ "$_now" -ge "$_run_after" ] 2>/dev/null && return 0
    if [ "$_first_epoch" -gt 0 ] 2>/dev/null; then
        _max_run=$((_first_epoch + TASK_QUEUE_MAX_DELAY_SEC))
        [ "$_now" -ge "$_max_run" ] 2>/dev/null && return 0
    fi
    return 1
}

task_queue_dump_lines() {
    _label="$1"
    _file="$2"
    if [ ! -f "$_file" ] || [ ! -s "$_file" ]; then
        printf '%s: (empty)\n' "$_label"
        return 0
    fi
    printf '%s:\n' "$_label"
    sed 's/^/  /' "$_file"
}

task_queue_status_text() {
    task_queue_load_config
    _now="$(task_queue_now_epoch)"
    _run_after="$(task_queue_state_get RUN_AFTER_EPOCH 0)"
    _first="$(task_queue_state_get FIRST_ENQUEUE_EPOCH 0)"
    _reason="$(task_queue_state_get LAST_REASON '')"
    _enqueue_count="$(task_queue_state_get ENQUEUE_COUNT 0)"
    _executing="$(task_queue_state_get EXECUTING 0)"
    _digest_gen="$(task_queue_state_get DIGEST_GENERATION 0)"
    _pending_digest="$(task_queue_state_get PENDING_DIGEST 0)"

    printf 'queue_id=%s\n' "$TASK_QUEUE_ID"
    printf 'enabled=%s\n' "$TASK_QUEUE_ENABLED"
    printf 'executing=%s\n' "$_executing"
    printf 'pending_digest=%s\n' "$_pending_digest"
    printf 'digest_generation=%s\n' "$_digest_gen"
    printf 'last_reason=%s\n' "$_reason"
    printf 'enqueue_count=%s\n' "$_enqueue_count"
    printf 'run_after_epoch=%s\n' "$_run_after"
    printf 'first_enqueue_epoch=%s\n' "$_first"
    if [ "$_run_after" -gt "$_now" ] 2>/dev/null; then
        printf 'due_in_sec=%s\n' "$((_run_after - _now))"
    else
        printf 'due_in_sec=0\n'
    fi
    printf 'debounce_sec=%s\n' "$TASK_QUEUE_DEBOUNCE_SEC"
    printf 'max_delay_sec=%s\n' "$TASK_QUEUE_MAX_DELAY_SEC"
    printf 'digest_max_passes=%s\n' "$TASK_QUEUE_DIGEST_MAX_PASSES"
    task_queue_dump_lines 'task_queue' "$TASK_QUEUE_TASKS_FILE"
    task_queue_dump_lines 'micro_queue' "$TASK_QUEUE_MICRO_FILE"
}

task_queue_execute_task_line() {
    _line="$1"
    _job_type="$(printf '%s' "$_line" | awk -F'|' '{ print $2 }')"
    _reason="$(printf '%s' "$_line" | awk -F'|' '{ print $3 }')"
    task_queue_hook_execute_task "$_job_type" "$_reason"
}

task_queue_execute_micro_line() {
    _line="$1"
    _micro_type="$(printf '%s' "$_line" | awk -F'|' '{ print $2 }')"
    _reason="$(printf '%s' "$_line" | awk -F'|' '{ print $3 }')"
    task_queue_hook_execute_micro "$_micro_type" "$_reason"
}

task_queue_digest_pass() {
    _rc=0
    while task_queue_tasks_nonempty; do
        _line="$(task_queue_pop_head "$TASK_QUEUE_TASKS_FILE")" || break
        task_queue_execute_task_line "$_line" || _rc=1
    done
    while task_queue_micro_nonempty; do
        _line="$(task_queue_pop_head "$TASK_QUEUE_MICRO_FILE")" || break
        task_queue_execute_micro_line "$_line" || _rc=1
    done
    return "$_rc"
}

task_queue_digest() {
    _force="${1:-0}"

    task_queue_load_config
    if [ "$_force" != "1" ] && [ "$TASK_QUEUE_ENABLED" != "1" ]; then
        task_queue_hook_log "digest: skip ENABLED=$TASK_QUEUE_ENABLED"
        return 0
    fi

    if [ "$(task_queue_state_get EXECUTING 0)" = "1" ]; then
        task_queue_hook_log "digest: skip already executing"
        return 0
    fi

    if ! task_queue_ready_to_digest "$_force"; then
        if [ "$_force" != "1" ] && task_queue_any_nonempty; then
            _now="$(task_queue_now_epoch)"
            _run_after="$(task_queue_state_get RUN_AFTER_EPOCH 0)"
            case "$_run_after" in
                ''|*[!0-9]*) _due=15 ;;
                *)
                    _due=$((_run_after - _now))
                    [ "$_due" -lt 1 ] && _due=1
                    [ "$_due" -gt 300 ] && _due=300
                    ;;
            esac
            task_queue_hook_log "digest: not due (${_due}s); rearm"
            if command -v task_queue_hook_digest_not_due >/dev/null 2>&1; then
                task_queue_hook_digest_not_due "$_due"
            fi
        fi
        return 0
    fi

    task_queue_state_set EXECUTING 1
    task_queue_reset_schedule_meta

    _gen="$(task_queue_state_get DIGEST_GENERATION 0)"
    case "$_gen" in
        ''|*[!0-9]*) _gen=0 ;;
    esac
    _gen=$((_gen + 1))
    task_queue_state_set DIGEST_GENERATION "$_gen"

    task_queue_hook_log "digest: begin generation=$_gen"
    _rc=0
    _pass=0
    while :; do
        _pass=$((_pass + 1))
        _had_work=0
        if task_queue_any_nonempty; then
            _had_work=1
            task_queue_hook_log "digest: pass=$_pass"
            task_queue_digest_pass || _rc=1
        fi
        task_queue_any_nonempty || break
        [ "$_pass" -lt "$TASK_QUEUE_DIGEST_MAX_PASSES" ] || {
            task_queue_hook_log "digest: max passes=$TASK_QUEUE_DIGEST_MAX_PASSES (queues may remain)"
            task_queue_state_set PENDING_DIGEST 1
            break
        }
        [ "$_had_work" -eq 1 ] || break
    done

    task_queue_state_set EXECUTING 0

    if task_queue_any_nonempty; then
        task_queue_state_set PENDING_DIGEST 1
        _now="$(task_queue_now_epoch)"
        task_queue_bump_run_after "$_now" 5
        task_queue_hook_log "digest: queues remain; rescheduled run_after+5s"
    else
        task_queue_state_set PENDING_DIGEST 0
    fi

    if [ "$_rc" -eq 0 ]; then
        task_queue_hook_log "digest: done generation=$_gen passes=$_pass"
    else
        task_queue_hook_log "digest: done with errors generation=$_gen passes=$_pass"
    fi
    return "$_rc"
}

task_queue_finalize() {
    task_queue_digest "$@"
}

task_queue_tick() {
    task_queue_digest "${1:-0}"
}
