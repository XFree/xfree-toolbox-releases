#!/bin/sh
# shellcheck shell=sh
# Portable timeout (OpenWrt часто без GNU timeout).

# Usage: cmd_timeout <sec> <command> [args...]
cmd_timeout() {
    _sec="$1"
    shift
    case "$_sec" in
        ''|*[!0-9]*) _sec=5 ;;
    esac
    [ $# -gt 0 ] || return 2

    if command -v timeout >/dev/null 2>&1; then
        timeout "$_sec" "$@"
        return $?
    fi

    "$@" &
    _pid=$!
    _left="$_sec"
    while [ "$_left" -gt 0 ]; do
        if kill -0 "$_pid" 2>/dev/null; then
            sleep 1
            _left=$((_left - 1))
            continue
        fi
        wait "$_pid" 2>/dev/null
        return $?
    done
    kill "$_pid" 2>/dev/null
    wait "$_pid" 2>/dev/null
    return 124
}
