#!/bin/sh
# shellcheck shell=sh

NL='
'

UI_WIDTH="${UI_WIDTH:-74}"
UI_MENU_HEIGHT="${UI_MENU_HEIGHT:-20}"
UI_MSGBOX_HEIGHT="${UI_MSGBOX_HEIGHT:-20}"
UI_CONFIRM_HEIGHT="${UI_CONFIRM_HEIGHT:-22}"
UI_INPUTBOX_HEIGHT="${UI_INPUTBOX_HEIGHT:-10}"

if [ -n "${ROOT_DIR:-}" ] && [ -f "${ROOT_DIR}/lib/common.sh" ]; then
  COMMON_SH="${ROOT_DIR}/lib/common.sh"
elif [ -f "./lib/common.sh" ]; then
  COMMON_SH="./lib/common.sh"
else
  UI_DIR="$(CDPATH= cd -- "$(dirname -- "${0:-$PWD}")" && pwd -P)"
  COMMON_SH="${UI_DIR}/common.sh"
fi

[ -f "$COMMON_SH" ] || {
  echo "[!] Не найден common.sh: $COMMON_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"
PROTON_MANUAL_CONF_CAPTURE_SH="$(CDPATH= cd -- "$(dirname -- "$COMMON_SH")" && pwd -P)/proton-manual-conf-capture.sh"
# shellcheck disable=SC1090
[ -f "$PROTON_MANUAL_CONF_CAPTURE_SH" ] && . "$PROTON_MANUAL_CONF_CAPTURE_SH"
: "${NCURSES_NO_UTF8_ACS:=1}"
export NCURSES_NO_UTF8_ACS

UI_COMPONENTS_DIR="$(CDPATH= cd -- "$(dirname -- "$COMMON_SH")/ui/components" && pwd -P)"
UPSTREAMS_SELECTION_COMPONENT="$UI_COMPONENTS_DIR/upstreams-selection.sh"
[ -f "$UPSTREAMS_SELECTION_COMPONENT" ] && . "$UPSTREAMS_SELECTION_COMPONENT"

ui_have_whiptail() {
  command -v whiptail >/dev/null 2>&1 && [ -c /dev/tty ]
}

ui_prepare_tty() {
  ui_have_whiptail || return 0
  stty sane </dev/tty 2>/dev/null || true
  printf '\033[0m' >/dev/tty 2>/dev/null || true
  printf '\033[?25h' >/dev/tty 2>/dev/null || true
}

# Terminal size for whiptail clamping (SSH/Windows Terminal often < caller width).
ui_tty_cols() {
  _cols=""
  if [ -n "${COLUMNS:-}" ]; then
    case "$COLUMNS" in
      *[!0-9]*) ;;
      *) [ "$COLUMNS" -gt 0 ] 2>/dev/null && _cols="$COLUMNS" ;;
    esac
  fi
  if [ -z "$_cols" ]; then
    _cols="$(stty size </dev/tty 2>/dev/null | awk '{print $2}')" || _cols=""
  fi
  if [ -z "$_cols" ] && command -v tput >/dev/null 2>&1; then
    _cols="$(tput cols 2>/dev/null)" || _cols=""
  fi
  case "${_cols:-}" in
    ''|*[!0-9]*) _cols=80 ;;
  esac
  [ "$_cols" -ge 40 ] 2>/dev/null || _cols=40
  printf '%s\n' "$_cols"
}

ui_tty_lines() {
  _lines=""
  if [ -n "${LINES:-}" ]; then
    case "$LINES" in
      *[!0-9]*) ;;
      *) [ "$LINES" -gt 0 ] 2>/dev/null && _lines="$LINES" ;;
    esac
  fi
  if [ -z "$_lines" ]; then
    _lines="$(stty size </dev/tty 2>/dev/null | awk '{print $1}')" || _lines=""
  fi
  if [ -z "$_lines" ] && command -v tput >/dev/null 2>&1; then
    _lines="$(tput lines 2>/dev/null)" || _lines=""
  fi
  case "${_lines:-}" in
    ''|*[!0-9]*) _lines=24 ;;
  esac
  [ "$_lines" -ge 12 ] 2>/dev/null || _lines=12
  printf '%s\n' "$_lines"
}

# Clamp whiptail box so width/height fit the TTY. Too-wide dialogs clip checklist
# tags on the left (e.g. "[*]" → "*]").
# Sets: UI_CLAMP_HEIGHT UI_CLAMP_WIDTH [UI_CLAMP_LIST_HEIGHT if $3 given]
ui_clamp_whiptail_box() {
  _want_h="$1"
  _want_w="$2"
  _want_list="${3:-}"

  _max_h=$(($(ui_tty_lines) - 1))
  _max_w=$(($(ui_tty_cols) - 2))
  [ "$_max_h" -ge 12 ] 2>/dev/null || _max_h=12
  [ "$_max_w" -ge 40 ] 2>/dev/null || _max_w=40

  case "${_want_h:-}" in ''|*[!0-9]*) _want_h=20 ;; esac
  case "${_want_w:-}" in ''|*[!0-9]*) _want_w="$UI_WIDTH" ;; esac

  UI_CLAMP_HEIGHT="$_want_h"
  UI_CLAMP_WIDTH="$_want_w"
  if [ "$UI_CLAMP_HEIGHT" -gt "$_max_h" ]; then
    UI_CLAMP_HEIGHT="$_max_h"
  fi
  if [ "$UI_CLAMP_WIDTH" -gt "$_max_w" ]; then
    UI_CLAMP_WIDTH="$_max_w"
  fi

  if [ -n "$_want_list" ]; then
    case "$_want_list" in ''|*[!0-9]*) _want_list=10 ;; esac
    UI_CLAMP_LIST_HEIGHT="$_want_list"
    # Title/border/prompt/buttons overhead ≈ 7 rows inside the box.
    _max_list=$((UI_CLAMP_HEIGHT - 7))
    [ "$_max_list" -ge 1 ] || _max_list=1
    if [ "$UI_CLAMP_LIST_HEIGHT" -gt "$_max_list" ]; then
      UI_CLAMP_LIST_HEIGHT="$_max_list"
    fi
  fi
  return 0
}

ui_capture_whiptail() {
  # POSIX sh + set -u: dash has no RANDOM; use mktemp when available.
  ui_tmp_root="${UI_TMP_ROOT:-/tmp}"
  mkdir -p "$ui_tmp_root" 2>/dev/null || ui_tmp_root="/tmp"

  if command -v mktemp >/dev/null 2>&1; then
    tmp="$(mktemp "$ui_tmp_root/whiptail.XXXXXX" 2>/dev/null)" || tmp=""
  else
    tmp=""
  fi
  if [ -z "$tmp" ]; then
    tmp="$ui_tmp_root/whiptail.$$.$(date +%s 2>/dev/null || echo 0).out"
    : > "$tmp" || {
      tmp="/tmp/whiptail.$$.$(date +%s 2>/dev/null || echo 0).out"
      : > "$tmp"
    }
  fi

  ui_prepare_tty

  if "$@" </dev/tty >/dev/tty 2>"$tmp"; then
    cat "$tmp"
    rm -f "$tmp"
    return 0
  fi

  rm -f "$tmp"
  return 1
}

ui_init() {
  UI_TMP_ROOT="${1:-/tmp/ui.$$}"
  export UI_TMP_ROOT
  mkdir -p "$UI_TMP_ROOT"
}

# Menu visibility (normal / expert). Expert shows all items; normal hides visibility:expert.
_menu_expert_mode() {
  case "$(common_upper_ascii "${XFREE_MENU_MODE:-normal}")" in
    EXPERT|1|YES|TRUE|ON) return 0 ;;
    *) return 1 ;;
  esac
}

_menu_mode_label() {
  if _menu_expert_mode; then
    printf '%s' "эксперт"
  else
    printf '%s' "простой"
  fi
}

menu_mode_normalize() {
  case "$(common_upper_ascii "${XFREE_MENU_MODE:-normal}")" in
    EXPERT|1|YES|TRUE|ON) export XFREE_MENU_MODE=expert ;;
    *) export XFREE_MENU_MODE=normal ;;
  esac
}

menu_mode_persist() {
  mode="$1"
  root="${ROOT_DIR:-}"
  config_file="${root}/config.sh"
  tmp_file="${root}/config.sh.tmp.$$"

  [ -n "$root" ] || return 0
  [ -f "$config_file" ] || {
    printf "XFREE_MENU_MODE='%s'\n" "$mode" >"$config_file"
    return 0
  }

  awk -v mode="$mode" '
    BEGIN { updated=0 }
    /^[[:space:]]*#/ { print; next }
    /^[[:space:]]*XFREE_MENU_MODE=/ {
      if (updated == 0) {
        print "XFREE_MENU_MODE='\''" mode "'\''"
        updated=1
      }
      next
    }
    { print }
    END {
      if (updated == 0)
        print "XFREE_MENU_MODE='\''" mode "'\''"
    }
  ' "$config_file" >"$tmp_file"
  mv "$tmp_file" "$config_file"
}

menu_mode_set() {
  case "$1" in
    expert) export XFREE_MENU_MODE=expert; menu_mode_persist expert ;;
    *) export XFREE_MENU_MODE=normal; menu_mode_persist normal ;;
  esac
}

menu_mode_toggle() {
  if _menu_expert_mode; then
    menu_mode_set normal
  else
    menu_mode_set expert
  fi
}

_menu_item_visible() {
  vis="${1:-}"
  case "$vis" in
    expert) _menu_expert_mode ;;
    *) return 0 ;;
  esac
}

ui_cleanup() {
  dir="${UI_TMP_ROOT:-}"

  [ -n "$dir" ] || return 0
  [ -d "$dir" ] || return 0

  case "$dir" in
    /tmp/*)
      rm -rf -- "$dir" 2>/dev/null || true
      ;;
  esac

  UI_TMP_ROOT=""
}

# Do not trap INT/TERM -> ui_cleanup: the shell continues after the trap and
# ui_run_with_output (and others) may still write under UI_TMP_ROOT -> "nonexistent directory".
# Cleanup runs once via EXIT after normal exit or exit from INT/TERM traps below.
#
# Bash: subshells inherit EXIT traps, but $$ is still the parent pid — guard with
# BASHPID so `( ui_menu_invoke_with_output … )` does not rm UI_TMP_ROOT early.
# Ash/dash (OpenWrt /bin/sh): no BASHPID; EXIT traps are not inherited by
# subshells, so a bare ui_cleanup trap is correct. Never expand bare $BASHPID
# under set -u (menu.gen.sh) — that aborts xft on the router.
ui_trap_cleanup_on_exit() {
  if [ -n "${BASHPID:-}" ]; then
    UI_CLEANUP_OWNER_BASHPID=$BASHPID
    export UI_CLEANUP_OWNER_BASHPID
    trap '[ "${BASHPID:-}" = "${UI_CLEANUP_OWNER_BASHPID:-}" ] && ui_cleanup' EXIT
  else
    trap 'ui_cleanup' EXIT
  fi
  trap 'exit 130' INT
  trap 'exit 143' TERM
}

ui_pause() {
  printf '\nНажмите Enter для продолжения...'
  read -r _
}

# Строки-итоги для компактного textbox (полный лог уже был в консоли / batch log).
# Совпадает с: "[*] Итог проверки:…", "[*] Готово обновление:…", "[*] Готово применение:…", "[*] Готово индекс:…".
ui_extract_output_summary_lines() {
  _in="${1:-}"
  _out="${2:-}"
  [ -n "$_in" ] && [ -f "$_in" ] && [ -n "$_out" ] || return 1
  # shellcheck disable=SC2016
  grep -E '^\[\*\] (Итог проверки:|Готово обновление:|Готово применение:|Готово индекс:)' "$_in" 2>/dev/null | tr -d '\r' > "$_out" || true
  [ -s "$_out" ]
}

# $1=full log file → печатает путь файла для textbox (summary или full).
# UI_RUN_WITH_OUTPUT_*_DIALOG_SUMMARY=1: при успехе только строки итога; иначе полный лог.
ui_dialog_log_file_for_display() {
  _src="${1:-}"
  _want_summary="${2:-0}"
  _summary="$UI_TMP_ROOT/run-summary.$$"
  if [ "$_want_summary" = "1" ] && ui_extract_output_summary_lines "$_src" "$_summary"; then
    printf '%s\n' "$_summary"
    return 0
  fi
  printf '%s\n' "$_src"
}

# Несколько ui_run_with_output подряд: живой лог на tty, один textbox в конце (без Enter между шагами).
# UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY=1 — в успехе textbox только со строками итога (см. ui_extract_output_summary_lines).
ui_run_with_output_batch_begin() {
  UI_RUN_WITH_OUTPUT_BATCH_DEPTH=$(( ${UI_RUN_WITH_OUTPUT_BATCH_DEPTH:-0} + 1 ))
  if [ "$UI_RUN_WITH_OUTPUT_BATCH_DEPTH" -eq 1 ]; then
    UI_TMP_ROOT="${UI_TMP_ROOT:-/tmp/ui.$$}"
    mkdir -p "$UI_TMP_ROOT"
    UI_RUN_WITH_OUTPUT_BATCH_LOG="$UI_TMP_ROOT/run-batch.$$"
    : > "$UI_RUN_WITH_OUTPUT_BATCH_LOG"
    export UI_RUN_WITH_OUTPUT_BATCH_LOG
    export UI_RUN_WITH_OUTPUT_SUPPRESS_FINISH=1
    UI_RUN_WITH_OUTPUT_BATCH_WORST_RC=0
    export UI_RUN_WITH_OUTPUT_BATCH_WORST_RC
  fi
}

ui_run_with_output_batch_end() {
  title="${1:-Операция}"
  depth="${UI_RUN_WITH_OUTPUT_BATCH_DEPTH:-0}"
  [ "$depth" -gt 0 ] || return 0

  UI_RUN_WITH_OUTPUT_BATCH_DEPTH=$(( depth - 1 ))
  [ "$UI_RUN_WITH_OUTPUT_BATCH_DEPTH" -gt 0 ] && return 0

  unset UI_RUN_WITH_OUTPUT_SUPPRESS_FINISH || true
  worst_rc="${UI_RUN_WITH_OUTPUT_BATCH_WORST_RC:-0}"
  unset UI_RUN_WITH_OUTPUT_BATCH_WORST_RC || true

  log_file="${UI_RUN_WITH_OUTPUT_BATCH_LOG:-}"
  unset UI_RUN_WITH_OUTPUT_BATCH_LOG || true

  if [ -z "${log_file:-}" ] || [ ! -s "$log_file" ]; then
    return "$worst_rc"
  fi

  if ui_have_whiptail; then
    if [ "$worst_rc" -eq 0 ]; then
      dialog_file="$(ui_dialog_log_file_for_display "$log_file" "${UI_RUN_WITH_OUTPUT_BATCH_DIALOG_SUMMARY:-0}")"
      ui_show_textbox "$title" "$dialog_file"
    else
      printf '\n[!] Операция завершилась с ошибкой (code=%s).\n' "$worst_rc" >/dev/tty 2>/dev/null || \
        printf '\n[!] Операция завершилась с ошибкой (code=%s).\n' "$worst_rc"
      printf 'Нажмите Enter для просмотра полного лога...\n' >/dev/tty 2>/dev/null || true
      read -r _ </dev/tty 2>/dev/null || true
      ui_show_textbox "$title: ошибка" "$log_file"
    fi
  else
    cat "$log_file"
    ui_pause
  fi
  return "$worst_rc"
}

ui_msgbox() {
  title="$1"
  text="${2:-}"

  [ -n "$text" ] || text=" "

  case "$text" in
    *"$NL") ;;
    *) text="${text}${NL}" ;;
  esac

  text="${text}${NL}"

  ui_capture_whiptail \
    whiptail --title "$title" \
    --msgbox "$text" \
    "${UI_MSGBOX_HEIGHT}" "${UI_WIDTH}"
}

ui_show_textbox() {
  title="$1"
  file="$2"
  height="${3:-28}"
  width="${4:-110}"

  if ui_have_whiptail; then
    [ -f "$file" ] || {
      ui_msgbox "$title" "Файл отчёта не найден."
      return 1
    }
    ui_clamp_whiptail_box "$height" "$width"
    ui_capture_whiptail \
      whiptail --title "$title" --scrolltext --textbox "$file" "$UI_CLAMP_HEIGHT" "$UI_CLAMP_WIDTH"
  else
    cat "$file"
  fi
}

# Текст в памяти → временный файл → ui_show_textbox (whiptail --textbox принимает только путь).
ui_show_textbox_text() {
  title="$1"
  text="$2"
  height="${3:-28}"
  width="${4:-110}"
  tmp=""

  tmp="$(mktemp /tmp/xfree-ui-textbox.XXXXXX 2>/dev/null || true)"
  if [ -z "$tmp" ] || [ ! -e "$tmp" ]; then
    tmp="/tmp/xfree-ui-textbox-$$"
  fi
  printf '%s\n' "$text" >"$tmp"
  ui_show_textbox "$title" "$tmp" "$height" "$width"
  rm -f "$tmp"
}

ui_inputbox() {
  title="$1"
  prompt="${2:-}"
  default_value="${3:-}"

  [ -n "$prompt" ] || prompt=" "

  case "$prompt" in
    *"$NL") ;;
    *) prompt="${prompt}${NL}" ;;
  esac

  prompt="${prompt}${NL}"

  ui_capture_whiptail \
    whiptail --title "$title" \
    --inputbox "$prompt" \
    "${UI_INPUTBOX_HEIGHT}" "${UI_WIDTH}" \
    "$default_value"
}

ui_confirm() {
  title="$1"
  text="${2:-}"

  [ -n "$text" ] || text=" "

  case "$text" in
    *"$NL") ;;
    *) text="${text}${NL}" ;;
  esac

  text="${text}${NL}"

  ui_capture_whiptail \
    whiptail --title "$title" \
    --yesno "$text" \
    "${UI_CONFIRM_HEIGHT}" "${UI_WIDTH}"
}

ui_menu() {
  title="$1"
  prompt="$2"
  height="${3:-$UI_MENU_HEIGHT}"
  width="${4:-$UI_WIDTH}"
  menu_height="$5"
  shift 5

  ui_clamp_whiptail_box "$height" "$width" "$menu_height"
  height="$UI_CLAMP_HEIGHT"
  width="$UI_CLAMP_WIDTH"
  menu_height="$UI_CLAMP_LIST_HEIGHT"

  _ui_menu_notags=""
  [ -n "${UI_MENU_NOTAGS:-}" ] && _ui_menu_notags="--notags"

  if [ -n "${UI_MENU_DEFAULT_ITEM:-}" ]; then
    ui_capture_whiptail \
      whiptail --title "$title" \
      --default-item "$UI_MENU_DEFAULT_ITEM" \
      --menu "$prompt" \
      "$height" "$width" "$menu_height" \
      $_ui_menu_notags \
      "$@"
  else
    ui_capture_whiptail \
      whiptail --title "$title" \
      --menu "$prompt" \
      "$height" "$width" "$menu_height" \
      $_ui_menu_notags \
      "$@"
  fi
}

ui_checklist() {
  title="$1"
  prompt="$2"
  height="$3"
  width="$4"
  list_height="$5"
  shift 5

  # Stable partition: selected (ON) first, then the rest; relative order within
  # each group is unchanged so callers keep their existing sort.
  _ui_cl_n=0
  _ui_cl_on=
  _ui_cl_off=
  while [ "$#" -ge 3 ]; do
    _ui_cl_n=$((_ui_cl_n + 1))
    eval "_ui_cl_tag_${_ui_cl_n}=\$1"
    eval "_ui_cl_item_${_ui_cl_n}=\$2"
    eval "_ui_cl_state_${_ui_cl_n}=\$3"
    case "$3" in
      ON|on|On) _ui_cl_on="${_ui_cl_on} ${_ui_cl_n}" ;;
      *) _ui_cl_off="${_ui_cl_off} ${_ui_cl_n}" ;;
    esac
    shift 3
  done

  set --
  for _ui_cl_i in ${_ui_cl_on} ${_ui_cl_off}; do
    eval "set -- \"\$@\" \"\$_ui_cl_tag_${_ui_cl_i}\" \"\$_ui_cl_item_${_ui_cl_i}\" \"\$_ui_cl_state_${_ui_cl_i}\""
  done

  _ui_cl_i=1
  while [ "$_ui_cl_i" -le "$_ui_cl_n" ]; do
    eval "unset _ui_cl_tag_${_ui_cl_i} _ui_cl_item_${_ui_cl_i} _ui_cl_state_${_ui_cl_i}"
    _ui_cl_i=$((_ui_cl_i + 1))
  done
  unset _ui_cl_n _ui_cl_on _ui_cl_off _ui_cl_i

  ui_clamp_whiptail_box "$height" "$width" "$list_height"
  height="$UI_CLAMP_HEIGHT"
  width="$UI_CLAMP_WIDTH"
  list_height="$UI_CLAMP_LIST_HEIGHT"

  if ui_have_whiptail; then
    ui_capture_whiptail \
      whiptail --title "$title" \
      --checklist "$prompt" \
      "$height" "$width" "$list_height" \
      "$@" --notags --separate-output
    return $?
  fi

  return 1
}

ui_select_file_from_dir() {
  title="$1"
  prompt="$2"
  dir="$3"
  pattern="${4:-*}"

  [ -d "$dir" ] || die "Каталог не найден: $dir"

  set -- "$dir"/$pattern
  [ -e "$1" ] || die "Нет файлов $pattern в $dir"

  items=""
  idx=1
  for f in "$dir"/$pattern; do
    [ -e "$f" ] || continue
    base="$(basename "$f")"
    items="$items $idx $base"
    eval "UI_SEL_$idx=\"\$f\""
    idx=$((idx + 1))
  done

  choice="$(ui_menu "$title" "$prompt" 20 80 10 $items)" || return 1
  [ -n "${choice:-}" ] || return 1

  eval "selected=\${UI_SEL_$choice:-}"
  [ -n "${selected:-}" ] || return 1
  printf '%s\n' "$selected"
}

ui_select_dir_from_dir() {
  title="$1"
  prompt="$2"
  dir="$3"

  [ -d "$dir" ] || die "Каталог не найден: $dir"

  items=""
  idx=1
  found=0
  for d in "$dir"/*; do
    [ -d "$d" ] || continue
    found=1
    base="$(basename "$d")"
    items="$items $idx $base"
    eval "UI_DIRSEL_$idx=\"\$d\""
    idx=$((idx + 1))
  done

  [ "$found" = "1" ] || die "Нет подкаталогов в $dir"

  choice="$(ui_menu "$title" "$prompt" 20 80 10 $items)" || return 1
  [ -n "${choice:-}" ] || return 1

  eval "selected=\${UI_DIRSEL_$choice:-}"
  [ -n "${selected:-}" ] || return 1
  printf '%s\n' "$selected"
}

ui_menu_or_back() {
  result="$(ui_menu "$@" || true)"
  [ -n "${result:-}" ] || return 0
  printf '%s\n' "$result"
}

ui_inputbox_or_back() {
  result="$(ui_inputbox "$@" || true)"
  [ -n "${result:-}" ] || return 0
  printf '%s\n' "$result"
}

ui_select_file_or_back() {
  result="$(ui_select_file_from_dir "$@" || true)"
  [ -n "${result:-}" ] || return 0
  printf '%s\n' "$result"
}

ui_select_dir_or_back() {
  result="$(ui_select_dir_from_dir "$@" || true)"
  [ -n "${result:-}" ] || return 0
  printf '%s\n' "$result"
}

ui_checklist_or_back() {
  result="$(ui_checklist "$@" || true)"
  [ -n "${result:-}" ] || return 0
  printf '%s\n' "$result"
}

ui_select_from_lines() {
  title="$1"
  prompt="$2"
  lines="$3"
  height="${4:-20}"
  width="${5:-90}"
  menu_height="${6:-10}"

  [ -n "${lines:-}" ] || return 1

  map="${UI_TMP_ROOT:-/tmp}/select-lines.$$"
  : > "$map"

  idx=1
  while IFS= read -r line || [ -n "$line" ]; do
    [ -n "$line" ] || continue
    printf '%s\t%s\n' "$idx" "$line" >> "$map"
    idx=$((idx + 1))
  done <<EOF2
$lines
EOF2

  [ -s "$map" ] || return 1

  set --
  while IFS="$(printf '\t')" read -r key line || [ -n "$key$line" ]; do
    [ -n "$key" ] || continue
    set -- "$@" "$key" "$line"
  done < "$map"

  choice="$(ui_menu "$title" "$prompt" "$height" "$width" "$menu_height" "$@" || true)"
  [ -n "${choice:-}" ] || return 1

  selected="$(awk -F '\t' -v want="$choice" '$1 == want { print $2; exit }' "$map")"
  [ -n "${selected:-}" ] || return 1
  printf '%s\n' "$selected"
}

ui_strip_ansi_file() {
  src="$1"
  dst="$2"

  awk '
    {
      gsub(/\r/, "")
      while (match($0, /\033\[[0-9;?]*[A-Za-z]/)) {
        $0 = substr($0, 1, RSTART - 1) substr($0, RSTART + RLENGTH)
      }
      print
    }
  ' "$src" > "$dst"
}

ui_run_script() {
  script="$1"
  shift || true

  [ -e "$script" ] || {
    warn "Скрипт не найден: $script"
    ui_pause
    return 1
  }

  [ -x "$script" ] || chmod +x "$script" 2>/dev/null || true
  [ -x "$script" ] || {
    warn "Скрипт не исполняем: $script"
    ui_pause
    return 1
  }

  ui_prepare_tty
  "$script" "$@"
  rc=$?
  ui_prepare_tty
  return $rc
}

# Встраивание готового меню: отдельный entrypoint (обычно */menu.sh), который сам
# делает ui_init / цикл whiptail через lib/ui.sh. Доп. аргументы передаются в скрипт.
# Ошибки выполнения не рвут вызывающее меню (как в корневом menu.sh run_menu_script).
ui_run_menu_script() {
  script="$1"
  shift || true

  [ -f "$script" ] || {
    ui_msgbox "Ошибка" "Скрипт не найден: $script"
    return 0
  }

  [ -x "$script" ] || chmod +x "$script" 2>/dev/null || true
  ui_run_script "$script" "$@" || true
  return 0
}

# Многострочный ввод с TTY: единый механизм с system/prepare-template (lib/proton-manual-conf-capture.sh):
# nano при наличии, иначе vi, иначе cat+Ctrl+D. Переменная PROTON_MANUAL_CONF_EDITOR=nano|vi|cat.
# Usage:
#   ui_capture_tty_multiline_to_file <banner_title> <target_file> [continuation_hint]
# Returns:
#   0 — ввод завершён
#   1 — отмена / ошибка
ui_capture_tty_multiline_to_file() {
  title="$1"
  target_file="$2"
  continuation_hint="${3:-Сохраните файл в редакторе или завершите ввод в cat — затем продолжится сценарий.}"

  [ -n "$target_file" ] || return 1

  command -v proton_manual_conf_capture_to_file >/dev/null 2>&1 || {
    warn "ui_capture_tty_multiline_to_file: не найден lib/proton-manual-conf-capture.sh (ожидался $PROTON_MANUAL_CONF_CAPTURE_SH)"
    return 1
  }

  ui_prepare_tty
  if ! proton_manual_conf_capture_to_file "$target_file" "$title" "$continuation_hint"; then
    ui_prepare_tty
    return 1
  fi
  ui_prepare_tty
  return 0
}

# Совместимость: старое имя — тот же механизм, что ui_capture_tty_multiline_to_file.
ui_capture_stdin_to_file() {
  ui_capture_tty_multiline_to_file "$@"
}

ui_run_with_output() {
  title="$1"
  shift

  UI_TMP_ROOT="${UI_TMP_ROOT:-/tmp/ui.$$}"
  mkdir -p "$UI_TMP_ROOT"
  run_mode="${UI_RUN_WITH_OUTPUT_MODE:-live-and-textbox}"

  raw="$UI_TMP_ROOT/run.raw.$$"
  out="$UI_TMP_ROOT/run.$$"
  cmd_rc=0
  # CR из CRLF-файлов/env ломает case *" $cmd_rc "* (например 10\r).
  ok_codes=" $(printf '%s' "${UI_RUN_WITH_OUTPUT_OK_CODES:-0}" | tr -d '\r') "
  treated_ok=0

  : > "$raw"
  : > "$out"

  if ui_have_whiptail && [ "$run_mode" = "live-and-textbox" ]; then
    if [ "${UI_RUN_WITH_OUTPUT_SUPPRESS_FINISH:-0}" != "1" ]; then
      clear >/dev/tty 2>/dev/null || true
    fi
    printf '\n=== %s ===\n\n' "$title" >/dev/tty
    if [ "${UI_RUN_WITH_OUTPUT_SUPPRESS_FINISH:-0}" != "1" ]; then
      printf 'Выполняется команда. Живой лог выводится ниже.\n' >/dev/tty
      printf 'После завершения будет показан полный лог.\n\n' >/dev/tty
    fi
  fi

  case "$run_mode" in
    live-and-textbox)
      # fifo+script на OpenWrt часто не стримит (полная буферизация в pipe).
      # tail -f по растущему файлу — тот же приём, что в ui_bg_task_follow_log.
      tail_pid=""
      if ui_have_whiptail; then
        tail -n 0 -f "$raw" >/dev/tty 2>/dev/null &
        tail_pid=$!
      fi

      common_exec_streaming "$@" >>"$raw" 2>&1 || cmd_rc=$?

      if [ -n "${tail_pid:-}" ]; then
        sleep 1
        kill "$tail_pid" 2>/dev/null || true
        wait "$tail_pid" 2>/dev/null || true
      fi
      ;;
    textbox)
      common_exec_streaming "$@" >"$raw" 2>&1 || cmd_rc=$?
      ;;
    *)
      die "ui_run_with_output: неподдерживаемый режим '$run_mode'"
      ;;
  esac

  ui_strip_ansi_file "$raw" "$out"

  case "$ok_codes" in
    *" $cmd_rc "*) treated_ok=1 ;;
    *) treated_ok=0 ;;
  esac

  # Для UI: «успех» = код из OK_CODES (в т.ч. 10/11 = drift найден).
  # Наружу из ui_run_with_output при treated_ok возвращаем 0, чтобы batch/итог
  # не показывали «завершилось с ошибкой» на информационных кодах.
  UI_RUN_WITH_OUTPUT_LAST_RC="$cmd_rc"
  export UI_RUN_WITH_OUTPUT_LAST_RC

  if [ "$treated_ok" -eq 1 ]; then
    [ -s "$out" ] || printf 'Готово.\n' > "$out"
  else
    [ -s "$out" ] || printf 'Ошибка выполнения.\n' > "$out"
  fi

  if [ "${UI_RUN_WITH_OUTPUT_SUPPRESS_FINISH:-0}" = "1" ]; then
    if [ -n "${UI_RUN_WITH_OUTPUT_BATCH_LOG:-}" ]; then
      {
        printf '=== %s ===\n' "$title"
        cat "$out"
        printf '\n'
      } >> "$UI_RUN_WITH_OUTPUT_BATCH_LOG"
    fi
    if [ "$treated_ok" -eq 0 ]; then
      UI_RUN_WITH_OUTPUT_BATCH_WORST_RC="$cmd_rc"
      [ "${UI_RUN_WITH_OUTPUT_BATCH_WORST_RC:-0}" -ne 0 ] || UI_RUN_WITH_OUTPUT_BATCH_WORST_RC=1
      export UI_RUN_WITH_OUTPUT_BATCH_WORST_RC
      return "$cmd_rc"
    fi
    return 0
  fi

  if ui_have_whiptail; then
    if [ "$run_mode" = "live-and-textbox" ]; then
      printf '\n' >/dev/tty
      if [ "$treated_ok" -eq 1 ]; then
        printf '[*] Операция завершена успешно.\n' >/dev/tty
      else
        printf '[!] Операция завершилась с ошибкой (code=%s).\n' "$cmd_rc" >/dev/tty
      fi
      if [ "${UI_RUN_WITH_OUTPUT_SKIP_ENTER_BEFORE_TEXTBOX:-0}" != "1" ]; then
        if [ "${UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY:-0}" = "1" ]; then
          printf 'Нажмите Enter для просмотра итога...\n' >/dev/tty
        else
          printf 'Нажмите Enter для просмотра полного лога...\n' >/dev/tty
        fi
        read -r _ </dev/tty || true
      fi
    fi

    if [ "$treated_ok" -eq 1 ]; then
      # UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY=1 — компактный итог; live-лог уже ушёл в tty.
      dialog_file="$(ui_dialog_log_file_for_display "$out" "${UI_RUN_WITH_OUTPUT_DIALOG_SUMMARY:-0}")"
      ui_show_textbox "$title" "$dialog_file"
      return 0
    fi
    ui_show_textbox "$title: ошибка" "$out"
    return "$cmd_rc"
  fi

  printf '\n'
  if [ "$treated_ok" -eq 1 ]; then
    printf '[*] Операция завершена успешно.\n'
    ui_pause
    return 0
  fi
  printf '[!] Операция завершилась с ошибкой (code=%s).\n' "$cmd_rc"

  ui_pause
  return "$cmd_rc"
}

ui_warn() { warn "$@"; }
ui_log() { info "$@"; }
ui_die() { die "$@"; }

# Единый запуск из меню: lib/ui/components/menu-invoke.sh (см. docs/ui/menu-patterns-audit.md, B1).
# shellcheck disable=SC1090
[ -f "$UI_COMPONENTS_DIR/menu-invoke.sh" ] && . "$UI_COMPONENTS_DIR/menu-invoke.sh"
