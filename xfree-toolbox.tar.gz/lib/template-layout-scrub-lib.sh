#!/bin/sh
# shellcheck shell=sh

# Shared template scrub for profile-like layouts.
# Args:
#   $1 - export/profile root
#   $2 - proton session mode: include|exclude (default: exclude)
scrub_iface_source_meta_for_template() {
    meta_file="$1"
    [ -f "$meta_file" ] || return 0

    generator_kind="$(awk -F '=' '
        $1 == "GENERATOR_KIND" {
            v = substr($0, index($0, "=") + 1)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
            gsub(/^\047|\047$/, "", v)
            print v
            exit
        }
    ' "$meta_file" 2>/dev/null || true)"

    case "$generator_kind" in
        proton)
            awk '
                BEGIN { profile_label_done=0 }
                /^SESSION_NAME=/ { print "SESSION_NAME='\''***RECREATE***'\''"; next }
                /^SESSION_DIR=/ { print "SESSION_DIR='\''***RECREATE***'\''"; next }
                /^SERVER_ID=/ { print "SERVER_ID='\''***RECREATE***'\''"; next }
                /^PEER_PUBLIC_KEY=/ { print "PEER_PUBLIC_KEY='\''***RECREATE***'\''"; next }
                /^ENDPOINT=/ { print "ENDPOINT='\''***RECREATE***'\''"; next }
                /^ENDPOINT_HOST=/ { print "ENDPOINT_HOST='\''***RECREATE***'\''"; next }
                /^ENDPOINT_PORT=/ { print "ENDPOINT_PORT='\''***RECREATE***'\''"; next }
                /^PEER_IP=/ { print "PEER_IP='\''***RECREATE***'\''"; next }
                /^PEER_NAME=/ { print "PEER_NAME='\''***RECREATE***'\''"; next }
                /^PROFILE_LABEL=/ {
                    print "PROFILE_LABEL='\''template proton profile'\''"
                    profile_label_done=1
                    next
                }
                { print }
                END {
                    if (!profile_label_done) print "PROFILE_LABEL='\''template proton profile'\''"
                }
            ' "$meta_file" > "$meta_file.tmp"
            mv "$meta_file.tmp" "$meta_file"
            ;;
        warp)
            awk '
                BEGIN { profile_label_done=0 }
                /^SERVER_ID=/ { print "SERVER_ID='\''***RECREATE***'\''"; next }
                /^ENDPOINT=/ { print "ENDPOINT='\''***RECREATE***'\''"; next }
                /^ENDPOINT_HOST=/ { print "ENDPOINT_HOST='\''***RECREATE***'\''"; next }
                /^ENDPOINT_PORT=/ { print "ENDPOINT_PORT='\''***RECREATE***'\''"; next }
                /^ENDPOINT_LABEL=/ { print "ENDPOINT_LABEL='\''***RECREATE***'\''"; next }
                /^PROFILE_LABEL=/ {
                    print "PROFILE_LABEL='\''template warp profile'\''"
                    profile_label_done=1
                    next
                }
                { print }
                END {
                    if (!profile_label_done) print "PROFILE_LABEL='\''template warp profile'\''"
                }
            ' "$meta_file" > "$meta_file.tmp"
            mv "$meta_file.tmp" "$meta_file"
            ;;
    esac
}

template_iter_iface_config_dirs() {
    export_root="$1"
    interfaces_dir="$export_root/iface-routing/interfaces"
    [ -d "$interfaces_dir" ] || return 0

    # Use the same shared interface discovery as runtime scripts.
    if command -v common_list_domain_interfaces >/dev/null 2>&1; then
        common_list_domain_interfaces "$interfaces_dir" | while IFS= read -r iface; do
            [ -n "$iface" ] || continue
            printf '%s/%s/config\n' "$interfaces_dir" "$iface"
        done
        return 0
    fi

    find "$interfaces_dir" -type d -path '*/config' 2>/dev/null
}

xfree_scrub_template_layout() {
    export_root="$1"
    proton_session_mode="${2:-exclude}"

    : > "$export_root/TEMPLATE"
    mkdir -p "$export_root/iface-routing/interfaces"
    : > "$export_root/iface-routing/TEMPLATE"
    : > "$export_root/iface-routing/interfaces/TEMPLATE"

    find "$export_root/iface-routing/interfaces" -type f \( -path '*/config/source.conf' -o -path '*/config/network.uci' \) 2>/dev/null \
        | while IFS= read -r f; do
            [ -n "$f" ] && rm -f "$f"
        done

    template_iter_iface_config_dirs "$export_root" | while IFS= read -r config_dir; do
            [ -n "$config_dir" ] || continue
            if [ -f "$config_dir/source.conf.meta" ]; then
                : > "$config_dir/TEMPLATE"
                iface_dir="$(dirname -- "$config_dir")"
                [ -d "$iface_dir" ] && : > "$iface_dir/TEMPLATE"
                scrub_iface_source_meta_for_template "$config_dir/source.conf.meta"
            fi
        done

    mkdir -p "$export_root/awg-ingress"
    : > "$export_root/awg-ingress/TEMPLATE"

    rm -f "$export_root/awg-ingress/server/private.key" 2>/dev/null || true
    rm -f "$export_root/awg-ingress/server/public.key" 2>/dev/null || true

    if [ -f "$export_root/awg-ingress/server/server.env" ]; then
        awk -F '=' '
            BEGIN { updated=0 }
            $1 == "AWG_INGRESS_PUBLIC_KEY" { print "AWG_INGRESS_PUBLIC_KEY=***RECREATE***"; updated=1; next }
            { print }
            END { if (!updated) print "AWG_INGRESS_PUBLIC_KEY=***RECREATE***" }
        ' "$export_root/awg-ingress/server/server.env" > "$export_root/awg-ingress/server/server.env.tmp"
        mv "$export_root/awg-ingress/server/server.env.tmp" "$export_root/awg-ingress/server/server.env"
    fi

    find "$export_root/awg-ingress/peers" -type f \( -name 'private.key' -o -name 'public.key' -o -name 'client.conf' \) 2>/dev/null \
        | while IFS= read -r f; do
            [ -n "$f" ] && rm -f "$f"
        done

    find "$export_root/awg-ingress/peers" -type f -name 'peer.env' 2>/dev/null \
        | while IFS= read -r f; do
            [ -n "$f" ] || continue
            awk -F '=' '
                BEGIN {
                    have_pub=0
                    have_endpoint=0
                }
                $1 == "PEER_PUBLIC_KEY" { print "PEER_PUBLIC_KEY=***RECREATE***"; have_pub=1; next }
                $1 == "PEER_ENDPOINT" { print "PEER_ENDPOINT=***PROMPT***"; have_endpoint=1; next }
                { print }
                END {
                    if (!have_pub) print "PEER_PUBLIC_KEY=***RECREATE***"
                    if (!have_endpoint) print "PEER_ENDPOINT=***PROMPT***"
                }
            ' "$f" > "$f.tmp"
            mv "$f.tmp" "$f"
        done

    # peers.tsv is runtime metadata; template must not contain it.
    rm -f "$export_root/awg-ingress/peers.tsv" 2>/dev/null || true

    if [ -f "$export_root/awg-ingress/config/local.conf" ]; then
        awk -F '=' '
            BEGIN { updated=0 }
            $1 == "AWG_INGRESS_PEER_ENDPOINT" {
                print "AWG_INGRESS_PEER_ENDPOINT='\''***PROMPT***'\''"
                updated=1
                next
            }
            { print }
            END {
                if (!updated) print "AWG_INGRESS_PEER_ENDPOINT='\''***PROMPT***'\''"
            }
        ' "$export_root/awg-ingress/config/local.conf" > "$export_root/awg-ingress/config/local.conf.tmp"
        mv "$export_root/awg-ingress/config/local.conf.tmp" "$export_root/awg-ingress/config/local.conf"
    fi

    rm -rf "$export_root/vpn/warp" 2>/dev/null || true
    if [ "$proton_session_mode" = "exclude" ]; then
        rm -rf "$export_root/vpn/proton/sessions" 2>/dev/null || true
    fi

    mkdir -p "$export_root/vpn"
    rm -f "$export_root/vpn/TEMPLATE" "$export_root/vpn/TEMPLATE-NOTES.txt" 2>/dev/null || true
}
