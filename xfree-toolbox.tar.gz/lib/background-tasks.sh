#!/bin/sh
# shellcheck shell=sh
# Unified background task runtime state.

XFREE_BG_ROOT="${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}"
XFREE_BG_LOCK_DIR="${XFREE_BG_LOCK_DIR:-$XFREE_BG_ROOT/lock}"
XFREE_BG_PID_FILE="${XFREE_BG_PID_FILE:-$XFREE_BG_ROOT/pid}"
XFREE_BG_META_FILE="${XFREE_BG_META_FILE:-$XFREE_BG_ROOT/meta.current}"
XFREE_BG_LAST_META_FILE="${XFREE_BG_LAST_META_FILE:-$XFREE_BG_ROOT/meta.last}"

BG_TASK_PID=""
BG_TASK_NAME=""
BG_TASK_LOG_FILE=""
BG_TASK_STARTED_AT=""
BG_TASK_LED_HOOK_ENGAGED=""

bg_tasks_led_hook_start() {
    BG_TASK_LED_HOOK_ENGAGED=""
    [ -n "${XFREE_TOOLBOX_ROOT:-}" ] || return 0
    [ -f "${XFREE_TOOLBOX_ROOT}/lib/led/led-lib.sh" ] || return 0
    # shellcheck disable=SC1090
    . "${XFREE_TOOLBOX_ROOT}/lib/led/led-lib.sh" 2>/dev/null || return 0
    command -v hardware_led_bg_task_blink_start >/dev/null 2>&1 || return 0
    if hardware_led_bg_task_blink_start 2>/dev/null; then
        BG_TASK_LED_HOOK_ENGAGED="1"
    fi
    return 0
}

bg_tasks_led_hook_stop() {
    [ "${BG_TASK_LED_HOOK_ENGAGED:-}" = "1" ] || return 0
    [ -n "${XFREE_TOOLBOX_ROOT:-}" ] || return 0
    [ -f "${XFREE_TOOLBOX_ROOT}/lib/led/led-lib.sh" ] || return 0
    # shellcheck disable=SC1090
    . "${XFREE_TOOLBOX_ROOT}/lib/led/led-lib.sh" 2>/dev/null || return 0
    command -v hardware_led_bg_task_blink_stop >/dev/null 2>&1 || return 0
    hardware_led_bg_task_blink_stop 2>/dev/null || true
    BG_TASK_LED_HOOK_ENGAGED=""
    return 0
}

bg_tasks_init() {
    mkdir -p "$XFREE_BG_ROOT" 2>/dev/null || true
}

bg_tasks_now() {
    date '+%Y-%m-%d %H:%M:%S %z' 2>/dev/null || date
}

bg_tasks_escape() {
    printf '%s' "${1:-}" | sed "s/'/'\\\\''/g"
}

bg_tasks_clear_runtime() {
    bg_tasks_led_hook_stop
    rm -f "$XFREE_BG_PID_FILE" "$XFREE_BG_META_FILE" 2>/dev/null || true
    rmdir "$XFREE_BG_LOCK_DIR" 2>/dev/null || true
}

bg_tasks_is_running() {
    BG_TASK_PID=""
    BG_TASK_NAME=""
    BG_TASK_LOG_FILE=""
    BG_TASK_STARTED_AT=""

    [ -f "$XFREE_BG_PID_FILE" ] || return 1
    _pid="$(cat "$XFREE_BG_PID_FILE" 2>/dev/null || true)"
    [ -n "$_pid" ] || {
        bg_tasks_clear_runtime
        return 1
    }

    if ! kill -0 "$_pid" 2>/dev/null; then
        bg_tasks_clear_runtime
        return 1
    fi

    BG_TASK_PID="$_pid"
    if [ -f "$XFREE_BG_META_FILE" ]; then
        # shellcheck disable=SC1090
        . "$XFREE_BG_META_FILE" 2>/dev/null || true
        BG_TASK_NAME="${TASK_NAME:-}"
        BG_TASK_LOG_FILE="${TASK_LOG_FILE:-}"
        BG_TASK_STARTED_AT="${STARTED_AT:-}"
    fi
    return 0
}

bg_tasks_start() {
    _task_name="${1:-}"
    _task_log_file="${2:-}"
    _task_cmd="${3:-}"
    [ -n "$_task_name" ] || return 1

    bg_tasks_init
    if bg_tasks_is_running; then
        return 1
    fi

    if ! mkdir "$XFREE_BG_LOCK_DIR" 2>/dev/null; then
        # lock may be stale
        if ! bg_tasks_is_running; then
            bg_tasks_clear_runtime
            mkdir "$XFREE_BG_LOCK_DIR" 2>/dev/null || return 1
        else
            return 1
        fi
    fi

    printf '%s\n' "$$" >"$XFREE_BG_PID_FILE" 2>/dev/null || true
    _started_at="$(bg_tasks_now)"
    {
        printf "TASK_NAME='%s'\n" "$(bg_tasks_escape "$_task_name")"
        printf "TASK_LOG_FILE='%s'\n" "$(bg_tasks_escape "$_task_log_file")"
        printf "TASK_COMMAND='%s'\n" "$(bg_tasks_escape "$_task_cmd")"
        printf "STARTED_AT='%s'\n" "$(bg_tasks_escape "$_started_at")"
        printf "TASK_PID='%s'\n" "$(bg_tasks_escape "$$")"
    } >"$XFREE_BG_META_FILE"
    bg_tasks_led_hook_start
    return 0
}

bg_tasks_finish() {
    _status="${1:-done}"
    _exit_code="${2:-0}"
    _finished_at="$(bg_tasks_now)"

    if [ -f "$XFREE_BG_META_FILE" ]; then
        cp -f "$XFREE_BG_META_FILE" "$XFREE_BG_LAST_META_FILE" 2>/dev/null || true
        {
            printf "FINISHED_AT='%s'\n" "$(bg_tasks_escape "$_finished_at")"
            printf "STATUS='%s'\n" "$(bg_tasks_escape "$_status")"
            printf "EXIT_CODE='%s'\n" "$(bg_tasks_escape "$_exit_code")"
        } >>"$XFREE_BG_LAST_META_FILE" 2>/dev/null || true
    fi

    bg_tasks_clear_runtime
    return 0
}

# Последняя завершённая задача (meta.last): STATUS, EXIT_CODE.
bg_tasks_read_last_meta() {
    BG_TASK_LAST_STATUS=""
    BG_TASK_LAST_EXIT_CODE=""
    BG_TASK_LAST_NAME=""
    BG_TASK_LAST_LOG_FILE=""

    [ -f "$XFREE_BG_LAST_META_FILE" ] || return 1
    # shellcheck disable=SC1090
    . "$XFREE_BG_LAST_META_FILE" 2>/dev/null || return 1
    BG_TASK_LAST_STATUS="${STATUS:-}"
    BG_TASK_LAST_EXIT_CODE="${EXIT_CODE:-}"
    BG_TASK_LAST_NAME="${TASK_NAME:-}"
    BG_TASK_LAST_LOG_FILE="${TASK_LOG_FILE:-}"
    return 0
}

# Подстраховка: exit=0 в meta, но в логе status=failed (старые trap/обёртки).
bg_tasks_exit_code_from_log() {
    _log="${1:-}"
    _default="${2:-0}"
    _line=""
    _erc=""

    [ -n "$_log" ] && [ -f "$_log" ] || {
        printf '%s\n' "$_default"
        return 0
    }

    _line="$(grep 'bg-task-run: finish' "$_log" 2>/dev/null | tail -n 1 || true)"
    case "$_line" in
        *status=failed*)
            _default=1
            ;;
    esac
    case "$_line" in
        *exit=*)
            _erc="${_line#*exit=}"
            _erc="${_erc%% *}"
            case "$_erc" in
                ''|*[!0-9]*) _erc="" ;;
            esac
            ;;
    esac

    if [ -n "$_erc" ] && [ "$_erc" -gt 0 ] 2>/dev/null; then
        printf '%s\n' "$_erc"
        return 0
    fi

    if grep -qE 'error: sync-update-apply pipeline failed|Установка прервана \(код' "$_log" 2>/dev/null; then
        printf '1\n'
        return 0
    fi

    printf '%s\n' "$_default"
}

# status=failed + EXIT_CODE=0 (старые bg-task-run) → ненулевой код для UI.
bg_tasks_resolve_exit_code() {
    _status="${1:-}"
    _code="${2:-0}"
    _log="${3:-}"

    if [ "$_status" != "done" ] && [ "${_code:-0}" -eq 0 ] 2>/dev/null; then
        _code=1
    fi
    if [ -n "$_log" ]; then
        _code="$(bg_tasks_exit_code_from_log "$_log" "$_code")"
    fi
    printf '%s\n' "$_code"
}
