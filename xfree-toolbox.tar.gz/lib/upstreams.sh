#!/bin/sh
# shellcheck shell=sh



upstreams__project_root() {
    if [ -n "${PROJECT_ROOT:-}" ] && [ -d "$PROJECT_ROOT" ]; then
        printf '%s\n' "$PROJECT_ROOT"
        return 0
    fi

    if command -v common_get_project_root >/dev/null 2>&1; then
        common_get_project_root "${1:-$PWD}"
        return 0
    fi

    if [ -n "${ROOT_DIR:-}" ] && [ -d "$ROOT_DIR" ]; then
        printf '%s\n' "$ROOT_DIR"
        return 0
    fi

    printf '%s\n' "${1:-$PWD}"
}

upstreams_get_dir() {
    start_dir="${1:-$PWD}"

    case "$start_dir" in
        */upstreams)
            if [ -d "$start_dir" ] && [ -f "$start_dir/menu.sh" ]; then
                printf '%s\n' "$start_dir"
                return 0
            fi
            ;;
    esac

    # Explicit override (iface-routing pins an absolute path here).
    if [ -n "${UPSTREAMS_DIR:-}" ]; then
        case "$UPSTREAMS_DIR" in
            /*)
                printf '%s\n' "$UPSTREAMS_DIR"
                ;;
            *)
                project_root="$(upstreams__project_root "$start_dir")"
                candidate="$project_root/$UPSTREAMS_DIR"
                if [ ! -d "$candidate" ] && [ "$(basename "$project_root")" = "$UPSTREAMS_DIR" ]; then
                    candidate="$project_root"
                fi
                printf '%s\n' "$candidate"
                ;;
        esac
        return 0
    fi

    # Prefer start_dir/upstreams when present (callers pass toolbox ROOT_DIR).
    # Defense in depth vs stale parent trees; primary fix is common_detect_project_root
    # recognizing lib/common.sh + upstreams/ and not climbing to /root.
    case "$start_dir" in
        /*)
            if [ -d "$start_dir/upstreams" ]; then
                printf '%s/upstreams\n' "$start_dir"
                return 0
            fi
            ;;
        *)
            if [ -d "$start_dir/upstreams" ]; then
                printf '%s/upstreams\n' "$start_dir"
                return 0
            fi
            ;;
    esac

    project_root="$(upstreams__project_root "$start_dir")"
    if [ -d "$project_root/upstreams" ]; then
        printf '%s/upstreams\n' "$project_root"
    elif [ "$(basename "$project_root")" = "upstreams" ] && [ -f "$project_root/menu.sh" ]; then
        printf '%s\n' "$project_root"
    else
        printf '%s/upstreams\n' "$project_root"
    fi
}

upstreams__normalize_name() {
    raw="${1:-}"

    if command -v common_normalize_token >/dev/null 2>&1; then
        common_normalize_token "$raw"
        return 0
    fi

    # Fallback for environments where lib/common.sh is not loaded.
    printf '%s' "$raw" \
        | tr -d '\r' \
        | tr 'A-Z' 'a-z' \
        | sed 's/[^a-z0-9._-]/-/g; s/-\{2,\}/-/g; s/^-//; s/-$//'
}

upstreams__module_conf_file() {
    printf '%s/upstream.conf\n' "$1"
}

upstreams__load_conf() {
    module_dir="$1"
    conf_file="$(upstreams__module_conf_file "$module_dir")"

    unset \
        UPSTREAM_NAME \
        UPSTREAM_TITLE \
        UPSTREAM_DESCRIPTION \
        UPSTREAM_ENABLED \
        2>/dev/null || true

    [ -f "$conf_file" ] || return 0

    tmp_conf="/tmp/upstream-conf.$$.$(date +%s 2>/dev/null || printf '0')"
    tr -d '\r' < "$conf_file" > "$tmp_conf"
    # Conf may reference optional vars (e.g. SCRIPT_DIR); never abort caller under set -u.
    _upstreams_nounset=0
    case $- in
        *u*) _upstreams_nounset=1 ;;
    esac
    set +u
    # shellcheck disable=SC1090
    . "$tmp_conf"
    if [ "$_upstreams_nounset" = "1" ]; then
        set -u
    fi
    unset _upstreams_nounset
    rm -f "$tmp_conf"
}

upstreams_module_enabled() {
    module_dir="$1"
    upstreams__load_conf "$module_dir"

    case "${UPSTREAM_ENABLED:-1}" in
        1) printf '1\n' ;;
        0) printf '0\n' ;;
        *) printf '1\n' ;;
    esac
}

upstreams_module_name() {
    module_dir="$1"
    upstreams__load_conf "$module_dir"

    [ -n "${UPSTREAM_NAME:-}" ] || return 1

    normalized="$(upstreams__normalize_name "$UPSTREAM_NAME")"
    [ -n "$normalized" ] || return 1

    printf '%s\n' "$normalized"
}

upstreams_module_title() {
    module_dir="$1"
    upstreams__load_conf "$module_dir"

    if [ -n "${UPSTREAM_TITLE:-}" ]; then
        printf '%s\n' "$(printf '%s' "$UPSTREAM_TITLE" | tr -d '\r')"
        return 0
    fi

    if name="$(upstreams_module_name "$module_dir" 2>/dev/null)"; then
        printf '%s\n' "$name"
        return 0
    fi

    printf '%s\n' "unknown"
}

upstreams_module_description() {
    module_dir="$1"
    upstreams__load_conf "$module_dir"

    if [ -n "${UPSTREAM_DESCRIPTION:-}" ]; then
        printf '%s\n' "$(printf '%s' "$UPSTREAM_DESCRIPTION" | tr -d '\r')"
        return 0
    fi

    printf '\n'
}

upstreams_module_script() {
    printf '%s/update-lists.sh\n' "$1"
}

upstreams_module_data_dir() {
    module_dir="$1"
    printf '%s/upstream\n' "$module_dir"
}

upstreams_is_manageable_module_dir() {
    module_dir="$1"
    [ -d "$module_dir" ] || return 1
    [ -f "$(upstreams__module_conf_file "$module_dir")" ] || return 1
    [ -f "$module_dir/update-lists.sh" ] || return 1
    upstreams_module_name "$module_dir" >/dev/null 2>&1 || return 1
    return 0
}

upstreams_is_data_module_dir() {
    module_dir="$1"
    upstreams_is_manageable_module_dir "$module_dir" || return 1
    dd="$(upstreams_module_data_dir "$module_dir")"
    [ -d "$dd" ] || return 1
    return 0
}

upstreams_list_all_modules_tsv() {
    start_dir="${1:-$PWD}"
    upstreams_dir="$(upstreams_get_dir "$start_dir")"

    [ -d "$upstreams_dir" ] || return 0

    # Каталог модуля — родитель upstream.conf (в т.ч. upstreams/vpn/).
    find "$upstreams_dir" -type f -name upstream.conf 2>/dev/null \
        | sort \
        | while IFS= read -r conf_path; do
        [ -n "$conf_path" ] || continue
        [ -f "$conf_path" ] || continue
        module_dir="${conf_path%/*}"
        [ -n "$module_dir" ] || continue
        upstreams_is_manageable_module_dir "$module_dir" || continue

        name="$(upstreams_module_name "$module_dir")"
        title="$(upstreams_module_title "$module_dir")"
        description="$(upstreams_module_description "$module_dir")"
        enabled="$(upstreams_module_enabled "$module_dir")"
        script="$(upstreams_module_script "$module_dir")"
        data_dir="$(upstreams_module_data_dir "$module_dir")"
        conf_file="$(upstreams__module_conf_file "$module_dir")"

        printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
            "$name" "$title" "$description" "$enabled" "$script" "$data_dir" "$conf_file"
    done
}

upstreams_list_modules_tsv() {
    start_dir="${1:-$PWD}"

    upstreams_list_all_modules_tsv "$start_dir" | while IFS="$(printf '\t')" read -r name title description enabled script data_dir conf_file; do
        [ -n "$name" ] || continue
        [ "$enabled" = "1" ] || continue

        printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
            "$name" "$title" "$description" "$script" "$data_dir" "$conf_file"
    done
}

upstreams_run_module_update() {
    module_dir="$1"
    script="$(upstreams_module_script "$module_dir")"
    enabled="$(upstreams_module_enabled "$module_dir")"

    if [ "$enabled" != "1" ]; then
        printf '[*] Пропуск отключённого upstream: %s\n' "$(upstreams_module_title "$module_dir")" >&2
        return 0
    fi

    [ -f "$script" ] || {
        printf '[!] Скрипт не найден: %s\n' "$script" >&2
        return 1
    }

    [ -x "$script" ] || chmod +x "$script" 2>/dev/null || true
    sh "$script"
}

upstreams_set_module_enabled() {
    module_dir="$1"
    enabled="$2"
    conf_file="$(upstreams__module_conf_file "$module_dir")"

    [ "$enabled" = "0" ] || [ "$enabled" = "1" ] || {
        printf '[!] Некорректное значение UPSTREAM_ENABLED: %s\n' "$enabled" >&2
        return 1
    }

    [ -f "$conf_file" ] || {
        printf '[!] Не найден конфиг: %s\n' "$conf_file" >&2
        return 1
    }

    tmp_file="${conf_file}.tmp.$$"

    if grep -q '^[[:space:]]*UPSTREAM_ENABLED=' "$conf_file" 2>/dev/null; then
        sed "s/^[[:space:]]*UPSTREAM_ENABLED=.*/UPSTREAM_ENABLED=\"$enabled\"/" "$conf_file" > "$tmp_file"
    else
        cat "$conf_file" > "$tmp_file"
        printf '\nUPSTREAM_ENABLED="%s"\n' "$enabled" >> "$tmp_file"
    fi

    mv "$tmp_file" "$conf_file"
}

upstreams__detect_kind() {
    file_name="$1"

    case "$file_name" in
        fqdn-*.lst|domains-*.lst)
            printf 'fqdn\n'
            ;;
        prefixes*.lst)
            printf 'prefix\n'
            ;;
        *)
            return 1
            ;;
    esac
}

upstreams_module_index_dir() {
    module_dir="$1"
    printf '%s/.index\n' "$module_dir"
}

upstreams_module_index_raw_file() {
    module_dir="$1"
    printf '%s/lists.raw.tsv\n' "$(upstreams_module_index_dir "$module_dir")"
}

# Index field 8: path relative to module data dir (…/upstream/), never absolute.
# At work time: abs = <src_root on this install> / <relative from index>.
# Same index works on profile-generator host and on the router.
upstreams_index_path_rel() {
    src_root="$1"
    abs_or_rel="$2"
    case "$abs_or_rel" in
        '')
            return 1
            ;;
        /*)
            # Legacy absolute rows (host or old router index): strip to rel only.
            case "$abs_or_rel" in
                "$src_root"/*)
                    printf '%s\n' "${abs_or_rel#"$src_root"/}"
                    return 0
                    ;;
                */upstream/*)
                    printf '%s\n' "${abs_or_rel##*/upstream/}"
                    return 0
                    ;;
                *)
                    return 1
                    ;;
            esac
            ;;
        *)
            printf '%s\n' "$abs_or_rel"
            return 0
            ;;
    esac
}

# Resolve index path for this install. Never returns a foreign absolute path as-is.
upstreams_index_path_abs() {
    src_root="$1"
    stored="$2"
    rel="$(upstreams_index_path_rel "$src_root" "$stored" 2>/dev/null || true)"
    [ -n "$rel" ] || return 1
    printf '%s/%s\n' "$src_root" "$rel"
}

upstreams_rebuild_module_index() {
    module_dir="$1"
    source_name="${2:-}"
    src_root="${3:-}"

    [ -d "$module_dir" ] || return 1

    if [ -z "$source_name" ]; then
        source_name="$(upstreams_module_name "$module_dir" 2>/dev/null || true)"
    fi
    [ -n "$source_name" ] || return 1

    if [ -z "$src_root" ]; then
        src_root="$(upstreams_module_data_dir "$module_dir")"
    fi
    [ -d "$src_root" ] || return 1

    index_dir="$(upstreams_module_index_dir "$module_dir")"
    index_raw="$(upstreams_module_index_raw_file "$module_dir")"
    tmp_raw="${index_raw}.tmp.$$"

    mkdir -p "$index_dir"
    : > "$tmp_raw"

    find "$src_root" -type f -name '*.lst' 2>/dev/null | sort | while IFS= read -r src_path; do
        [ -f "$src_path" ] || continue

        rel="${src_path#"$src_root"/}"
        file_name="$(basename "$rel")"
        dirpart="$(dirname "$rel")"
        kind="$(upstreams__detect_kind "$file_name" 2>/dev/null || true)"

        [ -n "$kind" ] || continue

        case "$dirpart" in
            .)
                group="root"
                service=""
                level="group"
                tag="grp__${source_name}__root"
                dest_name="${source_name}__group__root.lst"
                ;;
            */*)
                group="${dirpart%%/*}"
                service="${dirpart#*/}"
                level="service"
                tag="svc__${source_name}__${group}__${service}"
                dest_name="${source_name}__service__${group}__${service}.lst"
                ;;
            *)
                group="$dirpart"
                service=""
                level="group"
                tag="grp__${source_name}__${group}"
                dest_name="${source_name}__group__${group}.lst"
                ;;
        esac

        # Field 8: path relative to src_root (portable across host ↔ router).
        printf '%s|%s|%s|%s|%s|%s|%s|%s|%s\n' \
            "$tag" "$source_name" "$group" "$service" "$level" "$kind" "$file_name" "$rel" "$dest_name" >> "$tmp_raw"
    done

    mv -f "$tmp_raw" "$index_raw"
    return 0
}

upstreams_rebuild_module_index_for_data_dir() {
    src_root="$1"
    [ -d "$src_root" ] || return 1
    module_dir="$(dirname "$src_root")"
    upstreams_rebuild_module_index "$module_dir" "" "$src_root"
}

# True (exit 0) when indexed paths are unusable: missing file, or absolute
# (host/router) path that must be rewritten to relative.
upstreams__module_index_paths_bad_p() {
    module_dir="$1"
    src_root="$2"
    index_raw="$(upstreams_module_index_raw_file "$module_dir")"

    [ -s "$index_raw" ] || return 0
    [ -d "$src_root" ] || return 0

    while IFS='|' read -r _t _s _g _svc _lvl _k _fn src_path _dst; do
        [ -n "${src_path:-}" ] || continue
        case "$src_path" in
            /*) return 0 ;;
        esac
        abs="$(upstreams_index_path_abs "$src_root" "$src_path" 2>/dev/null || true)"
        [ -n "$abs" ] && [ -f "$abs" ] || return 0
    done < "$index_raw"

    return 1
}

upstreams__module_index_stale_p() {
    module_dir="$1"
    src_root="$2"
    index_raw="$(upstreams_module_index_raw_file "$module_dir")"

    [ -s "$index_raw" ] || return 0
    [ -d "$src_root" ] || return 0

    if upstreams__module_index_paths_bad_p "$module_dir" "$src_root"; then
        return 0
    fi

    if find "$src_root" -type f -name '*.lst' -newer "$index_raw" 2>/dev/null | grep -q .; then
        return 0
    fi

    return 1
}

upstreams__ensure_module_index() {
    module_dir="$1"
    source_name="$2"
    src_root="$3"

    index_raw="$(upstreams_module_index_raw_file "$module_dir")"
    # Hot path: rebuild only when paths missing/absolute. Full find -newer walk
    # is seconds on overlay — only with UPSTREAMS_INDEX_VERIFY=1, update-lists,
    # or menu «Пересобрать индекс».
    if [ -s "$index_raw" ]; then
        need_rebuild=0
        if upstreams__module_index_paths_bad_p "$module_dir" "$src_root"; then
            need_rebuild=1
        elif [ "${UPSTREAMS_INDEX_VERIFY:-0}" = "1" ] \
            && upstreams__module_index_stale_p "$module_dir" "$src_root"; then
            need_rebuild=1
        fi
        if [ "$need_rebuild" -eq 0 ]; then
            printf '%s\n' "$index_raw"
            return 0
        fi
    fi

    upstreams_rebuild_module_index "$module_dir" "$source_name" "$src_root" || return 1
    [ -s "$index_raw" ] || return 1
    printf '%s\n' "$index_raw"
}

# Spare (startup / deploy): rewrite only modules whose index still has absolute
# or missing paths. Not a full reindex — list changes rebuild via update-lists
# or menu «Переиндексировать source-списки».
upstreams_repair_bad_indexes() {
    start_dir="${1:-}"
    [ -n "$start_dir" ] || start_dir="${ROOT_DIR:-}"
    [ -n "$start_dir" ] || return 0
    [ -d "$start_dir/upstreams" ] || return 0

    # shellcheck disable=SC2034
    upstreams_list_modules_tsv "$start_dir" | while IFS="$(printf '\t')" read -r source title description script src_root conf_file; do
        source="$(printf '%s' "$source" | tr -d '\r')"
        src_root="$(printf '%s' "$src_root" | tr -d '\r')"
        module_dir="$(dirname "$conf_file")"
        [ -n "$source" ] && [ -d "$src_root" ] && [ -d "$module_dir" ] || continue
        if upstreams__module_index_paths_bad_p "$module_dir" "$src_root"; then
            upstreams_rebuild_module_index "$module_dir" "$source" "$src_root" >/dev/null 2>&1 || true
        fi
    done
    return 0
}

# Append one module index into combined raw TSV with paths resolved against
# this install's src_root (relative index → absolute for staging/cp only).
upstreams__append_module_index_resolved() {
    src_root="$1"
    index_raw="$2"
    out_raw="$3"

    [ -s "$index_raw" ] || return 1
    [ -d "$src_root" ] || return 1

    while IFS='|' read -r tag source group service level kind file_name src_path dest_name; do
        [ -n "${tag:-}" ] || continue
        abs="$(upstreams_index_path_abs "$src_root" "$src_path" 2>/dev/null || true)"
        [ -n "$abs" ] || continue
        [ -f "$abs" ] || continue
        printf '%s|%s|%s|%s|%s|%s|%s|%s|%s\n' \
            "$tag" "$source" "$group" "$service" "$level" "$kind" "$file_name" "$abs" "$dest_name" >> "$out_raw"
    done < "$index_raw"
}

upstreams_iter_list_files_tsv() {
    start_dir="${1:-$PWD}"

    upstreams_list_modules_tsv "$start_dir" | while IFS="$(printf '\t')" read -r source title description script src_root conf_file; do
        source="$(printf '%s' "$source" | tr -d '\r')"
        src_root="$(printf '%s' "$src_root" | tr -d '\r')"

        [ -n "$source" ] || continue
        [ -n "$src_root" ] || continue
        [ -d "$src_root" ] || continue

        find "$src_root" -type f -name '*.lst' 2>/dev/null | sort | while IFS= read -r src_path; do
            [ -f "$src_path" ] || continue

            rel="${src_path#$src_root/}"
            file_name="$(basename "$rel")"
            dirpart="$(dirname "$rel")"
            kind="$(upstreams__detect_kind "$file_name" 2>/dev/null || true)"

            [ -n "$kind" ] || continue

            case "$dirpart" in
                .)
                    group="root"
                    service=""
                    level="group"
                    tag="grp__${source}__root"
                    dest_name="${source}__group__root.lst"
                    ;;
                */*)
                    group="${dirpart%%/*}"
                    service="${dirpart#*/}"
                    level="service"
                    tag="svc__${source}__${group}__${service}"
                    dest_name="${source}__service__${group}__${service}.lst"
                    ;;
                *)
                    group="$dirpart"
                    service=""
                    level="group"
                    tag="grp__${source}__${group}"
                    dest_name="${source}__group__${group}.lst"
                    ;;
            esac

            printf '%s|%s|%s|%s|%s|%s|%s|%s|%s\n' \
                "$tag" "$source" "$group" "$service" "$level" "$kind" "$file_name" "$src_path" "$dest_name"
        done
    done
}

upstreams_build_model_tsv() {
    start_dir="$1"
    entities_out="$2"
    files_out="$3"
    raw_out="${4:-}"

    tmp_raw="${raw_out:-/tmp/upstreams-raw.$$}"
    : > "$tmp_raw"
    : > "$entities_out"
    : > "$files_out"

    : > "$tmp_raw"
    upstreams_list_modules_tsv "$start_dir" | while IFS="$(printf '\t')" read -r source title description script src_root conf_file; do
        source="$(printf '%s' "$source" | tr -d '\r')"
        src_root="$(printf '%s' "$src_root" | tr -d '\r')"
        module_dir="$(dirname "$conf_file")"

        [ -n "$source" ] || continue
        [ -n "$src_root" ] || continue
        [ -d "$src_root" ] || continue
        [ -d "$module_dir" ] || continue

        index_raw="$(upstreams__ensure_module_index "$module_dir" "$source" "$src_root" 2>/dev/null || true)"
        if [ -n "$index_raw" ] && [ -s "$index_raw" ]; then
            upstreams__append_module_index_resolved "$src_root" "$index_raw" "$tmp_raw" || true
            continue
        fi

        upstreams_rebuild_module_index "$module_dir" "$source" "$src_root" >/dev/null 2>&1 || true
        index_raw="$(upstreams_module_index_raw_file "$module_dir")"
        if [ -s "$index_raw" ]; then
            upstreams__append_module_index_resolved "$src_root" "$index_raw" "$tmp_raw" || true
            continue
        fi

        # Last-resort fallback for compatibility if index creation failed.
        find "$src_root" -type f -name '*.lst' 2>/dev/null | sort | while IFS= read -r src_path; do
            [ -f "$src_path" ] || continue

            rel="${src_path#"$src_root"/}"
            file_name="$(basename "$rel")"
            dirpart="$(dirname "$rel")"
            kind="$(upstreams__detect_kind "$file_name" 2>/dev/null || true)"
            [ -n "$kind" ] || continue

            case "$dirpart" in
                .)
                    group="root"
                    service=""
                    level="group"
                    tag="grp__${source}__root"
                    dest_name="${source}__group__root.lst"
                    ;;
                */*)
                    group="${dirpart%%/*}"
                    service="${dirpart#*/}"
                    level="service"
                    tag="svc__${source}__${group}__${service}"
                    dest_name="${source}__service__${group}__${service}.lst"
                    ;;
                *)
                    group="$dirpart"
                    service=""
                    level="group"
                    tag="grp__${source}__${group}"
                    dest_name="${source}__group__${group}.lst"
                    ;;
            esac

            printf '%s|%s|%s|%s|%s|%s|%s|%s|%s\n' \
                "$tag" "$source" "$group" "$service" "$level" "$kind" "$file_name" "$src_path" "$dest_name" >> "$tmp_raw"
        done
    done

    awk -F'|' '
    {
        tag=$1
        source=$2
        group=$3
        service=$4
        level=$5
        kind=$6

        if (!(tag in seen)) {
            seen[tag]=1
            src[tag]=source
            grp[tag]=group
            svc[tag]=service
            lvl[tag]=level
            fqdn[tag]=0
            pref[tag]=0
        }

        if (kind=="fqdn") fqdn[tag]=1
        if (kind=="prefix") pref[tag]=1
    }
    END {
        for (t in seen) {
            order = (lvl[t]=="group" ? "0" : "1")
            printf "%s|%s|%s|%s|%s|%d|%d|%s\n",
                t, src[t], grp[t], svc[t], lvl[t], fqdn[t], pref[t], order
        }
    }' "$tmp_raw" | sort -t'|' -k2,2 -k3,3 -k8,8 -k4,4 > "$entities_out"

    awk -F'|' '{ printf "%s|%s|%s|%s\n", $1, $6, $8, $9 }' "$tmp_raw" > "$files_out"

    if [ -z "$raw_out" ]; then
        rm -f "$tmp_raw"
    fi
}

upstreams__kind_is_prefix() {
    kind="$1"
    case "$kind" in
        prefix|prefix4|prefix6|prefix_ipv4|prefix_ipv6|prefix-ipv4|prefix-ipv6)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

upstreams__prefix_family_from_name() {
    name="$1"
    case "$name" in
        prefixes-ipv4-*|prefixes-ipv4.lst|*__ipv4.lst|*__ipv4)
            printf 'ipv4\n'
            ;;
        prefixes-ipv6-*|prefixes-ipv6.lst|*__ipv6.lst|*__ipv6)
            printf 'ipv6\n'
            ;;
        *)
            printf 'prefix\n'
            ;;
    esac
}

upstreams_materialize_target_name() {
    consumer="$1"   # iface|zapret|dns
    kind="$2"
    src_path="$3"
    dest_name="$4"

    case "$consumer" in
        dns)
            printf '%s\n' "$dest_name"
            return 0
            ;;
        zapret)
            stem="${dest_name%.lst}"
            if [ "$kind" = "fqdn" ]; then
                printf '%s__fqdn.lst\n' "$stem"
            elif upstreams__kind_is_prefix "$kind"; then
                family="$(upstreams__prefix_family_from_name "$(basename "$src_path")")"
                case "$family" in
                    ipv4) printf '%s__ipv4.lst\n' "$stem" ;;
                    ipv6) printf '%s__ipv6.lst\n' "$stem" ;;
                    *)    printf '%s__prefix.lst\n' "$stem" ;;
                esac
            else
                printf '%s\n' "$dest_name"
            fi
            return 0
            ;;
        iface)
            case "$dest_name" in
                fqdn-*|prefixes-ipv4-*|prefixes-ipv6-*|*__fqdn.lst|*__ipv4.lst|*__ipv6.lst)
                    printf '%s\n' "$dest_name"
                    return 0
                    ;;
            esac

            stem="${dest_name%.lst}"
            if [ "$kind" = "fqdn" ]; then
                printf '%s__fqdn.lst\n' "$stem"
                return 0
            fi

            if upstreams__kind_is_prefix "$kind"; then
                family="$(upstreams__prefix_family_from_name "$(basename "$src_path")")"
                case "$family" in
                    ipv4) printf '%s__ipv4.lst\n' "$stem" ;;
                    ipv6) printf '%s__ipv6.lst\n' "$stem" ;;
                    *)    printf '%s\n' "$dest_name" ;;
                esac
                return 0
            fi

            printf '%s\n' "$dest_name"
            return 0
            ;;
        *)
            printf '%s\n' "$dest_name"
            return 0
            ;;
    esac
}

# Safer wrapper for rows produced by upstreams_build_model_tsv files.tsv.
# Row shape is: tag|kind|src_path|dest_name
upstreams_materialize_target_from_model_row() {
    consumer="$1"   # iface|zapret|dns
    kind="$2"
    src_path="$3"
    dest_name="$4"
    upstreams_materialize_target_name "$consumer" "$kind" "$src_path" "$dest_name"
}

upstreams_should_skip_prefix_target_name() {
    target_name="$1"
    disable_ipv4="${2:-0}"
    disable_ipv6="${3:-0}"

    case "$target_name" in
        *__ipv4.lst) [ "$disable_ipv4" = "1" ] && return 0 ;;
        *__ipv6.lst) [ "$disable_ipv6" = "1" ] && return 0 ;;
    esac
    return 1
}

# Match materialized target file in profile dir (canonical + legacy stem.lst names).
upstreams_target_file_present() {
    consumer="$1"
    dir="$2"
    target="$3"

    [ -n "${dir:-}" ] || return 1
    [ -f "$dir/$target" ] && return 0

    case "$consumer" in
        zapret|iface)
            case "$target" in
                *__fqdn.lst)
                    [ -f "$dir/${target%__fqdn.lst}.lst" ] && return 0
                    ;;
                *__ipv4.lst)
                    [ -f "$dir/${target%__ipv4.lst}.lst" ] && return 0
                    [ -f "$dir/${target%__ipv4.lst}__prefix.lst" ] && return 0
                    ;;
                *__ipv6.lst)
                    [ -f "$dir/${target%__ipv6.lst}.lst" ] && return 0
                    ;;
                *__prefix.lst)
                    [ -f "$dir/${target%__prefix.lst}.lst" ] && return 0
                    ;;
            esac
            ;;
    esac
    return 1
}

# Build enabled upstream tags for checklist state in one pass (stdout: one tag per line).
# mode: all | fqdn_only
# Lists target dirs once, then one awk — not a subshell per files.tsv row.
upstreams_build_enabled_tags_tsv() {
    consumer="$1"
    files_tsv="$2"
    fqdn_dir="$3"
    prefix_dir="$4"
    mode="${5:-all}"
    disable_ipv4="${6:-0}"
    disable_ipv6="${7:-0}"

    present_fqdn="$(mktemp)"
    present_pfx="$(mktemp)"
    # Do not trap EXIT: callers already have tmp traps; trap - at the end
    # would drop them. Leak two mktemp files on abort is acceptable.
    : > "$present_fqdn"
    : > "$present_pfx"

    if [ -d "$fqdn_dir" ]; then
        for f in "$fqdn_dir"/*.lst; do
            [ -f "$f" ] || continue
            printf '%s\n' "${f##*/}" >> "$present_fqdn"
        done
    fi
    if [ -n "${prefix_dir:-}" ] && [ -d "$prefix_dir" ]; then
        for f in "$prefix_dir"/*.lst; do
            [ -f "$f" ] || continue
            printf '%s\n' "${f##*/}" >> "$present_pfx"
        done
    fi

    awk -F'|' -v consumer="$consumer" -v mode="$mode" \
        -v dv4="$disable_ipv4" -v dv6="$disable_ipv6" \
        -v pfq="$present_fqdn" -v ppx="$present_pfx" '
    function bn(path,   n, a) {
        n = split(path, a, "/")
        return a[n]
    }
    function stem_lst(dest) {
        sub(/\.lst$/, "", dest)
        return dest
    }
    function fam(src,   b) {
        b = bn(src)
        if (b ~ /^prefixes-ipv4-/ || b ~ /__ipv4\.lst$/ || b ~ /__ipv4$/) return "ipv4"
        if (b ~ /^prefixes-ipv6-/ || b ~ /__ipv6\.lst$/ || b ~ /__ipv6$/) return "ipv6"
        return "prefix"
    }
    function is_prefix(kind) {
        return (kind == "prefix" || kind == "prefix4" || kind == "prefix6" \
            || kind == "prefix_ipv4" || kind == "prefix_ipv6" \
            || kind == "prefix-ipv4" || kind == "prefix-ipv6")
    }
    function target_name(kind, src, dest,   st, f) {
        if (consumer == "dns") return dest
        st = stem_lst(dest)
        if (kind == "fqdn") {
            if (consumer == "zapret") return st "__fqdn.lst"
            if (dest ~ /^(fqdn-)/ || dest ~ /__fqdn\.lst$/ || dest ~ /^(prefixes-ipv4-|prefixes-ipv6-)/ || dest ~ /__ipv4\.lst$/ || dest ~ /__ipv6\.lst$/)
                return dest
            return st "__fqdn.lst"
        }
        if (!is_prefix(kind)) return dest
        f = fam(src)
        if (consumer == "zapret") {
            if (f == "ipv4") return st "__ipv4.lst"
            if (f == "ipv6") return st "__ipv6.lst"
            return st "__prefix.lst"
        }
        if (dest ~ /^(fqdn-)/ || dest ~ /^(prefixes-ipv4-|prefixes-ipv6-)/ || dest ~ /__fqdn\.lst$/ || dest ~ /__ipv4\.lst$/ || dest ~ /__ipv6\.lst$/)
            return dest
        if (f == "ipv4") return st "__ipv4.lst"
        if (f == "ipv6") return st "__ipv6.lst"
        return dest
    }
    function skip_af(t) {
        if (dv4 == "1" && t ~ /__ipv4\.lst$/) return 1
        if (dv6 == "1" && t ~ /__ipv6\.lst$/) return 1
        return 0
    }
    function present_in(file, name,   stem) {
        if (name == "") return 0
        if ((file SUBSEP name) in have) return 1
        if (consumer == "zapret" || consumer == "iface") {
            if (name ~ /__fqdn\.lst$/) {
                stem = name
                sub(/__fqdn\.lst$/, ".lst", stem)
                if ((file SUBSEP stem) in have) return 1
            }
            if (name ~ /__ipv4\.lst$/) {
                stem = name
                sub(/__ipv4\.lst$/, ".lst", stem)
                if ((file SUBSEP stem) in have) return 1
                stem = name
                sub(/__ipv4\.lst$/, "__prefix.lst", stem)
                if ((file SUBSEP stem) in have) return 1
            }
            if (name ~ /__ipv6\.lst$/) {
                stem = name
                sub(/__ipv6\.lst$/, ".lst", stem)
                if ((file SUBSEP stem) in have) return 1
            }
            if (name ~ /__prefix\.lst$/) {
                stem = name
                sub(/__prefix\.lst$/, ".lst", stem)
                if ((file SUBSEP stem) in have) return 1
            }
        }
        return 0
    }
    BEGIN {
        while ((getline line < pfq) > 0) {
            sub(/\r$/, "", line)
            if (line != "") have[pfq SUBSEP line] = 1
        }
        close(pfq)
        while ((getline line < ppx) > 0) {
            sub(/\r$/, "", line)
            if (line != "") have[ppx SUBSEP line] = 1
        }
        close(ppx)
    }
    NF >= 4 {
        tag = $1
        kind = $2
        src = $3
        dest = $4
        if (mode == "fqdn_only" && kind != "fqdn") next
        tname = target_name(kind, src, dest)
        if (is_prefix(kind) && skip_af(tname)) next
        req[tag]++
        okp = 0
        if (kind == "fqdn")
            okp = present_in(pfq, tname)
        else if (is_prefix(kind))
            okp = present_in(ppx, tname)
        if (okp) ok[tag]++
    }
    END {
        for (t in req) {
            if (req[t] > 0 && ok[t] == req[t]) print t
        }
    }' "$files_tsv"

    rm -f "$present_fqdn" "$present_pfx"
}

# Check whether all files for a tag are present in target dirs.
# mode: all | fqdn_only
upstreams_is_tag_enabled_in_target() {
    consumer="$1"
    tag="$2"
    files_tsv="$3"
    fqdn_dir="$4"
    prefix_dir="$5"
    mode="${6:-all}"
    disable_ipv4="${7:-0}"
    disable_ipv6="${8:-0}"

    total=0
    present=0

    awk -F'|' -v t="$tag" '$1 == t' "$files_tsv" | while IFS='|' read -r _ kind src dst; do
        [ -n "${kind:-}" ] || continue

        if [ "$mode" = "fqdn_only" ] && [ "$kind" != "fqdn" ]; then
            continue
        fi

        target="$(upstreams_materialize_target_from_model_row "$consumer" "$kind" "$src" "$dst")"

        if upstreams__kind_is_prefix "$kind"; then
            if upstreams_should_skip_prefix_target_name "$target" "$disable_ipv4" "$disable_ipv6"; then
                continue
            fi
        fi

        total=$((total + 1))

        if [ "$kind" = "fqdn" ]; then
            if upstreams_target_file_present "$consumer" "$fqdn_dir" "$target"; then
                present=$((present + 1))
            fi
        elif upstreams__kind_is_prefix "$kind"; then
            if upstreams_target_file_present "$consumer" "$prefix_dir" "$target"; then
                present=$((present + 1))
            fi
        fi
    done

    [ "$total" -gt 0 ] && [ "$present" -eq "$total" ]
}

# Copy files for one tag from files.tsv to staged dirs.
# mode: all | fqdn_only
upstreams_stage_tag_files_from_model() {
    consumer="$1"
    tag="$2"
    files_tsv="$3"
    staged_fqdn_dir="$4"
    staged_prefix_dir="$5"
    mode="${6:-all}"
    disable_ipv4="${7:-0}"
    disable_ipv6="${8:-0}"

    awk -F'|' -v t="$tag" '$1==t' "$files_tsv" | while IFS='|' read -r _ kind src dst; do
        [ -f "$src" ] || continue

        if [ "$mode" = "fqdn_only" ] && [ "$kind" != "fqdn" ]; then
            continue
        fi

        target="$(upstreams_materialize_target_from_model_row "$consumer" "$kind" "$src" "$dst")"

        if [ "$kind" = "fqdn" ]; then
            [ -n "${staged_fqdn_dir:-}" ] || continue
            mkdir -p "$staged_fqdn_dir"
            cp -f "$src" "$staged_fqdn_dir/$target"
        elif upstreams__kind_is_prefix "$kind"; then
            if upstreams_should_skip_prefix_target_name "$target" "$disable_ipv4" "$disable_ipv6"; then
                continue
            fi
            [ -n "${staged_prefix_dir:-}" ] || continue
            mkdir -p "$staged_prefix_dir"
            cp -f "$src" "$staged_prefix_dir/$target"
        fi
    done
}

upstreams_replace_dir_from_staged() {
    target_dir="$1"
    staged_dir="$2"
    mkdir -p "$target_dir"
    rm -f "$target_dir"/*.lst 2>/dev/null || true
    for f in "$staged_dir"/*.lst; do
        [ -f "$f" ] || continue
        cp -f "$f" "$target_dir/$(basename "$f")"
    done
}

upstreams_count_nonempty_lines() {
    file="$1"
    [ -f "$file" ] || {
        printf '0\n'
        return 0
    }
    awk 'NF { n++ } END { print n + 0 }' "$file"
}

upstreams_count_staged_lists() {
    dir="$1"
    [ -d "$dir" ] || {
        printf '0\n'
        return 0
    }
    find "$dir" -maxdepth 1 -type f -name '*.lst' 2>/dev/null | wc -l | tr -d ' '
}

# Exit 0 when selected tags exist but staging has no .lst (failed materialization).
upstreams_staging_selection_mismatch() {
    choices_file="$1"
    staged_fqdn_dir="$2"
    staged_prefix_dir="${3:-}"

    selected_n="$(upstreams_count_nonempty_lines "$choices_file")"
    staged_n=$(( $(upstreams_count_staged_lists "$staged_fqdn_dir") + $(upstreams_count_staged_lists "$staged_prefix_dir") ))

    [ "$selected_n" -gt 0 ] && [ "$staged_n" -eq 0 ]
}

# User-facing hint when staging failed but tags were selected (no UI dependency).
upstreams_staging_mismatch_message() {
    choices_file="$1"
    selected_n="$(upstreams_count_nonempty_lines "$choices_file")"
    printf '%s\n' "Выбрано upstream-тегов: $selected_n, но ни один исходный .lst не скопирован в staging.

Профиль не изменён. Попробуйте:
  Upstreams → «Переиндексировать source-списки»
  затем повторите выбор."
}

upstreams_dematerialize_target_name() {
    consumer="$1"            # iface|zapret|dns
    kind_hint="$2"           # fqdn|prefix
    materialized_name="$3"   # e.g. foo__ipv4.lst

    kind="$kind_hint"
    dest_name="$materialized_name"

    case "$consumer" in
        iface|zapret)
            case "$materialized_name" in
                *__fqdn.lst)
                    kind="fqdn"
                    dest_name="${materialized_name%__fqdn.lst}.lst"
                    ;;
                *__ipv4.lst|*__ipv6.lst|*__prefix.lst)
                    kind="prefix"
                    case "$materialized_name" in
                        *__ipv4.lst) dest_name="${materialized_name%__ipv4.lst}.lst" ;;
                        *__ipv6.lst) dest_name="${materialized_name%__ipv6.lst}.lst" ;;
                        *__prefix.lst) dest_name="${materialized_name%__prefix.lst}.lst" ;;
                    esac
                    ;;
            esac
            ;;
    esac

    printf '%s|%s\n' "$kind" "$dest_name"
}