#!/bin/sh
# shellcheck shell=sh
# Единая обёртка: lock + LED + лог + meta для фоновых задач toolbox.
# Work-скрипты не вызывают bg_tasks_* — только эта обёртка (меню, WPS hotplug, фон через subshell &).
set -eu

_SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
_XFREE_ROOT="$(CDPATH= cd -- "$_SCRIPT_DIR/.." && pwd -P)"
XFREE_TOOLBOX_ROOT="${XFREE_TOOLBOX_ROOT:-$_XFREE_ROOT}"

# shellcheck disable=SC1090
. "$XFREE_TOOLBOX_ROOT/lib/background-tasks.sh"

BG_RUN_TASK_NAME=""
BG_RUN_LOG_FILE=""
BG_RUN_STATUS="failed"
BG_RUN_EXIT_CODE="1"
BG_RUN_CMD_DISPLAY=""

bg_task_run_usage() {
    cat <<EOF
Usage: $(basename "$0") <task-name> [--log <file>] -- <command> [args...]

Регистрирует фоновую задачу (lib/background-tasks.sh), пишет stdout/stderr в лог,
выполняет команду. Переменная окружения XFREE_BG_TASK_LOG_FILE указывает путь лога.

Пример:
  ( sh $(basename "$0") apply-template -- sh /root/xfree-toolbox/templates/apply-template.sh ) &
EOF
}

bg_task_run_cleanup() {
    bg_tasks_finish "${BG_RUN_STATUS:-unknown}" "${BG_RUN_EXIT_CODE:-1}" || true
}

while [ $# -gt 0 ]; do
    case "$1" in
        -h|--help)
            bg_task_run_usage
            exit 0
            ;;
        --log)
            [ $# -ge 2 ] || {
                bg_task_run_usage >&2
                exit 2
            }
            BG_RUN_LOG_FILE="$2"
            shift 2
            ;;
        --)
            shift
            break
            ;;
        *)
            if [ -z "$BG_RUN_TASK_NAME" ]; then
                BG_RUN_TASK_NAME="$1"
                shift
            else
                break
            fi
            ;;
    esac
done

if [ -z "$BG_RUN_TASK_NAME" ] || [ $# -lt 1 ]; then
    bg_task_run_usage >&2
    exit 2
fi

BG_RUN_LOG_FILE="${BG_RUN_LOG_FILE:-${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}/${BG_RUN_TASK_NAME}.log}"
BG_RUN_CMD_DISPLAY="$*"
_log_dir="$(dirname -- "$BG_RUN_LOG_FILE")"
mkdir -p "$_log_dir" 2>/dev/null || true

if ! bg_tasks_start "$BG_RUN_TASK_NAME" "$BG_RUN_LOG_FILE" "$BG_RUN_CMD_DISPLAY"; then
    if bg_tasks_is_running; then
        printf 'bg-task-run: skip, already running %s (pid=%s)\n' \
            "${BG_TASK_NAME:-task}" "${BG_TASK_PID:-?}" >&2
        exit 0
    fi
    printf 'bg-task-run: failed to start task %s\n' "$BG_RUN_TASK_NAME" >&2
    exit 1
fi

trap bg_task_run_cleanup EXIT INT TERM HUP
export XFREE_BG_TASK_LOG_FILE="$BG_RUN_LOG_FILE"
export XFREE_TOOLBOX_ROOT
export XFREE_BG_TASK=1

: >"$BG_RUN_LOG_FILE" 2>/dev/null || true
{
    printf '[%s] bg-task-run: start task=%s log=%s pid=%s\n' \
        "$(bg_tasks_now)" "$BG_RUN_TASK_NAME" "$BG_RUN_LOG_FILE" "$$"
    printf '[%s] command: %s\n' "$(bg_tasks_now)" "$BG_RUN_CMD_DISPLAY"
} >>"$BG_RUN_LOG_FILE" 2>/dev/null || true

if "$@" >>"$BG_RUN_LOG_FILE" 2>&1; then
    BG_RUN_STATUS="done"
    _rc=0
else
    BG_RUN_STATUS="failed"
    _rc=$?
    [ "$_rc" -eq 0 ] && _rc=1
fi
BG_RUN_EXIT_CODE="$_rc"

{
    printf '[%s] bg-task-run: finish task=%s status=%s exit=%s\n' \
        "$(bg_tasks_now)" "$BG_RUN_TASK_NAME" "$BG_RUN_STATUS" "$_rc"
} >>"$BG_RUN_LOG_FILE" 2>/dev/null || true

exit "$_rc"
