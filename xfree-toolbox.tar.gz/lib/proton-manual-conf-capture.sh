#!/bin/sh
# shellcheck shell=sh
# Единый TTY-ввод многострочного текста (nano → vi → cat+Ctrl+D).
# Environment:
#   PROTON_MANUAL_CONF_EDITOR   Принудительно: nano | vi | cat
# Вызывается:
#   - proton_manual_conf_capture_to_file — напрямую из templates/prepare-template.sh
#   - ui_capture_tty_multiline_to_file в lib/ui.sh — из меню и других UI-сценариев

proton_manual_conf_tty_ok() {
  # ui_run_with_output перенаправляет stdout в файл; реальный TTY — /dev/tty.
  printf '' >/dev/tty 2>/dev/null || return 1
  return 0
}

# Returns one of: nano | vi | cat
proton_manual_conf_pick_editor() {
  case "${PROTON_MANUAL_CONF_EDITOR:-}" in
    nano|vi|cat)
      printf '%s\n' "$PROTON_MANUAL_CONF_EDITOR"
      return
      ;;
  esac
  if command -v nano >/dev/null 2>&1; then
    printf 'nano\n'
    return
  fi
  if command -v vi >/dev/null 2>&1; then
    printf 'vi\n'
    return
  fi
  printf 'cat\n'
}

# Args: <target_file> <banner_title> <continuation_hint>
# Writes prompts to /dev/tty; fills target_file from nano/vi/cat.
proton_manual_conf_capture_to_file() {
  target_file="$1"
  banner_title="$2"
  continuation_hint="$3"

  : > "$target_file" || return 1
  proton_manual_conf_tty_ok || return 1
  stty sane </dev/tty 2>/dev/null || true
  clear >/dev/tty 2>/dev/null || true
  ed="$(proton_manual_conf_pick_editor)"
  printf '\n=== %s ===\n\n' "$banner_title" >/dev/tty
  case "$ed" in
    nano)
      printf '%s\n' 'Откроется nano: вставьте полный Proton .conf, сохраните (Ctrl+O, Enter) и выйдите (Ctrl+X). После выхода возможна пауза без вывода (лог шага может собираться целиком).' >/dev/tty
      ;;
    vi)
      printf '%s\n' 'Откроется vi: вставьте полный Proton .conf, затем :wq. Дальше возможна пауза без вывода в терминале.' >/dev/tty
      ;;
    cat)
      printf '%s\n' 'Вставьте полный Proton .conf; на новой пустой строке завершите ввод Ctrl+D (при необходимости дважды).' >/dev/tty
      ;;
  esac
  printf '%s\n\n' "$continuation_hint" >/dev/tty

  case "$ed" in
    nano|vi)
      if ! "$ed" "$target_file" </dev/tty >/dev/tty 2>&1; then
        stty sane </dev/tty 2>/dev/null || true
        return 1
      fi
      ;;
    cat)
      if ! cat < /dev/tty > "$target_file"; then
        stty sane </dev/tty 2>/dev/null || true
        return 1
      fi
      ;;
  esac
  stty sane </dev/tty 2>/dev/null || true
  return 0
}
