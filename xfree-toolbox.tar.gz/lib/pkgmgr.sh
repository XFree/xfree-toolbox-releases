#!/bin/sh
# shellcheck shell=sh

if [ -n "${ROOT_DIR:-}" ] && [ -f "${ROOT_DIR}/lib/common.sh" ]; then
  COMMON_SH="${ROOT_DIR}/lib/common.sh"
elif [ -f "./lib/common.sh" ]; then
  COMMON_SH="./lib/common.sh"
else
  echo "[!] Не найден common.sh. Ожидался ROOT_DIR/lib/common.sh" >&2
  exit 1
fi

# shellcheck disable=SC1090
. "$COMMON_SH"
_HTTP_GH_PROXY="$(dirname -- "$COMMON_SH")/http-github-proxy.sh"
if [ -f "$_HTTP_GH_PROXY" ]; then
  # shellcheck disable=SC1090
  . "$_HTTP_GH_PROXY"
fi
unset _HTTP_GH_PROXY

: "${PKG_MGR:=auto}"
: "${APK_ALLOW_UNTRUSTED:=1}"
# OpenWrt 25.12+ apk: локальные .apk (zapret/AWG release) не из feeds — иначе ERROR non-repository.
: "${APK_FORCE_NON_REPOSITORY:=1}"
: "${HTTP_CLIENT:=auto}"
: "${HTTP_USER_AGENT:=openwrt-installer/1.0}"
# GitHub/CDN AAAA often hangs on OpenWrt (Operation not permitted); prefer IPv4.
: "${HTTP_PREFER_IPV4:=1}"
: "${HTTP_CONNECT_TIMEOUT:=25}"
: "${HTTP_MAX_TIME:=300}"
: "${HTTP_SPEED_TIME:=15}"
: "${HTTP_SPEED_LIMIT:=32768}"

pm_detect() {
  case "$PKG_MGR" in
    apk|opkg)
      printf '%s\n' "$PKG_MGR"
      return 0
      ;;
    auto|"") ;;
    *)
      die "Unknown PKG_MGR=$PKG_MGR (expected: auto|apk|opkg)"
      ;;
  esac

  if command -v apk >/dev/null 2>&1; then
    printf 'apk\n'
  elif command -v opkg >/dev/null 2>&1; then
    printf 'opkg\n'
  else
    die "Neither apk nor opkg found"
  fi
}

PM="${PM:-$(pm_detect)}"
export PM

pm_print() {
  info "Package manager: $PM (PKG_MGR=$PKG_MGR)"
}

http_detect() {
  case "${HTTP_CLIENT:-auto}" in
    curl|wget|uclient-fetch)
      command -v "$HTTP_CLIENT" >/dev/null 2>&1 || die "HTTP client not found: $HTTP_CLIENT"
      printf '%s\n' "$HTTP_CLIENT"
      ;;
    auto|"")
      if command -v curl >/dev/null 2>&1; then
        printf 'curl\n'
      elif command -v wget >/dev/null 2>&1; then
        printf 'wget\n'
      elif command -v uclient-fetch >/dev/null 2>&1; then
        printf 'uclient-fetch\n'
      else
        die "Neither curl, wget nor uclient-fetch found"
      fi
      ;;
    *)
      die "Unknown HTTP_CLIENT=$HTTP_CLIENT (expected: auto|curl|wget|uclient-fetch)"
      ;;
  esac
}

HTTP_FETCH_CMD="${HTTP_FETCH_CMD:-$(http_detect 2>/dev/null || true)}"
export HTTP_FETCH_CMD

http_print() {
  info "HTTP client: ${HTTP_FETCH_CMD:-<none>} (HTTP_CLIENT=$HTTP_CLIENT)"
}

http_need_tools() {
  if command -v curl >/dev/null 2>&1 || \
     command -v wget >/dev/null 2>&1 || \
     command -v uclient-fetch >/dev/null 2>&1; then
    HTTP_FETCH_CMD="$(http_detect)"
    export HTTP_FETCH_CMD
    return 0
  fi

  case "$PM" in
    apk)
      pm_update || true
      pm_install curl ca-certificates || true
      command -v update-ca-certificates >/dev/null 2>&1 && update-ca-certificates || true
      ;;
    opkg)
      pm_update || true
      pm_install curl ca-bundle || true
      ;;
    *)
      die "PM=$PM not supported"
      ;;
  esac

  HTTP_FETCH_CMD="$(http_detect)"
  export HTTP_FETCH_CMD
}

_http_curl_to_file() {
  # Uses url/out from caller. Extra curl flags in "$@".
  if [ -n "${_HTTP_URL_EFFECTIVE_FILE:-}" ]; then
    curl --http1.1 -fL -S \
      --connect-timeout "$HTTP_CONNECT_TIMEOUT" \
      --max-time "$HTTP_MAX_TIME" \
      --retry 2 --retry-delay 2 \
      --speed-time "$HTTP_SPEED_TIME" --speed-limit "$HTTP_SPEED_LIMIT" \
      -A "$HTTP_USER_AGENT" \
      "$@" \
      -o "$out" \
      -w '%{url_effective}' \
      "$url" >"$_HTTP_URL_EFFECTIVE_FILE"
    return
  fi
  curl --http1.1 -fL -S \
    --connect-timeout "$HTTP_CONNECT_TIMEOUT" \
    --max-time "$HTTP_MAX_TIME" \
    --retry 2 --retry-delay 2 \
    --speed-time "$HTTP_SPEED_TIME" --speed-limit "$HTTP_SPEED_LIMIT" \
    -A "$HTTP_USER_AGENT" \
    "$@" \
    -o "$out" \
    "$url"
}

_http_wget_to_file() {
  wget \
    --user-agent="$HTTP_USER_AGENT" \
    -T "$HTTP_CONNECT_TIMEOUT" \
    "$@" \
    -O "$out" \
    "$url"
}

_http_run_to_file() {
  url="$1"
  out="$2"
  _rc=0

  [ -n "${HTTP_FETCH_CMD:-}" ] || HTTP_FETCH_CMD="$(http_detect)"

  case "$HTTP_FETCH_CMD" in
    curl)
      if [ "${HTTP_PREFER_IPV4:-1}" = "1" ]; then
        _http_curl_to_file -4 || _rc=$?
        if [ "$_rc" -ne 0 ]; then
          warn "HTTP curl IPv4 (-4) не удался (код $_rc) — dual-stack…"
          _http_curl_to_file
        fi
      else
        _http_curl_to_file || _rc=$?
        if [ "$_rc" -ne 0 ]; then
          warn "HTTP curl dual-stack не удался (код $_rc) — IPv4 (-4)…"
          _http_curl_to_file -4
        fi
      fi
      ;;
    wget)
      if [ "${HTTP_PREFER_IPV4:-1}" = "1" ]; then
        _http_wget_to_file -4 || _rc=$?
        if [ "$_rc" -ne 0 ]; then
          warn "HTTP wget IPv4 (-4) не удался (код $_rc) — dual-stack…"
          _http_wget_to_file
        fi
      else
        _http_wget_to_file || _rc=$?
        if [ "$_rc" -ne 0 ]; then
          warn "HTTP wget dual-stack не удался (код $_rc) — IPv4 (-4)…"
          _http_wget_to_file -4
        fi
      fi
      ;;
    uclient-fetch)
      uclient-fetch \
        --user-agent="$HTTP_USER_AGENT" \
        -O "$out" \
        "$url"
      ;;
    *)
      die "Unsupported HTTP_FETCH_CMD=$HTTP_FETCH_CMD"
      ;;
  esac
}

_http_download_heartbeat() {
  _out="$1"
  _flag="$2"
  _interval="${3:-15}"
  _n=0
  while [ -f "$_flag" ]; do
    sleep "$_interval" || break
    [ -f "$_flag" ] || break
    _n=$((_n + 1))
    _sz=0
    if [ -f "$_out" ]; then
      _sz="$(wc -c < "$_out" 2>/dev/null | tr -d ' ')"
    fi
    info "HTTP: ещё качаю (${_n}×${_interval}с, ${_sz:-0} байт)…"
  done
}

http_download_file() {
  _orig_url="$1"
  url="$_orig_url"
  out="$2"
  _hb_flag=""
  _hb_pid=""

  [ -n "$url" ] || die "http_download_file: url is required"
  [ -n "$out" ] || die "http_download_file: output path is required"
  url="$(http_github_proxy_url "$url")"

  ensure_parent_dir "$out"
  if [ "${HTTP_DOWNLOAD_QUIET:-0}" != "1" ]; then
    info "HTTP GET $url"
    info " → $out (connect=${HTTP_CONNECT_TIMEOUT}s max=${HTTP_MAX_TIME}s, IPv4 prefer=${HTTP_PREFER_IPV4:-1})"
  fi
  _hb_flag="${TMPDIR:-/tmp}/xfree-http-dl.$$"
  _HTTP_URL_EFFECTIVE_FILE="${TMPDIR:-/tmp}/xfree-http-eff.$$"
  : >"$_hb_flag"
  : >"$_HTTP_URL_EFFECTIVE_FILE"
  _http_download_heartbeat "$out" "$_hb_flag" 15 &
  _hb_pid=$!
  _rc=0
  _http_run_to_file "$url" "$out" || _rc=$?
  if [ "$_rc" -ne 0 ]; then
    _eff_url="$(tr -d '\r\n' <"$_HTTP_URL_EFFECTIVE_FILE" 2>/dev/null || true)"
    _fb="$(http_github_proxy_fallback_pick "$_orig_url" "$_eff_url" "$url")" || _fb=""
    if [ -n "$_fb" ]; then
      warn "HTTP: githubusercontent.com не ответил (код $_rc) — повтор через gh-proxy.com"
      url="$_fb"
      if [ "${HTTP_DOWNLOAD_QUIET:-0}" != "1" ]; then
        info "HTTP GET $url"
      fi
      _rc=0
      _http_run_to_file "$url" "$out" || _rc=$?
    fi
  fi
  rm -f "$_hb_flag" "$_HTTP_URL_EFFECTIVE_FILE"
  unset _HTTP_URL_EFFECTIVE_FILE
  if [ -n "$_hb_pid" ]; then
    kill "$_hb_pid" 2>/dev/null || true
    wait "$_hb_pid" 2>/dev/null || true
  fi
  [ "$_rc" -eq 0 ] || return "$_rc"
  [ -s "$out" ] || die "HTTP GET пустой файл: $out"
}

http_fetch_text() {
  url="$1"
  tmp_body="${TMPDIR:-/tmp}/http-body.$$"
  _prev_quiet="${HTTP_DOWNLOAD_QUIET:-}"

  HTTP_DOWNLOAD_QUIET=1
  http_download_file "$url" "$tmp_body"
  if [ -n "$_prev_quiet" ]; then
    HTTP_DOWNLOAD_QUIET="$_prev_quiet"
  else
    unset HTTP_DOWNLOAD_QUIET
  fi
  cat "$tmp_body"
  rm -f "$tmp_body"
}

# HEAD/SPIDER probe (releases asset check, etc.). Uses same client as http_fetch_text.
_http_head_url() {
  case "$HTTP_FETCH_CMD" in
    curl)
      curl -fsI --connect-timeout 10 --max-time 20 -A "$HTTP_USER_AGENT" "$1" >/dev/null 2>&1
      ;;
    wget)
      wget -q --spider --timeout=20 --user-agent="$HTTP_USER_AGENT" "$1" >/dev/null 2>&1
      ;;
    uclient-fetch)
      uclient-fetch --spider --user-agent="$HTTP_USER_AGENT" "$1" >/dev/null 2>&1 \
        || uclient-fetch -O /dev/null --user-agent="$HTTP_USER_AGENT" "$1" >/dev/null 2>&1
      ;;
    *)
      die "Unsupported HTTP_FETCH_CMD=$HTTP_FETCH_CMD"
      ;;
  esac
}

# HEAD/SPIDER probe (releases asset check, etc.). Uses same client as http_fetch_text.
http_head_exists() {
  _orig_url="$1"
  url="$_orig_url"
  [ -n "$url" ] || return 1
  url="$(http_github_proxy_url "$url")"
  [ -n "${HTTP_FETCH_CMD:-}" ] || HTTP_FETCH_CMD="$(http_detect)"

  if _http_head_url "$url"; then
    return 0
  fi
  _fb="$(http_github_proxy_fallback_url "$_orig_url")" || return 1
  [ "$_fb" != "$url" ] || return 1
  _http_head_url "$_fb"
}

_pm_update_heartbeat() {
  flagfile="$1"
  interval="${2:-20}"
  n=0
  while [ -f "$flagfile" ]; do
    sleep "$interval" || break
    [ -f "$flagfile" ] || break
    n=$((n + 1))
    if [ -n "${COMMON_LOG_FILE:-}" ]; then
      common_log "[*] … всё ещё выполняется (${n}×${interval} с)"
    else
      info "… всё ещё выполняется (${n}×${interval} с)"
    fi
  done
}

# Снять «зависшие» heartbeat от прерванных apk update/upgrade (меню, Ctrl+C, script(1)).
_pm_stale_heartbeat_cleanup() {
  _xf_tmp="${TMPDIR:-/tmp}"
  for flag in "$_xf_tmp"/xfree-apk-update.* "$_xf_tmp"/xfree-apk-upgrade.*; do
    [ -e "$flag" ] || continue
    case "$flag" in
      *.pid) continue ;;
    esac
    pidf="${flag}.pid"
    if [ -f "$pidf" ]; then
      opid=$(cat "$pidf" 2>/dev/null || true)
      if [ -n "$opid" ]; then
        kill "$opid" 2>/dev/null || true
        wait "$opid" 2>/dev/null || true
      fi
      rm -f "$pidf" 2>/dev/null || true
    fi
    rm -f "$flag" 2>/dev/null || true
  done
}

# tag: apk-update | apk-upgrade (имя файла-флага в $TMPDIR).
_pm_heartbeat_start() {
  tag="${1:-apk-update}"
  interval="${2:-20}"
  _pm_stale_heartbeat_cleanup
  _pm_heartbeat_flag="${TMPDIR:-/tmp}/xfree-${tag}.$$"
  _pm_heartbeat_pidfile="${_pm_heartbeat_flag}.pid"
  : >"$_pm_heartbeat_flag"
  _pm_update_heartbeat "$_pm_heartbeat_flag" "$interval" &
  _pm_heartbeat_pid=$!
  printf '%s\n' "$_pm_heartbeat_pid" >"$_pm_heartbeat_pidfile"
}

_pm_heartbeat_stop() {
  flag="${1:-${_pm_heartbeat_flag:-}}"
  pid="${2:-}"
  if [ -z "$pid" ] && [ -n "${_pm_heartbeat_pidfile:-}" ] && [ -f "$_pm_heartbeat_pidfile" ]; then
    pid=$(cat "$_pm_heartbeat_pidfile" 2>/dev/null || true)
  fi
  [ -z "$pid" ] && pid="${_pm_heartbeat_pid:-}"
  [ -n "$flag" ] && rm -f "$flag" "${flag}.pid" 2>/dev/null || true
  if [ -n "$pid" ]; then
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
  fi
  _pm_heartbeat_flag=
  _pm_heartbeat_pid=
  _pm_heartbeat_pidfile=
}

# Другой apk (apply + LuCI, повтор после Ctrl+C) держит /lib/apk/db/lock → EAGAIN.
pm_apk_busy() {
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -x apk >/dev/null 2>&1 && return 0
    pgrep -f '^apk |/apk |^/sbin/apk |^/usr/bin/apk ' >/dev/null 2>&1 && return 0
  fi
  if [ -e /lib/apk/db/lock ] && command -v fuser >/dev/null 2>&1; then
    fuser /lib/apk/db/lock >/dev/null 2>&1 && return 0
  fi
  return 1
}

# $1 — макс. секунд (0 = не ждать). PM_APK_LOCK_POLL_SEC — шаг опроса (по умолчанию 2).
pm_apk_wait_idle() {
  max="${1:-${PM_APK_LOCK_WAIT_SEC:-60}}"
  poll="${PM_APK_LOCK_POLL_SEC:-2}"
  case "$max" in
    ''|*[!0-9]*) max=60 ;;
  esac
  case "$poll" in
    ''|*[!0-9]*) poll=2 ;;
  esac
  [ "$poll" -ge 1 ] || poll=1
  [ "$max" -eq 0 ] && return 0

  elapsed=0
  logged=0
  while pm_apk_busy; do
    if [ "$logged" = "0" ]; then
      info "apk занят (БД залочена другим процессом), жду до ${max}s…"
      logged=1
    fi
    [ "$elapsed" -ge "$max" ] && {
      warn "apk всё ещё занят после ${max}s — продолжаю (возможен lock)"
      return 1
    }
    sleep "$poll" || break
    elapsed=$((elapsed + poll))
  done
  return 0
}

_pm_apk_log_indicates_lock() {
  log="$1"
  [ -f "$log" ] || return 1
  grep -q 'Unable to lock database' "$log" 2>/dev/null \
    || grep -q 'Failed to open apk database' "$log" 2>/dev/null
}

_pm_apk_retry_sleep() {
  default_sec="$1"
  sec="${PM_APK_RETRY_SLEEP_SEC:-$default_sec}"
  case "$sec" in
    ''|*[!0-9]*) sec="$default_sec" ;;
  esac
  [ "$sec" -eq 0 ] && return 0
  sleep "$sec"
}

# apk иногда выходит с 0 при wget WARNING / без финальной OK-строки.
_pm_apk_log_indicates_success() {
  log="$1"
  [ -f "$log" ] || return 1
  grep -q 'OK: [0-9][0-9]* distinct packages available' "$log" 2>/dev/null
}

# Живой вывод + лог для проверки OK; код выхода apk, не tee.
_pm_apk_update_attempt() {
  log="$1"
  verbose="${2:-0}"
  pm_apk_wait_idle "${PM_APK_LOCK_WAIT_SEC:-60}" || true
  rcf="${TMPDIR:-/tmp}/xfree-apk-rc.$$"
  rm -f "$rcf"
  : >"$log"

  if [ "$verbose" = "1" ]; then
    set -- apk update -v
  else
    set -- apk update
  fi

  if [ -n "${COMMON_LOG_FILE:-}" ]; then
    if command -v stdbuf >/dev/null 2>&1; then
      ( stdbuf -oL -eL "$@"; echo $? >"$rcf" ) 2>&1 | tee -a "$COMMON_LOG_FILE" | tee -a "$log"
    else
      ( "$@"; echo $? >"$rcf" ) 2>&1 | tee -a "$COMMON_LOG_FILE" | tee -a "$log"
    fi
  elif command -v stdbuf >/dev/null 2>&1; then
    ( stdbuf -oL -eL "$@"; echo $? >"$rcf" ) 2>&1 | tee -a "$log"
  else
    ( "$@"; echo $? >"$rcf" ) 2>&1 | tee -a "$log"
  fi

  rc=1
  [ -f "$rcf" ] && rc=$(cat "$rcf" 2>/dev/null || echo 1)
  rm -f "$rcf"

  if [ "$rc" -ne 0 ]; then
    return "$rc"
  fi
  if _pm_apk_log_indicates_success "$log"; then
    return 0
  fi
  warn "apk update завершился без строки «OK: N distinct packages available» (возможны сбои wget)."
  return 1
}

_pm_apk_update_with_retries() {
  log="${TMPDIR:-/tmp}/xfree-apk-update-log.$$"
  rc=1

  if _pm_apk_update_attempt "$log" 0; then
    rc=0
  fi

  if [ "$rc" -ne 0 ] && _pm_apk_log_indicates_lock "$log"; then
    warn "apk update: база занята, жду освобождения и повтор…"
    pm_apk_wait_idle "${PM_APK_LOCK_WAIT_SEC:-90}" || true
    _pm_apk_retry_sleep 2
    _pm_apk_update_attempt "$log" 0 && rc=0
  fi

  if [ "$rc" -ne 0 ]; then
    warn "apk update: повтор через 3 с…"
    _pm_apk_retry_sleep 3
    _pm_apk_update_attempt "$log" 0 && rc=0
  fi

  if [ "$rc" -ne 0 ] && ! _pm_apk_log_indicates_lock "$log"; then
    warn "apk update: перезапуск dnsmasq/https-dns-proxy и повтор…"
    if [ -f "${ROOT_DIR}/dns-routing/lib/restart-stack.sh" ]; then
      # shellcheck disable=SC1091
      . "${ROOT_DIR}/dns-routing/lib/restart-stack.sh"
      dns_routing_restart_resolver_stack || true
    fi
    _pm_apk_retry_sleep 2
    _pm_apk_update_attempt "$log" 0 && rc=0
  elif [ "$rc" -ne 0 ]; then
    warn "apk update: база всё ещё занята — без перезапуска DNS, ещё одна пауза…"
    pm_apk_wait_idle "${PM_APK_LOCK_WAIT_SEC:-60}" || true
    _pm_apk_retry_sleep 5
    _pm_apk_update_attempt "$log" 0 && rc=0
  fi

  if [ "$rc" -ne 0 ]; then
    warn "apk update: ещё одна попытка через 5 с…"
    _pm_apk_retry_sleep 5
    _pm_apk_update_attempt "$log" 0 && rc=0
  fi

  rm -f "$log"
  return "$rc"
}

pm_update() {
  case "$PM" in
    opkg)
      info "opkg update: загрузка списков пакетов с зеркал…"
      common_run_live opkg update
      ;;
    apk)
      info "apk update: загрузка индексов репозиториев (обычно 30–120 с)…"
      _pm_heartbeat_start apk-update 20
      trap '_pm_heartbeat_stop' EXIT INT TERM HUP
      set +e
      if _pm_apk_update_with_retries; then
        rc=0
      else
        rc=$?
      fi
      set -e
      _pm_heartbeat_stop
      trap - EXIT INT TERM HUP
      return "$rc"
      ;;
    *)
      die "PM=$PM not supported"
      ;;
  esac
}

# Перед установкой локальных .apk/.ipk из скачанного релиза (зависимости — из feed).
pm_update_index() {
  case "$PM" in
    apk)  info "Обновляю индекс репозиториев (apk update)" ;;
    opkg) info "Обновляю индекс репозиториев (opkg update)" ;;
    *) die "PM=$PM not supported" ;;
  esac
  pm_update
}

pm_update_index_optional() {
  pm_update_index || warn "${PM} update не удался; локальный пакет может не установиться без зависимостей из репозитория"
}

pm_install() {
  [ "$#" -gt 0 ] || return 0
  case "$PM" in
    opkg) opkg install "$@" ;;
    apk)
      pm_apk_wait_idle "${PM_APK_LOCK_WAIT_SEC:-60}" || true
      apk add "$@"
      ;;
    *) die "PM=$PM not supported" ;;
  esac
}

pm_remove() {
  [ "$#" -gt 0 ] || return 0
  case "$PM" in
    opkg) opkg remove "$@" ;;
    apk)  apk del "$@" ;;
    *) die "PM=$PM not supported" ;;
  esac
}

pm_download() {
  pkg="$1"
  out_dir="${2:-.}"
  [ -n "$pkg" ] || die "pm_download: package name is required"
  [ -d "$out_dir" ] || mkdir -p "$out_dir"

  case "$PM" in
    opkg)
      (cd "$out_dir" && opkg download "$pkg")
      ;;
    apk)
      pm_apk_fetch_packages "$out_dir" "$pkg"
      ;;
    *)
      die "PM=$PM not supported"
      ;;
  esac
}

pm_apk_fetch_packages() {
  out_dir="$1"
  shift
  [ "$#" -gt 0 ] || return 1
  [ -d "$out_dir" ] || mkdir -p "$out_dir"
  (
    cd "$out_dir" || exit 1
    apk fetch "$@"
  )
}

pm_apk_find_fetched_file() {
  out_dir="$1"
  pkg="$2"
  [ -d "$out_dir" ] && [ -n "$pkg" ] || return 1
  # shellcheck disable=SC2086
  for f in "$out_dir"/${pkg}-*.apk "$out_dir"/${pkg}-[0-9]*; do
    [ -f "$f" ] || continue
    printf '%s' "$f"
    return 0
  done
  return 1
}

pm_apk_collect_fetch_package_names() {
  target="$1"
  out="$2"
  [ -n "$target" ] && [ -n "$out" ] || return 1

  printf '%s\n' "$target" >>"$out"
  _sim="${TMPDIR:-/tmp}/xfree-apk-sim.$$"
  if apk add -s "$target" >"$_sim" 2>&1 \
    || apk add --simulate "$target" >"$_sim" 2>&1; then
    grep 'Upgrading ' "$_sim" 2>/dev/null \
      | sed -n 's/.*Upgrading \([^ (]*\).*/\1/p' \
      >>"$out" || true
  fi
  rm -f "$_sim"
  sort -u "$out" -o "$out" 2>/dev/null || true
}

pm_apk_add_files_logged() {
  _log="$1"
  shift
  [ -n "$_log" ] || return 1
  [ "$#" -gt 0 ] || return 1
  : >"$_log"
  pm_apk_wait_idle "${PM_APK_LOCK_WAIT_SEC:-60}" || true
  _pm_apk_add_args=""
  if [ "$APK_ALLOW_UNTRUSTED" = "1" ]; then
    _pm_apk_add_args="$_pm_apk_add_args --allow-untrusted"
  fi
  if [ "$APK_FORCE_NON_REPOSITORY" = "1" ]; then
    _pm_apk_add_args="$_pm_apk_add_args --force-non-repository"
  fi
  # shellcheck disable=SC2086
  apk add $_pm_apk_add_args "$@" >>"$_log" 2>&1
  _rc=$?
  [ "$_rc" -eq 0 ] && return 0
  cat "$_log" >&2
  return "$_rc"
}

# Установка из каталога apk fetch (target + зависимости, напр. hostapd-common).
pm_apk_install_fetched_dir_logged() {
  fetch_dir="$1"
  log="$2"
  [ -d "$fetch_dir" ] || return 1
  _files=""
  for _f in "$fetch_dir"/*; do
    [ -f "$_f" ] || continue
    _files="$_files $_f"
  done
  [ -n "$_files" ] || return 1
  # shellcheck disable=SC2086
  pm_apk_add_files_logged "$log" $_files
}

pm_install_file() {
  file="$1"
  [ -f "$file" ] || die "Package file not found: $file"

  case "$PM" in
    opkg)
      opkg install "$file"
      ;;
    apk)
      # Локальный файл (release zip): --allow-untrusted + --force-non-repository (OpenWrt 25.12 apk).
      pm_apk_wait_idle "${PM_APK_LOCK_WAIT_SEC:-60}" || true
      _pm_apk_add_args=""
      if [ "$APK_ALLOW_UNTRUSTED" = "1" ]; then
        _pm_apk_add_args="$_pm_apk_add_args --allow-untrusted"
      fi
      if [ "$APK_FORCE_NON_REPOSITORY" = "1" ]; then
        _pm_apk_add_args="$_pm_apk_add_args --force-non-repository"
      fi
      # shellcheck disable=SC2086
      apk add $_pm_apk_add_args "$file"
      ;;
    *)
      die "PM=$PM not supported"
      ;;
  esac
}

pm_apk_route_default_exists() {
  command -v ip >/dev/null 2>&1 || return 0
  ip route 2>/dev/null | grep -q '^default '
}

# Проверка маршрута + apk update перед деструктивной заменой пакетов.
pm_apk_preflight_repository() {
  case "$PM" in
    apk) ;;
    *) return 0 ;;
  esac

  if ! pm_apk_route_default_exists; then
    warn "apk preflight: нет default route"
    return 1
  fi

  pm_update || {
    warn "apk preflight: apk update не удался (wget/DNS?)"
    return 1
  }
  return 0
}

pm_apk_name_is_upgradable() {
  pkg="$1"
  [ -n "$pkg" ] || return 1
  pm_apk_list_upgradable_names | grep -Fxq "$pkg"
}

# Имена зависимостей target из индекса репозитория (после apk update).
pm_apk_collect_target_dep_names() {
  target="$1"
  out="$2"
  [ -n "$target" ] && [ -n "$out" ] || return 1

  apk info -R "$target" 2>/dev/null \
    | grep -v 'depends on:' \
    | sed 's/^[[:space:]]*//;s/[[:space:]].*$//' \
    | awk '
      /^[a-zA-Z0-9][a-zA-Z0-9+._-]*$/ { print }
      /^[a-zA-Z0-9][a-zA-Z0-9+._-]*=/ {
        sub(/=.*/, "")
        if ($0 != "") print
      }
    ' \
    >>"$out" 2>/dev/null || true
}

# План apk add -s: какие пакеты будут Upgrading при установке target.
pm_apk_collect_simulate_upgrades() {
  target="$1"
  out="$2"
  sim="$3"
  [ -n "$target" ] && [ -n "$out" ] && [ -n "$sim" ] || return 1

  if apk add -s "$target" >"$sim" 2>&1 \
    || apk add --simulate "$target" >"$sim" 2>&1; then
    grep 'Upgrading ' "$sim" 2>/dev/null \
      | sed -n 's/.*Upgrading \([^ (]*\).*/\1/p' \
      >>"$out" || true
    return 0
  fi
  return 1
}

pm_apk_world_has() {
  pkg="$1"
  [ -n "$pkg" ] || return 1
  grep -Fxq "$pkg" /etc/apk/world 2>/dev/null
}

pm_apk_error_log_is_network_failure() {
  log="$1"
  [ -f "$log" ] || return 1
  grep -qE 'wget|Operation not permitted|unexpected end of file|Failed to send request|ERROR: wget' "$log" 2>/dev/null
}

pm_apk_error_log_is_solver_failure() {
  log="$1"
  [ -f "$log" ] || return 1
  grep -qE 'unable to select packages|conflicts:|breaks:' "$log" 2>/dev/null
}

pm_apk_add_logged() {
  _log="$1"
  shift
  [ -n "$_log" ] || return 1
  : >"$_log"
  pm_apk_wait_idle "${PM_APK_LOCK_WAIT_SEC:-60}" || true
  apk add "$@" >>"$_log" 2>&1
  _rc=$?
  [ "$_rc" -eq 0 ] && return 0
  cat "$_log" >&2
  return "$_rc"
}

# Перед заменой: убрать «битый» target из world; снять dual-world (target + old).
pm_apk_prepare_exclusive_world() {
  target="$1"
  shift

  case "$PM" in
    apk) ;;
    *) return 0 ;;
  esac
  [ -n "$target" ] || return 0

  pm_apk_scrub_stale_world_package "$target"

  for old in "$@"; do
    [ -n "$old" ] || continue
    if pm_apk_world_has "$target" && pm_apk_world_has "$old"; then
      warn "apk world: конфликт $target и $old — убираю $target из world"
      apk del "$target" 2>/dev/null || true
      apk fix 2>/dev/null || true
      pm_apk_scrub_stale_world_package "$target"
    fi
  done
}

# hostapd-common и др. обновляются атомарно с wpad в одном apk add — только лог плана.
pm_apk_log_target_install_plan() {
  target="$1"
  case "$PM" in
    apk) ;;
    *) return 0 ;;
  esac
  [ -n "$target" ] || return 0

  _sim="${TMPDIR:-/tmp}/xfree-apk-sim.$$"
  if apk add -s "$target" >"$_sim" 2>&1 \
    || apk add --simulate "$target" >"$_sim" 2>&1; then
    grep -E 'Upgrading |Installing |Removing ' "$_sim" 2>/dev/null | while read -r line; do
      [ -n "$line" ] || continue
      info "apk план: $(printf '%s' "$line" | sed 's/^[[:space:]]*//')"
    done || true
  else
    warn "apk simulate для $target не удался — установка может потребовать замену старого пакета"
  fi
  rm -f "$_sim"
}

# Обновить отдельные upgradable-зависимости (не для exclusive replace wpad/dnsmasq).
pm_apk_preupgrade_target_deps() {
  target="$1"
  case "$PM" in
    apk) ;;
    *) return 0 ;;
  esac
  [ -n "$target" ] || return 0

  _sim="${TMPDIR:-/tmp}/xfree-apk-sim.$$"
  _deps="${TMPDIR:-/tmp}/xfree-apk-deps.$$"
  : >"$_deps"

  pm_apk_collect_simulate_upgrades "$target" "$_deps" "$_sim" || true
  pm_apk_collect_target_dep_names "$target" "$_deps"

  _upgraded=0
  _checked=0
  while read -r dep; do
    [ -n "$dep" ] || continue
    [ "$dep" = "$target" ] && continue
    _checked=$((_checked + 1))
    if ! pm_apk_name_is_upgradable "$dep"; then
      continue
    fi
    _upgraded=$((_upgraded + 1))
    info "Обновляю зависимость $dep перед установкой $target"
    apk add "$dep" || apk upgrade "$dep" || warn "Не удалось обновить $dep"
  done <<EOF
$(sort -u "$_deps" 2>/dev/null)
EOF

  if [ "$_upgraded" = "0" ]; then
    if [ "$_checked" -gt 0 ]; then
      info "Зависимости $target: в индексе репозитория обновлений нет"
    else
      info "Зависимости $target: не удалось получить список (apk info -R / simulate)"
    fi
  fi

  rm -f "$_sim" "$_deps"
}

# Убрать target из apk world после сбоя (частичная установка / EOF).
pm_apk_scrub_stale_world_package() {
  pkg="$1"
  case "$PM" in
    apk) ;;
    *) return 0 ;;
  esac
  [ -n "$pkg" ] || return 0
  pm_is_installed "$pkg" && return 0

  if grep -Fxq "$pkg" /etc/apk/world 2>/dev/null; then
    warn "apk world: убираю неполный $pkg"
    apk del "$pkg" 2>/dev/null || true
    apk fix 2>/dev/null || true
  fi
}

# Одна попытка exclusive replace: локальные apk или репозиторий; опционально удалить old.
pm_apk_replace_try_install() {
  target="$1"
  fetch_dir="$2"
  log="$3"
  use_fetched="$4"
  remove_old="$5"
  shift 5

  if [ "$remove_old" = "1" ]; then
    for _old in "$@"; do
      [ -n "$_old" ] || continue
      pm_is_installed "$_old" || continue
      info "Удаляю $_old"
      pm_remove "$_old" || true
    done
  fi
  if [ "$use_fetched" = "1" ] \
    && pm_apk_find_fetched_file "$fetch_dir" "$target" >/dev/null 2>&1; then
    info "Устанавливаю $target из локальных apk"
    pm_apk_install_fetched_dir_logged "$fetch_dir" "$log" && return 0
  fi
  info "Устанавливаю $target из репозитория"
  pm_apk_add_logged "$log" "$target"
}

# Замена взаимоисключающих пакетов (dnsmasq→dnsmasq-full, wpad-basic→wpad-mesh, …).
# old_pkgs: один или несколько имён; удаляется первый найденный установленный (apk — все из списка).
# apk/opkg: сначала прямой install; при неудаче — remove old, install; opkg — ещё fallback download.
pm_replace_exclusive_package() {
  target="$1"
  shift

  [ -n "$target" ] || die "pm_replace_exclusive_package: target required"
  [ "$#" -gt 0 ] || die "pm_replace_exclusive_package: old package name(s) required"

  if pm_is_installed "$target"; then
    info "$target уже установлен"
    return 0
  fi

  had_old=0
  old_installed=""
  for old in "$@"; do
    [ -n "$old" ] || continue
    if pm_is_installed "$old"; then
      had_old=1
      [ -n "$old_installed" ] || old_installed="$old"
    fi
  done

  [ "$had_old" = "1" ] || {
    warn "pm_replace_exclusive_package: ни один из [$*] не установлен"
    return 1
  }

  _ok=0
  case "$PM" in
    apk)
      pm_apk_preflight_repository \
        || warn "Репозиторий apk недоступен — замена может оставить систему без Wi-Fi/DNS"

      pm_apk_prepare_exclusive_world "$target" "$@"
      pm_apk_log_target_install_plan "$target"

      _apk_log="${TMPDIR:-/tmp}/xfree-apk-replace.$$"
      _fetch_dir="$(mktemp -d /tmp/xfree-apk-fetch.XXXXXX)"
      _fetch_list="${TMPDIR:-/tmp}/xfree-apk-fetch-names.$$"
      : >"$_fetch_list"
      pm_apk_collect_fetch_package_names "$target" "$_fetch_list"
      if [ -s "$_fetch_list" ]; then
        info "Скачиваю пакеты локально (apk fetch): $(tr '\n' ' ' <"$_fetch_list")"
        # shellcheck disable=SC2046
        pm_apk_fetch_packages "$_fetch_dir" $(cat "$_fetch_list") \
          || warn "apk fetch не удался — останется установка из репозитория"
      fi
      _have_fetched=0
      if pm_apk_find_fetched_file "$_fetch_dir" "$target" >/dev/null 2>&1; then
        _have_fetched=1
      fi

      if pm_apk_replace_try_install "$target" "$_fetch_dir" "$_apk_log" 1 0; then
        _ok=1
      elif pm_apk_error_log_is_network_failure "$_apk_log"; then
        if [ "$_have_fetched" = "1" ]; then
          info "Сеть: повтор установки $target из локальных apk"
          pm_apk_replace_try_install "$target" "$_fetch_dir" "$_apk_log" 1 0 && _ok=1
        fi
        [ "$_ok" = "1" ] || {
          warn "Сбой сети при установке $target — старый wpad не удаляем"
          warn "Без перезагрузки: sh ${ROOT_DIR:-/root/xfree-toolbox}/system/recover-apk-network.sh --full"
        }
      else
        if pm_apk_error_log_is_solver_failure "$_apk_log"; then
          warn "apk solver: повтор после очистки world"
          pm_apk_prepare_exclusive_world "$target" "$@"
        fi
        info "Повторная установка $target"
        if pm_apk_replace_try_install "$target" "$_fetch_dir" "$_apk_log" 1 0; then
          _ok=1
        elif pm_apk_replace_try_install "$target" "$_fetch_dir" "$_apk_log" 0 0; then
          _ok=1
        elif pm_apk_error_log_is_network_failure "$_apk_log"; then
          if [ "$_have_fetched" = "1" ]; then
            pm_apk_replace_try_install "$target" "$_fetch_dir" "$_apk_log" 1 0 && _ok=1
          fi
          [ "$_ok" = "1" ] || {
            warn "Сбой сети при установке $target — старый wpad не удаляем"
            warn "Без перезагрузки: sh ${ROOT_DIR:-/root/xfree-toolbox}/system/recover-apk-network.sh --full"
          }
        else
          if pm_apk_replace_try_install "$target" "$_fetch_dir" "$_apk_log" 1 1 "$@"; then
            _ok=1
          elif pm_apk_replace_try_install "$target" "$_fetch_dir" "$_apk_log" 0 1 "$@"; then
            _ok=1
          elif pm_apk_error_log_is_network_failure "$_apk_log"; then
            if [ "$_have_fetched" = "1" ]; then
              pm_apk_replace_try_install "$target" "$_fetch_dir" "$_apk_log" 1 1 "$@" && _ok=1
            fi
            [ "$_ok" = "1" ] || {
              warn "Сбой сети после удаления старого пакета — Wi-Fi может не работать"
              warn "Без перезагрузки: sh ${ROOT_DIR:-/root/xfree-toolbox}/system/recover-apk-network.sh --full"
            }
          fi
        fi
      fi
      rm -f "$_apk_log" "$_fetch_list"
      rm -rf "$_fetch_dir"
      ;;
    opkg)
      if pm_install "$target" >/dev/null 2>&1; then
        _ok=1
      else
        info "Прямой install $target не сработал, fallback (download/remove/install)"
        tmp_dir="$(mktemp -d /tmp/xfree-pkg-replace.XXXXXX)"
        trap 'rm -rf "$tmp_dir" >/dev/null 2>&1 || true' EXIT INT TERM

        if pm_download "$target" "$tmp_dir"; then
          ipk_file="$(ls "$tmp_dir"/"${target}"*.ipk 2>/dev/null | sed -n '1p')"
          if [ -n "${ipk_file:-}" ]; then
            for old in "$@"; do
              pm_is_installed "$old" || continue
              info "Удаляю $old"
              pm_remove "$old" || true
            done
            info "Устанавливаю $target из локального ipk"
            if pm_install_file "$ipk_file"; then
              _ok=1
            fi
          fi
        fi
        rm -rf "$tmp_dir" >/dev/null 2>&1 || true
        trap - EXIT INT TERM
      fi
      ;;
    *)
      die "PM=$PM not supported for pm_replace_exclusive_package"
      ;;
  esac

  if [ "$_ok" = "1" ] && pm_is_installed "$target"; then
    success "$target установлен"
    return 0
  fi

  if [ -n "$old_installed" ] && ! pm_is_installed "$target"; then
    _still_have_old=0
    for old in "$@"; do
      pm_is_installed "$old" && _still_have_old=1
    done
    if [ "$_still_have_old" = "0" ]; then
      pm_apk_scrub_stale_world_package "$target"
      if [ "$PM" = "apk" ]; then
        _rb_log="${TMPDIR:-/tmp}/xfree-apk-rollback.$$"
        warn "Восстанавливаю $old_installed после сбоя установки $target…"
        if pm_apk_add_logged "$_rb_log" "$old_installed"; then
          :
        elif pm_apk_error_log_is_network_failure "$_rb_log"; then
          warn "Откат $old_installed: сбой сети — см. recover-apk-network.sh --full"
        else
          warn "Не удалось переустановить $old_installed"
        fi
        rm -f "$_rb_log"
      else
        warn "Восстанавливаю $old_installed после сбоя установки $target…"
        pm_install "$old_installed" || warn "Не удалось переустановить $old_installed"
      fi
    fi
  fi
  return 1
}

pm_is_installed() {
  pkg="$1"
  case "$PM" in
    opkg) opkg list-installed "$pkg" 2>/dev/null | awk '{print $1}' | grep -Fxq "$pkg" ;;
    apk)  apk info -e "$pkg" >/dev/null 2>&1 ;;
    *) die "PM=$PM not supported" ;;
  esac
}

pm_list_installed_names() {
  case "$PM" in
    opkg) opkg list-installed 2>/dev/null | awk '{print $1}' ;;
    apk)  apk info 2>/dev/null ;;
    *) die "PM=$PM not supported" ;;
  esac
}

pm_list_installed_luci() {
  pm_list_installed_names | awk '/^luci([_-]|$)/ {print}' | sort -u
}

pm_repo_has() {
  pkg="$1"
  case "$PM" in
    opkg)
      opkg list 2>/dev/null | awk '{print $1}' | grep -Fxq "$pkg"
      ;;
    apk)
      apk search -x "$pkg" 2>/dev/null \
        | awk '
            {
              line=$0
              sub(/[[:space:]].*$/, "", line)
              name=line
              sub(/-[0-9][A-Za-z0-9._~+-]*$/, "", name)
              print name
            }
          ' \
        | grep -Fxq "$pkg"
      ;;
    *)
      die "PM=$PM not supported"
      ;;
  esac
}

# Имя пакета из «pkg-ver» (первая колонка apk list / apk version); для pipe.
pm_apk_strip_version_suffix() {
  awk '{
    pkg = $1
    if (sub(/-[0-9][A-Za-z0-9._~+]*(-r[0-9]+)?$/, "", pkg)) {
      if (pkg != "") print pkg
      next
    }
    sub(/20[0-9]{6,}(-r[0-9]+)?$/, "", pkg)
    if (pkg != "") print pkg
  }'
}

pm_apk_list_upgradable_names() {
  n=0
  if apk version -l '<' 2>/dev/null | grep -q ' < '; then
    apk version -l '<' 2>/dev/null \
      | grep ' < ' \
      | pm_apk_strip_version_suffix \
      | sort -u > "${TMPDIR:-/tmp}/apk-upgradable.$$"
    n="$(wc -l < "${TMPDIR:-/tmp}/apk-upgradable.$$" | tr -d ' \n\r\t')"
    case "$n" in
      '' | *[!0-9]*) n=0 ;;
    esac
    if [ "$n" -gt 0 ] 2>/dev/null; then
      cat "${TMPDIR:-/tmp}/apk-upgradable.$$"
      rm -f "${TMPDIR:-/tmp}/apk-upgradable.$$"
      return 0
    fi
    rm -f "${TMPDIR:-/tmp}/apk-upgradable.$$"
  fi
  apk list -u 2>/dev/null | pm_apk_strip_version_suffix | sort -u
}

pm_list_upgradable_names() {
  case "$PM" in
    opkg)
      opkg list-upgradable 2>/dev/null | awk '{print $1}' | sort -u
      ;;
    apk)
      pm_apk_list_upgradable_names
      ;;
    *)
      die "PM=$PM not supported"
      ;;
  esac
}

pm_apk_sanitize_world_qpins() {
  _world="/etc/apk/world"
  _tmp="${TMPDIR:-/tmp}/xfree-apk-world.$$"
  _backup=""

  [ -f "$_world" ] || return 0

  sed -E 's/><Q[[:alnum:]+\/=._-]+$//' "$_world" >"$_tmp" 2>/dev/null || {
    rm -f "$_tmp" 2>/dev/null || true
    warn "Не удалось проверить /etc/apk/world на устаревшие Q-пины"
    return 0
  }

  if cmp -s "$_world" "$_tmp" 2>/dev/null; then
    rm -f "$_tmp" 2>/dev/null || true
    return 0
  fi

  _backup="${_world}.xfree-bak.$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"
  cp "$_world" "$_backup" 2>/dev/null || _backup=""
  mv "$_tmp" "$_world"

  if [ -n "$_backup" ]; then
    info "apk world: удалены устаревшие Q-пины (backup: $_backup)"
  else
    info "apk world: удалены устаревшие Q-пины"
  fi
}

pm_upgrade() {
  [ "$#" -gt 0 ] || return 0
  case "$PM" in
    opkg) opkg install "$@" ;;
    apk)  apk upgrade "$@" ;;
    *) die "PM=$PM not supported" ;;
  esac
}

# Пакетное обновление всех установленных пакетов (аналог LuCI «Upgrade all»).
pm_upgrade_all() {
  case "$PM" in
    opkg)
      # OpenWrt 24.10+ opkg: bare `upgrade` без имён пакетов — ошибка usage.
      set -- $(pm_list_upgradable_names)
      [ "$#" -gt 0 ] || return 0
      opkg upgrade "$@"
      ;;
    apk)
      pm_apk_sanitize_world_qpins
      apk upgrade
      ;;
    *) die "PM=$PM not supported" ;;
  esac
}

pm_upgrade_live() {
  [ "$#" -gt 0 ] || return 0
  case "$PM" in
    opkg) common_run_live opkg install "$@" ;;
    apk)  common_run_live apk upgrade "$@" ;;
    *) die "PM=$PM not supported" ;;
  esac
}

pm_install_or_upgrade_packages() {
  mode="install"
  force="0"
  changed="0"

  while [ "$#" -gt 0 ]; do
    case "$1" in
      --force) force="1" ;;
      --mode=install|--mode=upgrade) mode="${1#--mode=}" ;;
      --) shift; break ;;
      -*) die "Unknown option for pm_install_or_upgrade_packages: $1" ;;
      *) break ;;
    esac
    shift
  done

  [ "$#" -gt 0 ] || return 0

  for pkg in "$@"; do
    if [ "$mode" = "upgrade" ]; then
      if pm_is_installed "$pkg"; then
        info "Updating: $pkg"
        pm_upgrade "$pkg" || return 2
      else
        info "Installing missing package: $pkg"
        pm_install "$pkg" || return 2
      fi
      changed="1"
      continue
    fi

    if pm_is_installed "$pkg" && [ "$force" != "1" ]; then
      say "[=] Already installed: $pkg"
      continue
    fi

    if [ "$force" = "1" ] && pm_is_installed "$pkg"; then
      info "Reinstalling: $pkg"
    else
      info "Installing: $pkg"
    fi

    pm_install "$pkg" || return 2
    changed="1"
  done

  # 0 = без изменений; 1 = установлено/обновлено; 2+ = ошибка.
  [ "$changed" = "1" ] && return 1
  return 0
}

pm_map_luci_pkg_to_ru_i18n() {
  pkg="$1"

  case "$pkg" in
    luci-i18n-*) return 1 ;;
  esac

  case "$pkg" in
    luci-base)
      printf 'luci-i18n-base-ru\n'
      return 0
      ;;
    luci-app-*)
      module="${pkg#luci-app-}"
      ;;
    luci-proto-*)
      module="${pkg#luci-proto-}"
      ;;
    luci-theme-*)
      module="${pkg#luci-theme-}"
      ;;
    luci|luci-ssl|luci-light|luci-mod-*|luci-lib-*)
      return 1
      ;;
    *)
      return 1
      ;;
  esac

  printf 'luci-i18n-%s-ru\n' "$module"
}

pm_list_missing_luci_i18n_ru() {
  force="0"

  while [ "$#" -gt 0 ]; do
    case "$1" in
      --force) force="1" ;;
      *) die "Unknown option for pm_list_missing_luci_i18n_ru: $1" ;;
    esac
    shift
  done

  pm_list_installed_luci \
    | while IFS= read -r pkg; do
        ru_pkg="$(pm_map_luci_pkg_to_ru_i18n "$pkg" || true)"
        [ -n "$ru_pkg" ] || continue

        if [ "$force" = "1" ]; then
          printf '%s\n' "$ru_pkg"
          continue
        fi

        pm_is_installed "$ru_pkg" || printf '%s\n' "$ru_pkg"
      done \
    | sort -u
}

pm_install_luci_i18n_ru() {
  force="0"

  while [ "$#" -gt 0 ]; do
    case "$1" in
      --force) force="1" ;;
      *) die "Unknown option for pm_install_luci_i18n_ru: $1" ;;
    esac
    shift
  done

  pkgs="$(pm_list_missing_luci_i18n_ru $( [ "$force" = "1" ] && printf '%s' -- '--force' ))"
  [ -n "$pkgs" ] || {
    say "[=] LUCI RU packages are already installed."
    return 0
  }

  # shellcheck disable=SC2086
  pm_install_or_upgrade_packages $( [ "$force" = "1" ] && printf '%s' -- '--force' ) -- $pkgs || {
    rc=$?
    [ "$rc" -eq 1 ] || return "$rc"
  }
}