#!/bin/sh
# shellcheck shell=sh
# Apk registry (pubkey + repositories.d) for xfree-toolbox on OpenWrt 25+.

xfree_apk_registry_repo_file() {
  _dir="${ROUTER_APK_REPOS_DIR:-${APK_REPOS_DIR:-/etc/apk/repositories.d}}"
  _name="${ROUTER_APK_REPO_FILE:-${APK_REPO_FILE:-xfree-toolbox.list}}"
  printf '%s/%s\n' "$_dir" "$_name"
}

xfree_apk_registry_pubkey_file() {
  _dir="${ROUTER_APK_KEYS_DIR:-${APK_KEYS_DIR:-/etc/apk/keys}}"
  _name="${XFREE_APK_PUBKEY_NAME:-${PUBKEY_BASENAME:-xfree-toolbox.pub}}"
  printf '%s/%s\n' "$_dir" "$_name"
}

xfree_apk_registry_normalize_feed_url() {
  _base="${1:-}"
  [ -n "$_base" ] || return 1
  case "$_base" in
    */packages.adb) printf '%s\n' "$_base" ;;
    *) printf '%s/packages.adb\n' "${_base%/}" ;;
  esac
}

xfree_apk_registry_feed_url() {
  xfree_apk_registry_normalize_feed_url "${FEED_BASE:-${XFREE_APK_FEED_PUBLIC_BASE:-}}"
}

xfree_apk_feed_state_file() {
  printf '%s/apk-feed.env\n' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

# Direct raw.githubusercontent.com — apk/uclient-fetch does not follow 30x
# (github.com/releases/download and github.com/.../raw/... both redirect).
xfree_apk_feed_github_public_base() {
  if [ -n "${XFREE_APK_FEED_GITHUB_PUBLIC_BASE:-}" ]; then
    printf '%s\n' "${XFREE_APK_FEED_GITHUB_PUBLIC_BASE%/}"
    return 0
  fi
  printf 'https://raw.githubusercontent.com/%s/%s\n' \
    "${XFREE_APK_FEED_GITHUB_REPO:-XFree/xfree-toolbox-releases}" \
    "${XFREE_APK_FEED_GITHUB_BRANCH:-${XFREE_APK_FEED_GITHUB_TAG:-main}}"
}

xfree_apk_feed_load_state() {
  XFREE_APK_FEED_SOURCE="${XFREE_APK_FEED_SOURCE:-cloud}"
  _sf="$(xfree_apk_feed_state_file)"
  if [ -r "$_sf" ]; then
    # shellcheck disable=SC1090
    . "$_sf"
  fi
  case "${XFREE_APK_FEED_SOURCE:-}" in
    github|cloud) ;;
    *) XFREE_APK_FEED_SOURCE=cloud ;;
  esac
}

xfree_apk_feed_save_source() {
  _src="${1:-}"
  case "$_src" in
    cloud|github) ;;
    *) return 1 ;;
  esac
  _sf="$(xfree_apk_feed_state_file)"
  mkdir -p "$(dirname "$_sf")" || return 1
  printf "XFREE_APK_FEED_SOURCE='%s'\n" "$_src" >"$_sf" || return 1
  XFREE_APK_FEED_SOURCE="$_src"
}

# Infer cloud|github from repositories.d, else from env (GitHub factory injects github).
xfree_apk_feed_infer_source() {
  _repo="$(xfree_apk_registry_repo_file)"
  if [ -f "$_repo" ] && grep -qE 'raw\.githubusercontent\.com/' "$_repo" 2>/dev/null; then
    printf '%s\n' github
    return 0
  fi
  if [ -f "$_repo" ]; then
    printf '%s\n' cloud
    return 0
  fi
  case "${XFREE_APK_FEED_SOURCE:-cloud}" in
    github) printf '%s\n' github ;;
    *) printf '%s\n' cloud ;;
  esac
}

# Persist source on first install. Existing apk-feed.env is sticky unless XFREE_APK_FEED_SOURCE_EXPLICIT=1.
xfree_apk_feed_seed_source() {
  _sf="$(xfree_apk_feed_state_file)"
  if [ -r "$_sf" ] && [ "${XFREE_APK_FEED_SOURCE_EXPLICIT:-0}" != "1" ]; then
    xfree_apk_feed_load_state
    return 0
  fi
  _src="${XFREE_APK_FEED_SOURCE:-}"
  if [ "${XFREE_APK_FEED_SOURCE_EXPLICIT:-0}" != "1" ]; then
    _src="$(xfree_apk_feed_infer_source)"
  fi
  case "$_src" in
    cloud|github) ;;
    *) _src=cloud ;;
  esac
  xfree_apk_feed_save_source "$_src"
}

xfree_apk_feed_tar_url() {
  xfree_apk_feed_load_state
  case "$XFREE_APK_FEED_SOURCE" in
    github)
      printf '%s/%s\n' "$(xfree_apk_feed_github_public_base)" "${ARCHIVE_NAME:-xfree-toolbox.tar.gz}"
      ;;
    *)
      printf '%s\n' "${UPDATE_URL:-${XFREE_UPDATE_URL:-}}"
      ;;
  esac
}

# Factory installer: GitHub raw when overlay is github (self-update must not wget Nextcloud).
xfree_apk_feed_install_url() {
  _name="${XFREE_INSTALL_SCRIPT_NAME:-${INSTALL_SCRIPT_NAME:-install-from-cloud.sh}}"
  xfree_apk_feed_load_state
  case "$XFREE_APK_FEED_SOURCE" in
    github)
      printf '%s/%s\n' "$(xfree_apk_feed_github_public_base)" "$_name"
      ;;
    *)
      _factory="${FACTORY_PUBLIC_BASE:-${XFREE_FACTORY_PUBLIC_BASE:-}}"
      [ -n "$_factory" ] || return 1
      printf '%s/%s\n' "${_factory%/}" "$_name"
      ;;
  esac
}

xfree_apk_registry_feed_url_for_source() {
  _src="${1:-cloud}"
  case "$_src" in
    github)
      xfree_apk_registry_normalize_feed_url "$(xfree_apk_feed_github_public_base)"
      ;;
    cloud|*)
      xfree_apk_registry_normalize_feed_url "${FEED_BASE:-${XFREE_APK_FEED_PUBLIC_BASE:-}}"
      ;;
  esac
}

xfree_apk_feed_active_url() {
  xfree_apk_feed_load_state
  xfree_apk_registry_feed_url_for_source "$XFREE_APK_FEED_SOURCE"
}

xfree_apk_feed_source_label() {
  xfree_apk_feed_load_state
  case "$XFREE_APK_FEED_SOURCE" in
    github) printf '%s' 'GitHub' ;;
    *) printf '%s' 'Nextcloud' ;;
  esac
}

# Host for DNS/health probes (recover-apk-network). Not a download URL.
xfree_apk_feed_probe_host() {
  xfree_apk_feed_load_state
  case "$XFREE_APK_FEED_SOURCE" in
    github) printf '%s\n' 'raw.githubusercontent.com' ;;
    *) printf '%s\n' 'xfree-cloud.duckdns.org' ;;
  esac
}

xfree_apk_feed_is_enabled() {
  _repo="$(xfree_apk_registry_repo_file)"
  [ -f "$_repo" ] || return 1
  grep -qE '^[[:space:]]*https?://' "$_repo"
}

xfree_apk_feed_restore_off() {
  _repo="$(xfree_apk_registry_repo_file)"
  _off="${_repo}.off"
  if [ -f "$_off" ] && [ ! -f "$_repo" ]; then
    mv "$_off" "$_repo" || return 1
  fi
  return 0
}

xfree_apk_feed_enable() {
  xfree_apk_feed_restore_off || true
  _url="$(xfree_apk_feed_active_url)" || return 1
  _repo="$(xfree_apk_registry_repo_file)"
  mkdir -p "$(dirname "$_repo")" || return 1
  printf '%s\n' "$_url" >"$_repo" || return 1
  chmod 0644 "$_repo" 2>/dev/null || true
  return 0
}

xfree_apk_feed_disable() {
  _repo="$(xfree_apk_registry_repo_file)"
  if [ ! -f "$_repo" ]; then
    _url="$(xfree_apk_feed_active_url)" || return 1
    mkdir -p "$(dirname "$_repo")" || return 1
    printf '# xfree-toolbox apk feed (disabled)\n# %s\n' "$_url" >"$_repo" || return 1
    chmod 0644 "$_repo" 2>/dev/null || true
    return 0
  fi
  _tmp="${_repo}.tmp.$$"
  awk '
    /^[[:space:]]*#/ { print; next }
    /^[[:space:]]*https?:\/\// { print "# " $0; next }
    { print }
  ' "$_repo" >"$_tmp" || {
    rm -f "$_tmp" 2>/dev/null || true
    return 1
  }
  mv -f "$_tmp" "$_repo"
}

xfree_apk_feed_set_source() {
  xfree_apk_feed_save_source "${1:-}" || return 1
  if xfree_apk_feed_is_enabled; then
    xfree_apk_feed_enable
  fi
}

xfree_apk_registry_pubkey_url() {
  if [ -n "${PUB_KEY_URL:-}" ]; then
    printf '%s\n' "$PUB_KEY_URL"
    return 0
  fi
  _basename="${XFREE_APK_PUBKEY_NAME:-${PUBKEY_BASENAME:-xfree-toolbox.pub}}"
  xfree_apk_feed_load_state
  case "$XFREE_APK_FEED_SOURCE" in
    github)
      printf '%s/%s\n' "$(xfree_apk_feed_github_public_base)" "$_basename"
      return 0
      ;;
  esac
  _factory="${FACTORY_PUBLIC_BASE:-${XFREE_FACTORY_PUBLIC_BASE:-}}"
  [ -n "$_factory" ] || return 1
  printf '%s/%s\n' "${_factory%/}" "$_basename"
}

# Last path segment of public.php/dav/files/<token>/…
xfree_apk_registry_share_token() {
  _url="${1:-}"
  _url="${_url%/}"
  [ -n "$_url" ] || return 1
  _token="${_url##*/}"
  [ -n "$_token" ] || return 1
  printf '%s\n' "$_token"
}

# True when factory base points at the tar share (common misconfig: pubkey 404).
xfree_apk_registry_factory_looks_like_tar_url() {
  _factory="${1:-${FACTORY_PUBLIC_BASE:-${XFREE_FACTORY_PUBLIC_BASE:-}}}"
  _update="${2:-${UPDATE_URL:-${XFREE_UPDATE_URL:-}}}"
  _ft=""
  _ut=""
  _ft="$(xfree_apk_registry_share_token "$_factory" 2>/dev/null || true)"
  _ut="$(xfree_apk_registry_share_token "$_update" 2>/dev/null || true)"
  [ -n "$_ft" ] && [ -n "$_ut" ] && [ "$_ft" = "$_ut" ]
}

xfree_apk_registry_default_factory_base() {
  printf '%s\n' "${XFREE_APK_FACTORY_DEFAULT:-https://xfree-cloud.duckdns.org/public.php/dav/files/L982AaEEYAHYtTj}"
}

xfree_apk_registry_configured() {
  [ -f "$(xfree_apk_registry_repo_file)" ] \
    && [ -f "$(xfree_apk_registry_pubkey_file)" ]
}

xfree_apk_registry_https_fetch() {
  _dst="$1"
  _url="$2"

  [ -n "$_url" ] || return 1
  XFREE_APK_REGISTRY_LAST_FETCH_URL="$_url"

  if command -v curl >/dev/null 2>&1; then
    if curl --http1.1 -fL --connect-timeout 25 --max-time 180 -o "$_dst" "$_url" 2>/dev/null \
      && [ -s "$_dst" ]; then
      return 0
    fi
    if curl --http1.1 -fL -k --connect-timeout 25 --max-time 180 -o "$_dst" "$_url" \
      && [ -s "$_dst" ]; then
      return 0
    fi
    return 1
  fi

  if command -v wget >/dev/null 2>&1; then
    if wget -T 25 -O "$_dst" "$_url" 2>/dev/null && [ -s "$_dst" ]; then
      return 0
    fi
    wget --no-check-certificate -T 25 -O "$_dst" "$_url" && [ -s "$_dst" ]
    return $?
  fi

  return 1
}

# Idempotent: ensure pubkey + feed list. Returns 0 when registry is ready.
xfree_ensure_apk_registry() {
  _repo="$(xfree_apk_registry_repo_file)"
  _pub="$(xfree_apk_registry_pubkey_file)"
  _keys_dir="${ROUTER_APK_KEYS_DIR:-${APK_KEYS_DIR:-/etc/apk/keys}}"
  _repos_dir="${ROUTER_APK_REPOS_DIR:-${APK_REPOS_DIR:-/etc/apk/repositories.d}}"
  _feed_url=""
  _pub_url=""
  _pub_tmp=""
  _had=0

  command -v apk >/dev/null 2>&1 || return 1

  xfree_apk_feed_seed_source || true

  if xfree_apk_registry_configured; then
    XFREE_APK_REGISTRY_STATUS=configured
    return 0
  fi

  _feed_url="$(xfree_apk_feed_active_url)" || return 1
  _pub_url="$(xfree_apk_registry_pubkey_url)" || return 1

  mkdir -p "$_keys_dir" "$_repos_dir" || return 1

  _pub_tmp="${TMPDIR:-/tmp}/xfree-registry-pubkey.$$"
  if ! xfree_apk_registry_https_fetch "$_pub_tmp" "$_pub_url"; then
    rm -f "$_pub_tmp" 2>/dev/null || true
    if command -v warn >/dev/null 2>&1; then
      warn "Не удалось скачать pubkey apk: $_pub_url"
      if xfree_apk_registry_factory_looks_like_tar_url; then
        warn "XFREE_FACTORY_PUBLIC_BASE совпадает с tar share (XFREE_UPDATE_URL); ключ на factory share"
      fi
    fi
    xfree_apk_feed_load_state
    _default_factory="$(xfree_apk_registry_default_factory_base)"
    _default_pub="${_default_factory%/}/${XFREE_APK_PUBKEY_NAME:-${PUBKEY_BASENAME:-xfree-toolbox.pub}}"
    if [ "${XFREE_APK_FEED_SOURCE:-}" = github ]; then
      rm -f "$_pub_tmp" 2>/dev/null || true
      return 1
    fi
    if [ "$_pub_url" != "$_default_pub" ] \
      && xfree_apk_registry_https_fetch "$_pub_tmp" "$_default_pub"; then
      if command -v warn >/dev/null 2>&1; then
        warn "Pubkey взят с factory по умолчанию: $_default_pub"
        warn "Исправьте XFREE_FACTORY_PUBLIC_BASE в config.sh (не подставляйте XFREE_UPDATE_URL)"
      fi
      FACTORY_PUBLIC_BASE="$_default_factory"
      XFREE_FACTORY_PUBLIC_BASE="$_default_factory"
    else
      rm -f "$_pub_tmp" 2>/dev/null || true
      return 1
    fi
  fi

  cp "$_pub_tmp" "$_pub" || {
    rm -f "$_pub_tmp" 2>/dev/null || true
    return 1
  }
  chmod 0644 "$_pub" 2>/dev/null || true
  rm -f "$_pub_tmp" 2>/dev/null || true

  printf '%s\n' "$_feed_url" >"$_repo" || return 1
  chmod 0644 "$_repo" 2>/dev/null || true

  XFREE_APK_REGISTRY_STATUS=auto-configured
  if command -v info >/dev/null 2>&1; then
    info "Apk registry: $_pub, $_repo"
  fi
  return 0
}
