#!/bin/sh
# shellcheck shell=sh
# Меню: запуск work-скриптов через lib/bg-task-run.sh и просмотр лога активной задачи.

# Требует до source: lib/ui.sh, lib/background-tasks.sh; ROOT_DIR или XFREE_TOOLBOX_ROOT.

ui_bg_task_default_log() {
    _name="${1:-task}"
    printf '%s/%s.log\n' "${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}" "$_name"
}

ui_bg_task_runner() {
    _root="${XFREE_TOOLBOX_ROOT:-${ROOT_DIR:-}}"
    [ -n "$_root" ] || return 1
    printf '%s/lib/bg-task-run.sh\n' "$_root"
}

# «Живой» tail лога до завершения pid; затем textbox с полным логом.
ui_bg_task_follow_log() {
    _title="${1:-Фоновая задача}"
    _log_file="${2:-${BG_TASK_LOG_FILE:-}}"
    _task_pid="${3:-${BG_TASK_PID:-}}"

    if [ -z "${_log_file:-}" ] || [ ! -f "$_log_file" ]; then
        ui_msgbox "$_title" "Файл лога не найден:
${_log_file:-<unknown>}

pid=${_task_pid:-?}"
        return 0
    fi

    if [ -z "${_task_pid:-}" ]; then
        UI_RUN_WITH_OUTPUT_MODE=textbox ui_run_with_output "$_title" \
            sh -c 'tail -n 400 "$1"' sh "$_log_file"
        return 0
    fi

    _live_out="/dev/tty"
    if ! [ -c "$_live_out" ] 2>/dev/null; then
        _live_out="/dev/stdout"
    fi

    if ui_have_whiptail; then
        clear >"$_live_out" 2>/dev/null || true
        printf '\n=== %s ===\n\n' "$_title" >"$_live_out"
        printf 'Живой лог обновляется до завершения задачи (pid=%s).\n\n' "$_task_pid" >"$_live_out"
    else
        printf '\n=== %s ===\n\n' "$_title"
        printf 'Живой лог (pid=%s)…\n\n' "$_task_pid"
    fi

    tail -n 220 -f "$_log_file" >"$_live_out" 2>/dev/null &
    _tail_pid=$!

    while kill -0 "$_task_pid" 2>/dev/null; do
        sleep 1
    done

    sleep 1
    kill "$_tail_pid" 2>/dev/null || true
    wait "$_tail_pid" 2>/dev/null || true

    _follow_rc=0
    _root="${XFREE_TOOLBOX_ROOT:-${ROOT_DIR:-}}"
    if [ -n "$_root" ] && [ -f "$_root/lib/background-tasks.sh" ]; then
        # shellcheck disable=SC1090
        . "$_root/lib/background-tasks.sh"
        if bg_tasks_read_last_meta 2>/dev/null; then
            _follow_rc="$(bg_tasks_resolve_exit_code \
                "${BG_TASK_LAST_STATUS:-}" \
                "${BG_TASK_LAST_EXIT_CODE:-0}" \
                "$_log_file")"
        else
            _follow_rc="$(bg_tasks_exit_code_from_log "$_log_file" 0)"
        fi
    fi

    _out="${TMPDIR:-/tmp}/xfree-bg-follow-$$.log"
    ui_strip_ansi_file "$_log_file" "$_out"

    if ui_have_whiptail; then
        printf '\n' >/dev/tty
        if [ "$_follow_rc" -eq 0 ]; then
            printf '[*] Задача завершена.\n' >/dev/tty
        else
            printf '[!] Задача завершилась с ошибкой (code=%s).\n' "$_follow_rc" >/dev/tty
        fi
        printf 'Нажмите Enter для просмотра полного лога...\n' >/dev/tty
        read -r _ </dev/tty || true
        if [ "$_follow_rc" -eq 0 ]; then
            ui_show_textbox "$_title" "$_out"
        else
            ui_show_textbox "$_title: ошибка" "$_out"
        fi
    else
        if [ "$_follow_rc" -eq 0 ]; then
            printf '\n[*] Задача завершена.\n'
        else
            printf '\n[!] Задача завершилась с ошибкой (code=%s).\n' "$_follow_rc"
        fi
        ui_pause
        cat "$_out"
    fi

    rm -f "$_out"
    return "$_follow_rc"
}

# Если уже есть фоновая задача — показать её лог; иначе false.
ui_bg_task_redirect_if_running() {
    _title="${1:-Фоновая задача}"
    bg_tasks_is_running || return 1
    _name="${BG_TASK_NAME:-задача}"
    ui_bg_task_follow_log "$_title: $_name (pid=${BG_TASK_PID:-?})" \
        "${BG_TASK_LOG_FILE:-}" "${BG_TASK_PID:-}"
    return 0
}

# Фоновый запуск через bg-task-run.sh (без nohup: на OpenWrt его часто нет).
ui_run_background_task() {
    _title="$1"
    _task_name="$2"
    shift 2

    [ -n "${_title:-}" ] && [ -n "${_task_name:-}" ] || return 1

    if ui_bg_task_redirect_if_running "$_title"; then
        return 0
    fi

    _runner="$(ui_bg_task_runner || true)"
    [ -n "${_runner:-}" ] && [ -f "$_runner" ] || {
        ui_msgbox "Ошибка" "Не найден lib/bg-task-run.sh"
        return 1
    }

    _log_file="$(ui_bg_task_default_log "$_task_name")"
    if ! ui_confirm "Фоновая задача" \
"Запустить «$_task_name» в фоне?

Лог:
$_log_file

Меню можно закрыть; LED мигает на время выполнения."; then
        return 0
    fi

    _toolbox_root="${XFREE_TOOLBOX_ROOT:-${ROOT_DIR:-}}"
    [ -n "$_toolbox_root" ] && export XFREE_TOOLBOX_ROOT="$_toolbox_root"

    [ -x "$_runner" ] || chmod +x "$_runner" 2>/dev/null || true
    if [ -f "${1:-}" ]; then
        chmod +x "$1" 2>/dev/null || true
    fi

    # Как install-from-cloud / WPS hotplug: subshell + &, work-скрипт через sh.
    (
        export XFREE_TOOLBOX_ROOT="$_toolbox_root"
        sh "$_runner" "$_task_name" --log "$_log_file" -- sh "$@"
    ) >/dev/null 2>&1 &
    sleep 1

    if bg_tasks_is_running; then
        ui_bg_task_follow_log "$_title (${BG_TASK_NAME:-$_task_name}, pid=${BG_TASK_PID:-?})" \
            "${BG_TASK_LOG_FILE:-$_log_file}" "${BG_TASK_PID:-}"
    else
        _log_tail=""
        if [ -f "$_log_file" ]; then
            _log_tail="$(tail -n 12 "$_log_file" 2>/dev/null || true)"
        fi
        ui_msgbox "$_title" "Задача завершилась сразу или не стартовала.

Лог:
$_log_file
${_log_tail:+
---
$_log_tail}"
    fi
    return 0
}

# run_log с флагом --background --task-name <name>
ui_run_log() {
    _bg=0
    _task_name=""
    while [ $# -gt 0 ]; do
        case "$1" in
            --background)
                _bg=1
                shift
                ;;
            --task-name)
                [ $# -ge 2 ] || return 1
                _task_name="$2"
                shift 2
                ;;
            *)
                break
                ;;
        esac
    done

    _title="${1:-}"
    shift || true
    [ -n "$_title" ] || return 1

    if [ "$_bg" = "1" ]; then
        [ -n "$_task_name" ] || _task_name="menu-task-$$"
        ui_run_background_task "$_title" "$_task_name" "$@"
        return 0
    fi

    run_mode="${UI_RUN_WITH_OUTPUT_MODE:-live-and-textbox}"
    UI_RUN_WITH_OUTPUT_MODE="$run_mode" ui_run_with_output "$_title" "$@"
}
