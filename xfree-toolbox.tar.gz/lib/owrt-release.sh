#!/bin/sh
# OpenWrt release helpers (distribution channel: tar vs apk).
# shellcheck shell=sh

owrt_release_load() {
  OWRT_DISTRIB_RELEASE=""
  OWRT_DISTRIB_ID=""
  OWRT_RELEASE_MAJOR=""

  if [ -f /etc/openwrt_release ]; then
    # shellcheck disable=SC1091
    . /etc/openwrt_release 2>/dev/null || true
    OWRT_DISTRIB_RELEASE="${DISTRIB_RELEASE:-}"
    OWRT_DISTRIB_ID="${DISTRIB_ID:-}"
  fi

  if [ -z "$OWRT_DISTRIB_RELEASE" ] && [ -f /etc/os-release ]; then
    # shellcheck disable=SC1091
    . /etc/os-release 2>/dev/null || true
    OWRT_DISTRIB_RELEASE="${OPENWRT_VERSION:-${VERSION_ID:-}}"
    [ -n "$OWRT_DISTRIB_ID" ] || OWRT_DISTRIB_ID="${NAME:-OpenWrt}"
  fi

  [ -n "$OWRT_DISTRIB_RELEASE" ] || return 1

  OWRT_RELEASE_MAJOR="${OWRT_DISTRIB_RELEASE%%.*}"
  return 0
}

# Prints: tar | apk | unknown
owrt_install_channel_recommended() {
  if ! owrt_release_load; then
    printf '%s\n' unknown
    return 0
  fi

  case "$OWRT_RELEASE_MAJOR" in
    ''|*[!0-9]*)
      if command -v apk >/dev/null 2>&1; then
        printf '%s\n' apk
      else
        printf '%s\n' unknown
      fi
      ;;
    0|1|2|3|4|5|6|7|8|9|1[0-9]|2[0-4])
      printf '%s\n' tar
      ;;
    *)
      if command -v apk >/dev/null 2>&1; then
        printf '%s\n' apk
      else
        printf '%s\n' tar
      fi
      ;;
  esac
}

owrt_apk_package_installed() {
  command -v apk >/dev/null 2>&1 || return 1
  apk info -e xfree-toolbox >/dev/null 2>&1
}
