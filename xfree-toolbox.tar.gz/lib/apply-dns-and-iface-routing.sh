#!/bin/sh
# shellcheck shell=sh
# Menu/runtime wrapper: dns-routing/apply.sh then iface-routing/apply-routing.sh.
# Inner scripts stay callable (full apply-template, pbr-bypass, tests).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

COMMON_SH="${ROOT_DIR}/lib/common.sh"
[ -f "$COMMON_SH" ] || {
    echo "[-] Не найден common.sh: $COMMON_SH" >&2
    exit 1
}
# shellcheck disable=SC1090
. "$COMMON_SH"

PROFILE_DIR_ARG="${PROFILE_DIR:-}"
while [ "$#" -gt 0 ]; do
    case "$1" in
        --profile-dir)
            shift
            [ "$#" -gt 0 ] || die "Не указано значение для --profile-dir"
            PROFILE_DIR_ARG="$1"
            ;;
        -h|--help)
            cat <<EOF
Usage:
  $(basename "$0") [--profile-dir DIR]

Runs:
  1) dns-routing/apply.sh --no-restart  (skipped if profile has no DNS lists)
  2) iface-routing/apply-routing.sh
EOF
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift
done

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "$PROFILE_DIR_ARG")"
export PROFILE_DIR

DNS_APPLY_SCRIPT="${DNS_APPLY_SCRIPT:-$ROOT_DIR/dns-routing/apply.sh}"
IFACE_APPLY_SCRIPT="${IFACE_APPLY_SCRIPT:-$ROOT_DIR/iface-routing/apply-routing.sh}"

wrapper_has_dns_lists() {
    [ -d "$PROFILE_DIR/dns-routing/dns" ] || return 1
    find "$PROFILE_DIR/dns-routing/dns" -type f -name '*.lst' 2>/dev/null | grep '/fqdn\.d/' | sed -n '1p' | grep -q .
}

info "apply-dns-and-iface-routing: PROFILE_DIR=$PROFILE_DIR"

if wrapper_has_dns_lists; then
    [ -f "$DNS_APPLY_SCRIPT" ] || die "Не найден dns-routing apply: $DNS_APPLY_SCRIPT"
    info "apply-dns-and-iface-routing: dns-routing/apply (--no-restart)"
    sh "$DNS_APPLY_SCRIPT" --profile-dir "$PROFILE_DIR" --no-restart
else
    info "apply-dns-and-iface-routing: dns-routing/apply пропущен (нет DNS списков в профиле)"
fi

[ -f "$IFACE_APPLY_SCRIPT" ] || die "Не найден iface-routing apply: $IFACE_APPLY_SCRIPT"
info "apply-dns-and-iface-routing: iface-routing/apply-routing"
sh "$IFACE_APPLY_SCRIPT" --profile-dir "$PROFILE_DIR"

success "apply-dns-and-iface-routing: DNS redirect и маршрутизация применены"
