#!/bin/sh
# shellcheck shell=sh
# GitHub CDN proxy. Default off (direct). Affects only *.githubusercontent.com
# (raw / objects / release-assets / gist). Never github.com, codeload, api.
#
# XFREE_GITHUB_PROXY (канон: config.sh, по умолчанию 0):
#   empty | 0 | off | false | no — напрямую; таймаут githubusercontent.com —
#     один повтор через https://gh-proxy.com (http_fetch_file / http_download_file).
#     Если запрос шёл на github.com и curl ушёл редиректом на githubusercontent —
#     повтор зеркалит уже CDN-URL, не github.com.
#   1 | yes | true | on | gh-proxy | ghproxy — сразу prefix для githubusercontent
#   otherwise — custom base URL (trailing slash stripped), только githubusercontent

[ -n "${HTTP_GITHUB_PROXY_LOADED:-}" ] && return 0
HTTP_GITHUB_PROXY_LOADED=1

# curl: abort a crawl and let --retry open a fresh connection.
# GitHub/codeload is often DPI-shaped to ~20KB/s (still above 512 B/s), so the old
# --speed-limit 512 sat until HTTP_MAX_TIME (300s) then the retry finished in seconds.
: "${HTTP_CONNECT_TIMEOUT:=25}"
: "${HTTP_MAX_TIME:=300}"
: "${HTTP_FETCH_RETRY:=2}"
: "${HTTP_SPEED_TIME:=15}"
: "${HTTP_SPEED_LIMIT:=32768}"

if [ -z "${XFREE_GITHUB_PROXY:-}" ] && [ -f /etc/openwrt_release ]; then
  _ghp_overlay="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/github-proxy.env"
  if [ -r "$_ghp_overlay" ]; then
    # shellcheck disable=SC1090
    . "$_ghp_overlay"
  fi
  unset _ghp_overlay
fi

http_github_proxy_base() {
  _v="${XFREE_GITHUB_PROXY:-0}"
  case "$_v" in
    ""|0|off|false|no|OFF|FALSE|NO)
      return 0
      ;;
    1|yes|true|on|YES|TRUE|ON|gh-proxy|ghproxy)
      printf '%s\n' 'https://gh-proxy.com'
      return 0
      ;;
  esac
  printf '%s\n' "${_v%/}"
}

# $1=url $2=proxy base (no trailing slash). Prefix *.githubusercontent.com only.
http_github_proxy_wrap_url() {
  _url="$1"
  _base="${2:-}"
  _base="${_base%/}"
  [ -n "$_url" ] || {
    printf '%s\n' "$_url"
    return 0
  }
  [ -n "$_base" ] || {
    printf '%s\n' "$_url"
    return 0
  }

  case "$_url" in
    https://gh-proxy.com/*|http://gh-proxy.com/*|https://ghproxy.com/*|http://ghproxy.com/*)
      printf '%s\n' "$_url"
      return 0
      ;;
  esac
  case "$_url" in
    "${_base}"/*)
      printf '%s\n' "$_url"
      return 0
      ;;
  esac

  case "$_url" in
    https://*.githubusercontent.com/*|http://*.githubusercontent.com/*|https://githubusercontent.com/*|http://githubusercontent.com/*)
      printf '%s/%s\n' "$_base" "$_url"
      return 0
      ;;
  esac

  printf '%s\n' "$_url"
}

http_github_proxy_url() {
  _url="$1"
  _base="$(http_github_proxy_base)" || _base=""
  http_github_proxy_wrap_url "$_url" "$_base"
}

# Distinct gh-proxy.com URL after a direct githubusercontent fetch failed.
# stdout empty + rc 1 if the URL is not *.githubusercontent.com (or already that mirror).
http_github_proxy_fallback_url() {
  _url="$1"
  _fb="$(http_github_proxy_wrap_url "$_url" "https://gh-proxy.com")"
  [ -n "$_fb" ] && [ "$_fb" != "$_url" ] || return 1
  printf '%s\n' "$_fb"
}

# $1=original request URL $2=curl %{url_effective} (optional) $3=URL already tried.
# Prefers orig if it is githubusercontent; else the redirect target.
http_github_proxy_fallback_pick() {
  _orig="$1"
  _eff="$2"
  _tried="$3"
  _fb="$(http_github_proxy_fallback_url "$_orig")" || _fb=""
  if [ -z "$_fb" ] && [ -n "$_eff" ]; then
    _fb="$(http_github_proxy_fallback_url "$_eff")" || _fb=""
  fi
  [ -n "$_fb" ] && [ "$_fb" != "$_tried" ] || return 1
  printf '%s\n' "$_fb"
}

# $1=url $2=dst $3=file for curl %{url_effective} (optional)
http_fetch_file_curl_once() {
  _url="$1"
  _dst="$2"
  _eff="${3:-}"
  set -- curl --http1.1 -fL -S \
    --connect-timeout "${HTTP_CONNECT_TIMEOUT:-25}" \
    --max-time "${HTTP_MAX_TIME:-300}" \
    --retry "${HTTP_FETCH_RETRY:-2}" --retry-delay 2 \
    --speed-time "${HTTP_SPEED_TIME:-15}" --speed-limit "${HTTP_SPEED_LIMIT:-32768}" \
    -A "${HTTP_USER_AGENT:-Mozilla/5.0}"
  if [ -n "$_eff" ]; then
    "$@" -o "$_dst" -w '%{url_effective}' "$_url" >"$_eff"
    return
  fi
  "$@" -o "$_dst" "$_url"
}

# $1=url $2=dest. Rewrites via http_github_proxy_url when always-on proxy is set.
# If that GET fails and the URL (or curl redirect target) is githubusercontent.com,
# retries once via gh-proxy.com.
http_fetch_file() {
  _orig="${1:-}"
  _dst="${2:-}"
  [ -n "$_orig" ] && [ -n "$_dst" ] || return 1
  _url="$(http_github_proxy_url "$_orig")"
  _eff="${TMPDIR:-/tmp}/xfree-http-eff.$$"
  if command -v curl >/dev/null 2>&1; then
    if http_fetch_file_curl_once "$_url" "$_dst" "$_eff"; then
      rm -f "$_eff"
      return 0
    fi
    _eff_url="$(tr -d '\r\n' <"$_eff" 2>/dev/null || true)"
    rm -f "$_eff"
    _fb="$(http_github_proxy_fallback_pick "$_orig" "$_eff_url" "$_url")" || return 1
    echo "http_fetch_file: githubusercontent.com не ответил — повтор через gh-proxy.com" >&2
    http_fetch_file_curl_once "$_fb" "$_dst"
    return
  fi
  rm -f "$_eff"
  if command -v wget >/dev/null 2>&1; then
    if wget -T "${HTTP_CONNECT_TIMEOUT:-25}" -t 3 -O "$_dst" "$_url"; then
      return 0
    fi
    _fb="$(http_github_proxy_fallback_pick "$_orig" "" "$_url")" || return 1
    echo "http_fetch_file: githubusercontent.com не ответил — повтор через gh-proxy.com" >&2
    wget -T "${HTTP_CONNECT_TIMEOUT:-25}" -t 3 -O "$_dst" "$_fb"
    return
  fi
  echo "http_fetch_file: нужен curl или wget" >&2
  return 1
}
