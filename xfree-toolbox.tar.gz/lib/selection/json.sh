#!/bin/sh
# JSON helpers for selection backend (LuCI / rpcd). No whiptail.
# shellcheck shell=sh

selection_json_q() {
	printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

selection_json_error() {
	msg="${1:-error}"
	printf '{"code":1,"stderr":"%s"}' "$(selection_json_q "$msg")"
}

selection_json_ok_scopes() {
	# Caller prints: selection_json_ok_scopes; then scope objects; then closing ]
	printf '{"code":0,"scopes":['
}

selection_json_ok_model() {
	scope_key="$1"
	scope_val="$2"
	printf '{"code":0,"%s":"%s","items":[' "$(selection_json_q "$scope_key")" "$(selection_json_q "$scope_val")"
}

selection_json_item() {
	tag="$1"
	label="$2"
	checked="$3"
	source="${4:-}"
	group="${5:-}"
	service="${6:-}"
	level="${7:-}"
	kind="${8:-}"
	printf '{"tag":"%s","label":"%s","checked":%s,"source":"%s","group":"%s","service":"%s","level":"%s","kind":"%s"}' \
		"$(selection_json_q "$tag")" \
		"$(selection_json_q "$label")" \
		"$checked" \
		"$(selection_json_q "$source")" \
		"$(selection_json_q "$group")" \
		"$(selection_json_q "$service")" \
		"$(selection_json_q "$level")" \
		"$(selection_json_q "$kind")"
}

# One awk: entities.tsv + enabled tags → full get_model JSON (no per-field sed).
# entities: tag|source|group|service|level|has_fqdn|has_prefix|order
selection_json_emit_model() {
	scope_key="$1"
	scope_val="$2"
	entities_tsv="$3"
	enabled_tags_tsv="$4"
	mode="${5:-all}"

	awk -F'|' -v skey="$scope_key" -v sval="$scope_val" -v ef="$enabled_tags_tsv" -v mode="$mode" '
	function esc(s) {
		gsub(/\\/, "\\\\", s)
		gsub(/"/, "\\\"", s)
		return s
	}
	BEGIN {
		while ((getline t < ef) > 0) {
			sub(/\r$/, "", t)
			if (t != "") en[t] = 1
		}
		close(ef)
	}
	NF >= 5 {
		tag = $1
		source = $2
		group = $3
		service = $4
		level = $5
		hf = $6 + 0
		hp = $7 + 0
		if (mode == "fqdn_only" && hf != 1) next
		kind = ""
		if (hf == 1 && hp == 1) kind = "fqdn+prefix"
		else if (hf == 1) kind = "fqdn"
		else if (hp == 1) kind = "prefix"
		else kind = "unknown"
		if (level == "group")
			label = "[" source "] [group] " group
		else
			label = "[" source "] [service] " group " / " service
		if (mode == "fqdn_only")
			label = label " (fqdn)"
		else
			label = label " (" kind ")"
		n++
		tags[n] = tag
		labs[n] = label
		srcs[n] = source
		grps[n] = group
		svcs[n] = service
		lvls[n] = level
		kinds[n] = kind
		chk[n] = (tag in en ? 1 : 0)
	}
	END {
		printf "{\"code\":0,\"%s\":\"%s\"", esc(skey), esc(sval)
		if (skey != "scope")
			printf ",\"scope\":\"%s\"", esc(sval)
		printf ",\"items\":["
		sep = ""
		for (pass = 1; pass <= 2; pass++) {
			for (i = 1; i <= n; i++) {
				if (pass == 1 && chk[i] != 1) continue
				if (pass == 2 && chk[i] == 1) continue
				printf "%s{\"tag\":\"%s\",\"label\":\"%s\",\"checked\":%s,\"source\":\"%s\",\"group\":\"%s\",\"service\":\"%s\",\"level\":\"%s\",\"kind\":\"%s\"}", \
					sep, esc(tags[i]), esc(labs[i]), chk[i], esc(srcs[i]), esc(grps[i]), esc(svcs[i]), esc(lvls[i]), esc(kinds[i])
				sep = ","
			}
		}
		printf "]}"
	}' "$entities_tsv"
}

# Matrix JSON for LuCI «Общее»: one catalog pass + checked map.
# columns_tsv: key|target|scope|label|mode
# checked_tsv: key|tag
selection_json_emit_matrix() {
	entities_tsv="$1"
	columns_tsv="$2"
	checked_tsv="$3"

	awk -F'|' -v cols="$columns_tsv" -v chkf="$checked_tsv" '
	function esc(s) {
		gsub(/\\/, "\\\\", s)
		gsub(/"/, "\\\"", s)
		return s
	}
	BEGIN {
		while ((getline line < cols) > 0) {
			sub(/\r$/, "", line)
			if (line == "") continue
			n = split(line, a, "|")
			if (n < 5) continue
			cn++
			ckey[cn] = a[1]
			ctgt[cn] = a[2]
			cscp[cn] = a[3]
			clab[cn] = a[4]
			cmode[cn] = a[5]
		}
		close(cols)
		while ((getline line < chkf) > 0) {
			sub(/\r$/, "", line)
			if (line == "") continue
			n = split(line, a, "|")
			if (n < 2) continue
			checked[a[1] SUBSEP a[2]] = 1
			anytag[a[2]] = 1
			if (a[1] in chks) chks[a[1]] = chks[a[1]] ",\"" esc(a[2]) "\""
			else chks[a[1]] = "\"" esc(a[2]) "\""
		}
		close(chkf)
	}
	NF >= 5 {
		tag = $1
		source = $2
		group = $3
		service = $4
		level = $5
		hf = $6 + 0
		hp = $7 + 0
		kind = ""
		if (hf == 1 && hp == 1) kind = "fqdn+prefix"
		else if (hf == 1) kind = "fqdn"
		else if (hp == 1) kind = "prefix"
		else kind = "unknown"
		n++
		tags[n] = tag
		srcs[n] = source
		grps[n] = group
		svcs[n] = service
		lvls[n] = level
		kinds[n] = kind
		hfs[n] = hf
		if (level == "group")
			labs[n] = "[" source "] [group] " group
		else
			labs[n] = "[" source "] [service] " group " / " service
		anyc[n] = ((tag in anytag) ? 1 : 0)
	}
	END {
		printf "{\"code\":0,\"columns\":["
		sep = ""
		for (i = 1; i <= cn; i++) {
			printf "%s{\"key\":\"%s\",\"target\":\"%s\",\"scope\":\"%s\",\"label\":\"%s\",\"mode\":\"%s\"}", \
				sep, esc(ckey[i]), esc(ctgt[i]), esc(cscp[i]), esc(clab[i]), esc(cmode[i])
			sep = ","
		}
		printf "],\"items\":["
		sep = ""
		for (pass = 1; pass <= 2; pass++) {
			for (i = 1; i <= n; i++) {
				if (pass == 1 && anyc[i] != 1) continue
				if (pass == 2 && anyc[i] == 1) continue
				printf "%s{\"tag\":\"%s\",\"label\":\"%s\",\"source\":\"%s\",\"group\":\"%s\",\"service\":\"%s\",\"level\":\"%s\",\"kind\":\"%s\",\"has_fqdn\":%s}", \
					sep, esc(tags[i]), esc(labs[i]), esc(srcs[i]), esc(grps[i]), esc(svcs[i]), esc(lvls[i]), esc(kinds[i]), (hfs[i] ? "true" : "false")
				sep = ","
			}
		}
		printf "],\"checked\":{"
		sep = ""
		for (i = 1; i <= cn; i++) {
			printf "%s\"%s\":[%s]", sep, esc(ckey[i]), (ckey[i] in chks ? chks[ckey[i]] : "")
			sep = ","
		}
		printf "}}"
	}' "$entities_tsv"
}
