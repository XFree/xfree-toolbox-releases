#!/bin/sh
# JSON helpers for selection backend (LuCI / rpcd). No whiptail.
# shellcheck shell=sh

selection_json_q() {
	printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

selection_json_error() {
	msg="${1:-error}"
	printf '{"code":1,"stderr":"%s"}' "$(selection_json_q "$msg")"
}

selection_json_ok_scopes() {
	# Caller prints: selection_json_ok_scopes; then scope objects; then closing ]
	printf '{"code":0,"scopes":['
}

selection_json_ok_model() {
	scope_key="$1"
	scope_val="$2"
	printf '{"code":0,"%s":"%s","items":[' "$(selection_json_q "$scope_key")" "$(selection_json_q "$scope_val")"
}

selection_json_item() {
	tag="$1"
	label="$2"
	checked="$3"
	source="${4:-}"
	group="${5:-}"
	service="${6:-}"
	level="${7:-}"
	kind="${8:-}"
	printf '{"tag":"%s","label":"%s","checked":%s,"source":"%s","group":"%s","service":"%s","level":"%s","kind":"%s"}' \
		"$(selection_json_q "$tag")" \
		"$(selection_json_q "$label")" \
		"$checked" \
		"$(selection_json_q "$source")" \
		"$(selection_json_q "$group")" \
		"$(selection_json_q "$service")" \
		"$(selection_json_q "$level")" \
		"$(selection_json_q "$kind")"
}

# One awk: entities.tsv + enabled tags → full get_model JSON (no per-field sed).
# entities: tag|source|group|service|level|has_fqdn|has_prefix|order
selection_json_emit_model() {
	scope_key="$1"
	scope_val="$2"
	entities_tsv="$3"
	enabled_tags_tsv="$4"
	mode="${5:-all}"

	awk -F'|' -v skey="$scope_key" -v sval="$scope_val" -v ef="$enabled_tags_tsv" -v mode="$mode" '
	function esc(s) {
		gsub(/\\/, "\\\\", s)
		gsub(/"/, "\\\"", s)
		return s
	}
	BEGIN {
		while ((getline t < ef) > 0) {
			sub(/\r$/, "", t)
			if (t != "") en[t] = 1
		}
		close(ef)
	}
	NF >= 5 {
		tag = $1
		source = $2
		group = $3
		service = $4
		level = $5
		hf = $6 + 0
		hp = $7 + 0
		if (mode == "fqdn_only" && hf != 1) next
		kind = ""
		if (hf == 1 && hp == 1) kind = "fqdn+prefix"
		else if (hf == 1) kind = "fqdn"
		else if (hp == 1) kind = "prefix"
		else kind = "unknown"
		if (level == "group")
			label = "[" source "] [group] " group
		else
			label = "[" source "] [service] " group " / " service
		if (mode == "fqdn_only")
			label = label " (fqdn)"
		else
			label = label " (" kind ")"
		n++
		tags[n] = tag
		labs[n] = label
		srcs[n] = source
		grps[n] = group
		svcs[n] = service
		lvls[n] = level
		kinds[n] = kind
		chk[n] = (tag in en ? 1 : 0)
	}
	END {
		printf "{\"code\":0,\"%s\":\"%s\"", esc(skey), esc(sval)
		if (skey != "scope")
			printf ",\"scope\":\"%s\"", esc(sval)
		printf ",\"items\":["
		sep = ""
		for (pass = 1; pass <= 2; pass++) {
			for (i = 1; i <= n; i++) {
				if (pass == 1 && chk[i] != 1) continue
				if (pass == 2 && chk[i] == 1) continue
				printf "%s{\"tag\":\"%s\",\"label\":\"%s\",\"checked\":%s,\"source\":\"%s\",\"group\":\"%s\",\"service\":\"%s\",\"level\":\"%s\",\"kind\":\"%s\"}", \
					sep, esc(tags[i]), esc(labs[i]), chk[i], esc(srcs[i]), esc(grps[i]), esc(svcs[i]), esc(lvls[i]), esc(kinds[i])
				sep = ","
			}
		}
		printf "]}"
	}' "$entities_tsv"
}
