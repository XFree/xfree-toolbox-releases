#!/bin/sh
# zapret target: scopes (sections), checklist model, materialize (no whiptail).
# shellcheck shell=sh

SELECTION_ZAPRET_DIR=""
SELECTION_ZAPRET_ROOT=""
SELECTION_ZAPRET_SECTIONS=""

selection_zapret_sanitize() {
	printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

selection_zapret_init_module() {
	zapret_dir="$1"
	[ -n "$zapret_dir" ] && [ -d "$zapret_dir" ] || return 1

	SELECTION_ZAPRET_DIR="$zapret_dir"
	SELECTION_ZAPRET_ROOT="$(CDPATH= cd -- "$zapret_dir/.." && pwd -P)"

	# shellcheck disable=SC1090
	. "$SELECTION_ZAPRET_ROOT/lib/common.sh"
	# shellcheck disable=SC1090
	. "$SELECTION_ZAPRET_ROOT/lib/upstreams.sh"

	common_load_project_config "$SELECTION_ZAPRET_ROOT"
	export PROFILE_DIR="$(common_profile_dir "$SELECTION_ZAPRET_ROOT")"
	SELECTION_ZAPRET_SECTIONS="$PROFILE_DIR/zapret/sections"
	export PROJECT_ROOT="$SELECTION_ZAPRET_ROOT"
}

selection_zapret_section_on_p() {
	conf="$1"
	[ -f "$conf" ] || return 0
	val="$(awk -F"'" '/^ZAPRET_SECTION_ENABLED=/ { print $2; exit }' "$conf")"
	case "${val:-1}" in
	0|off|OFF|false|no) return 1 ;;
	*) return 0 ;;
	esac
}

selection_zapret_load_context() {
	section="$(selection_zapret_sanitize "$1")"
	[ -n "$section" ] || return 1
	WORK_FQDN_DIR="$SELECTION_ZAPRET_SECTIONS/$section/fqdn.d"
	WORK_PREFIX_DIR="$SELECTION_ZAPRET_SECTIONS/$section/prefixes.d"
	mkdir -p "$WORK_FQDN_DIR" "$WORK_PREFIX_DIR"
}

selection_zapret_mark_changed() {
	section="$1"
	f="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"
	mkdir -p "$(dirname -- "$f")"
	touch "$f"
	if ! awk -v s="$section" '$0==s{found=1} END{exit(found?0:1)}' "$f"; then
		printf '%s\n' "$section" >> "$f"
	fi
}

selection_zapret_disable_flags() {
	tmpl="$PROFILE_DIR/zapret/${PROFILE_CFG_TEMPLATE_NAME:-zapret.template}"
	SELECTION_ZAPRET_DV4=0
	SELECTION_ZAPRET_DV6=0
	[ -f "$tmpl" ] || return 0
	SELECTION_ZAPRET_DV4="$(awk '$1=="option" && $2=="DISABLE_IPV4" {
		v=$0; sub(/^[[:space:]]*option[[:space:]]+[^[:space:]]+[[:space:]]+'\''/, "", v)
		sub(/'\''[[:space:]]*$/, "", v); print v; exit
	}' "$tmpl")"
	SELECTION_ZAPRET_DV6="$(awk '$1=="option" && $2=="DISABLE_IPV6" {
		v=$0; sub(/^[[:space:]]*option[[:space:]]+[^[:space:]]+[[:space:]]+'\''/, "", v)
		sub(/'\''[[:space:]]*$/, "", v); print v; exit
	}' "$tmpl")"
	SELECTION_ZAPRET_DV4="${SELECTION_ZAPRET_DV4:-0}"
	SELECTION_ZAPRET_DV6="${SELECTION_ZAPRET_DV6:-0}"
}

selection_zapret_json_list_scopes() {
	tmp="$(mktemp)"
	trap 'rm -f "$tmp"' EXIT INT TERM

	if [ -d "$SELECTION_ZAPRET_SECTIONS" ]; then
		for dir in "$SELECTION_ZAPRET_SECTIONS"/*; do
			[ -d "$dir" ] || continue
			id="$(basename "$dir")"
			if selection_zapret_section_on_p "$dir/config/section.conf"; then
				label="[ON] $id"
			else
				label="[OFF] $id"
			fi
			printf '%s\t%s\n' "$id" "$label" >> "$tmp"
		done
	fi

	selection_json_ok_scopes
	first=1
	while IFS="$(printf '\t')" read -r id label; do
		[ -n "${id:-}" ] || continue
		[ "$first" -eq 0 ] && printf ','
		first=0
		printf '{"id":"%s","label":"%s"}' "$(selection_json_q "$id")" "$(selection_json_q "$label")"
	done < "$tmp"
	printf ']}'
	trap - EXIT INT TERM
	rm -f "$tmp"
}

selection_zapret_json_get_model() {
	section="$1"
	mode="${2:-all}"

	[ -n "${section:-}" ] || {
		selection_json_error "section required"
		return 0
	}

	selection_zapret_load_context "$section" || {
		selection_json_error "invalid section"
		return 0
	}
	selection_zapret_disable_flags

	selection_json_get_model_common \
		"zapret" \
		"$section" \
		"$mode" \
		"$SELECTION_ZAPRET_ROOT" \
		"$WORK_FQDN_DIR" \
		"$WORK_PREFIX_DIR" \
		"scope" \
		"$SELECTION_ZAPRET_DV4" \
		"$SELECTION_ZAPRET_DV6"
}

selection_zapret_materialize_tags() {
	section="$1"
	mode="${2:-all}"
	shift 2

	selection_zapret_load_context "$section" || return 1
	selection_zapret_disable_flags
	# stage helper reads disable via files.tsv mode; prefix skip is in enabled tags.
	selection_materialize_common \
		"zapret" \
		"$mode" \
		"$SELECTION_ZAPRET_ROOT" \
		"$WORK_FQDN_DIR" \
		"$WORK_PREFIX_DIR" \
		"$@" || return $?
	selection_zapret_mark_changed "$section"
	return 0
}

selection_zapret_json_save() {
	section="$1"
	mode="${2:-all}"
	shift 2

	[ -n "${section:-}" ] || {
		selection_json_error "section required"
		return 0
	}

	if selection_zapret_materialize_tags "$section" "$mode" "$@"; then
		printf '{"code":0,"scope":"%s","saved":%s}' \
			"$(selection_json_q "$section")" "$#"
	else
		rc=$?
		if [ "$rc" -eq 2 ]; then
			selection_json_error "staging mismatch (reindex upstreams)"
		else
			selection_json_error "invalid section"
		fi
	fi
}
