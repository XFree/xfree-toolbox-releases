#!/bin/sh
# Shared catalog + get_model/save for iface|dns|zapret (no whiptail).
# shellcheck shell=sh

selection_catalog_cache_dir() {
	root="$1"
	base="${XFREE_UPSTREAMS_MODEL_CACHE:-/tmp/xfree-toolbox/upstreams-model}"
	mkdir -p "$base"
	# OpenWrt BusyBox has no cksum(1); never abort get_model (luci-rpc.sh uses set -e).
	sum="$(find "$root/upstreams" -path '*/.index/lists.raw.tsv' -type f -exec cat {} + 2>/dev/null | (
		if command -v md5sum >/dev/null 2>&1; then
			md5sum
		elif command -v sha256sum >/dev/null 2>&1; then
			sha256sum
		else
			wc -c
		fi
	) | awk '{print $1}')"
	[ -n "$sum" ] || sum="empty"
	printf '%s/%s\n' "$base" "$sum"
}

# stdout: directory with entities.tsv + files.tsv (index-backed, cached).
selection_catalog_prepare() {
	root="$1"
	dir="$(selection_catalog_cache_dir "$root")"
	if [ -s "$dir/entities.tsv" ] && [ -s "$dir/files.tsv" ]; then
		printf '%s\n' "$dir"
		return 0
	fi
	mkdir -p "$dir"
	upstreams_build_model_tsv "$root" "$dir/entities.tsv" "$dir/files.tsv" || return 1
	[ -s "$dir/entities.tsv" ] || return 1
	printf '%s\n' "$dir"
}

# get_model JSON. consumer = iface|dns|zapret (enabled-tags + materialize).
selection_json_get_model_common() {
	consumer="$1"
	scope="$2"
	mode="${3:-all}"
	root="$4"
	fqdn_dir="$5"
	prefix_dir="${6:-}"
	scope_key="${7:-scope}"
	disable_ipv4="${8:-0}"
	disable_ipv6="${9:-0}"

	cat_dir="$(selection_catalog_prepare "$root")" || {
		selection_json_error "empty upstream model"
		return 0
	}

	enabled_tags_tsv="$(mktemp)"
	upstreams_build_enabled_tags_tsv \
		"$consumer" \
		"$cat_dir/files.tsv" \
		"$fqdn_dir" \
		"$prefix_dir" \
		"$mode" \
		"$disable_ipv4" \
		"$disable_ipv6" > "$enabled_tags_tsv"

	selection_json_emit_model "$scope_key" "$scope" "$cat_dir/entities.tsv" "$enabled_tags_tsv" "$mode"
	rm -f "$enabled_tags_tsv"
}

selection_materialize_common() {
	consumer="$1"
	mode="$2"
	root="$3"
	fqdn_dir="$4"
	prefix_dir="${5:-}"
	shift 5

	TMP="$(mktemp -d)"
	trap 'rm -rf "$TMP"' EXIT INT TERM

	cat_dir="$(selection_catalog_prepare "$root")" || return 1

	staged_fqdn="$TMP/staged-fqdn"
	staged_prefix="$TMP/staged-prefix"
	choices_file="$TMP/choices.lst"
	mkdir -p "$staged_fqdn"
	[ -n "$prefix_dir" ] && mkdir -p "$staged_prefix"
	: > "$choices_file"

	for tag in "$@"; do
		[ -n "${tag:-}" ] || continue
		printf '%s\n' "$tag" >> "$choices_file"
		upstreams_stage_tag_files_from_model \
			"$consumer" \
			"$tag" \
			"$cat_dir/files.tsv" \
			"$staged_fqdn" \
			"$staged_prefix" \
			"$mode"
	done

	if [ -n "$prefix_dir" ]; then
		if upstreams_staging_selection_mismatch "$choices_file" "$staged_fqdn" "$staged_prefix"; then
			rm -rf "$TMP"
			trap - EXIT INT TERM
			return 2
		fi
		upstreams_replace_dir_from_staged "$fqdn_dir" "$staged_fqdn"
		upstreams_replace_dir_from_staged "$prefix_dir" "$staged_prefix"
	else
		if upstreams_staging_selection_mismatch "$choices_file" "$staged_fqdn" ""; then
			rm -rf "$TMP"
			trap - EXIT INT TERM
			return 2
		fi
		upstreams_replace_dir_from_staged "$fqdn_dir" "$staged_fqdn"
	fi

	rm -rf "$TMP"
	trap - EXIT INT TERM
	return 0
}
