#!/bin/sh
# WAN6 (selective IPv6) target: checklist model & materialize (fqdn_only -> dnsmasq nftset).
# shellcheck shell=sh

SELECTION_WAN6_ROOT=""
SELECTION_WAN6_FQDN_DIR=""

selection_wan6_init_module() {
	root_dir="$1"
	[ -n "$root_dir" ] && [ -d "$root_dir" ] || return 1

	SELECTION_WAN6_ROOT="$root_dir"
	# shellcheck disable=SC1090
	. "$SELECTION_WAN6_ROOT/lib/common.sh"
	# shellcheck disable=SC1090
	. "$SELECTION_WAN6_ROOT/lib/upstreams.sh"
	if [ -f "$SELECTION_WAN6_ROOT/lib/wan6-policy.sh" ]; then
		# shellcheck disable=SC1090
		. "$SELECTION_WAN6_ROOT/lib/wan6-policy.sh"
	fi

	common_load_project_config "$SELECTION_WAN6_ROOT"
	export PROFILE_DIR="$(common_profile_dir "$SELECTION_WAN6_ROOT")"
	export PROJECT_ROOT="$SELECTION_WAN6_ROOT"
}

selection_wan6_fqdn_dir() {
	if [ -n "${SELECTION_WAN6_FQDN_DIR:-}" ]; then
		printf '%s\n' "$SELECTION_WAN6_FQDN_DIR"
		return 0
	fi
	printf '%s/wan6/fqdn.d\n' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

selection_wan6_ensure_workspace() {
	_w6_fqdn="$(selection_wan6_fqdn_dir)"
	mkdir -p "$_w6_fqdn"
}

selection_wan6_ensure_default() {
	_entities_tsv="${1:-}"
	_w6_fqdn="$(selection_wan6_fqdn_dir)"
	[ -d "$_w6_fqdn" ] && return 0

	mkdir -p "$_w6_fqdn"
	if [ -n "$_entities_tsv" ] && [ -f "$_entities_tsv" ]; then
		_def_tag="$(awk -F'|' '
			($1 == "youtube" || ($4 == "youtube" && $5 == "service")) && ($6 + 0 == 1) {
				print $1
				exit
			}
		' "$_entities_tsv" 2>/dev/null || true)"
		if [ -n "$_def_tag" ]; then
			selection_wan6_materialize_tags "fqdn_only" "$_def_tag" >/dev/null 2>&1 || true
		fi
	fi
}

selection_wan6_json_list_scopes() {
	selection_json_ok_scopes
	printf '{"id":"wan6","label":"wan6"}]}'
}

selection_wan6_json_get_model() {
	mode="${1:-fqdn_only}"
	selection_wan6_ensure_workspace || {
		selection_json_error "wan6 workspace error"
		return 0
	}
	_w6_fqdn="$(selection_wan6_fqdn_dir)"
	selection_json_get_model_common \
		"dns" \
		"wan6" \
		"$mode" \
		"$SELECTION_WAN6_ROOT" \
		"$_w6_fqdn" \
		"" \
		"scope"
}

selection_wan6_materialize_tags() {
	mode="${1:-fqdn_only}"
	shift 1 || true
	selection_wan6_ensure_workspace || return 1
	_w6_fqdn="$(selection_wan6_fqdn_dir)"
	selection_materialize_common \
		"dns" \
		"$mode" \
		"$SELECTION_WAN6_ROOT" \
		"$_w6_fqdn" \
		"" \
		"$@"
}

selection_wan6_json_save() {
	mode="${1:-fqdn_only}"
	shift 1 || true

	if selection_wan6_materialize_tags "$mode" "$@"; then
		printf '{"code":0,"scope":"wan6","saved":%s}' "$#"
	else
		rc=$?
		selection_json_error "save failed ($rc)"
	fi
}
