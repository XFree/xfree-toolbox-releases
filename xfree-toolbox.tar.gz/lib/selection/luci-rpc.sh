#!/bin/sh
# LuCI/rpcd JSON entry → lib/selection (target=iface|dns|zapret).
# Usage: list-scopes TARGET | get-model TARGET SCOPE [mode] | save TARGET SCOPE MODE [tags...]
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/selection/upstream-selection.sh"

selection_upstream_init_all "$ROOT_DIR"

case "${1:-}" in
list-scopes)
	selection_upstream_json_list_scopes "${2:-iface}"
	;;
get-model)
	selection_upstream_json_get_model "${2:-iface}" "${3:-}" "${4:-}"
	;;
save)
	target="${2:-iface}"
	scope="${3:-}"
	mode="${4:-}"
	shift 4 || shift 3 || shift 2 || true
	selection_upstream_json_save "$target" "$scope" "$mode" "$@"
	;;
*)
	selection_json_error "usage: list-scopes TARGET | get-model TARGET SCOPE [mode] | save TARGET SCOPE MODE [tags...]"
	;;
esac
