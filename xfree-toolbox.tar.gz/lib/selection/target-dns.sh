#!/bin/sh
# dns-routing target: scopes, checklist model, materialize (no whiptail).
# shellcheck shell=sh

SELECTION_DNS_ROUTING_DIR=""
SELECTION_DNS_ROOT=""
SELECTION_DNS_DIR=""

selection_dns_sanitize() {
	printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

selection_dns_init_module() {
	dns_routing_dir="$1"
	[ -n "$dns_routing_dir" ] && [ -d "$dns_routing_dir" ] || return 1

	SELECTION_DNS_ROUTING_DIR="$dns_routing_dir"
	SELECTION_DNS_ROOT="$(CDPATH= cd -- "$dns_routing_dir/.." && pwd -P)"

	# shellcheck disable=SC1090
	. "$SELECTION_DNS_ROOT/lib/common.sh"
	# shellcheck disable=SC1090
	. "$SELECTION_DNS_ROOT/lib/upstreams.sh"

	common_load_project_config "$SELECTION_DNS_ROOT"
	export PROFILE_DIR="$(common_profile_dir "$SELECTION_DNS_ROOT")"
	export PROJECT_ROOT="$SELECTION_DNS_ROOT"

	# Same instance list as CLI select-lists.sh (UCI https-dns-proxy + profile).
	DNS_ROUTING_LIB_DIR="$dns_routing_dir"
	# shellcheck disable=SC1090
	. "$dns_routing_dir/lib.sh"
	SELECTION_DNS_DIR="$DNS_DIR"
}

selection_dns_ensure_workspace() {
	dns_id="$1"
	[ -n "$dns_id" ] || return 1
	# die() would kill rpcd; isolate like a failed CLI probe.
	if command -v dns_routing_ensure_dns_workspace >/dev/null 2>&1; then
		( dns_routing_ensure_dns_workspace "$dns_id" ) >/dev/null 2>&1 || true
	fi
	mkdir -p "$SELECTION_DNS_DIR/$dns_id/fqdn.d"
}

selection_dns_load_context() {
	dns_id="$(selection_dns_sanitize "$1")"
	[ -n "$dns_id" ] || return 1
	selection_dns_ensure_workspace "$dns_id"
	WORK_FQDN_DIR="$SELECTION_DNS_DIR/$dns_id/fqdn.d"
	mkdir -p "$WORK_FQDN_DIR"
}

selection_dns_json_list_scopes() {
	tmp="$(mktemp)"
	trap 'rm -f "$tmp"' EXIT INT TERM

	# idx|dns_id|host|target|resolver_url  (CLI: dns_routing_list_instances_tsv)
	dns_routing_list_instances_tsv > "$tmp" 2>/dev/null || true

	selection_json_ok_scopes
	first=1
	while IFS='|' read -r _idx dns_id host _target _url; do
		[ -n "${dns_id:-}" ] || continue
		label="${host:-$dns_id}"
		[ "$first" -eq 0 ] && printf ','
		first=0
		printf '{"id":"%s","label":"%s"}' "$(selection_json_q "$dns_id")" "$(selection_json_q "$label")"
	done < "$tmp"
	printf ']}'
	trap - EXIT INT TERM
	rm -f "$tmp"
}

selection_dns_json_get_model() {
	dns_id="$1"
	mode="${2:-fqdn_only}"

	[ -n "${dns_id:-}" ] || {
		selection_json_error "dns id required"
		return 0
	}

	selection_dns_load_context "$dns_id" || {
		selection_json_error "invalid dns id"
		return 0
	}

	selection_json_get_model_common \
		"dns" \
		"$dns_id" \
		"$mode" \
		"$SELECTION_DNS_ROOT" \
		"$WORK_FQDN_DIR" \
		"" \
		"scope"
}

selection_dns_materialize_tags() {
	dns_id="$1"
	mode="${2:-fqdn_only}"
	shift 2

	selection_dns_load_context "$dns_id" || return 1
	selection_materialize_common \
		"dns" \
		"$mode" \
		"$SELECTION_DNS_ROOT" \
		"$WORK_FQDN_DIR" \
		"" \
		"$@"
}

selection_dns_json_save() {
	dns_id="$1"
	mode="${2:-fqdn_only}"
	shift 2

	[ -n "${dns_id:-}" ] || {
		selection_json_error "dns id required"
		return 0
	}

	if selection_dns_materialize_tags "$dns_id" "$mode" "$@"; then
		printf '{"code":0,"scope":"%s","saved":%s}' \
			"$(selection_json_q "$dns_id")" "$#"
	else
		rc=$?
		if [ "$rc" -eq 2 ]; then
			selection_json_error "staging mismatch (reindex upstreams)"
		else
			selection_json_error "invalid dns id"
		fi
	fi
}
