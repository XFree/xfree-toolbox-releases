#!/bin/sh
# iface-routing target: scopes, checklist model, materialize (no whiptail).
# Used by CLI (selection-ui.sh) and LuCI (iface-routing/luci/upstream-selection-rpc.sh).
# shellcheck shell=sh

# Module globals (set by selection_iface_init_module).
# json.sh is sourced from upstream-selection.sh before this file.
SELECTION_IFACE_ROUTING_DIR=""
SELECTION_ROOT_DIR=""
SELECTION_RUNTIME_FILE=""
SELECTION_BASE_DIR=""
SELECTION_INTERFACES_DIR=""
SELECTION_UPSTREAMS_DIR=""

selection_iface_init_module() {
	iface_routing_dir="$1"
	[ -n "$iface_routing_dir" ] || return 1
	[ -f "$iface_routing_dir/ui.conf" ] || return 1

	SELECTION_IFACE_ROUTING_DIR="$iface_routing_dir"
	SELECTION_ROOT_DIR="$(CDPATH= cd -- "$iface_routing_dir/.." && pwd -P)"

	# shellcheck disable=SC1090
	. "$SELECTION_ROOT_DIR/lib/common.sh"
	# shellcheck disable=SC1090
	. "$SELECTION_ROOT_DIR/lib/upstreams.sh"
	# JSON get_model does not need whiptail/ui.sh

	_override_profile_dir=""
	if [ -n "${XFREE_APPLY_PROFILE_DIR:-}" ] && [ -d "$XFREE_APPLY_PROFILE_DIR" ]; then
		_override_profile_dir="$XFREE_APPLY_PROFILE_DIR"
	elif [ -n "${PROFILE_DIR:-}" ]; then
		case "$PROFILE_DIR" in
			/*)
				[ -d "$PROFILE_DIR" ] && _override_profile_dir="$PROFILE_DIR"
				;;
		esac
	fi

	common_load_project_config "$SELECTION_ROOT_DIR"
	# shellcheck disable=SC1090
	. "$iface_routing_dir/ui.conf"

	if [ -n "$_override_profile_dir" ]; then
		export PROFILE_DIR="$_override_profile_dir"
	else
		export PROFILE_DIR="$(common_profile_dir "$SELECTION_ROOT_DIR")"
	fi
	export INTERFACES_DIR="$PROFILE_DIR/iface-routing/interfaces"
	unset _override_profile_dir

	SELECTION_RUNTIME_FILE="${DOMAIN_ROUTING_RUNTIME:-$iface_routing_dir/iface-runtime.sh}"
	SELECTION_BASE_DIR="$(common_resolve_path "$iface_routing_dir" "${BASE_DIR:-.}")"
	case "$INTERFACES_DIR" in
		/*) SELECTION_INTERFACES_DIR="$INTERFACES_DIR" ;;
		*) SELECTION_INTERFACES_DIR="$(common_resolve_path "$iface_routing_dir" "${INTERFACES_DIR:-interfaces}")" ;;
	esac
	SELECTION_UPSTREAMS_DIR="$(common_resolve_path "$iface_routing_dir" "${UPSTREAMS_DIR:-../upstreams}")"
	export UPSTREAMS_DIR="$SELECTION_UPSTREAMS_DIR"
	export PROJECT_ROOT="$SELECTION_ROOT_DIR"
}

selection_iface_sanitize_name() {
	printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

selection_iface_load_context() {
	iface="$1"
	iface="$(selection_iface_sanitize_name "$iface")"
	[ -n "$iface" ] || return 1
	[ -f "$SELECTION_RUNTIME_FILE" ] || return 1

	export INTERFACE_NAME="$iface"
	# ui.conf uses relative PROJECT_ROOT; runtime must see absolute profile paths (LuCI cwd ≠ module dir).
	export PROFILE_DIR="$(common_profile_dir "$SELECTION_ROOT_DIR")"
	export INTERFACES_DIR="$SELECTION_INTERFACES_DIR"
	export DOMAIN_ROUTING_CONFIG="${DOMAIN_ROUTING_CONFIG:-$SELECTION_IFACE_ROUTING_DIR/config.sh}"
	export IFACE_RUNTIME_SCRIPT="$SELECTION_RUNTIME_FILE"
	# shellcheck disable=SC1090
	. "$SELECTION_RUNTIME_FILE"
}

# stdout: one interface id per line
selection_iface_list_scope_ids() {
	common_list_domain_interfaces "$SELECTION_INTERFACES_DIR"
}

selection_iface_json_list_scopes() {
	tmp="$(mktemp)"
	trap 'rm -f "$tmp"' EXIT INT TERM

	selection_iface_list_scope_ids > "$tmp" 2>/dev/null || :

	selection_json_ok_scopes
	first=1
	while IFS= read -r iface; do
		[ -n "${iface:-}" ] || continue
		[ "$first" -eq 0 ] && printf ','
		first=0
		printf '{"id":"%s","label":"%s"}' \
			"$(selection_json_q "$iface")" \
			"$(selection_json_q "$iface")"
	done < "$tmp"
	printf ']}'
	trap - EXIT INT TERM
	rm -f "$tmp"
}

# Materialize selected tags into WORK_* (empty tag list = clear). Returns 0 on success.
selection_iface_materialize_tags() {
	iface="$1"
	mode="${2:-all}"
	shift 2

	selection_iface_load_context "$iface" || return 1

	selection_materialize_common \
		"iface" \
		"$mode" \
		"$SELECTION_ROOT_DIR" \
		"$WORK_FQDN_DIR" \
		"$WORK_PREFIX_DIR" \
		"$@"
}
selection_iface_materialize_tags_lines() {
	iface="$1"
	mode="${2:-all}"
	set --
	while IFS= read -r tag; do
		[ -n "${tag:-}" ] || continue
		set -- "$@" "$tag"
	done
	selection_iface_materialize_tags "$iface" "$mode" "$@"
}

selection_iface_json_get_model() {
	iface="$1"
	mode="${2:-all}"

	[ -n "${iface:-}" ] || {
		selection_json_error "iface required"
		return 0
	}

	selection_iface_load_context "$iface" || {
		selection_json_error "invalid iface or runtime"
		return 0
	}

	selection_json_get_model_common \
		"iface" \
		"$iface" \
		"$mode" \
		"$SELECTION_ROOT_DIR" \
		"$WORK_FQDN_DIR" \
		"$WORK_PREFIX_DIR" \
		"iface"
}

selection_iface_json_save() {
	iface="$1"
	mode="${2:-all}"
	shift 2

	[ -n "${iface:-}" ] || {
		selection_json_error "iface required"
		return 0
	}

	if selection_iface_materialize_tags "$iface" "$mode" "$@"; then
		printf '{"code":0,"iface":"%s","saved":%s}' \
			"$(selection_json_q "$iface")" "$#"
	else
		rc=$?
		if [ "$rc" -eq 2 ]; then
			choices_file="$(mktemp)"
			: > "$choices_file"
			for tag in "$@"; do
				[ -n "${tag:-}" ] || continue
				printf '%s\n' "$tag" >> "$choices_file"
			done
			selection_json_error "$(upstreams_staging_mismatch_message "$choices_file")"
			rm -f "$choices_file"
		else
			selection_json_error "invalid iface or runtime"
		fi
	fi
}
