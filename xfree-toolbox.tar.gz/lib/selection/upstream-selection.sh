#!/bin/sh
# Dispatch selection backend by target (iface | dns | zapret).
# Presentation: CLI (lib/ui/components) and LuCI (rpcd) call into here.
# shellcheck shell=sh

if [ -z "${SELECTION_LIB_DIR:-}" ]; then
	if [ -n "${ROOT_DIR:-}" ] && [ -d "$ROOT_DIR/lib/selection" ]; then
		SELECTION_LIB_DIR="$ROOT_DIR/lib/selection"
	else
		SELECTION_LIB_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
	fi
fi

# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/json.sh"
# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/model.sh"
# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/target-iface.sh"
# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/target-dns.sh"
# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/target-zapret.sh"

selection_upstream_init_all() {
	root="$1"
	[ -n "$root" ] || return 1
	selection_iface_init_module "$root/iface-routing" || true
	selection_dns_init_module "$root/dns-routing" || true
	selection_zapret_init_module "$root/zapret" || true
}

selection_upstream_json_list_scopes() {
	target="$1"
	case "$target" in
	iface)
		selection_iface_json_list_scopes
		;;
	dns)
		selection_dns_json_list_scopes
		;;
	zapret)
		selection_zapret_json_list_scopes
		;;
	*)
		selection_json_error "unknown target: $target"
		;;
	esac
}

selection_upstream_json_get_model() {
	target="$1"
	scope="$2"
	mode="${3:-}"
	case "$target" in
	iface)
		selection_iface_json_get_model "$scope" "${mode:-all}"
		;;
	dns)
		selection_dns_json_get_model "$scope" "${mode:-fqdn_only}"
		;;
	zapret)
		selection_zapret_json_get_model "$scope" "${mode:-all}"
		;;
	*)
		selection_json_error "unknown target: $target"
		;;
	esac
}

selection_upstream_json_save() {
	target="$1"
	scope="$2"
	mode="${3:-}"
	shift 3
	case "$target" in
	iface)
		selection_iface_json_save "$scope" "${mode:-all}" "$@"
		;;
	dns)
		selection_dns_json_save "$scope" "${mode:-fqdn_only}" "$@"
		;;
	zapret)
		selection_zapret_json_save "$scope" "${mode:-all}" "$@"
		;;
	*)
		selection_json_error "unknown target: $target"
		;;
	esac
}

# columns line + present basenames (key|fqdn|name or key|pfx|name). No files.tsv scan.
selection_matrix_register_scope() {
	_mx_target="$1"
	_mx_scope="$2"
	_mx_label="$3"
	_mx_mode="$4"
	_mx_cols="$5"
	_mx_present="$6"
	_mx_key="${_mx_target}:${_mx_scope}"
	_mx_fqdn=""
	_mx_pfx=""

	case "$_mx_target" in
	iface)
		_mx_scope="$(selection_iface_sanitize_name "$_mx_scope")"
		[ -n "$_mx_scope" ] || return 0
		[ -n "${SELECTION_INTERFACES_DIR:-}" ] || return 0
		_mx_fqdn="$SELECTION_INTERFACES_DIR/$_mx_scope/fqdn.d"
		_mx_pfx="$SELECTION_INTERFACES_DIR/$_mx_scope/prefixes.d"
		;;
	dns)
		_mx_scope="$(selection_dns_sanitize "$_mx_scope")"
		[ -n "$_mx_scope" ] || return 0
		[ -n "${SELECTION_DNS_DIR:-}" ] || return 0
		_mx_fqdn="$SELECTION_DNS_DIR/$_mx_scope/fqdn.d"
		_mx_pfx=""
		;;
	zapret)
		_mx_scope="$(selection_zapret_sanitize "$_mx_scope")"
		[ -n "$_mx_scope" ] || return 0
		[ -n "${SELECTION_ZAPRET_SECTIONS:-}" ] || return 0
		_mx_fqdn="$SELECTION_ZAPRET_SECTIONS/$_mx_scope/fqdn.d"
		_mx_pfx="$SELECTION_ZAPRET_SECTIONS/$_mx_scope/prefixes.d"
		;;
	*)
		return 0
		;;
	esac

	printf '%s|%s|%s|%s|%s\n' \
		"$_mx_key" "$_mx_target" "$_mx_scope" "$_mx_label" "$_mx_mode" >> "$_mx_cols"

	if [ -d "$_mx_fqdn" ]; then
		for _mx_f in "$_mx_fqdn"/*.lst; do
			[ -f "$_mx_f" ] || continue
			printf '%s|fqdn|%s\n' "$_mx_key" "${_mx_f##*/}" >> "$_mx_present"
		done
	fi
	if [ -n "$_mx_pfx" ] && [ -d "$_mx_pfx" ]; then
		for _mx_f in "$_mx_pfx"/*.lst; do
			[ -f "$_mx_f" ] || continue
			printf '%s|pfx|%s\n' "$_mx_key" "${_mx_f##*/}" >> "$_mx_present"
		done
	fi
}

# One files.tsv index + per-scope present scan → checked_tsv (key|tag).
# Inverted vs N×files: candidate tags come from present basenames (few), then full verify.
selection_matrix_resolve_checked() {
	_mx_files_tsv="$1"
	_mx_cols="$2"
	_mx_present="$3"
	_mx_checked="$4"
	_mx_dv4="${5:-0}"
	_mx_dv6="${6:-0}"

	awk -F'|' -v cols="$_mx_cols" -v present="$_mx_present" -v dv4="$_mx_dv4" -v dv6="$_mx_dv6" '
	function bn(path,   n, a) {
		n = split(path, a, "/")
		return a[n]
	}
	function stem_lst(dest) {
		sub(/\.lst$/, "", dest)
		return dest
	}
	function fam(src,   b) {
		b = bn(src)
		if (b ~ /^prefixes-ipv4-/ || b ~ /__ipv4\.lst$/ || b ~ /__ipv4$/) return "ipv4"
		if (b ~ /^prefixes-ipv6-/ || b ~ /__ipv6\.lst$/ || b ~ /__ipv6$/) return "ipv6"
		return "prefix"
	}
	function is_prefix(kind) {
		return (kind == "prefix" || kind == "prefix4" || kind == "prefix6" \
			|| kind == "prefix_ipv4" || kind == "prefix_ipv6" \
			|| kind == "prefix-ipv4" || kind == "prefix-ipv6")
	}
	function target_name(consumer, kind, src, dest,   st, f) {
		if (consumer == "dns") return dest
		st = stem_lst(dest)
		if (kind == "fqdn") {
			if (consumer == "zapret") return st "__fqdn.lst"
			if (dest ~ /^(fqdn-)/ || dest ~ /__fqdn\.lst$/ || dest ~ /^(prefixes-ipv4-|prefixes-ipv6-)/ || dest ~ /__ipv4\.lst$/ || dest ~ /__ipv6\.lst$/)
				return dest
			return st "__fqdn.lst"
		}
		if (!is_prefix(kind)) return dest
		f = fam(src)
		if (consumer == "zapret") {
			if (f == "ipv4") return st "__ipv4.lst"
			if (f == "ipv6") return st "__ipv6.lst"
			return st "__prefix.lst"
		}
		if (dest ~ /^(fqdn-)/ || dest ~ /^(prefixes-ipv4-|prefixes-ipv6-)/ || dest ~ /__fqdn\.lst$/ || dest ~ /__ipv4\.lst$/ || dest ~ /__ipv6\.lst$/)
			return dest
		if (f == "ipv4") return st "__ipv4.lst"
		if (f == "ipv6") return st "__ipv6.lst"
		return dest
	}
	function skip_af(t) {
		if (dv4 == "1" && t ~ /__ipv4\.lst$/) return 1
		if (dv6 == "1" && t ~ /__ipv6\.lst$/) return 1
		return 0
	}
	function present_in(key, consumer, dirtype, name,   stem) {
		if (name == "" || key == "") return 0
		if ((key SUBSEP dirtype SUBSEP name) in have) return 1
		if (consumer != "zapret" && consumer != "iface") return 0
		if (name ~ /__fqdn\.lst$/) {
			stem = name; sub(/__fqdn\.lst$/, ".lst", stem)
			if ((key SUBSEP dirtype SUBSEP stem) in have) return 1
		}
		if (name ~ /__ipv4\.lst$/) {
			stem = name; sub(/__ipv4\.lst$/, ".lst", stem)
			if ((key SUBSEP dirtype SUBSEP stem) in have) return 1
			stem = name; sub(/__ipv4\.lst$/, "__prefix.lst", stem)
			if ((key SUBSEP dirtype SUBSEP stem) in have) return 1
		}
		if (name ~ /__ipv6\.lst$/) {
			stem = name; sub(/__ipv6\.lst$/, ".lst", stem)
			if ((key SUBSEP dirtype SUBSEP stem) in have) return 1
		}
		if (name ~ /__prefix\.lst$/) {
			stem = name; sub(/__prefix\.lst$/, ".lst", stem)
			if ((key SUBSEP dirtype SUBSEP stem) in have) return 1
		}
		return 0
	}
	function add_rev(consumer, dirtype, name, tag,   k) {
		if (name == "" || tag == "") return
		k = consumer SUBSEP dirtype SUBSEP name
		if ((k SUBSEP tag) in revseen) return
		revseen[k SUBSEP tag] = 1
		rev[k] = rev[k] tag "\n"
	}
	function index_req(consumer, dirtype, tname, tag,   stem) {
		reqn[consumer SUBSEP tag]++
		rn = reqn[consumer SUBSEP tag]
		reqd[consumer SUBSEP tag SUBSEP rn] = dirtype
		reqt[consumer SUBSEP tag SUBSEP rn] = tname
		add_rev(consumer, dirtype, tname, tag)
		if (consumer != "zapret" && consumer != "iface") return
		if (tname ~ /__fqdn\.lst$/) {
			stem = tname; sub(/__fqdn\.lst$/, ".lst", stem)
			add_rev(consumer, dirtype, stem, tag)
		}
		if (tname ~ /__ipv4\.lst$/) {
			stem = tname; sub(/__ipv4\.lst$/, ".lst", stem)
			add_rev(consumer, dirtype, stem, tag)
			stem = tname; sub(/__ipv4\.lst$/, "__prefix.lst", stem)
			add_rev(consumer, dirtype, stem, tag)
		}
		if (tname ~ /__ipv6\.lst$/) {
			stem = tname; sub(/__ipv6\.lst$/, ".lst", stem)
			add_rev(consumer, dirtype, stem, tag)
		}
		if (tname ~ /__prefix\.lst$/) {
			stem = tname; sub(/__prefix\.lst$/, ".lst", stem)
			add_rev(consumer, dirtype, stem, tag)
		}
	}
	function mark_cand(consumer, key, dirtype, name,   k, list, n, i, tag) {
		k = consumer SUBSEP dirtype SUBSEP name
		if (!(k in rev)) return
		list = rev[k]
		n = split(list, tags, "\n")
		for (i = 1; i <= n; i++) {
			tag = tags[i]
			if (tag == "") continue
			if ((key SUBSEP tag) in cand) continue
			cand[key SUBSEP tag] = 1
			candlist[key] = candlist[key] tag "\n"
		}
	}
	function tag_complete(key, consumer, tag,   n, i, dirtype, tname) {
		n = reqn[consumer SUBSEP tag] + 0
		if (n < 1) return 0
		for (i = 1; i <= n; i++) {
			dirtype = reqd[consumer SUBSEP tag SUBSEP i]
			tname = reqt[consumer SUBSEP tag SUBSEP i]
			if (!present_in(key, consumer, dirtype, tname)) return 0
		}
		return 1
	}
	BEGIN {
		while ((getline line < cols) > 0) {
			sub(/\r$/, "", line)
			if (line == "") continue
			n = split(line, a, "|")
			if (n < 5) continue
			ckey = a[1]; ctgt[ckey] = a[2]; cmode[ckey] = a[5]
			keys[++kn] = ckey
			need[a[2] SUBSEP a[5]] = 1
		}
		close(cols)
		while ((getline line < present) > 0) {
			sub(/\r$/, "", line)
			if (line == "") continue
			n = split(line, a, "|")
			if (n < 3) continue
			have[a[1] SUBSEP a[2] SUBSEP a[3]] = 1
			pk = a[1]
			pres[pk] = pres[pk] a[2] "|" a[3] "\n"
		}
		close(present)
	}
	NF >= 4 {
		tag = $1; kind = $2; src = $3; dest = $4
		pref = is_prefix(kind)
		if (("iface" SUBSEP "all") in need) {
			tn = target_name("iface", kind, src, dest)
			if (kind == "fqdn") index_req("iface", "fqdn", tn, tag)
			else if (pref) index_req("iface", "pfx", tn, tag)
		}
		if (("dns" SUBSEP "fqdn_only") in need) {
			if (kind == "fqdn") index_req("dns", "fqdn", dest, tag)
		}
		if (("zapret" SUBSEP "all") in need) {
			tn = target_name("zapret", kind, src, dest)
			if (pref && skip_af(tn)) {
				# skipped requirement (AF disabled)
			} else if (kind == "fqdn") {
				index_req("zapret", "fqdn", tn, tag)
			} else if (pref) {
				index_req("zapret", "pfx", tn, tag)
			}
		}
	}
	END {
		for (i = 1; i <= kn; i++) {
			key = keys[i]
			consumer = ctgt[key]
			if (!(key in pres)) continue
			n = split(pres[key], rows, "\n")
			for (r = 1; r <= n; r++) {
				if (rows[r] == "") continue
				split(rows[r], p, "|")
				mark_cand(consumer, key, p[1], p[2])
			}
			if (!(key in candlist)) continue
			n = split(candlist[key], tags, "\n")
			for (t = 1; t <= n; t++) {
				tag = tags[t]
				if (tag == "") continue
				if (tag_complete(key, consumer, tag))
					print key "|" tag
			}
		}
	}' "$_mx_files_tsv" > "$_mx_checked"
}

# One ubus payload for LuCI routing «Общее» (catalog once; files.tsv once).
selection_upstream_json_matrix() {
	_mx_root="${SELECTION_ROOT_DIR:-${SELECTION_DNS_ROOT:-${SELECTION_ZAPRET_ROOT:-}}}"
	[ -n "$_mx_root" ] || {
		selection_json_error "selection root missing"
		return 0
	}

	_mx_cat="$(selection_catalog_prepare "$_mx_root")" || {
		selection_json_error "empty upstream model"
		return 0
	}

	_mx_cols="$(mktemp)"
	_mx_present="$(mktemp)"
	_mx_checked="$(mktemp)"
	: > "$_mx_cols"
	: > "$_mx_present"
	: > "$_mx_checked"

	if [ -n "${SELECTION_ZAPRET_SECTIONS:-}" ]; then
		selection_zapret_disable_flags
	fi

	_mx_tmp="$(mktemp)"
	selection_iface_list_scope_ids > "$_mx_tmp" 2>/dev/null || :
	while IFS= read -r _mx_id || [ -n "${_mx_id:-}" ]; do
		[ -n "${_mx_id:-}" ] || continue
		selection_matrix_register_scope \
			iface "$_mx_id" "$_mx_id" all "$_mx_cols" "$_mx_present"
	done < "$_mx_tmp"

	: > "$_mx_tmp"
	if command -v dns_routing_list_instances_tsv >/dev/null 2>&1; then
		dns_routing_list_instances_tsv > "$_mx_tmp" 2>/dev/null || true
	fi
	while IFS='|' read -r _idx _mx_id _mx_host _t _u || [ -n "${_mx_id:-}" ]; do
		[ -n "${_mx_id:-}" ] || continue
		selection_matrix_register_scope \
			dns "$_mx_id" "${_mx_host:-$_mx_id}" fqdn_only "$_mx_cols" "$_mx_present"
	done < "$_mx_tmp"

	: > "$_mx_tmp"
	if [ -d "${SELECTION_ZAPRET_SECTIONS:-}" ]; then
		for _mx_dir in "$SELECTION_ZAPRET_SECTIONS"/*; do
			[ -d "$_mx_dir" ] || continue
			_mx_id="$(basename "$_mx_dir")"
			if selection_zapret_section_on_p "$_mx_dir/config/section.conf"; then
				printf '%s\t%s\n' "$_mx_id" "$_mx_id" >> "$_mx_tmp"
			fi
		done
	fi
	while IFS="$(printf '\t')" read -r _mx_id _mx_lab || [ -n "${_mx_id:-}" ]; do
		[ -n "${_mx_id:-}" ] || continue
		selection_matrix_register_scope \
			zapret "$_mx_id" "$_mx_lab" all "$_mx_cols" "$_mx_present"
	done < "$_mx_tmp"
	rm -f "$_mx_tmp"

	selection_matrix_resolve_checked \
		"$_mx_cat/files.tsv" "$_mx_cols" "$_mx_present" "$_mx_checked" \
		"${SELECTION_ZAPRET_DV4:-0}" "${SELECTION_ZAPRET_DV6:-0}"

	selection_json_emit_matrix "$_mx_cat/entities.tsv" "$_mx_cols" "$_mx_checked"
	rm -f "$_mx_cols" "$_mx_present" "$_mx_checked"
}

# CLI: materialize without JSON wrapper
selection_upstream_materialize() {
	target="$1"
	scope="$2"
	mode="${3:-}"
	shift 3
	case "$target" in
	iface)
		selection_iface_materialize_tags "$scope" "${mode:-all}" "$@"
		;;
	dns)
		selection_dns_materialize_tags "$scope" "${mode:-fqdn_only}" "$@"
		;;
	zapret)
		selection_zapret_materialize_tags "$scope" "${mode:-all}" "$@"
		;;
	*)
		return 1
		;;
	esac
}
