#!/bin/sh
# Dispatch selection backend by target (iface | dns | zapret).
# Presentation: CLI (lib/ui/components) and LuCI (rpcd) call into here.
# shellcheck shell=sh

if [ -z "${SELECTION_LIB_DIR:-}" ]; then
	if [ -n "${ROOT_DIR:-}" ] && [ -d "$ROOT_DIR/lib/selection" ]; then
		SELECTION_LIB_DIR="$ROOT_DIR/lib/selection"
	else
		SELECTION_LIB_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
	fi
fi

# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/json.sh"
# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/model.sh"
# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/target-iface.sh"
# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/target-dns.sh"
# shellcheck disable=SC1091
. "$SELECTION_LIB_DIR/target-zapret.sh"

selection_upstream_init_all() {
	root="$1"
	[ -n "$root" ] || return 1
	selection_iface_init_module "$root/iface-routing" || true
	selection_dns_init_module "$root/dns-routing" || true
	selection_zapret_init_module "$root/zapret" || true
}

selection_upstream_json_list_scopes() {
	target="$1"
	case "$target" in
	iface)
		selection_iface_json_list_scopes
		;;
	dns)
		selection_dns_json_list_scopes
		;;
	zapret)
		selection_zapret_json_list_scopes
		;;
	*)
		selection_json_error "unknown target: $target"
		;;
	esac
}

selection_upstream_json_get_model() {
	target="$1"
	scope="$2"
	mode="${3:-}"
	case "$target" in
	iface)
		selection_iface_json_get_model "$scope" "${mode:-all}"
		;;
	dns)
		selection_dns_json_get_model "$scope" "${mode:-fqdn_only}"
		;;
	zapret)
		selection_zapret_json_get_model "$scope" "${mode:-all}"
		;;
	*)
		selection_json_error "unknown target: $target"
		;;
	esac
}

selection_upstream_json_save() {
	target="$1"
	scope="$2"
	mode="${3:-}"
	shift 3
	case "$target" in
	iface)
		selection_iface_json_save "$scope" "${mode:-all}" "$@"
		;;
	dns)
		selection_dns_json_save "$scope" "${mode:-fqdn_only}" "$@"
		;;
	zapret)
		selection_zapret_json_save "$scope" "${mode:-all}" "$@"
		;;
	*)
		selection_json_error "unknown target: $target"
		;;
	esac
}

# CLI: materialize without JSON wrapper
selection_upstream_materialize() {
	target="$1"
	scope="$2"
	mode="${3:-}"
	shift 3
	case "$target" in
	iface)
		selection_iface_materialize_tags "$scope" "${mode:-all}" "$@"
		;;
	dns)
		selection_dns_materialize_tags "$scope" "${mode:-fqdn_only}" "$@"
		;;
	zapret)
		selection_zapret_materialize_tags "$scope" "${mode:-all}" "$@"
		;;
	*)
		return 1
		;;
	esac
}
