#!/bin/sh
# shellcheck shell=sh

state_sync__die() {
    if command -v die >/dev/null 2>&1; then
        die "$@"
    fi
    printf '[-] %s\n' "$*" >&2
    exit 1
}

state_sync_copy_dir_contents() {
    src="$1"
    dst="$2"
    [ -d "$src" ] || return 0
    mkdir -p "$dst"
    cp -a "$src/." "$dst/"
}

state_sync_copy_file_if_exists() {
    src="$1"
    dst="$2"
    [ -f "$src" ] || return 0
    mkdir -p "$(dirname -- "$dst")"
    cp -a "$src" "$dst"
}

state_sync_mirror_dir_files() {
    src="$1"
    dst="$2"
    mkdir -p "$src" "$dst"
    find "$dst" -mindepth 1 -maxdepth 1 -exec rm -rf {} \; 2>/dev/null || true
    find "$src" -mindepth 1 -maxdepth 1 -type f | sort | while IFS= read -r f; do
        [ -f "$f" ] || continue
        cp -f "$f" "$dst/"
    done
}

state_sync_iface_config_mirror_from_work() {
    iface="$1"
    work_interfaces_dir="$2"
    state_interfaces_dir="$3"

    [ -n "$iface" ] || state_sync__die "state_sync_iface_config_mirror_from_work: iface не задан"
    [ -n "$work_interfaces_dir" ] || state_sync__die "state_sync_iface_config_mirror_from_work: work_interfaces_dir не задан"
    [ -n "$state_interfaces_dir" ] || state_sync__die "state_sync_iface_config_mirror_from_work: state_interfaces_dir не задан"

    work_config_dir="$work_interfaces_dir/$iface/config"
    state_config_dir="$state_interfaces_dir/$iface/config"
    [ -d "$work_config_dir" ] || state_sync__die "Не найден рабочий config dir для iface=$iface: $work_config_dir"

    mkdir -p "$state_config_dir"
    find "$state_config_dir" -mindepth 1 -maxdepth 1 -exec rm -rf {} \; 2>/dev/null || true

    cp -f "$work_config_dir/iface.conf" "$state_config_dir/iface.conf"
    [ -f "$work_config_dir/network.uci" ] && cp -f "$work_config_dir/network.uci" "$state_config_dir/network.uci"
    [ -f "$work_config_dir/firewall.uci" ] && cp -f "$work_config_dir/firewall.uci" "$state_config_dir/firewall.uci"
    [ -f "$work_config_dir/source.conf" ] && cp -f "$work_config_dir/source.conf" "$state_config_dir/source.conf"
    [ -f "$work_config_dir/source.conf.meta" ] && cp -f "$work_config_dir/source.conf.meta" "$state_config_dir/source.conf.meta"
}

state_sync_iface_lists_mirror_from_work() {
    iface="$1"
    work_interfaces_dir="$2"
    state_interfaces_dir="$3"

    [ -n "$iface" ] || state_sync__die "state_sync_iface_lists_mirror_from_work: iface не задан"
    [ -n "$work_interfaces_dir" ] || state_sync__die "state_sync_iface_lists_mirror_from_work: work_interfaces_dir не задан"
    [ -n "$state_interfaces_dir" ] || state_sync__die "state_sync_iface_lists_mirror_from_work: state_interfaces_dir не задан"

    work_fqdn_dir="$work_interfaces_dir/$iface/fqdn.d"
    work_fqdn_exclude_dir="$work_interfaces_dir/$iface/fqdn.exclude.d"
    work_prefix_dir="$work_interfaces_dir/$iface/prefixes.d"
    state_fqdn_dir="$state_interfaces_dir/$iface/fqdn.d"
    state_fqdn_exclude_dir="$state_interfaces_dir/$iface/fqdn.exclude.d"
    state_prefix_dir="$state_interfaces_dir/$iface/prefixes.d"

    state_sync_mirror_dir_files "$work_fqdn_dir" "$state_fqdn_dir"
    state_sync_mirror_dir_files "$work_fqdn_exclude_dir" "$state_fqdn_exclude_dir"
    state_sync_mirror_dir_files "$work_prefix_dir" "$state_prefix_dir"
}

state_sync_profile_iface_routing() {
    state_root="$1"
    output_dir="$2"
    state_sync_copy_dir_contents "$state_root/iface-routing/state/interfaces" "$output_dir/iface-routing/interfaces"
}

state_sync_profile_dns_routing() {
    state_root="$1"
    output_dir="$2"
    state_sync_copy_dir_contents "$state_root/dns-routing/state/config" "$output_dir/dns-routing/config"
    state_sync_copy_dir_contents "$state_root/dns-routing/state/dns" "$output_dir/dns-routing/dns"
    state_sync_copy_dir_contents "$state_root/dns-routing/state/hosts" "$output_dir/dns-routing/hosts"
}

state_sync_profile_https_dns_proxy() {
    system_https_dns_proxy_file="$1"
    output_dir="$2"
    state_sync_copy_file_if_exists "$system_https_dns_proxy_file" "$output_dir/https-dns-proxy/https-dns-proxy"
}

state_sync_profile_zapret() {
    state_root="$1"
    output_dir="$2"
    state_sync_copy_dir_contents "$state_root/zapret/state/sections" "$output_dir/zapret/sections"
    state_sync_copy_file_if_exists "$state_root/zapret/state/sections.order" "$output_dir/zapret/sections.order"
    state_sync_copy_file_if_exists "$state_root/zapret/state/zapret.template" "$output_dir/zapret/zapret.template"
}

state_sync_profile_awg_ingress() {
    state_root="$1"
    output_dir="$2"
    state_sync_copy_dir_contents "$state_root/awg-ingress/state/server" "$output_dir/awg-ingress/server"
    state_sync_copy_dir_contents "$state_root/awg-ingress/state/peers" "$output_dir/awg-ingress/peers"
    state_sync_copy_file_if_exists "$state_root/awg-ingress/state/peers.tsv" "$output_dir/awg-ingress/peers.tsv"
}

state_sync_profile_vpn() {
    state_root="$1"
    output_dir="$2"
    state_sync_copy_dir_contents "$state_root/vpn/state/proton" "$output_dir/vpn/proton"
    state_sync_copy_dir_contents "$state_root/vpn/state/warp" "$output_dir/vpn/warp"
}

state_sync_profile_vk_turn() {
    state_root="$1"
    output_dir="$2"
    state_sync_copy_dir_contents "$state_root/vk-turn/state" "$output_dir/vk-turn"
}

# strict=1 (по умолчанию): без network.uci рядом с iface.conf — ошибка (portable export).
# strict=0: только предупреждение (materialize для restore с «живого» state, где UCI ещё не попал в state).
state_sync_validate_iface_export_contract() {
    interfaces_dir="$1"
    strict="${2:-1}"
    [ -d "$interfaces_dir" ] || return 0

    for iface_dir in "$interfaces_dir"/*/; do
        [ -d "$iface_dir" ] || continue
        iface_name="$(basename -- "${iface_dir%/}")"
        config_dir="$iface_dir/config"
        iface_conf="$config_dir/iface.conf"
        network_uci="$config_dir/network.uci"

        [ -f "$iface_conf" ] || continue
        if [ -f "$network_uci" ]; then
            continue
        fi
        msg="Нарушен контракт state export: отсутствует network.uci для iface=$iface_name ($network_uci)"
        if [ "$strict" = "1" ]; then
            state_sync__die "$msg"
        fi
        printf '[!] %s (strict=0: materialize продолжит)\n' "$msg" >&2
    done
}
