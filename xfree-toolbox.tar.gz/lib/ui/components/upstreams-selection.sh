#!/bin/sh
# shellcheck shell=sh
#
# Upstreams list selection (model-driven): entities.tsv + files.tsv → whiptail checklist.
# Sourced from lib/ui.sh (do not source this file directly from feature scripts).
#
# Call sites (выбор тегов upstream для материализации в target):
#   - iface-routing/selection-ui.sh
#   - dns-routing/select-lists.sh
#   - zapret/select-lists.sh (основные списки секции + exclude)
# Клавиши чеклиста (Пробел/Ok) — в ui_checklist.
# После Ok вызывающий пишет в профиль; CLI-итог — звёздочка у «Применить …», не msgbox.
#
# Large catalogs: whiptail argv limits. When the label map exceeds
# UI_UPSTREAMS_CHECKLIST_MAX (default 100), narrow by upstream source (from
# entities.tsv), then checklist that source; OK merges with ON tags elsewhere.
#
# Trap contract (ash + slang/newt; см. agents/conventions/ui-ux-contract.md):
#   - INT/TERM must not be default during whiptail (slang SIGINT on Ok → Cancel).
#   - Trap body must not rm tmp on INT — only on EXIT (nested source menu Ok).
#   - Caller держит свой `trap 'rm -rf "$TMP"' EXIT INT TERM` через весь вызов
#     ui_upstreams_select_tags_from_model (не снимать на время чеклиста).
#
# Not this component: upstreams/menu.sh «включить/выключить модули» — там другой
# набор строк (модули upstreams/, не rows из upstreams_build_model_tsv).

# Soft max checklist triples before source/group narrowing (override for tests/routers).
ui_upstreams_checklist_max() {
  _max="${UI_UPSTREAMS_CHECKLIST_MAX:-100}"
  case "$_max" in
    ''|*[!0-9]*) _max=100 ;;
  esac
  [ "$_max" -ge 1 ] || _max=100
  printf '%s\n' "$_max"
}

# Build map: "tag<TAB>label" from upstream entities.tsv.
# mode:
#   - all       : include entities with type suffix (fqdn/prefix/fqdn+prefix)
#   - fqdn_only : include only entities where has_fqdn=1, suffix "(fqdn)"
ui_upstreams_build_label_map() {
  entities_tsv="$1"
  map_tsv="$2"
  mode="${3:-all}"

  case "$mode" in
    fqdn_only)
      awk -F'|' '
      {
        tag=$1; source=$2; group=$3; service=$4; level=$5; has_fqdn=$6
        gsub(/\r/, "", has_fqdn)
        if (has_fqdn != 1) next
        if (level=="group") label="[" source "] [group] " group
        else label="[" source "] [service] " group " / " service
        print tag "\t" label " (fqdn)"
      }' "$entities_tsv" > "$map_tsv"
      ;;
    *)
      awk -F'|' '
      {
        tag=$1; source=$2; group=$3; service=$4; level=$5; has_fqdn=$6; has_prefix=$7
        if (level=="group") label="[" source "] [group] " group
        else label="[" source "] [service] " group " / " service
        type=""
        if (has_fqdn == 1) type="fqdn"
        if (has_prefix == 1) type=(type ? type "+prefix" : "prefix")
        if (type == "") type="unknown"
        print tag "\t" label " (" type ")"
      }' "$entities_tsv" > "$map_tsv"
      ;;
  esac
}

# Enrich states (tag, label, state) → tag, label, state, source, group (TSV).
# Prefer source/group from entities.tsv (col2/col3) — label parsing is BusyBox-fragile
# and was dropping whole upstreams (e.g. user) from the source picker on some routers.
ui_upstreams__enrich_states_tsv() {
  states_in="$1"
  states_out="$2"
  entities_tsv="${3:-}"

  awk -F'\t' -v ent="$entities_tsv" '
  BEGIN {
    if (ent != "") {
      while ((getline line < ent) > 0) {
        sub(/\r$/, "", line)
        n = split(line, a, "|")
        if (n >= 3 && a[1] != "") {
          tag_src[a[1]] = a[2]
          tag_grp[a[1]] = a[3]
        }
      }
      close(ent)
    }
  }
  NF >= 3 {
    tag = $1
    label = $2
    state = $3
    src = ""
    grp = ""
    if (tag in tag_src) src = tag_src[tag]
    if (tag in tag_grp) grp = tag_grp[tag]
    # Fallback: parse "[source] …" from label (portable index/substr only).
    if (src == "" && substr(label, 1, 1) == "[") {
      end = index(label, "]")
      if (end > 1) {
        src = substr(label, 2, end - 2)
        rest = substr(label, end + 1)
        if (substr(rest, 1, 1) == " ") rest = substr(rest, 2)
        if (grp == "" && index(rest, "[group] ") == 1) {
          rest = substr(rest, length("[group] ") + 1)
          p = index(rest, " (")
          if (p > 0) rest = substr(rest, 1, p - 1)
          grp = rest
        } else if (grp == "" && index(rest, "[service] ") == 1) {
          rest = substr(rest, length("[service] ") + 1)
          p = index(rest, " (")
          if (p > 0) rest = substr(rest, 1, p - 1)
          s = index(rest, " / ")
          if (s > 0) grp = substr(rest, 1, s - 1)
          else grp = rest
        }
      }
    }
    print tag "\t" label "\t" state "\t" src "\t" grp
  }' "$states_in" > "$states_out"
}

# Run checklist for a states slice (tag, label, state[, ...]). Prints mapped tags.
# ash: avoid title=/prompt=/label= names that ui_* clobber.
ui_upstreams__checklist_slice() {
  _uus_cs_title="$1"
  _uus_cs_prompt="$2"
  _uus_cs_slice="$3"
  _uus_cs_map="$4"

  : > "$_uus_cs_map"
  set --
  _uus_cs_id=1
  while IFS="$(printf '\t')" read -r _uus_cs_tag _uus_cs_label _uus_cs_state _uus_cs_src _uus_cs_grp; do
    [ -n "${_uus_cs_tag:-}" ] || continue
    printf '%s\t%s\t%s\n' "$_uus_cs_id" "$_uus_cs_tag" "$_uus_cs_label" >> "$_uus_cs_map"
    set -- "$@" "$_uus_cs_id" "$_uus_cs_label" "$_uus_cs_state"
    _uus_cs_id=$((_uus_cs_id + 1))
  done < "$_uus_cs_slice"

  [ "$#" -gt 0 ] || return 1

  if ! _uus_cs_selected="$(ui_checklist "$_uus_cs_title" "$_uus_cs_prompt" 24 100 18 "$@")"; then
    return 1
  fi

  _uus_cs_choices="${_uus_cs_map}.choices"
  _uus_cs_mapped="${_uus_cs_map}.mapped"
  printf '%s\n' "$_uus_cs_selected" | tr -d '\r"' | awk '{ for (i = 1; i <= NF; i++) print $i }' > "$_uus_cs_choices"
  : > "$_uus_cs_mapped"
  if [ -s "$_uus_cs_choices" ]; then
    while IFS= read -r _uus_cs_key; do
      [ -n "${_uus_cs_key:-}" ] || continue
      _uus_cs_tag="$(awk -F "$(printf '\t')" -v key="$_uus_cs_key" '$1 == key { print $2; exit }' "$_uus_cs_map")"
      [ -n "${_uus_cs_tag:-}" ] || _uus_cs_tag="$(awk -F "$(printf '\t')" -v key="$_uus_cs_key" '$3 == key { print $2; exit }' "$_uus_cs_map")"
      [ -n "${_uus_cs_tag:-}" ] || continue
      printf '%s\n' "$_uus_cs_tag" >> "$_uus_cs_mapped"
    done < "$_uus_cs_choices"
  fi
  cat "$_uus_cs_mapped"
  return 0
}

# Build source meta (source\ttotal\ton) from entities ∩ states tags.
# Prefer entities col2 — do not depend on enriched label parse (BusyBox/UI drift).
ui_upstreams__source_meta_from_entities() {
  entities_tsv="$1"
  states_tsv="$2"
  meta_out="$3"

  awk -F'|' -v st="$states_tsv" '
  BEGIN {
    nsrc = 0
    while ((getline line < st) > 0) {
      sub(/\r$/, "", line)
      nf = split(line, a, "\t")
      if (nf < 1 || a[1] == "") continue
      intags[a[1]] = 1
      if (nf >= 3 && (a[3] == "ON" || a[3] == "on" || a[3] == "On")) on_tag[a[1]] = 1
    }
    close(st)
  }
  NF >= 2 {
    tag = $1
    src = $2
    gsub(/\r/, "", tag)
    gsub(/\r/, "", src)
    if (tag == "" || src == "") next
    if (!(tag in intags)) next
    if (!(src in seen)) {
      seen[src] = 1
      nsrc++
      order[nsrc] = src
      total[src] = 0
      on[src] = 0
    }
    total[src]++
    if (tag in on_tag) on[src]++
  }
  END {
    for (i = 1; i <= nsrc; i++) {
      k = order[i]
      print k "\t" total[k] "\t" on[k]
    }
  }' "$entities_tsv" > "$meta_out"
}

# Pick upstream source for a large catalog.
# Exit: 0 + source name on stdout; 1 = Cancel/Esc; 2 = no sources.
# Order: smallest catalogs first so user is not hidden under rekryt on a short TTY.
# ash has no local: do not assign title/prompt here — ui_menu would clobber caller.
ui_upstreams__pick_source() {
  _uus_ps_title="$1"
  _uus_ps_entities="$2"
  _uus_ps_states="$3"

  _uus_ps_meta="$(mktemp)"
  _uus_ps_keys="$(mktemp)"
  ui_upstreams__source_meta_from_entities "$_uus_ps_entities" "$_uus_ps_states" "$_uus_ps_meta"

  if [ ! -s "$_uus_ps_meta" ]; then
    rm -f "$_uus_ps_meta" "$_uus_ps_keys"
    return 2
  fi

  sort -t "$(printf '\t')" -k2,2n -k1,1 "$_uus_ps_meta" > "$_uus_ps_keys"

  set --
  _uus_ps_n=0
  _uus_ps_names=""
  while IFS="$(printf '\t')" read -r _uus_ps_key _uus_ps_tot _uus_ps_on; do
    [ -n "${_uus_ps_key:-}" ] || continue
    _uus_ps_n=$((_uus_ps_n + 1))
    if [ -n "$_uus_ps_names" ]; then
      _uus_ps_names="$_uus_ps_names, $_uus_ps_key"
    else
      _uus_ps_names="$_uus_ps_key"
    fi
    set -- "$@" "$_uus_ps_key" "${_uus_ps_key} (вкл ${_uus_ps_on:-0} / ${_uus_ps_tot:-0})"
  done < "$_uus_ps_keys"
  rm -f "$_uus_ps_meta" "$_uus_ps_keys"

  [ "$#" -gt 0 ] || return 2

  _uus_ps_list_h="$_uus_ps_n"
  [ "$_uus_ps_list_h" -lt 3 ] && _uus_ps_list_h=3
  [ "$_uus_ps_list_h" -gt 12 ] && _uus_ps_list_h=12
  _uus_ps_height=$((_uus_ps_list_h + 8))
  [ "$_uus_ps_height" -lt 14 ] && _uus_ps_height=14

  # Prefix assignment persists on ash functions — clear after menu.
  UI_MENU_NOTAGS=1
  ui_menu \
    "$_uus_ps_title" \
    "Выберите upstream (всего $_uus_ps_n: $_uus_ps_names)" \
    "$_uus_ps_height" 100 "$_uus_ps_list_h" \
    "$@"
  _uus_ps_rc=$?
  unset UI_MENU_NOTAGS
  return "$_uus_ps_rc"
}

# Filter states rows to one source (via entities tag→source map).
# BusyBox awk: never assign to $1/$2 before print $0 — that rebuilds $0 with OFS=space
# and drops tabs, so checklist_slice then sees empty labels.
ui_upstreams__states_for_source() {
  entities_tsv="$1"
  states_tsv="$2"
  source="$3"
  out_tsv="$4"

  awk -F'\t' -v ent="$entities_tsv" -v s="$source" '
  BEGIN {
    while ((getline line < ent) > 0) {
      sub(/\r$/, "", line)
      n = split(line, a, "|")
      if (n >= 2 && a[1] != "" && a[2] == s) tags[a[1]] = 1
    }
    close(ent)
  }
  NF >= 3 {
    tag = $1
    gsub(/\r/, "", tag)
    if (tag in tags) print $1 "\t" $2 "\t" $3
  }' "$states_tsv" > "$out_tsv"
}

# Show a unified upstream checklist and return selected tags (newline-separated).
# Arguments:
#  1 title
#  2 prompt
#  3 entities_tsv
#  4 files_tsv
#  5 mode (all|fqdn_only)
#  6 state_checker_func (function: checker <tag> <files_tsv>) — legacy per-tag path
#  7 enabled_tags_tsv (optional) — precomputed enabled tags; preferred for large models
# Contract (whiptail checklist):
#  - OK: exit 0. stdout — выбранные теги по строке; пустой stdout означает подтверждённый пустой выбор
#    (все галочки сняты). Вызывающий код обязан записать это в target (в т.ч. очистить списки).
#  - Cancel / Esc / ошибка диалога: exit 1, stdout пустой — не сохранять, вернуться к предыдущему меню.
ui_upstreams_select_tags_from_model() {
  # ash has no local — keep caller-facing args under _uus_* so ui_menu/ui_checklist
  # (which assign title=/prompt=) cannot clobber the DNS/iface prompt.
  _uus_title="$1"
  _uus_prompt="$2"
  _uus_entities="$3"
  _uus_files="$4"
  _uus_mode="${5:-all}"
  _uus_checker="$6"
  _uus_enabled="${7:-}"

  [ -s "$_uus_entities" ] || return 1
  [ -s "$_uus_files" ] || return 1

  _uus_tmp="$(mktemp -d)"
  # Swallow slang SIGINT on Ok; only EXIT removes tmp (INT must not wipe mid-flow).
  trap 'rm -rf "$_uus_tmp"' EXIT
  trap ':' INT TERM

  _uus_map="$_uus_tmp/map.tsv"
  _uus_choice_map="$_uus_tmp/choice-map.tsv"
  _uus_states="$_uus_tmp/states.tsv"
  _uus_slice="$_uus_tmp/slice.tsv"
  _uus_selected="$_uus_tmp/selected-scope.lst"
  _uus_merged="$_uus_tmp/merged.lst"

  ui_upstreams_build_label_map "$_uus_entities" "$_uus_map" "$_uus_mode"
  [ -s "$_uus_map" ] || {
    rm -rf "$_uus_tmp"
    trap - EXIT INT TERM
    return 1
  }

  if [ -s "${_uus_enabled:-}" ]; then
    awk -F'\t' -v ef="$_uus_enabled" '
      BEGIN {
        while ((getline t < ef) > 0) {
          sub(/\r$/, "", t)
          if (t != "") en[t] = 1
        }
        close(ef)
      }
      NF >= 2 {
        tag = $1
        label = $2
        state = (tag in en ? "ON" : "OFF")
        print tag "\t" label "\t" state
      }' "$_uus_map" > "$_uus_states"
  elif [ -n "${_uus_checker:-}" ]; then
    : > "$_uus_states"
    while IFS="$(printf '\t')" read -r _uus_tag _uus_label; do
      [ -n "${_uus_tag:-}" ] || continue
      _uus_state="OFF"
      if "$_uus_checker" "$_uus_tag" "$_uus_files"; then
        _uus_state="ON"
      fi
      printf '%s\t%s\t%s\n' "$_uus_tag" "$_uus_label" "$_uus_state" >> "$_uus_states"
    done < "$_uus_map"
  else
    awk -F'\t' 'NF >= 2 { print $1 "\t" $2 "\t" "OFF" }' "$_uus_map" > "$_uus_states"
  fi

  [ -s "$_uus_states" ] || {
    rm -rf "$_uus_tmp"
    trap - EXIT INT TERM
    return 1
  }

  _uus_total="$(wc -l < "$_uus_states" | tr -d ' ')"
  _uus_max="$(ui_upstreams_checklist_max)"
  _uus_scope=""

  if [ "$_uus_total" -gt "$_uus_max" ]; then
    _uus_scope_out="$_uus_tmp/scope.out"
    : > "$_uus_scope_out"
    _uus_scope_rc=0
    ui_upstreams__pick_source \
      "$_uus_title" \
      "$_uus_entities" \
      "$_uus_states" > "$_uus_scope_out" || _uus_scope_rc=$?
    if [ "$_uus_scope_rc" -eq 2 ]; then
      _uus_src_n="$(awk -F'|' 'NF>=2 { print $2 }' "$_uus_entities" | sort -u | wc -l | tr -d ' ')"
      ui_msgbox "$_uus_title" "Не удалось построить список upstream (пустой scope). entities sources≈${_uus_src_n}, rows=${_uus_total}."
      rm -rf "$_uus_tmp"
      trap - EXIT INT TERM
      return 1
    fi
    if [ "$_uus_scope_rc" -ne 0 ]; then
      rm -rf "$_uus_tmp"
      trap - EXIT INT TERM
      return 1
    fi
    _uus_scope="$(tr -d '\r' < "$_uus_scope_out" | sed 's/^"//;s/"$//' | head -n1)"
    [ -n "$_uus_scope" ] || {
      rm -rf "$_uus_tmp"
      trap - EXIT INT TERM
      return 1
    }

    ui_upstreams__states_for_source "$_uus_entities" "$_uus_states" "$_uus_scope" "$_uus_slice"
    _uus_checklist_prompt="${_uus_prompt} — [${_uus_scope}]"
  else
    cp "$_uus_states" "$_uus_slice"
    _uus_checklist_prompt="$_uus_prompt"
  fi

  [ -s "$_uus_slice" ] || {
    rm -rf "$_uus_tmp"
    trap - EXIT INT TERM
    return 1
  }

  if ! ui_upstreams__checklist_slice "$_uus_title" "$_uus_checklist_prompt" "$_uus_slice" "$_uus_choice_map" > "$_uus_selected"; then
    rm -rf "$_uus_tmp"
    trap - EXIT INT TERM
    return 1
  fi

  if [ -z "$_uus_scope" ]; then
    cat "$_uus_selected"
  else
    awk -F'\t' -v ent="$_uus_entities" -v s="$_uus_scope" -v sel="$_uus_selected" '
      BEGIN {
        while ((getline line < ent) > 0) {
          sub(/\r$/, "", line)
          n = split(line, a, "|")
          if (n >= 2 && a[1] != "") tag_src[a[1]] = a[2]
        }
        close(ent)
        while ((getline t < sel) > 0) {
          sub(/\r$/, "", t)
          if (t != "") picked[t] = 1
        }
        close(sel)
      }
      NF >= 3 {
        tag = $1
        state = $3
        gsub(/\r/, "", tag)
        src = tag_src[tag]
        if (src == s) {
          if (tag in picked) print tag
        } else if (state == "ON" || state == "on" || state == "On") {
          print tag
        }
      }
    ' "$_uus_states" > "$_uus_merged"
    cat "$_uus_merged"
  fi

  rm -rf "$_uus_tmp"
  trap - EXIT INT TERM
  return 0
}
