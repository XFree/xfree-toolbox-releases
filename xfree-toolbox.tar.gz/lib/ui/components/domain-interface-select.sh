#!/bin/sh
# shellcheck shell=sh
#
# Domain interface selection component (profile interfaces):
# lists domain interfaces from profiles/.../iface-routing/interfaces/,
# formats tags and labels, provides whiptail menu and CLI fallback,
# and handles optional "--all" marker for batch diagnostics/apply.
#
# Sourced from lib/ui.sh (or lib/common.sh fallback).
# Do not source directly from arbitrary feature scripts.
#
# Call sites:
#   - lib/common.sh (common_select_domain_interface wrapper)
#   - iface-routing/selection-ui.sh (select lists for interface)
#   - iface-routing/menu-interfaces.sh (select_interface_name)
#   - iface-routing/apply-interfaces.sh (choose_interface_interactive)
#   - iface-routing/delete-interface.sh (choose_interface_interactive)
#   - iface-routing/check-routing.sh (choose_interface_interactive)
#
# Not this component:
#   - iface-routing/self-route/menu.sh (special directory structure for self-route)
#   - Creating or deleting interface profile directories

: "${NL:=$(printf '\n')}"

ui_domain_iface_select() {
  _udis_title="Выбор интерфейса"
  _udis_prompt="Выберите интерфейс"
  _udis_dir=""
  _udis_item_desc=""
  _udis_item_desc_explicit=0
  _udis_has_all=0
  _udis_all_marker="${XFREE_CHECK_ROUTING_ALL_MARKER:-__xfree_iface_all__}"
  _udis_all_label="Все"
  _udis_numeric=0
  _udis_empty_msg=""
  _udis_empty_die=0
  _udis_filter_cmd=""
  _udis_list_override=""

  # Positional compatibility: ui_domain_iface_select [title] [interfaces_dir]
  if [ $# -gt 0 ]; then
    case "$1" in
      -*) ;;
      *)
        _udis_title="${1:-Выбор интерфейса}"
        [ $# -ge 2 ] && _udis_dir="$2"
        if [ $# -ge 2 ]; then
          shift 2
        else
          shift 1
        fi
        ;;
    esac
  fi

  while [ $# -gt 0 ]; do
    case "$1" in
      --title)
        _udis_title="$2"
        shift 2
        ;;
      --prompt)
        _udis_prompt="$2"
        shift 2
        ;;
      --dir)
        _udis_dir="$2"
        shift 2
        ;;
      --item-desc)
        _udis_item_desc="$2"
        _udis_item_desc_explicit=1
        shift 2
        ;;
      --all)
        _udis_has_all=1
        shift
        ;;
      --all-marker)
        _udis_all_marker="$2"
        _udis_has_all=1
        shift 2
        ;;
      --all-label)
        _udis_all_label="$2"
        _udis_has_all=1
        shift 2
        ;;
      --numeric)
        _udis_numeric=1
        shift
        ;;
      --filter-cmd)
        _udis_filter_cmd="$2"
        shift 2
        ;;
      --empty-msg)
        _udis_empty_msg="$2"
        shift 2
        ;;
      --empty-die)
        _udis_empty_die=1
        shift
        ;;
      --list)
        _udis_list_override="$2"
        shift 2
        ;;
      *)
        shift
        ;;
    esac
  done

  if [ -z "$_udis_dir" ] && [ -z "$_udis_list_override" ]; then
    if [ -n "${INTERFACES_DIR:-}" ]; then
      _udis_dir="$INTERFACES_DIR"
    elif command -v common_interfaces_dir >/dev/null 2>&1; then
      _udis_dir="$(common_interfaces_dir 2>/dev/null || true)"
    fi
  fi

  _udis_raw=""
  if [ -n "$_udis_list_override" ]; then
    _udis_raw="$_udis_list_override"
  elif [ -n "$_udis_dir" ] && [ -d "$_udis_dir" ]; then
    if command -v common_list_domain_interfaces >/dev/null 2>&1; then
      _udis_raw="$(common_list_domain_interfaces "$_udis_dir" 2>/dev/null || true)"
    else
      _udis_raw="$(find "$_udis_dir" -type f -path '*/config/iface.conf' 2>/dev/null \
        | sed "s|$_udis_dir/||" \
        | sed 's|/config/iface.conf$||' \
        | sed '/^$/d' \
        | sort -u)"
    fi
  fi

  _udis_filtered=""
  while IFS= read -r _udis_candidate || [ -n "$_udis_candidate" ]; do
    [ -n "$_udis_candidate" ] || continue
    if [ -n "$_udis_filter_cmd" ]; then
      "$_udis_filter_cmd" "$_udis_candidate" 2>/dev/null || continue
    fi
    _udis_filtered="${_udis_filtered}${_udis_filtered:+$NL}$_udis_candidate"
  done <<EOF
$_udis_raw
EOF

  if [ -z "$_udis_filtered" ]; then
    if [ -z "$_udis_empty_msg" ]; then
      if [ -n "$_udis_dir" ]; then
        _udis_empty_msg="Не найдены интерфейсы в каталоге:
$_udis_dir"
      else
        _udis_empty_msg="Интерфейсы не найдены."
      fi
    fi

    if [ "$_udis_empty_die" = "1" ]; then
      if command -v die >/dev/null 2>&1; then
        die "$_udis_empty_msg"
      else
        echo "[-] $_udis_empty_msg" >&2
        exit 1
      fi
    fi

    if command -v ui_msgbox >/dev/null 2>&1 && [ -t 0 ] && [ -c /dev/tty ]; then
      ui_msgbox "$_udis_title" "$_udis_empty_msg"
    elif command -v warn >/dev/null 2>&1; then
      warn "$_udis_empty_msg"
    else
      echo "[-] $_udis_empty_msg" >&2
    fi
    return 1
  fi

  # Non-interactive environment without tty (LuCI, cron, batch pipelines)
  if [ ! -t 0 ] && [ ! -c /dev/tty ]; then
    if [ "$_udis_has_all" = "1" ]; then
      printf '%s\n' "$_udis_all_marker"
      return 0
    fi
    return 1
  fi

  # Whiptail interactive menu (only when stdin is a terminal)
  if [ -t 0 ] && [ -c /dev/tty ] && command -v ui_menu >/dev/null 2>&1 && command -v ui_have_whiptail >/dev/null 2>&1 && ui_have_whiptail; then
    set --
    if [ "$_udis_numeric" = "1" ]; then
      _udis_mi=1
      if [ "$_udis_has_all" = "1" ]; then
        set -- "$@" "1" "$_udis_all_label"
        _udis_mi=2
      fi
      while IFS= read -r _udis_iface || [ -n "$_udis_iface" ]; do
        [ -n "$_udis_iface" ] || continue
        set -- "$@" "$_udis_mi" "$_udis_iface"
        _udis_mi=$((_udis_mi + 1))
      done <<EOF
$_udis_filtered
EOF

      _udis_choice="$(ui_menu "$_udis_title" "$_udis_prompt" 20 90 12 "$@" || true)"
      [ -n "${_udis_choice:-}" ] || return 1

      case "$_udis_choice" in
        ''|*[!0-9]*) return 1 ;;
      esac

      if [ "$_udis_has_all" = "1" ]; then
        if [ "$_udis_choice" -eq 1 ]; then
          printf '%s\n' "$_udis_all_marker"
          return 0
        fi
        _udis_target_idx=$((_udis_choice - 1))
      else
        _udis_target_idx="$_udis_choice"
      fi

      _udis_curr=1
      _udis_pick=""
      while IFS= read -r _udis_line || [ -n "$_udis_line" ]; do
        [ -n "$_udis_line" ] || continue
        if [ "$_udis_curr" -eq "$_udis_target_idx" ]; then
          _udis_pick="$_udis_line"
          break
        fi
        _udis_curr=$((_udis_curr + 1))
      done <<EOF
$_udis_filtered
EOF

      [ -n "$_udis_pick" ] || return 1
      printf '%s\n' "$_udis_pick"
      return 0
    else
      # Tag-based menu: tag is interface name (or all_marker)
      if [ "$_udis_has_all" = "1" ]; then
        set -- "$@" "$_udis_all_marker" "$_udis_all_label"
      fi
      while IFS= read -r _udis_iface || [ -n "$_udis_iface" ]; do
        [ -n "$_udis_iface" ] || continue
        if [ "$_udis_item_desc_explicit" = "1" ]; then
          _udis_desc="$_udis_item_desc"
        else
          _udis_desc="config: $_udis_iface"
        fi
        set -- "$@" "$_udis_iface" "$_udis_desc"
      done <<EOF
$_udis_filtered
EOF

      _udis_choice="$(ui_menu "$_udis_title" "$_udis_prompt" 20 100 12 "$@" || true)"
      [ -n "${_udis_choice:-}" ] || return 1
      printf '%s\n' "$_udis_choice"
      return 0
    fi
  fi

  # CLI fallback (plain text numbers from stdin)
  if [ "$_udis_has_all" = "1" ]; then
    printf '  1) %s\n' "$_udis_all_label" >&2
    _udis_i=2
    while IFS= read -r _udis_iface || [ -n "$_udis_iface" ]; do
      [ -n "$_udis_iface" ] || continue
      printf ' %2d) %s\n' "$_udis_i" "$_udis_iface" >&2
      _udis_i=$((_udis_i + 1))
    done <<EOF
$_udis_filtered
EOF
    printf 'Выберите номер: ' >&2
    if ! IFS= read -r _udis_num; then
      # If stdin is empty / closed (non-interactive stream), return all marker
      printf '%s\n' "$_udis_all_marker"
      return 0
    fi
    case "$_udis_num" in
      ''|*[!0-9]*) return 1 ;;
      1)
        printf '%s\n' "$_udis_all_marker"
        return 0
        ;;
      *)
        _udis_target_idx=$((_udis_num - 1))
        _udis_curr=1
        _udis_pick=""
        while IFS= read -r _udis_line || [ -n "$_udis_line" ]; do
          [ -n "$_udis_line" ] || continue
          if [ "$_udis_curr" -eq "$_udis_target_idx" ]; then
            _udis_pick="$_udis_line"
            break
          fi
          _udis_curr=$((_udis_curr + 1))
        done <<EOF
$_udis_filtered
EOF
        [ -n "$_udis_pick" ] || return 1
        printf '%s\n' "$_udis_pick"
        return 0
        ;;
    esac
  else
    _udis_i=1
    while IFS= read -r _udis_iface || [ -n "$_udis_iface" ]; do
      [ -n "$_udis_iface" ] || continue
      printf ' %2d) %s\n' "$_udis_i" "$_udis_iface" >&2
      _udis_i=$((_udis_i + 1))
    done <<EOF
$_udis_filtered
EOF
    printf 'Select interface: ' >&2
    IFS= read -r _udis_num || return 1
    case "$_udis_num" in
      ''|*[!0-9]*)
        if [ "$_udis_empty_die" = "1" ]; then
          if command -v die >/dev/null 2>&1; then
            die "Invalid selection: $_udis_num"
          else
            echo "[-] Invalid selection: $_udis_num" >&2
            exit 1
          fi
        else
          return 1
        fi
        ;;
    esac
    _udis_target_idx="$_udis_num"
    _udis_curr=1
    _udis_pick=""
    while IFS= read -r _udis_line || [ -n "$_udis_line" ]; do
      [ -n "$_udis_line" ] || continue
      if [ "$_udis_curr" -eq "$_udis_target_idx" ]; then
        _udis_pick="$_udis_line"
        break
      fi
      _udis_curr=$((_udis_curr + 1))
    done <<EOF
$_udis_filtered
EOF
    [ -n "$_udis_pick" ] || return 1
    printf '%s\n' "$_udis_pick"
    return 0
  fi
}

ui_domain_interface_select() {
  ui_domain_iface_select "$@"
}
