#!/bin/sh
# shellcheck shell=sh
#
# Единые обёртки запуска команд из **/menu.sh (через lib/ui.sh).
# Подключается из lib/ui.sh после определения ui_run_with_output.
#
# Контракт argv (единый стиль «title → команда → аргументы»):
#   ui_menu_invoke_with_output <title> <команда> [аргументы...]
#     <команда> — как первый токен exec: часто sh, poetry, абсолютный путь к .sh.
#   ui_menu_invoke_with_output_textbox — то же, итог только в textbox (без живого tty).
#   ui_menu_invoke_with_output_script[_relaxed] <title> <scriptPath> [аргументы...]
#     Один исполняемый файл + его argv (chmod + проверка существования).
#   ui_menu_invoke_script[_relaxed] <scriptPath> [аргументы...]
#     Без live-log и без итогового textbox: только прямой TTY (ui_run_script).
#     Только для коротких/вложенных меню (ui), интерактивного выбора, не для install/upgrade.
#   ui_menu_invoke_with_output_sh_relaxed <scriptPath> [аргументы...]
#     Заголовок = basename(script); запуск: sh scriptPath args (как diagnostics run_log_safe).
#
# Потоковый вывод в «живом» режиме: ui_run_with_output → common_exec_streaming (lib/common.sh).

ui_menu_prepare_executable() {
  path="$1"
  [ -n "$path" ] || return 1
  [ -f "$path" ] || {
    ui_msgbox "Ошибка" "Скрипт не найден:\n$path"
    return 1
  }
  [ -x "$path" ] || chmod +x "$path" 2>/dev/null || true
  return 0
}

ui_menu_invoke_with_output() {
  title="$1"
  shift
  ui_run_with_output "$title" "$@"
}

ui_menu_invoke_with_output_textbox() {
  title="$1"
  shift
  UI_RUN_WITH_OUTPUT_MODE=textbox ui_run_with_output "$title" "$@"
}

ui_menu_invoke_script() {
  script="$1"
  shift || true
  ui_menu_prepare_executable "$script" || return 1
  ui_run_script "$script" "$@"
}

ui_menu_invoke_script_relaxed() {
  script="$1"
  shift || true
  ui_menu_prepare_executable "$script" || return 0
  ui_run_script "$script" "$@" || true
  return 0
}

ui_menu_invoke_with_output_script() {
  title="$1"
  script="$2"
  shift 2 || true
  ui_menu_prepare_executable "$script" || return 1
  ui_run_with_output "$title" "$script" "$@"
}

ui_menu_invoke_with_output_script_relaxed() {
  title="$1"
  script="$2"
  shift 2 || true
  ui_menu_prepare_executable "$script" || return 0
  ui_run_with_output "$title" "$script" "$@" || true
  return 0
}

# Заголовок = basename(script); не рвёт меню при ошибке / отсутствии файла.
ui_menu_invoke_with_output_sh_relaxed() {
  script="$1"
  shift || true
  ui_menu_prepare_executable "$script" || return 0
  title="$(basename -- "$script" 2>/dev/null || basename "$script")"
  ui_run_with_output "$title" sh "$script" "$@" || true
  return 0
}

# Паттерн awg-ingress: первый argv — обёртка (run-sh-safe), chmod если файл есть и не +x.
ui_menu_chmod_first_if_needed() {
  [ -f "${1:-}" ] && [ ! -x "$1" ] && chmod +x "$1" 2>/dev/null || true
}
