#!/bin/sh
# shellcheck shell=sh
# Canonical LED runtime library for xfree-toolbox.

# Список по умолчанию для Cudy WBR3000UAX (отсутствующие в sysfs пропускаются).
HARDWARE_LED_DEFAULT_LIST="
blue:power
blue:wan-online
blue:wan
blue:lan
blue:wlan-2ghz
blue:wlan-5ghz
mt76-phy0
mt76-phy1
red:fault
red:wps
"

hardware_led_describe() {
    case "$1" in
        blue:power)
            echo "Проверяю blue:power"
            echo "Действие: включаю синий индикатор питания."
            echo "Ожидание: на роутере должен загореться синий индикатор питания."
            ;;
        blue:wan-online)
            echo "Проверяю blue:wan-online"
            echo "Действие: включаю синий индикатор состояния интернета / WAN online."
            echo "Ожидание: должен загореться синий индикатор, связанный с доступом в интернет."
            ;;
        blue:wan)
            echo "Проверяю blue:wan"
            echo "Действие: включаю синий индикатор WAN."
            echo "Ожидание: должен загореться синий индикатор WAN-порта."
            ;;
        blue:lan)
            echo "Проверяю blue:lan"
            echo "Действие: включаю синий индикатор LAN."
            echo "Ожидание: должен загореться синий индикатор LAN."
            ;;
        blue:wlan-2ghz)
            echo "Проверяю blue:wlan-2ghz"
            echo "Действие: включаю синий индикатор Wi-Fi 2.4 GHz."
            echo "Ожидание: должен загореться синий индикатор диапазона 2.4 GHz."
            ;;
        blue:wlan-5ghz)
            echo "Проверяю blue:wlan-5ghz"
            echo "Действие: включаю синий индикатор Wi-Fi 5 GHz."
            echo "Ожидание: должен загореться синий индикатор диапазона 5 GHz."
            ;;
        mt76-phy0)
            echo "Проверяю mt76-phy0"
            echo "Действие: включаю служебный LED от Wi-Fi-драйвера mt76 для phy0."
            echo "Ожидание: может загореться один из Wi-Fi-индикаторов. Если ничего не видно — служебная сущность без отдельной лампы."
            ;;
        mt76-phy1)
            echo "Проверяю mt76-phy1"
            echo "Действие: включаю служебный LED от Wi-Fi-драйвера mt76 для phy1."
            echo "Ожидание: может загореться один из Wi-Fi-индикаторов. Если ничего не видно — служебная сущность без отдельной лампы."
            ;;
        red:fault)
            echo "Проверяю red:fault"
            echo "Действие: включаю красный индикатор ошибки."
            echo "Ожидание: должен загореться красный индикатор аварии / fault."
            ;;
        red:wps)
            echo "Проверяю red:wps"
            echo "Действие: включаю красный индикатор WPS."
            echo "Ожидание: должен загореться красный индикатор WPS или служебный красный индикатор."
            ;;
        *)
            echo "Проверяю $1"
            echo "Действие: включаю неизвестный LED."
            echo "Ожидание: смотрите, какой индикатор физически загорится."
            ;;
    esac
}

hardware_led_sysfs_path() {
    name="$1"
    [ -n "$name" ] || return 1
    printf '%s' "/sys/class/leds/$name"
}

HARDWARE_LED_STATE_DIR="${TMPDIR:-/tmp}/xfree-led-state"

hardware_led_state_slug() {
    printf '%s' "$1" | tr ':/' '_'
}

# Активный trigger из sysfs (строка вида «… [default-on] …»).
hardware_led_sysfs_active_trigger() {
    _led="$1"
    _path="$(hardware_led_sysfs_path "$_led")" || return 1
    sed -n 's/.*\[\([^][]*\)\].*/\1/p' "$_path/trigger" 2>/dev/null | head -n1
}

hardware_led_capture_state() {
    led="$1"
    path="$(hardware_led_sysfs_path "$led")" || return 1
    [ -d "$path" ] || return 1
    slug="$(hardware_led_state_slug "$led")"
    stdir="$HARDWARE_LED_STATE_DIR/$slug"
    [ -f "$stdir/captured" ] && return 0

    mkdir -p "$stdir"
    trig="$(hardware_led_sysfs_active_trigger "$led")"
    [ -n "$trig" ] || trig="none"
    printf '%s\n' "$trig" >"$stdir/trigger"
    cat "$path/brightness" 2>/dev/null >"$stdir/brightness" || printf '0\n' >"$stdir/brightness"

    for _attr in device_name mode link tx rx delayon delayoff interval \
        default-state gpio inverted port pin; do
        if [ -f "$path/$_attr" ]; then
            cat "$path/$_attr" 2>/dev/null >"$stdir/$_attr" || true
        fi
    done
    : >"$stdir/captured"
    return 0
}

hardware_led_apply_uci_led() {
    led="$1"
    path="$(hardware_led_sysfs_path "$led")" || return 1
    [ -d "$path" ] || return 1
    command -v uci >/dev/null 2>&1 || return 1

    section=""
    for s in $(uci -q show system 2>/dev/null | sed -n 's/^\(system\.[^=]*\)=led$/\1/p'); do
        sysfs="$(uci -q get "${s}.sysfs" 2>/dev/null)" || true
        name="$(uci -q get "${s}.name" 2>/dev/null)" || true
        if [ "$sysfs" = "$led" ] || [ "$name" = "$led" ]; then
            section="$s"
            break
        fi
    done
    [ -n "$section" ] || return 1

    trigger="$(uci -q get "${section}.trigger" 2>/dev/null)" || trigger="none"
    echo none >"$path/trigger" 2>/dev/null || true
    echo "$trigger" >"$path/trigger" 2>/dev/null || return 1

    case "$trigger" in
        netdev)
            dev="$(uci -q get "${section}.dev" 2>/dev/null)" || true
            mode="$(uci -q get "${section}.mode" 2>/dev/null)" || true
            [ -n "$dev" ] && echo "$dev" >"$path/device_name" 2>/dev/null || true
            [ -n "$mode" ] && echo "$mode" >"$path/mode" 2>/dev/null || true
            ;;
        timer)
            delayon="$(uci -q get "${section}.delayon" 2>/dev/null)" || true
            delayoff="$(uci -q get "${section}.delayoff" 2>/dev/null)" || true
            [ -n "$delayon" ] && echo "$delayon" >"$path/delayon" 2>/dev/null || true
            [ -n "$delayoff" ] && echo "$delayoff" >"$path/delayoff" 2>/dev/null || true
            ;;
        gpio)
            gpio="$(uci -q get "${section}.gpio" 2>/dev/null)" || true
            port="$(uci -q get "${section}.port" 2>/dev/null)" || true
            pin="$(uci -q get "${section}.pin" 2>/dev/null)" || true
            inverted="$(uci -q get "${section}.inverted" 2>/dev/null)" || true
            [ -n "$gpio" ] && echo "$gpio" >"$path/gpio" 2>/dev/null || true
            [ -n "$port" ] && echo "$port" >"$path/port" 2>/dev/null || true
            [ -n "$pin" ] && echo "$pin" >"$path/pin" 2>/dev/null || true
            [ -n "$inverted" ] && echo "$inverted" >"$path/inverted" 2>/dev/null || true
            ;;
        none)
            max="$(cat "$path/max_brightness" 2>/dev/null)" || max=255
            bri="$(uci -q get "${section}.default" 2>/dev/null)" || bri="$max"
            echo "$bri" >"$path/brightness" 2>/dev/null || true
            ;;
    esac
    return 0
}

hardware_led_restore_captured() {
    led="$1"
    path="$(hardware_led_sysfs_path "$led")" || return 1
    [ -d "$path" ] || return 1
    slug="$(hardware_led_state_slug "$led")"
    stdir="$HARDWARE_LED_STATE_DIR/$slug"
    [ -f "$stdir/captured" ] || return 1

    trig="$(cat "$stdir/trigger" 2>/dev/null)" || trig="none"
    echo none >"$path/trigger" 2>/dev/null || true
    echo "$trig" >"$path/trigger" 2>/dev/null || {
        rm -rf "$stdir" 2>/dev/null || true
        hardware_led_apply_uci_led "$led"
        return $?
    }

    for _attr in device_name mode link tx rx delayon delayoff interval \
        default-state gpio inverted port pin; do
        if [ -f "$stdir/$_attr" ] && [ -f "$path/$_attr" ]; then
            cat "$stdir/$_attr" >"$path/$_attr" 2>/dev/null || true
        fi
    done

    if [ "$trig" = "none" ]; then
        cat "$stdir/brightness" >"$path/brightness" 2>/dev/null || true
    fi

    rm -rf "$stdir" 2>/dev/null || true
    return 0
}

# Вернуть LED в состояние до ручного управления (тест / мигание).
hardware_led_release() {
    led="$1"
    if hardware_led_restore_captured "$led" 2>/dev/null; then
        return 0
    fi
    hardware_led_apply_uci_led "$led" 2>/dev/null && return 0
    return 1
}

hardware_led_restore_all_captured() {
    [ -d "$HARDWARE_LED_STATE_DIR" ] || return 0
    for stdir in "$HARDWARE_LED_STATE_DIR"/*; do
        [ -d "$stdir" ] || continue
        [ -f "$stdir/captured" ] || continue
        slug="${stdir##*/}"
        led=""
        for _name in $(hardware_led_list_sysfs_all 2>/dev/null); do
            [ "$(hardware_led_state_slug "$_name")" = "$slug" ] || continue
            led="$_name"
            break
        done
        [ -n "$led" ] && hardware_led_restore_captured "$led" 2>/dev/null || true
    done
}

hardware_led_on() {
    led="$1"
    path="$(hardware_led_sysfs_path "$led")" || return 1
    [ -d "$path" ] || return 1
    hardware_led_capture_state "$led" || true
    echo none > "$path/trigger" 2>/dev/null || true
    echo 1 > "$path/brightness" 2>/dev/null || return 1
    return 0
}

hardware_led_off() {
    led="$1"
    path="$(hardware_led_sysfs_path "$led")" || return 1
    [ -d "$path" ] || return 1
    echo 0 > "$path/brightness" 2>/dev/null || true
    return 0
}

hardware_led_restore_uci() {
    hardware_led_restore_all_captured 2>/dev/null || true
    if [ -x /etc/init.d/led ]; then
        /etc/init.d/led stop >/dev/null 2>&1 || true
        sleep 1
        if /etc/init.d/led start >/dev/null 2>&1; then
            return 0
        fi
        /etc/init.d/led restart >/dev/null 2>&1 && return 0
    fi
    if [ -x /etc/init.d/system ]; then
        /etc/init.d/system reload 2>/dev/null || true
        return 0
    fi
    return 1
}

hardware_led_list_available() {
    for name in $HARDWARE_LED_DEFAULT_LIST; do
        [ -d "/sys/class/leds/$name" ] && printf '%s\n' "$name"
    done
}

hardware_led_list_sysfs_all() {
    if [ ! -d /sys/class/leds ]; then
        return 1
    fi
    for x in /sys/class/leds/*; do
        [ -e "$x" ] || continue
        basename "$x"
    done
}

# Все LED на плате, стабильный порядок (для теста).
hardware_led_list_sysfs_sorted() {
    hardware_led_list_sysfs_all | sort -u
}

# --- Мигание red:fault ↔ blue:wan (USB modem cycle / ожидание интернета) ---

HARDWARE_LED_MODEM_BLINK_A="red:fault"
HARDWARE_LED_MODEM_BLINK_B="blue:wan"
HARDWARE_LED_MODEM_BLINK_PID="${TMPDIR:-/tmp}/xfree-modem-cycle-led.pid"
HARDWARE_LED_BG_TASK_BLINK_PID="${TMPDIR:-/tmp}/xfree-background-task-led.pid"

hardware_led_sleep_half() {
    sleep 0.5 2>/dev/null || sleep 1
}

hardware_led_modem_cycle_blink_available() {
    [ -d "/sys/class/leds/$HARDWARE_LED_MODEM_BLINK_A" ] && \
        [ -d "/sys/class/leds/$HARDWARE_LED_MODEM_BLINK_B" ]
}

hardware_led_modem_cycle_blink_loop() {
    while true; do
        hardware_led_on "$HARDWARE_LED_MODEM_BLINK_A" 2>/dev/null || true
        hardware_led_off "$HARDWARE_LED_MODEM_BLINK_B" 2>/dev/null || true
        hardware_led_sleep_half
        hardware_led_off "$HARDWARE_LED_MODEM_BLINK_A" 2>/dev/null || true
        hardware_led_on "$HARDWARE_LED_MODEM_BLINK_B" 2>/dev/null || true
        hardware_led_sleep_half
    done
}

hardware_led_modem_cycle_blink_start() {
    hardware_led_modem_cycle_blink_available || return 1
    hardware_led_modem_cycle_blink_stop 2>/dev/null || true
    hardware_led_capture_state "$HARDWARE_LED_MODEM_BLINK_A" || true
    hardware_led_capture_state "$HARDWARE_LED_MODEM_BLINK_B" || true
    ( hardware_led_modem_cycle_blink_loop ) &
    printf '%s\n' "$!" >"$HARDWARE_LED_MODEM_BLINK_PID"
    return 0
}

hardware_led_modem_cycle_blink_stop() {
    if [ -f "$HARDWARE_LED_MODEM_BLINK_PID" ]; then
        _pid="$(cat "$HARDWARE_LED_MODEM_BLINK_PID" 2>/dev/null || true)"
        case "$_pid" in
            ''|*[!0-9]*) ;;
            *)
                kill "$_pid" 2>/dev/null || true
                wait "$_pid" 2>/dev/null || true
                ;;
        esac
        rm -f "$HARDWARE_LED_MODEM_BLINK_PID" 2>/dev/null || true
    fi
    if command -v internet_status_led_modem_blink_teardown >/dev/null 2>&1; then
        internet_status_led_modem_blink_teardown
        return 0
    fi
    hardware_led_release "$HARDWARE_LED_MODEM_BLINK_A" 2>/dev/null || true
    hardware_led_release "$HARDWARE_LED_MODEM_BLINK_B" 2>/dev/null || true
    return 0
}

hardware_led_pair_pick_existing() {
    _list="$1"
    for _name in $_list; do
        [ -d "/sys/class/leds/$_name" ] || continue
        printf '%s\n' "$_name"
        return 0
    done
    return 1
}

_hardware_led_known_router_lib_init() {
    if [ -n "${_HARDWARE_LED_KNOWN_ROUTER_LIB:-}" ]; then
        return 0
    fi
    _root="${XFREE_TOOLBOX_ROOT:-}"
    if [ -z "$_root" ]; then
        _here="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
        _root="$(CDPATH= cd -- "$_here/../.." && pwd -P)"
    fi
    _dir="$_root/system/hardware"
    _lib="$_dir/lib-known-router.sh"
    [ -f "$_lib" ] || return 1
    _HARDWARE_LED_KNOWN_ROUTER_LIB="$_lib"
    _HARDWARE_LED_KNOWN_ROUTER_DIR="$_dir"
    return 0
}

_hardware_led_bg_task_candidates_from_db() {
    _which="$1"
    _hardware_led_known_router_lib_init || return 1
    HARDWARE_KNOWN_ROUTER_DIR="$_HARDWARE_LED_KNOWN_ROUTER_DIR"
    # shellcheck source=system/hardware/lib-known-router.sh
    . "$_HARDWARE_LED_KNOWN_ROUTER_LIB"
    case "$_which" in
        a) hardware_known_router_bg_led_candidates_a 2>/dev/null || return 1 ;;
        b) hardware_known_router_bg_led_candidates_b 2>/dev/null || return 1 ;;
        *) return 1 ;;
    esac
}

hardware_led_bg_task_candidates_wan() {
    _candidates="$(_hardware_led_bg_task_candidates_from_db a 2>/dev/null || true)"
    if [ -n "$_candidates" ]; then
        # shellcheck disable=SC2086
        for _n in $_candidates; do
            printf '%s\n' "$_n"
        done
        return 0
    fi
    cat <<'EOF'
blue:wan
blue:wan-online
white:wan
white:wan-online
white:internet
white:net
EOF
}

hardware_led_bg_task_candidates_wps() {
    _candidates="$(_hardware_led_bg_task_candidates_from_db b 2>/dev/null || true)"
    if [ -n "$_candidates" ]; then
        # shellcheck disable=SC2086
        for _n in $_candidates; do
            printf '%s\n' "$_n"
        done
        return 0
    fi
    cat <<'EOF'
red:wps
white:wps
EOF
}

hardware_led_bg_task_pair_resolve() {
    _wan="$(hardware_led_pair_pick_existing "$(hardware_led_bg_task_candidates_wan)")" || return 1
    _wps="$(hardware_led_pair_pick_existing "$(hardware_led_bg_task_candidates_wps)")" || return 1
    printf '%s\t%s\n' "$_wan" "$_wps"
    return 0
}

hardware_led_pair_blink_loop() {
    _a="$1"
    _b="$2"
    while true; do
        hardware_led_on "$_a" 2>/dev/null || true
        hardware_led_off "$_b" 2>/dev/null || true
        hardware_led_sleep_half
        hardware_led_off "$_a" 2>/dev/null || true
        hardware_led_on "$_b" 2>/dev/null || true
        hardware_led_sleep_half
    done
}

hardware_led_bg_task_blink_available() {
    _pair="$(hardware_led_bg_task_pair_resolve 2>/dev/null || true)"
    [ -n "$_pair" ]
}

hardware_led_bg_task_blink_start() {
    _pair="$(hardware_led_bg_task_pair_resolve 2>/dev/null || true)"
    [ -n "$_pair" ] || return 1
    _wan="${_pair%%	*}"
    _wps="${_pair#*	}"
    [ -n "$_wan" ] || return 1
    [ -n "$_wps" ] || return 1

    hardware_led_bg_task_blink_stop 2>/dev/null || true
    hardware_led_capture_state "$_wan" || true
    hardware_led_capture_state "$_wps" || true

    ( hardware_led_pair_blink_loop "$_wan" "$_wps" ) &
    printf '%s\n' "$!" >"$HARDWARE_LED_BG_TASK_BLINK_PID"
    return 0
}

hardware_led_bg_task_blink_stop() {
    if [ -f "$HARDWARE_LED_BG_TASK_BLINK_PID" ]; then
        _pid="$(cat "$HARDWARE_LED_BG_TASK_BLINK_PID" 2>/dev/null || true)"
        case "$_pid" in
            ''|*[!0-9]*) ;;
            *)
                kill "$_pid" 2>/dev/null || true
                wait "$_pid" 2>/dev/null || true
                ;;
        esac
        rm -f "$HARDWARE_LED_BG_TASK_BLINK_PID" 2>/dev/null || true
    fi

    _pair="$(hardware_led_bg_task_pair_resolve 2>/dev/null || true)"
    [ -n "$_pair" ] || return 0
    _wan="${_pair%%	*}"
    _wps="${_pair#*	}"
    [ -n "$_wan" ] && hardware_led_release "$_wan" 2>/dev/null || true
    [ -n "$_wps" ] && hardware_led_release "$_wps" 2>/dev/null || true
    return 0
}
