#!/bin/sh
# shellcheck shell=sh
# Единый контракт определения и фиксации роли узла (master | satellite).
# Приоритет: явный конфиг ${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/node-role.env,
# иначе детерминированное автоопределение по признакам (dhcp.lan.ignore=1 или default route через br-lan).

node_role_state_file() {
  printf '%s/node-role.env\n' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

node_role_detect_auto() {
  _nr_dhcp_ign="$(uci -q get dhcp.lan.ignore 2>/dev/null || echo 0)"
  if [ "$_nr_dhcp_ign" = "1" ]; then
    printf 'satellite\n'
    return 0
  fi

  _nr_def_routes="$(ip route show default 2>/dev/null || true)"
  if printf '%s\n' "$_nr_def_routes" | grep -qE '^default .* dev br-lan( |$)'; then
    if ! uci -q get network.wan >/dev/null 2>&1; then
      printf 'satellite\n'
      return 0
    fi
  fi

  _nr_lan_gw="$(uci -q get network.lan.gateway 2>/dev/null || true)"
  if [ -n "$_nr_lan_gw" ] && [ -z "$_nr_def_routes" ]; then
    printf 'satellite\n'
    return 0
  fi

  printf 'master\n'
}

node_role_get() {
  _nr_file="$(node_role_state_file)"
  if [ -f "$_nr_file" ]; then
    _nr_val="$(sed -n 's/^NODE_ROLE=//p' "$_nr_file" 2>/dev/null | tail -n 1 | tr -d "\"' \r\n" || true)"
    case "$_nr_val" in
      master|satellite)
        printf '%s\n' "$_nr_val"
        return 0
        ;;
    esac
  fi

  node_role_detect_auto
}

node_role_is_satellite() {
  [ "$(node_role_get)" = "satellite" ]
}

node_role_set() {
  _nr_new="${1:-}"
  case "$_nr_new" in
    master|satellite) ;;
    *)
      echo "[-] node_role_set: ожидается master или satellite, получено: $_nr_new" >&2
      return 1
      ;;
  esac

  _nr_file="$(node_role_state_file)"
  mkdir -p "$(dirname "$_nr_file")" 2>/dev/null || return 1
  {
    printf '# xfree-toolbox node role (master | satellite)\n'
    printf 'NODE_ROLE=%s\n' "$_nr_new"
  } >"$_nr_file"
}
