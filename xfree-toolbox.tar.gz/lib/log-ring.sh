#!/bin/sh
# shellcheck shell=sh
# Append a line to a log file and keep only the last N lines (ring buffer).

LOG_RING_LIB_SOURCED="${LOG_RING_LIB_SOURCED:-}"
[ -n "$LOG_RING_LIB_SOURCED" ] && return 0
LOG_RING_LIB_SOURCED=1

log_ring_default_max() {
    case "${LOG_RING_MAX_LINES:-100}" in
        ''|*[!0-9]*) printf '100\n' ;;
        0) printf '100\n' ;;
        *) printf '%s\n' "${LOG_RING_MAX_LINES:-100}" ;;
    esac
}

# log_ring_append <file> <line> [max_lines]
log_ring_append() {
    _file="$1"
    _line="$2"
    _max="${3:-$(log_ring_default_max)}"
    case "$_max" in
        ''|*[!0-9]*) _max="$(log_ring_default_max)" ;;
    esac
    [ "$_max" -ge 1 ] 2>/dev/null || _max=100

    [ -n "$_file" ] || return 0
    mkdir -p "$(dirname -- "$_file")" 2>/dev/null || true
    printf '%s\n' "$_line" >>"$_file" 2>/dev/null || return 0

    _lines="$(wc -l <"$_file" 2>/dev/null | tr -d ' ')"
    case "$_lines" in
        ''|*[!0-9]*) return 0 ;;
    esac
    [ "$_lines" -gt "$_max" ] 2>/dev/null || return 0

    _tmp="${_file}.ring.$$"
    if tail -n "$_max" "$_file" >"$_tmp" 2>/dev/null; then
        mv -f "$_tmp" "$_file" 2>/dev/null || rm -f "$_tmp" 2>/dev/null || true
    else
        rm -f "$_tmp" 2>/dev/null || true
    fi
    return 0
}
