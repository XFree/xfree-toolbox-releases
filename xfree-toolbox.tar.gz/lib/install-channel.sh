#!/bin/sh
# shellcheck shell=sh
# Unified install/update channel: apk (OpenWrt 25+) vs tar.
# Sets XFREE_CHANNEL_REASON on resolve.

_xfree_install_channel_lib_dir() {
  if [ -n "${ROOT_DIR:-}" ] && [ -f "${ROOT_DIR}/lib/owrt-release.sh" ]; then
    printf '%s\n' "${ROOT_DIR}/lib"
    return 0
  fi
  CDPATH= cd -- "$(dirname -- "$0")" && pwd -P
}

_xfree_install_channel_owrt_lib="$(_xfree_install_channel_lib_dir)/owrt-release.sh"
if [ -f "$_xfree_install_channel_owrt_lib" ]; then
  # shellcheck disable=SC1090
  . "$_xfree_install_channel_owrt_lib"
fi

# Prints OpenWrt version line for check/update UI (best-effort).
xfree_print_openwrt_version_line() {
  if command -v owrt_release_load >/dev/null 2>&1 && owrt_release_load; then
    printf '[*] OpenWrt         : %s %s (major=%s)\n' \
      "${OWRT_DISTRIB_ID:-OpenWrt}" "${OWRT_DISTRIB_RELEASE:-?}" "${OWRT_RELEASE_MAJOR:-?}"
    return 0
  fi
  printf '[*] OpenWrt         : <unknown>\n'
}

# Prints: apk | tar
# Env: USE_TAR=1, XFREE_FORCE_CHANNEL=apk|tar (optional overrides).
# Priority: force → apk package installed → OS version (25+ → apk) → tar.
xfree_resolve_update_channel() {
  _force="${XFREE_FORCE_CHANNEL:-}"
  if [ -z "$_force" ] && [ "${USE_TAR:-0}" = "1" ]; then
    _force=tar
  fi
  if [ -n "$_force" ]; then
    XFREE_CHANNEL_REASON="forced: $_force"
    printf '%s\n' "$_force"
    return 0
  fi

  if command -v owrt_apk_package_installed >/dev/null 2>&1; then
    if owrt_apk_package_installed 2>/dev/null; then
      XFREE_CHANNEL_REASON="apk package installed"
      printf '%s\n' apk
      return 0
    fi
  elif command -v apk >/dev/null 2>&1; then
    _pkg="${XFREE_APK_PACKAGE_NAME:-xfree-toolbox}"
    if apk info -e "$_pkg" >/dev/null 2>&1; then
      XFREE_CHANNEL_REASON="apk package installed"
      printf '%s\n' apk
      return 0
    fi
  fi

  _rec=unknown
  if command -v owrt_install_channel_recommended >/dev/null 2>&1; then
    _rec="$(owrt_install_channel_recommended)"
  fi

  case "$_rec" in
    apk)
      if command -v apk >/dev/null 2>&1; then
        XFREE_CHANNEL_REASON="OpenWrt 25+ recommended"
        printf '%s\n' apk
        return 0
      fi
      XFREE_CHANNEL_REASON="OpenWrt 25+ but apk command missing"
      printf '%s\n' tar
      return 0
      ;;
    tar)
      XFREE_CHANNEL_REASON="OpenWrt ≤24"
      printf '%s\n' tar
      return 0
      ;;
    *)
      if command -v apk >/dev/null 2>&1; then
        XFREE_CHANNEL_REASON="unknown OpenWrt version, apk present"
        printf '%s\n' apk
        return 0
      fi
      XFREE_CHANNEL_REASON="unknown OpenWrt version, no apk"
      printf '%s\n' tar
      return 0
      ;;
  esac
}

# Parse toolbox version from VERSION (0.1.0+789) or apk (0.1.0-r789 / xfree-toolbox-0.1.0-r789 …).
# Sets XFREE_TB_VER_MAJOR/MINOR/PATCH/BUILD. Same build number: 0.1.0+N == 0.1.0-rN.
xfree_toolbox_version_parse() {
  _in="${1:-}"
  XFREE_TB_VER_MAJOR=""
  XFREE_TB_VER_MINOR=""
  XFREE_TB_VER_PATCH=""
  XFREE_TB_VER_BUILD=""
  _in="$(printf '%s' "$_in" | tr -d '\r' | awk '{print $1; exit}')"
  [ -n "$_in" ] || return 1
  _semver="$(printf '%s' "$_in" | sed -n 's/.*\([0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\).*/\1/p')"
  [ -n "$_semver" ] || return 1
  XFREE_TB_VER_MAJOR="${_semver%%.*}"
  _rest="${_semver#*.}"
  XFREE_TB_VER_MINOR="${_rest%%.*}"
  XFREE_TB_VER_PATCH="${_rest#*.}"
  _build="$(printf '%s' "$_in" | sed -n 's/.*+\([0-9][0-9]*\).*/\1/p')"
  if [ -z "$_build" ]; then
    _build="$(printf '%s' "$_in" | sed -n 's/.*-r\([0-9][0-9]*\).*/\1/p')"
  fi
  XFREE_TB_VER_BUILD="${_build:-0}"
  return 0
}

# stdout: -1 (a<b), 0 (equal), 1 (a>b). Unparsable a → -1; unparsable b → 1.
xfree_toolbox_version_cmp() {
  _a_maj=0 _a_min=0 _a_pat=0 _a_bld=0
  _b_maj=0 _b_min=0 _b_pat=0 _b_bld=0
  if xfree_toolbox_version_parse "$1"; then
    _a_maj="$XFREE_TB_VER_MAJOR"
    _a_min="$XFREE_TB_VER_MINOR"
    _a_pat="$XFREE_TB_VER_PATCH"
    _a_bld="$XFREE_TB_VER_BUILD"
  else
    printf '%s\n' '-1'
    return 0
  fi
  if xfree_toolbox_version_parse "$2"; then
    _b_maj="$XFREE_TB_VER_MAJOR"
    _b_min="$XFREE_TB_VER_MINOR"
    _b_pat="$XFREE_TB_VER_PATCH"
    _b_bld="$XFREE_TB_VER_BUILD"
  else
    printf '%s\n' '1'
    return 0
  fi
  if [ "$_a_maj" -lt "$_b_maj" ]; then printf '%s\n' '-1'; return 0; fi
  if [ "$_a_maj" -gt "$_b_maj" ]; then printf '%s\n' '1'; return 0; fi
  if [ "$_a_min" -lt "$_b_min" ]; then printf '%s\n' '-1'; return 0; fi
  if [ "$_a_min" -gt "$_b_min" ]; then printf '%s\n' '1'; return 0; fi
  if [ "$_a_pat" -lt "$_b_pat" ]; then printf '%s\n' '-1'; return 0; fi
  if [ "$_a_pat" -gt "$_b_pat" ]; then printf '%s\n' '1'; return 0; fi
  if [ "$_a_bld" -lt "$_b_bld" ]; then printf '%s\n' '-1'; return 0; fi
  if [ "$_a_bld" -gt "$_b_bld" ]; then printf '%s\n' '1'; return 0; fi
  printf '%s\n' '0'
}

xfree_toolbox_version_ge() {
  _cmp="$(xfree_toolbox_version_cmp "$1" "$2")"
  [ "$_cmp" = "0" ] || [ "$_cmp" = "1" ]
}

xfree_toolbox_version_from_tree() {
  _explicit="${1:-}"
  if [ -n "$_explicit" ] && [ -f "$_explicit/VERSION" ]; then
    head -n1 "$_explicit/VERSION" | tr -d '\r\n\t '
    return 0
  fi
  for _td in \
    "${XFREE_TOOLBOX_TARGET_DIR:-}" \
    "${TARGET_DIR:-}" \
    "${XFREE_TOOLBOX_ROOT:-}" \
    "${ROOT_DIR:-}" \
    /root/xfree-toolbox \
    /root/xfree-utils
  do
    [ -n "$_td" ] || continue
    if [ -f "$_td/VERSION" ]; then
      head -n1 "$_td/VERSION" | tr -d '\r\n\t '
      return 0
    fi
  done
  printf '%s' ""
}

# Deploy stamp for luci-app (file-deploy does not update apk world).
xfree_luci_app_version_from_stamp() {
  _sf="${XFREE_LUCI_APP_VERSION_FILE:-/etc/xfree-toolbox/luci-app.version}"
  if [ -f "$_sf" ]; then
    head -n1 "$_sf" | tr -d '\r\n\t '
    return 0
  fi
  printf '%s' ""
}

# VERSION «X.Y.Z+B» / «X.Y.Z» → stamp/apk «X.Y.Z-rB» (как deploy-luci / release-pipeline).
xfree_version_to_luci_stamp() {
  _line="$(printf '%s' "${1:-}" | tr -d '\r\n\t ')"
  [ -n "$_line" ] || return 1
  case "$_line" in
  *-r[0-9]*)
    printf '%s\n' "$_line"
    return 0
    ;;
  *+*)
    printf '%s\n' "$_line" | sed -nE 's/^([0-9]+\.[0-9]+\.[0-9]+)\+([0-9]+)$/\1-r\2/p'
    ;;
  *)
    printf '%s\n' "$_line" | sed -nE 's/^([0-9]+\.[0-9]+\.[0-9]+)$/\1-r0/p'
    ;;
  esac
}

# True if string parses as toolbox/luci semver (+N or -rN).
xfree_toolbox_version_parsable() {
  xfree_toolbox_version_parse "${1:-}" >/dev/null 2>&1
}

# Local version for feed compare: max(tree/stamp, installed apk line with real semver).
# xfree-toolbox → VERSION file; luci-app → luci-app.version stamp (not toolbox VERSION).
xfree_apk_local_version_for_pkg() {
  _pkg="${1:-}"
  _inst="${2:-}"
  _tree=""
  _main="${XFREE_APK_PACKAGE_NAME:-xfree-toolbox}"
  _luci="luci-app-${_main}"
  case "$_pkg" in
  "$_main")
    _tree="$(xfree_toolbox_version_from_tree "${3:-}")"
    ;;
  "$_luci")
    _tree="$(xfree_luci_app_version_from_stamp)"
    ;;
  esac
  # apk info -e may print bare name without -rN — ignore for max().
  if [ -n "$_inst" ] && ! xfree_toolbox_version_parsable "$_inst"; then
    _inst=""
  fi
  if [ -n "$_tree" ] && [ -n "$_inst" ]; then
    if xfree_toolbox_version_ge "$_tree" "$_inst"; then
      printf '%s\n' "$_tree"
    else
      printf '%s\n' "$_inst"
    fi
    return 0
  fi
  if [ -n "$_tree" ]; then
    printf '%s\n' "$_tree"
    return 0
  fi
  printf '%s\n' "$_inst"
}

# If local (tree and/or installed apk) is already >= feed line, do not apk add/upgrade.
xfree_apk_skip_if_local_newer_than_feed() {
  _feed_line="${1:-}"
  _pkg="${2:-${XFREE_APK_PACKAGE_NAME:-xfree-toolbox}}"
  _inst="${3:-}"
  [ -n "$_feed_line" ] || return 1
  _local_ver="$(xfree_apk_local_version_for_pkg "$_pkg" "$_inst")"
  [ -n "$_local_ver" ] || return 1
  xfree_toolbox_version_ge "$_local_ver" "$_feed_line"
}

# Backward-compatible alias (tree-only callers).
xfree_apk_skip_if_tree_newer_than_feed() {
  xfree_apk_skip_if_local_newer_than_feed "${1:-}" "${XFREE_APK_PACKAGE_NAME:-xfree-toolbox}" ""
}

# First apk list line for exact package name (not luci-app-xfree-toolbox when pkg=xfree-toolbox).
xfree_apk_first_pkg_line() {
  _pkg="${1:-}"
  [ -n "$_pkg" ] || return 0
  awk -v pkg="$_pkg" '
    index($0, pkg "-") == 1 {
      c = substr($0, length(pkg) + 2, 1)
      if (c ~ /[0-9]/) { print; exit }
    }
  '
}

# After `apk update`. Sets:
#   XFREE_APK_CHECK_INSTALLED  — apk version or empty
#   XFREE_APK_CHECK_AVAILABLE  — first matching feed/upgrade line or empty
#   XFREE_APK_CHECK_ACTION     — none | upgrade | add
# add = package not in apk world, but feed has it (tar-only on OpenWrt 25+).
# Never trust apk list -u alone: OpenWrt apk may list an older feed line as "upgradable".
xfree_apk_probe_feed_update() {
  _pkg="${1:-${XFREE_APK_PACKAGE_NAME:-xfree-toolbox}}"
  XFREE_APK_CHECK_INSTALLED=""
  XFREE_APK_CHECK_AVAILABLE=""
  XFREE_APK_CHECK_ACTION=none

  command -v apk >/dev/null 2>&1 || return 1

  if apk info -e "$_pkg" >/dev/null 2>&1; then
    # Prefer list -I (has -rN). info -e often prints bare name without version.
    XFREE_APK_CHECK_INSTALLED="$(apk list -I 2>/dev/null | xfree_apk_first_pkg_line "$_pkg" || true)"
    if [ -z "$XFREE_APK_CHECK_INSTALLED" ]; then
      XFREE_APK_CHECK_INSTALLED="$(apk info -e "$_pkg" 2>/dev/null | sed -n '1p')"
    fi
    [ -n "$XFREE_APK_CHECK_INSTALLED" ] || XFREE_APK_CHECK_INSTALLED="$_pkg"
    XFREE_APK_CHECK_AVAILABLE="$(apk list -u 2>/dev/null | xfree_apk_first_pkg_line "$_pkg" || true)"
    if [ -n "$XFREE_APK_CHECK_AVAILABLE" ]; then
      XFREE_APK_CHECK_ACTION=upgrade
    fi
  else
    XFREE_APK_CHECK_AVAILABLE="$(apk list 2>/dev/null | xfree_apk_first_pkg_line "$_pkg" || true)"
    if [ -n "$XFREE_APK_CHECK_AVAILABLE" ]; then
      XFREE_APK_CHECK_ACTION=add
    fi
  fi

  case "${XFREE_APK_CHECK_ACTION:-none}" in
  add | upgrade)
    if xfree_apk_skip_if_local_newer_than_feed \
      "$XFREE_APK_CHECK_AVAILABLE" "$_pkg" "${XFREE_APK_CHECK_INSTALLED:-}"; then
      XFREE_APK_CHECK_ACTION=none
      # Do not surface an older feed line as "Новая версия" in LuCI/CLI.
      XFREE_APK_CHECK_AVAILABLE=""
    fi
    ;;
  esac

  # Defense: even if apk did not mark -u, never keep AVAILABLE older than local.
  if [ -n "${XFREE_APK_CHECK_AVAILABLE:-}" ] \
    && xfree_apk_skip_if_local_newer_than_feed \
      "$XFREE_APK_CHECK_AVAILABLE" "$_pkg" "${XFREE_APK_CHECK_INSTALLED:-}"; then
    XFREE_APK_CHECK_ACTION=none
    XFREE_APK_CHECK_AVAILABLE=""
  fi
  return 0
}

# Print [*] lines for --check-only / menu. Caller already ran apk update.
xfree_apk_print_feed_check() {
  _pkg="${1:-${XFREE_APK_PACKAGE_NAME:-xfree-toolbox}}"
  xfree_apk_probe_feed_update "$_pkg" || return 1
  _inst="${XFREE_APK_CHECK_INSTALLED:-}"
  [ -n "$_inst" ] || _inst="<не установлен>"
  printf '[*] Package         : %s\n' "$_pkg"
  printf '[*] Installed       : %s\n' "$_inst"
  printf '[*] Available       : %s\n' "${XFREE_APK_CHECK_AVAILABLE:-<none>}"
  printf '[*] Action          : %s\n' "${XFREE_APK_CHECK_ACTION:-none}"
  case "${XFREE_APK_CHECK_ACTION:-none}" in
    upgrade|add) printf '[*] Upgradable      : yes\n' ;;
    *) printf '[*] Upgradable      : no\n' ;;
  esac
  return 0
}
