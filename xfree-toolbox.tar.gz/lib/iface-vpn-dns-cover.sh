#!/bin/sh
# shellcheck shell=sh
# VPN FQDN ↔ DNS-redirect cover helpers (generation-time skip, not list mutation).
#
# Pipeline: fqdn.d minus interfaces/*/fqdn.exclude.d, then every rule uses that
# list only (nftset, tunnel server=, and the WAN-DNS skip). Chicken-egg names
# stay on WAN DNS. A covered name equals a remaining iface FQDN or is its subdomain.
# Parent WAN-DNS rules stay if VPN listed a more specific child.
# Port-53 fwmark is not applied to an IP that is also a dns-routing DNS_TARGET.
# Tunnel server= uses DNS_VALUE from the iface (the address written in the
# tunnel config), bound as server=/name/DNS@VPN_DEV, and only for names that
# remain after exclude (the same names that get the nftset mark). A public
# resolver such as 1.1.1.1 is a valid tunnel server= when it is that DNS_VALUE.
# It is not fwmarked and does not enter prefix sets: the same address on the
# main table stays the WAN path. Proton 10.2.0.1 is marked because it is only
# reachable inside the tunnel.

iface_vpn_dns_normalize_fqdn() {
    printf '%s\n' "$1" | awk '{
        line=$0
        sub(/\r$/, "", line)
        sub(/[[:space:]]*#.*/, "", line)
        gsub(/^[ \t]+|[ \t]+$/, "", line)
        if (line == "") next
        if (line ~ /^;/) next
        if (line ~ /^\[/) next
        split(line, a, /[ \t]+/)
        d=a[1]
        gsub(/^\*\./, "", d)
        gsub(/^\./, "", d)
        d=tolower(d)
        if (d != "") print d
    }'
}

# Union of FQDNs in interfaces/*/fqdn.exclude.d (chicken-egg: Proton, WARP API).
iface_vpn_dns_collect_exclude_fqdns() {
    ifaces_dir="${1:-}"
    [ -d "$ifaces_dir" ] || return 0

    find "$ifaces_dir" -type f -name '*.lst' 2>/dev/null | grep '/fqdn\.exclude\.d/' | sort | while IFS= read -r lst; do
        [ -f "$lst" ] || continue
        while IFS= read -r raw_line || [ -n "$raw_line" ]; do
            iface_vpn_dns_normalize_fqdn "$raw_line"
        done < "$lst"
    done | sort -u
}

# Return 0 if domain equals an exclude FQDN or is a subdomain of one (proton.me → api.proton.me).
iface_vpn_dns_domain_excluded() {
    domain="$1"
    excludes_file="$2"
    [ -n "${domain:-}" ] || return 1
    [ -s "$excludes_file" ] || return 1
    domain="$(printf '%s' "$domain" | tr 'A-Z' 'a-z')"

    while IFS= read -r v || [ -n "$v" ]; do
        [ -n "$v" ] || continue
        if [ "$domain" = "$v" ]; then
            return 0
        fi
        case "$domain" in
            *."$v")
                return 0
                ;;
        esac
    done < "$excludes_file"
    return 1
}

# Print lines from src that are not excluded (exact or subdomain). Empty src → empty dest.
iface_vpn_dns_filter_excluded_file() {
    src="$1"
    excludes_file="$2"
    dest="$3"
    [ -n "${dest:-}" ] || return 1
    : > "$dest"
    [ -s "$src" ] || return 0
    while IFS= read -r domain || [ -n "$domain" ]; do
        [ -n "$domain" ] || continue
        if iface_vpn_dns_domain_excluded "$domain" "$excludes_file"; then
            continue
        fi
        printf '%s\n' "$domain"
    done < "$src" > "$dest"
}

iface_vpn_dns_collect_profile_fqdns() {
    profile_dir="${1:-}"
    ifaces_dir="${profile_dir%/}/iface-routing/interfaces"
    [ -d "$ifaces_dir" ] || return 0

    ex_tmp="$(mktemp "${TMPDIR:-/tmp}/iface-vpn-dns-ex.XXXXXX")" || return 1
    iface_vpn_dns_collect_exclude_fqdns "$ifaces_dir" > "$ex_tmp" || true

    find "$ifaces_dir" -type f -name '*.lst' 2>/dev/null | grep '/fqdn\.d/' | grep -v '/fqdn.exclude.d/' | sort | while IFS= read -r lst; do
        [ -f "$lst" ] || continue
        while IFS= read -r raw_line || [ -n "$raw_line" ]; do
            d="$(iface_vpn_dns_normalize_fqdn "$raw_line")"
            [ -n "$d" ] || continue
            if iface_vpn_dns_domain_excluded "$d" "$ex_tmp"; then
                continue
            fi
            printf '%s\n' "$d"
        done < "$lst"
    done | sort -u
    rm -f "$ex_tmp"
}

# Return 0 if domain equals a VPN FQDN or is a subdomain of one.
iface_vpn_dns_domain_covered() {
    domain="$1"
    fqdns_file="$2"
    [ -n "${domain:-}" ] || return 1
    [ -s "$fqdns_file" ] || return 1
    domain="$(printf '%s' "$domain" | tr 'A-Z' 'a-z')"

    while IFS= read -r v || [ -n "$v" ]; do
        [ -n "$v" ] || continue
        if [ "$domain" = "$v" ]; then
            return 0
        fi
        case "$domain" in
            *."$v")
                return 0
                ;;
        esac
    done < "$fqdns_file"
    return 1
}

iface_vpn_dns_is_loopback_ip() {
    ip="$1"
    case "$ip" in
        ''|0.0.0.0|::|::1|[::1])
            return 0
            ;;
        127.*)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# Cloudflare public DNS. Used as plain WAN DNS; not a tunnel destination.
iface_vpn_dns_is_protected_public_dns() {
    ip="$1"
    [ -n "${ip:-}" ] || return 1
    ip="$(printf '%s' "$ip" | tr 'A-Z' 'a-z')"
    ip="${ip%%/*}"
    case "$ip" in
        \[*) ip="${ip#\[}"; ip="${ip%%\]*}" ;;
    esac
    case "$ip" in
        1.1.1.1|1.0.0.1|2606:4700:4700::1111|2606:4700:4700::1001)
            return 0
            ;;
    esac
    return 1
}

# Print IPs from a DNS CSV.
# purpose=resolver: skip loopback only (public DNS may be server=@VPN_DEV).
# purpose=mark (default): also skip Cloudflare public resolvers.
iface_vpn_dns_ips_from_csv() {
    csv="${1:-}"
    purpose="${2:-mark}"
    [ -n "$csv" ] || return 0
    printf '%s\n' "$csv" | tr ',' '\n' | while IFS= read -r token; do
        ip="$(printf '%s' "$token" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//; s/^\[//; s/\]$//')"
        [ -n "$ip" ] || continue
        iface_vpn_dns_is_loopback_ip "$ip" && continue
        if [ "$purpose" != "resolver" ] && iface_vpn_dns_is_protected_public_dns "$ip"; then
            continue
        fi
        printf '%s\n' "$ip"
    done
}

# First IPv4, else first remaining IP (IPv6). Empty if none.
iface_vpn_dns_preferred_resolver() {
    csv="${1:-}"
    iface_vpn_dns_ips_from_csv "$csv" resolver | awk '
        {
            if ($0 ~ /:/) {
                if (v6 == "") v6=$0
            } else if ($0 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) {
                if (v4 == "") v4=$0
            }
        }
        END {
            if (v4 != "") print v4
            else if (v6 != "") print v6
        }
    '
}

iface_vpn_dns_meta_key() {
    file="$1"
    key="$2"
    [ -f "$file" ] || return 0
    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            gsub(/^"|"$/, "", val)
            print val
            exit
        }
    ' "$file"
}

# DNS written on the interface. ORIGINAL_DNS_VALUE is not substituted.
iface_vpn_dns_meta_dns_csv() {
    meta_file="${1:-}"
    [ -f "$meta_file" ] || return 0
    iface_vpn_dns_meta_key "$meta_file" DNS_VALUE
}

# Non-loopback IPs from dns-routing DNS_TARGET (plain WAN resolvers such as 1.1.1.1#53).
iface_vpn_dns_collect_wan_target_ips() {
    dns_root="${1:-}"
    [ -d "$dns_root" ] || return 0

    find "$dns_root" -type f -name 'dns.conf' 2>/dev/null | sort | while IFS= read -r conf; do
        [ -f "$conf" ] || continue
        awk -F= '
            $1 ~ /^[[:space:]]*DNS_TARGET[[:space:]]*$/ {
                val = $2
                for (i = 3; i <= NF; i++) val = val "=" $i
                sub(/\r$/, "", val)
                gsub(/[[:space:]]/, "", val)
                gsub(/^[\047"]|[\047"]$/, "", val)
                if (val ~ /^\[/) {
                    sub(/^\[/, "", val)
                    sub(/\].*$/, "", val)
                } else {
                    sub(/#.*$/, "", val)
                }
                if (val != "") print val
            }
        ' "$conf"
    done | while IFS= read -r ip; do
        [ -n "$ip" ] || continue
        iface_vpn_dns_is_loopback_ip "$ip" && continue
        printf '%s\n' "$ip"
    done | sort -u
}

iface_vpn_dns_nft_output_marks() {
    mark_hex="$1"
    csv="$2"
    skip_ips="${3:-}"
    [ -n "${mark_hex:-}" ] || return 0
    iface_vpn_dns_ips_from_csv "$csv" | while IFS= read -r ip; do
        [ -n "$ip" ] || continue
        if [ -n "$skip_ips" ] && [ -f "$skip_ips" ] && grep -Fxq "$ip" "$skip_ips"; then
            continue
        fi
        case "$ip" in
            *:*)
                printf '    ip6 daddr %s udp dport 53 meta mark set %s\n' "$ip" "$mark_hex"
                printf '    ip6 daddr %s tcp dport 53 meta mark set %s\n' "$ip" "$mark_hex"
                ;;
            *)
                printf '    ip daddr %s udp dport 53 meta mark set %s\n' "$ip" "$mark_hex"
                printf '    ip daddr %s tcp dport 53 meta mark set %s\n' "$ip" "$mark_hex"
                ;;
        esac
    done
}
