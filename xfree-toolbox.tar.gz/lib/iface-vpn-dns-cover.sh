#!/bin/sh
# shellcheck shell=sh
# VPN FQDN ↔ DNS-redirect cover helpers (generation-time skip, not list mutation).
#
# A dns-routing FQDN is covered when it equals an iface-routing FQDN or is a
# subdomain of one. Parent xbox-dns rules stay if VPN listed a more specific child.

iface_vpn_dns_normalize_fqdn() {
    printf '%s\n' "$1" | awk '{
        line=$0
        sub(/\r$/, "", line)
        sub(/[[:space:]]*#.*/, "", line)
        gsub(/^[ \t]+|[ \t]+$/, "", line)
        if (line == "") next
        if (line ~ /^;/) next
        if (line ~ /^\[/) next
        split(line, a, /[ \t]+/)
        d=a[1]
        gsub(/^\*\./, "", d)
        gsub(/^\./, "", d)
        d=tolower(d)
        if (d != "") print d
    }'
}

iface_vpn_dns_collect_profile_fqdns() {
    profile_dir="${1:-}"
    ifaces_dir="${profile_dir%/}/iface-routing/interfaces"
    [ -d "$ifaces_dir" ] || return 0

    # BusyBox find: filter fqdn.d via grep (portable vs -path).
    find "$ifaces_dir" -type f -name '*.lst' 2>/dev/null | grep '/fqdn\.d/' | sort | while IFS= read -r lst; do
        [ -f "$lst" ] || continue
        while IFS= read -r raw_line || [ -n "$raw_line" ]; do
            iface_vpn_dns_normalize_fqdn "$raw_line"
        done < "$lst"
    done | sort -u
}

# Return 0 if domain equals a VPN FQDN or is a subdomain of one.
iface_vpn_dns_domain_covered() {
    domain="$1"
    fqdns_file="$2"
    [ -n "${domain:-}" ] || return 1
    [ -s "$fqdns_file" ] || return 1
    domain="$(printf '%s' "$domain" | tr 'A-Z' 'a-z')"

    while IFS= read -r v || [ -n "$v" ]; do
        [ -n "$v" ] || continue
        if [ "$domain" = "$v" ]; then
            return 0
        fi
        case "$domain" in
            *."$v")
                return 0
                ;;
        esac
    done < "$fqdns_file"
    return 1
}

iface_vpn_dns_is_loopback_ip() {
    ip="$1"
    case "$ip" in
        ''|0.0.0.0|::|::1|[::1])
            return 0
            ;;
        127.*)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# Print non-loopback DNS IPs from a CSV (ORIGINAL_DNS_VALUE / DNS_VALUE).
iface_vpn_dns_ips_from_csv() {
    csv="${1:-}"
    [ -n "$csv" ] || return 0
    printf '%s\n' "$csv" | tr ',' '\n' | while IFS= read -r token; do
        ip="$(printf '%s' "$token" | sed 's/\r$//; s/^[[:space:]]*//; s/[[:space:]]*$//; s/^\[//; s/\]$//')"
        [ -n "$ip" ] || continue
        iface_vpn_dns_is_loopback_ip "$ip" && continue
        printf '%s\n' "$ip"
    done
}

# First IPv4, else first remaining IP (IPv6). Empty if none.
iface_vpn_dns_preferred_resolver() {
    csv="${1:-}"
    iface_vpn_dns_ips_from_csv "$csv" | awk '
        {
            if ($0 ~ /:/) {
                if (v6 == "") v6=$0
            } else if ($0 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) {
                if (v4 == "") v4=$0
            }
        }
        END {
            if (v4 != "") print v4
            else if (v6 != "") print v6
        }
    '
}

iface_vpn_dns_meta_key() {
    file="$1"
    key="$2"
    [ -f "$file" ] || return 0
    awk -F= -v key="$key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            gsub(/^"|"$/, "", val)
            print val
            exit
        }
    ' "$file"
}

# ORIGINAL_DNS_VALUE, then DNS_VALUE if that is not loopback-only.
iface_vpn_dns_meta_dns_csv() {
    meta_file="${1:-}"
    [ -f "$meta_file" ] || return 0
    original="$(iface_vpn_dns_meta_key "$meta_file" ORIGINAL_DNS_VALUE)"
    if [ -n "$(iface_vpn_dns_preferred_resolver "$original")" ]; then
        printf '%s\n' "$original"
        return 0
    fi
    fallback="$(iface_vpn_dns_meta_key "$meta_file" DNS_VALUE)"
    if [ -n "$(iface_vpn_dns_preferred_resolver "$fallback")" ]; then
        printf '%s\n' "$fallback"
    fi
}

iface_vpn_dns_nft_output_marks() {
    mark_hex="$1"
    csv="$2"
    [ -n "${mark_hex:-}" ] || return 0
    iface_vpn_dns_ips_from_csv "$csv" | while IFS= read -r ip; do
        [ -n "$ip" ] || continue
        case "$ip" in
            *:*)
                printf '    ip6 daddr %s udp dport 53 meta mark set %s\n' "$ip" "$mark_hex"
                printf '    ip6 daddr %s tcp dport 53 meta mark set %s\n' "$ip" "$mark_hex"
                ;;
            *)
                printf '    ip daddr %s udp dport 53 meta mark set %s\n' "$ip" "$mark_hex"
                printf '    ip daddr %s tcp dport 53 meta mark set %s\n' "$ip" "$mark_hex"
                ;;
        esac
    done
}
