#!/bin/sh
# shellcheck shell=sh
# Каталог логов toolbox: фоновые задачи (bg-task-run), state, мониторинг.
# Используется меню diagnostics и при необходимости другими разделами.

system_logs_bg_root() {
    printf '%s\n' "${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}"
}

system_logs_state_root() {
    printf '%s\n' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

system_logs_routing_monitor_log() {
    _ir="${XFREE_IFACE_ROUTING_ROOT:-$(system_logs_state_root)/iface-routing}"
    printf '%s/state/monitor/routing-check.log\n' "$_ir"
}

system_logs_dns_check_log() {
    printf '%s/system/dns-check.log\n' "$(system_logs_state_root)"
}

# Подсказка для пункта меню: размер и время изменения.
system_logs_entry_blurb() {
    _path="$1"
    _prefix="${2:-}"
    [ -f "$_path" ] || return 1
    _bytes="$(wc -c <"$_path" 2>/dev/null | tr -d ' ')"
    case "$_bytes" in
        ''|*[!0-9]*) _bytes=0 ;;
    esac
    _mtime="$(date -r "$_path" '+%m-%d %H:%M' 2>/dev/null || echo '?')"
    if [ "$_bytes" -ge 1048576 ]; then
        _sz="$((_bytes / 1048576))M"
    elif [ "$_bytes" -ge 1024 ]; then
        _sz="$((_bytes / 1024))K"
    else
        _sz="${_bytes}b"
    fi
    if [ -n "$_prefix" ]; then
        printf '%s · %s · %s' "$_prefix" "$_sz" "$_mtime"
    else
        printf '%s · %s' "$_sz" "$_mtime"
    fi
}

# Записать строку в каталог (ключ = порядковый номер среди существующих файлов).
# stdout: присвоенный key; return 1 если файла нет.
system_logs_catalog_add() {
    _catalog="$1"
    _path="$2"
    _live="${3:-0}"
    _title="$4"
    [ -f "$_path" ] || return 1
    _key=1
    if [ -s "$_catalog" ]; then
        _key="$(wc -l <"$_catalog" 2>/dev/null | tr -d ' ')"
        case "$_key" in
            ''|*[!0-9]*) _key=0 ;;
        esac
        _key=$((_key + 1))
    fi
    printf '%s\t%s\t%s\t%s\n' "$_key" "$_path" "$_live" "$_title" >>"$_catalog"
    printf '%s\n' "$_key"
    return 0
}

# Собрать каталог существующих логов в файл (перезаписывает).
# stdout: число пунктов в меню.
system_logs_build_catalog() {
    _catalog="${1:-}"
    [ -n "$_catalog" ] || return 1
    : >"$_catalog"
    _bg="$(system_logs_bg_root)"
    _state="$(system_logs_state_root)"

    if command -v bg_tasks_is_running >/dev/null 2>&1 && bg_tasks_is_running; then
        _log="${BG_TASK_LOG_FILE:-}"
        [ -n "$_log" ] && system_logs_catalog_add "$_catalog" "$_log" 1 \
            "► ${BG_TASK_NAME:-задача} (pid ${BG_TASK_PID:-?})" >/dev/null || true
    fi

    system_logs_catalog_add "$_catalog" \
        "$_state/system/iface-recovery-scheduler.log" 0 "Recovery planner" >/dev/null || true

    # Nightly cron auto-update (permanent log; bg-task-run --log сюда же).
    _auto_update_log="$_state/system/auto-update.log"
    if [ -f "$_auto_update_log" ]; then
        _skip_auto=0
        if command -v bg_tasks_is_running >/dev/null 2>&1 && bg_tasks_is_running; then
            [ "${BG_TASK_LOG_FILE:-}" = "$_auto_update_log" ] && _skip_auto=1
        fi
        if [ "$_skip_auto" = "0" ]; then
            system_logs_catalog_add "$_catalog" "$_auto_update_log" 0 "Автообновление" >/dev/null || true
        fi
    fi

    system_logs_catalog_add "$_catalog" \
        "$_state/system/usb-power-watch.log" 0 "Мониторинг uplink" >/dev/null || true

    system_logs_catalog_add "$_catalog" \
        "$(system_logs_routing_monitor_log)" 0 "Контроль маршрутизации" >/dev/null || true

    system_logs_catalog_add "$_catalog" \
        "$(system_logs_dns_check_log)" 0 "Диагностика DNS" >/dev/null || true

    system_logs_catalog_add "$_catalog" \
        "$_state/migration.log" 0 "Миграция state" >/dev/null || true

    if [ -d "$_bg" ]; then
        for _f in "$_bg"/*.log; do
            [ -f "$_f" ] || continue
            if command -v bg_tasks_is_running >/dev/null 2>&1 && bg_tasks_is_running; then
                [ "$_f" = "${BG_TASK_LOG_FILE:-}" ] && continue
            fi
            _base="$(basename "$_f" .log)"
            system_logs_catalog_add "$_catalog" "$_f" 0 "bg: $_base" >/dev/null || true
        done
    fi

    if [ -f "$_bg/meta.last" ]; then
        system_logs_catalog_add "$_catalog" "$_bg/meta.last" 0 \
            "Последняя bg-задача (meta)" >/dev/null || true
    fi

    if [ -s "$_catalog" ]; then
        wc -l <"$_catalog" | tr -d ' '
    else
        printf '0\n'
    fi
}

system_logs_catalog_lookup() {
    _catalog="$1"
    _choice="$2"
    awk -F'\t' -v want="$_choice" '$1 == want { print $2 "\t" $3 "\t" $4; exit }' "$_catalog" 2>/dev/null
}

# tail для textbox; большие файлы — последние N строк.
system_logs_prepare_view_file() {
    _src="$1"
    _dest="$2"
    _lines="${3:-400}"
    [ -f "$_src" ] || return 1
    {
        printf '=== %s ===\n\n' "$_src"
        tail -n "$_lines" "$_src" 2>/dev/null || cat "$_src" 2>/dev/null || true
    } >"$_dest"
}

system_logs_view_path() {
    _title="$1"
    _path="$2"
    _live="${3:-0}"
    _task_pid="${4:-}"

    [ -n "$_path" ] || return 1
    [ -f "$_path" ] || {
        ui_msgbox "$_title" "Файл не найден:\n$_path"
        return 0
    }

    if [ "$_live" = "1" ] && [ -n "$_task_pid" ] && kill -0 "$_task_pid" 2>/dev/null; then
        ui_bg_task_follow_log "$_title" "$_path" "$_task_pid"
        return 0
    fi

    _tmp="${UI_TMP_ROOT:-/tmp}/xfree-system-log-view.$$"
    system_logs_prepare_view_file "$_path" "$_tmp" 400
    ui_show_textbox "$_title" "$_tmp" 32 110
    rm -f "$_tmp" 2>/dev/null || true
    return 0
}
