#!/bin/sh
# shellcheck shell=sh
# Shared WAN6 (IPv6) policy state contract ($XFREE_STATE_ROOT/wan6-policy.env).
# Consumed by system/disable-wan-ipv6.sh, system/hardware/wan-uplink-guard.sh,
# iface-routing/lib/wan6-guard.sh, and zapret/apply.sh.
#
# Modes (XFREE_WAN6_MODE):
#   auto      - (default) analyze IPv6 support: if IPv6 is present -> selective, else -> off (no clutter)
#   off       - explicitly disable WAN6 on all interfaces and omit wan6 guard rules
#   selective - force WAN6 enabled: VPN IPv6 + allowlisted direct WAN6 (YouTube/Google), reject rest
#   full      - force WAN6 enabled: VPN IPv6 leak guard + all direct IPv6 allowed

WAN6_DEFAULT_ALLOW_DOMAINS="youtube.com googlevideo.com ytimg.com ggpht.com youtu.be youtubei.googleapis.com"

wan6_policy_file() {
    printf '%s/wan6-policy.env\n' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

wan6_policy_load() {
    XFREE_WAN6_MODE="${XFREE_WAN6_MODE:-auto}"
    XFREE_WAN6_ALLOW_DOMAINS="${XFREE_WAN6_ALLOW_DOMAINS:-$WAN6_DEFAULT_ALLOW_DOMAINS}"
    XFREE_ZAPRET_IPV6="${XFREE_ZAPRET_IPV6:-}"

    _pfile="$(wan6_policy_file)"
    if [ -f "$_pfile" ]; then
        # shellcheck disable=SC1090
        . "$_pfile"
    fi

    case "${XFREE_WAN6_MODE:-auto}" in
        auto|off|selective|full) ;;
        *) XFREE_WAN6_MODE="auto" ;;
    esac
    [ -n "${XFREE_WAN6_ALLOW_DOMAINS:-}" ] || XFREE_WAN6_ALLOW_DOMAINS="$WAN6_DEFAULT_ALLOW_DOMAINS"
}

wan6_policy_has_ipv6() {
    case "${WAN6_FORCE_IPV6_DETECT:-}" in
        1) return 0 ;;
        0) return 1 ;;
    esac
    if command -v ip >/dev/null 2>&1; then
        if ip -6 route show default 2>/dev/null | grep -q 'default'; then
            return 0
        fi
        # Check global IPv6 on non-loopback/non-bridge uplink/VPN interfaces
        if ip -6 addr show scope global 2>/dev/null | grep -q 'inet6 '; then
            if ip -6 route show 2>/dev/null | grep -vE '^(fe80::|ff00::|fd|fc)' | grep -q 'dev '; then
                return 0
            fi
        fi
    fi
    return 1
}

wan6_policy_effective_mode() {
    wan6_policy_load
    case "$XFREE_WAN6_MODE" in
        off|selective|full)
            printf '%s\n' "$XFREE_WAN6_MODE"
            ;;
        auto|*)
            if wan6_policy_has_ipv6; then
                printf 'selective\n'
            else
                printf 'off\n'
            fi
            ;;
    esac
}

wan6_policy_write() {
    _mode="${1:-auto}"
    _domains="${2:-$WAN6_DEFAULT_ALLOW_DOMAINS}"
    _zapret_v6="${3:-}"
    _state_root="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
    _pfile="$_state_root/wan6-policy.env"

    mkdir -p "$_state_root" 2>/dev/null || true
    {
        printf '# Managed by xfree-toolbox (disable-wan-ipv6.sh / wan6-policy)\n'
        printf "XFREE_WAN6_MODE='%s'\n" "$_mode"
        printf "XFREE_WAN6_ALLOW_DOMAINS='%s'\n" "$_domains"
        if [ -n "$_zapret_v6" ]; then
            printf "XFREE_ZAPRET_IPV6='%s'\n" "$_zapret_v6"
        fi
    } > "${_pfile}.tmp"
    mv -f "${_pfile}.tmp" "$_pfile"
}
