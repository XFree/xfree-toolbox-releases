#!/bin/sh
# shellcheck shell=sh

common_basename() {
  basename -- "$0" 2>/dev/null || basename "$0"
}

say() {
  [ "${SILENT:-0}" = "1" ] || [ "${QUIET:-0}" = "1" ] || printf '%s\n' "$*"
}

info() {
  say "[*] $*"
}

success() {
  say "[✓] $*"
}

warn() {
  printf '[!] %s\n' "$*" >&2
}

error() {
  printf '[-] %s\n' "$*" >&2
}

common_append_log_file() {
  log_file_path="$1"
  shift

  [ -n "$log_file_path" ] || return 0
  mkdir -p "$(dirname -- "$log_file_path")" 2>/dev/null || true
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)" "$*" >> "$log_file_path" 2>/dev/null || true
}

die() {
  if [ -n "${COMMON_DIE_LOG_FILE:-}" ]; then
    common_append_log_file "$COMMON_DIE_LOG_FILE" "[ERROR] $*"
  fi
  error "$*"
  exit 1
}

# Строка в терминал и в COMMON_LOG_FILE (если задан).
common_log() {
  if [ -n "${COMMON_LOG_FILE:-}" ]; then
    printf '%s\n' "$*" | tee -a "$COMMON_LOG_FILE"
  else
    printf '%s\n' "$*"
  fi
}

# Выполнить команду с построчным выводом (stdbuf при наличии) в терминал и COMMON_LOG_FILE.
# При pipe в tee код выхода берётся из subshell (иначе успешен всегда tee).
common_run_live() {
  [ "$#" -ge 1 ] || return 2
  rcf="${TMPDIR:-/tmp}/xfree-run-rc.$$"
  rm -f "$rcf"
  if [ -n "${COMMON_LOG_FILE:-}" ]; then
    if command -v stdbuf >/dev/null 2>&1; then
      ( stdbuf -oL -eL "$@"; echo $? >"$rcf" ) 2>&1 | tee -a "$COMMON_LOG_FILE"
    else
      ( "$@"; echo $? >"$rcf" ) 2>&1 | tee -a "$COMMON_LOG_FILE"
    fi
  elif command -v stdbuf >/dev/null 2>&1; then
    stdbuf -oL -eL "$@" 2>&1
    return $?
  else
    "$@" 2>&1
    return $?
  fi
  rc=1
  [ -f "$rcf" ] && rc=$(cat "$rcf" 2>/dev/null || echo 1)
  rm -f "$rcf"
  return "$rc"
}

# URL → hostname (как usb_watch_target_to_host).
common_url_to_host() {
  _target="${1:-}"
  [ -n "$_target" ] || return 1
  case "$_target" in
    http://*|https://*)
      _h="${_target#*://}"
      _h="${_h%%/*}"
      _h="${_h%%:*}"
      [ -n "$_h" ] || return 1
      printf '%s\n' "$_h"
      ;;
    *)
      printf '%s\n' "${_target%%/*}"
      ;;
  esac
}

# Корень toolbox для подключения uplink-probe (usb-power-watch-lib).
common_toolbox_root() {
  for _d in "${XFREE_ROOT_DIR:-}" "${XFREE_TOOLBOX_ROOT:-}" "${USB_WATCH_ROOT_DIR:-}" "${ROOT_DIR:-}" "${XFREE_TOOLBOX_TARGET_DIR:-}"; do
    [ -n "$_d" ] || continue
    if [ -f "$_d/lib/common.sh" ]; then
      printf '%s\n' "$_d"
      return 0
    fi
  done
  if [ -f /root/xfree-toolbox/lib/common.sh ]; then
    printf '%s\n' /root/xfree-toolbox
    return 0
  fi
  return 1
}

common_ensure_usb_watch_lib() {
  case "${COMMON_USB_WATCH_LIB_OK:-}" in
    1) return 0 ;;
    0) return 1 ;;
  esac
  _root="$(common_toolbox_root 2>/dev/null || true)"
  if [ -z "$_root" ]; then
    COMMON_USB_WATCH_LIB_OK=0
    return 1
  fi
  _lib="$_root/system/hardware/usb-power-watch-lib.sh"
  if [ ! -f "$_lib" ]; then
    COMMON_USB_WATCH_LIB_OK=0
    return 1
  fi
  USB_WATCH_ROOT_DIR="$_root"
  export USB_WATCH_ROOT_DIR
  # shellcheck disable=SC1090
  . "$_lib"
  COMMON_USB_WATCH_LIB_OK=1
  return 0
}

# ICMP по имени (нужен рабочий DNS). Без подмены ping на IP.
common_ping_named_host() {
  _host="${1:-}"
  [ -n "$_host" ] || return 1
  command -v ping >/dev/null 2>&1 || return 1
  if ping -4 -c 1 -W 2 "$_host" >/dev/null 2>&1; then
    return 0
  fi
  ping -c 1 -W 2 "$_host" >/dev/null 2>&1
}

# Resolve/ICMP probe для дополнительного хоста ($2 у wait, режим dns).
# $2 — опциональный nameserver (BusyBox: nslookup HOST SERVER), для bootstrap DNS.
# Для apk/feeds используйте common_probe_http_host / wait $3=https (BusyBox wget без --spider).
common_probe_dns_host() {
  _host="${1:-}"
  _ns="${2:-}"
  [ -n "$_host" ] || return 1
  if command -v nslookup >/dev/null 2>&1; then
    if [ -n "$_ns" ]; then
      nslookup "$_host" "$_ns" >/dev/null 2>&1 && return 0
    else
      nslookup "$_host" >/dev/null 2>&1 && return 0
    fi
  fi
  if [ -z "$_ns" ] && command -v host >/dev/null 2>&1; then
    host "$_host" >/dev/null 2>&1 && return 0
  fi
  [ -n "$_ns" ] && return 1
  common_ping_named_host "$_host"
}

# BusyBox wget / GNU wget / OpenWrt uclient-fetch: HTTP 4xx/5xx still means
# TCP+TLS reached the host (api.cloudflareclient.com GET / is 404).
# uclient-fetch: "HTTP error 404", exit 8; with -q the message is omitted.
common_probe_http_reached() {
  case "$1" in
    *'server returned error: HTTP'*) return 0 ;;
    *'HTTP error '[1-5][0-9][0-9]*) return 0 ;;
    *'ERROR '[1-5][0-9][0-9]*) return 0 ;;
    *'HTTP/'*[1-5][0-9][0-9]*) return 0 ;;
  esac
  return 1
}

common_probe_wget_get() {
  _err=""
  _rc=0
  _err="$(wget -q -O /dev/null -T 5 "$@" "$_url" 2>&1)" || _rc=$?
  [ "$_rc" -eq 0 ] && return 0
  # GNU wget / uclient-fetch: server issued an HTTP error response.
  [ "$_rc" -eq 8 ] && return 0
  common_probe_http_reached "$_err"
}

common_probe_curl_get() {
  _code=""
  _code="$(curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 5 "$@" "$_url" 2>/dev/null)" || true
  case "$_code" in
    [1-9][0-9][0-9]) return 0 ;;
  esac
  return 1
}

# HTTPS GET как apk/uclient-fetch (OpenWrt wget = BusyBox, нет GNU --spider).
# IPv4 сначала: dual-stack на STA без IPv6 зависает на AAAA / Operation not permitted
# (тот же порядок, что HTTP_PREFER_IPV4 в lib/pkgmgr.sh).
# Повтор --no-check-certificate / curl -k — как xfree_https_fetch (factory часто без ca-bundle).
# Любой HTTP-код (в т.ч. 404) = хост доступен; timeout/DNS/handshake — нет.
common_probe_http_host() {
  _host="${1:-}"
  [ -n "$_host" ] || return 1
  _url="https://${_host}/"
  if command -v wget >/dev/null 2>&1; then
    common_probe_wget_get -4 && return 0
    common_probe_wget_get -4 --no-check-certificate && return 0
    common_probe_wget_get && return 0
    common_probe_wget_get --no-check-certificate && return 0
  fi
  if command -v curl >/dev/null 2>&1; then
    common_probe_curl_get -4 && return 0
    common_probe_curl_get -4 -k && return 0
    common_probe_curl_get && return 0
    common_probe_curl_get -k && return 0
  fi
  return 1
}

# Базовый uplink-probe: домены/алгоритм как у мониторинга uplink (TEST_URL → ping host).
# Без мягкой подмены ICMP на IP резолвера.
common_uplink_connectivity_ok() {
  if common_ensure_usb_watch_lib && command -v usb_watch_uplink_base_ready >/dev/null 2>&1; then
    usb_watch_uplink_base_ready
    return $?
  fi
  # Fallback без lib: те же дефолты, что TEST_URL в usb-power-watch-lib.
  _url="${USB_WATCH_TEST_URL:-https://ya.ru/}"
  _host="$(common_url_to_host "$_url" 2>/dev/null || true)"
  [ -n "$_host" ] || _host="ya.ru"
  common_ping_named_host "$_host"
}

# Wait until default route and uplink connectivity work (after network restart / before HTTP API).
# $1 — timeout sec (default 90)
# $2 — optional extra hostname (e.g. api.cloudflareclient.com, downloads.openwrt.org)
# $3 — extra probe: dns (default; nslookup/ping) | https (BusyBox wget GET, как apk).
#      Legacy strict_dns (1/true) treated as dns.
# Returns 0 when ready, 1 on timeout.
common_wait_network_after_restart() {
  timeout_sec="${1:-90}"
  extra_dns_host="${2:-}"
  extra_probe="${3:-dns}"
  case "$extra_probe" in
    https|http|wget) extra_probe=https ;;
    *) extra_probe=dns ;;
  esac
  started="$(date +%s 2>/dev/null || echo 0)"
  deadline=$((started + timeout_sec))
  last_log="$started"

  if [ -n "$extra_dns_host" ] && [ "$extra_probe" = "https" ]; then
    info "Ожидаю готовность сети (маршрут + uplink + HTTPS ${extra_dns_host}, до ${timeout_sec}s)…"
  elif [ -n "$extra_dns_host" ]; then
    info "Ожидаю готовность сети (маршрут + uplink + DNS ${extra_dns_host}, до ${timeout_sec}s)…"
  else
    info "Ожидаю готовность сети (маршрут + uplink TEST_URL, до ${timeout_sec}s)…"
  fi

  while :; do
    now="$(date +%s 2>/dev/null || echo 0)"
    [ "$now" -ge "$deadline" ] && break

    route_ok=0
    if command -v ip >/dev/null 2>&1; then
      ip route 2>/dev/null | grep -q '^default ' && route_ok=1
    elif command -v route >/dev/null 2>&1; then
      route -n 2>/dev/null | awk '$1=="0.0.0.0" && $2!="0.0.0.0" {found=1; exit} END{exit !found}' && route_ok=1
    fi

    uplink_ok=0
    if [ "$route_ok" = "1" ] && common_uplink_connectivity_ok; then
      uplink_ok=1
    fi

    extra_ok=1
    if [ -n "$extra_dns_host" ]; then
      extra_ok=0
      if [ "$uplink_ok" = "1" ]; then
        if [ "$extra_probe" = "https" ]; then
          common_probe_http_host "$extra_dns_host" && extra_ok=1
        else
          common_probe_dns_host "$extra_dns_host" && extra_ok=1
        fi
      fi
    fi

    if [ "$route_ok" = "1" ] && [ "$uplink_ok" = "1" ] && [ "$extra_ok" = "1" ]; then
      success "Сеть готова (маршрут и uplink)"
      return 0
    fi

    if [ $((now - last_log)) -ge 10 ] 2>/dev/null; then
      info "Сеть ещё поднимается… (маршрут=${route_ok} uplink=${uplink_ok} extra=${extra_ok})"
      last_log="$now"
    fi

    sleep 2
  done

  if [ -n "$extra_dns_host" ] && [ "$extra_probe" = "https" ]; then
    warn "Сеть не готова за ${timeout_sec}s (маршрут/uplink/HTTPS ${extra_dns_host})"
  elif [ -n "$extra_dns_host" ]; then
    warn "Сеть не готова за ${timeout_sec}s (маршрут/uplink/DNS ${extra_dns_host})"
  else
    warn "Сеть не готова за ${timeout_sec}s (маршрут/uplink)"
  fi
  return 1
}

# Alias for callers that only need connectivity, not necessarily a fresh restart.
common_ensure_network_ready() {
  common_wait_network_after_restart "$@"
}

# Run "$@" so stdout/stderr behave like on a TTY as much as possible when the
# caller redirects them to a fifo/pipe (full stdio buffering otherwise).
# Order: script(1) PTY (typical on OpenWrt BusyBox) → GNU stdbuf → plain exec.
common_exec_streaming() {
  [ "$#" -ge 1 ] || return 2

  if command -v script >/dev/null 2>&1; then
    _xf_launcher="$(mktemp "${TMPDIR:-/tmp}/xfree-exec-wrap.XXXXXX")" || return 1
    _xf_rc_file="$(mktemp "${TMPDIR:-/tmp}/xfree-exec-rc.XXXXXX")" || {
      rm -f "$_xf_launcher"
      return 1
    }
    {
      printf '%s\n' '#!/bin/sh'
      printf 'set --'
      for _xf_arg in "$@"; do
        s_q=$(printf '%s' "$_xf_arg" | sed "s/'/'\\\\''/g; 1s/^/'/; \$s/\$/'/")
        printf ' %s' "$s_q"
      done
      printf '\n'
      printf '"$@"\n'
    } > "$_xf_launcher" || {
      rm -f "$_xf_launcher" "$_xf_rc_file"
      return 1
    }
    chmod +x "$_xf_launcher" 2>/dev/null || true
    _XFREE_STREAM_WRAP="$_xf_launcher"
    _XFREE_STREAM_RC_FILE="$_xf_rc_file"
    export _XFREE_STREAM_WRAP _XFREE_STREAM_RC_FILE
    _xf_rc=0
    # util-linux script on WSL often returns 0 even when the child fails — persist rc in a file.
    script -q -c 'sh "$_XFREE_STREAM_WRAP"; _ec=$?; printf "%s" "$_ec" > "$_XFREE_STREAM_RC_FILE"; exit "$_ec"' /dev/null 2>/dev/null || true
    if [ -s "$_xf_rc_file" ]; then
      _xf_rc=$(cat "$_xf_rc_file" 2>/dev/null || echo 0)
    fi
    unset _XFREE_STREAM_WRAP _XFREE_STREAM_RC_FILE
    rm -f "$_xf_launcher" "$_xf_rc_file"
    return "$_xf_rc"
  fi

  if command -v stdbuf >/dev/null 2>&1; then
    stdbuf -oL -eL -- "$@"
    return $?
  fi

  "$@"
  return $?
}

_debug_enabled() {
  case "$(common_upper_ascii "${XFREE_MODE:-PROD}")" in
    DEV) return 0 ;;
    *)   return 1 ;;
  esac
}

debug() {
  _debug_enabled || return 0
  printf '[D] %s\n' "$*" >&2
}

info_err() {
  [ "${SILENT:-0}" = "1" ] || [ "${QUIET:-0}" = "1" ] || printf '[*] %s\n' "$*" >&2
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Команда не найдена: $1"
}

ensure_parent_dir() {
  target="$1"
  mkdir -p "$(dirname -- "$target")"
}

timestamp_now() {
  date '+%Y-%m-%d_%H-%M-%S' 2>/dev/null || date
}

backup_stamp_now() {
  date '+%Y%m%d-%H%M%S' 2>/dev/null || date '+%s'
}

common_backup_root() {
  root="${BACKUP_ROOT:-${XFREE_BACKUP_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/backups}}"
  printf '%s\n' "$root"
}

common_backup_keep() {
  printf '%s\n' "${BACKUP_KEEP:-${KEEP_BACKUPS:-5}}"
}

common_backup_rotate() {
  dir="$1"
  prefix="$2"
  keep="${3:-$(common_backup_keep)}"

  [ -n "$dir" ] || return 0
  [ -n "$prefix" ] || return 0
  [ -d "$dir" ] || return 0

  case "$keep" in
    ''|*[!0-9]*) keep=5 ;;
  esac
  [ "$keep" -gt 0 ] || return 0

  find "$dir" -mindepth 1 -maxdepth 1 -name "${prefix}.*" 2>/dev/null \
    | sort -r \
    | awk -v keep="$keep" 'NR > keep { print }' \
    | while IFS= read -r old; do
        [ -n "$old" ] || continue
        rm -rf "$old"
      done
}

common_backup_path() {
  namespace="$1"
  prefix="$2"
  ext="${3:-bak}"
  root="$(common_backup_root)"
  stamp="$(backup_stamp_now)"
  dir="$root/$namespace"

  mkdir -p "$dir"
  if [ -n "$ext" ]; then
    printf '%s/%s.%s.%s\n' "$dir" "$prefix" "$stamp" "$ext"
  else
    printf '%s/%s.%s\n' "$dir" "$prefix" "$stamp"
  fi
}

common_backup_file() {
  src="$1"
  namespace="$2"
  prefix="$3"
  keep="${4:-$(common_backup_keep)}"
  ext="${5:-bak}"

  [ -f "$src" ] || return 0
  dst="$(common_backup_path "$namespace" "$prefix" "$ext")"
  cp -f "$src" "$dst"
  common_backup_rotate "$(dirname -- "$dst")" "$prefix" "$keep"
  printf '%s\n' "$dst"
}

common_backup_dir() {
  src="$1"
  namespace="$2"
  prefix="$3"
  keep="${4:-$(common_backup_keep)}"
  ext="${5:-}"

  [ -d "$src" ] || return 0
  dst="$(common_backup_path "$namespace" "$prefix" "$ext")"
  cp -a "$src" "$dst"
  common_backup_rotate "$(dirname -- "$dst")" "$prefix" "$keep"
  printf '%s\n' "$dst"
}

backup_file_if_exists() {
  src="$1"
  namespace="${2:-${BACKUP_NAMESPACE:-}}"
  [ -f "$src" ] || return 0
  [ -n "$namespace" ] || die "backup_file_if_exists: namespace не задан"

  prefix="$(basename -- "$src")"
  suffix="${3:-}"
  if [ -n "$suffix" ]; then
    prefix="$prefix.$suffix"
  fi

  # Backup policy: compatibility wrapper requires an explicit namespace and uses common retention.
  backup="$(common_backup_file "$src" "$namespace" "$prefix" "$(common_backup_keep)" bak)"
  if [ -n "$backup" ]; then
    info "Создан бэкап: $backup"
  fi
}

safe_copy_file() {
  src="$1"
  dst="$2"
  do_backup="${3:-0}"
  force="${4:-0}"
  namespace="${5:-${BACKUP_NAMESPACE:-}}"

  [ -f "$src" ] || die "Файл не найден: $src"
  ensure_parent_dir "$dst"

  if [ -e "$dst" ] && [ "$do_backup" = "1" ]; then
    backup_file_if_exists "$dst" "$namespace"
  fi

  if [ -e "$dst" ] && [ "$force" != "1" ]; then
    cmp -s "$src" "$dst" && return 0
  fi

  cp -f "$src" "$dst"
}

confirm_or_exit() {
  prompt="${1:-Продолжить?}"

  if [ "${YES:-0}" = "1" ] || [ "${FORCE:-0}" = "1" ]; then
    return 0
  fi

  printf '%s [y/N]: ' "$prompt" >&2
  IFS= read -r ans || ans=""
  case "$ans" in
    y|Y|yes|YES) return 0 ;;
    *)
      info "Отменено пользователем."
      exit 0
      ;;
  esac
}

restart_service_if_exists() {
  service="$1"
  init="/etc/init.d/$service"

  [ -x "$init" ] || return 0
  "$init" restart >/dev/null 2>&1 || true
}

wait_interface_ready() {
  iface="$1"
  max_tries="${2:-15}"
  sleep_sec="${3:-1}"
  require_ipv4="${4:-1}"

  [ -n "$iface" ] || die "wait_interface_ready: не указано имя интерфейса"

  i=1
  while [ "$i" -le "$max_tries" ]; do
    if ip link show dev "$iface" >/dev/null 2>&1; then
      if [ "$require_ipv4" = "0" ]; then
        return 0
      fi

      if ip -4 addr show dev "$iface" 2>/dev/null | grep -q "inet "; then
        return 0
      fi
    fi

    sleep "$sleep_sec"
    i=$((i + 1))
  done

  return 1
}

wait_interface_absent() {
  iface="$1"
  max_tries="${2:-10}"
  sleep_sec="${3:-1}"

  [ -n "$iface" ] || die "wait_interface_absent: не указано имя интерфейса"

  i=1
  while [ "$i" -le "$max_tries" ]; do
    if ! ip link show dev "$iface" >/dev/null 2>&1; then
      return 0
    fi
    sleep "$sleep_sec"
    i=$((i + 1))
  done

  return 1
}

reload_network_soft() {
  init="/etc/init.d/network"
  [ -x "$init" ] || die "Сервис не найден: network"

  info "Выполняю reload для network"
  "$init" reload || die "Не удалось выполнить reload для network"
}

refresh_target() {
  target_type="$1"
  target_name="$2"
  mode="${3:-default}"

  [ -n "$target_type" ] || die "refresh_target: не указан тип цели"
  [ -n "$target_name" ] || die "refresh_target: не указано имя цели"

  case "$target_type" in
    service)
      init="/etc/init.d/$target_name"
      [ -x "$init" ] || die "Сервис не найден: $target_name"

      case "$mode" in
        default)
          "$init" restart || die "Не удалось перезапустить сервис: $target_name"
          ;;
        stop-start)
          "$init" stop || true
          sleep 1
          "$init" start || die "Не удалось запустить сервис: $target_name"
          ;;
        reload)
          "$init" reload || die "Не удалось выполнить reload для сервиса: $target_name"
          ;;
        *)
          die "refresh_target: неподдерживаемый режим сервиса '$mode'"
          ;;
      esac
      ;;
    interface)
      require_cmd ifup
      require_cmd ifdown

      case "$mode" in
        default|bounce)
          info "Выполняю ifdown для интерфейса: $target_name"
          ifdown "$target_name" 2>/dev/null || true

          info "Ожидаю остановки интерфейса: $target_name"
          wait_interface_absent "$target_name" 10 1 || true

          sleep 1

          info "Выполняю ifup для интерфейса: $target_name"
          ifup "$target_name" || die "Не удалось выполнить ifup для интерфейса: $target_name"

          info "Ожидаю появления интерфейса: $target_name"
          wait_interface_ready "$target_name" 30 1 0 || die "Интерфейс $target_name не появился в течение 30 секунд"

          info "Ожидаю получения IPv4 на интерфейсе: $target_name"
          wait_interface_ready "$target_name" 30 1 1 || die "Интерфейс $target_name не получил IPv4 в течение 30 секунд"
          ;;
        ifup-only)
          info "Выполняю ifup для интерфейса: $target_name"
          ifup "$target_name" || die "Не удалось выполнить ifup для интерфейса: $target_name"

          info "Ожидаю появления интерфейса: $target_name"
          wait_interface_ready "$target_name" 30 1 0 || die "Интерфейс $target_name не появился в течение 30 секунд"

          info "Ожидаю получения IPv4 на интерфейсе: $target_name"
          wait_interface_ready "$target_name" 30 1 1 || die "Интерфейс $target_name не получил IPv4 в течение 30 секунд"
          ;;
        ifdown-only)
          info "Выполняю ifdown для интерфейса: $target_name"
          ifdown "$target_name" 2>/dev/null || true

          info "Ожидаю остановки интерфейса: $target_name"
          wait_interface_absent "$target_name" 10 1 || true
          ;;
        reload-network)
          info "Выполняю ifdown для интерфейса: $target_name"
          ifdown "$target_name" 2>/dev/null || true

          info "Ожидаю остановки интерфейса: $target_name"
          wait_interface_absent "$target_name" 10 1 || true

          reload_network_soft
          ;;
        *)
          die "refresh_target: неподдерживаемый режим интерфейса '$mode'"
          ;;
      esac
      ;;
    *)
      die "refresh_target: неподдерживаемый тип цели '$target_type'"
      ;;
  esac
}

common_resolve_path() {
  base_dir="$1"
  target_path="$2"

  case "$target_path" in
    /*) printf '%s\n' "$target_path" ;;
    *)
      if [ -n "$base_dir" ] && [ -d "$base_dir" ]; then
        (CDPATH= cd -- "$base_dir" 2>/dev/null && CDPATH= cd -- "$target_path" 2>/dev/null && pwd -P) && return 0
      fi
      printf '%s\n' "$target_path"
      ;;
  esac
}

resolve_path_from() {
  common_resolve_path "$1" "$2"
}

common_detect_project_root() {
  start_dir="${1:-$PWD}"

  # Walk up only to find the toolbox tree (lib/common.sh + upstreams/).
  # Do not treat a parent with leftover upstreams/domain-routing as the root —
  # callers that know the install dir should set PROJECT_ROOT or pin UPSTREAMS_DIR.
  cur="$start_dir"
  while [ -n "$cur" ] && [ "$cur" != "/" ]; do
    if [ -f "$cur/lib/common.sh" ] && [ -d "$cur/upstreams" ]; then
      printf '%s\n' "$cur"
      return 0
    fi
    parent="$(dirname -- "$cur")"
    [ "$parent" != "$cur" ] || break
    cur="$parent"
  done

  printf '%s\n' "$start_dir"
}

common_get_project_root() {
  start_dir="${1:-$PWD}"

  if [ -n "${PROJECT_ROOT:-}" ]; then
    case "$PROJECT_ROOT" in
      /*) printf '%s\n' "$PROJECT_ROOT" ;;
      *) (CDPATH= cd -- "$start_dir" 2>/dev/null && CDPATH= cd -- "$PROJECT_ROOT" 2>/dev/null && pwd -P) || printf '%s\n' "$PROJECT_ROOT" ;;
    esac
    return 0
  fi

  common_detect_project_root "$start_dir"
}

common_load_project_config() {
  project_root="$(common_get_project_root "${1:-$PWD}")"
  config_file="$project_root/config.sh"

  [ -f "$config_file" ] || return 0

  # shellcheck disable=SC1090
  . "$config_file"
  # Menus run with `set -u`; old/partial config.sh must not leave these unset.
  : "${XFREE_TOOLBOX_NAME:=xfree-toolbox}"
  : "${XFREE_STATE_ROOT:=/etc/$XFREE_TOOLBOX_NAME}"
  : "${XFREE_IFACE_ROUTING_ROOT:=$XFREE_STATE_ROOT/iface-routing}"
}

common_active_profile_name() {
  root_dir="${1:-$PWD}"
  common_load_project_config "$root_dir"

  # Prefer explicit profile name from config/env. Do NOT prefer basename(PROFILE_DIR):
  # long-lived menu shells often export a stale PROFILE_DIR that disagrees with config.sh,
  # which skipped set_active (choice==current) and made apply target the wrong profile.
  profile="${XFREE_PROFILE:-${PROFILE_NAME:-}}"
  profile="$(printf '%s' "$profile" | tr -cd 'A-Za-z0-9._-')"
  if [ -z "$profile" ]; then
    profile_dir_override="${XFREE_PROFILE_DIR:-${PROFILE_DIR:-}}"
    if [ -n "$profile_dir_override" ]; then
      profile="$(basename -- "$profile_dir_override")"
      profile="$(printf '%s' "$profile" | tr -cd 'A-Za-z0-9._-')"
    fi
  fi
  [ -n "$profile" ] || profile="default"
  printf '%s\n' "$profile"
}

# Last successfully applied profile (system state). Survives deploy; config.sh may reset.
common_applied_profile_file() {
  state_root="${1:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}}"
  printf '%s/applied-profile.env\n' "$state_root"
}

common_applied_profile_name() {
  state_root="${1:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}}"
  file="$(common_applied_profile_file "$state_root")"
  [ -f "$file" ] || return 1
  profile="$(sed -n 's/^XFREE_APPLIED_PROFILE=//p' "$file" 2>/dev/null | head -n1)"
  profile="$(printf '%s' "$profile" | sed "s/^['\"]//; s/['\"]$//" | tr -cd 'A-Za-z0-9._-')"
  [ -n "$profile" ] || return 1
  printf '%s\n' "$profile"
}

# $1=profile name, $2=optional state root
common_write_applied_profile() {
  profile_name="$(common_sanitize_profile_name "${1:-}" 2>/dev/null)" || return 1
  state_root="${2:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}}"
  file="$(common_applied_profile_file "$state_root")"
  mkdir -p "$state_root" 2>/dev/null || true
  ts_utc="$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date -u +"%Y-%m-%dT%H:%M:%SZ")"
  {
    printf '%s\n' "# Last profile applied to the system (apply-template). Not overwritten by toolbox deploy."
    printf '%s\n' "XFREE_APPLIED_PROFILE=$profile_name"
    printf '%s\n' "XFREE_APPLIED_AT_UTC=$ts_utc"
  } >"${file}.tmp"
  mv -f "${file}.tmp" "$file"
}

common_clear_applied_profile() {
  state_root="${1:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}}"
  file="$(common_applied_profile_file "$state_root")"
  rm -f "$file" 2>/dev/null || true
}

# Drop session overrides so config.sh (`:=` / assignments) can take effect.
# install-from-cloud / menu may leave XFREE_PROFILE=default in the environment.
common_profile_env_clear_overrides() {
  unset PROFILE_DIR
  unset XFREE_PROFILE
  unset XFREE_PROFILE_DIR
}

# Compat alias (older call sites cleared only PROFILE_DIR).
common_profile_env_clear_dir_override() {
  common_profile_env_clear_overrides
}

# Write XFREE_PROFILE / XFREE_PROFILE_DIR in project config.sh ($1=root, $2=profile name).
# Replaces both `: "${XFREE_PROFILE:=...}"` and plain assignments; keeps other config lines.
common_set_active_profile_in_config() {
  root_dir="${1:-${ROOT_DIR:-$PWD}}"
  profile_name="$(common_sanitize_profile_name "${2:-}" 2>/dev/null)" || return 1
  profiles_dir="$(common_profiles_dir "$root_dir")"
  profile_dir_rel="$profiles_dir/$profile_name"
  case "$profile_dir_rel" in
    "$root_dir"/*) profile_dir_rel="${profile_dir_rel#"$root_dir"/}" ;;
  esac
  tmp_file="$root_dir/config.sh.tmp.$$"
  config_file="$root_dir/config.sh"

  if [ -f "$config_file" ]; then
    awk -v profile="$profile_name" -v profile_dir="$profile_dir_rel" '
      BEGIN { got_profile=0; got_dir=0 }
      /^[[:space:]]*#/ { print; next }
      index($0, "XFREE_PROFILE_DIR") > 0 {
        if (got_dir == 0) {
          print "XFREE_PROFILE_DIR=\047" profile_dir "\047"
          got_dir=1
        }
        next
      }
      index($0, "XFREE_PROFILE") > 0 {
        if (got_profile == 0) {
          print "XFREE_PROFILE='\''" profile "'\''"
          got_profile=1
        }
        next
      }
      { print }
      END {
        if (got_profile == 0) {
          print "XFREE_PROFILE='\''" profile "'\''"
        }
        if (got_dir == 0) {
          print "XFREE_PROFILE_DIR=\047" profile_dir "\047"
        }
      }
    ' "$config_file" >"$tmp_file"
  else
    {
      printf "XFREE_PROFILE='%s'\n" "$profile_name"
      printf "XFREE_PROFILE_DIR='%s'\n" "$profile_dir_rel"
    } >"$tmp_file"
  fi

  mv "$tmp_file" "$config_file"
  return 0
}

common_profiles_dir() {
  root_dir="${1:-$PWD}"
  common_load_project_config "$root_dir"

  profiles_dir="${PROFILES_DIR:-${XFREE_PROFILES_DIR:-$root_dir/profiles}}"
  case "$profiles_dir" in
    /*) printf '%s\n' "$profiles_dir" ;;
    *) common_resolve_path "$root_dir" "$profiles_dir" ;;
  esac
}

# Имена подкаталогов profiles/<name>, по одному в строке, отсортировано (для меню и restore UX).
common_list_profile_dirnames() {
  root_dir="${1:-$PWD}"
  profiles_dir="$(common_profiles_dir "$root_dir")"
  [ -d "$profiles_dir" ] || return 0
  find "$profiles_dir" -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
    | while IFS= read -r d; do
      [ -n "$d" ] || continue
      basename "$d"
    done | LC_ALL=C sort
}

common_sanitize_profile_name() {
  raw="${1:-}"
  sanitized="$(printf '%s' "$raw" | tr -cd 'A-Za-z0-9._-')"
  [ -n "$sanitized" ] || return 1
  printf '%s\n' "$sanitized"
}

common_profile_templates_dir() {
  root_dir="${1:-$PWD}"
  common_load_project_config "$root_dir"

  templates_dir="${PROFILE_TEMPLATES_DIR:-${XFREE_PROFILE_TEMPLATES_DIR:-$root_dir/profile-templates}}"
  case "$templates_dir" in
    /*) printf '%s\n' "$templates_dir" ;;
    *) common_resolve_path "$root_dir" "$templates_dir" ;;
  esac
}

common_profile_template_resolve_dir() {
  root_dir="${1:-$PWD}"
  template_arg="${2:-}"
  templates_dir="$(common_profile_templates_dir "$root_dir")"
  template_arg="$(common_sanitize_profile_name "$template_arg" 2>/dev/null)" || return 1
  printf '%s/%s\n' "$templates_dir" "$template_arg"
}

# Имена подкаталогов profile-templates/<name>, по одному в строке.
common_list_profile_template_dirnames() {
  root_dir="${1:-$PWD}"
  templates_dir="$(common_profile_templates_dir "$root_dir")"
  [ -d "$templates_dir" ] || return 0
  find "$templates_dir" -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
    | while IFS= read -r d; do
      [ -n "$d" ] || continue
      basename "$d"
    done | LC_ALL=C sort
}

# Слить содержимое каталога в dst (cp -a): новые файлы добавляются, совпадающие пути обновляются; лишнее в dst не удаляется.
xfree_cp_merge_dir() {
  src="$1"
  dst="$2"
  [ -d "$src" ] || return 0
  mkdir -p "$dst"
  cp -a "$src/." "$dst/"
}

# profiles/ на роутере не берётся из архива целиком: только сохранённый каталог или пустой + README.
xfree_install_materialize_profiles_dir() {
  source_dir="$1"
  target_dir="$2"
  keep_profiles_dir="${3:-}"

  rm -rf "$target_dir/profiles"
  if [ -n "$keep_profiles_dir" ] && [ -d "$keep_profiles_dir" ]; then
    cp -a "$keep_profiles_dir" "$target_dir/profiles"
    return 0
  fi

  mkdir -p "$target_dir/profiles"
  if [ -f "$source_dir/profiles/README.md" ]; then
    cp -f "$source_dir/profiles/README.md" "$target_dir/profiles/" 2>/dev/null || true
  fi
}

# profile-templates/: сначала с роутера (если есть), затем слияние из source (архив/дерево обновления).
xfree_install_merge_profile_templates_dir() {
  source_dir="$1"
  target_dir="$2"
  router_templates_dir="${3:-}"

  [ -d "$source_dir/profile-templates" ] || return 0

  mkdir -p "$target_dir/profile-templates"
  if [ -n "$router_templates_dir" ] && [ -d "$router_templates_dir" ]; then
    xfree_cp_merge_dir "$router_templates_dir" "$target_dir/profile-templates"
  fi
  xfree_cp_merge_dir "$source_dir/profile-templates" "$target_dir/profile-templates"
}

# Есть ли в state данные модулей (не пустые каталоги после migrate-state-root.sh).
# migrate-state-root.sh делает mkdir -p iface-routing, dns-routing, vpn на каждом запуске меню —
# только наличие каталога не означает, что был деплой или apply.
common_state_root_looks_populated() {
  state_root="${1:-}"
  [ -n "$state_root" ] || return 1
  [ -d "$state_root" ] || return 1

  for mod in iface-routing dns-routing zapret awg-ingress vpn vk-turn domain-routing; do
    subdir="$state_root/$mod"
    [ -d "$subdir" ] || continue
    if find "$subdir" -type f 2>/dev/null | head -n 1 | grep -q .; then
      return 0
    fi
  done
  return 1
}

# Первое значение EXPORT_NAME= из EXPORT-META.txt (только печатные символы имени).
common_export_meta_export_name() {
  meta_file="${1:-}"
  [ -f "$meta_file" ] || return 1
  line="$(grep '^EXPORT_NAME=' "$meta_file" 2>/dev/null | head -n1)"
  [ -n "$line" ] || return 1
  val="${line#EXPORT_NAME=}"
  val="$(printf '%s' "$val" | tr -cd 'A-Za-z0-9._-')"
  [ -n "$val" ] || return 1
  printf '%s\n' "$val"
}

# Подсказка имени узла из runtime-status (роутер) или uname; не годится для generic-хостнеймов.
common_runtime_hostname_slug() {
  state_root="${1:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}}"
  status_file="$state_root/runtime-status.env"
  raw=""
  if [ -f "$status_file" ]; then
    raw="$(grep '^XFREE_HOSTNAME=' "$status_file" 2>/dev/null | head -n1 | sed 's/^XFREE_HOSTNAME=//; s/\r$//')"
  fi
  if [ -z "$raw" ]; then
    raw="$(uname -n 2>/dev/null || printf '%s\n' '')"
  fi
  slug="$(printf '%s' "$raw" | tr -cd 'A-Za-z0-9._-')"
  [ -n "$slug" ] || return 1
  lc="$(printf '%s' "$slug" | tr '[:upper:]' '[:lower:]')"
  case "$lc" in
    openwrt|lede|localhost) return 1 ;;
  esac
  printf '%s\n' "$slug"
}

common_profile_dir() {
  root_dir="${1:-$PWD}"
  profile_arg="${2:-}"
  common_profile_resolve_dir "$root_dir" "$profile_arg"
}

common_profile_resolve_dir() {
  root_dir="${1:-$PWD}"
  profile_arg="${2:-}"
  common_load_project_config "$root_dir"

  profiles_dir="$(common_profiles_dir "$root_dir")"
  active="$(common_active_profile_name "$root_dir")"

  # Explicit apply override always wins (menu/install-from-cloud → apply-template children).
  if [ -n "${XFREE_APPLY_PROFILE_DIR:-}" ] && [ -d "$XFREE_APPLY_PROFILE_DIR" ]; then
    case "$XFREE_APPLY_PROFILE_DIR" in
      /*)
        printf '%s\n' "$XFREE_APPLY_PROFILE_DIR"
        return 0
        ;;
      *)
        common_resolve_path "$root_dir" "$XFREE_APPLY_PROFILE_DIR"
        return 0
        ;;
    esac
  fi

  # Path-like profile_arg / ambient PROFILE_DIR often stale in long-lived menu shells
  # (basename default while config already says default-with-proton). Keep only if
  # basename matches active name; bare names are intentional profile picks.
  if [ -n "$profile_arg" ]; then
    case "$profile_arg" in
      */*)
        _arg_base="$(basename -- "$profile_arg")"
        _arg_base="$(printf '%s' "$_arg_base" | tr -cd 'A-Za-z0-9._-')"
        if [ "$_arg_base" != "$active" ]; then
          profile_arg=""
        fi
        ;;
    esac
  fi

  resolved_input="$profile_arg"
  if [ -z "$resolved_input" ]; then
    if [ -n "${PROFILE_DIR:-}" ]; then
      _pd_base="$(basename -- "$PROFILE_DIR")"
      _pd_base="$(printf '%s' "$_pd_base" | tr -cd 'A-Za-z0-9._-')"
      if [ "$_pd_base" = "$active" ]; then
        resolved_input="$PROFILE_DIR"
      fi
    fi
    if [ -z "$resolved_input" ] && [ -n "${XFREE_PROFILE_DIR:-}" ]; then
      _xd_base="$(basename -- "$XFREE_PROFILE_DIR")"
      _xd_base="$(printf '%s' "$_xd_base" | tr -cd 'A-Za-z0-9._-')"
      if [ "$_xd_base" = "$active" ]; then
        resolved_input="$XFREE_PROFILE_DIR"
      fi
    fi
    if [ -z "$resolved_input" ]; then
      printf '%s/%s\n' "$profiles_dir" "$active"
      return 0
    fi
  fi

  case "$resolved_input" in
    */*)
      case "$resolved_input" in
        /*)
          printf '%s\n' "$resolved_input"
          return 0
          ;;
        *)
          common_resolve_path "$root_dir" "$resolved_input"
          return 0
          ;;
      esac
      ;;
    *)
      sanitized="$(printf '%s' "$resolved_input" | tr -cd 'A-Za-z0-9._-')"
      [ -n "$sanitized" ] || sanitized="default"
      printf '%s/%s\n' "$profiles_dir" "$sanitized"
      return 0
      ;;
  esac
}

load_base_config() {
  start_dir="${1:-$PWD}"

  if [ -n "${XFREE_CONFIG_FILE:-}" ] && [ -f "$XFREE_CONFIG_FILE" ]; then
    # shellcheck disable=SC1090
    . "$XFREE_CONFIG_FILE"
    return 0
  fi

  if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/config.sh" ]; then
    # shellcheck disable=SC1090
    . "$ROOT_DIR/config.sh"
    return 0
  fi

  project_root="$(common_get_project_root "$start_dir")"
  if [ -f "$project_root/config.sh" ]; then
    # shellcheck disable=SC1090
    . "$project_root/config.sh"
  fi
}

load_module_config() {
  config_file="${1:-}"
  [ -n "$config_file" ] || return 0
  [ -f "$config_file" ] || return 0

  # shellcheck disable=SC1090
  . "$config_file"
}

common_get_upstreams_dir() {
  start_dir="${1:-$PWD}"
  project_root="$(common_get_project_root "$start_dir")"

  if [ -n "${UPSTREAMS_DIR:-}" ]; then
    case "$UPSTREAMS_DIR" in
      /*) printf '%s\n' "$UPSTREAMS_DIR" ;;
      *) (CDPATH= cd -- "$start_dir" 2>/dev/null && CDPATH= cd -- "$UPSTREAMS_DIR" 2>/dev/null && pwd -P) || printf '%s\n' "$UPSTREAMS_DIR" ;;
    esac
    return 0
  fi

  printf '%s/upstreams\n' "$project_root"
}

common__upstreams_lib_path() {
  if [ -n "${ROOT_DIR:-}" ] && [ -f "${ROOT_DIR}/lib/upstreams.sh" ]; then
    printf '%s\n' "${ROOT_DIR}/lib/upstreams.sh"
    return 0
  fi

  project_root="$(common_get_project_root "${1:-$PWD}")"
  if [ -f "${project_root}/lib/upstreams.sh" ]; then
    printf '%s\n' "${project_root}/lib/upstreams.sh"
    return 0
  fi

  return 1
}

common__source_upstreams_lib() {
  lib_path="$(common__upstreams_lib_path "${1:-$PWD}" 2>/dev/null || true)"
  [ -n "$lib_path" ] || return 1

  # shellcheck disable=SC1090
  . "$lib_path"
  return 0
}

common_upstream_title() {
  module_dir="$1"

  if common__source_upstreams_lib "$module_dir" >/dev/null 2>&1; then
    if upstreams_module_title "$module_dir" >/dev/null 2>&1; then
      upstreams_module_title "$module_dir"
      return 0
    fi
  fi

  conf="$module_dir/upstream.conf"
  if [ -f "$conf" ]; then
    title="$(sed -n 's/^UPSTREAM_TITLE=//p' "$conf" | head -n1 | sed "s/^['\"]//; s/['\"]$//")"
    if [ -n "$title" ]; then
      printf '%s\n' "$title"
      return 0
    fi

    name="$(sed -n 's/^UPSTREAM_NAME=//p' "$conf" | head -n1 | sed "s/^['\"]//; s/['\"]$//")"
    if [ -n "$name" ]; then
      printf '%s\n' "$name"
      return 0
    fi
  fi

  printf '%s\n' "unknown"
}

common_list_upstream_modules_tsv() {
  start_dir="${1:-$PWD}"

  if common__source_upstreams_lib "$start_dir" >/dev/null 2>&1; then
    upstreams_list_all_modules_tsv "$start_dir" | while IFS="$(printf '\t')" read -r name title description enabled script data_dir conf_file; do
      [ -n "$name" ] || continue
      [ -n "$data_dir" ] || continue
      [ -d "$data_dir" ] || continue

      printf '%s\t%s\t%s\n' "$name" "$title" "$data_dir"
    done
    return 0
  fi

  upstreams_dir="$(common_get_upstreams_dir "$start_dir")"
  [ -d "$upstreams_dir" ] || return 0

  find "$upstreams_dir" -type f -name upstream.conf 2>/dev/null | sort | while IFS= read -r conf_path; do
    [ -f "$conf_path" ] || continue
    module_dir="${conf_path%/*}"
    data_root="$module_dir/upstream"
    [ -d "$data_root" ] || continue

    key="$(sed -n 's/^UPSTREAM_NAME=//p' "$conf_path" | head -n1 | sed "s/^['\"]//; s/['\"]$//" | common_lower_ascii_stream | sed 's/[^a-z0-9._-]/-/g')"
    [ -n "$key" ] || continue

    title="$(common_upstream_title "$module_dir")"
    printf '%s\t%s\t%s\n' "$key" "$title" "$data_root"
  done
}

common_sync_dir_mirror() {
  src="$1"
  dst="$2"

  [ -n "$src" ] || die "common_sync_dir_mirror: src не задан"
  [ -n "$dst" ] || die "common_sync_dir_mirror: dst не задан"

  mkdir -p "$src" "$dst"

  find "$dst" -mindepth 1 -maxdepth 1 -exec rm -rf {} \; 2>/dev/null || true

  find "$src" -mindepth 1 -maxdepth 1 -type f | sort | while IFS= read -r f; do
    [ -f "$f" ] || continue
    cp -f "$f" "$dst/"
  done
}

common_clear_dir_files() {
  dir="$1"
  pattern="${2:-*}"

  [ -n "$dir" ] || die "common_clear_dir_files: dir не задан"
  mkdir -p "$dir"
  rm -f "$dir"/$pattern 2>/dev/null || true
}

common_sync_domain_routing_work_from_active() {
  work_fqdn_dir="$1"
  work_prefix_dir="$2"
  active_fqdn_dir="$3"
  active_prefix_dir="$4"

  [ -n "$work_fqdn_dir" ] || die "common_sync_domain_routing_work_from_active: work_fqdn_dir не задан"
  [ -n "$work_prefix_dir" ] || die "common_sync_domain_routing_work_from_active: work_prefix_dir не задан"
  [ -n "$active_fqdn_dir" ] || die "common_sync_domain_routing_work_from_active: active_fqdn_dir не задан"
  [ -n "$active_prefix_dir" ] || die "common_sync_domain_routing_work_from_active: active_prefix_dir не задан"

  mkdir -p "$work_fqdn_dir" "$work_prefix_dir"

  if [ ! -d "$active_fqdn_dir" ] && [ ! -d "$active_prefix_dir" ]; then
    common_clear_dir_files "$work_fqdn_dir" '*.lst'
    common_clear_dir_files "$work_prefix_dir" '*.lst'
    return 0
  fi

  mkdir -p "$active_fqdn_dir" "$active_prefix_dir"

  common_sync_dir_mirror "$active_fqdn_dir" "$work_fqdn_dir"
  common_sync_dir_mirror "$active_prefix_dir" "$work_prefix_dir"
}

common_list_domain_interfaces() {
  interfaces_dir="$1"

  [ -n "$interfaces_dir" ] || die "common_list_domain_interfaces: interfaces_dir не задан"
  [ -d "$interfaces_dir" ] || return 0

  find "$interfaces_dir" -type f -path '*/config/iface.conf' 2>/dev/null \
    | sed "s|$interfaces_dir/||" \
    | sed 's|/config/iface.conf$||' \
    | sed '/^$/d' \
    | sort -u
}

common_select_domain_interface() {
  title="${1:-Выбор интерфейса}"
  interfaces_dir="$2"

  [ -n "$interfaces_dir" ] || die "common_select_domain_interface: interfaces_dir не задан"

  tmp="$(mktemp)"
  trap 'rm -f "$tmp"' EXIT INT TERM

  common_list_domain_interfaces "$interfaces_dir" > "$tmp"

  if [ ! -s "$tmp" ]; then
    if command -v ui_msgbox >/dev/null 2>&1; then
      ui_msgbox "$title" "Не найдены интерфейсы в каталоге:\n$interfaces_dir"
    else
      warn "Не найдены интерфейсы в каталоге: $interfaces_dir"
    fi
    return 1
  fi

  if command -v ui_menu >/dev/null 2>&1; then
    set --
    while IFS= read -r iface; do
      [ -n "${iface:-}" ] || continue
      set -- "$@" "$iface" "config: $iface"
    done < "$tmp"

    choice="$(ui_menu "$title" "Выберите интерфейс" 20 100 12 "$@" || true)"
    [ -n "${choice:-}" ] || return 1
    printf '%s\n' "$choice"
  else
    awk '{ printf "%2d) %s\n", NR, $0 }' "$tmp" >&2
    printf 'Select interface: ' >&2
    IFS= read -r num || return 1
    case "$num" in
      ''|*[!0-9]*) die "Invalid selection: $num" ;;
    esac
    sed -n "${num}p" "$tmp"
  fi

  trap - EXIT INT TERM
  rm -f "$tmp"
}

# Normalize UCI .path value (strip wrapping quotes).
common_uci_path_value() {
  printf '%s' "${1:-}" | sed "s/^'//; s/'$//"
}

common_basename_from_path() {
  p="${1:-}"
  printf '%s\n' "${p##*/}"
}

# Delete firewall include sections whose nft path is the primary runtime file,
# known legacy locations, or (optional) a non-primary file still containing
# legacy single-VPN nft (vpn_* sets, mark 0x10000).
# Args: primary_nft_path, legacy_cleanup_enabled (0|1), delete_orphan_content_match (0|1)
# Returns 0. Logs via info when uci deletes.
common_firewall_remove_fqdn_includes() {
  primary_nft="${1:-}"
  legacy_enabled="${2:-1}"
  content_match="${3:-0}"

  command -v uci >/dev/null 2>&1 || return 0

  state_root="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
  domain_rt="${state_root}/domain-routing/90-domain-routing.nft"
  domain_rt_xfree="${state_root}/domain-routing/90-xfree-toolbox-fqdn-routing.nft"

  deleted_any=1
  while [ "$deleted_any" = "1" ]; do
    deleted_any=0
    while IFS= read -r sec; do
      [ -n "$sec" ] || continue
      path_raw="$(uci -q get "${sec}.path" 2>/dev/null || true)"
      path="$(common_uci_path_value "$path_raw")"
      [ -n "$path" ] || continue

      drop=0
      if [ -n "$primary_nft" ] && [ "$path" = "$primary_nft" ]; then
        drop=1
      fi
      if [ "$legacy_enabled" = "1" ]; then
        case "$path" in
          /etc/domain-routing/90-domain-routing.nft|/etc/domain-routing/90-xfree-toolbox-fqdn-routing.nft)
            drop=1
            ;;
          "$domain_rt"|"$domain_rt_xfree")
            drop=1
            ;;
        esac
        bn="$(common_basename_from_path "$path")"
        if [ "$bn" = "90-domain-routing.nft" ]; then
          drop=1
        fi
        if [ "$content_match" = "1" ] && [ "$drop" = "0" ]; then
          if [ -n "$primary_nft" ] && [ "$path" != "$primary_nft" ] && [ -f "$path" ] \
            && grep -qE 'vpn_fqdn4|vpn_fqdn6|vpn_prefixes4|vpn_prefixes6|@vpn_|set vpn_|meta mark set 0x00010000|meta mark set 0x10000' "$path" 2>/dev/null; then
            drop=1
          fi
        fi
      fi

      if [ "$drop" = "1" ]; then
        info "Удаляю firewall include $sec (path=$path)"
        uci delete "$sec" 2>/dev/null || true
        deleted_any=1
        break
      fi
    done <<EOF2
$(uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=include$/\1/p" || true)
EOF2
  done
}

# Strip legacy single-VPN nft lines (vpn_* sets, mark 0x10000) from an autogenerated
# fqdn routing file. Only touches files whose first non-empty line matches the
# domain-routing generator banner. Backs up once as .legacy-vpnmark.bak.
# Returns 0 even when no change.
common_strip_legacy_vpnmark_from_autogen_nft() {
  nft_path="${1:-}"

  [ -n "$nft_path" ] || return 0
  [ -f "$nft_path" ] || return 0
  grep -qE 'vpn_fqdn4|vpn_fqdn6|vpn_prefixes4|vpn_prefixes6|@vpn_|set vpn_|meta mark set 0x00010000|meta mark set 0x10000' "$nft_path" 2>/dev/null || return 0

  first_line="$(sed -n '/[^[:space:]]/p' "$nft_path" | head -n1)"
  case "$first_line" in
    '# autogenerated by domain-routing'*) ;;
    *) return 0 ;;
  esac

  tmp="${nft_path}.strip.$$"
  grep -vE 'vpn_fqdn4|vpn_fqdn6|vpn_prefixes4|vpn_prefixes6|@vpn_|set vpn_|meta mark set 0x00010000|meta mark set 0x10000' "$nft_path" > "$tmp" 2>/dev/null || {
    rm -f "$tmp"
    return 0
  }

  if command -v nft >/dev/null 2>&1; then
    if ! nft -c -f "$tmp" >/dev/null 2>&1; then
      warn "strip legacy nft: синтаксис после вырезания неверен, откат: $nft_path"
      rm -f "$tmp"
      return 0
    fi
  fi

  if cmp -s "$nft_path" "$tmp" 2>/dev/null; then
    rm -f "$tmp"
    return 0
  fi

  [ -f "${nft_path}.legacy-vpnmark.bak" ] || cp -a "$nft_path" "${nft_path}.legacy-vpnmark.bak" 2>/dev/null || true
  mv -f "$tmp" "$nft_path"
  info "Вырезаны legacy-строки vpn_* / 0x10000 из $nft_path"
}

# Только таблицы с префиксом route_table_prefix, runtime-файлы toolbox, generated,
# uci confdir для dnsmasq toolbox, rt_tables без vpnmark.
# Аргументы 1–8 как у common_cleanup_domain_routing_owned.
common_cleanup_domain_routing_core() {
  route_table_prefix="$1"
  nft_file="$2"
  dnsmasq_file="$3"
  hotplug_file="$4"
  dnsmasq_dir="$5"
  system_generated_dir="$6"
  system_interfaces_dir="$7"
  legacy_mode="${8:-1}"

  [ -n "$route_table_prefix" ] || die "common_cleanup_domain_routing_core: route_table_prefix не задан"
  [ -n "$nft_file" ] || die "common_cleanup_domain_routing_core: nft_file не задан"
  [ -n "$dnsmasq_file" ] || die "common_cleanup_domain_routing_core: dnsmasq_file не задан"
  [ -n "$hotplug_file" ] || die "common_cleanup_domain_routing_core: hotplug_file не задан"
  [ -n "$dnsmasq_dir" ] || die "common_cleanup_domain_routing_core: dnsmasq_dir не задан"
  [ -n "$system_generated_dir" ] || die "common_cleanup_domain_routing_core: system_generated_dir не задан"
  [ -n "$system_interfaces_dir" ] || die "common_cleanup_domain_routing_core: system_interfaces_dir не задан"

  tmp_root="$(mktemp -d)"
  tmp_tables="$tmp_root/owned_tables.lst"
  tmp_rt="$tmp_root/rt_tables"
  : > "$tmp_tables"

  if command -v ip >/dev/null 2>&1; then
    ip rule show 2>/dev/null | awk -v p="$route_table_prefix" '
      {
        for (i = 1; i <= NF; i++) {
          if ($i == "lookup" && (i + 1) <= NF) {
            t = $(i + 1)
            if (index(t, p) == 1) print t
          }
        }
      }
    ' >> "$tmp_tables" || true
  fi

  if [ -f /etc/iproute2/rt_tables ]; then
    awk -v p="$route_table_prefix" '$2 ~ ("^" p) { print $2 }' /etc/iproute2/rt_tables >> "$tmp_tables" || true
  fi

  sort -u "$tmp_tables" -o "$tmp_tables"

  if [ -s "$tmp_tables" ]; then
    while IFS= read -r table_name; do
      [ -n "$table_name" ] || continue
      case "$table_name" in
        vpnmark) continue ;;
      esac
      info "Очищаю policy routing для таблицы: $table_name"
      while ip rule del lookup "$table_name" 2>/dev/null; do :; done
      ip route flush table "$table_name" 2>/dev/null || true
    done < "$tmp_tables"
  fi

  rm -f "$hotplug_file" "$dnsmasq_file" "$nft_file"
  rm -rf "$system_generated_dir" "$system_interfaces_dir"
  mkdir -p "$system_generated_dir" "$system_interfaces_dir"
  rmdir "$dnsmasq_dir" 2>/dev/null || true

  current_confdirs="$(uci -q get dhcp.@dnsmasq[0].confdir 2>/dev/null || true)"
  for d in $current_confdirs; do
    [ "$d" = "$dnsmasq_dir" ] && uci del_list dhcp.@dnsmasq[0].confdir="$dnsmasq_dir" 2>/dev/null || true
  done

  if [ -f /etc/iproute2/rt_tables ]; then
    cp -f /etc/iproute2/rt_tables "$tmp_rt"
    sed -i "\\|[[:space:]]$route_table_prefix|d" "$tmp_rt"
    cp -f "$tmp_rt" /etc/iproute2/rt_tables
  fi

  rm -rf "$tmp_root"
}

# vpnmark, firewall include (в т.ч. по содержимому), старые пути domain-routing,
# uci confdir domain-routing, строка vpnmark в rt_tables.
# Без legacy_mode=1 — no-op.
common_cleanup_domain_routing_legacy() {
  route_table_prefix="$1"
  nft_file="$2"
  dnsmasq_file="$3"
  hotplug_file="$4"
  dnsmasq_dir="$5"
  system_generated_dir="$6"
  system_interfaces_dir="$7"
  legacy_mode="${8:-1}"

  [ "$legacy_mode" = "1" ] || return 0

  [ -n "$nft_file" ] || die "common_cleanup_domain_routing_legacy: nft_file не задан"
  [ -n "$dnsmasq_dir" ] || die "common_cleanup_domain_routing_legacy: dnsmasq_dir не задан"
  [ -n "$hotplug_file" ] || die "common_cleanup_domain_routing_legacy: hotplug_file не задан"

  while ip rule del lookup vpnmark 2>/dev/null; do :; done
  while ip rule del fwmark 0x10000 lookup vpnmark pref 10000 2>/dev/null; do :; done
  while ip rule del fwmark 0x10000 lookup vpnmark 2>/dev/null; do :; done
  ip route flush table vpnmark 2>/dev/null || true

  legacy_content_scan=1
  common_firewall_remove_fqdn_includes "$nft_file" "1" "$legacy_content_scan"

  if [ "$nft_file" != "/etc/domain-routing/90-domain-routing.nft" ]; then
    rm -f /etc/domain-routing/90-domain-routing.nft 2>/dev/null || true
    rm -f /etc/domain-routing/90-xfree-toolbox-fqdn-routing.nft 2>/dev/null || true
    rm -f "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/domain-routing/90-domain-routing.nft" 2>/dev/null || true
    rm -f "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/domain-routing/90-xfree-toolbox-fqdn-routing.nft" 2>/dev/null || true
    rm -f "$(dirname -- "$nft_file")/90-domain-routing.nft" 2>/dev/null || true
  fi
  if [ "$hotplug_file" != "/etc/hotplug.d/iface/90-domain-routing" ]; then
    rm -f /etc/hotplug.d/iface/90-domain-routing 2>/dev/null || true
  fi
  if [ "$dnsmasq_file" != "/etc/dnsmasq.d/domain-routing/90-domain-routing.conf" ]; then
    rm -f /etc/dnsmasq.d/domain-routing/90-domain-routing.conf 2>/dev/null || true
    rm -f "$dnsmasq_dir/90-domain-routing.conf" 2>/dev/null || true
    rm -f "$dnsmasq_dir/90-xfree-toolbox-routing.conf" 2>/dev/null || true
  fi
  rmdir /etc/dnsmasq.d/domain-routing 2>/dev/null || true

  current_confdirs="$(uci -q get dhcp.@dnsmasq[0].confdir 2>/dev/null || true)"
  for d in $current_confdirs; do
    [ "$d" = "/etc/dnsmasq.d/domain-routing" ] && uci del_list dhcp.@dnsmasq[0].confdir="/etc/dnsmasq.d/domain-routing" 2>/dev/null || true
  done

  if [ -f /etc/iproute2/rt_tables ]; then
    tmp_rt="$(mktemp)"
    cp -f /etc/iproute2/rt_tables "$tmp_rt"
    sed -i '/[[:space:]]vpnmark\([[:space:]]\+\|$\)/d' "$tmp_rt"
    cp -f "$tmp_rt" /etc/iproute2/rt_tables
    rm -f "$tmp_rt"
  fi
}

# Полная очистка: core + legacy (для apply-routing и обратной совместимости).
common_cleanup_domain_routing_owned() {
  route_table_prefix="$1"
  nft_file="$2"
  dnsmasq_file="$3"
  hotplug_file="$4"
  dnsmasq_dir="$5"
  system_generated_dir="$6"
  system_interfaces_dir="$7"
  legacy_mode="${8:-1}"

  [ -n "$route_table_prefix" ] || die "common_cleanup_domain_routing_owned: route_table_prefix не задан"
  [ -n "$nft_file" ] || die "common_cleanup_domain_routing_owned: nft_file не задан"
  [ -n "$dnsmasq_file" ] || die "common_cleanup_domain_routing_owned: dnsmasq_file не задан"
  [ -n "$hotplug_file" ] || die "common_cleanup_domain_routing_owned: hotplug_file не задан"
  [ -n "$dnsmasq_dir" ] || die "common_cleanup_domain_routing_owned: dnsmasq_dir не задан"
  [ -n "$system_generated_dir" ] || die "common_cleanup_domain_routing_owned: system_generated_dir не задан"
  [ -n "$system_interfaces_dir" ] || die "common_cleanup_domain_routing_owned: system_interfaces_dir не задан"

  common_cleanup_domain_routing_core "$route_table_prefix" "$nft_file" "$dnsmasq_file" "$hotplug_file" "$dnsmasq_dir" "$system_generated_dir" "$system_interfaces_dir" "$legacy_mode"
  common_cleanup_domain_routing_legacy "$route_table_prefix" "$nft_file" "$dnsmasq_file" "$hotplug_file" "$dnsmasq_dir" "$system_generated_dir" "$system_interfaces_dir" "$legacy_mode"
}

common_normalize_token() {
  input="${1:-}"

  common_lower_ascii "$input" \
    | sed 's/[^a-z0-9._-]/-/g; s/-\{2,\}/-/g; s/^-//; s/-$//'
}

common_url_host() {
  url="${1:-}"
  host="${url#*://}"
  host="${host%%/*}"
  host="${host%%\?*}"
  host="${host%%\#*}"
  printf '%s\n' "$host" | tr -d '\r'
}

common_dns_id_from_url() {
  url="${1:-}"
  host="$(common_url_host "$url")"
  common_normalize_token "$host"
}

common_lower_ascii() {
  printf '%s' "${1:-}" | common_lower_ascii_stream
}

common_upper_ascii() {
  printf '%s' "${1:-}" | common_upper_ascii_stream
}

# OpenWrt/BusyBox tr may handle character classes such as '[:lower:]'
# and '[:upper:]' differently across builds/locales. Keep ASCII ranges here.
# shellcheck disable=SC2018,SC2019
common_lower_ascii_stream() {
  tr -d '\r' | tr 'A-Z' 'a-z'
}

# See common_lower_ascii_stream: do not replace with '[:lower:]'/'[:upper:]'.
# shellcheck disable=SC2018,SC2019
common_upper_ascii_stream() {
  tr -d '\r' | tr 'a-z' 'A-Z'
}

common_norm_domains_stream() {
  tr -d '\r' \
    | sed '/^[[:space:]]*$/d' \
    | sed '/^[[:space:]]*[#;]/d' \
    | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' \
    | common_lower_ascii_stream \
    | sort -u
}

# Internal: merge duplicate zone sections for one logical zone name (see common_firewall_dedupe_zones_by_name).
common_firewall_dedupe_flush_group() {
  fname="${1:-}"
  flist="${2:-}"
  [ -n "$fname" ] || return 0
  count=0
  set -f
  for _s in $(printf '%s\n' "$flist"); do
    [ -n "$_s" ] || continue
    count=$((count + 1))
  done
  [ "$count" -le 1 ] && {
    set +f
    return 0
  }

  keeper=""
  for s in $(printf '%s\n' "$flist"); do
    [ -n "$s" ] || continue
    if [ "$s" = "$fname" ]; then
      keeper="$s"
      break
    fi
  done
  [ -n "$keeper" ] || keeper="$(printf '%s\n' "$flist" | sed -n '1p')"

  for s in $(printf '%s\n' "$flist"); do
    [ -n "$s" ] || continue
    [ "$s" = "$keeper" ] && continue
    for net in $(uci -q get "firewall.$s.network" 2>/dev/null || true); do
      [ -n "$net" ] || continue
      have="$(uci -q get "firewall.$keeper.network" 2>/dev/null || true)"
      printf '%s\n' "$have" | tr ' ' '\n' | grep -Fxq "$net" 2>/dev/null && continue
      uci add_list "firewall.${keeper}.network=$net"
    done
    info "firewall: объединяю дубликат зоны name=$fname (секция $s -> $keeper)"
    uci -q delete "firewall.$s" || true
  done
  set +f
}

# fw4 emits one nft `define <zone.name>_devices` per zone name. Multiple UCI
# zone sections with the same `option name` break nft with "redefinition of symbol".
# Merge `list network` into one canonical section (prefer section id == name) and delete the rest.
common_firewall_dedupe_zones_by_name() {
  tab="$(printf '\t')"
  zones_list="$(
    { uci show firewall 2>/dev/null || true; } | sed -n 's/^firewall\.\([^.]*\)=zone$/\1/p' | while IFS= read -r sec || [ -n "$sec" ]; do
      [ -n "$sec" ] || continue
      zname="$(uci -q get "firewall.$sec.name" 2>/dev/null || true)"
      [ -n "$zname" ] || continue
      printf '%s%s%s\n' "$zname" "$tab" "$sec"
    done | LC_ALL=C sort -t "$tab" -k1,1 -k2,2
  )"

  cur_name=""
  cur_secs=""

  while IFS="$tab" read -r zname sec || [ -n "$zname" ]; do
    [ -n "$zname" ] && [ -n "$sec" ] || continue
    if [ -z "$cur_name" ]; then
      cur_name="$zname"
      cur_secs="$sec"
      continue
    fi
    if [ "$zname" = "$cur_name" ]; then
      cur_secs="$cur_secs
$sec"
      continue
    fi
    common_firewall_dedupe_flush_group "$cur_name" "$cur_secs"
    cur_name="$zname"
    cur_secs="$sec"
  done <<EOF2
$(printf '%s\n' "$zones_list")
EOF2

  common_firewall_dedupe_flush_group "$cur_name" "$cur_secs"
}

# GitHub CDN proxy (XFREE_GITHUB_PROXY, default 0; fallback gh-proxy only for githubusercontent.com). Loaded when ROOT_DIR or COMMON_SH is known.
if ! command -v http_github_proxy_url >/dev/null 2>&1; then
  _hgp=""
  if [ -n "${ROOT_DIR:-}" ] && [ -f "${ROOT_DIR}/lib/http-github-proxy.sh" ]; then
    _hgp="${ROOT_DIR}/lib/http-github-proxy.sh"
  elif [ -n "${COMMON_SH:-}" ] && [ -f "$(dirname -- "$COMMON_SH")/http-github-proxy.sh" ]; then
    _hgp="$(dirname -- "$COMMON_SH")/http-github-proxy.sh"
  fi
  if [ -n "$_hgp" ]; then
    # shellcheck disable=SC1090
    . "$_hgp"
  fi
  unset _hgp
fi
