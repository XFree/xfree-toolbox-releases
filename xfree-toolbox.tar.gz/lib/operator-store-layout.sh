#!/bin/sh
# shellcheck shell=sh
# Canonical VPN paths: ci/store/<id>/vpn/... and profiles/<name>/vpn/... (same shape).

# --- operator store (ci/store) ---

operator_store_proton_sessions_dir() {
    store_root="$1"
    store_id="$2"
    printf '%s/%s/vpn/proton/sessions\n' "$store_root" "$store_id"
}

operator_store_proton_conf_dir() {
    store_root="$1"
    store_id="$2"
    printf '%s/%s/vpn/proton/conf\n' "$store_root" "$store_id"
}

operator_store_warp_conf_dir() {
    store_root="$1"
    store_id="$2"
    printf '%s/%s/vpn/warp/conf\n' "$store_root" "$store_id"
}

operator_store_profile_dir() {
    store_root="$1"
    store_id="$2"
    printf '%s/%s/profile\n' "$store_root" "$store_id"
}

operator_store_resolve_proton_sessions_dir() {
    store_root="$1"
    store_id="$2"
    canonical="$(operator_store_proton_sessions_dir "$store_root" "$store_id")"
    legacy="$store_root/$store_id/session/proton"
    if [ -d "$canonical" ]; then
        printf '%s\n' "$canonical"
        return 0
    fi
    if [ -d "$legacy" ]; then
        printf '%s\n' "$legacy"
        return 0
    fi
    printf '%s\n' "$canonical"
}

# --- profile (profiles/<name>) ---

xfree_profile_proton_conf_dir() {
    profile_root="$1"
    printf '%s/vpn/proton/conf\n' "$profile_root"
}

xfree_profile_warp_conf_dir() {
    profile_root="$1"
    printf '%s/vpn/warp/conf\n' "$profile_root"
}

xfree_profile_proton_sessions_dir() {
    profile_root="$1"
    printf '%s/vpn/proton/sessions\n' "$profile_root"
}

# Legacy: *.conf directly under vpn/proton/ (not vpn/proton/conf/).
xfree_profile_legacy_proton_conf_dir() {
    profile_root="$1"
    printf '%s/vpn/proton\n' "$profile_root"
}

xfree_profile_legacy_warp_conf_dir() {
    profile_root="$1"
    printf '%s/vpn/warp\n' "$profile_root"
}

xfree_profile_dir_has_conf_files() {
    dir="$1"
    [ -d "$dir" ] || return 1
    for f in "$dir"/*.conf; do
        [ -f "$f" ] || continue
        return 0
    done
    return 1
}

xfree_profile_resolve_proton_conf_dir() {
    xfree_profile_proton_conf_dir "$1"
}

xfree_profile_resolve_warp_conf_dir() {
    xfree_profile_warp_conf_dir "$1"
}
