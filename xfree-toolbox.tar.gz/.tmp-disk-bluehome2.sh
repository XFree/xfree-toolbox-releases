#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo "=== backups ==="
du -sh /root/xfree-toolbox.backup.* 2>/dev/null || true
ls -lah /root/
echo
echo "=== /usr top ==="
du -sh /overlay/upper/usr/* 2>/dev/null | sort -hr | head -12
echo
echo "=== /opt top ==="
du -sh /overlay/upper/opt/* 2>/dev/null | sort -hr | head -10
echo
echo "=== if delete 3 backups, reclaim ==="
du -sc /root/xfree-toolbox.backup.* 2>/dev/null | tail -1
echo
echo "=== apk cache ==="
du -sh /overlay/upper/lib/apk/* 2>/dev/null | sort -hr | head -8
find /overlay/upper -name '*.apk' 2>/dev/null | head -10
REMOTE
