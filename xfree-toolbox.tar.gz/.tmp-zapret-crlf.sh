#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo '=== file types / CRLF on section.conf ==='
file /root/xfree-toolbox/profiles/default/zapret/sections/youtube_29/config/section.conf 2>/dev/null || true
od -c /root/xfree-toolbox/profiles/default/zapret/sections/youtube_29/config/section.conf | head -5
echo '=== apply-template.log today (zapret) ==='
grep -nE 'zapret|Секция|hostlist|youtube_29|ENABLED|CRLF|ошиб' /tmp/xfree-background-tasks/apply-template.log 2>/dev/null | tail -100 || true
echo '=== tail apply-template.log ==='
tail -80 /tmp/xfree-background-tasks/apply-template.log 2>/dev/null || true
echo '=== discord fqdn.d present? ==='
ls -la /root/xfree-toolbox/profiles/default/zapret/sections/discord/fqdn.d/ 2>&1 | head
wc -l /root/xfree-toolbox/profiles/default/zapret/sections/discord/fqdn.d/*.lst 2>/dev/null || true
echo '=== cdn-host fqdn ==='
ls /root/xfree-toolbox/profiles/default/zapret/sections/cdn-host/fqdn.d/ 2>&1 | head
wc -l /root/xfree-toolbox/profiles/default/zapret/sections/cdn-host/fqdn.d/*.lst 2>/dev/null || echo 0
echo '=== simulate load ENABLED ==='
# replicate zapret_load strip
conf=/root/xfree-toolbox/profiles/default/zapret/sections/youtube_29/config/section.conf
en=$(awk -F"'" '/^ZAPRET_SECTION_ENABLED=/ { print $2; exit }' "$conf")
printf 'raw en hex: '; printf '%s' "$en" | od -An -tx1
[ "${en:-1}" = "1" ] && echo 'shell eq 1: YES' || echo 'shell eq 1: NO'
REMOTE
