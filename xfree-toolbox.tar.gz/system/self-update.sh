#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
COMMON_SH="$ROOT_DIR/lib/common.sh"

[ -f "$COMMON_SH" ] || {
  echo "[-] common.sh не найден: $COMMON_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"
UPDATE_ETAG_SH="$ROOT_DIR/lib/update-etag.sh"
if [ -f "$UPDATE_ETAG_SH" ]; then
  # shellcheck disable=SC1090
  . "$UPDATE_ETAG_SH"
else
  warn "update-etag.sh не найден в $ROOT_DIR — stamp ETag после tar может быть недоступен"
fi
load_base_config "$ROOT_DIR"

INSTALL_CHANNEL_SH="$ROOT_DIR/lib/install-channel.sh"
APK_REGISTRY_SH="$ROOT_DIR/lib/apk-registry.sh"
FEED_BASE="${FEED_BASE:-${XFREE_APK_FEED_PUBLIC_BASE:-https://xfree-cloud.duckdns.org/public.php/dav/files/GFqGBrf6giHzpZQ}}"
PUBKEY_BASENAME="${XFREE_APK_PUBKEY_NAME:-xfree-toolbox.pub}"

if [ -f "$INSTALL_CHANNEL_SH" ]; then
  # shellcheck disable=SC1090
  . "$INSTALL_CHANNEL_SH"
fi
if [ -f "$APK_REGISTRY_SH" ]; then
  # shellcheck disable=SC1090
  . "$APK_REGISTRY_SH"
fi

UPDATE_URL="${UPDATE_URL:-${XFREE_UPDATE_URL:-https://xfree-cloud.duckdns.org/public.php/dav/files/xkwFs6doydiM4Pw}}"
FACTORY_PUBLIC_BASE="${FACTORY_PUBLIC_BASE:-${XFREE_FACTORY_PUBLIC_BASE:-https://xfree-cloud.duckdns.org/public.php/dav/files/L982AaEEYAHYtTj}}"
INSTALL_SCRIPT_NAME="${INSTALL_SCRIPT_NAME:-${XFREE_INSTALL_SCRIPT_NAME:-install-from-cloud.sh}}"
APK_REPOS_DIR="${ROUTER_APK_REPOS_DIR:-/etc/apk/repositories.d}"
APK_REPO_FILE="${ROUTER_APK_REPO_FILE:-xfree-toolbox.list}"
APK_PKG_NAME="${XFREE_APK_PACKAGE_NAME:-xfree-toolbox}"
OWRT_LIB="$ROOT_DIR/lib/owrt-release.sh"
TARGET_DIR="${TARGET_DIR:-/root/xfree-toolbox}"
LEGACY_TARGET_DIR="${LEGACY_TARGET_DIR:-/root/xfree-utils}"
BACKUP_ROOT="${BACKUP_ROOT:-$(dirname -- "$TARGET_DIR")}"
BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"
ARCHIVE_NAME="${ARCHIVE_NAME:-xfree-toolbox.tar.gz}"
LOG_FILE="${LOG_FILE:-$TARGET_DIR/update.log}"
COMMON_DIE_LOG_FILE="$LOG_FILE"

ETAG_FILE="$TARGET_DIR/.update-etag"
LASTMOD_FILE="$TARGET_DIR/.update-lastmodified"

MENU_RESTART_FLAG="${XFREE_MENU_RESTART_FLAG:-}"
LAUNCHER_NAME="${XFREE_LAUNCHER_NAME:-xft}"

TMP_DIR=""
NEW_DIR=""
BACKUP_DIR=""
BACKUP_RESTORE_DIR=""
SWITCH_DONE=0
REMOTE_ETAG=""
REMOTE_LASTMOD=""
LOCAL_ETAG=""
SILENT=0
CHECK_ONLY=0
FORCE=0
USE_TAR=0
PRESERVE_PROFILES="${PRESERVE_PROFILES:-1}"
SOURCE_DIR=""

log_file() {
  mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE" 2>/dev/null || true
}

cleanup() {
  if [ -n "${TMP_DIR:-}" ] && [ -d "$TMP_DIR" ]; then
    rm -rf "$TMP_DIR"
  fi
  return 0
}

rollback() {
  if [ "$SWITCH_DONE" -eq 0 ] && [ -n "${BACKUP_DIR:-}" ] && [ -d "${BACKUP_DIR:-}" ]; then
    warn "Ошибка во время обновления. Выполняю rollback."
    log_file "[WARN] rollback start"
    restore_dir="${BACKUP_RESTORE_DIR:-$TARGET_DIR}"
    rm -rf "$restore_dir" 2>/dev/null || true
    mv "$BACKUP_DIR" "$restore_dir" 2>/dev/null || true
    log_file "[INFO] rollback completed"
    success "Rollback выполнен"
  fi
  return 0
}

trap 'cleanup' EXIT
trap 'rollback; cleanup' INT TERM HUP

usage() {
  cat <<EOF
Usage: $0 [--silent] [--check-only] [--force] [--preserve-profiles|--replace-profiles] [--source-dir <dir>]

  Обёртка обновления: проверка версии здесь; установка/upgrade — через install-from-cloud.sh
  (GitHub raw, если /etc/xfree-toolbox/apk-feed.env = github; иначе Nextcloud factory).

  --silent             Минимум вывода
  --check-only         Проверка: apk (25+: upgrade или apk add если пакет ещё не в world) / tar (ETag); exit 0 / 10
  --use-tar            Принудительно tar (ETag / install-from-cloud --use-tar), не apk
  --force              Передать --force в cloud install (tar) или выполнить при --source-dir
  --preserve-profiles  Сохранить profiles/ (по умолчанию)
  --replace-profiles   Устарел: то же, что --preserve-profiles
  --source-dir <dir>   Локальная установка tar-дерева (dev/CI; без cloud install-from-cloud)
EOF
}

trim_trailing_slash() {
  _v="$1"
  while [ -n "$_v" ]; do
    case "$_v" in
      */) _v="${_v%/}" ;;
      *) break ;;
    esac
  done
  printf '%s' "$_v"
}

cloud_install_public_url() {
  _u=""
  if command -v xfree_apk_feed_install_url >/dev/null 2>&1; then
    _u="$(xfree_apk_feed_install_url 2>/dev/null || true)"
  fi
  if [ -n "$_u" ]; then
    printf '%s\n' "$_u"
    return 0
  fi
  _base="$(trim_trailing_slash "${FACTORY_PUBLIC_BASE:-}")"
  [ -n "$_base" ] || die "XFREE_FACTORY_PUBLIC_BASE не задан (или источник GitHub в apk-feed.env)"
  printf '%s/%s\n' "$_base" "$INSTALL_SCRIPT_NAME"
}

self_update_tar_url() {
  _u=""
  if command -v xfree_apk_feed_tar_url >/dev/null 2>&1; then
    _u="$(xfree_apk_feed_tar_url 2>/dev/null || true)"
  fi
  if [ -n "$_u" ]; then
    printf '%s\n' "$_u"
    return 0
  fi
  printf '%s\n' "$UPDATE_URL"
}

self_update_fetch() {
  _dst="$1"
  _url="$2"
  if command -v http_fetch_file >/dev/null 2>&1; then
    http_fetch_file "$_url" "$_dst"
    return
  fi
  if command -v curl >/dev/null 2>&1; then
    curl --http1.1 -fL --retry 3 --connect-timeout 15 -o "$_dst" "$_url"
    return
  fi
  if command -v wget >/dev/null 2>&1; then
    wget -O "$_dst" "$_url"
    return
  fi
  return 1
}

detect_check_channel() {
  if command -v xfree_resolve_update_channel >/dev/null 2>&1; then
    xfree_resolve_update_channel
    return 0
  fi
  [ "$USE_TAR" -eq 1 ] && printf '%s\n' tar && return 0
  printf '%s\n' tar
}

check_apk_updates() {
  command -v apk >/dev/null 2>&1 || die "apk не найден (OpenWrt 25+)"

  if command -v xfree_ensure_apk_registry >/dev/null 2>&1; then
    if xfree_apk_registry_configured 2>/dev/null; then
      printf '[*] Registry        : configured\n'
    elif xfree_ensure_apk_registry; then
      printf '[*] Registry        : %s\n' "${XFREE_APK_REGISTRY_STATUS:-auto-configured}"
    else
      warn "Не удалось настроить apk registry (pubkey: ${XFREE_APK_REGISTRY_LAST_FETCH_URL:-<url?>}; нужны XFREE_APK_FEED_PUBLIC_BASE и XFREE_FACTORY_PUBLIC_BASE)"
      return 1
    fi
  elif [ ! -f "$APK_REPOS_DIR/$APK_REPO_FILE" ]; then
    warn "Реестр apk не настроен ($APK_REPOS_DIR/$APK_REPO_FILE)"
    return 1
  fi

  if [ "${XFREE_BG_TASK:-0}" = "1" ]; then
    [ "$SILENT" -eq 0 ] && info "Проверка apk ($APK_PKG_NAME), без apk update (фоновая задача)"
  else
    [ "$SILENT" -eq 0 ] && info "Проверка обновления apk ($APK_PKG_NAME)"
    apk update --force-missing-repositories 2>&1 || warn "apk update: см. UNTRUSTED / реестр"
  fi

  if command -v xfree_apk_print_feed_check >/dev/null 2>&1; then
    xfree_apk_print_feed_check "$APK_PKG_NAME" || return 1
  else
    warn "lib/install-channel.sh без xfree_apk_print_feed_check"
    return 1
  fi

  case "${XFREE_APK_CHECK_ACTION:-none}" in
    add)
      success "Пакет apk не установлен — в фиде есть $APK_PKG_NAME (apk add, дальше apk upgrade)"
      log_file "[INFO] check-only: apk add available"
      exit 10
      ;;
    upgrade)
      success "Доступно обновление (apk)"
      log_file "[INFO] check-only: apk update available"
      exit 10
      ;;
    *)
      success "Обновлений apk нет"
      log_file "[INFO] check-only: apk no update"
      exit 0
      ;;
  esac
}

check_tar_updates() {
  if [ -n "$SOURCE_DIR" ]; then
    die "--check-only не поддерживается вместе с --source-dir"
  fi

  info "Проверяю опубликованную версию (tar)"
  fetch_remote_props
  LOCAL_ETAG="$(read_local_etag)"

  if [ -n "$LOCAL_ETAG" ] && [ "$REMOTE_ETAG" = "$LOCAL_ETAG" ] && [ "$FORCE" -eq 0 ]; then
    success "Новая версия отсутствует"
    printf '%s\n' ""
    print_check_report
    log_file "[INFO] check-only: no update, remote_etag=$REMOTE_ETAG"
    exit 0
  fi

  success "Доступна новая версия"
  printf '%s\n' ""
  print_check_report
  log_file "[INFO] check-only: update available, remote_etag=$REMOTE_ETAG local_etag=${LOCAL_ETAG:-<none>}"
  exit 10
}

run_check_only() {
  if command -v xfree_print_openwrt_version_line >/dev/null 2>&1; then
    xfree_print_openwrt_version_line
  fi
  _channel="$(detect_check_channel)"
  printf '[*] Channel         : %s\n' "$_channel"
  [ -n "${XFREE_CHANNEL_REASON:-}" ] && printf '[*] Channel reason  : %s\n' "$XFREE_CHANNEL_REASON"
  case "$_channel" in
    apk)
      if check_apk_updates; then
        :
      else
        _tar_fallback=1
        if [ "$USE_TAR" -eq 0 ] && command -v owrt_release_load >/dev/null 2>&1 \
          && owrt_release_load && [ "${OWRT_RELEASE_MAJOR:-0}" -ge 25 ] 2>/dev/null; then
          _tar_fallback=0
          die "Проверка apk не удалась (см. выше). На OpenWrt 25+ tar fallback отключён; исправьте XFREE_FACTORY_PUBLIC_BASE / XFREE_APK_FEED_PUBLIC_BASE в config.sh"
        fi
        if [ "$_tar_fallback" -eq 1 ]; then
          warn "apk check не удался — fallback tar"
          check_tar_updates
        fi
      fi
      ;;
    *)
      check_tar_updates
      ;;
  esac
}

run_cloud_install_script() {
  _url="$(cloud_install_public_url)"
  _tmp="/tmp/${INSTALL_SCRIPT_NAME}.$$"
  info "Скачиваю install-from-cloud: $_url"
  log_file "[INFO] wget cloud install $_url"

  self_update_fetch "$_tmp" "$_url" || die "Не удалось скачать install-from-cloud.sh"

  [ -s "$_tmp" ] || die "Скачан пустой install-from-cloud.sh (404?)"

  chmod +x "$_tmp" 2>/dev/null || true

  _forward=""
  [ "$SILENT" -eq 1 ] && _forward="$_forward --silent"
  [ "$PRESERVE_PROFILES" -eq 1 ] && _forward="$_forward --preserve-profiles"
  [ "$FORCE" -eq 1 ] && _forward="$_forward --force"
  [ "$USE_TAR" -eq 1 ] && _forward="$_forward --use-tar"
  if command -v xfree_apk_feed_load_state >/dev/null 2>&1; then
    xfree_apk_feed_load_state
    [ "${XFREE_APK_FEED_SOURCE:-}" = github ] && _forward="$_forward --source github"
  fi

  # shellcheck disable=SC2086
  exec sh "$_tmp" $_forward
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --silent) SILENT=1 ;;
      --check-only) CHECK_ONLY=1 ;;
      --force) FORCE=1 ;;
      --use-tar) USE_TAR=1 ;;
      --preserve-profiles) PRESERVE_PROFILES=1 ;;
      --replace-profiles)
        echo "[!] --replace-profiles устарел: profiles/ не перезаписываются из архива." >&2
        PRESERVE_PROFILES=1
        ;;
      --source-dir)
        shift
        [ $# -gt 0 ] || die "--source-dir требует путь"
        SOURCE_DIR="$1"
        ;;
      -h|--help)
        usage
        exit 0
        ;;
      *)
        die "Неизвестный аргумент: $1"
        ;;
    esac
    shift
  done
}

prepare_new_tree_from_source_dir() {
  [ -n "$SOURCE_DIR" ] || die "SOURCE_DIR пустой"
  [ -d "$SOURCE_DIR" ] || die "Не найден --source-dir: $SOURCE_DIR"
  [ -f "$SOURCE_DIR/menu.sh" ] || die "--source-dir не похож на xfree-toolbox (нет menu.sh): $SOURCE_DIR"
  [ -d "$SOURCE_DIR/lib" ] || die "--source-dir не похож на xfree-toolbox (нет lib): $SOURCE_DIR"

  info "Использую локальный source dir: $SOURCE_DIR"
  cp -a "$SOURCE_DIR"/. "$NEW_DIR"/
}

read_local_etag() {
  if command -v xfree_read_local_etag >/dev/null 2>&1; then
    xfree_read_local_etag "$TARGET_DIR"
    return 0
  fi
  if [ -f "$ETAG_FILE" ]; then
    head -n1 "$ETAG_FILE" | tr -d '\r\n'
  else
    printf '%s' ""
  fi
}

fetch_remote_props() {
  _url="$(self_update_tar_url)"
  xfree_fetch_remote_tar_props "$_url" \
    || die "Не удалось получить remote ETag (PROPFIND/HEAD; url=$_url)"
  REMOTE_ETAG="$XFREE_REMOTE_ETAG"
  REMOTE_LASTMOD="$XFREE_REMOTE_LASTMOD"
}

download_archive() {
  local archive_path="$TMP_DIR/$ARCHIVE_NAME"
  _url="$(self_update_tar_url)"
  self_update_fetch "$archive_path" "$_url" || die "Не найден ни curl, ни wget (или скачивание не удалось: $_url)"
}

validate_new_tree() {
  [ -d "$NEW_DIR" ] || die "Не создан каталог распаковки"
  [ -f "$NEW_DIR/menu.sh" ] || die "В архиве отсутствует menu.sh"
  [ -d "$NEW_DIR/lib" ] || die "В архиве отсутствует каталог lib"

  find "$NEW_DIR" -type f -name '*.sh' -exec chmod +x {} \;
}

cleanup_old_backups() {
  # Backup policy: keep BACKUP_KEEP newest install snapshots next to TARGET_DIR.
  [ -d "$BACKUP_ROOT" ] || return 0

  common_backup_rotate "$BACKUP_ROOT" "$(basename -- "$TARGET_DIR").backup" "$BACKUP_KEEP"
}

preserve_install_tree_profile_dirs() {
  if [ "$PRESERVE_PROFILES" != "1" ]; then
    echo "[!] --replace-profiles устарел: profiles/ не перезаписываются из архива." >&2
  fi

  profiles_src=""
  if [ -d "$TARGET_DIR/profiles" ]; then
    profiles_src="$TARGET_DIR/profiles"
  elif [ -n "$LEGACY_TARGET_DIR" ] && [ "$LEGACY_TARGET_DIR" != "$TARGET_DIR" ] && [ -d "$LEGACY_TARGET_DIR/profiles" ]; then
    profiles_src="$LEGACY_TARGET_DIR/profiles"
  fi

  tree_source="${SOURCE_DIR:-$NEW_DIR}"
  if [ -n "$profiles_src" ]; then
    info "Сохраняю текущие profiles из $profiles_src"
    log_file "[INFO] profiles preserved from current install"
  else
    info "profiles/: каталог на роутере будет создан при установке (без копирования из архива)"
  fi
  xfree_install_materialize_profiles_dir "$tree_source" "$NEW_DIR" "$profiles_src"

  # profile-templates/ — только из пакета (как apk). Не сливать старые файлы с роутера.
  if [ -d "$tree_source/profile-templates" ]; then
    info "profile-templates/: замена из пакета (apk-семантика, без leftover)"
    xfree_install_replace_profile_templates_dir "$tree_source" "$NEW_DIR"
  fi
}

save_remote_props() {
  xfree_save_installed_tar_props "$TARGET_DIR" "$REMOTE_ETAG" "$REMOTE_LASTMOD" \
    || die "Не удалось сохранить local ETag"
}

request_menu_restart() {
  [ -n "$MENU_RESTART_FLAG" ] || return 0
  mkdir -p "$(dirname "$MENU_RESTART_FLAG")" 2>/dev/null || true
  printf '%s\n' "$TARGET_DIR/menu.sh" > "$MENU_RESTART_FLAG"
}

print_check_report() {
  _local_ver=""
  if command -v xfree_read_local_version >/dev/null 2>&1; then
    _local_ver="$(xfree_read_local_version "$TARGET_DIR")"
  elif [ -f "$TARGET_DIR/VERSION" ]; then
    _local_ver="$(head -n1 "$TARGET_DIR/VERSION" | tr -d '\r\n')"
  fi
  printf '%s\n' "[*] Remote ETag     : $REMOTE_ETAG"
  printf '%s\n' "[*] Local ETag      : ${LOCAL_ETAG:-<none>}"
  printf '%s\n' "[*] Local version   : ${_local_ver:-<none>}"
  printf '%s\n' "[*] Remote modified : ${REMOTE_LASTMOD:-<unknown>}"
  printf '%s\n' ""
}

ensure_launcher_command() {
  launcher="$LAUNCHER_NAME"
  [ -n "$launcher" ] || return 0
  desired="$TARGET_DIR/menu.sh"
  [ -f "$desired" ] || return 0

  for bin_dir in /usr/bin /usr/sbin; do
    [ -d "$bin_dir" ] || continue
    if [ -w "$bin_dir" ] || [ -w "$bin_dir/$launcher" ]; then
      ln -sfn "$desired" "$bin_dir/$launcher" 2>/dev/null || true
      if command -v "$launcher" >/dev/null 2>&1; then
        log_file "[INFO] launcher configured: $launcher -> $desired"
        return 0
      fi
    fi
  done

  warn "Не удалось автоматически настроить launcher '$launcher' (нет прав на /usr/bin или /usr/sbin)"
  warn "Выполните вручную: ln -sfn $desired /usr/bin/$launcher"
  log_file "[WARN] launcher setup failed: $launcher"
}

main() {
  parse_args "$@"

  if [ "$CHECK_ONLY" -eq 1 ]; then
    run_check_only
  fi

  if [ -z "$SOURCE_DIR" ]; then
    run_cloud_install_script
  fi

  require_cmd tar
  require_cmd mktemp
  require_cmd find
  require_cmd cp
  require_cmd mv
  require_cmd sed
  require_cmd grep
  require_cmd cut
  require_cmd head

  LOCAL_ETAG="$(read_local_etag)"
  info "Local source update mode"
  info "Local ETag      : ${LOCAL_ETAG:-<none>}"

  TMP_DIR="$(mktemp -d /tmp/xfree-update.XXXXXX)"
  NEW_DIR="$TMP_DIR/new"

  mkdir -p "$NEW_DIR"
  mkdir -p "$BACKUP_ROOT"

  prepare_new_tree_from_source_dir

  info "Проверяю структуру"
  validate_new_tree
  preserve_install_tree_profile_dirs

  if [ -d "$TARGET_DIR" ]; then
    # Backup policy: rollback copy next to TARGET_DIR for easy manual rollback.
    BACKUP_DIR="$BACKUP_ROOT/$(basename -- "$TARGET_DIR").backup.$(backup_stamp_now)"
    BACKUP_RESTORE_DIR="$TARGET_DIR"
    info "Создаю backup: $BACKUP_DIR"
    log_file "[INFO] backup created: $BACKUP_DIR"
    mv "$TARGET_DIR" "$BACKUP_DIR"
  elif [ -n "$LEGACY_TARGET_DIR" ] && [ "$LEGACY_TARGET_DIR" != "$TARGET_DIR" ] && [ -d "$LEGACY_TARGET_DIR" ] && [ ! -L "$LEGACY_TARGET_DIR" ]; then
    legacy_base="$(basename -- "$LEGACY_TARGET_DIR")"
    BACKUP_DIR="$BACKUP_ROOT/$legacy_base.backup.$(backup_stamp_now)"
    BACKUP_RESTORE_DIR="$LEGACY_TARGET_DIR"
    info "Создаю backup legacy install: $BACKUP_DIR"
    log_file "[INFO] legacy backup created: $BACKUP_DIR"
    mv "$LEGACY_TARGET_DIR" "$BACKUP_DIR"
  fi

  info "Устанавливаю новую версию"
  mkdir -p "$TARGET_DIR"
  cp -a "$NEW_DIR"/. "$TARGET_DIR"/

  [ -f "$TARGET_DIR/menu.sh" ] || die "После установки отсутствует menu.sh"
  [ -d "$TARGET_DIR/lib" ] || die "После установки отсутствует каталог lib"

  if [ -n "$LEGACY_TARGET_DIR" ] && [ "$LEGACY_TARGET_DIR" != "$TARGET_DIR" ] && [ ! -e "$LEGACY_TARGET_DIR" ]; then
    ln -s "$TARGET_DIR" "$LEGACY_TARGET_DIR" 2>/dev/null || true
  fi

  update_source_file="$TARGET_DIR/.last-update-source"
  printf '%s\n' "self-update:source-dir" > "$update_source_file" 2>/dev/null || true
  if command -v xfree_update_etag_load_lib >/dev/null 2>&1; then
    xfree_update_etag_load_lib "$TARGET_DIR" || true
  elif [ -f "$TARGET_DIR/lib/update-etag.sh" ]; then
    # shellcheck disable=SC1090
    . "$TARGET_DIR/lib/update-etag.sh"
  fi
  if command -v xfree_stamp_installed_tar_etag >/dev/null 2>&1; then
    _stamp_url="$(self_update_tar_url)"
    xfree_stamp_installed_tar_etag "$TARGET_DIR" "$_stamp_url"
  fi
  SWITCH_DONE=1
  cleanup_old_backups

  ensure_launcher_command

  if [ -f "$TARGET_DIR/system/install-finish.sh" ]; then
    sh "$TARGET_DIR/system/install-finish.sh" "$TARGET_DIR"
  else
    warn "install-finish.sh отсутствует — hooks/launcher вручную"
    if [ -f "$TARGET_DIR/system/hardware/install-sbin-links.sh" ]; then
      # shellcheck disable=SC1090
      . "$TARGET_DIR/system/hardware/install-sbin-links.sh"
      install_hardware_sbin_links "$TARGET_DIR" || true
    fi
    if [ -f "$TARGET_DIR/system/hardware/install-button-hooks.sh" ]; then
      sh "$TARGET_DIR/system/hardware/install-button-hooks.sh" --install "$TARGET_DIR" \
        >>/tmp/xfree-postinst.log 2>&1 || true
    fi
    if [ -f "$TARGET_DIR/system/hardware/install-wps-trace-hook.sh" ]; then
      sh "$TARGET_DIR/system/hardware/install-wps-trace-hook.sh" --install \
        >>/tmp/xfree-postinst.log 2>&1 || true
    fi
    if [ -f "$TARGET_DIR/system/hardware/usb-power-watch-upgrade.sh" ]; then
      sh "$TARGET_DIR/system/hardware/usb-power-watch-upgrade.sh" --on-deploy --quiet "$TARGET_DIR" \
        >>/tmp/xfree-postinst.log 2>&1 || true
    fi
  fi

  success "Обновление завершено"
  log_file "[INFO] local-source update completed, source_dir=$SOURCE_DIR"

  request_menu_restart
}

main "$@"
