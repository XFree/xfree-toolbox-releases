#!/bin/sh
# shellcheck shell=sh
# После установки/замены базовых пакетов: dnsmasq restart; при замене wpad — reboot
# (network restart / wifi reload не поднимают radio под новый hostapd).
# $3 — restart dnsmasq (0|1), $4 — wpad-mesh заменён/установлен впервые (0|1).

pm_post_install_reboot_after_wpad() {
  silent="${1:-0}"
  [ "$silent" = "0" ] && info "Перезагрузка: смена wpad не поднимает radio через network restart"
  sync
  # -d: дать SSH дочитать лог; соединение всё равно оборвётся.
  reboot -d 2 2>/dev/null || reboot
}

pm_post_install_refresh() {
  local root="${1:-}"
  local silent="${2:-0}"
  local refresh_dnsmasq="${3:-0}"
  local refresh_wpad="${4:-0}"

  [ -n "$root" ] || return 0
  [ -f "$root/lib/common.sh" ] || return 0

  # shellcheck disable=SC1090
  . "$root/lib/common.sh"

  command -v opkg >/dev/null 2>&1 || command -v apk >/dev/null 2>&1 || return 0
  [ -f "$root/lib/pkgmgr.sh" ] || return 0

  # shellcheck disable=SC1090
  . "$root/lib/pkgmgr.sh"

  if [ "$refresh_dnsmasq" = "1" ] && pm_is_installed dnsmasq-full && [ -x /etc/init.d/dnsmasq ]; then
    [ "$silent" = "0" ] && info "Перезапуск dnsmasq после замены dnsmasq-full…"
    /etc/init.d/dnsmasq restart 2>/dev/null || warn "dnsmasq restart завершился с ошибкой"
  fi

  if [ "$refresh_wpad" = "1" ] && [ "${XFREE_BG_TASK:-0}" != "1" ] && pm_is_installed wpad-mesh-mbedtls; then
    _hooks="$root/system/hardware/install-button-hooks.sh"
    if [ -f "$_hooks" ]; then
      [ "$silent" = "0" ] && info "Проверка WPS hotplug после wpad-mesh-mbedtls…"
      sh "$_hooks" --ensure --quiet "$root" 2>/dev/null \
        || warn "install-button-hooks --ensure после wpad-mesh завершился с ошибкой"
    fi
    pm_update_index_optional
    pm_post_install_reboot_after_wpad "$silent"
    return 0
  fi

  if [ "$refresh_dnsmasq" = "1" ]; then
    pm_update_index_optional
  fi
  return 0
}
