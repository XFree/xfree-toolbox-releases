#!/bin/sh
# Проверка и установка базовых пакетов OpenWrt (system/base-packages.sh).
# Вызывается из menu.sh, install-from-cloud.sh (--menu / --apply-template), вручную.
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
YES=0
SILENT=0

usage() {
  cat <<'USAGE'
Usage: ensure-base-packages.sh [--root <toolbox-dir>] [--yes] [--silent]

Устанавливает недостающие пакеты из system/base-packages.sh через system/install.sh.
Если всё уже установлено — завершается без apk/opkg update.
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --root)
      shift
      [ "$#" -gt 0 ] || { echo "[-] --root требует путь" >&2; exit 1; }
      ROOT_DIR="$(CDPATH= cd -- "$1" && pwd -P)"
      ;;
    --yes) YES=1 ;;
    --silent) SILENT=1 ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[-] Неизвестный аргумент: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift
done

COMMON_SH="$ROOT_DIR/lib/common.sh"
[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
# shellcheck disable=SC1090
. "$COMMON_SH"
# shellcheck disable=SC1090
. "$ROOT_DIR/lib/pkgmgr.sh"

BASE_SH="$ROOT_DIR/system/base-packages.sh"
INSTALL_SH="$ROOT_DIR/system/install.sh"
[ -f "$BASE_SH" ] || { echo "[-] Не найден base-packages.sh: $BASE_SH" >&2; exit 1; }
# shellcheck disable=SC1090
. "$BASE_SH"
# shellcheck disable=SC1090
. "$SCRIPT_DIR/lib/base-packages-check.sh"

missing="$(list_missing_base_packages || true)"
if [ -z "${missing:-}" ]; then
  [ "$SILENT" = "0" ] && info "Базовые пакеты xfree-toolbox уже установлены"
  exit 0
fi

if [ "$SILENT" = "0" ]; then
  printf '\n[!] Не хватает базовых пакетов для xfree-toolbox:\n' >&2
  printf '%s\n' "$missing" | sed 's/^/  - /' >&2
fi

[ -f "$INSTALL_SH" ] || die "Не найден install.sh: $INSTALL_SH"
[ -x "$INSTALL_SH" ] || chmod +x "$INSTALL_SH" 2>/dev/null || true

[ "$SILENT" = "0" ] && info "Устанавливаю базовые пакеты ($PM)…"
_install_flags=""
[ "$YES" = "1" ] && _install_flags="$_install_flags --yes"
[ "$SILENT" = "1" ] && _install_flags="$_install_flags --silent --no-ru --no-update"
# shellcheck disable=SC2086
sh "$INSTALL_SH" $_install_flags || die "install.sh завершился с ошибкой"

missing_after="$(list_missing_base_packages || true)"
[ -z "${missing_after:-}" ] || die "После install.sh не хватает пакетов: $missing_after"

optional_missing="$(list_missing_optional_base_packages || true)"
if [ -n "${optional_missing:-}" ]; then
  if [ "$SILENT" = "0" ]; then
    warn "Необязательные пакеты не установлены (apply-template не блокируется):"
    printf '%s\n' "$optional_missing" | sed 's/^/  - /' >&2
  fi
fi

[ "$SILENT" = "0" ] && success "Базовые пакеты установлены"
