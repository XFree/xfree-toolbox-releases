#!/bin/sh
# shellcheck shell=sh
# Shared post-install finish for apk postinst and tar bootstrap/self-update.
# Payload files (including profile-templates/) must already be on disk.
# profiles/ are restored from a stash when --restore-profiles-from is set
# (apk preinst / tar keep), matching apk upgrade semantics.
set -eu

ROOT=""
RESTORE_PROFILES_FROM=""
LAUNCHER="${XFREE_LAUNCHER_NAME:-xft}"
LOG="${XFREE_POSTINST_LOG:-/tmp/xfree-postinst.log}"

usage() {
  cat <<EOF
Usage: $(basename "$0") <toolbox-root> [--restore-profiles-from <dir>]

Finish install/upgrade after package files are in place:
  chmod *.sh, launcher symlink, hardware hooks, optional profiles restore,
  sync-runtime-status, rpcd reload.
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    -h|--help)
      usage
      exit 0
      ;;
    --restore-profiles-from)
      shift
      [ "$#" -gt 0 ] || {
        echo "[-] --restore-profiles-from требует каталог" >&2
        exit 1
      }
      RESTORE_PROFILES_FROM="$1"
      ;;
    *)
      if [ -z "$ROOT" ]; then
        ROOT="$1"
      else
        echo "[-] Неизвестный аргумент: $1" >&2
        exit 1
      fi
      ;;
  esac
  shift || true
done

[ -n "$ROOT" ] || {
  usage >&2
  exit 1
}
[ -d "$ROOT" ] || {
  echo "[-] toolbox root не найден: $ROOT" >&2
  exit 1
}

if [ -d "$ROOT" ]; then
  find "$ROOT" -type f -name "*.sh" -exec chmod +x {} \; 2>/dev/null || true
fi

if [ -f "$ROOT/menu.sh" ]; then
  for bin_dir in /usr/bin /usr/sbin; do
    [ -d "$bin_dir" ] || continue
    ln -sfn "$ROOT/menu.sh" "$bin_dir/$LAUNCHER" 2>/dev/null && break
  done
else
  echo "xfree-toolbox: warning: missing $ROOT/menu.sh — launcher $LAUNCHER not installed" >&2
fi

if [ -f "$ROOT/system/hardware/install-sbin-links.sh" ]; then
  # shellcheck disable=SC1090
  . "$ROOT/system/hardware/install-sbin-links.sh"
  install_hardware_sbin_links "$ROOT" || true
fi

if [ -f "$ROOT/system/hardware/install-button-hooks.sh" ]; then
  if ! sh "$ROOT/system/hardware/install-button-hooks.sh" --install "$ROOT" >>"$LOG" 2>&1; then
    echo "xfree-toolbox: warning: install-button-hooks failed (see $LOG)" >&2
  fi
fi
if [ -f "$ROOT/system/hardware/install-wps-trace-hook.sh" ]; then
  sh "$ROOT/system/hardware/install-wps-trace-hook.sh" --install >>"$LOG" 2>&1 || true
fi
if [ -f "$ROOT/system/hardware/usb-power-watch-upgrade.sh" ]; then
  sh "$ROOT/system/hardware/usb-power-watch-upgrade.sh" --on-deploy --quiet "$ROOT" \
    >>"$LOG" 2>&1 || true
fi

if [ -n "$RESTORE_PROFILES_FROM" ] && [ -d "$RESTORE_PROFILES_FROM" ]; then
  rm -rf "$ROOT/profiles"
  cp -a "$RESTORE_PROFILES_FROM" "$ROOT/profiles" || true
  # Stash under /tmp is owned by preinst; remove when we restored from it.
  case "$RESTORE_PROFILES_FROM" in
    /tmp/.xfree-toolbox-profiles-preserve|/tmp/.xfree-toolbox-profiles-preserve/*)
      rm -rf /tmp/.xfree-toolbox-profiles-preserve
      ;;
  esac
fi

if [ -x "$ROOT/system/sync-runtime-status.sh" ]; then
  sh "$ROOT/system/sync-runtime-status.sh" >/dev/null 2>&1 || true
fi

if [ -x /usr/libexec/rpcd/xfree-toolbox ]; then
  /etc/init.d/rpcd reload >/dev/null 2>&1 || true
fi

exit 0
