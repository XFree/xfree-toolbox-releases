#!/bin/sh
# shellcheck shell=sh
# Detects all WAN interfaces in OpenWrt and completely disables IPv6 on WAN and LAN RA.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/wan6-policy.sh" ] && . "$ROOT_DIR/lib/wan6-policy.sh"

APPLY=0
RELOAD=1
MODE="off"
ZAPRET_IPV6=""
UCI="${UCI_CMD:-uci}"

usage() {
    cat <<USAGE
Usage: $(basename "$0") [--enable] [--mode off|selective|full] [--zapret-ipv6 0|1] [--apply] [--no-reload] [--help]

Reliably detect all WAN interfaces (Ethernet, PPPoE, WWAN, wan6) and configure IPv6:
  Default (off):
    - Sets option ipv6 '0' on all WAN logical interfaces (including PPPoE noipv6)
    - Deactivates wan6 / dhcpv6 interfaces (option disabled '1', auto '0')
    - Sets option ipv6 '0' on associated physical network devices
    - Disables RA / DHCPv6 / NDP server on LAN
  With --enable (--mode selective|full):
    - Enables IPv6 on WAN (ipv6='auto'), activates wan6 (disabled='0', auto='1') and LAN RA/DHCPv6
    - Writes wan6-policy.env (selective = VPN v6 + YouTube/Google only; full = all non-VPN + VPN leak guard)

Options:
  --enable            Enable WAN/LAN IPv6 (sets mode=selective unless --mode is given)
  --mode MODE         WAN6 policy mode: off | selective | full
  --zapret-ipv6 0|1   Override Zapret IPv6 processing (default: 0 for selective, 1 for full)
  --apply             Apply changes to UCI and reload services (default is dry-run check)
  --no-reload         Do not reload network and odhcpd after UCI commit
  -h, --help          Show this help
USAGE
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --enable)
            [ "$MODE" = "off" ] && MODE="selective"
            ;;
        --mode)
            shift
            [ "$#" -gt 0 ] || { echo "Missing value for --mode" >&2; exit 1; }
            MODE="$1"
            ;;
        --zapret-ipv6)
            shift
            [ "$#" -gt 0 ] || { echo "Missing value for --zapret-ipv6" >&2; exit 1; }
            ZAPRET_IPV6="$1"
            ;;
        --apply)
            APPLY=1
            ;;
        --no-reload)
            RELOAD=0
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage
            exit 1
            ;;
    esac
    shift
done

case "$MODE" in
    auto|off|selective|full) ;;
    *) echo "Invalid mode: $MODE (expected auto|off|selective|full)" >&2; exit 1 ;;
esac

find_wan_interfaces() {
    _found=""

    # 1. Inspect firewall zone 'wan' for member networks
    if command -v "$UCI" >/dev/null 2>&1 || [ -n "${UCI_CMD:-}" ]; then
        _zone_idx=0
        while true; do
            _zname="$($UCI -q get "firewall.@zone[$_zone_idx].name" 2>/dev/null || true)"
            [ -n "$_zname" ] || break
            if [ "$_zname" = "wan" ]; then
                _nets="$($UCI -q get "firewall.@zone[$_zone_idx].network" 2>/dev/null || true)"
                for _n in $_nets; do
                    _found="$_found $_n"
                done
            fi
            _zone_idx=$((_zone_idx + 1))
        done

        # 2. Inspect network interfaces by naming pattern and proto
        _iface_dump="$($UCI show network 2>/dev/null | grep -E '^network\.[^.]+=interface$' || true)"
        for _line in $_iface_dump; do
            _ifname="$(printf '%s\n' "$_line" | sed -n 's/^network\.\([^.]*\)=interface$/\1/p')"
            [ -n "$_ifname" ] || continue
            case "$_ifname" in
                wan*|wwan*|modem*|lte*)
                    _found="$_found $_ifname"
                    ;;
                *)
                    _proto="$($UCI -q get "network.$_ifname.proto" 2>/dev/null || true)"
                    if [ "$_proto" = "dhcpv6" ]; then
                        _found="$_found $_ifname"
                    fi
                    ;;
            esac
        done
    fi

    # Deduplicate and output
    printf '%s\n' $_found | sort -u | grep -v '^$' || true
}

find_wan_devices() {
    _devs=""
    if command -v "$UCI" >/dev/null 2>&1 || [ -n "${UCI_CMD:-}" ]; then
        _dev_idx=0
        while true; do
            _dname="$($UCI -q get "network.@device[$_dev_idx].name" 2>/dev/null || true)"
            [ -n "$_dname" ] || break
            case "$_dname" in
                wan*|eth1|eth0.2)
                    _devs="$_devs $_dev_idx"
                    ;;
            esac
            _dev_idx=$((_dev_idx + 1))
        done
    fi
    printf '%s\n' $_devs | sort -u | grep -v '^$' || true
}

wan_list="$(find_wan_interfaces)"
dev_list="$(find_wan_devices)"

echo "=== Detected WAN Interfaces ==="
if [ -z "$wan_list" ]; then
    echo "  (none detected)"
else
    for iface in $wan_list; do
        _proto="$($UCI -q get "network.$iface.proto" 2>/dev/null || echo "unknown")"
        _v6="$($UCI -q get "network.$iface.ipv6" 2>/dev/null || echo "default/auto")"
        _auto="$($UCI -q get "network.$iface.auto" 2>/dev/null || echo "1")"
        _disabled="$($UCI -q get "network.$iface.disabled" 2>/dev/null || echo "0")"
        echo "  - $iface (proto: $_proto, ipv6: $_v6, auto: $_auto, disabled: $_disabled)"
    done
fi

echo "=== Detected WAN Physical Devices ==="
if [ -z "$dev_list" ]; then
    echo "  (none detected)"
else
    for didx in $dev_list; do
        _dname="$($UCI -q get "network.@device[$didx].name" 2>/dev/null || true)"
        _v6="$($UCI -q get "network.@device[$didx].ipv6" 2>/dev/null || echo "default")"
        echo "  - @device[$didx] ($_dname, ipv6: $_v6)"
    done
fi

if [ "$APPLY" -eq 0 ]; then
    echo ""
    echo "Dry-run mode. Run with --apply to execute changes."
    exit 0
fi

echo ""
changes_net=0
changes_dhcp=0

if [ "$MODE" = "off" ]; then
    echo "=== Applying IPv6 Disablement on WAN & LAN ==="

    # 1. Disable on logical interfaces
    for iface in $wan_list; do
        _proto="$($UCI -q get "network.$iface.proto" 2>/dev/null || true)"
        if [ "$_proto" = "dhcpv6" ]; then
            _cur_auto="$($UCI -q get "network.$iface.auto" 2>/dev/null || echo "1")"
            _cur_disabled="$($UCI -q get "network.$iface.disabled" 2>/dev/null || echo "0")"
            if [ "$_cur_auto" != "0" ] || [ "$_cur_disabled" != "1" ]; then
                echo "[*] Deactivating dhcpv6 interface: $iface (disabled=1, auto=0)"
                $UCI set "network.$iface.disabled=1"
                $UCI set "network.$iface.auto=0"
                changes_net=1
            fi
        else
            _cur_v6="$($UCI -q get "network.$iface.ipv6" 2>/dev/null || true)"
            if [ "$_cur_v6" != "0" ]; then
                echo "[*] Setting ipv6='0' on WAN interface: $iface (proto: $_proto)"
                $UCI set "network.$iface.ipv6=0"
                changes_net=1
            fi
        fi
    done

    # 2. Disable on physical devices
    for didx in $dev_list; do
        _cur_v6="$($UCI -q get "network.@device[$didx].ipv6" 2>/dev/null || true)"
        if [ "$_cur_v6" != "0" ]; then
            _dname="$($UCI -q get "network.@device[$didx].name" 2>/dev/null || true)"
            echo "[*] Setting ipv6='0' on device: @device[$didx] ($_dname)"
            $UCI set "network.@device[$didx].ipv6=0"
            changes_net=1
        fi
    done

    # 3. Disable LAN IPv6 announcements (odhcpd)
    if $UCI -q get dhcp.lan >/dev/null 2>&1; then
        for opt in ra dhcpv6 ndp; do
            _cur="$($UCI -q get "dhcp.lan.$opt" 2>/dev/null || true)"
            if [ "$_cur" != "disabled" ]; then
                echo "[*] Setting dhcp.lan.$opt='disabled'"
                $UCI set "dhcp.lan.$opt=disabled"
                changes_dhcp=1
            fi
        done
    fi
else
    echo "=== Applying WAN6 Enablement (mode: $MODE) ==="

    # 1. Enable on logical interfaces
    for iface in $wan_list; do
        _proto="$($UCI -q get "network.$iface.proto" 2>/dev/null || true)"
        if [ "$_proto" = "dhcpv6" ]; then
            _cur_auto="$($UCI -q get "network.$iface.auto" 2>/dev/null || echo "1")"
            _cur_disabled="$($UCI -q get "network.$iface.disabled" 2>/dev/null || echo "0")"
            if [ "$_cur_auto" != "1" ] || [ "$_cur_disabled" != "0" ]; then
                echo "[*] Activating dhcpv6 interface: $iface (disabled=0, auto=1)"
                $UCI set "network.$iface.disabled=0"
                $UCI set "network.$iface.auto=1"
                changes_net=1
            fi
        else
            _cur_v6="$($UCI -q get "network.$iface.ipv6" 2>/dev/null || true)"
            if [ "$_cur_v6" = "0" ]; then
                echo "[*] Setting ipv6='auto' on WAN interface: $iface (proto: $_proto)"
                $UCI set "network.$iface.ipv6=auto"
                changes_net=1
            fi
        fi
    done

    # 2. Enable on physical devices
    for didx in $dev_list; do
        _cur_v6="$($UCI -q get "network.@device[$didx].ipv6" 2>/dev/null || true)"
        if [ "$_cur_v6" = "0" ]; then
            _dname="$($UCI -q get "network.@device[$didx].name" 2>/dev/null || true)"
            echo "[*] Setting ipv6='1' on device: @device[$didx] ($_dname)"
            $UCI set "network.@device[$didx].ipv6=1"
            changes_net=1
        fi
    done

    # 3. Enable LAN IPv6 announcements (odhcpd)
    if $UCI -q get dhcp.lan >/dev/null 2>&1; then
        for opt in ra dhcpv6; do
            _cur="$($UCI -q get "dhcp.lan.$opt" 2>/dev/null || true)"
            if [ "$_cur" != "server" ]; then
                echo "[*] Setting dhcp.lan.$opt='server'"
                $UCI set "dhcp.lan.$opt=server"
                changes_dhcp=1
            fi
        done
    fi
fi

if command -v wan6_policy_write >/dev/null 2>&1; then
    if [ -z "$ZAPRET_IPV6" ]; then
        case "$MODE" in
            full) ZAPRET_IPV6="1" ;;
            *) ZAPRET_IPV6="0" ;;
        esac
    fi
    wan6_policy_write "$MODE" "${WAN6_DEFAULT_ALLOW_DOMAINS:-}" "$ZAPRET_IPV6"
    echo "[*] Saved wan6-policy.env: mode=$MODE zapret_ipv6=$ZAPRET_IPV6"
fi

if [ "$changes_net" -eq 1 ]; then
    echo "[*] Committing network configuration..."
    $UCI commit network
fi

if [ "$changes_dhcp" -eq 1 ]; then
    echo "[*] Committing dhcp configuration..."
    $UCI commit dhcp
fi

if [ "$RELOAD" -eq 1 ]; then
    if [ "$changes_dhcp" -eq 1 ] && [ -x /etc/init.d/odhcpd ]; then
        echo "[*] Restarting odhcpd..."
        /etc/init.d/odhcpd restart 2>/dev/null || true
    fi
    if [ "$changes_net" -eq 1 ] && [ -x /etc/init.d/network ]; then
        echo "[*] Reloading network..."
        /etc/init.d/network reload 2>/dev/null || true
    fi
fi

if [ "$MODE" = "off" ]; then
    echo "[+] Done. WAN IPv6 disabled."
else
    echo "[+] Done. WAN IPv6 enabled (mode=$MODE). Run iface-routing/apply-routing.sh to update firewall guards."
fi
