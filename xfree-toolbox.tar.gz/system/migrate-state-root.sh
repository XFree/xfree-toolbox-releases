#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$(readlink -f "$0")")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"

VERBOSE=1
DRY_RUN=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --quiet)
      VERBOSE=0
      ;;
    --dry-run)
      DRY_RUN=1
      ;;
    -h|--help)
      cat <<EOF
Usage: $0 [--quiet] [--dry-run]

Migrates known legacy state directories into ${XFREE_STATE_ROOT:-/etc/xfree-toolbox}.
Existing files in the new state root are not overwritten.
Legacy directories are left in place.
EOF
      exit 0
      ;;
    *)
      warn "Неизвестный параметр миграции: $1"
      ;;
  esac
  shift
done

: "${XFREE_STATE_ROOT:=/etc/xfree-toolbox}"
: "${XFREE_BACKUP_ROOT:=$XFREE_STATE_ROOT/backups}"
: "${XFREE_DOMAIN_ROUTING_ROOT:=$XFREE_STATE_ROOT/domain-routing}"
: "${XFREE_IFACE_ROUTING_ROOT:=$XFREE_STATE_ROOT/iface-routing}"
: "${XFREE_DNS_ROUTING_ROOT:=$XFREE_STATE_ROOT/dns-routing}"
: "${XFREE_VPN_ROOT:=$XFREE_STATE_ROOT/vpn}"
: "${BACKUP_ROOT:=$XFREE_BACKUP_ROOT}"
: "${BACKUP_KEEP:=$(common_backup_keep)}"

MIGRATION_LOG="$XFREE_STATE_ROOT/migration.log"
MIGRATION_MARKER="$XFREE_STATE_ROOT/.state-root-migrated"
MIGRATION_SUMMARY="$XFREE_STATE_ROOT/migration-summary.txt"
MIGRATION_CHECK_REPORT="$XFREE_STATE_ROOT/migration-check.txt"
MIGRATION_IMPACT="$XFREE_STATE_ROOT/migration-impact.env"

NEEDS_IFACE_ROUTING_APPLY=0
NEEDS_DNS_ROUTING_APPLY=0
NEEDS_SELF_ROUTE_REFRESH=0
IMPACT_REASONS=""

if [ "$DRY_RUN" != "1" ]; then
  mkdir -p "$XFREE_STATE_ROOT" 2>/dev/null || true
  {
    printf 'Миграция xfree-toolbox\n'
    printf 'Время: %s\n\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"
    printf 'Изменения:\n'
  } > "$MIGRATION_SUMMARY" 2>/dev/null || true
fi

migration_say() {
  [ "$VERBOSE" = "1" ] || return 0
  printf '%s\n' "$*"
}

migration_log() {
  [ "$DRY_RUN" != "1" ] || return 0
  mkdir -p "$XFREE_STATE_ROOT" 2>/dev/null || true
  common_append_log_file "$MIGRATION_LOG" "$*"
}

migration_summary_add() {
  [ "$DRY_RUN" != "1" ] || return 0
  mkdir -p "$XFREE_STATE_ROOT" 2>/dev/null || true
  printf -- '- %s\n' "$*" >> "$MIGRATION_SUMMARY" 2>/dev/null || true
}

impact_add_reason() {
  reason="$1"
  [ -n "$reason" ] || return 0
  IMPACT_REASONS="${IMPACT_REASONS}${IMPACT_REASONS:+; }$reason"
}

impact_mark_iface() {
  NEEDS_IFACE_ROUTING_APPLY=1
  impact_add_reason "$1"
}

impact_mark_dns() {
  NEEDS_DNS_ROUTING_APPLY=1
  impact_add_reason "$1"
}

impact_mark_self_route() {
  NEEDS_SELF_ROUTE_REFRESH=1
  impact_add_reason "$1"
}

write_migration_impact() {
  [ "$DRY_RUN" != "1" ] || return 0
  mkdir -p "$XFREE_STATE_ROOT" 2>/dev/null || true
  {
    printf 'NEEDS_IFACE_ROUTING_APPLY=%s\n' "$NEEDS_IFACE_ROUTING_APPLY"
    printf 'NEEDS_DNS_ROUTING_APPLY=%s\n' "$NEEDS_DNS_ROUTING_APPLY"
    printf 'NEEDS_SELF_ROUTE_REFRESH=%s\n' "$NEEDS_SELF_ROUTE_REFRESH"
    printf 'IMPACT_REASONS=%s\n' "$(printf '%s' "$IMPACT_REASONS" | sed "s/'/'\\\\''/g; s/^/'/; s/$/'/")"
  } > "$MIGRATION_IMPACT"
}

run_post_migration_repair() {
  [ "$DRY_RUN" != "1" ] || return 0
  [ "$NEEDS_IFACE_ROUTING_APPLY" = "1" ] || [ "$NEEDS_DNS_ROUTING_APPLY" = "1" ] || [ "$NEEDS_SELF_ROUTE_REFRESH" = "1" ] || return 0

  profile_dir="$(common_profile_dir "$ROOT_DIR")"

  if [ "$NEEDS_IFACE_ROUTING_APPLY" = "1" ] || [ "$NEEDS_DNS_ROUTING_APPLY" = "1" ]; then
    if [ -f "$ROOT_DIR/lib/apply-dns-and-iface-routing.sh" ]; then
      migration_say "[*] Post-migration repair: dns+iface apply (PROFILE_DIR=$profile_dir)"
      if "$ROOT_DIR/lib/apply-dns-and-iface-routing.sh" --profile-dir "$profile_dir"; then
        migration_log "[OK] post-repair dns+iface apply"
      else
        migration_log "[WARN] post-repair dns+iface apply failed"
        migration_summary_add "Post-repair: dns+iface apply завершился с ошибкой"
      fi
    else
      migration_log "[WARN] post-repair wrapper missing: lib/apply-dns-and-iface-routing.sh"
    fi
  fi

  if [ "$NEEDS_SELF_ROUTE_REFRESH" = "1" ] && [ -x "$ROOT_DIR/iface-routing/self-route/apply.sh" ]; then
    migration_say "[*] Post-migration repair: self-route refresh"
    if PROFILE_DIR="$profile_dir" "$ROOT_DIR/iface-routing/self-route/apply.sh" --run-hotplug; then
      migration_log "[OK] post-repair self-route refresh"
    else
      migration_log "[WARN] post-repair self-route refresh failed"
      migration_summary_add "Post-repair: self-route refresh завершился с ошибкой"
    fi
  fi
}

same_path() {
  left="${1%/}"
  right="${2%/}"
  [ "$left" = "$right" ]
}

copy_missing_item() {
  src_item="$1"
  dst_item="$2"

  if [ -e "$dst_item" ] || [ -L "$dst_item" ]; then
    return 0
  fi

  if [ "$DRY_RUN" = "1" ]; then
    migration_say "copy: $src_item -> $dst_item"
    return 0
  fi

  mkdir -p "$(dirname -- "$dst_item")"
  cp -a "$src_item" "$dst_item"
}

dir_has_missing_items() {
  src_dir="$1"
  dst_dir="$2"

  [ -d "$src_dir" ] || return 1
  same_path "$src_dir" "$dst_dir" && return 1

  while IFS= read -r rel_path; do
    [ -n "$rel_path" ] || continue
    src_item="$src_dir/$rel_path"
    dst_item="$dst_dir/$rel_path"

    if [ -d "$src_item" ] && [ ! -L "$src_item" ]; then
      if [ ! -d "$dst_item" ]; then
        return 0
      fi
      continue
    fi

    if [ ! -e "$dst_item" ] && [ ! -L "$dst_item" ]; then
      return 0
    fi
  done <<EOF2
$(cd "$src_dir" 2>/dev/null && find . -mindepth 1 -print)
EOF2

  return 1
}

merge_dir_missing() {
  src_dir="$1"
  dst_dir="$2"
  label="$3"

  [ -d "$src_dir" ] || return 0
  same_path "$src_dir" "$dst_dir" && return 0
  dir_has_missing_items "$src_dir" "$dst_dir" || return 0

  migration_say "[*] $label: $src_dir -> $dst_dir"
  migration_summary_add "$label: $src_dir -> $dst_dir"
  migration_log "[START] $label: $src_dir -> $dst_dir"

  if [ "$DRY_RUN" != "1" ]; then
    mkdir -p "$dst_dir"
  fi

  (
    cd "$src_dir" || exit 1
    find . -mindepth 1 -print
  ) | while IFS= read -r rel_path; do
    src_item="$src_dir/$rel_path"
    dst_item="$dst_dir/$rel_path"

    if [ -d "$src_item" ] && [ ! -L "$src_item" ]; then
      [ "$DRY_RUN" = "1" ] || mkdir -p "$dst_item"
      continue
    fi

    copy_missing_item "$src_item" "$dst_item"
  done

  migration_log "[DONE] $label"
}

remove_legacy_backup_path() {
  path="$1"
  label="$2"

  [ -e "$path" ] || [ -L "$path" ] || return 0

  migration_say "[*] backup cleanup: удаляю legacy backup storage $path"
  migration_summary_add "Удалено legacy backup storage: $path"
  migration_log "[START] backup legacy storage remove: $label $path"
  [ "$DRY_RUN" = "1" ] || rm -rf "$path"
  migration_log "[DONE] backup legacy storage remove"
}

remove_legacy_path() {
  path="$1"
  label="$2"

  [ -e "$path" ] || [ -L "$path" ] || return 0

  migration_say "[*] legacy cleanup: удаляю $path"
  migration_summary_add "Удалён legacy path: $path"
  migration_log "[START] legacy path remove: $label $path"
  [ "$DRY_RUN" = "1" ] || rm -rf "$path"
  migration_log "[DONE] legacy path remove"
}

cleanup_legacy_backup_suffix() {
  parent_dir="$1"
  suffix="$2"
  label="$3"
  name_pattern="${4:-*$suffix}"

  [ -d "$parent_dir" ] || return 0
  [ -n "$suffix" ] || return 0

  find "$parent_dir" -mindepth 1 -maxdepth 1 -type d -name "$name_pattern" 2>/dev/null \
    | sort \
    | while IFS= read -r old_dir; do
        [ -n "$old_dir" ] || continue
        new_dir="${old_dir%$suffix}"
        [ "$new_dir" != "$old_dir" ] || continue

        if [ -e "$new_dir" ] || [ -L "$new_dir" ]; then
          migration_say "[*] backup cleanup: удаляю legacy-дубликат $old_dir"
          migration_summary_add "Удалён legacy backup duplicate: $old_dir"
          migration_log "[START] backup legacy duplicate cleanup: $old_dir"
          [ "$DRY_RUN" = "1" ] || rm -rf "$old_dir"
          migration_log "[DONE] backup legacy duplicate cleanup"
        else
          migration_say "[*] backup cleanup: $old_dir -> $new_dir"
          migration_summary_add "Переименован legacy backup: $old_dir -> $new_dir"
          migration_log "[START] backup legacy rename: $old_dir -> $new_dir"
          [ "$DRY_RUN" = "1" ] || mv "$old_dir" "$new_dir" 2>/dev/null || true
          migration_log "[DONE] backup legacy rename"
        fi
      done
}

rotate_backup_pattern() {
  parent_dir="$1"
  name_pattern="$2"
  label="$3"

  [ -d "$parent_dir" ] || return 0
  [ -n "$name_pattern" ] || return 0
  keep="$BACKUP_KEEP"
  case "$keep" in
    ''|*[!0-9]*) keep=5 ;;
  esac

  migration_say "[*] backup cleanup: rotation $label"
  migration_log "[START] backup rotation: $label"
  if [ "$DRY_RUN" != "1" ]; then
    find "$parent_dir" -mindepth 1 -maxdepth 1 -type d 2>/dev/null \
      -name "$name_pattern" \
      | sort -r \
      | awk -v keep="$keep" 'NR > keep { print }' \
      | while IFS= read -r old_dir; do
          [ -n "$old_dir" ] && rm -rf "$old_dir"
        done
  fi
  migration_log "[DONE] backup rotation"
}

if [ "$DRY_RUN" != "1" ]; then
  # Каркас каталогов (может быть пустым на новом роутере). «Заполненный state» — только при файлах внутри
  # (см. common_state_root_looks_populated в lib/common.sh).
  mkdir -p "$XFREE_STATE_ROOT" "$XFREE_BACKUP_ROOT" "$XFREE_IFACE_ROUTING_ROOT" "$XFREE_DNS_ROUTING_ROOT" "$XFREE_VPN_ROOT" 2>/dev/null || true
fi

NEW_INSTALL_DIR="${XFREE_ROOT_DIR:-/root/xfree-toolbox}"
LEGACY_INSTALL_DIR="${XFREE_LEGACY_ROOT_DIR:-/root/xfree-utils}"
INSTALL_BACKUP_ROOT="$(dirname -- "$NEW_INSTALL_DIR")"
NEW_INSTALL_BASE="$(basename -- "$NEW_INSTALL_DIR")"
LEGACY_INSTALL_BASE="$(basename -- "$LEGACY_INSTALL_DIR")"

cleanup_legacy_backup_suffix "$INSTALL_BACKUP_ROOT" ".dir" "install backups" "$NEW_INSTALL_BASE.*.dir"
cleanup_legacy_backup_suffix "$INSTALL_BACKUP_ROOT" ".dir" "legacy install backups" "$LEGACY_INSTALL_BASE.*.dir"
cleanup_legacy_backup_suffix "$XFREE_BACKUP_ROOT/iface-routing" ".dir" "iface-routing backups" "runtime.*.dir"
cleanup_legacy_backup_suffix "$XFREE_BACKUP_ROOT/install" ".dir" "migration install backups" "*.legacy.*.dir"
cleanup_legacy_backup_suffix "$XFREE_BACKUP_ROOT/zapret" ".bak" "zapret directory backups" "*.bak"

rotate_backup_pattern "$INSTALL_BACKUP_ROOT" "$NEW_INSTALL_BASE.[0-9]*-[0-9]*" "deploy backups"
rotate_backup_pattern "$INSTALL_BACKUP_ROOT" "$NEW_INSTALL_BASE.self-update.*" "self-update backups"
rotate_backup_pattern "$INSTALL_BACKUP_ROOT" "$LEGACY_INSTALL_BASE.[0-9]*-[0-9]*" "legacy deploy backups"
rotate_backup_pattern "$INSTALL_BACKUP_ROOT" "$LEGACY_INSTALL_BASE.self-update.*" "legacy self-update backups"
rotate_backup_pattern "$XFREE_BACKUP_ROOT/iface-routing" "runtime.*" "iface-routing backups"
rotate_backup_pattern "$XFREE_BACKUP_ROOT/install" "*.legacy.*" "migration install backups"
rotate_backup_pattern "$XFREE_BACKUP_ROOT/zapret" "ipset.*" "zapret ipset directory backups"

if [ -d "$NEW_INSTALL_DIR" ] && [ "$LEGACY_INSTALL_DIR" != "$NEW_INSTALL_DIR" ]; then
  if [ -d "$LEGACY_INSTALL_DIR" ] && [ ! -L "$LEGACY_INSTALL_DIR" ]; then
    legacy_backup="$BACKUP_ROOT/install/$(basename -- "$LEGACY_INSTALL_DIR").legacy.$(backup_stamp_now)"
    migration_say "[*] install: переношу legacy install в backup: $legacy_backup"
    migration_summary_add "Legacy install перенесён в backup: $LEGACY_INSTALL_DIR -> $legacy_backup"
    migration_log "[START] install legacy backup: $LEGACY_INSTALL_DIR -> $legacy_backup"
    if [ "$DRY_RUN" != "1" ]; then
      mkdir -p "$(dirname -- "$legacy_backup")"
      mv "$LEGACY_INSTALL_DIR" "$legacy_backup" 2>/dev/null || true
      ln -s "$NEW_INSTALL_DIR" "$LEGACY_INSTALL_DIR" 2>/dev/null || true
    fi
    migration_log "[DONE] install legacy backup"
  elif [ ! -e "$LEGACY_INSTALL_DIR" ]; then
    migration_say "[*] install: создаю legacy symlink $LEGACY_INSTALL_DIR -> $NEW_INSTALL_DIR"
    migration_summary_add "Создан legacy symlink: $LEGACY_INSTALL_DIR -> $NEW_INSTALL_DIR"
    migration_log "[START] install legacy symlink: $LEGACY_INSTALL_DIR -> $NEW_INSTALL_DIR"
    [ "$DRY_RUN" = "1" ] || ln -s "$NEW_INSTALL_DIR" "$LEGACY_INSTALL_DIR" 2>/dev/null || true
    migration_log "[DONE] install legacy symlink"
  fi
fi

migration_say "[*] Миграция: фаза переноса данных в state (${XFREE_STATE_ROOT})..."
migration_log "[START] migration data phase (merge / rename / uci)"

merge_dir_missing "/etc/domain-routing" "$XFREE_DOMAIN_ROUTING_ROOT" "domain-routing legacy state"
merge_dir_missing "/etc/xfree-utils/domain-routing" "$XFREE_DOMAIN_ROUTING_ROOT" "domain-routing legacy toolbox state"
merge_dir_missing "/etc/xfree-utils/backups" "$XFREE_BACKUP_ROOT" "backup state"
merge_dir_missing "/etc/domain-routing/backup" "$XFREE_BACKUP_ROOT/iface-routing" "domain-routing legacy backups"
merge_dir_missing "/etc/xfree-utils/domain-routing/backup" "$XFREE_BACKUP_ROOT/iface-routing" "domain-routing legacy toolbox backups"
merge_dir_missing "$XFREE_DOMAIN_ROUTING_ROOT/backup" "$XFREE_BACKUP_ROOT/iface-routing" "domain-routing migrated legacy backups"
merge_dir_missing "/etc/xfree-utils/awg-ingress" "$XFREE_STATE_ROOT/awg-ingress" "awg-ingress state"
merge_dir_missing "/etc/xfree-utils/vk-turn" "$XFREE_STATE_ROOT/vk-turn" "vk-turn state"
if dir_has_missing_items "/etc/dnsmasq.d/domain-routing" "/etc/dnsmasq.d/xfree-toolbox-routing"; then
  merge_dir_missing "/etc/dnsmasq.d/domain-routing" "/etc/dnsmasq.d/xfree-toolbox-routing" "dnsmasq runtime confdir"
  impact_mark_dns "legacy dnsmasq runtime confdir merged"
fi

remove_legacy_backup_path "/etc/xfree-utils/backups" "xfree-utils backups"
remove_legacy_backup_path "/etc/domain-routing/backup" "domain-routing backups"
remove_legacy_backup_path "/etc/xfree-utils/domain-routing/backup" "xfree-utils domain-routing backups"
remove_legacy_backup_path "$XFREE_DOMAIN_ROUTING_ROOT/backup" "migrated domain-routing backups"

PROTON_LEGACY_SESSIONS_DIR="/root/proton/sessions"
PROTON_STATE_DIR="$XFREE_VPN_ROOT/state/proton"
PROTON_SESSIONS_DIR="$PROTON_STATE_DIR/sessions"
PROTON_GENERATED_DIR="$XFREE_VPN_ROOT/generated/proton"

merge_dir_missing "$PROTON_LEGACY_SESSIONS_DIR" "$PROTON_SESSIONS_DIR" "proton sessions"

remove_legacy_path "$PROTON_LEGACY_SESSIONS_DIR" "proton sessions"
if [ -d "/root/proton" ]; then
  if ! find "/root/proton" -mindepth 1 -print -quit 2>/dev/null | grep -q .; then
    remove_legacy_path "/root/proton" "proton legacy root"
  fi
fi

if [ -d "/root/proton" ] && [ ! -d "$PROTON_LEGACY_SESSIONS_DIR" ]; then
  migration_log "[WARN] proton legacy root exists without sessions dir: /root/proton"
fi

if [ "$DRY_RUN" != "1" ]; then
  mkdir -p "$PROTON_SESSIONS_DIR" "$PROTON_GENERATED_DIR" 2>/dev/null || true
fi

IFACE_ROUTING_STATE_INTERFACES_DIR="$XFREE_IFACE_ROUTING_ROOT/state/interfaces"
IFACE_ROUTING_GENERATED_DIR="$XFREE_IFACE_ROUTING_ROOT/generated"
IFACE_ROUTING_GENERATED_INTERFACES_DIR="$IFACE_ROUTING_GENERATED_DIR/interfaces"
DNS_ROUTING_GENERATED_DIR="$XFREE_DNS_ROUTING_ROOT/generated"

if dir_has_missing_items "$XFREE_DOMAIN_ROUTING_ROOT/interfaces" "$IFACE_ROUTING_STATE_INTERFACES_DIR"; then
  merge_dir_missing "$XFREE_DOMAIN_ROUTING_ROOT/interfaces" "$IFACE_ROUTING_STATE_INTERFACES_DIR" "iface-routing state interfaces"
  impact_mark_iface "iface-routing state interfaces merged from legacy domain-routing"
fi

if [ -d "$XFREE_DOMAIN_ROUTING_ROOT/generated" ]; then
  if [ "$DRY_RUN" != "1" ]; then
    mkdir -p "$IFACE_ROUTING_GENERATED_INTERFACES_DIR" "$DNS_ROUTING_GENERATED_DIR"
  fi

  for generated_item in "$XFREE_DOMAIN_ROUTING_ROOT/generated"/*; do
    [ -e "$generated_item" ] || continue
    generated_name="$(basename -- "$generated_item")"
    case "$generated_name" in
      dns-redirects.map|dns-redirects.summary)
        dst_item="$DNS_ROUTING_GENERATED_DIR/$generated_name"
        if [ ! -e "$dst_item" ] && [ ! -L "$dst_item" ]; then
          impact_mark_dns "dns-routing generated artifact migrated: $generated_name"
        fi
        copy_missing_item "$generated_item" "$DNS_ROUTING_GENERATED_DIR/$generated_name"
        ;;
      *)
        if [ -d "$generated_item" ] && [ ! -L "$generated_item" ]; then
          dst_dir="$IFACE_ROUTING_GENERATED_INTERFACES_DIR/$generated_name"
          if dir_has_missing_items "$generated_item" "$dst_dir"; then
            merge_dir_missing "$generated_item" "$dst_dir" "iface-routing generated interface $generated_name"
            impact_mark_iface "iface-routing generated interface migrated: $generated_name"
          fi
        else
          dst_item="$IFACE_ROUTING_GENERATED_DIR/$generated_name"
          if [ ! -e "$dst_item" ] && [ ! -L "$dst_item" ]; then
            impact_mark_iface "iface-routing generated artifact migrated: $generated_name"
          fi
          copy_missing_item "$generated_item" "$IFACE_ROUTING_GENERATED_DIR/$generated_name"
        fi
        ;;
    esac
  done
fi

DNSMASQ_CONF_DIR="/etc/dnsmasq.d/xfree-toolbox-routing"
FQDN_DNSMASQ_FILE="$DNSMASQ_CONF_DIR/90-xfree-toolbox-fqdn-routing.conf"
OLD_FQDN_DNSMASQ_FILE="$DNSMASQ_CONF_DIR/90-domain-routing.conf"
INTERMEDIATE_FQDN_DNSMASQ_FILE="$DNSMASQ_CONF_DIR/90-xfree-toolbox-routing.conf"

[ "$DRY_RUN" = "1" ] || mkdir -p "$DNSMASQ_CONF_DIR" 2>/dev/null || true

if [ -f "$INTERMEDIATE_FQDN_DNSMASQ_FILE" ] && [ ! -e "$FQDN_DNSMASQ_FILE" ]; then
  migration_say "[*] dnsmasq: 90-xfree-toolbox-routing.conf -> 90-xfree-toolbox-fqdn-routing.conf"
  migration_summary_add "dnsmasq FQDN config renamed to canonical name"
  migration_log "[START] dnsmasq intermediate fqdn config rename"
  [ "$DRY_RUN" = "1" ] || mv "$INTERMEDIATE_FQDN_DNSMASQ_FILE" "$FQDN_DNSMASQ_FILE" 2>/dev/null || true
  migration_log "[DONE] dnsmasq intermediate fqdn config rename"
  impact_mark_dns "dnsmasq fqdn routing file renamed to canonical path"
elif [ -f "$INTERMEDIATE_FQDN_DNSMASQ_FILE" ] && [ -e "$FQDN_DNSMASQ_FILE" ]; then
  migration_say "[*] dnsmasq: удаляю legacy-дубликат 90-xfree-toolbox-routing.conf"
  migration_summary_add "Удалён dnsmasq legacy duplicate: 90-xfree-toolbox-routing.conf"
  migration_log "[START] dnsmasq intermediate fqdn duplicate cleanup"
  [ "$DRY_RUN" = "1" ] || rm -f "$INTERMEDIATE_FQDN_DNSMASQ_FILE"
  migration_log "[DONE] dnsmasq intermediate fqdn duplicate cleanup"
  impact_mark_dns "dnsmasq intermediate fqdn duplicate removed"
fi

if [ -f "$OLD_FQDN_DNSMASQ_FILE" ] && [ ! -e "$FQDN_DNSMASQ_FILE" ]; then
  migration_say "[*] dnsmasq: 90-domain-routing.conf -> 90-xfree-toolbox-fqdn-routing.conf"
  migration_summary_add "dnsmasq legacy FQDN config renamed to canonical name"
  migration_log "[START] dnsmasq legacy fqdn config rename"
  [ "$DRY_RUN" = "1" ] || mv "$OLD_FQDN_DNSMASQ_FILE" "$FQDN_DNSMASQ_FILE" 2>/dev/null || true
  migration_log "[DONE] dnsmasq legacy fqdn config rename"
  impact_mark_dns "legacy dnsmasq fqdn config renamed to canonical path"
elif [ -f "$OLD_FQDN_DNSMASQ_FILE" ] && [ -e "$FQDN_DNSMASQ_FILE" ]; then
  migration_say "[*] dnsmasq: удаляю legacy-дубликат 90-domain-routing.conf"
  migration_summary_add "Удалён dnsmasq legacy duplicate: 90-domain-routing.conf"
  migration_log "[START] dnsmasq legacy fqdn duplicate cleanup"
  [ "$DRY_RUN" = "1" ] || rm -f "$OLD_FQDN_DNSMASQ_FILE"
  migration_log "[DONE] dnsmasq legacy fqdn duplicate cleanup"
  impact_mark_dns "legacy dnsmasq fqdn duplicate removed"
fi

if [ -f "$DNSMASQ_CONF_DIR/90-dns-redirects.conf" ] && [ ! -e "$DNSMASQ_CONF_DIR/90-xfree-toolbox-dns-redirects.conf" ]; then
  migration_say "[*] dnsmasq: 90-dns-redirects.conf -> 90-xfree-toolbox-dns-redirects.conf"
  migration_summary_add "dnsmasq redirects config renamed to canonical name"
  migration_log "[START] dnsmasq redirects config rename"
  [ "$DRY_RUN" = "1" ] || mv "$DNSMASQ_CONF_DIR/90-dns-redirects.conf" "$DNSMASQ_CONF_DIR/90-xfree-toolbox-dns-redirects.conf" 2>/dev/null || true
  migration_log "[DONE] dnsmasq redirects config rename"
elif [ -f "$DNSMASQ_CONF_DIR/90-dns-redirects.conf" ] && [ -e "$DNSMASQ_CONF_DIR/90-xfree-toolbox-dns-redirects.conf" ]; then
  migration_say "[*] dnsmasq: удаляю legacy-дубликат 90-dns-redirects.conf"
  migration_summary_add "Удалён dnsmasq legacy duplicate: 90-dns-redirects.conf"
  migration_log "[START] dnsmasq redirects legacy duplicate cleanup"
  [ "$DRY_RUN" = "1" ] || rm -f "$DNSMASQ_CONF_DIR/90-dns-redirects.conf"
  migration_log "[DONE] dnsmasq redirects legacy duplicate cleanup"
fi

if command -v uci >/dev/null 2>&1; then
  current_confdirs="$(uci -q get dhcp.@dnsmasq[0].confdir 2>/dev/null || true)"
  confdir_exists=0
  for confdir in $current_confdirs; do
    if [ "$confdir" = "/etc/dnsmasq.d/xfree-toolbox-routing" ]; then
      confdir_exists=1
    elif [ "$confdir" = "/etc/dnsmasq.d/domain-routing" ]; then
      migration_say "[*] dnsmasq: удаляю legacy confdir $confdir"
      migration_summary_add "Удалён UCI legacy dnsmasq confdir: $confdir"
      migration_log "[START] dnsmasq legacy confdir remove: $confdir"
      [ "$DRY_RUN" = "1" ] || uci del_list dhcp.@dnsmasq[0].confdir="$confdir" 2>/dev/null || true
      migration_log "[DONE] dnsmasq legacy confdir remove"
      impact_mark_dns "legacy dnsmasq confdir removed from UCI"
    fi
  done

  if [ "$confdir_exists" -eq 0 ]; then
    migration_say "[*] dnsmasq: добавляю confdir /etc/dnsmasq.d/xfree-toolbox-routing"
    migration_summary_add "Добавлен UCI dnsmasq confdir: /etc/dnsmasq.d/xfree-toolbox-routing"
    migration_log "[START] dnsmasq new confdir add"
    [ "$DRY_RUN" = "1" ] || uci add_list dhcp.@dnsmasq[0].confdir="/etc/dnsmasq.d/xfree-toolbox-routing"
    migration_log "[DONE] dnsmasq new confdir add"
    impact_mark_dns "canonical dnsmasq confdir added to UCI"
  fi

  [ "$DRY_RUN" = "1" ] || uci commit dhcp 2>/dev/null || true
fi

FQDN_NFT_FILE="$IFACE_ROUTING_GENERATED_DIR/90-xfree-toolbox-fqdn-routing.nft"
OLD_FQDN_NFT_FILE="$XFREE_DOMAIN_ROUTING_ROOT/90-domain-routing.nft"
INTERMEDIATE_FQDN_NFT_FILE="$XFREE_DOMAIN_ROUTING_ROOT/90-xfree-toolbox-fqdn-routing.nft"
LEGACY_FQDN_NFT_FILE="/etc/domain-routing/90-domain-routing.nft"
LEGACY_INTERMEDIATE_FQDN_NFT_FILE="/etc/domain-routing/90-xfree-toolbox-fqdn-routing.nft"

if [ -f "$INTERMEDIATE_FQDN_NFT_FILE" ] && [ ! -e "$FQDN_NFT_FILE" ]; then
  migration_say "[*] nft: domain-routing/90-xfree-toolbox-fqdn-routing.nft -> iface-routing/generated"
  migration_summary_add "nft include moved to iface-routing generated path"
  migration_log "[START] nft intermediate include move"
  if [ "$DRY_RUN" != "1" ]; then
    mkdir -p "$IFACE_ROUTING_GENERATED_DIR"
    mv "$INTERMEDIATE_FQDN_NFT_FILE" "$FQDN_NFT_FILE" 2>/dev/null || true
  fi
  migration_log "[DONE] nft intermediate include move"
  impact_mark_iface "fqdn nft include moved to canonical iface-routing generated path"
elif [ -f "$INTERMEDIATE_FQDN_NFT_FILE" ] && [ -e "$FQDN_NFT_FILE" ]; then
  migration_say "[*] nft: удаляю legacy-дубликат 90-xfree-toolbox-fqdn-routing.nft"
  migration_summary_add "Удалён legacy nft duplicate: 90-xfree-toolbox-fqdn-routing.nft"
  migration_log "[START] nft intermediate duplicate cleanup"
  [ "$DRY_RUN" = "1" ] || rm -f "$INTERMEDIATE_FQDN_NFT_FILE"
  migration_log "[DONE] nft intermediate duplicate cleanup"
  impact_mark_iface "intermediate fqdn nft duplicate removed"
fi

if [ -f "$OLD_FQDN_NFT_FILE" ] && [ ! -e "$FQDN_NFT_FILE" ]; then
  migration_say "[*] nft: 90-domain-routing.nft -> 90-xfree-toolbox-fqdn-routing.nft"
  migration_summary_add "legacy nft include moved to canonical generated path"
  migration_log "[START] nft legacy include rename"
  if [ "$DRY_RUN" != "1" ]; then
    mkdir -p "$IFACE_ROUTING_GENERATED_DIR"
    mv "$OLD_FQDN_NFT_FILE" "$FQDN_NFT_FILE" 2>/dev/null || true
  fi
  migration_log "[DONE] nft legacy include rename"
  impact_mark_iface "legacy fqdn nft include renamed to canonical path"
elif [ -f "$OLD_FQDN_NFT_FILE" ] && [ -e "$FQDN_NFT_FILE" ]; then
  migration_say "[*] nft: удаляю legacy-дубликат 90-domain-routing.nft"
  migration_summary_add "Удалён legacy nft duplicate: 90-domain-routing.nft"
  migration_log "[START] nft legacy duplicate cleanup"
  [ "$DRY_RUN" = "1" ] || rm -f "$OLD_FQDN_NFT_FILE"
  migration_log "[DONE] nft legacy duplicate cleanup"
  impact_mark_iface "legacy fqdn nft duplicate removed"
fi

if [ -f "$LEGACY_INTERMEDIATE_FQDN_NFT_FILE" ] && [ ! -e "$FQDN_NFT_FILE" ]; then
  migration_say "[*] nft: /etc/domain-routing/90-xfree-toolbox-fqdn-routing.nft -> iface-routing/generated"
  migration_summary_add "legacy /etc/domain-routing nft include copied to canonical generated path"
  migration_log "[START] nft legacy intermediate include move"
  if [ "$DRY_RUN" != "1" ]; then
    mkdir -p "$IFACE_ROUTING_GENERATED_DIR"
    cp -a "$LEGACY_INTERMEDIATE_FQDN_NFT_FILE" "$FQDN_NFT_FILE" 2>/dev/null || true
  fi
  migration_log "[DONE] nft legacy intermediate include move"
  impact_mark_iface "legacy /etc/domain-routing nft include copied to canonical path"
fi

if command -v uci >/dev/null 2>&1; then
  firewall_changed=0
  canonical_firewall_include=0
  while IFS= read -r section; do
    [ -n "$section" ] || continue
    path="$(uci -q get "$section.path" 2>/dev/null || true)"
    [ "$path" = "$FQDN_NFT_FILE" ] && canonical_firewall_include=1
  done <<EOF2
$(uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=include$/\1/p" || true)
EOF2

  while IFS= read -r section; do
    [ -n "$section" ] || continue
    path="$(uci -q get "$section.path" 2>/dev/null || true)"
    case "$path" in
      "$FQDN_NFT_FILE")
        ;;
      "$OLD_FQDN_NFT_FILE"|"$INTERMEDIATE_FQDN_NFT_FILE"|"$LEGACY_FQDN_NFT_FILE"|"$LEGACY_INTERMEDIATE_FQDN_NFT_FILE")
        if [ "$canonical_firewall_include" = "1" ]; then
          migration_say "[*] firewall: удаляю legacy include $section"
          migration_summary_add "Удалён legacy firewall include: $section"
          migration_log "[START] firewall legacy include remove: $section $path"
          [ "$DRY_RUN" = "1" ] || uci delete "$section" 2>/dev/null || true
          migration_log "[DONE] firewall legacy include remove: $section"
          impact_mark_iface "legacy firewall include removed: $path"
        else
          migration_say "[*] firewall: обновляю include $section"
          migration_summary_add "Firewall include migrated to: $FQDN_NFT_FILE"
          migration_log "[START] firewall include path migrate: $section $path -> $FQDN_NFT_FILE"
          if [ "$DRY_RUN" != "1" ]; then
            uci set "$section.type"='nftables'
            uci set "$section.path"="$FQDN_NFT_FILE"
            uci set "$section.fw4_compatible"='1'
            uci set "$section.enabled"='1'
            uci -q delete "${section}.comment" || true
          fi
          canonical_firewall_include=1
          migration_log "[DONE] firewall include path migrate: $section"
          impact_mark_iface "firewall include migrated to canonical fqdn nft path"
        fi
        firewall_changed=1
        ;;
    esac
  done <<EOF2
$(uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=include$/\1/p" || true)
EOF2

  if [ "$DRY_RUN" != "1" ]; then
    legacy_vpnmark_present=0
    if [ -f "$FQDN_NFT_FILE" ] && grep -qE 'vpn_fqdn4|vpn_fqdn6|vpn_prefixes4|vpn_prefixes6|@vpn_|set vpn_|meta mark set 0x00010000|meta mark set 0x10000' "$FQDN_NFT_FILE" 2>/dev/null; then
      legacy_vpnmark_present=1
    fi

    legacy_firewall_include_present=0
    if uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=include$/\1/p" | while IFS= read -r sec; do
      [ -n "$sec" ] || continue
      p="$(common_uci_path_value "$(uci -q get "$sec.path" 2>/dev/null || true)")"
      case "$p" in
        /etc/domain-routing/90-domain-routing.nft|/etc/domain-routing/90-xfree-toolbox-fqdn-routing.nft|"$OLD_FQDN_NFT_FILE"|"$INTERMEDIATE_FQDN_NFT_FILE"|"$LEGACY_FQDN_NFT_FILE"|"$LEGACY_INTERMEDIATE_FQDN_NFT_FILE")
          echo 1
          break
          ;;
      esac
    done | grep -q 1; then
      legacy_firewall_include_present=1
    fi

    common_strip_legacy_vpnmark_from_autogen_nft "$FQDN_NFT_FILE" || true
    # Important: do not pass canonical path here, otherwise helper removes canonical include too.
    common_firewall_remove_fqdn_includes "" "1" "1"

    if [ "$legacy_vpnmark_present" = "1" ] || [ "$legacy_firewall_include_present" = "1" ]; then
      impact_mark_iface "legacy vpnmark nft/include cleanup applied"
    fi
    firewall_changed=1
  fi

  if [ "$firewall_changed" = "1" ]; then
    [ "$DRY_RUN" = "1" ] || uci commit firewall 2>/dev/null || true
  fi
fi

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" 2>/dev/null || printf '%s\n' "$ROOT_DIR/profiles/default")"
DNS_ROUTING_PROFILE_DNS_DIR="$PROFILE_DIR/dns-routing/dns"
DNS_ROUTING_STATE_DNS_DIR="$XFREE_DNS_ROUTING_ROOT/state/dns"

if [ -d "$DNS_ROUTING_PROFILE_DNS_DIR" ] && [ ! -d "$DNS_ROUTING_STATE_DNS_DIR" ]; then
  migration_say "[*] dns-routing: создаю state/dns из активного профиля"
  migration_summary_add "dns-routing state/dns created from active profile"
  migration_log "[START] dns-routing profile state import: $DNS_ROUTING_PROFILE_DNS_DIR -> $DNS_ROUTING_STATE_DNS_DIR"
  if [ "$DRY_RUN" != "1" ]; then
    mkdir -p "$DNS_ROUTING_STATE_DNS_DIR"
    cp -a "$DNS_ROUTING_PROFILE_DNS_DIR/." "$DNS_ROUTING_STATE_DNS_DIR/" 2>/dev/null || true
  fi
  migration_log "[DONE] dns-routing profile state import"
fi

OLD_HOTPLUG_FILE="/etc/hotplug.d/iface/90-domain-routing"
NEW_HOTPLUG_FILE="/etc/hotplug.d/iface/90-xfree-toolbox-routing"
OLD_SELF_ROUTE_HOTPLUG_FILE="/etc/hotplug.d/iface/95-xfree-self-route"
NEW_SELF_ROUTE_HOTPLUG_FILE="/etc/hotplug.d/iface/95-xfree-toolbox-self-route"

if [ -f "$OLD_HOTPLUG_FILE" ] && [ ! -e "$NEW_HOTPLUG_FILE" ] && [ ! -L "$NEW_HOTPLUG_FILE" ]; then
  migration_say "[*] hotplug: $OLD_HOTPLUG_FILE -> $NEW_HOTPLUG_FILE"
  migration_summary_add "hotplug renamed: $OLD_HOTPLUG_FILE -> $NEW_HOTPLUG_FILE"
  migration_log "[START] hotplug rename: $OLD_HOTPLUG_FILE -> $NEW_HOTPLUG_FILE"
  if [ "$DRY_RUN" != "1" ]; then
    mv "$OLD_HOTPLUG_FILE" "$NEW_HOTPLUG_FILE"
    chmod +x "$NEW_HOTPLUG_FILE" 2>/dev/null || true
  fi
  migration_log "[DONE] hotplug rename"
  impact_mark_iface "iface-routing hotplug renamed to canonical filename"
elif [ -f "$OLD_HOTPLUG_FILE" ] && [ -f "$NEW_HOTPLUG_FILE" ]; then
  if command -v cmp >/dev/null 2>&1 && cmp -s "$OLD_HOTPLUG_FILE" "$NEW_HOTPLUG_FILE"; then
    migration_say "[*] hotplug: удаляю дубликат $OLD_HOTPLUG_FILE"
    migration_summary_add "Удалён hotplug duplicate: $OLD_HOTPLUG_FILE"
    migration_log "[START] hotplug duplicate cleanup: $OLD_HOTPLUG_FILE"
    [ "$DRY_RUN" = "1" ] || rm -f "$OLD_HOTPLUG_FILE"
    migration_log "[DONE] hotplug duplicate cleanup"
    impact_mark_iface "legacy iface-routing hotplug duplicate removed"
  else
    migration_log "[WARN] hotplug legacy file left in place because new file already exists: $OLD_HOTPLUG_FILE"
  fi
fi

if [ -f "$OLD_SELF_ROUTE_HOTPLUG_FILE" ] && [ ! -e "$NEW_SELF_ROUTE_HOTPLUG_FILE" ] && [ ! -L "$NEW_SELF_ROUTE_HOTPLUG_FILE" ]; then
  migration_say "[*] hotplug: $OLD_SELF_ROUTE_HOTPLUG_FILE -> $NEW_SELF_ROUTE_HOTPLUG_FILE"
  migration_summary_add "self-route hotplug renamed: $OLD_SELF_ROUTE_HOTPLUG_FILE -> $NEW_SELF_ROUTE_HOTPLUG_FILE"
  migration_log "[START] self-route hotplug rename: $OLD_SELF_ROUTE_HOTPLUG_FILE -> $NEW_SELF_ROUTE_HOTPLUG_FILE"
  if [ "$DRY_RUN" != "1" ]; then
    mv "$OLD_SELF_ROUTE_HOTPLUG_FILE" "$NEW_SELF_ROUTE_HOTPLUG_FILE"
    chmod +x "$NEW_SELF_ROUTE_HOTPLUG_FILE" 2>/dev/null || true
  fi
  migration_log "[DONE] self-route hotplug rename"
  impact_mark_self_route "self-route hotplug renamed to canonical filename"
elif [ -f "$OLD_SELF_ROUTE_HOTPLUG_FILE" ] && [ -f "$NEW_SELF_ROUTE_HOTPLUG_FILE" ]; then
  if command -v cmp >/dev/null 2>&1 && cmp -s "$OLD_SELF_ROUTE_HOTPLUG_FILE" "$NEW_SELF_ROUTE_HOTPLUG_FILE"; then
    migration_say "[*] hotplug: удаляю дубликат $OLD_SELF_ROUTE_HOTPLUG_FILE"
    migration_summary_add "Удалён self-route hotplug duplicate: $OLD_SELF_ROUTE_HOTPLUG_FILE"
    migration_log "[START] self-route hotplug duplicate cleanup: $OLD_SELF_ROUTE_HOTPLUG_FILE"
    [ "$DRY_RUN" = "1" ] || rm -f "$OLD_SELF_ROUTE_HOTPLUG_FILE"
    migration_log "[DONE] self-route hotplug duplicate cleanup"
    impact_mark_self_route "legacy self-route hotplug duplicate removed"
  else
    migration_log "[WARN] self-route legacy hotplug left in place because new file already exists: $OLD_SELF_ROUTE_HOTPLUG_FILE"
  fi
fi

migration_log "[END] migration data phase"
migration_say "[*] Миграция: фаза удаления старых путей (после переноса)..."
migration_log "[START] legacy path cleanup phase (post-migration)"

LEGACY_PATH_CLEANUP_COUNT=0
if [ -e "/etc/domain-routing" ] || [ -L "/etc/domain-routing" ]; then
  LEGACY_PATH_CLEANUP_COUNT=$((LEGACY_PATH_CLEANUP_COUNT + 1))
  remove_legacy_path "/etc/domain-routing" "domain-routing state"
fi
if [ -e "/etc/xfree-utils/domain-routing" ] || [ -L "/etc/xfree-utils/domain-routing" ]; then
  LEGACY_PATH_CLEANUP_COUNT=$((LEGACY_PATH_CLEANUP_COUNT + 1))
  remove_legacy_path "/etc/xfree-utils/domain-routing" "xfree-utils domain-routing state"
fi
if [ -e "/etc/xfree-utils/awg-ingress" ] || [ -L "/etc/xfree-utils/awg-ingress" ]; then
  LEGACY_PATH_CLEANUP_COUNT=$((LEGACY_PATH_CLEANUP_COUNT + 1))
  remove_legacy_path "/etc/xfree-utils/awg-ingress" "xfree-utils awg-ingress state"
fi
if [ -e "/etc/xfree-utils/vk-turn" ] || [ -L "/etc/xfree-utils/vk-turn" ]; then
  LEGACY_PATH_CLEANUP_COUNT=$((LEGACY_PATH_CLEANUP_COUNT + 1))
  remove_legacy_path "/etc/xfree-utils/vk-turn" "xfree-utils vk-turn state"
fi
if [ -e "/etc/dnsmasq.d/domain-routing" ] || [ -L "/etc/dnsmasq.d/domain-routing" ]; then
  LEGACY_PATH_CLEANUP_COUNT=$((LEGACY_PATH_CLEANUP_COUNT + 1))
  remove_legacy_path "/etc/dnsmasq.d/domain-routing" "dnsmasq legacy confdir"
fi
if [ -e "$XFREE_DOMAIN_ROUTING_ROOT" ] || [ -L "$XFREE_DOMAIN_ROUTING_ROOT" ]; then
  LEGACY_PATH_CLEANUP_COUNT=$((LEGACY_PATH_CLEANUP_COUNT + 1))
  remove_legacy_path "$XFREE_DOMAIN_ROUTING_ROOT" "xfree-toolbox migrated domain-routing state"
fi

if [ "$LEGACY_PATH_CLEANUP_COUNT" -eq 0 ]; then
  migration_say "[*] Миграция: старых путей для удаления не найдено (уже чисто)"
  migration_summary_add "Legacy paths: старых не найдено"
  migration_log "[OK] legacy path cleanup phase: nothing to remove"
else
  migration_say "[*] Миграция: удалено устаревших корневых путей: $LEGACY_PATH_CLEANUP_COUNT"
  migration_summary_add "Legacy paths: удалено $LEGACY_PATH_CLEANUP_COUNT"
  migration_log "[OK] legacy path cleanup phase: removed $LEGACY_PATH_CLEANUP_COUNT path(s)"
fi

CHECK_SCRIPT="$ROOT_DIR/system/check-migration.sh"
if [ -f "$CHECK_SCRIPT" ]; then
  migration_say "[*] Проверяю результат миграции"
  if [ "$DRY_RUN" != "1" ]; then
    if sh "$CHECK_SCRIPT" > "$MIGRATION_CHECK_REPORT" 2>&1; then
      migration_summary_add "Проверка миграции: OK"
    else
      migration_summary_add "Проверка миграции: есть предупреждения, см. $MIGRATION_CHECK_REPORT"
    fi
  fi
fi

if [ "$DRY_RUN" != "1" ]; then
  if ! grep -q '^- ' "$MIGRATION_SUMMARY" 2>/dev/null; then
    migration_summary_add "Изменений не потребовалось"
  fi
  if [ -f "$MIGRATION_CHECK_REPORT" ]; then
    {
      printf '\nПроверка:\n'
      sed 's/^/  /' "$MIGRATION_CHECK_REPORT"
    } >> "$MIGRATION_SUMMARY" 2>/dev/null || true
  fi

  {
    printf 'state_root=%s\n' "$XFREE_STATE_ROOT"
    printf 'last_run=%s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"
  } > "$MIGRATION_MARKER" 2>/dev/null || true
fi

write_migration_impact
run_post_migration_repair

migration_log "[OK] state root migration completed"
migration_say "[✓] Миграция состояния завершена"
