#!/bin/sh
# shellcheck shell=sh
# Настройки автообновления (режим, расписание).
# Usage: auto-update-settings-menu.sh ui

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/ui.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"
ui_init
ui_trap_cleanup_on_exit
set +e

export AUTO_UPDATE_ROOT_DIR="$ROOT_DIR"
export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/auto-update-lib.sh"

auto_update_settings_show_status() {
	report="${UI_TMP_ROOT:-/tmp}/auto-update-status.$$"
	auto_update_status_text >"$report" 2>&1
	printf '\n--- crontab ---\n' >>"$report"
	auto_update_crontab_read | grep -F 'auto-update' >>"$report" 2>&1 || \
		printf '(нет строк auto-update)\n' >>"$report"
	ui_show_textbox "Автообновление — статус" "$report" 24 "${UI_WIDTH:-78}" || true
	rm -f "$report" 2>/dev/null || true
}

auto_update_settings_pick_mode() {
	auto_update_load_config
	choice="$(ui_menu "Режим автообновления" \
"Текущий: $(auto_update_mode_label "$AUTO_UPDATE_MODE")

Выберите, что выполнять по расписанию:" 22 90 10 \
		"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS" "Списки upstream (без пакета toolbox)" \
		"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS_PACKAGE" "Списки upstream + обновление пакета" \
		"$AUTO_UPDATE_MODE_TEMPLATES_SYNC" "Обновить и применить (как п.1 в шаблонах)" \
		"0" "Назад" || true)"
	[ -n "${choice:-}" ] || return 0
	[ "$choice" != "0" ] || return 0
	if ! auto_update_normalize_mode "$choice" >/dev/null 2>&1; then
		ui_msgbox "Автообновление" "Неизвестный режим: $choice"
		return 0
	fi
	auto_update_conf_set "$(auto_update_conf_path)" MODE "$choice"
	if [ "$AUTO_UPDATE_ENABLED" = "1" ]; then
		auto_update_cron_install >/dev/null 2>&1 || true
	fi
	ui_msgbox "Автообновление" "Сохранено:
$(auto_update_mode_label "$choice")"
}

auto_update_settings_edit_schedule() {
	auto_update_load_config
	hour="$(ui_inputbox_or_back "Час запуска (0–23)" \
"Местное время роутера.
Текущий: $AUTO_UPDATE_SCHEDULE_HOUR" \
		"$AUTO_UPDATE_SCHEDULE_HOUR")" || return 0
	[ -n "$hour" ] || return 0
	minute="$(ui_inputbox_or_back "Минута (0–59)" \
"Текущий: $AUTO_UPDATE_SCHEDULE_MINUTE" \
		"$AUTO_UPDATE_SCHEDULE_MINUTE")" || return 0
	[ -n "$minute" ] || return 0

	_h="$(auto_update_normalize_schedule_part "$hour" 0 23)" || {
		ui_msgbox "Автообновление" "Некорректный час: $hour"
		return 0
	}
	_m="$(auto_update_normalize_schedule_part "$minute" 0 59)" || {
		ui_msgbox "Автообновление" "Некорректная минута: $minute"
		return 0
	}

	_cf="$(auto_update_conf_path)"
	auto_update_conf_set "$_cf" SCHEDULE_HOUR "$_h"
	auto_update_conf_set "$_cf" SCHEDULE_MINUTE "$_m"
	if [ "$AUTO_UPDATE_ENABLED" = "1" ]; then
		auto_update_cron_install >/dev/null 2>&1 || true
	fi
	ui_msgbox "Автообновление" "Расписание: $(printf '%02d:%02d' "$_h" "$_m") (местное время)"
}

auto_update_settings_menu() {
	while :; do
		auto_update_load_config
		_en_label='выкл'
		[ "$AUTO_UPDATE_ENABLED" = "1" ] && _en_label='вкл'
		choice="$(ui_menu "Настройка автообновления" \
"Состояние: $_en_label
Режим: $(auto_update_mode_label "$AUTO_UPDATE_MODE")
Время: $(printf '%02d:%02d' "$AUTO_UPDATE_SCHEDULE_HOUR" "$AUTO_UPDATE_SCHEDULE_MINUTE") (местное)" \
			22 90 12 \
			"1" "Режим обновления" \
			"2" "Время запуска (час и минута)" \
			"3" "Статус и cron" \
			"0" "Назад" || true)"
		[ -n "${choice:-}" ] || return 0
		case "$choice" in
			0) return 0 ;;
			1) auto_update_settings_pick_mode ;;
			2) auto_update_settings_edit_schedule ;;
			3) auto_update_settings_show_status ;;
		esac
	done
}

case "${1:-ui}" in
	ui) auto_update_settings_menu ;;
	*) echo "Usage: $0 [ui]" >&2; exit 1 ;;
esac
