#!/bin/sh
# Print recommended install/upgrade channel for this OpenWrt version.
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
INSTALL_CHANNEL_SH="$ROOT_DIR/lib/install-channel.sh"

[ -f "$INSTALL_CHANNEL_SH" ] || {
  echo "[-] missing: $INSTALL_CHANNEL_SH" >&2
  exit 1
}
# shellcheck disable=SC1090
. "$INSTALL_CHANNEL_SH"

channel="$(xfree_resolve_update_channel)"
xfree_print_openwrt_version_line
printf '[*] Channel         : %s\n' "$channel"
[ -n "${XFREE_CHANNEL_REASON:-}" ] && printf '[*] Channel reason  : %s\n' "$XFREE_CHANNEL_REASON"

case "$channel" in
  tar)
    echo "Recommended channel: tar (xfree-toolbox.tar.gz + system/self-update.sh or ci deploy)"
    echo "Fallback on 25+: same tar via system/install-bootstrap.sh"
    ;;
  apk)
    echo "Recommended channel: apk (package xfree-toolbox; same payload as tar)"
    echo "Fallback: tar — wget/self-update/install-bootstrap"
    if owrt_apk_package_installed; then
      echo "Installed: apk package xfree-toolbox is present"
      echo "Upgrade hint: apk upgrade xfree-toolbox  (avoid tar self-update unless --force)"
    else
      echo "Installed: apk package xfree-toolbox is NOT in world (tar tree possible)"
      echo "Adopt hint: self-update --check-only then apk add xfree-toolbox (feed); further upgrades via apk"
    fi
    ;;
  *)
    echo "Recommended channel: unknown — use tar; see README and build/openwrt/xfree-toolbox/README.md"
    ;;
esac
