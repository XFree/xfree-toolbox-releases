#!/bin/sh
# shellcheck shell=sh
# Handlers for system/mesh/menu.yaml

mesh_menu_configure_roaming() {
	if ! ui_confirm "Бесшовный роуминг" "Выровнять параметры бесшовного роуминга на точках доступа:
- Включение 802.11r Fast BSS Transition
- Единый Mobility Domain на всех диапазонах (2.4 GHz и 5 GHz)
- Включение 802.11k RRM и 802.11v BSS Transition
- Включение STP=1 и IGMP Snooping на br-lan (защита от петель)

Существующие имена сетей (SSID) и пароли НЕ изменяются.

Продолжить?"; then
		return 0
	fi
	ui_menu_invoke_with_output "Выравнивание роуминга" \
		sh "$SCRIPT_DIR/../configure-mesh.sh" --role master --yes
}

mesh_menu_configure_master() {
	_cur_s5="$(uci -q get wireless.default_radio1.ssid 2>/dev/null || true)"
	[ -z "$_cur_s5" ] && _cur_s5="$(uci -q get wireless.wifinet1.ssid 2>/dev/null || true)"
	_cur_s2="$(uci -q get wireless.default_radio0.ssid 2>/dev/null || true)"
	[ -z "$_cur_s2" ] && _cur_s2="$(uci -q get wireless.wifinet0.ssid 2>/dev/null || true)"

	_summary="Настройка основного роутера (Mesh Master):
- Включение STP и IGMP Snooping на br-lan (защита бэкхола)
- Фиксация канала 5 GHz на 36 (для стабильности mesh)
- Создание 802.11s Mesh интерфейса (mesh5g, WPA3-SAE)
- Включение 802.11r/k/v бесшовного роуминга

Существующие точки доступа (${_cur_s5:-5G} / ${_cur_s2:-2.4G}) и пароли сохраняются.

Продолжить?"

	if ! ui_confirm "Mesh Master" "$_summary"; then
		return 0
	fi
	ui_menu_invoke_with_output "Настройка Mesh Master" \
		sh "$SCRIPT_DIR/../configure-mesh.sh" --role master --yes
}

mesh_menu_configure_satellite() {
	# 1. Проверка wpad-mesh
	_has_mesh=0
	if command -v apk >/dev/null 2>&1; then
		apk info -e wpad-mesh-mbedtls >/dev/null 2>&1 && _has_mesh=1
	elif command -v opkg >/dev/null 2>&1; then
		opkg list-installed wpad-mesh-mbedtls 2>/dev/null | grep -q '^wpad-mesh-mbedtls' && _has_mesh=1
	fi
	if [ "$_has_mesh" = "0" ]; then
		if ui_confirm "wpad-mesh" "Для работы 802.11s Mesh требуется wpad-mesh-mbedtls.
Установить wpad-mesh сейчас? (Потребуется перезагрузка)"; then
			ui_menu_invoke_with_output "Установка wpad-mesh-mbedtls" \
				sh "$SCRIPT_DIR/../install-wpad-mesh.sh" --yes
			return 0
		fi
	fi

	# 2. Опрос параметров у пользователя
	_def_gw="$(ip route 2>/dev/null | awk '/default/{print $3; exit}' || true)"
	[ -z "$_def_gw" ] && _def_gw="$(uci -q get network.lan.gateway 2>/dev/null || echo '192.168.1.1')"
	_gw="$(ui_inputbox "Mesh Satellite: Шлюз" "IP-адрес основного роутера (Master):" "$_def_gw" || true)"
	[ -n "$_gw" ] || return 0

	_prefix="${_gw%.*}"
	_suggested_ip="${_prefix}.2"
	_lan_ip="$(ui_inputbox "Mesh Satellite: LAN IP" "Уникальный LAN IP для этого сателлита (в подсети ${_prefix}.x):" "$_suggested_ip" || true)"
	[ -n "$_lan_ip" ] || return 0

	_base_ssid="$(ui_inputbox "Mesh Satellite: Имя Wi-Fi (SSID)" "Имя беспроводной сети (SSID) как на Master роутере:" "MyNetwork" || true)"
	[ -n "$_base_ssid" ] || return 0

	# Нормализация имен для диапазонов
	case "$_base_ssid" in
		*-5G|*_5G|*-5g|*_5g)
			_s5="$_base_ssid"
			_s2="${_base_ssid%[_-][55][Gg]}"
			;;
		*-2.4G|*_2.4G|*-2.4g|*_2.4g)
			_s2="$_base_ssid"
			_s5="${_base_ssid%[_-]2.4[Gg]}_5G"
			;;
		*)
			_s2="$_base_ssid"
			_s5="${_base_ssid}_5G"
			;;
	esac

	_key="$(ui_inputbox "Mesh Satellite: Пароль Wi-Fi" "Пароль сети Wi-Fi (как на Master роутере):" "" || true)"
	[ -n "$_key" ] || return 0

	# 3. Подтверждение сводки
	_msg="Применить параметры ведомого узла (Satellite)?

- Шлюз и DNS:       $_gw
- Новый LAN IP:     $_lan_ip
- Точка 5 GHz:      $_s5 (канал 36)
- Точка 2.4 GHz:    $_s2
- 802.11s Mesh:     ${_s5}_MESH (WPA3-SAE)
- Сетевой порт WAN: добавляется в br-lan
- Службы:           DHCP и firewall на сателлите отключаются"

	if ! ui_confirm "Подтверждение настройки" "$_msg"; then
		return 0
	fi

	ui_menu_invoke_with_output "Настройка Mesh Satellite" \
		sh "$SCRIPT_DIR/../configure-mesh.sh" --role satellite --yes \
			--gateway "$_gw" --lan-ip "$_lan_ip" \
			--ssid-5g "$_s5" --key-5g "$_key" \
			--ssid-2g "$_s2" --key-2g "$_key" \
			--channel-5g 36
}

mesh_menu_install_wpad() {
	if ! ui_confirm "wpad-mesh-mbedtls" "Замена wpad-basic → wpad-mesh для 802.11s mesh.

Возможен обрыв Wi-Fi uplink. После смены пакета роутер будет перезагружен.
Пакеты скачиваются локально (apk fetch); при сбое — откат wpad-basic из кэша.

Продолжить?"; then
		return 0
	fi
	ui_menu_invoke_with_output "Установка wpad-mesh-mbedtls" \
		sh "$SCRIPT_DIR/../install-wpad-mesh.sh" --yes
}

