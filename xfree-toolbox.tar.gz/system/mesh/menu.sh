#!/bin/sh
# shellcheck shell=sh
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
exec "$SCRIPT_DIR/menu.gen.sh" "$@"

