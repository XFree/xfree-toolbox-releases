#!/bin/sh
# shellcheck shell=sh
# Проверка и установка команд в PATH (xft, usb-modem-power-cycle).

router_cmd_resolve_target() {
    cmd_path="$1"
    if command -v readlink >/dev/null 2>&1; then
        readlink -f "$cmd_path" 2>/dev/null || printf '%s\n' "$cmd_path"
        return 0
    fi
    printf '%s\n' "$cmd_path"
}

router_cmd_install_launcher() {
    root="${1:-/root/xfree-toolbox}"
    launcher="${2:-xft}"
    desired="$root/menu.sh"

    [ -f "$desired" ] || return 1

    if router_cmd_check_launcher "$root" "$launcher" >/dev/null 2>&1; then
        return 0
    fi

    for bin_dir in /usr/bin /usr/sbin; do
        [ -d "$bin_dir" ] || continue
        if [ -w "$bin_dir" ] || [ ! -e "$bin_dir/$launcher" ]; then
            ln -sfn "$desired" "$bin_dir/$launcher" 2>/dev/null || continue
            if command -v "$launcher" >/dev/null 2>&1; then
                fixed="$(command -v "$launcher")"
                fixed_target="$(router_cmd_resolve_target "$fixed")"
                desired_target="$(router_cmd_resolve_target "$desired")"
                [ "$fixed_target" = "$desired_target" ] && return 0
            fi
        fi
    done
    return 1
}

router_cmd_check_launcher() {
    root="${1:-/root/xfree-toolbox}"
    launcher="${2:-xft}"
    desired="$root/menu.sh"

    if [ ! -f "$desired" ]; then
        printf '[FAIL] %s: нет %s\n' "$launcher" "$desired"
        return 1
    fi

    current="$(command -v "$launcher" 2>/dev/null || true)"
    if [ -z "${current:-}" ]; then
        printf '[FAIL] %s: не в PATH\n' "$launcher"
        return 1
    fi

    cur_target="$(router_cmd_resolve_target "$current")"
    want_target="$(router_cmd_resolve_target "$desired")"
    if [ "$cur_target" = "$want_target" ]; then
        printf '[OK] %s → %s\n' "$launcher" "$cur_target"
        return 0
    fi

    printf '[FAIL] %s → %s (ожидалось %s)\n' "$launcher" "$cur_target" "$want_target"
    return 1
}

router_cmd_install_usb_modem() {
    root="${1:-/root/xfree-toolbox}"
    usb_script="$root/system/hardware/usb-modem-power-cycle.sh"

    [ -f "$usb_script" ] || return 0

    if router_cmd_check_usb_modem "$root" >/dev/null 2>&1; then
        return 0
    fi

    chmod +x "$usb_script" 2>/dev/null || true

    for bin_dir in /usr/sbin /usr/bin; do
        [ -d "$bin_dir" ] || continue
        if [ -w "$bin_dir" ] || [ ! -e "$bin_dir/usb-modem-power-cycle" ]; then
            if ln -sfn "$usb_script" "$bin_dir/usb-modem-power-cycle" 2>/dev/null; then
                if command -v usb-modem-power-cycle >/dev/null 2>&1; then
                    fixed="$(command -v usb-modem-power-cycle)"
                    fixed_target="$(router_cmd_resolve_target "$fixed")"
                    want_target="$(router_cmd_resolve_target "$usb_script")"
                    [ "$fixed_target" = "$want_target" ] && return 0
                fi
            fi
        fi
    done
    return 1
}

router_cmd_check_usb_modem() {
    root="${1:-/root/xfree-toolbox}"
    usb_script="$root/system/hardware/usb-modem-power-cycle.sh"
    name="usb-modem-power-cycle"

    if [ ! -f "$usb_script" ]; then
        printf '[WARN] %s: скрипт отсутствует (%s) — пропуск\n' "$name" "$usb_script"
        return 0
    fi

    current="$(command -v "$name" 2>/dev/null || true)"
    if [ -z "${current:-}" ]; then
        printf '[FAIL] %s: не в PATH\n' "$name"
        return 1
    fi

    cur_target="$(router_cmd_resolve_target "$current")"
    want_target="$(router_cmd_resolve_target "$usb_script")"
    if [ "$cur_target" = "$want_target" ]; then
        printf '[OK] %s → %s\n' "$name" "$cur_target"
        return 0
    fi

    printf '[FAIL] %s → %s (ожидалось %s)\n' "$name" "$cur_target" "$want_target"
    return 1
}

router_cmd_check_all() {
    root="${1:-/root/xfree-toolbox}"
    launcher="${2:-xft}"
    failed=0

    router_cmd_check_launcher "$root" "$launcher" || failed=$((failed + 1))
    router_cmd_check_usb_modem "$root" || failed=$((failed + 1))

    return "$failed"
}

router_cmd_install_all() {
    root="${1:-/root/xfree-toolbox}"
    launcher="${2:-xft}"
    failed=0

    router_cmd_install_launcher "$root" "$launcher" || failed=$((failed + 1))
    router_cmd_install_usb_modem "$root" || failed=$((failed + 1))

    return "$failed"
}

# Старт menu.sh: проверить PATH-команды, при необходимости поставить симлинки (без вывода).
router_cmd_ensure_all() {
    root="${1:-/root/xfree-toolbox}"
    launcher="${2:-xft}"

    if router_cmd_check_all "$root" "$launcher" >/dev/null 2>&1; then
        return 0
    fi
    router_cmd_install_all "$root" "$launcher" >/dev/null 2>&1 || true
    router_cmd_check_all "$root" "$launcher" >/dev/null 2>&1
}
