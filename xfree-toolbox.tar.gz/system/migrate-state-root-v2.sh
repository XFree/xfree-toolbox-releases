#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$(readlink -f "$0")")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"

VERBOSE=1
DRY_RUN=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --quiet)
      VERBOSE=0
      ;;
    --dry-run)
      DRY_RUN=1
      ;;
    -h|--help)
      cat <<EOF
Usage: $0 [--quiet] [--dry-run]

Migration v2 for iface-routing metadata layout.
Normalizes iface.conf so it keeps only interface/runtime binding data while
generator/provider metadata remains in source.conf.meta.
EOF
      exit 0
      ;;
    *)
      warn "Неизвестный параметр миграции v2: $1"
      ;;
  esac
  shift
done

: "${XFREE_STATE_ROOT:=/etc/xfree-toolbox}"

MIGRATION_LOG="$XFREE_STATE_ROOT/migration.log"
MIGRATION_SUMMARY="$XFREE_STATE_ROOT/migration-summary.txt"
MIGRATION_MARKER="$XFREE_STATE_ROOT/.state-root-migrated-v2"
MIGRATION_IMPACT="$XFREE_STATE_ROOT/migration-impact.env"

NEEDS_IFACE_ROUTING_APPLY=0
NEEDS_DNS_ROUTING_APPLY=0
NEEDS_SELF_ROUTE_REFRESH=0
IMPACT_REASONS=""

migration_say() {
  [ "$VERBOSE" = "1" ] || return 0
  printf '%s\n' "$*"
}

migration_log() {
  [ "$DRY_RUN" != "1" ] || return 0
  mkdir -p "$XFREE_STATE_ROOT" 2>/dev/null || true
  common_append_log_file "$MIGRATION_LOG" "$*"
}

migration_summary_add() {
  [ "$DRY_RUN" != "1" ] || return 0
  mkdir -p "$XFREE_STATE_ROOT" 2>/dev/null || true
  if [ ! -f "$MIGRATION_SUMMARY" ]; then
    {
      printf 'Миграция xfree-toolbox\n'
      printf 'Время: %s\n\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"
      printf 'Изменения:\n'
    } > "$MIGRATION_SUMMARY" 2>/dev/null || true
  fi
  printf -- '- %s\n' "$*" >> "$MIGRATION_SUMMARY" 2>/dev/null || true
}

impact_add_reason() {
  reason="$1"
  [ -n "$reason" ] || return 0
  IMPACT_REASONS="${IMPACT_REASONS}${IMPACT_REASONS:+; }$reason"
}

impact_mark_iface() {
  NEEDS_IFACE_ROUTING_APPLY=1
  impact_add_reason "$1"
}

impact_mark_dns() {
  NEEDS_DNS_ROUTING_APPLY=1
  impact_add_reason "$1"
}

impact_mark_self_route() {
  NEEDS_SELF_ROUTE_REFRESH=1
  impact_add_reason "$1"
}

write_migration_impact() {
  [ "$DRY_RUN" != "1" ] || return 0
  mkdir -p "$XFREE_STATE_ROOT" 2>/dev/null || true
  {
    printf 'NEEDS_IFACE_ROUTING_APPLY=%s\n' "$NEEDS_IFACE_ROUTING_APPLY"
    printf 'NEEDS_DNS_ROUTING_APPLY=%s\n' "$NEEDS_DNS_ROUTING_APPLY"
    printf 'NEEDS_SELF_ROUTE_REFRESH=%s\n' "$NEEDS_SELF_ROUTE_REFRESH"
    printf 'IMPACT_REASONS=%s\n' "$(printf '%s' "$IMPACT_REASONS" | sed "s/'/'\\\\''/g; s/^/'/; s/$/'/")"
  } > "$MIGRATION_IMPACT"
}

run_post_migration_repair() {
  [ "$DRY_RUN" != "1" ] || return 0
  [ "$NEEDS_IFACE_ROUTING_APPLY" = "1" ] || [ "$NEEDS_DNS_ROUTING_APPLY" = "1" ] || [ "$NEEDS_SELF_ROUTE_REFRESH" = "1" ] || return 0

  profile_dir="$(common_profile_dir "$ROOT_DIR")"

  if [ "$NEEDS_IFACE_ROUTING_APPLY" = "1" ] || [ "$NEEDS_DNS_ROUTING_APPLY" = "1" ]; then
    if [ -f "$ROOT_DIR/lib/apply-dns-and-iface-routing.sh" ]; then
      migration_say "[*] Post-migration repair: dns+iface apply (PROFILE_DIR=$profile_dir)"
      if "$ROOT_DIR/lib/apply-dns-and-iface-routing.sh" --profile-dir "$profile_dir"; then
        migration_log "[OK] post-repair dns+iface apply"
      else
        migration_log "[WARN] post-repair dns+iface apply failed"
        migration_summary_add "Post-repair: dns+iface apply завершился с ошибкой"
      fi
    else
      migration_log "[WARN] post-repair wrapper missing: lib/apply-dns-and-iface-routing.sh"
    fi
  fi

  if [ "$NEEDS_SELF_ROUTE_REFRESH" = "1" ] && [ -x "$ROOT_DIR/iface-routing/self-route/apply.sh" ]; then
    migration_say "[*] Post-migration repair: self-route refresh"
    if PROFILE_DIR="$profile_dir" "$ROOT_DIR/iface-routing/self-route/apply.sh" --run-hotplug; then
      migration_log "[OK] post-repair self-route refresh"
    else
      migration_log "[WARN] post-repair self-route refresh failed"
      migration_summary_add "Post-repair: self-route refresh завершился с ошибкой"
    fi
  fi
}

conf_get() {
  file="$1"
  key="$2"
  [ -f "$file" ] || return 0
  awk -F= -v want="$key" '
    $1 == want {
      v = substr($0, index($0, "=") + 1)
      sub(/^[[:space:]]+/, "", v)
      sub(/[[:space:]]+$/, "", v)
      gsub(/^\047|\047$/, "", v)
      print v
      exit
    }
  ' "$file"
}

conf_upsert() {
  file="$1"
  key="$2"
  value="$3"
  [ -f "$file" ] || return 0
  tmp="${file}.tmp.$$"
  awk -v key="$key" -v value="$value" '
    BEGIN { done = 0 }
    $0 ~ ("^" key "=") {
      print key "=\047" value "\047"
      done = 1
      next
    }
    { print }
    END {
      if (!done) {
        print key "=\047" value "\047"
      }
    }
  ' "$file" > "$tmp"
  mv "$tmp" "$file"
}

write_iface_conf() {
  dst="$1"
  iface="$2"
  vpn_dev="$3"
  source_conf_name="$4"
  source_meta_name="$5"
  network_delete_sections="$6"
  firewall_model="$7"
  mark_hex="$8"
  route_table_id="$9"
  route_table_name="${10}"
  ip_rule_pref="${11}"
  routing_mode="${12}"
  peer_section="${13}"
  keepalive_default="${14}"
  test_ip="${15}"
  nft_fqdn4_set_name="${16}"
  nft_fqdn6_set_name="${17}"
  nft_prefix4_set_name="${18}"
  nft_prefix6_set_name="${19}"
  nft_chain_name="${20}"
  self_route_via="${21}"
  protocol_label="${22:-AmneziaWG}"

  cat > "$dst" <<EOF
# shellcheck shell=sh

INTERFACE_NAME='$iface'
VPN_DEV='$vpn_dev'

SOURCE_CONF='$source_conf_name'
SOURCE_META='$source_meta_name'

NETWORK_DELETE_SECTIONS='$network_delete_sections'
FIREWALL_MODEL='$firewall_model'

MARK_HEX='$mark_hex'
ROUTE_TABLE_ID='$route_table_id'
ROUTE_TABLE_NAME='$route_table_name'
IP_RULE_PREF='$ip_rule_pref'

ROUTING_MODE='$routing_mode'

PROTOCOL_LABEL='$protocol_label'
AMNEZIAWG_PEER_SECTION='$peer_section'
PERSISTENT_KEEPALIVE_DEFAULT='$keepalive_default'
TEST_IP='$test_ip'

NFT_FQDN4_SET_NAME='$nft_fqdn4_set_name'
NFT_FQDN6_SET_NAME='$nft_fqdn6_set_name'
NFT_PREFIX4_SET_NAME='$nft_prefix4_set_name'
NFT_PREFIX6_SET_NAME='$nft_prefix6_set_name'
NFT_CHAIN_NAME='$nft_chain_name'

# self-route:
# если задан интерфейс, endpoint данного интерфейса будет направляться через него.
# Пример: SELF_ROUTE_VIA='warp'
SELF_ROUTE_VIA='$self_route_via'
EOF
}

normalize_iface_conf() {
  iface_conf="$1"
  scope_label="$2"

  [ -f "$iface_conf" ] || return 0

  iface="$(conf_get "$iface_conf" "INTERFACE_NAME")"
  [ -n "$iface" ] || return 0

  vpn_dev="$(conf_get "$iface_conf" "VPN_DEV")"
  source_conf_name="$(conf_get "$iface_conf" "SOURCE_CONF")"
  source_meta_name="$(conf_get "$iface_conf" "SOURCE_META")"
  network_delete_sections="$(conf_get "$iface_conf" "NETWORK_DELETE_SECTIONS")"
  firewall_model="$(conf_get "$iface_conf" "FIREWALL_MODEL")"
  mark_hex="$(conf_get "$iface_conf" "MARK_HEX")"
  route_table_id="$(conf_get "$iface_conf" "ROUTE_TABLE_ID")"
  route_table_name="$(conf_get "$iface_conf" "ROUTE_TABLE_NAME")"
  ip_rule_pref="$(conf_get "$iface_conf" "IP_RULE_PREF")"
  routing_mode="$(conf_get "$iface_conf" "ROUTING_MODE")"
  peer_section="$(conf_get "$iface_conf" "AMNEZIAWG_PEER_SECTION")"
  keepalive_default="$(conf_get "$iface_conf" "PERSISTENT_KEEPALIVE_DEFAULT")"
  test_ip="$(conf_get "$iface_conf" "TEST_IP")"
  legacy_nft_fqdn_set_name="$(conf_get "$iface_conf" "NFT_FQDN_SET_NAME")"
  legacy_nft_prefix_set_name="$(conf_get "$iface_conf" "NFT_PREFIX_SET_NAME")"
  nft_fqdn4_set_name="$(conf_get "$iface_conf" "NFT_FQDN4_SET_NAME")"
  nft_fqdn6_set_name="$(conf_get "$iface_conf" "NFT_FQDN6_SET_NAME")"
  nft_prefix4_set_name="$(conf_get "$iface_conf" "NFT_PREFIX4_SET_NAME")"
  nft_prefix6_set_name="$(conf_get "$iface_conf" "NFT_PREFIX6_SET_NAME")"
  nft_chain_name="$(conf_get "$iface_conf" "NFT_CHAIN_NAME")"
  self_route_via="$(conf_get "$iface_conf" "SELF_ROUTE_VIA")"
  protocol_label="$(conf_get "$iface_conf" "PROTOCOL_LABEL")"

  [ -n "$vpn_dev" ] || vpn_dev="$iface"
  [ -n "$source_conf_name" ] || source_conf_name="source.conf"
  [ -n "$source_meta_name" ] || source_meta_name="source.conf.meta"
  [ -n "$network_delete_sections" ] || network_delete_sections="$iface amneziawg_$iface"
  [ -n "$firewall_model" ] || firewall_model="shared-vpn-zone"
  [ -n "$route_table_name" ] || route_table_name="xfree-routing-rt-$iface"
  [ -n "$routing_mode" ] || routing_mode="vpn"
  [ -n "$peer_section" ] || peer_section="network.@amneziawg_$iface[0]"
  [ -n "$keepalive_default" ] || keepalive_default="25"
  [ -n "$test_ip" ] || test_ip="1.1.1.1"
  [ -n "$protocol_label" ] || protocol_label="AmneziaWG"

  # Legacy single-stack names become canonical IPv4 names so existing references
  # keep working after migration. IPv6 names are synthesized canonically.
  [ -n "$nft_fqdn4_set_name" ] || nft_fqdn4_set_name="$legacy_nft_fqdn_set_name"
  [ -n "$nft_prefix4_set_name" ] || nft_prefix4_set_name="$legacy_nft_prefix_set_name"
  [ -n "$nft_fqdn4_set_name" ] || nft_fqdn4_set_name="${iface}_fqdn4"
  [ -n "$nft_fqdn6_set_name" ] || nft_fqdn6_set_name="${iface}_fqdn6"
  [ -n "$nft_prefix4_set_name" ] || nft_prefix4_set_name="${iface}_prefixes4"
  [ -n "$nft_prefix6_set_name" ] || nft_prefix6_set_name="${iface}_prefixes6"
  [ -n "$nft_chain_name" ] || nft_chain_name="mangle_prerouting_$iface"

  [ -n "$mark_hex" ] || {
    migration_log "[WARN] пропускаю $iface_conf: отсутствует MARK_HEX"
    return 0
  }
  [ -n "$route_table_id" ] || {
    migration_log "[WARN] пропускаю $iface_conf: отсутствует ROUTE_TABLE_ID"
    return 0
  }
  [ -n "$ip_rule_pref" ] || {
    migration_log "[WARN] пропускаю $iface_conf: отсутствует IP_RULE_PREF"
    return 0
  }

  tmp_file="${iface_conf}.tmp.$$"
  write_iface_conf \
    "$tmp_file" \
    "$iface" \
    "$vpn_dev" \
    "$source_conf_name" \
    "$source_meta_name" \
    "$network_delete_sections" \
    "$firewall_model" \
    "$mark_hex" \
    "$route_table_id" \
    "$route_table_name" \
    "$ip_rule_pref" \
    "$routing_mode" \
    "$peer_section" \
    "$keepalive_default" \
    "$test_ip" \
    "$nft_fqdn4_set_name" \
    "$nft_fqdn6_set_name" \
    "$nft_prefix4_set_name" \
    "$nft_prefix6_set_name" \
    "$nft_chain_name" \
    "$self_route_via" \
    "$protocol_label"

  if cmp -s "$iface_conf" "$tmp_file" 2>/dev/null; then
    rm -f "$tmp_file"
    return 0
  fi

  migration_say "[*] iface-routing v2: нормализую $scope_label/$iface"
  migration_summary_add "iface-routing v2: normalized $scope_label/$iface"
  migration_log "[START] iface-routing v2 normalize: $iface_conf"
  impact_mark_iface "iface.conf normalized: $scope_label/$iface"
  [ -n "$self_route_via" ] && impact_mark_self_route "self-route config touched: $scope_label/$iface"
  if [ "$DRY_RUN" != "1" ]; then
    mv "$tmp_file" "$iface_conf"
  else
    rm -f "$tmp_file"
  fi
  migration_log "[DONE] iface-routing v2 normalize: $iface_conf"
}

normalize_source_meta_for_iface() {
  iface_conf="$1"
  scope_label="$2"

  [ -f "$iface_conf" ] || return 0
  source_meta_name="$(conf_get "$iface_conf" "SOURCE_META")"
  [ -n "$source_meta_name" ] || source_meta_name="source.conf.meta"
  config_dir="$(dirname "$iface_conf")"
  source_meta_file="$config_dir/$source_meta_name"
  [ -f "$source_meta_file" ] || return 0

  keepalive_default="$(conf_get "$iface_conf" "PERSISTENT_KEEPALIVE_DEFAULT")"
  [ -n "$keepalive_default" ] || keepalive_default="20"
  route_allowed_default="$(conf_get "$source_meta_file" "ROUTE_ALLOWED_IPS_DEFAULT")"
  case "$route_allowed_default" in
    0|1) ;;
    *) route_allowed_default="0" ;;
  esac

  changed=0
  current_schema="$(conf_get "$source_meta_file" "NAME_SCHEMA_VERSION")"
  [ "$current_schema" = "7" ] || changed=1
  current_keepalive="$(conf_get "$source_meta_file" "PERSISTENT_KEEPALIVE_DEFAULT")"
  [ "$current_keepalive" = "$keepalive_default" ] || changed=1
  current_route_allowed="$(conf_get "$source_meta_file" "ROUTE_ALLOWED_IPS_DEFAULT")"
  [ "$current_route_allowed" = "$route_allowed_default" ] || changed=1

  [ "$changed" = "1" ] || return 0

  migration_say "[*] iface-routing v2: обновляю source.conf.meta для $scope_label/$(basename "$(dirname "$config_dir")")"
  migration_summary_add "iface-routing v2: source meta normalized for $scope_label/$(basename "$(dirname "$config_dir")")"
  migration_log "[START] iface-routing v2 source.meta normalize: $source_meta_file"
  impact_mark_iface "source.conf.meta normalized: $scope_label/$(basename "$(dirname "$config_dir")")"
  if [ "$DRY_RUN" != "1" ]; then
    conf_upsert "$source_meta_file" "NAME_SCHEMA_VERSION" "7"
    conf_upsert "$source_meta_file" "PERSISTENT_KEEPALIVE_DEFAULT" "$keepalive_default"
    conf_upsert "$source_meta_file" "ROUTE_ALLOWED_IPS_DEFAULT" "$route_allowed_default"
  fi
  migration_log "[DONE] iface-routing v2 source.meta normalize: $source_meta_file"
}

normalize_tree() {
  interfaces_dir="$1"
  scope_label="$2"

  [ -d "$interfaces_dir" ] || return 0

  find "$interfaces_dir" -mindepth 3 -maxdepth 3 -type f -path '*/config/iface.conf' 2>/dev/null \
    | sort \
    | while IFS= read -r iface_conf; do
        [ -n "$iface_conf" ] || continue
        normalize_iface_conf "$iface_conf" "$scope_label"
        normalize_source_meta_for_iface "$iface_conf" "$scope_label"
      done
}

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" 2>/dev/null || printf '%s\n' "$ROOT_DIR/profiles/default")"
PROFILE_INTERFACES_DIR="$PROFILE_DIR/iface-routing/interfaces"
STATE_INTERFACES_DIR="$XFREE_STATE_ROOT/iface-routing/state/interfaces"

migration_say "[*] Миграция v2: нормализация iface.conf и source.conf.meta..."
migration_log "[START] migration v2 normalize phase"

normalize_tree "$PROFILE_INTERFACES_DIR" "profile"
normalize_tree "$STATE_INTERFACES_DIR" "state"

migration_log "[END] migration v2 normalize phase"
migration_say "[*] Миграция v2: проверка хвостов fqdn nft и firewall include..."

if [ "$DRY_RUN" != "1" ] && command -v uci >/dev/null 2>&1; then
  IFACE_RT="${XFREE_IFACE_ROUTING_ROOT:-$XFREE_STATE_ROOT/iface-routing}"
  FQDN_NFT_MIG="$IFACE_RT/generated/90-xfree-toolbox-fqdn-routing.nft"
  legacy_vpnmark_present=0
  legacy_firewall_include_present=0
  if [ ! -f "$FQDN_NFT_MIG" ]; then
    migration_say "[*] Миграция v2: файла fqdn nft не найдено ($FQDN_NFT_MIG), strip пропущен"
    migration_log "[OK] fqdn nft missing, skip strip"
  elif ! grep -qE 'vpn_fqdn4|vpn_fqdn6|vpn_prefixes4|vpn_prefixes6|@vpn_|set vpn_|meta mark set 0x00010000|meta mark set 0x10000' "$FQDN_NFT_MIG" 2>/dev/null; then
    migration_say "[*] Миграция v2: в fqdn nft legacy-строк (vpn_*, 0x10000) не найдено"
    migration_log "[OK] fqdn nft has no legacy vpnmark lines"
  else
    legacy_vpnmark_present=1
  fi
  if uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=include$/\1/p" | while IFS= read -r sec; do
    [ -n "$sec" ] || continue
    p="$(common_uci_path_value "$(uci -q get "$sec.path" 2>/dev/null || true)")"
    case "$p" in
      /etc/domain-routing/90-domain-routing.nft|/etc/domain-routing/90-xfree-toolbox-fqdn-routing.nft|"${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/domain-routing/90-domain-routing.nft"|"${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/domain-routing/90-xfree-toolbox-fqdn-routing.nft")
        echo 1
        break
        ;;
    esac
  done | grep -q 1; then
    legacy_firewall_include_present=1
  fi
  common_strip_legacy_vpnmark_from_autogen_nft "$FQDN_NFT_MIG" || true
  # Important: do not pass canonical path here, otherwise helper removes canonical include too.
  common_firewall_remove_fqdn_includes "" "1" "1"
  if [ "$legacy_vpnmark_present" = "1" ] || [ "$legacy_firewall_include_present" = "1" ]; then
    impact_mark_iface "legacy fqdn nft/include cleanup in migration v2"
    impact_mark_dns "firewall/dnsmasq include cleanup in migration v2"
  fi
  uci commit firewall 2>/dev/null || true
  migration_log "[OK] fqdn nft legacy cleanup (strip + firewall includes)"
fi

if [ "$DRY_RUN" != "1" ]; then
  {
    printf 'state_root=%s\n' "$XFREE_STATE_ROOT"
    printf 'last_run=%s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"
  } > "$MIGRATION_MARKER" 2>/dev/null || true
fi

write_migration_impact
run_post_migration_repair

migration_log "[OK] state root migration v2 completed"
migration_say "[✓] Миграция состояния v2 завершена"
