#!/bin/sh
# shellcheck shell=sh
# Point this repo at tracked hooks in .githooks/ (pre-commit → fix-crlf).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
HOOKS_DIR="$ROOT_DIR/.githooks"

. "$ROOT_DIR/lib/common.sh"

command -v git >/dev/null 2>&1 || die "git not found"

git -C "$ROOT_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1 \
  || die "not a git work tree: $ROOT_DIR"

[ -d "$HOOKS_DIR" ] || die "missing hooks dir: $HOOKS_DIR"

for hook in "$HOOKS_DIR"/*; do
  [ -f "$hook" ] || continue
  chmod +x "$hook" 2>/dev/null || true
done

current="$(git -C "$ROOT_DIR" config --local --get core.hooksPath 2>/dev/null || true)"
if [ "$current" != ".githooks" ]; then
  git -C "$ROOT_DIR" config --local core.hooksPath .githooks
  info "git core.hooksPath → .githooks"
else
  info "git hooks already installed (.githooks)"
fi

success "pre-commit will run system/fix-crlf.sh on staged *.sh / eol=lf files"
