#!/bin/sh
# shellcheck shell=sh
# Test mesh connectivity and backhaul status on an OpenWrt node.
# Checks:
#   1. L2 bridge: STP enabled, IGMP snooping, port carrier status
#   2. L3 gateway: ping to master, ARP resolution
#   3. Internet & DNS: ping 1.1.1.1, nslookup via gateway
#   4. DHCP safety: verify dhcp.lan.ignore=1, dnsmasq not serving DHCP
#   5. Wireless 802.11s mesh: peer stations, RSSI, bitrate, mpath
#   6. Wireless roaming: 802.11r/k/v configuration
set -eu

GATEWAY=""
MESH_ID=""
ROLE=""

usage() {
  cat <<USAGE
Usage: test-mesh-connectivity.sh [options]

Диагностика связности узла Mesh / Ethernet Backhaul.

Опции:
  --role master|satellite  роль узла (по умолчанию: автоопределение)
  --gateway <ip>           IP-адрес основного роутера (шлюза)
  --mesh-id <id>           ожидаемый идентификатор 802.11s mesh
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --role)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --role" >&2; exit 1; }
      ROLE="$2"
      shift 2
      ;;
    --gateway)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --gateway" >&2; exit 1; }
      GATEWAY="$2"
      shift 2
      ;;
    --mesh-id)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --mesh-id" >&2; exit 1; }
      MESH_ID="$2"
      shift 2
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    *)
      echo "[!] Неизвестный параметр: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

# Автоопределение роли если не задана
if [ -z "$ROLE" ]; then
  _dhcp_ign="$(uci -q get dhcp.lan.ignore 2>/dev/null || echo 0)"
  _lan_gw="$(uci -q get network.lan.gateway 2>/dev/null || true)"
  if [ "$_dhcp_ign" = "1" ] || [ -n "$_lan_gw" ]; then
    ROLE="satellite"
  else
    ROLE="master"
  fi
fi

# Если шлюз не указан и роль satellite, определяем из routing table
if [ -z "$GATEWAY" ] && [ "$ROLE" = "satellite" ]; then
  GATEWAY="$(ip route 2>/dev/null | awk '/default/{print $3; exit}' || true)"
  [ -z "$GATEWAY" ] && GATEWAY="$(uci -q get network.lan.gateway 2>/dev/null || true)"
fi

echo "============================================================"
echo "    ДИАГНОСТИКА СВЯЗНОСТИ MESH / ETHERNET BACKHAUL"
echo "============================================================"
echo "Роль узла:         $ROLE"
echo "Узел (hostname):   $(uci -q get system.@system[0].hostname 2>/dev/null || cat /proc/sys/kernel/hostname)"
echo "LAN IP узла:       $(uci -q get network.lan.ipaddr 2>/dev/null || ip -4 addr show dev br-lan 2>/dev/null | awk '/inet /{print $2}')"
if [ "$ROLE" = "satellite" ]; then
  echo "Основной роутер:   ${GATEWAY:-не определён}"
fi
echo "------------------------------------------------------------"

total_errors=0
total_warns=0

# 0. Проверка пакета wpad-mesh-mbedtls
has_wpad_mesh=0
if command -v apk >/dev/null 2>&1; then
  if apk info -e wpad-mesh-mbedtls >/dev/null 2>&1; then
    has_wpad_mesh=1
  fi
elif command -v opkg >/dev/null 2>&1; then
  if opkg list-installed wpad-mesh-mbedtls 2>/dev/null | grep -q '^wpad-mesh-mbedtls'; then
    has_wpad_mesh=1
  fi
fi
if [ "$has_wpad_mesh" = "1" ]; then
  echo "[✓] Пакет wpad-mesh-mbedtls установлен (поддержка 802.11s и WPA3-SAE)"
else
  echo "[✗] Пакет wpad-mesh-mbedtls НЕ установлен! (mesh интерфейсы не смогут запуститься)"
  total_errors=$((total_errors + 1))
fi

# 1. Проверка L2 Bridge: STP и IGMP Snooping
echo
echo "--- [1/5] L2 Bridge и порты (Ethernet Backhaul) ---"
stp_ok=0
if [ -f /sys/class/net/br-lan/bridge/stp_state ]; then
  stp_val="$(cat /sys/class/net/br-lan/bridge/stp_state 2>/dev/null || echo 0)"
  if [ "$stp_val" = "1" ] || [ "$stp_val" = "2" ]; then
    echo "[✓] STP включен на br-lan (защита от сетевых петель)"
    stp_ok=1
  else
    echo "[!] STP отключен на br-lan (риск петли при кабеле + Wi-Fi mesh)"
    total_warns=$((total_warns + 1))
  fi
else
  echo "[*] br-lan не найден или не является bridge"
fi

if [ -f /sys/class/net/br-lan/bridge/multicast_snooping ]; then
  snoop_val="$(cat /sys/class/net/br-lan/bridge/multicast_snooping 2>/dev/null || echo 0)"
  if [ "$snoop_val" = "1" ]; then
    echo "[✓] IGMP Snooping включен (защита от multicast-штормов)"
  else
    echo "[!] IGMP Snooping отключен"
    total_warns=$((total_warns + 1))
  fi
fi

# Проверка линков физических портов
echo "[*] Состояние портов моста br-lan:"
if [ -d /sys/class/net/br-lan/brif ]; then
  for port in /sys/class/net/br-lan/brif/*; do
    [ -e "$port" ] || continue
    pname="$(basename "$port")"
    pcarrier="$(cat "/sys/class/net/$pname/carrier" 2>/dev/null || echo 0)"
    if [ "$pcarrier" = "1" ]; then
      echo "    - $pname: [LINK UP] кабель подключен / активен"
    else
      echo "    - $pname: [no link] нет кабеля / интерфейс не поднят"
    fi
  done
fi

# 2. Проверка L3: Связность
echo
if [ "$ROLE" = "satellite" ]; then
  echo "--- [2/5] L3 Связность с основным роутером ---"
  if [ -n "$GATEWAY" ]; then
    if ping -c 3 -W 2 "$GATEWAY" >/dev/null 2>&1; then
      ping_stat="$(ping -c 3 -W 2 "$GATEWAY" 2>/dev/null | tail -n 1)"
      echo "[✓] Пинг до основного роутера ($GATEWAY): OK ($ping_stat)"
    else
      echo "[✗] Нет ответа от основного роутера ($GATEWAY)!"
      total_errors=$((total_errors + 1))
    fi

    # ARP
    arp_entry="$(ip neigh show "$GATEWAY" 2>/dev/null | grep -v 'FAILED' || true)"
    if [ -n "$arp_entry" ]; then
      echo "[✓] ARP запись шлюза: $arp_entry"
    else
      echo "[!] ARP запись шлюза не найдена в кэше"
      total_warns=$((total_warns + 1))
    fi
  else
    echo "[✗] Шлюз по умолчанию не задан на узле!"
    total_errors=$((total_errors + 1))
  fi
else
  echo "--- [2/5] L3 Шлюз и WAN (Master) ---"
  wan_gw="$(ip route 2>/dev/null | awk '/default/{print $3; exit}' || true)"
  if [ -n "$wan_gw" ]; then
    echo "[✓] WAN шлюз провайдера: $wan_gw"
    if ping -c 3 -W 2 "$wan_gw" >/dev/null 2>&1; then
      echo "[✓] Пинг до WAN шлюза: OK"
    else
      echo "[!] Нет ответа от WAN шлюза ($wan_gw) на ICMP"
    fi
  else
    echo "[!] WAN шлюз по умолчанию не обнаружен в таблице маршрутизации"
    total_warns=$((total_warns + 1))
  fi
fi

# 3. Проверка выхода в интернет и DNS
echo
echo "--- [3/5] Доступ в Интернет и DNS ---"
if ping -c 3 -W 3 1.1.1.1 >/dev/null 2>&1; then
  echo "[✓] Пинг в интернет (1.1.1.1): OK"
else
  echo "[!] Нет доступа к внешним IP (1.1.1.1)"
  total_warns=$((total_warns + 1))
fi

if command -v nslookup >/dev/null 2>&1; then
  dns_test_target="${GATEWAY:-127.0.0.1}"
  [ "$ROLE" = "master" ] && dns_test_target="127.0.0.1"
  if nslookup openwrt.org "$dns_test_target" >/dev/null 2>&1; then
    echo "[✓] DNS резолв: OK"
  else
    echo "[!] DNS резолв не удался"
    total_warns=$((total_warns + 1))
  fi
fi

# 4. Проверка DHCP и DNS
echo
if [ "$ROLE" = "master" ]; then
  echo "--- [4/5] Службы DHCP и DNS (Master) ---"
  dhcp_ignore="$(uci -q get dhcp.lan.ignore 2>/dev/null || echo 0)"
  if [ "$dhcp_ignore" = "0" ] || [ -z "$dhcp_ignore" ]; then
    echo "[✓] DHCP сервер активен на LAN (Master раздаёт адреса)"
  else
    echo "[!] dhcp.lan.ignore установлен в 1 на Master (раздача DHCP отключена!)"
    total_warns=$((total_warns + 1))
  fi

  if [ -x /etc/init.d/dnsmasq ] && /etc/init.d/dnsmasq status >/dev/null 2>&1; then
    echo "[✓] dnsmasq запущен и работает"
  else
    echo "[!] dnsmasq не запущен"
    total_warns=$((total_warns + 1))
  fi
else
  echo "--- [4/5] Безопасность DHCP (Dumb AP Satellite) ---"
  dhcp_ignore="$(uci -q get dhcp.lan.ignore 2>/dev/null || echo 0)"
  if [ "$dhcp_ignore" = "1" ]; then
    echo "[✓] DHCP на LAN отключен (dhcp.lan.ignore=1)"
  else
    echo "[!] dhcp.lan.ignore НЕ установлен в 1 (риск конфликта DHCP)"
    total_warns=$((total_warns + 1))
  fi

  if [ -x /etc/init.d/dnsmasq ] && /etc/init.d/dnsmasq status >/dev/null 2>&1; then
    echo "[!] dnsmasq запущен (на satellite рекомендуется отключить)"
    total_warns=$((total_warns + 1))
  else
    echo "[✓] dnsmasq остановлен"
  fi
fi

# 5. Проверка беспроводного 802.11s Mesh и роуминга 802.11r
echo
echo "--- [5/5] Беспроводной 802.11s Mesh и 802.11r Роуминг ---"

# Проверка фиксации канала на радиоинтерфейсах
for dev in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-device$/\1/p' | cut -d. -f2); do
  chan="$(uci -q get "wireless.$dev.channel" 2>/dev/null || echo '')"
  band="$(uci -q get "wireless.$dev.band" 2>/dev/null || echo '')"
  if [ "$band" = "5g" ] || [ -z "$band" ]; then
    if [ "$chan" = "auto" ] || [ "$chan" = "0" ] || [ -z "$chan" ]; then
      echo "[!] Радио $dev (5 GHz): канал $chan (для Mesh требуется фиксированный канал, напр. 36)!"
      total_warns=$((total_warns + 1))
    else
      echo "[✓] Радио $dev (5 GHz): канал зафиксирован на $chan"
    fi
  fi
done

# Проверка UCI-конфигурации mesh
uci_mesh_count=0
for iface in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-iface$/\1/p' | cut -d. -f2); do
  mode="$(uci -q get "wireless.$iface.mode" 2>/dev/null || true)"
  if [ "$mode" = "mesh" ]; then
    uci_mesh_count=$((uci_mesh_count + 1))
    mid="$(uci -q get "wireless.$iface.mesh_id" 2>/dev/null || echo '')"
    menc="$(uci -q get "wireless.$iface.encryption" 2>/dev/null || echo '')"
    mdev="$(uci -q get "wireless.$iface.device" 2>/dev/null || echo '')"
    echo "[✓] UCI секция $iface: mode=mesh, mesh_id='$mid', device=$mdev, encryption=$menc"
    if [ "$menc" != "sae" ]; then
      echo "[!] Шифрование mesh интерфейса '$menc' (рекомендуется WPA3-SAE: 'sae')"
      total_warns=$((total_warns + 1))
    fi
  fi
done
if [ "$uci_mesh_count" -eq 0 ]; then
  echo "[!] В /etc/config/wireless не найдено интерфейсов с mode=mesh"
  total_warns=$((total_warns + 1))
fi

mesh_found=0
if command -v iw >/dev/null 2>&1; then
  for iface in $(iw dev 2>/dev/null | awk '/Interface/{print $2}'); do
    mtype="$(iw dev "$iface" info 2>/dev/null | awk '/type/{print $2}' || true)"
    if [ "$mtype" = "mesh" ]; then
      mesh_found=1
      echo "[✓] Найден 802.11s Mesh интерфейс: $iface"
      stations="$(iw dev "$iface" station dump 2>/dev/null || true)"
      if [ -n "$stations" ]; then
        echo "[✓] Подключенные пиры mesh:"
        printf '%s\n' "$stations" | grep -E 'Station|signal|rx bitrate|tx bitrate' | sed 's/^/    /'
      else
        echo "[!] Нет подключенных пиров на $iface (узлы вне зоны или на разных каналах)"
        total_warns=$((total_warns + 1))
      fi
      mpath="$(iw dev "$iface" mpath dump 2>/dev/null || true)"
      if [ -n "$mpath" ]; then
        echo "[*] Таблица маршрутов mesh (mpath):"
        printf '%s\n' "$mpath" | sed 's/^/    /'
      fi
    fi
  done
fi

if [ "$mesh_found" = "0" ]; then
  echo "[*] Беспроводной интерфейс 802.11s mesh не активен (используется проводной Ethernet backhaul)"
fi

# Проверка 802.11r/k/v на точках доступа
for iface in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-iface$/\1/p' | cut -d. -f2); do
  mode="$(uci -q get "wireless.$iface.mode" 2>/dev/null || true)"
  [ "$mode" = "ap" ] || continue
  ssid="$(uci -q get "wireless.$iface.ssid" 2>/dev/null || true)"
  r11="$(uci -q get "wireless.$iface.ieee80211r" 2>/dev/null || echo 0)"
  mdom="$(uci -q get "wireless.$iface.mobility_domain" 2>/dev/null || echo '')"
  if [ "$r11" = "1" ] && [ -n "$mdom" ]; then
    echo "[✓] AP $iface ('$ssid'): 802.11r FT включен (mobility_domain=$mdom)"
  else
    echo "[!] AP $iface ('$ssid'): 802.11r FT отключен"
    total_warns=$((total_warns + 1))
  fi
done

echo "============================================================"
if [ "$total_errors" -eq 0 ] && [ "$total_warns" -eq 0 ]; then
  echo "ИТОГ: ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО [PASS]"
elif [ "$total_errors" -eq 0 ]; then
  echo "ИТОГ: СВЯЗЬ РАБОТАЕТ, ПРЕДУПРЕЖДЕНИЙ: $total_warns [WARN]"
else
  echo "ИТОГ: ОБНАРУЖЕНЫ ОШИБКИ СВЯЗИ: $total_errors, ПРЕДУПРЕЖДЕНИЙ: $total_warns [FAIL]"
fi
echo "============================================================"

[ "$total_errors" -eq 0 ] || exit 1
exit 0
