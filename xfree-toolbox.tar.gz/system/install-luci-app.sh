#!/bin/sh
# shellcheck shell=sh
# Установка и обновление веб-интерфейса LuCI (luci-app-xfree-toolbox)
# Поддерживает OpenWrt 25+ (apk) и OpenWrt 24+ (tar.gz).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
COMMON_SH="$ROOT_DIR/lib/common.sh"

[ -f "$COMMON_SH" ] || {
  echo "[-] common.sh не найден: $COMMON_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"
load_base_config "$ROOT_DIR"

PKGMGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
if [ -f "$PKGMGR_SH" ]; then
  if ! command -v apk >/dev/null 2>&1 && ! command -v opkg >/dev/null 2>&1; then
    export PM="none"
  fi
  . "$PKGMGR_SH"
fi

OWRT_LIB="$ROOT_DIR/lib/owrt-release.sh"
[ -f "$OWRT_LIB" ] && . "$OWRT_LIB"

INSTALL_CHANNEL_SH="$ROOT_DIR/lib/install-channel.sh"
[ -f "$INSTALL_CHANNEL_SH" ] && . "$INSTALL_CHANNEL_SH"

APK_REGISTRY_SH="$ROOT_DIR/lib/apk-registry.sh"
[ -f "$APK_REGISTRY_SH" ] && . "$APK_REGISTRY_SH"

UPDATE_ETAG_SH="$ROOT_DIR/lib/update-etag.sh"
[ -f "$UPDATE_ETAG_SH" ] && . "$UPDATE_ETAG_SH"

MODE_AUTO=0
FORCE=0
SILENT=0
CHECK_ONLY=0
CHECK_INSTALLED=0
USE_TAR=0
USE_APK=0
SOURCE_DIR=""

usage() {
  cat <<'EOF'
Использование: install-luci-app.sh [опции]

Опции:
  --auto             Неинтерактивный режим
  --tar              Использовать канал tar.gz (OpenWrt 24+ / без apk)
  --apk              Использовать apk (OpenWrt 25+)
  --check-only       Проверить обновления (exit 0: нет, 10: есть)
  --check-installed  Проверить установку (exit 0: установлена, 1: нет)
  --force            Принудительная переустановка
  --silent           Минимум сообщений
  --source-dir <dir> Установка из локального каталога
  -h, --help         Справка
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --auto) MODE_AUTO=1 ;;
    --tar) USE_TAR=1 ;;
    --apk) USE_APK=1 ;;
    --check-only) CHECK_ONLY=1 ;;
    --check-installed) CHECK_INSTALLED=1 ;;
    --force) FORCE=1 ;;
    --silent) SILENT=1 ;;
    --source-dir)
      shift
      [ "$#" -gt 0 ] || die "--source-dir требует путь"
      SOURCE_DIR="$1"
      ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный параметр: $1" ;;
  esac
  shift
done

is_luci_app_installed() {
  if command -v apk >/dev/null 2>&1 && apk info -e luci-app-xfree-toolbox >/dev/null 2>&1; then
    return 0
  fi
  if [ -f /www/luci-static/resources/view/xfree-toolbox/shell.js ] || \
     [ -f /usr/share/luci/menu.d/luci-app-xfree-toolbox.json ]; then
    return 0
  fi
  return 1
}

if [ "$CHECK_INSTALLED" -eq 1 ]; then
  if is_luci_app_installed; then
    exit 0
  else
    exit 1
  fi
fi

is_base_luci_installed() {
  if [ -d /www/luci-static ] || [ -f /usr/share/ucode/luci/version.uc ]; then
    return 0
  fi
  if command -v pm_is_installed >/dev/null 2>&1; then
    if pm_is_installed luci || pm_is_installed luci-base || pm_is_installed luci-mod-admin-full; then
      return 0
    fi
  fi
  return 1
}

flush_luci_cache() {
  [ "$SILENT" -eq 1 ] || info "Сброс кэша LuCI и перезапуск служб..."
  rm -f /tmp/luci-indexcache /tmp/luci-indexcache.* 2>/dev/null || true
  rm -rf /tmp/luci-modulecache /usr/lib/lua/luci/cache 2>/dev/null || true
  [ -x /etc/init.d/rpcd ] && /etc/init.d/rpcd restart >/dev/null 2>&1 || true
  [ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd reload >/dev/null 2>&1 || true
  _ver="/usr/share/ucode/luci/version.uc"
  if [ -f "$_ver" ]; then
    _bust="$(date +%s 2>/dev/null || echo 1)"
    if grep -q 'xfreebust' "$_ver" 2>/dev/null; then
      sed -i "s/xfreebust[0-9]*/xfreebust${_bust}/" "$_ver" 2>/dev/null || true
    else
      sed -i "s/revision: '[^']*'/revision: 'xfreebust${_bust}'/" "$_ver" 2>/dev/null || true
    fi
  fi
}

ensure_base_luci() {
  if is_base_luci_installed; then
    return 0
  fi
  info "LuCI не обнаружен на роутере. Устанавливаю LuCI и веб-сервер uhttpd..."
  if command -v pm_update >/dev/null 2>&1; then
    pm_update || warn "Не удалось обновить списки пакетов"
    pm_install luci uhttpd || pm_install luci-base uhttpd || warn "Не удалось установить базовый LuCI через пакетный менеджер"
  fi
  if [ -x /etc/init.d/uhttpd ]; then
    /etc/init.d/uhttpd enable 2>/dev/null || true
    /etc/init.d/uhttpd start 2>/dev/null || true
  fi
}

ensure_rpcd_helper() {
  if [ -f "$ROOT_DIR/system/rpcd/xfree-toolbox" ]; then
    mkdir -p /usr/libexec/rpcd 2>/dev/null || true
    cp -f "$ROOT_DIR/system/rpcd/xfree-toolbox" /usr/libexec/rpcd/xfree-toolbox 2>/dev/null || true
    chmod +x /usr/libexec/rpcd/xfree-toolbox 2>/dev/null || true
  fi
}

detect_channel() {
  if [ -n "$SOURCE_DIR" ]; then
    printf 'source\n'
    return 0
  fi
  if [ "$USE_TAR" -eq 1 ]; then
    printf 'tar\n'
    return 0
  fi
  if [ "$USE_APK" -eq 1 ]; then
    printf 'apk\n'
    return 0
  fi
  if command -v xfree_resolve_update_channel >/dev/null 2>&1; then
    _ch="$(xfree_resolve_update_channel)"
    if [ "$_ch" = "apk" ]; then
      printf 'apk\n'
      return 0
    fi
  fi
  printf 'tar\n'
}

install_from_source() {
  _src="$1"
  _luci_src="$_src/build/openwrt/luci-app-xfree-toolbox"
  [ -d "$_luci_src" ] || die "В $_src отсутствует build/openwrt/luci-app-xfree-toolbox"

  [ "$SILENT" -eq 1 ] || info "Установка LuCI из исходного каталога: $_luci_src"
  mkdir -p /usr/share/luci/menu.d \
           /usr/share/rpcd/acl.d \
           /www/luci-static/resources/view/xfree-toolbox \
           /www/luci-static/resources/xfree-toolbox 2>/dev/null || true

  [ -f "$_luci_src/root/usr/share/luci/menu.d/luci-app-xfree-toolbox.json" ] && \
    cp -f "$_luci_src/root/usr/share/luci/menu.d/luci-app-xfree-toolbox.json" /usr/share/luci/menu.d/
  [ -f "$_luci_src/root/usr/share/rpcd/acl.d/luci-app-xfree-toolbox.json" ] && \
    cp -f "$_luci_src/root/usr/share/rpcd/acl.d/luci-app-xfree-toolbox.json" /usr/share/rpcd/acl.d/
  [ -f "$_luci_src/htdocs/luci-static/resources/view/xfree-toolbox/shell.js" ] && \
    cp -f "$_luci_src/htdocs/luci-static/resources/view/xfree-toolbox/shell.js" /www/luci-static/resources/view/xfree-toolbox/
  if [ -d "$_luci_src/htdocs/luci-static/resources/xfree-toolbox" ]; then
    cp -a "$_luci_src/htdocs/luci-static/resources/xfree-toolbox/." /www/luci-static/resources/xfree-toolbox/
  fi
  ensure_rpcd_helper
  flush_luci_cache
}

install_via_apk() {
  command -v apk >/dev/null 2>&1 || die "apk не найден"
  if [ "$CHECK_ONLY" -eq 1 ]; then
    if apk info -e luci-app-xfree-toolbox >/dev/null 2>&1; then
      if command -v xfree_apk_print_feed_check >/dev/null 2>&1; then
        xfree_apk_print_feed_check "luci-app-xfree-toolbox" || return 1
        case "${XFREE_APK_CHECK_ACTION:-none}" in
          upgrade) exit 10 ;;
          *) exit 0 ;;
        esac
      fi
      printf '[*] Package         : luci-app-xfree-toolbox\n'
      printf '[*] Upgradable      : no\n'
      exit 0
    else
      printf '[*] Package         : luci-app-xfree-toolbox\n'
      printf '[*] Action          : add\n'
      printf '[*] Upgradable      : yes\n'
      exit 10
    fi
  fi

  ensure_base_luci

  if apk info -e luci-app-xfree-toolbox >/dev/null 2>&1; then
    [ "$SILENT" -eq 1 ] || info "Обновление luci-app-xfree-toolbox через apk..."
    apk upgrade luci-app-xfree-toolbox 2>&1 || apk add --allow-untrusted luci-app-xfree-toolbox 2>&1 || die "Не удалось обновить luci-app-xfree-toolbox"
  else
    [ "$SILENT" -eq 1 ] || info "Установка luci-app-xfree-toolbox через apk..."
    apk add luci-app-xfree-toolbox 2>&1 || apk add --allow-untrusted luci-app-xfree-toolbox 2>&1 || die "Не удалось установить luci-app-xfree-toolbox"
  fi
  ensure_rpcd_helper
  flush_luci_cache
}

install_via_tar() {
  _url=""
  if command -v xfree_apk_feed_luci_tar_url >/dev/null 2>&1; then
    _url="$(xfree_apk_feed_luci_tar_url 2>/dev/null || true)"
  fi
  [ -n "$_url" ] || _url="${XFREE_LUCI_UPDATE_URL:-${XFREE_UPDATE_URL%/}/luci-app-xfree-toolbox.tar.gz}"

  _local_etag=""
  if command -v xfree_read_local_luci_etag >/dev/null 2>&1; then
    _local_etag="$(xfree_read_local_luci_etag)"
  elif [ -f /etc/xfree-toolbox/.luci-update-etag ]; then
    _local_etag="$(head -n1 /etc/xfree-toolbox/.luci-update-etag | tr -d '\r\n')"
  fi

  _remote_etag=""
  _remote_lastmod=""
  if command -v xfree_fetch_remote_tar_props >/dev/null 2>&1; then
    if xfree_fetch_remote_tar_props "$_url" 2>/dev/null; then
      _remote_etag="${XFREE_REMOTE_ETAG:-}"
      _remote_lastmod="${XFREE_REMOTE_LASTMOD:-}"
    fi
  fi

  if [ "$CHECK_ONLY" -eq 1 ]; then
    _local_ver=""
    if command -v xfree_luci_app_version_from_stamp >/dev/null 2>&1; then
      _local_ver="$(xfree_luci_app_version_from_stamp)"
    fi
    if [ -z "$_local_ver" ] && [ -f "$ROOT_DIR/VERSION" ] && command -v xfree_version_to_luci_stamp >/dev/null 2>&1; then
      _local_ver="$(xfree_version_to_luci_stamp "$(head -n1 "$ROOT_DIR/VERSION" | tr -d '\r\n\t ')" || true)"
    fi
    _remote_raw=""
    _remote_ver=""
    if command -v xfree_resolve_remote_tar_version >/dev/null 2>&1; then
      # Sibling VERSION рядом с luci tar; иначе тот же VERSION у toolbox.tar.gz.
      if xfree_resolve_remote_tar_version "$_url" "$_remote_etag" 2>/dev/null; then
        _remote_raw="${XFREE_REMOTE_VERSION:-}"
      fi
      if [ -z "$_remote_raw" ] && command -v xfree_apk_feed_tar_url >/dev/null 2>&1; then
        _tb_url="$(xfree_apk_feed_tar_url 2>/dev/null || true)"
        if [ -n "$_tb_url" ] && xfree_resolve_remote_tar_version "$_tb_url" "$_remote_etag" 2>/dev/null; then
          _remote_raw="${XFREE_REMOTE_VERSION:-}"
        fi
      fi
    fi
    if [ -n "$_remote_raw" ] && command -v xfree_version_to_luci_stamp >/dev/null 2>&1; then
      _remote_ver="$(xfree_version_to_luci_stamp "$_remote_raw" || true)"
    fi

    printf '[*] Channel         : tar\n'
    printf '[*] Package         : luci-app-xfree-toolbox\n'
    printf '[*] Remote LuCI ETag: %s\n' "${_remote_etag:-<unknown>}"
    printf '[*] Local LuCI ETag : %s\n' "${_local_etag:-<none>}"
    printf '[*] Local version   : %s\n' "${_local_ver:-<none>}"
    printf '[*] Remote version  : %s\n' "${_remote_ver:-${_remote_raw:-<unknown>}}"

    # Канон: semver. ETag — запасной сигнал, если VERSION недоступна.
    if [ -n "$_local_ver" ] && [ -n "$_remote_ver" ] && [ "$FORCE" -eq 0 ]; then
      if command -v xfree_toolbox_version_ge >/dev/null 2>&1 \
        && xfree_toolbox_version_ge "$_local_ver" "$_remote_ver"; then
        printf '[*] Available       : %s\n' "$_remote_ver"
        printf '[*] Upgradable      : no\n'
        [ "$SILENT" -eq 1 ] || success "Веб-интерфейс LuCI актуален"
        exit 0
      fi
      printf '[*] Available       : %s\n' "$_remote_ver"
      printf '[*] Upgradable      : yes\n'
      [ "$SILENT" -eq 1 ] || success "Доступно обновление веб-интерфейса LuCI"
      exit 10
    fi

    if [ -n "$_local_etag" ] && [ -n "$_remote_etag" ] && [ "$_local_etag" = "$_remote_etag" ] && [ "$FORCE" -eq 0 ]; then
      printf '[*] Available       : %s\n' "${_remote_ver:-<none>}"
      printf '[*] Upgradable      : no\n'
      [ "$SILENT" -eq 1 ] || success "Веб-интерфейс LuCI актуален"
      exit 0
    fi
    printf '[*] Available       : %s\n' "${_remote_ver:-${_remote_raw:-<unknown>}}"
    printf '[*] Upgradable      : yes\n'
    [ "$SILENT" -eq 1 ] || success "Доступно обновление веб-интерфейса LuCI"
    exit 10
  fi

  if [ "$FORCE" -eq 0 ] && [ -n "$_local_etag" ] && [ -n "$_remote_etag" ] && [ "$_local_etag" = "$_remote_etag" ] && is_luci_app_installed; then
    [ "$SILENT" -eq 1 ] || success "Веб-интерфейс LuCI уже установлен и актуален (ETag: $_local_etag)"
    return 0
  fi

  ensure_base_luci

  _tmp_dir="$(mktemp -d /tmp/xfree-luci-install.XXXXXX)"
  _archive="$_tmp_dir/luci-app-xfree-toolbox.tar.gz"

  [ "$SILENT" -eq 1 ] || info "Скачивание архива LuCI ($_url)..."
  if command -v http_fetch_file >/dev/null 2>&1; then
    http_fetch_file "$_url" "$_archive" || die "Не удалось скачать архив LuCI: $_url"
  elif command -v curl >/dev/null 2>&1; then
    curl --http1.1 -fsSL -o "$_archive" "$_url" || die "Не удалось скачать архив LuCI: $_url"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$_archive" "$_url" || die "Не удалось скачать архив LuCI: $_url"
  else
    die "Не найден ни curl, ни wget для скачивания архива LuCI"
  fi

  [ -s "$_archive" ] || die "Скачан пустой архив LuCI (404?)"

  [ "$SILENT" -eq 1 ] || info "Распаковка веб-интерфейса LuCI..."
  tar -xzf "$_archive" -C / || die "Ошибка распаковки архива LuCI"
  chmod 755 / 2>/dev/null || true

  ensure_rpcd_helper
  flush_luci_cache

  if [ -n "$_remote_etag" ]; then
    mkdir -p /etc/xfree-toolbox 2>/dev/null || true
    printf '%s\n' "$_remote_etag" > /etc/xfree-toolbox/.luci-update-etag 2>/dev/null || true
  fi
  if [ -n "$_remote_lastmod" ]; then
    mkdir -p /etc/xfree-toolbox 2>/dev/null || true
    printf '%s\n' "$_remote_lastmod" > /etc/xfree-toolbox/.luci-update-lastmodified 2>/dev/null || true
  fi

  rm -rf "$_tmp_dir"
  return 0
}

CHANNEL="$(detect_channel)"

if [ "$MODE_AUTO" -eq 0 ] && [ "$CHECK_ONLY" -eq 0 ]; then
  _status_luci="не установлен"
  is_base_luci_installed && _status_luci="установлен"
  _status_app="не установлен"
  is_luci_app_installed && _status_app="установлен"

  printf '\n'
  printf '== Веб-интерфейс LuCI (xfree-toolbox) ==\n'
  printf 'Базовый LuCI : %s\n' "$_status_luci"
  printf 'Панель xfree : %s\n' "$_status_app"
  printf 'Канал        : %s\n' "$CHANNEL"
  printf '\n'

  confirm_or_exit 'Продолжить установку / обновление веб-интерфейса LuCI?'
fi

case "$CHANNEL" in
  source) install_from_source "$SOURCE_DIR" ;;
  apk)    install_via_apk ;;
  tar)    install_via_tar ;;
  *)      die "Неизвестный канал: $CHANNEL" ;;
esac

[ "$SILENT" -eq 1 ] || success "Веб-интерфейс LuCI (luci-app-xfree-toolbox) готов к работе"
_lan_ip="$(uci -q get network.lan.ipaddr 2>/dev/null || true)"
if [ -n "$_lan_ip" ] && [ "$SILENT" -eq 0 ]; then
  info "Доступ: http://$_lan_ip/cgi-bin/luci (раздел «Службы» → «xfree-toolbox»)"
fi
