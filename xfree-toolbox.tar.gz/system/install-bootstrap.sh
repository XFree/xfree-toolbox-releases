#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
UPDATE_ETAG_SH="$ROOT_DIR/lib/update-etag.sh"
if [ -f "$UPDATE_ETAG_SH" ]; then
  # shellcheck disable=SC1090
  . "$UPDATE_ETAG_SH"
fi

TARGET_DIR="${TARGET_DIR:-/root/xfree-toolbox}"
LEGACY_TARGET_DIR="${LEGACY_TARGET_DIR:-/root/xfree-utils}"
SOURCE_DIR="$ROOT_DIR"
PRESERVE_PROFILES=1
RESTORE_ACTIVE_PROFILE_FROM_STATE=0
STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"

usage() {
    cat <<EOF
Usage: $(basename "$0") [options]

Install toolbox from extracted tree.

Options:
  --source-dir <dir>                   Extracted toolbox root (default: script root)
  --target-dir <dir>                   Install dir (default: $TARGET_DIR)
  --legacy-target-dir <dir>            Legacy symlink path (default: $LEGACY_TARGET_DIR)
  --preserve-profiles                  Keep router profiles/ (default; archive profiles/ ignored)
  --replace-profiles                   Deprecated: same as --preserve-profiles (profiles never replaced from archive)
  --restore-active-profile-from-state  Rebuild active profile from current state after install
  -h, --help
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --source-dir)
            shift
            [ "$#" -gt 0 ] || { echo "[-] --source-dir требует путь" >&2; exit 1; }
            SOURCE_DIR="$1"
            ;;
        --target-dir)
            shift
            [ "$#" -gt 0 ] || { echo "[-] --target-dir требует путь" >&2; exit 1; }
            TARGET_DIR="$1"
            ;;
        --legacy-target-dir)
            shift
            [ "$#" -gt 0 ] || { echo "[-] --legacy-target-dir требует путь" >&2; exit 1; }
            LEGACY_TARGET_DIR="$1"
            ;;
        --preserve-profiles)
            PRESERVE_PROFILES=1
            ;;
        --replace-profiles)
            echo "[!] --replace-profiles устарел: profiles/ не перезаписываются из архива. Создайте профиль из шаблона на роутере (меню «Шаблоны»)." >&2
            PRESERVE_PROFILES=1
            ;;
        --restore-active-profile-from-state)
            RESTORE_ACTIVE_PROFILE_FROM_STATE=1
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "[-] Неизвестный аргумент: $1" >&2
            exit 1
            ;;
    esac
    shift || true
done

[ -d "$SOURCE_DIR" ] || { echo "[-] source dir не найден: $SOURCE_DIR" >&2; exit 1; }
[ -f "$SOURCE_DIR/menu.sh" ] || { echo "[-] source dir не похож на xfree-toolbox: $SOURCE_DIR" >&2; exit 1; }

TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/xfree-bootstrap.XXXXXX")"
cleanup() {
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT HUP INT TERM

keep_profiles=""
if [ -d "$TARGET_DIR/profiles" ]; then
    mkdir -p "$TMP_DIR/keep"
    cp -a "$TARGET_DIR/profiles" "$TMP_DIR/keep/profiles"
    keep_profiles="$TMP_DIR/keep/profiles"
elif [ -n "$LEGACY_TARGET_DIR" ] && [ "$LEGACY_TARGET_DIR" != "$TARGET_DIR" ] && [ -d "$LEGACY_TARGET_DIR/profiles" ]; then
    mkdir -p "$TMP_DIR/keep"
    cp -a "$LEGACY_TARGET_DIR/profiles" "$TMP_DIR/keep/profiles"
    keep_profiles="$TMP_DIR/keep/profiles"
fi

router_templates=""
if [ -d "$TARGET_DIR/profile-templates" ]; then
    router_templates="$TARGET_DIR/profile-templates"
elif [ -n "$LEGACY_TARGET_DIR" ] && [ "$LEGACY_TARGET_DIR" != "$TARGET_DIR" ] && [ -d "$LEGACY_TARGET_DIR/profile-templates" ]; then
    router_templates="$LEGACY_TARGET_DIR/profile-templates"
fi

xfree_bootstrap_replace_target() {
    _target="$1"
    if [ ! -e "$_target" ]; then
        mkdir -p "$_target"
        return 0
    fi
    if rm -rf "$_target" 2>/dev/null; then
        mkdir -p "$_target"
        return 0
    fi
    _bak="${_target}.bootstrap-bak.$$"
    if mv "$_target" "$_bak" 2>/dev/null; then
        mkdir -p "$_target"
        rm -rf "$_bak" 2>/dev/null &
        return 0
    fi
    if command -v apk >/dev/null 2>&1 && apk info -e xfree-toolbox >/dev/null 2>&1; then
        echo "[-] Каталог $_target занят пакетом apk xfree-toolbox (файлы в overlay, rm недоступен)." >&2
        echo "[-] На OpenWrt 25+ не используйте tar/bootstrap: sh install-from-cloud.sh (канал apk) или apk upgrade xfree-toolbox" >&2
        exit 1
    fi
    echo "[-] Не удалось очистить $_target (Permission denied). Переименуйте вручную: mv $_target ${_target}.old" >&2
    exit 1
}

xfree_bootstrap_replace_target "$TARGET_DIR"
cp -a "$SOURCE_DIR"/. "$TARGET_DIR"/

xfree_install_materialize_profiles_dir "$SOURCE_DIR" "$TARGET_DIR" "$keep_profiles"
xfree_install_merge_profile_templates_dir "$SOURCE_DIR" "$TARGET_DIR" "$router_templates"

if [ -n "$LEGACY_TARGET_DIR" ] && [ "$LEGACY_TARGET_DIR" != "$TARGET_DIR" ]; then
    if [ -e "$LEGACY_TARGET_DIR" ] && [ ! -L "$LEGACY_TARGET_DIR" ]; then
        mv "$LEGACY_TARGET_DIR" "${LEGACY_TARGET_DIR}.legacy.$(date +%Y%m%d-%H%M%S 2>/dev/null || date +%s)"
    fi
    ln -sfn "$TARGET_DIR" "$LEGACY_TARGET_DIR"
fi

find "$TARGET_DIR" -type f -name "*.sh" -exec chmod +x {} \; 2>/dev/null || true

if [ "$RESTORE_ACTIVE_PROFILE_FROM_STATE" = "1" ]; then
    if [ -d "$STATE_ROOT" ]; then
        sh "$TARGET_DIR/templates/restore-profile-from-state.sh"
    else
        echo "[!] restore-from-state пропущен: state root не найден ($STATE_ROOT)" >&2
    fi
fi

if [ -x "$TARGET_DIR/system/sync-runtime-status.sh" ]; then
    sh "$TARGET_DIR/system/sync-runtime-status.sh" >/dev/null 2>&1 || true
fi

if [ -f "$TARGET_DIR/system/hardware/install-sbin-links.sh" ]; then
    # shellcheck disable=SC1090
    . "$TARGET_DIR/system/hardware/install-sbin-links.sh"
    install_hardware_sbin_links "$TARGET_DIR" || true
fi

if [ -f "$TARGET_DIR/system/hardware/install-button-hooks.sh" ]; then
    sh "$TARGET_DIR/system/hardware/install-button-hooks.sh" --install "$TARGET_DIR" || true
fi
if [ -f "$TARGET_DIR/system/hardware/usb-power-watch-upgrade.sh" ]; then
    sh "$TARGET_DIR/system/hardware/usb-power-watch-upgrade.sh" --on-deploy --quiet "$TARGET_DIR" \
        >>/tmp/xfree-postinst.log 2>&1 || true
fi

if command -v xfree_stamp_installed_tar_etag >/dev/null 2>&1; then
    _stamp_url="${UPDATE_URL:-${XFREE_UPDATE_URL:-}}"
    xfree_stamp_installed_tar_etag "$TARGET_DIR" "$_stamp_url" \
      "${XFREE_INSTALLED_TAR_ETAG:-}" "${XFREE_INSTALLED_TAR_LASTMOD:-}"
fi

echo "[✓] xfree-toolbox установлен в $TARGET_DIR"
