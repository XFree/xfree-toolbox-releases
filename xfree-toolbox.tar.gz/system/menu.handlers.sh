#!/bin/sh
# Hand-written handlers for cli.run component=custom in system/menu.yaml.
# shellcheck shell=sh

AUTO_UPDATE_LIB="$ROOT_DIR/system/auto-update-lib.sh"
AUTO_UPDATE_CRON="$ROOT_DIR/system/auto-update-cron.sh"
AUTO_UPDATE_SETTINGS="$ROOT_DIR/system/auto-update-settings-menu.sh"

system_menu_auto_update_load_lib() {
	[ -f "$AUTO_UPDATE_LIB" ] || return 1
	# shellcheck disable=SC1091
	. "$AUTO_UPDATE_LIB"
}

system_menu_auto_update_status_line() {
	if system_menu_auto_update_load_lib; then
		auto_update_load_config
		_st='выкл'
		[ "$AUTO_UPDATE_ENABLED" = "1" ] && _st='вкл'
		printf ' (%s, %s, %02d:%02d)' \
			"$_st" \
			"$(auto_update_mode_label_short "$AUTO_UPDATE_MODE")" \
			"$AUTO_UPDATE_SCHEDULE_HOUR" \
			"$AUTO_UPDATE_SCHEDULE_MINUTE"
	else
		printf '%s' ''
	fi
}

system_menu_title_auto_update_enable() {
	printf 'Включить автообновление%s' "$(system_menu_auto_update_status_line)"
}

system_menu_title_auto_update_disable() {
	printf 'Выключить автообновление%s' "$(system_menu_auto_update_status_line)"
}

profile_sync_button_menu_label() {
	_lib="$ROOT_DIR/system/hardware/lib-sync-button.sh"
	if [ -f "$_lib" ]; then
		sh "$_lib" --menu-label 2>/dev/null || printf '%s\n' "WPS"
	else
		printf '%s\n' "WPS"
	fi
}

# Хук 90-xfree-wps-sync-apply на месте → обновление профиля по кнопке включено.
profile_sync_button_hook_status() {
	_hook="${WPS_SYNC_HOOK_FILE:-/etc/hotplug.d/button/90-xfree-wps-sync-apply}"
	if [ -f "$_hook" ] && [ -x "$_hook" ]; then
		printf '%s' 'вкл'
	else
		printf '%s' 'выкл'
	fi
}

system_gen_menu_hint() {
	current_profile="$(current_profile_name)"
	printf 'Выберите действие\n\nАктивный профиль: %s\nРежим меню: %s' \
		"$current_profile" "$(_menu_mode_label)"
}

system_menu_title_11() {
	sync_btn_label="$(profile_sync_button_menu_label)"
	printf 'Включить обновление профиля (%s, %s)' \
		"$sync_btn_label" "$(profile_sync_button_hook_status)"
}

system_menu_title_12() {
	sync_btn_label="$(profile_sync_button_menu_label)"
	printf 'Выключить обновление профиля (%s, %s)' \
		"$sync_btn_label" "$(profile_sync_button_hook_status)"
}

toggle_wps_button_hook() {
	mode="$1"
	hook_script="$ROOT_DIR/system/hardware/install-button-hooks.sh"
	btn_label="$(profile_sync_button_menu_label)"

	if [ ! -f "$hook_script" ]; then
		ui_msgbox "Обновление профиля по кнопке" "Скрипт управления хуком не найден:\n$hook_script"
		return 0
	fi

	[ -x "$hook_script" ] || chmod +x "$hook_script" 2>/dev/null || true

	case "$mode" in
		install)
			ui_menu_invoke_with_output "Включить обновление профиля ($btn_label)" sh "$hook_script" --install "$ROOT_DIR"
			;;
		remove)
			ui_menu_invoke_with_output "Выключить обновление профиля ($btn_label)" sh "$hook_script" --remove
			;;
	esac
}

MAINTENANCE_HAS_CANDIDATES=0

show_maintenance_preview() {
	action="$1"
	title="$2"
	preview_file="${UI_TMP_ROOT:-/tmp}/xfree-maintenance-preview.$$"
	if sh "$SCRIPT_DIR/backup-maintenance.sh" --action "$action" --preview >"$preview_file" 2>&1; then
		ui_show_textbox "$title" "$preview_file"
		if grep -q "Итого кандидатов:[[:space:]]*[1-9][0-9]*" "$preview_file" 2>/dev/null; then
			MAINTENANCE_HAS_CANDIDATES=1
		else
			MAINTENANCE_HAS_CANDIDATES=0
		fi
	else
		ui_show_textbox "$title: ошибка preview" "$preview_file"
		rm -f "$preview_file" 2>/dev/null || true
		return 1
	fi
	rm -f "$preview_file" 2>/dev/null || true
	return 0
}

run_maintenance_action() {
	action="$1"
	title="$2"
	confirm_text="$3"

	MAINTENANCE_HAS_CANDIDATES=0
	show_maintenance_preview "$action" "$title (preview)" || return 0
	[ "$MAINTENANCE_HAS_CANDIDATES" = "1" ] || return 0

	if ui_confirm "$title" "$confirm_text"; then
		ui_menu_invoke_with_output "$title" sh "$SCRIPT_DIR/backup-maintenance.sh" --action "$action" --apply
	fi
}

current_profile_name() {
	common_active_profile_name "$ROOT_DIR"
}

check_and_update_toolbox() {
	update_runner="$SCRIPT_DIR/self-update.sh"
	[ -f "$update_runner" ] || {
		ui_msgbox "Обновление xfree-toolbox" "Не найден скрипт обновления:
$update_runner"
		return 0
	}

	check_out_file="${UI_TMP_ROOT:-/tmp}/self-update-check.$$"
	check_out=""
	check_rc=0
	remote_etag="<unknown>"
	local_etag="<unknown>"
	remote_modified="<unknown>"

	"$update_runner" --check-only --silent >"$check_out_file" 2>&1 || check_rc=$?
	if [ -f "$check_out_file" ]; then
		check_out="$(awk 'NR<=300 { print }' "$check_out_file")"
		rm -f "$check_out_file" 2>/dev/null || true
	fi

	[ -n "${check_out:-}" ] || check_out="(лог проверки пуст)"

	remote_etag="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Remote ETag[[:space:]]*:[[:space:]]*//p' | head -n1)"
	local_etag="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Local ETag[[:space:]]*:[[:space:]]*//p' | head -n1)"
	local_version="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Local version[[:space:]]*:[[:space:]]*//p' | head -n1)"
	remote_modified="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Remote modified[[:space:]]*:[[:space:]]*//p' | head -n1)"
	channel_line="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Channel[[:space:]]*:[[:space:]]*//p' | head -n1)"
	apk_package="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Package[[:space:]]*:[[:space:]]*//p' | head -n1)"
	apk_installed="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Installed[[:space:]]*:[[:space:]]*//p' | head -n1)"
	apk_available="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Available[[:space:]]*:[[:space:]]*//p' | head -n1)"
	apk_action="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Action[[:space:]]*:[[:space:]]*//p' | head -n1)"
	apk_upgradable="$(printf '%s\n' "$check_out" | sed -n 's/^\[\*\] Upgradable[[:space:]]*:[[:space:]]*//p' | head -n1)"

	[ -n "${remote_etag:-}" ] || remote_etag="<unknown>"
	[ -n "${local_etag:-}" ] || local_etag="<none>"
	[ -n "${local_version:-}" ] || local_version="<none>"
	[ -n "${remote_modified:-}" ] || remote_modified="<unknown>"

	if [ "$check_rc" -eq 0 ]; then
		if [ "${channel_line:-}" = "apk" ] && [ -n "${apk_package:-}" ]; then
			ui_msgbox "Обновление xfree-toolbox" "Обновлений нет.

Канал: apk
Пакет: ${apk_package}
Installed: ${apk_installed:-<не установлен>}
Available: ${apk_available:-<none>}
Action: ${apk_action:-none}
Upgradable: ${apk_upgradable:-no}"
		elif [ "$remote_etag" != "<unknown>" ] || [ "$local_etag" != "<none>" ]; then
			ui_msgbox "Обновление xfree-toolbox" "Обновлений нет.

Канал: ${channel_line:-tar}
Remote ETag     : $remote_etag
Local ETag      : $local_etag
Local version   : $local_version
Remote modified : $remote_modified"
		else
			ui_msgbox "Обновление xfree-toolbox" "Обновлений нет.

Канал: ${channel_line:-auto}"
		fi
		return 0
	fi

	if [ "$check_rc" -ne 10 ]; then
		err_file="${UI_TMP_ROOT:-/tmp}/self-update-check-error.$$"
		printf '%s\n' "$check_out" > "$err_file"
		ui_show_textbox "Проверка обновлений xfree-toolbox: ошибка" "$err_file"
		rm -f "$err_file" 2>/dev/null || true
		return "$check_rc"
	fi

	if [ "${channel_line:-}" = "apk" ] && [ -n "${apk_package:-}" ]; then
		if [ "${apk_action:-}" = "add" ]; then
			confirm_body="Toolbox стоит не через apk. На OpenWrt 25+ доставим пакет из фида (apk add), дальше обновления — apk.

Канал: apk
Пакет: ${apk_package}
Installed: ${apk_installed:-<не установлен>}
Available: ${apk_available:-<none>}

Установить пакет сейчас?

(install-from-cloud.sh; profiles сохраняются)"
		else
			confirm_body="Доступна новая версия xfree-toolbox.

Канал: apk
Пакет: ${apk_package}
Installed: ${apk_installed:-?}
Available: ${apk_available:-?}
Upgradable: ${apk_upgradable:-yes}

Обновить сейчас?

(установка через install-from-cloud.sh с factory share; profiles сохраняются)"
		fi
	else
		confirm_body="Доступна новая версия xfree-toolbox.

Канал: ${channel_line:-tar}
Remote ETag     : $remote_etag
Local ETag      : $local_etag
Local version   : $local_version
Remote modified : $remote_modified

Обновить сейчас?

(установка через install-from-cloud.sh с factory share; profiles сохраняются)"
	fi

	if ui_confirm "Обновление xfree-toolbox" "$confirm_body"; then
		run_system_script_with_output "Обновление xfree-toolbox" "$update_runner" --preserve-profiles
	fi
}

system_menu_maintenance_rotate() {
	run_maintenance_action \
		"rotate" \
		"Принудительная ротация backup" \
		"Сейчас будет выполнена принудительная ротация backup-семейств.

Сначала был показан preview кандидатов на удаление.
Продолжить удаление?"
}

system_menu_maintenance_cleanup() {
	run_maintenance_action \
		"cleanup" \
		"Чистка мусора backup/legacy" \
		"Сейчас будет удалён legacy backup-мусор (в т.ч. .bak/.dir), показанный в preview.

Продолжить удаление?"
}

system_menu_maintenance_purge() {
	run_maintenance_action \
		"purge" \
		"Полная очистка backup" \
		"Сейчас будет удалено ВСЁ содержимое backup-root, показанное в preview.

Это необратимое действие.
Продолжить удаление?"
}

system_menu_sync_button_install() {
	toggle_wps_button_hook install
}

system_menu_sync_button_remove() {
	toggle_wps_button_hook remove
}

system_menu_write_nfc() {
	ui_menu_invoke_with_output "Записать NFC (Wi‑Fi 5 GHz)" \
		sh "$ROOT_DIR/xinfc/write-nfc-5g.sh" --yes
}

system_menu_auto_update_enable() {
	if ! system_menu_auto_update_load_lib; then
		ui_msgbox "Автообновление" "Не найден:\n$AUTO_UPDATE_LIB"
		return 0
	fi
	auto_update_load_config
	if ! ui_confirm "Автообновление" \
"Включить ночное автообновление по cron?

Режим: $(auto_update_mode_label "$AUTO_UPDATE_MODE")
Время: $(printf '%02d:%02d' "$AUTO_UPDATE_SCHEDULE_HOUR" "$AUTO_UPDATE_SCHEDULE_MINUTE") (местное)

Настройки: Система → «Настройка автообновления»."; then
		return 0
	fi
	[ -f "$AUTO_UPDATE_CRON" ] || {
		ui_msgbox "Автообновление" "Не найден:\n$AUTO_UPDATE_CRON"
		return 0
	}
	ui_menu_invoke_with_output "Включить автообновление" sh "$AUTO_UPDATE_CRON" install
}

system_menu_auto_update_disable() {
	if ! system_menu_auto_update_load_lib; then
		ui_msgbox "Автообновление" "Не найден:\n$AUTO_UPDATE_LIB"
		return 0
	fi
	if ! ui_confirm "Автообновление" "Выключить cron и поставить ENABLED=0?"; then
		return 0
	fi
	[ -f "$AUTO_UPDATE_CRON" ] || {
		ui_msgbox "Автообновление" "Не найден:\n$AUTO_UPDATE_CRON"
		return 0
	}
	ui_menu_invoke_with_output "Выключить автообновление" sh "$AUTO_UPDATE_CRON" remove
}

system_menu_auto_update_settings() {
	[ -f "$AUTO_UPDATE_SETTINGS" ] || {
		ui_msgbox "Автообновление" "Не найден:\n$AUTO_UPDATE_SETTINGS"
		return 0
	}
	ui_run_menu_script "$AUTO_UPDATE_SETTINGS"
}

APK_FEED_SH="$ROOT_DIR/system/apk-feed.sh"

system_menu_apk_feed_load_lib() {
	[ -f "$ROOT_DIR/lib/apk-registry.sh" ] || return 1
	# shellcheck disable=SC1091
	. "$ROOT_DIR/lib/apk-registry.sh"
}

system_menu_apk_feed_status_line() {
	if system_menu_apk_feed_load_lib; then
		_st='выкл'
		xfree_apk_feed_is_enabled && _st='вкл'
		printf ' (%s, %s)' "$_st" "$(xfree_apk_feed_source_label)"
	else
		printf '%s' ''
	fi
}

system_menu_title_apk_feed_enable() {
	printf 'Включить фид xfree%s' "$(system_menu_apk_feed_status_line)"
}

system_menu_title_apk_feed_disable() {
	printf 'Выключить фид xfree%s' "$(system_menu_apk_feed_status_line)"
}

system_menu_title_apk_feed_source() {
	printf 'Источник фида xfree%s' "$(system_menu_apk_feed_status_line)"
}

system_menu_apk_feed_enable() {
	[ -f "$APK_FEED_SH" ] || {
		ui_msgbox "Фид xfree" "Не найден:\n$APK_FEED_SH"
		return 0
	}
	if ! ui_confirm "Фид xfree" \
"Включить apk-фид xfree-toolbox?

apk update снова будет ходить на выбранный источник (Nextcloud или GitHub).
Если Nextcloud (xfree-cloud) недоступен — смените источник на GitHub."; then
		return 0
	fi
	ui_menu_invoke_with_output "Включить фид xfree" sh "$APK_FEED_SH" enable
}

system_menu_apk_feed_disable() {
	[ -f "$APK_FEED_SH" ] || {
		ui_msgbox "Фид xfree" "Не найден:\n$APK_FEED_SH"
		return 0
	}
	if ! ui_confirm "Фид xfree" \
"Выключить apk-фид xfree-toolbox?

apk update больше не будет ждать xfree-cloud / GitHub (остальные репозитории OpenWrt без изменений).
Ключ подписи останется. Обновление toolbox — tar (install-from-cloud) или снова включить фид."; then
		return 0
	fi
	ui_menu_invoke_with_output "Выключить фид xfree" sh "$APK_FEED_SH" disable
}

system_menu_apk_feed_source() {
	[ -f "$APK_FEED_SH" ] || {
		ui_msgbox "Фид xfree" "Не найден:\n$APK_FEED_SH"
		return 0
	}
	system_menu_apk_feed_load_lib || {
		ui_msgbox "Фид xfree" "Не найден lib/apk-registry.sh"
		return 0
	}
	xfree_apk_feed_load_state
	_lines="$(printf '%s\n%s\n' \
		'cloud — Nextcloud (xfree-cloud.duckdns.org)' \
		'github — GitHub (публичный xfree-toolbox-releases)')"
	_choice="$(ui_select_from_lines "Источник фида xfree" \
"Где apk берёт packages.adb.

Сейчас: $(xfree_apk_feed_source_label).
GitHub — зеркало, если Nextcloud с вашего ISP недоступен." \
		"$_lines" 18 78 8 || true)"
	[ -n "${_choice:-}" ] || return 0
	_src=""
	case "$_choice" in
		cloud*) _src=cloud ;;
		github*) _src=github ;;
		*)
			ui_msgbox "Фид xfree" "Неизвестный источник:\n$_choice"
			return 0
			;;
	esac
	if ! ui_confirm "Источник фида xfree" \
"Поставить источник: $_src?

Если фид сейчас включён — URL в /etc/apk/repositories.d обновится и пойдёт apk update."; then
		return 0
	fi
	ui_menu_invoke_with_output "Источник фида xfree" sh "$APK_FEED_SH" source "$_src"
}

system_menu_install_wpad_mesh() {
	if ! ui_confirm "wpad-mesh-mbedtls" "Замена wpad-basic → wpad-mesh для 802.11s mesh.

Возможен обрыв Wi-Fi uplink. После смены пакета роутер будет перезагружен
(network restart не поднимает radio под новый hostapd).

Пакеты скачиваются локально (apk fetch); при сбое — откат wpad-basic из кэша.

Продолжить?"; then
		return 0
	fi
	ui_menu_invoke_with_output "Установка wpad-mesh-mbedtls" \
		sh "$SCRIPT_DIR/install-wpad-mesh.sh" --yes
}
