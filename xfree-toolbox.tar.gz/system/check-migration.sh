#!/bin/sh
# shellcheck shell=sh

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$(readlink -f "$0")")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"

: "${XFREE_STATE_ROOT:=/etc/xfree-toolbox}"
: "${XFREE_BACKUP_ROOT:=$XFREE_STATE_ROOT/backups}"
: "${XFREE_IFACE_ROUTING_ROOT:=$XFREE_STATE_ROOT/iface-routing}"
: "${XFREE_DNS_ROUTING_ROOT:=$XFREE_STATE_ROOT/dns-routing}"
: "${XFREE_VPN_ROOT:=$XFREE_STATE_ROOT/vpn}"
: "${XFREE_DOMAIN_ROUTING_ROOT:=$XFREE_STATE_ROOT/domain-routing}"

FAILED=0

ok() {
  printf '[OK] %s\n' "$*"
}

fail() {
  FAILED=1
  printf '[WARN] %s\n' "$*"
}

note() {
  printf '[OK] %s\n' "$*"
}

check_dir_exists() {
  path="$1"
  label="$2"
  if [ -d "$path" ]; then
    ok "$label: $path"
  else
    fail "$label отсутствует: $path"
  fi
}

check_absent() {
  path="$1"
  label="$2"
  if [ -e "$path" ] || [ -L "$path" ]; then
    fail "$label остался: $path"
  else
    ok "$label удалён: $path"
  fi
}

check_runtime_pair() {
  canonical_path="$1"
  canonical_label="$2"
  legacy_path="$3"
  legacy_label="$4"

  if [ -e "$canonical_path" ] || [ -L "$canonical_path" ]; then
    ok "$canonical_label: $canonical_path"
    return 0
  fi

  if [ -e "$legacy_path" ] || [ -L "$legacy_path" ]; then
    fail "$canonical_label отсутствует при наличии legacy path $legacy_label: $canonical_path"
    return 0
  fi

  note "$canonical_label ещё не создан: $canonical_path (чистое состояние без legacy path)"
}

printf 'Проверка миграции xfree-toolbox\n'
printf 'Время: %s\n\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"

printf 'Канонические каталоги:\n'
check_dir_exists "$XFREE_STATE_ROOT" "state root"
check_dir_exists "$XFREE_BACKUP_ROOT" "backup root"
check_dir_exists "$XFREE_IFACE_ROUTING_ROOT" "iface-routing root"
check_dir_exists "$XFREE_DNS_ROUTING_ROOT" "dns-routing root"
check_dir_exists "$XFREE_VPN_ROOT" "vpn root"
printf '\n'

printf 'Legacy paths:\n'
check_absent "/etc/domain-routing" "legacy domain-routing state"
check_absent "/etc/xfree-utils/domain-routing" "legacy xfree-utils domain-routing state"
check_absent "/etc/xfree-utils/backups" "legacy xfree-utils backups"
check_absent "/etc/xfree-utils/awg-ingress" "legacy xfree-utils awg-ingress"
check_absent "/etc/xfree-utils/vk-turn" "legacy xfree-utils vk-turn"
check_absent "/root/proton/sessions" "legacy proton sessions"
check_absent "/etc/dnsmasq.d/domain-routing" "legacy dnsmasq confdir"
check_absent "$XFREE_DOMAIN_ROUTING_ROOT" "legacy xfree-toolbox domain-routing state"
check_absent "/etc/hotplug.d/iface/90-domain-routing" "legacy hotplug"
check_absent "/etc/hotplug.d/iface/95-xfree-self-route" "legacy self-route hotplug"
printf '\n'

printf 'Canonical runtime paths:\n'
check_runtime_pair \
  "/etc/dnsmasq.d/xfree-toolbox-routing" \
  "dnsmasq confdir" \
  "/etc/dnsmasq.d/domain-routing" \
  "legacy dnsmasq confdir"

check_runtime_pair \
  "/etc/hotplug.d/iface/90-xfree-toolbox-routing" \
  "hotplug canonical file" \
  "/etc/hotplug.d/iface/90-domain-routing" \
  "legacy hotplug"

check_runtime_pair \
  "/etc/hotplug.d/iface/95-xfree-toolbox-self-route" \
  "self-route canonical file" \
  "/etc/hotplug.d/iface/95-xfree-self-route" \
  "legacy self-route hotplug"

if [ "$FAILED" -eq 0 ]; then
  printf '\nРезультат: OK\n'
  exit 0
fi

printf '\nРезультат: есть legacy-хвосты или отсутствующие canonical paths\n'
exit 1
