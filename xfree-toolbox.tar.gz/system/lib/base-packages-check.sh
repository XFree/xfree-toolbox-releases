#!/bin/sh
# shellcheck shell=sh
# Проверка: нужен ли пакет в install.sh (bulk + ensure).
# Только pm_is_installed и явные ветки контракта (PM / алиасы пакетов).

# Каноническое имя CA-пакета по менеджеру пакетов (ветка PM).
base_packages_ca_pkg() {
  _pm="${PM:-}"
  if [ -z "$_pm" ] && command -v pm_detect >/dev/null 2>&1; then
    _pm="$(pm_detect 2>/dev/null || true)"
  fi
  case "$_pm" in
    apk) printf '%s' 'ca-certificates' ;;
    *)   printf '%s' 'ca-bundle' ;;
  esac
}

# Логический слот → пакет для текущей ветки PM.
base_packages_resolve_pkg() {
  case "$1" in
    ca-certificates|ca-bundle)
      base_packages_ca_pkg
      ;;
    *)
      printf '%s' "$1"
      ;;
  esac
}

base_package_has_install_cmd() {
  command -v install >/dev/null 2>&1 && return 0
  command -v busybox >/dev/null 2>&1 || return 1
  busybox install --help >/dev/null 2>&1
}

# UPnP: контракт «luci-app-upnp или miniupnpd» (два имени одной роли).
base_package_upnp_satisfied() {
  pm_is_installed luci-app-upnp 2>/dev/null && return 0
  pm_is_installed miniupnpd 2>/dev/null && return 0
  return 1
}

base_package_is_missing() {
  pkg="$(base_packages_resolve_pkg "$1")"

  case "$pkg" in
    dnsmasq-full)
      if [ "${XFREE_BG_TASK:-0}" = "1" ] && [ "${XFREE_ALLOW_BG_INSTALL:-0}" != "1" ]; then
        pm_is_installed dnsmasq-full && return 1
        pm_is_installed dnsmasq && return 1
      fi
      pm_is_installed dnsmasq-full || return 0
      return 1
      ;;
    luci-app-upnp)
      base_package_upnp_satisfied && return 1
      return 0
      ;;
    coreutils-install)
      # Optional: пакет coreutils-install или штатный install(1) из busybox (24.x+).
      pm_is_installed coreutils-install 2>/dev/null && return 1
      base_package_has_install_cmd && return 1
      return 0
      ;;
    ip-tiny)
      # Контракт: ip-tiny или ip-full.
      pm_is_installed ip-tiny 2>/dev/null && return 1
      pm_is_installed ip-full 2>/dev/null && return 1
      return 0
      ;;
    *)
      pm_is_installed "$pkg" || return 0
      return 1
      ;;
  esac
}

# Развёртка списка required с учётом ветки CA.
base_packages_required_resolved() {
  for pkg in $BASE_PACKAGES_REQUIRED $INSTALL_ENSURE_PACKAGES; do
    [ -n "$pkg" ] || continue
    base_packages_resolve_pkg "$pkg"
    printf '\n'
  done
}

list_missing_base_packages() {
  pkg=""

  # Свежий снимок установленных имён (opkg: без per-pkg гонок).
  if command -v pm_installed_cache_load >/dev/null 2>&1; then
    pm_installed_cache_load
  fi

  for pkg in $BASE_PACKAGES_REQUIRED $INSTALL_ENSURE_PACKAGES; do
    [ -n "$pkg" ] || continue
    base_package_is_missing "$pkg" && printf '%s\n' "$(base_packages_resolve_pkg "$pkg")"
  done

  if command -v pm_installed_cache_clear >/dev/null 2>&1; then
    pm_installed_cache_clear
  fi
}

list_missing_optional_base_packages() {
  pkg=""

  if command -v pm_installed_cache_load >/dev/null 2>&1; then
    pm_installed_cache_load
  fi

  for pkg in $BASE_PACKAGES_OPTIONAL; do
    [ -n "$pkg" ] || continue
    base_package_is_missing "$pkg" && printf '%s\n' "$(base_packages_resolve_pkg "$pkg")"
  done

  if command -v pm_installed_cache_clear >/dev/null 2>&1; then
    pm_installed_cache_clear
  fi
}
