#!/bin/sh
# shellcheck shell=sh
# Проверка: нужен ли пакет в install.sh (bulk + ensure).

base_package_has_install_cmd() {
  command -v install >/dev/null 2>&1 && return 0
  command -v busybox >/dev/null 2>&1 || return 1
  busybox install --help >/dev/null 2>&1
}

base_package_upnp_satisfied() {
  pm_is_installed luci-app-upnp 2>/dev/null && return 0
  pm_is_installed miniupnpd 2>/dev/null && return 0
  return 1
}

base_package_is_missing() {
  pkg="$1"

  case "$pkg" in
    dnsmasq-full)
      if [ "${XFREE_BG_TASK:-0}" = "1" ]; then
        pm_is_installed dnsmasq-full && return 1
        pm_is_installed dnsmasq && return 1
      fi
      pm_is_installed dnsmasq-full || return 0
      return 1
      ;;
    luci-app-upnp)
      base_package_upnp_satisfied && return 1
      return 0
      ;;
    coreutils-install)
      pm_is_installed coreutils-install 2>/dev/null && return 1
      base_package_has_install_cmd && return 1
      return 0
      ;;
    *)
      pm_is_installed "$pkg" || return 0
      return 1
      ;;
  esac
}

list_missing_base_packages() {
  pkg=""

  for pkg in $BASE_PACKAGES_REQUIRED $INSTALL_ENSURE_PACKAGES; do
    [ -n "$pkg" ] || continue
    base_package_is_missing "$pkg" && printf '%s\n' "$pkg"
  done
}

list_missing_optional_base_packages() {
  pkg=""

  for pkg in $BASE_PACKAGES_OPTIONAL; do
    [ -n "$pkg" ] || continue
    base_package_is_missing "$pkg" && printf '%s\n' "$pkg"
  done
}
