#!/bin/sh
# shellcheck shell=sh
# Лестница восстановления DNS/apk: WAN → имена → стоп zapret → bootstrap DNS → пакеты.
# Sourced from system/recover-apk-network.sh (после common.sh / pkgmgr.sh).

: "${RECOVER_CLOUD_HOST:=xfree-cloud.duckdns.org}"
: "${RECOVER_MIRROR_HOST:=downloads.openwrt.org}"
: "${RECOVER_DNS_BOOTSTRAP_A:=1.1.1.1}"
: "${RECOVER_DNS_BOOTSTRAP_B:=8.8.8.8}"
: "${RECOVER_APK_PKG_NAME:=${XFREE_APK_PACKAGE_NAME:-xfree-toolbox}}"

if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/lib/apk-registry.sh" ]; then
    # shellcheck disable=SC1091
    . "$ROOT_DIR/lib/apk-registry.sh"
fi

recover_feed_probe_host() {
    if [ "${RECOVER_CLOUD_HOST_LOCK:-0}" = "1" ]; then
        printf '%s\n' "$RECOVER_CLOUD_HOST"
        return 0
    fi
    if command -v xfree_apk_feed_probe_host >/dev/null 2>&1; then
        xfree_apk_feed_probe_host
        return 0
    fi
    printf '%s\n' "$RECOVER_CLOUD_HOST"
}

RECOVER_WAN_OK=0
RECOVER_CLOUD_OK=0
RECOVER_MIRROR_BOOTSTRAP_OK=0
RECOVER_ZAPRET_STOPPED=0
RECOVER_USED_TEMP_DNS=0
RECOVER_NEED_PACKAGES=0
RECOVER_ZAPRET_REINSTALLED=0
RECOVER_RESOLV_FILE=""
RECOVER_RESOLV_BACKUP=""

recover_resolv_target() {
    if [ -n "${RECOVER_RESOLV_OVERRIDE:-}" ]; then
        printf '%s\n' "$RECOVER_RESOLV_OVERRIDE"
        return 0
    fi
    if [ -L /etc/resolv.conf ]; then
        _t="$(readlink -f /etc/resolv.conf 2>/dev/null || true)"
        [ -n "$_t" ] && printf '%s\n' "$_t" && return 0
        printf '%s\n' /tmp/resolv.conf
        return 0
    fi
    if [ -f /etc/resolv.conf ]; then
        printf '%s\n' /etc/resolv.conf
        return 0
    fi
    printf '%s\n' /tmp/resolv.conf
}

recover_probe_wan() {
    if command -v ip >/dev/null 2>&1; then
        ip route 2>/dev/null | grep -q '^default ' || return 1
    fi
    if command -v ping >/dev/null 2>&1; then
        ping -c 1 -W 3 "$RECOVER_DNS_BOOTSTRAP_A" >/dev/null 2>&1 && return 0
        ping -c 1 -W 3 "$RECOVER_DNS_BOOTSTRAP_B" >/dev/null 2>&1 && return 0
    fi
    return 1
}

recover_probe_cloud() {
    ns="${1:-}"
    if [ -n "$ns" ]; then
        common_probe_dns_host "$RECOVER_CLOUD_HOST" "$ns"
        return $?
    fi
    common_probe_dns_host "$RECOVER_CLOUD_HOST"
}

recover_probe_mirror_via() {
    ns="${1:-$RECOVER_DNS_BOOTSTRAP_A}"
    common_probe_dns_host "$RECOVER_MIRROR_HOST" "$ns"
}

recover_zapret_try_load() {
    [ -n "${ROOT_DIR:-}" ] || return 1
    [ -f "$ROOT_DIR/zapret/lib/engine.sh" ] || return 1
    [ -f "$ROOT_DIR/zapret/lib/service.sh" ] || return 1
    # shellcheck disable=SC1091
    . "$ROOT_DIR/zapret/lib/engine.sh"
    zapret_engine_apply_vars
    # shellcheck disable=SC1091
    . "$ROOT_DIR/zapret/lib/service.sh"
}

recover_zapret_stop_if_running() {
    RECOVER_ZAPRET_STOPPED=0
    recover_zapret_try_load || return 0
    init_script="$(zapret_initd_script)"
    [ -x "$init_script" ] || [ -f "$init_script" ] || return 0
    if ! zapret_service_is_running; then
        [ "${SILENT:-0}" = "0" ] && info "zapret не запущен — не останавливаю"
        return 0
    fi
    [ "${SILENT:-0}" = "0" ] && info "Останавливаю zapret (DPI/fake handshake мог резать WAN)…"
    if [ -x "$init_script" ]; then
        "$init_script" stop >/dev/null 2>&1 || true
    else
        sh "$init_script" stop >/dev/null 2>&1 || true
    fi
    RECOVER_ZAPRET_STOPPED=1
    return 0
}

recover_zapret_ensure_after() {
    recover_zapret_try_load || return 0
    if [ "$RECOVER_ZAPRET_STOPPED" != "1" ] && [ "$RECOVER_ZAPRET_REINSTALLED" != "1" ]; then
        return 0
    fi
    if [ "$RECOVER_ZAPRET_REINSTALLED" = "1" ]; then
        zapret_sync_config >/dev/null 2>&1 || true
    fi
    zapret_service_start_or_restart 0 || true
}

recover_temp_dns_restore() {
    [ -n "${RECOVER_RESOLV_BACKUP:-}" ] || return 0
    [ -f "$RECOVER_RESOLV_BACKUP" ] || return 0
    _target="${RECOVER_RESOLV_FILE:-$(recover_resolv_target)}"
    cp "$RECOVER_RESOLV_BACKUP" "$_target" 2>/dev/null || true
    rm -f "$RECOVER_RESOLV_BACKUP"
    RECOVER_RESOLV_BACKUP=""
    RECOVER_USED_TEMP_DNS=0
}

recover_temp_dns_apply() {
    RECOVER_RESOLV_FILE="$(recover_resolv_target)"
    mkdir -p "$(dirname -- "$RECOVER_RESOLV_FILE")" 2>/dev/null || true
    RECOVER_RESOLV_BACKUP="$(mktemp "${TMPDIR:-/tmp}/xfree-resolv.bak.XXXXXX")"
    if [ -f "$RECOVER_RESOLV_FILE" ]; then
        cp "$RECOVER_RESOLV_FILE" "$RECOVER_RESOLV_BACKUP"
    else
        : >"$RECOVER_RESOLV_BACKUP"
        : >"$RECOVER_RESOLV_FILE"
    fi
    printf 'nameserver %s\nnameserver %s\n' "$RECOVER_DNS_BOOTSTRAP_A" "$RECOVER_DNS_BOOTSTRAP_B" >"$RECOVER_RESOLV_FILE"
    RECOVER_USED_TEMP_DNS=1
    [ "${SILENT:-0}" = "0" ] && info "Временный DNS: $RECOVER_DNS_BOOTSTRAP_A / $RECOVER_DNS_BOOTSTRAP_B → $RECOVER_RESOLV_FILE"
    return 0
}

recover_refresh_packages() {
    [ "${SKIP_APK:-0}" = "1" ] && return 0
    command -v pm_update >/dev/null 2>&1 || return 0

    [ "${SILENT:-0}" = "0" ] && info "Обновляю индексы пакетов (pm_update)…"
    pm_update || warn "pm_update не удался — пробую точечные пакеты"

    if command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed "$RECOVER_APK_PKG_NAME"; then
        [ "${SILENT:-0}" = "0" ] && info "Обновляю пакет $RECOVER_APK_PKG_NAME…"
        pm_upgrade "$RECOVER_APK_PKG_NAME" || warn "Не удалось обновить $RECOVER_APK_PKG_NAME"
    fi

    if [ -f "${ROOT_DIR}/https-dns-proxy/install.sh" ]; then
        [ "${SILENT:-0}" = "0" ] && info "Переустанавливаю https-dns-proxy…"
        sh "${ROOT_DIR}/https-dns-proxy/install.sh" --yes --force --silent --no-update \
            || warn "Не удалось переустановить https-dns-proxy"
    fi

    if [ -f "${ROOT_DIR}/zapret/ensure-zapret.sh" ] && recover_zapret_try_load; then
        init_script="$(zapret_initd_script)"
        if [ -x "$init_script" ] || [ -f "$init_script" ] || [ "$RECOVER_ZAPRET_STOPPED" = "1" ]; then
            [ "${SILENT:-0}" = "0" ] && info "Проверяю/ставлю zapret…"
            if sh "${ROOT_DIR}/zapret/ensure-zapret.sh" --install-if-missing --upgrade-if-newer; then
                RECOVER_ZAPRET_REINSTALLED=1
            else
                warn "zapret ensure не удался — сервис всё равно попробуем start"
                RECOVER_ZAPRET_REINSTALLED=1
            fi
        fi
    fi
}

# Лестница: WAN → имя фида (Nextcloud или GitHub) → стоп zapret → bootstrap DNS + downloads.openwrt.org.
recover_network_diagnose() {
    RECOVER_WAN_OK=0
    RECOVER_CLOUD_OK=0
    RECOVER_MIRROR_BOOTSTRAP_OK=0
    RECOVER_NEED_PACKAGES=0
    RECOVER_CLOUD_HOST="$(recover_feed_probe_host)"

    if recover_probe_wan; then
        RECOVER_WAN_OK=1
        [ "${SILENT:-0}" = "0" ] && info "WAN: default route + ping ${RECOVER_DNS_BOOTSTRAP_A} ок"
    else
        warn "WAN слабый: нет default route или ping ${RECOVER_DNS_BOOTSTRAP_A}"
    fi

    if recover_probe_cloud; then
        RECOVER_CLOUD_OK=1
        [ "${SILENT:-0}" = "0" ] && info "DNS: $RECOVER_CLOUD_HOST резолвится"
    else
        [ "${SILENT:-0}" = "0" ] && warn "DNS: $RECOVER_CLOUD_HOST не резолвится текущим резолвером"
    fi

    if [ "$RECOVER_WAN_OK" = "1" ] && [ "$RECOVER_CLOUD_OK" != "1" ]; then
        recover_zapret_stop_if_running
        if recover_probe_cloud; then
            RECOVER_CLOUD_OK=1
            RECOVER_NEED_PACKAGES=1
            [ "${SILENT:-0}" = "0" ] && info "После стопа zapret $RECOVER_CLOUD_HOST резолвится"
        fi
    fi

    if [ "$RECOVER_WAN_OK" = "1" ] && [ "$RECOVER_CLOUD_OK" != "1" ]; then
        recover_temp_dns_apply
        RECOVER_NEED_PACKAGES=1
        if recover_probe_cloud "$RECOVER_DNS_BOOTSTRAP_A"; then
            RECOVER_CLOUD_OK=1
            [ "${SILENT:-0}" = "0" ] && info "Через ${RECOVER_DNS_BOOTSTRAP_A}: $RECOVER_CLOUD_HOST ок"
        else
            warn "Через ${RECOVER_DNS_BOOTSTRAP_A}: $RECOVER_CLOUD_HOST всё ещё не резолвится"
        fi
        if recover_probe_mirror_via "$RECOVER_DNS_BOOTSTRAP_A"; then
            RECOVER_MIRROR_BOOTSTRAP_OK=1
            [ "${SILENT:-0}" = "0" ] && info "Через ${RECOVER_DNS_BOOTSTRAP_A}: $RECOVER_MIRROR_HOST ок"
        else
            warn "Через ${RECOVER_DNS_BOOTSTRAP_A}: $RECOVER_MIRROR_HOST не резолвится — apk/opkg зеркала могут не скачаться"
        fi
    elif [ "$RECOVER_ZAPRET_STOPPED" = "1" ]; then
        RECOVER_NEED_PACKAGES=1
    fi

    [ "${SILENT:-0}" = "0" ] && info "Пробы: wan=${RECOVER_WAN_OK} cloud=${RECOVER_CLOUD_OK} mirror_bootstrap=${RECOVER_MIRROR_BOOTSTRAP_OK} zapret_stopped=${RECOVER_ZAPRET_STOPPED} temp_dns=${RECOVER_USED_TEMP_DNS}"
    return 0
}

recover_apk_sanitize_world_qpins() {
    _world="/etc/apk/world"
    _tmp="/tmp/xfree-recover-apk-world.$$"
    [ -f "$_world" ] || return 0
    sed -E 's/><Q[[:alnum:]+\/=._-]+$//' "$_world" >"$_tmp" 2>/dev/null || {
        rm -f "$_tmp" 2>/dev/null || true
        return 0
    }
    if cmp -s "$_world" "$_tmp" 2>/dev/null; then
        rm -f "$_tmp" 2>/dev/null || true
        return 0
    fi
    _backup="${_world}.xfree-bak.$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"
    cp "$_world" "$_backup" 2>/dev/null || true
    mv "$_tmp" "$_world"
    [ "${SILENT:-0}" = "0" ] && info "apk world: убраны устаревшие Q-пины (backup: ${_backup:-нет})"
    return 0
}

recover_ensure_dnsmasq_present() {
    if command -v pm_is_installed >/dev/null 2>&1; then
        if pm_is_installed dnsmasq-full || pm_is_installed dnsmasq; then
            return 0
        fi
        [ "${SILENT:-0}" = "0" ] && warn "dnsmasq не установлен — пробую установить dnsmasq-full…"
        if command -v pm_install >/dev/null 2>&1; then
            pm_install dnsmasq-full 2>/dev/null || pm_install dnsmasq 2>/dev/null || \
                warn "Не удалось установить dnsmasq-full/dnsmasq (сеть или репозиторий)"
        fi
        return 0
    fi
    if command -v apk >/dev/null 2>&1; then
        apk info -e dnsmasq-full >/dev/null 2>&1 && return 0
        apk info -e dnsmasq >/dev/null 2>&1 && return 0
        apk add dnsmasq-full 2>/dev/null || apk add dnsmasq 2>/dev/null || true
    elif command -v opkg >/dev/null 2>&1; then
        opkg list-installed 2>/dev/null | grep -q '^dnsmasq-full ' && return 0
        opkg list-installed 2>/dev/null | grep -q '^dnsmasq ' && return 0
        opkg install dnsmasq-full 2>/dev/null || opkg install dnsmasq 2>/dev/null || true
    fi
}

recover_probe_xfree_feed() {
    _feed=""
    for _f in /etc/apk/repositories.d/*.list /etc/apk/repositories.d/xfree-toolbox.list; do
        [ -f "$_f" ] || continue
        _line="$(grep -v '^[[:space:]]*#' "$_f" 2>/dev/null | sed -n '1p' | tr -d '\r\n')"
        case "$_line" in
            http://*|https://*) _feed="$_line" ;;
        esac
        [ -n "$_feed" ] && break
    done
    [ -n "$_feed" ] || return 0

    [ "${SILENT:-0}" = "0" ] && info "Проверка xfree feed (wget): $_feed"
    _tmp="/tmp/xfree-feed-probe.$$"
    if wget -T 25 -O "$_tmp" "$_feed" 2>/dev/null; then
        _sz="$(wc -c <"$_tmp" 2>/dev/null | tr -d ' ')"
        rm -f "$_tmp" 2>/dev/null || true
        if [ "${_sz:-0}" -gt 64 ]; then
            [ "${SILENT:-0}" = "0" ] && success "xfree feed скачивается (${_sz} bytes)"
            return 0
        fi
        warn "xfree feed: ответ слишком короткий (${_sz:-0} bytes) — unexpected EOF в apk update"
    else
        rm -f "$_tmp" 2>/dev/null || true
        warn "xfree feed: wget не смог скачать (Operation not permitted / error 4)"
        warn "Официальные репозитории OpenWrt при этом могут работать — проверьте policy routing, zapret, dns-routing, WAN."
    fi
    return 1
}
