#!/bin/sh
# shellcheck shell=sh
# Non-interactive system actions for LuCI (ubus xfree-toolbox systemMenu).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
STATUS_SH="$SCRIPT_DIR/toolbox-status.sh"

ACTION="${1:-}"
ARG="${2:-}"
PAYLOAD="${3:-}"

action_system_bg_status() {
	_log="/tmp/xfree-background-tasks/system-action.log"
	_running=0
	_task=""
	_exit="0"
	_status="idle"

	# shellcheck disable=SC1090
	[ -f "$ROOT_DIR/lib/background-tasks.sh" ] && . "$ROOT_DIR/lib/background-tasks.sh"

	if bg_tasks_is_running 2>/dev/null; then
		_running=1
		_task="${BG_TASK_NAME:-system}"
		_status="running"
		[ -n "${BG_TASK_LOG_FILE:-}" ] && _log="$BG_TASK_LOG_FILE"
	elif bg_tasks_read_last_meta 2>/dev/null; then
		_task="${BG_TASK_LAST_NAME:-}"
		_status="${BG_TASK_LAST_STATUS:-done}"
		_exit="${BG_TASK_LAST_EXIT_CODE:-0}"
		[ -n "${BG_TASK_LAST_LOG_FILE:-}" ] && _log="$BG_TASK_LAST_LOG_FILE"
	fi

	_out=""
	if [ -f "$_log" ]; then
		_out="$(tail -n 250 "$_log" 2>/dev/null || true)"
	fi

	set +u
	if [ -f /usr/share/libubox/jshn.sh ]; then
		# shellcheck disable=SC1091
		. /usr/share/libubox/jshn.sh
		json_init
		json_add_int code 0
		json_add_int running "$_running"
		json_add_string status "$_status"
		json_add_string exitCode "$_exit"
		json_add_string task "$_task"
		json_add_string stdout "$_out"
		json_dump
	else
		printf '{"code":0,"running":%d,"status":"%s","exitCode":"%s","task":"%s"}\n' \
			"$_running" "$_status" "$_exit" "$_task"
	fi
}

run_upstreams_handler() {
	export ROOT_DIR
	export XFREE_PIPELINE_HEADLESS=1
	export UI_TMP_ROOT="/tmp/upstreams-rpc-$$"
	mkdir -p "$UI_TMP_ROOT"
	# shellcheck disable=SC1091
	[ -f "$ROOT_DIR/lib/ui.sh" ] && . "$ROOT_DIR/lib/ui.sh"
	# shellcheck disable=SC1091
	[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"
	# shellcheck disable=SC1091
	[ -f "$ROOT_DIR/lib/upstreams.sh" ] && . "$ROOT_DIR/lib/upstreams.sh"
	# shellcheck disable=SC1091
	[ -f "$ROOT_DIR/upstreams/menu.handlers.sh" ] && . "$ROOT_DIR/upstreams/menu.handlers.sh"
	if command -v ui_init >/dev/null 2>&1; then
		ui_init
	fi
	"$@" || true
	rm -rf "$UI_TMP_ROOT"
}

case "$ACTION" in
status)
	sh "$STATUS_SH" --status
	;;
hardwareStatus)
	printf '=== Статус оборудования и аппаратных кнопок ===\n'
	if [ -f /etc/hotplug.d/button/90-xfree-wps-sync-apply ] && [ -x /etc/hotplug.d/button/90-xfree-wps-sync-apply ]; then
		printf '[✓] Обновление профиля кнопкой WPS/Mesh: ВКЛЮЧЕНО (удержание 3с запускает sync)\n'
	else
		printf '[-] Обновление профиля кнопкой WPS/Mesh: ВЫКЛЮЧЕНО (штатный обработчик OpenWrt)\n'
	fi
	;;
checkUpdate)
	printf '=== Проверка обновлений ===\n'
	sh "$STATUS_SH" --check
	;;
upgrade)
	printf '=== Обновление xfree-toolbox ===\n'
	sh "$STATUS_SH" --upgrade
	;;
installBase)
	printf '=== Установка / обновление базовых пакетов ===\n'
	sh "$SCRIPT_DIR/install.sh"
	;;
installLuciRu)
	printf '=== Установка русской локализации LuCI ===\n'
	sh "$SCRIPT_DIR/install-luci-i18n-ru.sh"
	;;
updateLuci)
	printf '=== Обновление LuCI ===\n'
	sh "$SCRIPT_DIR/update-luci.sh" --scope luci --auto
	;;
updateAll)
	printf '=== Обновление всех системных пакетов ===\n'
	sh "$SCRIPT_DIR/update-luci.sh" --scope all --auto
	;;
checkMigration)
	printf '=== Проверка миграции ===\n'
	sh "$SCRIPT_DIR/check-migration.sh"
	;;
backupRotate)
	printf '=== Принудительная ротация backup ===\n'
	sh "$SCRIPT_DIR/backup-maintenance.sh" --action rotate --apply
	;;
backupCleanup)
	printf '=== Чистка устаревших backup ===\n'
	sh "$SCRIPT_DIR/backup-maintenance.sh" --action cleanup --apply
	;;
backupPurge)
	printf '=== Полная очистка backup ===\n'
	sh "$SCRIPT_DIR/backup-maintenance.sh" --action purge --apply
	;;
wpsButtonEnable)
	printf '=== Включение обновления профиля по кнопке ===\n'
	sh "$SCRIPT_DIR/hardware/install-button-hooks.sh" --install "$ROOT_DIR"
	;;
wpsButtonDisable)
	printf '=== Выключение обновления профиля по кнопке ===\n'
	sh "$SCRIPT_DIR/hardware/install-button-hooks.sh" --remove
	;;
writeNfc)
	printf '=== Запись NFC (Wi-Fi 5 GHz) ===\n'
	if [ -f "$ROOT_DIR/xinfc/write-nfc-5g.sh" ]; then
		sh "$ROOT_DIR/xinfc/write-nfc-5g.sh" --yes
	else
		printf 'Скрипт write-nfc-5g.sh не найден\n'
	fi
	;;
installWpadMesh)
	printf '=== Установка wpad-mesh-mbedtls (802.11s) ===\n'
	sh "$SCRIPT_DIR/install-wpad-mesh.sh"
	;;
autoUpdateStatus)
	if [ -f "$STATUS_SH" ]; then
		sh "$STATUS_SH" --status 2>/dev/null || true
	fi
	printf '=== AUTO_UPDATE ===\n'
	# shellcheck disable=SC1091
	[ -f "$SCRIPT_DIR/auto-update-lib.sh" ] && . "$SCRIPT_DIR/auto-update-lib.sh"
	sh "$SCRIPT_DIR/auto-update-cron.sh" status
	_running=0
	[ -f /tmp/xfree-auto-update.once ] && _running=1
	printf 'RUNNING=%d\n' "$_running"
	_log="$(auto_update_log_path 2>/dev/null || echo /etc/xfree-toolbox/system/auto-update.log)"
	if [ -f "$_log" ]; then
		_last_line="$(grep -E '^(start|done|error):' "$_log" 2>/dev/null | tail -n 1 || true)"
		printf 'LAST_LOG_LINE=%s\n' "$_last_line"
		_last_mod="$(date -r "$_log" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || stat -c '%y' "$_log" 2>/dev/null || true)"
		printf 'LAST_LOG_DATE=%s\n' "$_last_mod"
	else
		printf 'LAST_LOG_LINE=\n'
		printf 'LAST_LOG_DATE=\n'
	fi
	printf '=== APK_FEED ===\n'
	sh "$SCRIPT_DIR/apk-feed.sh" status
	;;
autoUpdateSave)
	printf '=== Сохранение настроек автообновления ===\n'
	# shellcheck disable=SC1091
	. "$SCRIPT_DIR/auto-update-lib.sh"
	_en=""
	_mode=""
	_hour=""
	_min=""
	if [ -n "$ARG" ]; then
		_en="$(printf '%s' "$ARG" | cut -d'|' -f1)"
		_mode="$(printf '%s' "$ARG" | cut -d'|' -f2)"
		_hour="$(printf '%s' "$ARG" | cut -d'|' -f3)"
		_min="$(printf '%s' "$ARG" | cut -d'|' -f4)"
	fi
	if [ -z "$_en" ] && [ -n "$PAYLOAD" ]; then
		_en="$(printf '%s' "$PAYLOAD" | sed -n 's/.*"enabled"[[:space:]]*:[[:space:]]*"\?\([0-9]\+\)"\?.*/\1/p')"
		_mode="$(printf '%s' "$PAYLOAD" | sed -n 's/.*"mode"[[:space:]]*:[[:space:]]*"\?\([a-zA-Z0-9_-]\+\)"\?.*/\1/p')"
		_hour="$(printf '%s' "$PAYLOAD" | sed -n 's/.*"hour"[[:space:]]*:[[:space:]]*"\?\([0-9]\+\)"\?.*/\1/p')"
		_min="$(printf '%s' "$PAYLOAD" | sed -n 's/.*"minute"[[:space:]]*:[[:space:]]*"\?\([0-9]\+\)"\?.*/\1/p')"
	fi
	_conf="$(auto_update_conf_path)"
	[ -n "$_en" ] || _en="1"
	[ -n "$_mode" ] || _mode="upstreams-lists-package"
	[ -n "$_hour" ] || _hour="2"
	[ -n "$_min" ] || _min="0"

	auto_update_conf_kv_set "$_conf" ENABLED "$_en"
	auto_update_conf_kv_set "$_conf" MODE "$_mode"
	auto_update_conf_kv_set "$_conf" SCHEDULE_HOUR "$_hour"
	auto_update_conf_kv_set "$_conf" SCHEDULE_MINUTE "$_min"

	if [ "$_en" = "1" ]; then
		sh "$SCRIPT_DIR/auto-update-cron.sh" install
	else
		sh "$SCRIPT_DIR/auto-update-cron.sh" remove
	fi
	printf '[+] Настройки сохранены (ENABLED=%s, MODE=%s, SCHEDULE=%02d:%02d)\n' "$_en" "$_mode" "$_hour" "$_min"
	;;
autoUpdateRunNow)
	printf '=== Запуск автообновления вручную ===\n'
	# shellcheck disable=SC1091
	[ -f "$SCRIPT_DIR/auto-update-lib.sh" ] && . "$SCRIPT_DIR/auto-update-lib.sh"
	_bg="$ROOT_DIR/lib/bg-task-run.sh"
	_run="$SCRIPT_DIR/auto-update-run.sh"
	_log="$(auto_update_log_path 2>/dev/null || echo /etc/xfree-toolbox/system/auto-update.log)"
	if [ -f "$_bg" ] && [ -f "$_run" ]; then
		sh "$_bg" auto-update --log "$_log" -- /bin/sh "$_run" --force
		printf '[+] Фоновое обновление запущено (лог: %s)\n' "$_log"
	else
		printf '[-] Скрипты запуска не найдены\n'
		exit 1
	fi
	;;
autoUpdateLog)
	printf '=== Журнал автообновления ===\n'
	# shellcheck disable=SC1091
	[ -f "$SCRIPT_DIR/auto-update-lib.sh" ] && . "$SCRIPT_DIR/auto-update-lib.sh"
	_log="$(auto_update_log_path 2>/dev/null || echo /etc/xfree-toolbox/system/auto-update.log)"
	if [ -f /tmp/xfree-auto-update.once ] || pidof -s auto-update-run.sh >/dev/null 2>&1; then
		printf '[*] Внимание: процесс автообновления сейчас активен в фоне...\n\n'
	fi
	if [ -f "$_log" ] && [ -s "$_log" ]; then
		tail -n 250 "$_log"
	elif [ -f "$_log" ]; then
		printf 'Файл журнала (%s) пуст.\n' "$_log"
		printf 'Автообновление ещё не выполнялось по расписанию.\n'
		printf 'Нажмите «Запустить сейчас», чтобы выполнить тестовый запуск и наполнить журнал.\n'
	else
		printf 'Файл журнала (%s) ещё не создан.\n' "$_log"
		printf 'Нажмите «Запустить сейчас» для первого запуска.\n'
	fi
	;;
autoUpdateEnable)
	printf '=== Включение автообновления ===\n'
	sh "$SCRIPT_DIR/auto-update-cron.sh" install
	;;
autoUpdateDisable)
	printf '=== Выключение автообновления ===\n'
	sh "$SCRIPT_DIR/auto-update-cron.sh" remove
	;;
apkFeedEnable)
	printf '=== Включение APK-фида xfree ===\n'
	sh "$SCRIPT_DIR/apk-feed.sh" enable
	;;
apkFeedDisable)
	printf '=== Выключение APK-фида xfree ===\n'
	sh "$SCRIPT_DIR/apk-feed.sh" disable
	;;
apkFeedSetSource)
	_src="${ARG:-github}"
	printf '=== Смена источника APK-фида на %s ===\n' "$_src"
	sh "$SCRIPT_DIR/apk-feed.sh" source "$_src"
	;;
apkFeedFailover)
	printf '=== Проверка и переключение зеркала фида ===\n'
	sh "$SCRIPT_DIR/apk-feed.sh" failover
	;;
apkUpdate)
	printf '=== Обновление каталога пакетов (apk update) ===\n'
	if command -v apk >/dev/null 2>&1; then
		apk update
	else
		printf 'Команда apk не найдена\n'
	fi
	;;
modemDiag)
	printf '=== Диагностика USB-модема ===\n'
	if [ -f "$SCRIPT_DIR/modem/diagnostics.sh" ]; then
		sh "$SCRIPT_DIR/modem/diagnostics.sh"
	else
		printf 'Скрипт диагностики модема не найден\n'
	fi
	;;
modemHilink)
	printf '=== Установка пакетов HiLink ===\n'
	sh "$SCRIPT_DIR/modem/packages.sh" hilink-setup
	;;
modemLteIface)
	printf '=== Создание WAN-интерфейса lte ===\n'
	sh "$SCRIPT_DIR/modem/configure-hilink-wan.sh"
	;;
modemRecommended)
	printf '=== Установка рекомендуемого набора пакетов модема ===\n'
	sh "$SCRIPT_DIR/modem/packages.sh" recommended-setup
	;;
telemtStatus)
	printf '=== Статус Telemt MTProxy ===\n'
	if [ -f "$ROOT_DIR/telemt/ensure-telemt.sh" ]; then
		sh "$ROOT_DIR/telemt/ensure-telemt.sh" --status
	fi
	;;
telemtInstall)
	printf '=== Установка Telemt MTProxy ===\n'
	if [ -f "$ROOT_DIR/telemt/ensure-telemt.sh" ]; then
		sh "$ROOT_DIR/telemt/ensure-telemt.sh" --install-if-missing
	fi
	;;
vkturnStatus)
	printf '=== Статус VK-Turn Proxy ===\n'
	if [ -f "$ROOT_DIR/vk-turn/status.sh" ]; then
		sh "$ROOT_DIR/vk-turn/status.sh"
	fi
	;;
vkturnSetup)
	printf '=== Настройка VK-Turn Proxy ===\n'
	if [ -f "$ROOT_DIR/vk-turn/setup-server.sh" ]; then
		sh "$ROOT_DIR/vk-turn/setup-server.sh"
	fi
	;;
mgmtConnect)
	printf '=== Подключение к XFree Hub (mgmt-hub) ===\n'
	if [ -f "$ROOT_DIR/mgmt-hub/router/ensure-client.sh" ]; then
		sh "$ROOT_DIR/mgmt-hub/router/ensure-client.sh"
	else
		printf 'Скрипт ensure-client.sh не найден\n'
	fi
	;;
upstreamsUpdateApply)
	printf '=== Обновление и применение источников ===\n'
	run_upstreams_handler update_selected_modules
	run_upstreams_handler check_active_list_updates 1
	;;
upstreamsUpdateActive)
	printf '=== Обновление активных источников ===\n'
	run_upstreams_handler update_selected_modules
	;;
upstreamsApply)
	printf '=== Применение обновлений источников ===\n'
	run_upstreams_handler check_active_list_updates 1
	;;
upstreamsReindex)
	printf '=== Переиндексация источников списков ===\n'
	if [ -f "$ROOT_DIR/lib/upstreams.sh" ]; then
		# shellcheck disable=SC1091
		. "$ROOT_DIR/lib/upstreams.sh"
		upstreams_reindex_sources "$ROOT_DIR" 2>/dev/null || true
	fi
	printf 'OK: индекс обновлён\n'
	;;
systemStartBg)
	_task_name="${ARG:-}"
	[ -n "$_task_name" ] || _task_name="updateAll"
	_log="/tmp/xfree-background-tasks/system-action.log"
	mkdir -p "/tmp/xfree-background-tasks" 2>/dev/null || true

	# shellcheck disable=SC1090
	[ -f "$ROOT_DIR/lib/background-tasks.sh" ] && . "$ROOT_DIR/lib/background-tasks.sh"
	if bg_tasks_is_running 2>/dev/null; then
		set +u
		[ -f /usr/share/libubox/jshn.sh ] && . /usr/share/libubox/jshn.sh
		json_init
		json_add_int code 1
		json_add_int running 1
		json_add_string error "Другая фоновая задача уже выполняется: ${BG_TASK_NAME:-task}"
		json_dump
		exit 0
	fi

	rm -f "$_log" 2>/dev/null || true
	_runner="$ROOT_DIR/lib/bg-task-run.sh"
	(
		export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
		sh "$_runner" "system" --log "$_log" -- \
			sh "$SCRIPT_DIR/luci-rpc.sh" "$_task_name" "$PAYLOAD"
	) >/dev/null 2>&1 &

	sleep 1
	action_system_bg_status
	exit 0
	;;
systemBgStatus)
	action_system_bg_status
	exit 0
	;;
*)
	printf 'unknown systemMenu action: %s\n' "${ACTION:-?}" >&2
	exit 1
	;;
esac
