#!/bin/sh
# shellcheck shell=sh
# Non-interactive system actions for LuCI (ubus xfree-toolbox systemMenu).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
STATUS_SH="$SCRIPT_DIR/toolbox-status.sh"

ACTION="${1:-}"
ARG="${2:-}"
PAYLOAD="${3:-}"

# Display version for luci-app: deploy stamp → apk → toolbox VERSION (X.Y.Z+B → X.Y.Z-rB).
# Stamp first: tar/file deploy does not update apk world, so apk can be stale (e.g. 0.1.25-r0).
system_luci_app_version() {
	_v=""
	if [ -f /etc/xfree-toolbox/luci-app.version ]; then
		_v="$(head -n1 /etc/xfree-toolbox/luci-app.version | tr -d '\r\n\t ' || true)"
	fi
	if [ -z "$_v" ] && command -v apk >/dev/null 2>&1; then
		_v="$(apk list -I luci-app-xfree-toolbox 2>/dev/null | awk '{print $1}' | sed 's/^luci-app-xfree-toolbox-//' || true)"
	fi
	if [ -z "$_v" ] && [ -f "$ROOT_DIR/VERSION" ]; then
		_line="$(head -n1 "$ROOT_DIR/VERSION" | tr -d '\r\n\t ' || true)"
		case "$_line" in
		*+*)
			_v="$(printf '%s' "$_line" | sed -nE 's/^([0-9]+\.[0-9]+\.[0-9]+)\+([0-9]+)$/\1-r\2/p')"
			;;
		*)
			_v="$(printf '%s' "$_line" | sed -nE 's/^([0-9]+\.[0-9]+\.[0-9]+)$/\1-r0/p')"
			;;
		esac
	fi
	printf '%s\n' "${_v:-}"
}

action_system_bg_status() {
	_log="/tmp/xfree-background-tasks/system-action.log"
	_running=0
	_task=""
	_exit="0"
	_status="idle"

	# shellcheck disable=SC1090
	[ -f "$ROOT_DIR/lib/background-tasks.sh" ] && . "$ROOT_DIR/lib/background-tasks.sh"

	if bg_tasks_is_running 2>/dev/null; then
		_running=1
		_task="${BG_TASK_NAME:-system}"
		_status="running"
		[ -n "${BG_TASK_LOG_FILE:-}" ] && _log="$BG_TASK_LOG_FILE"
	elif bg_tasks_read_last_meta 2>/dev/null; then
		_task="${BG_TASK_LAST_NAME:-}"
		_status="${BG_TASK_LAST_STATUS:-done}"
		_exit="${BG_TASK_LAST_EXIT_CODE:-0}"
		[ -n "${BG_TASK_LAST_LOG_FILE:-}" ] && _log="$BG_TASK_LAST_LOG_FILE"
	fi

	_out=""
	if [ -f "$_log" ]; then
		_out="$(tail -n 250 "$_log" 2>/dev/null || true)"
	fi

	set +u
	if [ -f /usr/share/libubox/jshn.sh ]; then
		# shellcheck disable=SC1091
		. /usr/share/libubox/jshn.sh
		json_init
		json_add_int code 0
		json_add_int running "$_running"
		json_add_string status "$_status"
		json_add_string exitCode "$_exit"
		json_add_string task "$_task"
		json_add_string stdout "$_out"
		json_dump
	else
		printf '{"code":0,"running":%d,"status":"%s","exitCode":"%s","task":"%s"}\n' \
			"$_running" "$_status" "$_exit" "$_task"
	fi
}

run_upstreams_handler() {
	export ROOT_DIR
	export XFREE_PIPELINE_HEADLESS=1
	export UI_TMP_ROOT="/tmp/upstreams-rpc-$$"
	mkdir -p "$UI_TMP_ROOT"
	# shellcheck disable=SC1091
	[ -f "$ROOT_DIR/lib/ui.sh" ] && . "$ROOT_DIR/lib/ui.sh"
	# shellcheck disable=SC1091
	[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"
	# shellcheck disable=SC1091
	[ -f "$ROOT_DIR/lib/upstreams.sh" ] && . "$ROOT_DIR/lib/upstreams.sh"
	# shellcheck disable=SC1091
	[ -f "$ROOT_DIR/upstreams/menu.handlers.sh" ] && . "$ROOT_DIR/upstreams/menu.handlers.sh"
	if command -v ui_init >/dev/null 2>&1; then
		ui_init
	fi
	"$@" || true
	rm -rf "$UI_TMP_ROOT"
}

system_luci_emit_task_status() {
	_running=0
	_task=""
	_pid=""
	_log=""
	_last_status=""
	_last_exit=""

	# shellcheck disable=SC1090
	[ -f "$ROOT_DIR/lib/background-tasks.sh" ] && . "$ROOT_DIR/lib/background-tasks.sh"

	if bg_tasks_is_running 2>/dev/null; then
		_running=1
		_task="${BG_TASK_NAME:-}"
		_pid="${BG_TASK_PID:-}"
		_log="${BG_TASK_LOG_FILE:-}"
	elif bg_tasks_read_last_meta 2>/dev/null; then
		_task="${BG_TASK_LAST_NAME:-}"
		_log="${BG_TASK_LAST_LOG_FILE:-}"
		_last_status="${BG_TASK_LAST_STATUS:-}"
		_last_exit="${BG_TASK_LAST_EXIT_CODE:-}"
	fi

	if [ "$_running" -eq 1 ]; then
		printf 'STATUS=running\n'
	elif [ -n "$_last_status" ] || [ -n "$_task" ]; then
		printf 'STATUS=idle\n'
	else
		printf 'STATUS=none\n'
	fi
	[ -n "$_task" ] && printf 'TASK=%s\n' "$_task"
	[ -n "$_pid" ] && printf 'PID=%s\n' "$_pid"
	[ -n "$_log" ] && printf 'LOG=%s\n' "$_log"
	[ -n "$_last_status" ] && printf 'LAST_STATUS=%s\n' "$_last_status"
	[ -n "$_last_exit" ] && printf 'LAST_EXIT=%s\n' "$_last_exit"
	if [ -n "$_log" ] && [ -f "$_log" ]; then
		printf '%s\n' '---'
		tail -n 120 "$_log" 2>/dev/null || true
	fi
}

system_luci_start_bg() {
	_task="$1"
	shift
	_runner="$ROOT_DIR/lib/bg-task-run.sh"
	_log="${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}/${_task}.log"

	[ -f "$_runner" ] || {
		printf 'STATUS=error\n'
		printf 'missing: %s\n' "$_runner"
		return 1
	}

	# shellcheck disable=SC1090
	[ -f "$ROOT_DIR/lib/background-tasks.sh" ] && . "$ROOT_DIR/lib/background-tasks.sh"

	if bg_tasks_is_running 2>/dev/null; then
		printf '=== Задача уже выполняется ===\n'
		printf 'STATUS=already_running\n'
		system_luci_emit_task_status
		return 0
	fi

	printf '=== Запуск в фоне: %s ===\n' "$_task"
	printf 'Лог: %s\n\n' "$_log"
	(
		export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
		export XFREE_ALLOW_BG_INSTALL=1
		sh "$_runner" "$_task" --log "$_log" -- env SYSTEM_LUCI_FOREGROUND=1 "$@"
	) >/dev/null 2>&1 &
	sleep 1
	system_luci_emit_task_status
}

# NFC есть только у плат из xinfc/boards.tsv (сейчас Xiaomi AX3000T).
system_luci_nfc_board_init() {
	if [ -f "$ROOT_DIR/xinfc/lib/board.sh" ]; then
		XINFC_SCRIPT_DIR="$ROOT_DIR/xinfc"
		# shellcheck disable=SC1091
		. "$ROOT_DIR/xinfc/lib/board.sh"
		return 0
	fi
	return 1
}

system_luci_nfc_board_name() {
	if system_luci_nfc_board_init; then
		xinfc_board_name 2>/dev/null || true
		return 0
	fi
	printf '%s\n' "unknown"
}

system_luci_nfc_board_supported() {
	system_luci_nfc_board_init || return 1
	if xinfc_board_supported; then
		return 0
	fi
	return 1
}

system_luci_emit_nfc_status() {
	_nfc_board_state="unknown"
	_nfc_board_name="unknown"
	if system_luci_nfc_board_init; then
		_nfc_board_name="$(xinfc_board_name 2>/dev/null || true)"
		[ -n "$_nfc_board_name" ] || _nfc_board_name="unknown"
		if xinfc_board_supported; then
			_nfc_board_state="supported"
		else
			_nfc_board_state="unsupported"
		fi
	fi
	printf 'NFC_BOARD=%s\n' "$_nfc_board_state"
	printf 'NFC_BOARD_NAME=%s\n' "$_nfc_board_name"
	if [ -f "$ROOT_DIR/xinfc/write-nfc-5g.sh" ]; then
		printf 'NFC_SCRIPT=available\n'
	else
		printf 'NFC_SCRIPT=not_found\n'
	fi
}

system_luci_want_bg() {
	[ "${SYSTEM_LUCI_FOREGROUND:-}" = "1" ] && return 1
	case "${ACTION:-}" in
	installWpadMesh|configureMeshMaster|configureMeshRoaming|configureMeshSatellite|meshDiag|installBase|installLuciRu|updateLuci|updateAll|upgrade|apkUpdate|telemtInstall|telemtUpgrade|vkturnSetup|modemHilink|modemRecommended)
		return 0
		;;
	*)
		return 1
		;;
	esac
}

if system_luci_want_bg; then
	system_luci_start_bg "$ACTION" sh "$SCRIPT_DIR/luci-rpc.sh" "$ACTION" "${ARG:-}" "${PAYLOAD:-}"
	exit 0
fi

case "$ACTION" in
taskStatus)
	system_luci_emit_task_status
	exit 0
	;;
status)
	sh "$STATUS_SH" --status
	;;
hardwareStatus)
	printf '=== Статус оборудования и аппаратных кнопок ===\n'
	if [ -f /etc/hotplug.d/button/90-xfree-wps-sync-apply ] && [ -x /etc/hotplug.d/button/90-xfree-wps-sync-apply ]; then
		printf '[✓] Обновление профиля кнопкой WPS/Mesh: ВКЛЮЧЕНО (удержание 3с запускает sync)\n'
	else
		printf '[-] Обновление профиля кнопкой WPS/Mesh: ВЫКЛЮЧЕНО (штатный обработчик OpenWrt)\n'
	fi
	printf '=== NFC_STATUS ===\n'
	system_luci_emit_nfc_status
	printf '=== USB_POWER ===\n'
	if [ -f "$SCRIPT_DIR/hardware/usb-power.sh" ]; then
		sh "$SCRIPT_DIR/hardware/usb-power.sh" status 2>&1 || true
	else
		printf 'usb-power.sh не найден\n'
	fi
	;;
checkUpdate)
	printf '=== Проверка обновлений ===\n'
	sh "$STATUS_SH" --check
	if [ -f "$SCRIPT_DIR/install-luci-app.sh" ]; then
		printf '=== LUCI_APP ===\n'
		_luci_rc=0
		_luci_out="$(sh "$SCRIPT_DIR/install-luci-app.sh" --check-only 2>&1)" || _luci_rc=$?
		_luci_avail="$(printf '%s\n' "$_luci_out" | grep -m1 '^\[\*\] Available' | sed 's/^\[\*\] Available[[:space:]]*:[[:space:]]*//' || true)"
		_luci_upg="$(printf '%s\n' "$_luci_out" | grep -m1 '^\[\*\] Upgradable' | awk '{print $NF}' || true)"
		_luci_ver="$(system_luci_app_version)"
		[ -n "$_luci_ver" ] || _luci_ver="unknown"
		case "$_luci_avail" in
		'' | '<none>' | '<unknown>') _luci_avail="" ;;
		esac
		# tar check-only раньше не печатал Upgradable — опираемся и на exit 10.
		if [ "$_luci_upg" = "yes" ] || [ "$_luci_rc" -eq 10 ]; then
			_luci_status="available"
			_luci_label="есть обновление"
		else
			_luci_status="up-to-date"
			_luci_label="актуально"
			_luci_avail=""
		fi
		# Semver guard: feed/available ≤ local → не «обновление».
		if [ "$_luci_status" = "available" ] && [ -n "$_luci_avail" ] && [ -n "$_luci_ver" ]; then
			if [ -f "$ROOT_DIR/lib/install-channel.sh" ]; then
				# shellcheck disable=SC1090
				. "$ROOT_DIR/lib/install-channel.sh" >/dev/null 2>&1 || true
			fi
			if command -v xfree_toolbox_version_ge >/dev/null 2>&1 \
				&& xfree_toolbox_version_ge "$_luci_ver" "$_luci_avail"; then
				_luci_status="up-to-date"
				_luci_label="актуально"
				_luci_avail=""
			fi
		fi
		printf '%s\n' "$_luci_out"
		mkdir -p /etc/xfree-toolbox 2>/dev/null || true
		# Keep deploy stamp in sync with resolved version.
		printf '%s\n' "$_luci_ver" > /etc/xfree-toolbox/luci-app.version 2>/dev/null || true
		cat <<EOF > /etc/xfree-toolbox/.luci-status.cache
LUCI_VERSION=$_luci_ver
LUCI_UPDATE=$_luci_status
LUCI_UPDATE_LABEL=$_luci_label
LUCI_AVAILABLE=$_luci_avail
EOF
		cat /etc/xfree-toolbox/.luci-status.cache
	fi
	;;
upgrade)
	printf '=== Обновление xfree-toolbox ===\n'
	sh "$STATUS_SH" --upgrade
	;;
upgradeLuci)
	printf '=== Обновление luci-app-xfree-toolbox ===\n'
	if [ -f "$SCRIPT_DIR/install-luci-app.sh" ]; then
		sh "$SCRIPT_DIR/install-luci-app.sh" --auto
	else
		sh "$SCRIPT_DIR/update-luci.sh" --scope luci --auto
	fi
	;;
installBase)
	printf '=== Установка / обновление базовых пакетов ===\n'
	sh "$SCRIPT_DIR/install.sh"
	;;
installLuciRu)
	printf '=== Установка русской локализации LuCI ===\n'
	sh "$SCRIPT_DIR/install-luci-i18n-ru.sh"
	;;
updateLuci)
	printf '=== Обновление LuCI ===\n'
	sh "$SCRIPT_DIR/update-luci.sh" --scope luci --auto
	;;
updateAll)
	printf '=== Обновление всех системных пакетов ===\n'
	sh "$SCRIPT_DIR/update-luci.sh" --scope all --auto
	;;
checkMigration)
	printf '=== Проверка миграции ===\n'
	sh "$SCRIPT_DIR/check-migration.sh"
	;;
backupRotate)
	printf '=== Принудительная ротация backup ===\n'
	sh "$SCRIPT_DIR/backup-maintenance.sh" --action rotate --apply
	;;
backupCleanup)
	printf '=== Чистка устаревших backup ===\n'
	sh "$SCRIPT_DIR/backup-maintenance.sh" --action cleanup --apply
	;;
backupPurge)
	printf '=== Полная очистка backup ===\n'
	sh "$SCRIPT_DIR/backup-maintenance.sh" --action purge --apply
	;;
wpsButtonEnable)
	printf '=== Включение обновления профиля по кнопке ===\n'
	sh "$SCRIPT_DIR/hardware/install-button-hooks.sh" --install "$ROOT_DIR"
	;;
wpsButtonDisable)
	printf '=== Выключение обновления профиля по кнопке ===\n'
	sh "$SCRIPT_DIR/hardware/install-button-hooks.sh" --remove
	;;
writeNfc)
	printf '=== Запись NFC (Wi-Fi 5 GHz) ===\n'
	if ! system_luci_nfc_board_supported; then
		printf 'Запись NFC недоступна на этой плате: %s (см. xinfc/boards.tsv)\n' "$(system_luci_nfc_board_name)"
		exit 1
	fi
	if [ -f "$ROOT_DIR/xinfc/write-nfc-5g.sh" ]; then
		sh "$ROOT_DIR/xinfc/write-nfc-5g.sh" --yes
	else
		printf 'Скрипт write-nfc-5g.sh не найден\n'
		exit 1
	fi
	;;
usbPowerCycle)
	printf '=== Перезагрузка USB по питанию ===\n'
	if [ -f "$SCRIPT_DIR/hardware/usb-power.sh" ]; then
		sh "$SCRIPT_DIR/hardware/usb-power.sh" cycle 8 5 auto
	else
		printf 'usb-power.sh не найден\n'
	fi
	;;
usbPowerTest)
	printf '=== Тестирование питания USB ===\n'
	if [ -f "$SCRIPT_DIR/hardware/usb-power.sh" ]; then
		sh "$SCRIPT_DIR/hardware/usb-power.sh" test 8 5
	else
		printf 'usb-power.sh не найден\n'
	fi
	;;
installWpadMesh)
	printf '=== Установка wpad-mesh-mbedtls (802.11s) ===\n'
	sh "$SCRIPT_DIR/install-wpad-mesh.sh"
	;;
configureMeshMaster)
	printf '=== Настройка Mesh Master ===\n'
	sh "$SCRIPT_DIR/configure-mesh.sh" --action master --yes
	;;
configureMeshBackhaul)
	printf '=== Настройка 802.11s Mesh Backhaul ===\n'
	sh "$SCRIPT_DIR/configure-mesh.sh" --action mesh-setup --yes
	;;
disableMeshBackhaul)
	printf '=== Отключение 802.11s Mesh Backhaul (кабельный режим) ===\n'
	sh "$SCRIPT_DIR/configure-mesh.sh" --action mesh-disable --yes
	;;
configureMeshRoaming)
	printf '=== Настройка Fast Roaming (802.11r/k/v) ===\n'
	_domain="$(printf '%s' "$ARG" | awk '{print $1}')"
	_ifaces="$(printf '%s' "$ARG" | awk '{print $2}')"
	_cmd="sh \"$SCRIPT_DIR/configure-mesh.sh\" --action roaming-setup --yes"
	[ -n "$_domain" ] && _cmd="$_cmd --mobility-domain \"$_domain\""
	[ -n "$_ifaces" ] && _cmd="$_cmd --ifaces \"$_ifaces\""
	eval "$_cmd"
	;;
disableMeshRoaming)
	printf '=== Отключение Fast Roaming ===\n'
	_ifaces="$(printf '%s' "$ARG" | awk '{print $1}')"
	if [ -n "$_ifaces" ]; then
		sh "$SCRIPT_DIR/configure-mesh.sh" --action roaming-disable --ifaces "$_ifaces" --yes
	else
		sh "$SCRIPT_DIR/configure-mesh.sh" --action roaming-disable --yes
	fi
	;;
configureMeshSatellite)
	printf '=== Настройка Mesh Satellite ===\n'
	_gw="$(printf '%s' "$ARG" | awk '{print $1}')"
	_lan_ip="$(printf '%s' "$ARG" | awk '{print $2}')"
	_ssid="$(printf '%s' "$ARG" | awk '{print $3}')"
	_key="$(printf '%s' "$ARG" | awk '{$1=""; $2=""; $3=""; sub(/^[ \t]+/, ""); print}')"

	[ -n "$_gw" ] || _gw="192.168.1.1"
	[ -n "$_lan_ip" ] || _lan_ip="192.168.1.2"
	[ -n "$_ssid" ] || _ssid="OpenWrt"

	case "$_ssid" in
		*-5G|*_5G|*-5g|*_5g)
			_s5="$_ssid"
			_s2="${_ssid%[_-][55][Gg]}"
			;;
		*-2.4G|*_2.4G|*-2.4g|*_2.4g)
			_s2="$_ssid"
			_s5="${_ssid%[_-]2.4[Gg]}_5G"
			;;
		*)
			_s2="$_ssid"
			_s5="${_ssid}_5G"
			;;
	esac

	sh "$SCRIPT_DIR/configure-mesh.sh" --action satellite --yes \
		--gateway "$_gw" --lan-ip "$_lan_ip" \
		--ssid-5g "$_s5" --key-5g "$_key" \
		--ssid-2g "$_s2" --key-2g "$_key" \
		--channel-5g 36
	;;
meshDiag)
	printf '=== Диагностика связности Mesh / Backhaul ===\n'
	sh "$SCRIPT_DIR/test-mesh-connectivity.sh"
	;;
meshStatus)
	_wpad_mesh=0
	if command -v apk >/dev/null 2>&1; then
		apk info -e wpad-mesh-mbedtls >/dev/null 2>&1 && _wpad_mesh=1
	elif command -v opkg >/dev/null 2>&1; then
		opkg list-installed wpad-mesh-mbedtls 2>/dev/null | grep -q '^wpad-mesh-mbedtls' && _wpad_mesh=1
	fi

	_mesh_if=""
	_mesh_id=""
	_mobility_domain=""
	_channel_5g=""
	_mesh_disabled=0

	for s in $(uci -q show wireless 2>/dev/null | awk -F. '/\.mode=.mesh/{print $2}' | sort -u); do
		_mesh_if="$s"
		_mesh_id="$(uci -q get "wireless.$s.mesh_id" 2>/dev/null || true)"
		_dis="$(uci -q get "wireless.$s.disabled" 2>/dev/null || echo 0)"
		[ "$_dis" = "1" ] && _mesh_disabled=1
		break
	done

	for s in $(uci -q show wireless 2>/dev/null | awk -F. '/\.mobility_domain=/{print $2}' | sort -u); do
		_mobility_domain="$(uci -q get "wireless.$s.mobility_domain" 2>/dev/null || true)"
		[ -n "$_mobility_domain" ] && break
	done

	_channel_5g="$(uci -q get wireless.radio1.channel 2>/dev/null || uci -q get wireless.default_radio1.channel 2>/dev/null || true)"

	_stp=0
	[ -f /sys/class/net/br-lan/bridge/stp_state ] && [ "$(cat /sys/class/net/br-lan/bridge/stp_state 2>/dev/null)" = "1" ] && _stp=1
	[ "$_stp" = "0" ] && [ "$(uci -q get network.lan.stp 2>/dev/null)" = "1" ] && _stp=1

	_role="standalone"
	if [ -n "$_mesh_if" ] && [ "$_mesh_disabled" != "1" ]; then
		if [ "$(uci -q get dhcp.lan.ignore 2>/dev/null)" = "1" ]; then
			_role="satellite"
		else
			_role="master"
		fi
	fi

	_has_m_int=0
	[ -n "$_mesh_if" ] && _has_m_int=1

	# Собираем список AP интерфейсов
	_if_json=""
	for _if in $(uci -q show wireless 2>/dev/null | awk -F. '/\.mode=.ap/{print $2}' | sort -u); do
		_d="$(uci -q get "wireless.$_if.device" 2>/dev/null || true)"
		_b="$(uci -q get "wireless.$_d.band" 2>/dev/null || true)"
		if [ -z "$_b" ]; then
			_ht="$(uci -q get "wireless.$_d.htmode" 2>/dev/null || true)"
			case "$_ht" in
				*VHT*|*HE*|*EHT*) _b="5 GHz" ;;
				*) _b="2.4 GHz" ;;
			esac
		else
			case "$_b" in
				2.4g|2g|2ghz) _b="2.4 GHz" ;;
				5g|5ghz) _b="5 GHz" ;;
			esac
		fi

		_ssid="$(uci -q get "wireless.$_if.ssid" 2>/dev/null || true)"
		_net="$(uci -q get "wireless.$_if.network" 2>/dev/null || true)"
		_dis="$(uci -q get "wireless.$_if.disabled" 2>/dev/null || echo 0)"
		[ "$_dis" = "1" ] || _dis=0
		_r11r="$(uci -q get "wireless.$_if.ieee80211r" 2>/dev/null || echo 0)"
		[ "$_r11r" = "1" ] || _r11r=0
		_mob="$(uci -q get "wireless.$_if.mobility_domain" 2>/dev/null || true)"

		_entry="{\"section\":\"$_if\",\"device\":\"$_d\",\"band\":\"$_b\",\"ssid\":\"$_ssid\",\"network\":\"$_net\",\"disabled\":$_dis,\"ftEnabled\":$_r11r,\"mobilityDomain\":\"$_mob\"}"
		if [ -z "$_if_json" ]; then
			_if_json="$_entry"
		else
			_if_json="$_if_json,$_entry"
		fi
	done

	printf '{"code":0,"hasWpadMesh":%d,"hasMeshIf":%d,"meshDisabled":%d,"meshId":"%s","mobilityDomain":"%s","channel5g":"%s","stp":%d,"role":"%s","interfaces":[%s]}\n' \
		"$_wpad_mesh" \
		"$_has_m_int" \
		"$_mesh_disabled" \
		"$_mesh_id" \
		"$_mobility_domain" \
		"$_channel_5g" \
		"$_stp" \
		"$_role" \
		"$_if_json"
	;;
maintenanceStatus)
	printf '=== BACKUPS ===\n'
	_bk_dir="/etc/xfree-toolbox/backups"
	_bk_size="0"
	_bk_count=0
	if [ -d "$_bk_dir" ]; then
		_bk_size="$(du -sh "$_bk_dir" 2>/dev/null | awk '{print $1}' || echo "0")"
		_bk_count="$(find "$_bk_dir" -mindepth 1 -maxdepth 2 2>/dev/null | wc -l || echo "0")"
	fi
	printf 'BACKUP_DIR=%s\n' "$_bk_dir"
	printf 'BACKUP_SIZE=%s\n' "$_bk_size"
	printf 'BACKUP_COUNT=%s\n' "$_bk_count"
	printf 'BACKUP_KEEP=%s\n' "${BACKUP_KEEP:-3}"
	printf '=== BASE_PACKAGES ===\n'
	_missing_pkgs=""
	if [ -f "$SCRIPT_DIR/base-packages.sh" ] && [ -f "$SCRIPT_DIR/lib/base-packages-check.sh" ]; then
		# shellcheck disable=SC1090
		[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh" >/dev/null 2>&1 || true
		# shellcheck disable=SC1090
		[ -f "$ROOT_DIR/lib/pkgmgr.sh" ] && . "$ROOT_DIR/lib/pkgmgr.sh" >/dev/null 2>&1 || true
		# shellcheck disable=SC1090
		. "$SCRIPT_DIR/base-packages.sh" >/dev/null 2>&1 || true
		# shellcheck disable=SC1090
		. "$SCRIPT_DIR/lib/base-packages-check.sh" >/dev/null 2>&1 || true
		if command -v list_missing_base_packages >/dev/null 2>&1; then
			_missing_pkgs="$(list_missing_base_packages 2>/dev/null | tr '\n' ' ' | sed 's/[[:space:]]*$//' || true)"
		fi
	fi
	_luci_ru=0
	if command -v pm_is_installed >/dev/null 2>&1; then
		pm_is_installed luci-i18n-base-ru && _luci_ru=1
	elif apk info -e luci-i18n-base-ru >/dev/null 2>&1 || opkg list-installed luci-i18n-base-ru 2>/dev/null | grep -q .; then
		_luci_ru=1
	fi
	printf 'MISSING_PACKAGES=%s\n' "$_missing_pkgs"
	printf 'LUCI_RU_INSTALLED=%d\n' "$_luci_ru"
	printf '=== MIGRATIONS ===\n'
	_state_ok=1
	[ -d "/etc/xfree-toolbox" ] || _state_ok=0
	printf 'STATE_DIR_OK=%d\n' "$_state_ok"
	;;
autoUpdateStatus)
	if [ -f "$STATUS_SH" ]; then
		sh "$STATUS_SH" --status 2>/dev/null || true
	fi
	printf '=== LUCI_APP ===\n'
	if [ -f "$SCRIPT_DIR/install-luci-app.sh" ]; then
		if [ -f /etc/xfree-toolbox/.luci-status.cache ]; then
			cat /etc/xfree-toolbox/.luci-status.cache 2>/dev/null || true
		else
			_luci_ver="$(system_luci_app_version)"
			[ -n "$_luci_ver" ] || _luci_ver="unknown"
			printf 'LUCI_VERSION=%s\n' "$_luci_ver"
			printf 'LUCI_UPDATE=unknown\n'
			printf 'LUCI_UPDATE_LABEL=не проверено\n'
			printf 'LUCI_AVAILABLE=\n'
		fi
	fi
	printf '=== AUTO_UPDATE ===\n'
	# shellcheck disable=SC1091
	[ -f "$SCRIPT_DIR/auto-update-lib.sh" ] && . "$SCRIPT_DIR/auto-update-lib.sh"
	sh "$SCRIPT_DIR/auto-update-cron.sh" status
	_running=0
	[ -f /tmp/xfree-auto-update.once ] && _running=1
	printf 'RUNNING=%d\n' "$_running"
	_log="$(auto_update_log_path 2>/dev/null || echo /etc/xfree-toolbox/system/auto-update.log)"
	if [ -f "$_log" ]; then
		_last_line="$(grep -E '^(start|done|error):' "$_log" 2>/dev/null | tail -n 1 || true)"
		printf 'LAST_LOG_LINE=%s\n' "$_last_line"
		_last_mod="$(date -r "$_log" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || stat -c '%y' "$_log" 2>/dev/null || true)"
		printf 'LAST_LOG_DATE=%s\n' "$_last_mod"
	else
		printf 'LAST_LOG_LINE=\n'
		printf 'LAST_LOG_DATE=\n'
	fi
	printf '=== APK_FEED ===\n'
	sh "$SCRIPT_DIR/apk-feed.sh" status
	;;
autoUpdateSave)
	printf '=== Сохранение настроек автообновления ===\n'
	# shellcheck disable=SC1091
	. "$SCRIPT_DIR/auto-update-lib.sh"
	_en=""
	_mode=""
	_hour=""
	_min=""
	if [ -n "$ARG" ]; then
		_en="$(printf '%s' "$ARG" | cut -d'|' -f1)"
		_mode="$(printf '%s' "$ARG" | cut -d'|' -f2)"
		_hour="$(printf '%s' "$ARG" | cut -d'|' -f3)"
		_min="$(printf '%s' "$ARG" | cut -d'|' -f4)"
	fi
	if [ -z "$_en" ] && [ -n "$PAYLOAD" ]; then
		_en="$(printf '%s' "$PAYLOAD" | sed -n 's/.*"enabled"[[:space:]]*:[[:space:]]*"\?\([0-9]\+\)"\?.*/\1/p')"
		_mode="$(printf '%s' "$PAYLOAD" | sed -n 's/.*"mode"[[:space:]]*:[[:space:]]*"\?\([a-zA-Z0-9_-]\+\)"\?.*/\1/p')"
		_hour="$(printf '%s' "$PAYLOAD" | sed -n 's/.*"hour"[[:space:]]*:[[:space:]]*"\?\([0-9]\+\)"\?.*/\1/p')"
		_min="$(printf '%s' "$PAYLOAD" | sed -n 's/.*"minute"[[:space:]]*:[[:space:]]*"\?\([0-9]\+\)"\?.*/\1/p')"
	fi
	_conf="$(auto_update_conf_path)"
	[ -n "$_en" ] || _en="1"
	[ -n "$_mode" ] || _mode="upstreams-lists-package"
	[ -n "$_hour" ] || _hour="2"
	[ -n "$_min" ] || _min="0"

	auto_update_conf_kv_set "$_conf" ENABLED "$_en"
	auto_update_conf_kv_set "$_conf" MODE "$_mode"
	auto_update_conf_kv_set "$_conf" SCHEDULE_HOUR "$_hour"
	auto_update_conf_kv_set "$_conf" SCHEDULE_MINUTE "$_min"

	if [ "$_en" = "1" ]; then
		sh "$SCRIPT_DIR/auto-update-cron.sh" install
	else
		sh "$SCRIPT_DIR/auto-update-cron.sh" remove
	fi
	printf '[+] Настройки сохранены (ENABLED=%s, MODE=%s, SCHEDULE=%02d:%02d)\n' "$_en" "$_mode" "$_hour" "$_min"
	;;
autoUpdateRunNow)
	printf '=== Запуск автообновления вручную ===\n'
	# shellcheck disable=SC1091
	[ -f "$SCRIPT_DIR/auto-update-lib.sh" ] && . "$SCRIPT_DIR/auto-update-lib.sh"
	_bg="$ROOT_DIR/lib/bg-task-run.sh"
	_run="$SCRIPT_DIR/auto-update-run.sh"
	_log="$(auto_update_log_path 2>/dev/null || echo /etc/xfree-toolbox/system/auto-update.log)"
	if [ -f "$_bg" ] && [ -f "$_run" ]; then
		sh "$_bg" auto-update --log "$_log" -- /bin/sh "$_run" --force
		printf '[+] Фоновое обновление запущено (лог: %s)\n' "$_log"
	else
		printf '[-] Скрипты запуска не найдены\n'
		exit 1
	fi
	;;
autoUpdateLog)
	printf '=== Журнал автообновления ===\n'
	# shellcheck disable=SC1091
	[ -f "$SCRIPT_DIR/auto-update-lib.sh" ] && . "$SCRIPT_DIR/auto-update-lib.sh"
	_log="$(auto_update_log_path 2>/dev/null || echo /etc/xfree-toolbox/system/auto-update.log)"
	if [ -f /tmp/xfree-auto-update.once ] || pidof -s auto-update-run.sh >/dev/null 2>&1; then
		printf '[*] Внимание: процесс автообновления сейчас активен в фоне...\n\n'
	fi
	if [ -f "$_log" ] && [ -s "$_log" ]; then
		tail -n 250 "$_log"
	elif [ -f "$_log" ]; then
		printf 'Файл журнала (%s) пуст.\n' "$_log"
		printf 'Автообновление ещё не выполнялось по расписанию.\n'
		printf 'Нажмите «Запустить сейчас», чтобы выполнить тестовый запуск и наполнить журнал.\n'
	else
		printf 'Файл журнала (%s) ещё не создан.\n' "$_log"
		printf 'Нажмите «Запустить сейчас» для первого запуска.\n'
	fi
	;;
autoUpdateEnable)
	printf '=== Включение автообновления ===\n'
	sh "$SCRIPT_DIR/auto-update-cron.sh" install
	;;
autoUpdateDisable)
	printf '=== Выключение автообновления ===\n'
	sh "$SCRIPT_DIR/auto-update-cron.sh" remove
	;;
apkFeedEnable)
	printf '=== Включение APK-фида xfree ===\n'
	sh "$SCRIPT_DIR/apk-feed.sh" enable
	;;
apkFeedDisable)
	printf '=== Выключение APK-фида xfree ===\n'
	sh "$SCRIPT_DIR/apk-feed.sh" disable
	;;
apkFeedSetSource)
	_src="${ARG:-github}"
	printf '=== Смена источника APK-фида на %s ===\n' "$_src"
	sh "$SCRIPT_DIR/apk-feed.sh" source "$_src"
	;;
apkFeedFailover)
	printf '=== Проверка и переключение зеркала фида ===\n'
	sh "$SCRIPT_DIR/apk-feed.sh" failover
	;;
apkUpdate)
	printf '=== Обновление каталога пакетов (apk update) ===\n'
	if command -v apk >/dev/null 2>&1; then
		apk update
	else
		printf 'Команда apk не найдена\n'
	fi
	;;
modemDiag)
	printf '=== Диагностика USB-модема ===\n'
	if [ -f "$SCRIPT_DIR/modem/diagnostics.sh" ]; then
		sh "$SCRIPT_DIR/modem/diagnostics.sh"
	else
		printf 'Скрипт диагностики модема не найден\n'
	fi
	;;
modemHilink)
	printf '=== Установка пакетов HiLink ===\n'
	sh "$SCRIPT_DIR/modem/packages.sh" hilink-setup
	;;
modemLteIface)
	printf '=== Создание WAN-интерфейса lte ===\n'
	sh "$SCRIPT_DIR/modem/configure-hilink-wan.sh"
	;;
modemRecommended)
	printf '=== Установка рекомендуемого набора пакетов модема ===\n'
	sh "$SCRIPT_DIR/modem/packages.sh" recommended-setup
	;;
telemtStatus)
	if [ -f "$ROOT_DIR/telemt/status.sh" ]; then
		sh "$ROOT_DIR/telemt/status.sh"
	elif [ -f "$ROOT_DIR/telemt/ensure-telemt.sh" ]; then
		sh "$ROOT_DIR/telemt/ensure-telemt.sh" --status
	fi
	;;
telemtCheckUpdate)
	if [ -f "$ROOT_DIR/telemt/status.sh" ]; then
		sh "$ROOT_DIR/telemt/status.sh" --check-updates
	fi
	;;
telemtInstall)
	printf '=== Установка Telemt MTProxy ===\n'
	if [ -f "$ROOT_DIR/telemt/install-telemt-release.sh" ]; then
		sh "$ROOT_DIR/telemt/install-telemt-release.sh"
	elif [ -f "$ROOT_DIR/telemt/ensure-telemt.sh" ]; then
		sh "$ROOT_DIR/telemt/ensure-telemt.sh" --install-if-missing
	fi
	;;
telemtUpgrade)
	printf '=== Обновление Telemt MTProxy ===\n'
	if [ -f "$ROOT_DIR/telemt/install-telemt-release.sh" ]; then
		sh "$ROOT_DIR/telemt/install-telemt-release.sh" --upgrade --force
	fi
	;;
telemtService)
	cmd="${2:-status}"
	case "$cmd" in
		start|stop|restart|enable|disable)
			if [ -x /etc/init.d/telemt ]; then
				/etc/init.d/telemt "$cmd"
			else
				printf 'init-скрипт /etc/init.d/telemt не найден\n'
			fi
			;;
		*)
			printf 'Неизвестная команда сервиса: %s\n' "$cmd"
			;;
	esac
	;;
vkturnStatus)
	printf '=== Статус VK-Turn Proxy ===\n'
	if [ -f "$ROOT_DIR/vk-turn/status.sh" ]; then
		sh "$ROOT_DIR/vk-turn/status.sh"
	fi
	;;
vkturnSetup)
	printf '=== Настройка VK-Turn Proxy ===\n'
	if [ -f "$ROOT_DIR/vk-turn/setup-server.sh" ]; then
		sh "$ROOT_DIR/vk-turn/setup-server.sh"
	fi
	;;
mgmtStatus)
	if [ -f "$ROOT_DIR/mgmt-hub/router/status.sh" ]; then
		sh "$ROOT_DIR/mgmt-hub/router/status.sh"
	else
		printf 'Скрипт status.sh не найден\n'
	fi
	;;
mgmtEnable)
	printf '=== Включение mgmt-hub ===\n'
	if [ -f "$ROOT_DIR/mgmt-hub/router/apply-client.sh" ]; then
		sh "$ROOT_DIR/mgmt-hub/router/apply-client.sh" --enable
	else
		printf 'Скрипт apply-client.sh не найден\n'
	fi
	;;
mgmtDisable)
	printf '=== Отключение mgmt-hub ===\n'
	if [ -f "$ROOT_DIR/mgmt-hub/router/apply-client.sh" ]; then
		sh "$ROOT_DIR/mgmt-hub/router/apply-client.sh" --disable
	else
		printf 'Скрипт apply-client.sh не найден\n'
	fi
	;;
mgmtConnect)
	printf '=== Подключение к XFree Hub (mgmt-hub) ===\n'
	if [ -f "$ROOT_DIR/mgmt-hub/router/ensure-client.sh" ]; then
		sh "$ROOT_DIR/mgmt-hub/router/ensure-client.sh"
	else
		printf 'Скрипт ensure-client.sh не найден\n'
	fi
	;;
upstreamsUpdateApply)
	printf '=== Обновление и применение источников ===\n'
	run_upstreams_handler update_selected_modules
	run_upstreams_handler check_active_list_updates 1
	;;
upstreamsUpdateActive)
	printf '=== Обновление активных источников ===\n'
	run_upstreams_handler update_selected_modules
	;;
upstreamsApply)
	printf '=== Применение обновлений источников ===\n'
	run_upstreams_handler check_active_list_updates 1
	;;
upstreamsReindex)
	printf '=== Переиндексация источников списков ===\n'
	if [ -f "$ROOT_DIR/lib/upstreams.sh" ]; then
		# shellcheck disable=SC1091
		. "$ROOT_DIR/lib/upstreams.sh"
		upstreams_reindex_sources "$ROOT_DIR" 2>/dev/null || true
	fi
	printf 'OK: индекс обновлён\n'
	;;
systemStartBg)
	_task_name="${ARG:-}"
	[ -n "$_task_name" ] || _task_name="updateAll"
	_log="/tmp/xfree-background-tasks/system-action.log"
	mkdir -p "/tmp/xfree-background-tasks" 2>/dev/null || true

	# shellcheck disable=SC1090
	[ -f "$ROOT_DIR/lib/background-tasks.sh" ] && . "$ROOT_DIR/lib/background-tasks.sh"
	if bg_tasks_is_running 2>/dev/null; then
		set +u
		[ -f /usr/share/libubox/jshn.sh ] && . /usr/share/libubox/jshn.sh
		json_init
		json_add_int code 1
		json_add_int running 1
		json_add_string error "Другая фоновая задача уже выполняется: ${BG_TASK_NAME:-task}"
		json_dump
		exit 0
	fi

	rm -f "$_log" 2>/dev/null || true
	_runner="$ROOT_DIR/lib/bg-task-run.sh"
	(
		export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
		sh "$_runner" "system" --log "$_log" -- \
			sh "$SCRIPT_DIR/luci-rpc.sh" "$_task_name" "$PAYLOAD"
	) >/dev/null 2>&1 &

	sleep 1
	action_system_bg_status
	exit 0
	;;
systemBgStatus)
	action_system_bg_status
	exit 0
	;;
*)
	printf 'unknown systemMenu action: %s\n' "${ACTION:-?}" >&2
	exit 1
	;;
esac
