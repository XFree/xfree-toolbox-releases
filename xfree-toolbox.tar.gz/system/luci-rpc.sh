#!/bin/sh
# shellcheck shell=sh
# Non-interactive system actions for LuCI (ubus xfree-toolbox systemMenu).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
STATUS_SH="$SCRIPT_DIR/toolbox-status.sh"

ACTION="${1:-}"

case "$ACTION" in
status)
	sh "$STATUS_SH" --status
	;;
checkUpdate)
	printf '=== Проверка обновлений ===\n'
	sh "$STATUS_SH" --check
	;;
upgrade)
	printf '=== Обновление xfree-toolbox ===\n'
	sh "$STATUS_SH" --upgrade
	;;
*)
	printf 'unknown systemMenu action: %s\n' "${ACTION:-?}" >&2
	exit 1
	;;
esac
