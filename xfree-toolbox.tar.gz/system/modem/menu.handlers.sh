#!/bin/sh
# Hand-written handlers for cli.run component=custom in system/modem/menu.yaml.
# shellcheck shell=sh

MODEM_DIAG_SCRIPT="$SCRIPT_DIR/diagnostics.sh"
MODEM_INSTALL_SCRIPT="$SCRIPT_DIR/install.sh"
MODEM_CONFIGURE_WAN_SCRIPT="$SCRIPT_DIR/configure-hilink-wan.sh"

run_log() { ui_menu_invoke_with_output "$@"; }
run_script() { ui_menu_invoke_script_relaxed "$@"; }

show_modem_diagnostics() {
	report_file="${UI_TMP_ROOT:-/tmp}/xfree-modem-diagnostics.$$"
	if sh "$MODEM_DIAG_SCRIPT" --out "$report_file" 2>/dev/null; then
		:
	else
		printf '%s\n' "Не удалось собрать отчёт ($MODEM_DIAG_SCRIPT)." >"$report_file"
	fi
	ui_show_textbox "Диагностика USB-модема" "$report_file" 32 96
	rm -f "$report_file" 2>/dev/null || true
}

show_packages_reference() {
	report_file="${UI_TMP_ROOT:-/tmp}/xfree-modem-packages-ref.$$"
	: >"$report_file"
	modem_pkg_print_sets_reference >>"$report_file"
	ui_show_textbox "Наборы пакетов (справка)" "$report_file" 32 96
	rm -f "$report_file" 2>/dev/null || true
}

install_preset_confirm() {
	preset="$1"
	label="$(modem_pkg_set_label "$preset")"
	purpose="$(modem_pkg_set_purpose "$preset")"
	if ui_confirm "Установить: $label" \
"Назначение:
$purpose

Команда:
$(modem_pkg_format_install_cmd "$preset")

Уже установленные пакеты будут пропущены.
После установки — reboot и снова диагностика.

Продолжить?"; then
		run_log "Установка: $label" sh "$MODEM_INSTALL_SCRIPT" --preset "$preset"
	fi
}

install_hilink_e3372_setup() {
	install_preset_confirm "hilink-setup"
}

configure_hilink_wan_interface() {
	if ! command -v uci >/dev/null 2>&1; then
		ui_msgbox "Создать интерфейс LTE" "uci не найден. Скрипт выполняется на роутере с OpenWrt."
		return 0
	fi

	modem_lib_guess_hilink_device || true
	_dev="${MODEM_HILINK_DEVICE:-eth1}"
	_driver="$(modem_lib_net_driver_name "$_dev" 2>/dev/null || true)"

	if ui_confirm "Создать интерфейс LTE (HiLink)" \
"Будет создан UCI-интерфейс lte:
  proto = dhcp
  device = $_dev (драйвер: ${_driver:-авто})
  firewall → зона wan

Затем: ifup lte

APN и сигнал — http://192.168.8.1

Продолжить?"; then
		run_log "Создание интерфейса lte (HiLink)" sh "$MODEM_CONFIGURE_WAN_SCRIPT" --apply
	fi
}

install_recommended_set() {
	modem_detect_run
	modem_detect_recommended_presets
	primary="${MODEM_DETECT_PRIMARY_PRESET:-}"

	if [ -z "$primary" ]; then
		ui_msgbox "Установка набора" "Для режима «$(modem_detect_mode_label)» автоматический набор не задан.

Подключите модем и запустите диагностику, либо выберите набор вручную в меню «Установить набор пакетов»."
		return 0
	fi

	label="$(modem_pkg_set_label "$primary")"
	purpose="$(modem_pkg_set_purpose "$primary")"
	cmd="$(modem_pkg_format_install_cmd "$primary")"

	if ui_confirm "Установить рекомендуемый набор" \
"Режим: $(modem_detect_mode_label)
Набор: $label

Назначение:
$purpose

Будет выполнено:
$cmd

Продолжить?"; then
		run_log "Установка: $label" sh "$MODEM_INSTALL_SCRIPT" --recommended
	fi
}

install_preset_menu() {
	while true; do
		choice="$(ui_menu "Установить набор пакетов" "Набор пакетов (opkg/apk)." 22 78 12 \
			"rec" "★ Рекомендуемый (по текущей диагностике)" \
			"hilink-setup" "$(modem_pkg_set_menu_blurb hilink-setup)" \
			"usb-foundation" "$(modem_pkg_set_menu_blurb usb-foundation)" \
			"hilink-min" "$(modem_pkg_set_menu_blurb hilink-min)" \
			"hilink-rec" "$(modem_pkg_set_menu_blurb hilink-rec)" \
			"qmi-wiki" "$(modem_pkg_set_menu_blurb qmi-wiki)" \
			"qmi-extra" "$(modem_pkg_set_menu_blurb qmi-extra)" \
			"mbim-wiki" "$(modem_pkg_set_menu_blurb mbim-wiki)" \
			"mbim-extra" "$(modem_pkg_set_menu_blurb mbim-extra)" \
			"ncm-wiki" "$(modem_pkg_set_menu_blurb ncm-wiki)" \
			"0" "Назад" || true)"

		[ -n "${choice:-}" ] || return 0

		case "$choice" in
			0) return 0 ;;
			rec)
				install_recommended_set
				;;
			hilink-setup|usb-foundation|hilink-min|hilink-rec|qmi-wiki|qmi-extra|mbim-wiki|mbim-extra|ncm-wiki)
				install_preset_confirm "$choice"
				;;
		esac
	done
}

modem_menu_choice_1() { show_modem_diagnostics; }
modem_menu_choice_2() { install_hilink_e3372_setup; }
modem_menu_choice_3() { configure_hilink_wan_interface; }
modem_menu_choice_4() { install_recommended_set; }
modem_menu_choice_5() { install_preset_menu; }
modem_menu_choice_6() { show_packages_reference; }
