#!/bin/sh
# shellcheck shell=sh
# Наборы пакетов для USB-модемов (см. OpenWrt WWAN wiki).

# HiLink / CDC-Ethernet (Huawei E3372h-320 и аналоги)
MODEM_PKG_HILINK_MIN="kmod-usb-net-cdc-ether"
MODEM_PKG_HILINK_REC="${MODEM_PKG_HILINK_MIN} usb-modeswitch"

# QMI / MBIM — sample installation из ltedongle
MODEM_PKG_QMI_WIKI="kmod-usb-net-qmi-wwan uqmi luci-proto-qmi kmod-usb-serial-option picocom"
MODEM_PKG_MBIM_WIKI="kmod-usb-net-cdc-mbim umbim luci-proto-mbim kmod-usb-serial-option picocom"

# Расширения (не в минимальном sample wiki, но полезны на OpenWrt)
MODEM_PKG_QMI_EXTRA="wwan usb-modeswitch"
MODEM_PKG_MBIM_EXTRA="wwan usb-modeswitch"

# NCM (отдельная ветка wiki, не ltedongle)
MODEM_PKG_NCM_WIKI="kmod-usb-net-cdc-ncm comgt-ncm wwan luci-proto-ncm usb-modeswitch"

# Доп. USB для модема (не host: kmod-usb-core/usb3 обычно уже в образе)
MODEM_PKG_USB_FOUNDATION="kmod-usb-storage usbutils"

# Полная подготовка HiLink (E3372h-320): USB + cdc-ether + modeswitch
MODEM_PKG_HILINK_SETUP="${MODEM_PKG_USB_FOUNDATION} ${MODEM_PKG_HILINK_REC}"

MODEM_PKG_ALL_PRESETS="usb-foundation hilink-setup hilink-min hilink-rec qmi-wiki qmi-extra mbim-wiki mbim-extra ncm-wiki"

modem_pkg_set_label() {
    preset="$1"
    case "$preset" in
        usb-foundation) printf '%s' "USB: storage + usbutils" ;;
        hilink-setup) printf '%s' "HiLink E3372 — полная подготовка (USB + модем)" ;;
        hilink-min) printf '%s' "HiLink / CDC-Ethernet (минимум)" ;;
        hilink-rec) printf '%s' "HiLink / CDC-Ethernet (рекомендуется)" ;;
        qmi-wiki)   printf '%s' "QMI (OpenWrt ltedongle — sample)" ;;
        qmi-extra)  printf '%s' "QMI + wwan + usb-modeswitch" ;;
        mbim-wiki)  printf '%s' "MBIM (OpenWrt ltedongle — sample)" ;;
        mbim-extra) printf '%s' "MBIM + wwan + usb-modeswitch" ;;
        ncm-wiki)   printf '%s' "NCM (CDC-NCM, отдельная wiki)" ;;
        *)          printf '%s' "$preset" ;;
    esac
}

# Краткое назначение набора (колонка «для чего» в справке).
modem_pkg_set_purpose() {
    preset="$1"
    case "$preset" in
        usb-foundation)
            printf '%s' "Доп. USB для модема: mass storage (до modeswitch) и lsusb; драйверы host (usb-core/xhci) не ставим — они в образе."
            ;;
        hilink-setup)
            printf '%s' "Huawei E3372h-320: всё для HiLink одной установкой — usb-foundation + cdc-ether + modeswitch; затем reboot."
            ;;
        hilink-min)
            printf '%s' "Huawei E3372h-320 и HiLink: модем как eth*, WAN через DHCP в LuCI; без переключения CD-ROM."
            ;;
        hilink-rec)
            printf '%s' "То же + usb-modeswitch, если модем сначала виден только как флешка (mass storage)."
            ;;
        qmi-wiki)
            printf '%s' "Модемы Qualcomm QMI: /dev/cdc-wdm0, uqmi, интерфейс QMI Cellular в LuCI (wiki sample)."
            ;;
        qmi-extra)
            printf '%s' "QMI sample + hotplug wwan и modeswitch для нестандартного USB-состава."
            ;;
        mbim-wiki)
            printf '%s' "Модемы CDC-MBIM: /dev/cdc-wdm0, umbim, протокол MBIM Cellular в LuCI (wiki sample)."
            ;;
        mbim-extra)
            printf '%s' "MBIM sample + wwan и modeswitch."
            ;;
        ncm-wiki)
            printf '%s' "Часть Huawei/ZTE в режиме CDC-NCM (не типичный HiLink E3372); LuCI luci-proto-ncm."
            ;;
        *)
            printf '%s' "—"
            ;;
    esac
}

# Пояснение отдельного пакета (колонка «что делает»).
modem_pkg_package_role() {
    pkg="$1"
    case "$pkg" in
        kmod-usb-net-cdc-ether)
            printf '%s' "драйвер: модем как сетевой eth* (HiLink)"
            ;;
        kmod-usb-net-qmi-wwan)
            printf '%s' "драйвер ядра QMI (интерфейс wwan, узел cdc-wdm)"
            ;;
        kmod-usb-net-cdc-mbim)
            printf '%s' "драйвер ядра MBIM (cdc-wdm)"
            ;;
        kmod-usb-net-cdc-ncm)
            printf '%s' "драйвер CDC-NCM (Ethernet-over-USB, NCM)"
            ;;
        kmod-usb-serial-option)
            printf '%s' "драйвер serial-портов /dev/ttyUSB* (AT, SMS)"
            ;;
        uqmi)
            printf '%s' "утилита управления QMI (сеть, профиль, сигнал)"
            ;;
        umbim)
            printf '%s' "утилита управления MBIM"
            ;;
        comgt-ncm)
            printf '%s' "скрипты поднятия NCM-соединения (comgt)"
            ;;
        luci-proto-qmi)
            printf '%s' "LuCI: создание WAN «QMI Cellular»"
            ;;
        luci-proto-mbim)
            printf '%s' "LuCI: создание WAN «MBIM Cellular»"
            ;;
        luci-proto-ncm)
            printf '%s' "LuCI: создание WAN NCM"
            ;;
        picocom)
            printf '%s' "терминал для AT-команд на ttyUSB (режим модема)"
            ;;
        usb-modeswitch)
            printf '%s' "переключение USB-состава (CD-ROM → модем)"
            ;;
        wwan)
            printf '%s' "hotplug/скрипты OpenWrt для мобильных интерфейсов"
            ;;
        kmod-usb2)
            printf '%s' "драйвер USB 2.0 host (порт для донгла)"
            ;;
        kmod-usb3)
            printf '%s' "драйвер USB 3.0 host (если порт USB3)"
            ;;
        kmod-usb-storage)
            printf '%s' "режим CD-ROM / mass storage до modeswitch"
            ;;
        usbutils)
            printf '%s' "утилита lsusb (удобная диагностика USB)"
            ;;
        *)
            printf '%s' "пакет из репозитория OpenWrt"
            ;;
    esac
}

modem_pkg_set_list() {
    preset="$1"
    case "$preset" in
        usb-foundation) printf '%s\n' $MODEM_PKG_USB_FOUNDATION ;;
        hilink-setup) printf '%s\n' $MODEM_PKG_HILINK_SETUP ;;
        hilink-min) printf '%s\n' $MODEM_PKG_HILINK_MIN ;;
        hilink-rec) printf '%s\n' $MODEM_PKG_HILINK_REC ;;
        qmi-wiki)   printf '%s\n' $MODEM_PKG_QMI_WIKI ;;
        qmi-extra)  printf '%s\n' $MODEM_PKG_QMI_WIKI $MODEM_PKG_QMI_EXTRA ;;
        mbim-wiki)  printf '%s\n' $MODEM_PKG_MBIM_WIKI ;;
        mbim-extra) printf '%s\n' $MODEM_PKG_MBIM_WIKI $MODEM_PKG_MBIM_EXTRA ;;
        ncm-wiki)   printf '%s\n' $MODEM_PKG_NCM_WIKI ;;
        *)          return 1 ;;
    esac
}

modem_pkg_set_valid() {
    preset="$1"
    for p in $MODEM_PKG_ALL_PRESETS; do
        [ "$p" = "$preset" ] && return 0
    done
    return 1
}

modem_pkg_pm_name() {
    if command -v apk >/dev/null 2>&1; then
        printf 'apk'
    elif command -v opkg >/dev/null 2>&1; then
        printf 'opkg'
    else
        printf 'opkg'
    fi
}

modem_pkg_format_install_cmd() {
    preset="$1"
    pm="$(modem_pkg_pm_name)"
    pkgs="$(modem_pkg_set_list "$preset" | tr '\n' ' ')"

    case "$pm" in
        apk)
            printf 'apk update && apk add %s' "$pkgs"
            ;;
        *)
            printf 'opkg update && opkg install %s' "$pkgs"
            ;;
    esac
}

# Одна строка справки: пакет + роль (для таблицы в отчёте).
modem_pkg_format_package_line() {
    pkg="$1"
    role="$(modem_pkg_package_role "$pkg")"
    printf '    %-28s %s\n' "$pkg" "$role"
}

# Блок одного набора: название | назначение | пакеты | команда.
modem_pkg_print_set_block() {
    preset="$1"
    label="$(modem_pkg_set_label "$preset")"
    purpose="$(modem_pkg_set_purpose "$preset")"

    printf '%s\n' "[$preset] $label"
    printf '%s\n' "  Назначение: $purpose"
    printf '%s\n' "  Пакеты:"
    modem_pkg_set_list "$preset" | while read -r pkg; do
        [ -n "$pkg" ] || continue
        modem_pkg_format_package_line "$pkg"
    done
    printf '%s\n' "  Установка:"
    printf '    %s\n' "$(modem_pkg_format_install_cmd "$preset")"
    printf '\n'
}

modem_pkg_print_sets_reference() {
    printf '%s\n' "Справка: набор | назначение | пакеты (что делает) | команда opkg/apk"
    printf '%s\n' "Источник QMI/MBIM: OpenWrt wiki ltedongle; HiLink: CDC-Ethernet (E3372h-320)."
    printf '\n'
    for preset in $MODEM_PKG_ALL_PRESETS; do
        modem_pkg_print_set_block "$preset"
    done
}

# Краткая строка для пункта меню установки.
modem_pkg_set_menu_blurb() {
    preset="$1"
    case "$preset" in
        usb-foundation) printf '%s' "USB — storage + usbutils (без kmod-usb2/3)" ;;
        hilink-setup) printf '%s' "★ E3372 — всё: USB + cdc-ether + modeswitch" ;;
        hilink-min) printf '%s' "HiLink минимум — только cdc-ether" ;;
        hilink-rec) printf '%s' "HiLink рекомендуется — E3372, +modeswitch" ;;
        qmi-wiki)   printf '%s' "QMI — wiki sample (qmi-wwan, uqmi, luci)" ;;
        qmi-extra)  printf '%s' "QMI расширенный — wiki + wwan + modeswitch" ;;
        mbim-wiki)  printf '%s' "MBIM — wiki sample (mbim, umbim, luci)" ;;
        mbim-extra) printf '%s' "MBIM расширенный — wiki + wwan + modeswitch" ;;
        ncm-wiki)   printf '%s' "NCM — CDC-NCM, comgt-ncm, luci-proto-ncm" ;;
        *)          modem_pkg_set_label "$preset" ;;
    esac
}
