#!/bin/sh
# shellcheck shell=sh
# Установка набора пакетов для USB-модема.
# Usage: install.sh --preset NAME | --recommended [--no-update] [--yes]
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"
. "$SCRIPT_DIR/packages.sh"
. "$SCRIPT_DIR/lib.sh"

PRESET=""
RECOMMENDED=0
DO_UPDATE=1
usage() {
    cat <<USAGE
Usage: $(common_basename) --preset PRESET | --recommended [--no-update]

  PRESET: $(printf '%s' "$MODEM_PKG_ALL_PRESETS" | tr ' ' ', ')
USAGE
}

while [ $# -gt 0 ]; do
    case "$1" in
        --preset)
            shift
            PRESET="${1:-}"
            [ -n "$PRESET" ] || die "--preset requires a name"
            shift
            ;;
        --recommended)
            RECOMMENDED=1
            shift
            ;;
        --no-update)
            DO_UPDATE=0
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
done

if [ "$RECOMMENDED" = "1" ]; then
    modem_detect_run
    modem_detect_recommended_presets
    PRESET="${MODEM_DETECT_PRIMARY_PRESET:-}"
    [ -n "$PRESET" ] || die "Не удалось выбрать набор: режим модема «$(modem_detect_mode_label)». Запустите диагностику или укажите --preset."
    info "Режим: $(modem_detect_mode_label) (уверенность: ${MODEM_DETECT_CONFIDENCE:-low})"
    info "Набор: $(modem_pkg_set_label "$PRESET")"
elif [ -z "$PRESET" ]; then
    usage
    exit 1
fi

modem_pkg_set_valid "$PRESET" || die "Неизвестный набор: $PRESET"

pm_print
info "Назначение: $(modem_pkg_set_purpose "$PRESET")"

if [ "$DO_UPDATE" = "1" ]; then
    info "Обновление индекса пакетов..."
    pm_update
fi

# shellcheck disable=SC2046
set -- $(modem_pkg_set_list "$PRESET")
[ $# -gt 0 ] || die "Пустой список пакетов для $PRESET"

info "Установка пакетов ($PRESET): $*"
# shellcheck disable=SC2086
pm_install_or_upgrade_packages -- "$@" || {
    rc=$?
    # pm_install_or_upgrade_packages: 0 = всё уже было, 1 = что-то установлено, иначе — ошибка
    [ "$rc" -eq 1 ] || die "Не удалось установить один или несколько пакетов (код $rc)"
}

success "Набор «$(modem_pkg_set_label "$PRESET")» обработан."
info "После установки рекомендуется: reboot"
case "$PRESET" in
    usb-foundation)
        info "Переподключите модем; проверка: lsusb (нужен пакет usbutils) или диагностика xfree-toolbox"
        ;;
    hilink-setup|hilink-*)
        info "WAN: LuCI → Network → новый интерфейс DHCP на eth* модема; админка модема часто http://192.168.8.1"
        ;;
    qmi-*)
        info "Проверка: ls -l /dev/cdc-wdm* ; LuCI → QMI Cellular"
        ;;
    mbim-*)
        info "Проверка: ls -l /dev/cdc-wdm* ; LuCI → MBIM Cellular"
        ;;
    ncm-wiki)
        info "LuCI → NCM; см. wiki CDC-NCM"
        ;;
esac

exit 0
