#!/bin/sh
# shellcheck shell=sh
# UCI: DHCP WAN на eth* HiLink (Huawei E3372 и аналоги).
# Usage: configure-hilink-wan.sh [--apply] [--dry-run] [--iface NAME] [--device ethX]
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib.sh"

MODEM_UCI_IFACE="${MODEM_UCI_IFACE:-lte}"
DEVICE=""
APPLY=0
DRY_RUN=0

usage() {
    cat <<USAGE
Usage: $(common_basename) [--apply] [--dry-run] [--iface NAME] [--device ethX]

  Создаёт network.$MODEM_UCI_IFACE (proto dhcp) на интерфейсе HiLink (cdc_ether)
  и добавляет его в зону firewall wan.

  --apply     записать UCI и поднять интерфейс (без флага — только план)
  --dry-run   показать uci changes без commit
  --iface     имя интерфейса OpenWrt (по умолчанию: lte)
  --device    L2-устройство (по умолчанию: авто eth* + cdc_ether)
USAGE
}

while [ $# -gt 0 ]; do
    case "$1" in
        --apply) APPLY=1; shift ;;
        --dry-run) DRY_RUN=1; APPLY=1; shift ;;
        --iface)
            shift
            MODEM_UCI_IFACE="${1:-}"
            [ -n "$MODEM_UCI_IFACE" ] || die "--iface requires a name"
            shift
            ;;
        --device)
            shift
            DEVICE="${1:-}"
            [ -n "$DEVICE" ] || die "--device requires ethX"
            shift
            ;;
        -h|--help) usage; exit 0 ;;
        *) die "Unknown argument: $1" ;;
    esac
done

command -v uci >/dev/null 2>&1 || die "uci не найден (это скрипт для OpenWrt на роутере)"

if uci changes network 2>/dev/null | grep -q .; then
    die "Есть незакоммиченные изменения network. Выполните: uci commit network  или  uci revert network"
fi
if uci changes firewall 2>/dev/null | grep -q .; then
    die "Есть незакоммиченные изменения firewall. Выполните: uci commit firewall  или  uci revert firewall"
fi

if [ -z "$DEVICE" ]; then
    modem_lib_guess_hilink_device || die "Не найден eth* HiLink (cdc_ether). Подключите модем и проверьте диагностику."
    DEVICE="$MODEM_HILINK_DEVICE"
fi

[ -d "/sys/class/net/$DEVICE" ] || die "Сетевой интерфейс не найден: $DEVICE"

_driver="$(modem_lib_net_driver_name "$DEVICE")"
info "Устройство модема: $DEVICE (драйвер: ${_driver:-?})"
info "UCI-интерфейс: $MODEM_UCI_IFACE, proto=dhcp"

if uci -q get "network.$MODEM_UCI_IFACE" >/dev/null 2>&1; then
    _cur_proto="$(uci -q get "network.$MODEM_UCI_IFACE.proto" 2>/dev/null || true)"
    _cur_dev="$(uci -q get "network.$MODEM_UCI_IFACE.device" 2>/dev/null || true)"
    [ -n "$_cur_dev" ] || _cur_dev="$(uci -q get "network.$MODEM_UCI_IFACE.ifname" 2>/dev/null || true)"
    if [ "$_cur_proto" = "dhcp" ] && [ "$_cur_dev" = "$DEVICE" ]; then
        info "network.$MODEM_UCI_IFACE уже настроен (dhcp, device=$DEVICE)"
    else
        info "Обновляю network.$MODEM_UCI_IFACE (было: proto=${_cur_proto:-?} device=${_cur_dev:-?})"
    fi
else
    uci set "network.$MODEM_UCI_IFACE=interface"
fi

uci set "network.$MODEM_UCI_IFACE.proto=dhcp"
uci set "network.$MODEM_UCI_IFACE.device=$DEVICE"
uci -q delete "network.$MODEM_UCI_IFACE.ifname" 2>/dev/null || true

if modem_lib_uci_wan_zone_add_network "$MODEM_UCI_IFACE"; then
    info "firewall: $MODEM_UCI_IFACE добавлен в зону wan"
else
    warn "Зона firewall wan не найдена — добавьте $MODEM_UCI_IFACE в wan вручную в LuCI"
fi

if [ "$APPLY" != "1" ]; then
    info "План (без записи). Для применения: $0 --apply"
    info "  uci set network.$MODEM_UCI_IFACE ..."
    exit 0
fi

if [ "$DRY_RUN" = "1" ]; then
    info "--- uci changes network ---"
    uci changes network 2>/dev/null || true
    info "--- uci changes firewall ---"
    uci changes firewall 2>/dev/null || true
    exit 0
fi

uci commit network
uci commit firewall

info "Поднимаю интерфейс $MODEM_UCI_IFACE ..."
if ! ifup "$MODEM_UCI_IFACE" 2>/dev/null; then
    warn "ifup не удался, пробую /etc/init.d/network reload"
    /etc/init.d/network reload 2>/dev/null || true
fi

success "Интерфейс $MODEM_UCI_IFACE создан: proto=dhcp, device=$DEVICE, зона wan"
info "Проверка: ifstatus $MODEM_UCI_IFACE"
if command -v ifstatus >/dev/null 2>&1; then
    ifstatus "$MODEM_UCI_IFACE" 2>/dev/null | head -n 20 || true
fi
info "Админка модема (APN/сигнал): http://192.168.8.1"
info "LuCI: Network → Interfaces → $MODEM_UCI_IFACE"

exit 0
