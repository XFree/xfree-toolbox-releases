#!/bin/sh
# shellcheck shell=sh
# Эвристики определения режима USB-модема на роутере.

MODEM_DETECT_MODE=""
MODEM_DETECT_CONFIDENCE=""
MODEM_DETECT_HINTS=""

modem_lib_have_cmd() {
    command -v "$1" >/dev/null 2>&1
}

MODEM_HILINK_DEVICE=""

# Драйвер L2-интерфейса из sysfs (cdc_ether и т.п.).
modem_lib_net_driver_name() {
    iface="$1"
    [ -n "$iface" ] || return 1
    [ -e "/sys/class/net/$iface/device/driver" ] || return 1
    basename "$(readlink -f "/sys/class/net/$iface/device/driver" 2>/dev/null)" 2>/dev/null || true
}

# HiLink: интерфейс с драйвером cdc_ether; иначе eth1, если есть.
modem_lib_guess_hilink_device() {
    MODEM_HILINK_DEVICE=""
    for _path in /sys/class/net/eth*; do
        [ -e "$_path" ] || continue
        _name="${_path##*/}"
        _driver="$(modem_lib_net_driver_name "$_name")"
        case "$_driver" in
            cdc_ether)
                MODEM_HILINK_DEVICE="$_name"
                return 0
                ;;
        esac
    done
    if [ -d /sys/class/net/eth1 ]; then
        MODEM_HILINK_DEVICE="eth1"
        return 0
    fi
    return 1
}

# Добавить интерфейс в зону firewall wan (без дубликатов).
modem_lib_uci_wan_zone_add_network() {
    _iface="$1"
    _idx=0
    while uci -q get "firewall.@zone[$_idx]" >/dev/null 2>&1; do
        _zname="$(uci -q get "firewall.@zone[$_idx].name" 2>/dev/null || true)"
        if [ "$_zname" = "wan" ]; then
            _nets="$(uci -q get "firewall.@zone[$_idx].network" 2>/dev/null || true)"
            for _n in $_nets; do
                [ "$_n" = "$_iface" ] && return 0
            done
            uci add_list "firewall.@zone[$_idx].network=$_iface"
            return 0
        fi
        _idx=$((_idx + 1))
    done
    return 1
}

# Есть ли на шине устройство кроме корневых хабов (1d6b).
modem_lib_usb_has_non_hub_device() {
    if modem_lib_have_cmd lsusb; then
        lsusb 2>/dev/null | grep -viE '1d6b:000[123]|Linux Foundation.*root hub' | grep -q .
        return $?
    fi
    for _d in /sys/bus/usb/devices/[0-9]*-[0-9]*; do
        [ -d "$_d" ] || continue
        return 0
    done
    return 1
}

modem_lib_usb_sysfs_summary() {
    if [ ! -d /sys/bus/usb/devices ]; then
        printf '%s\n' "(нет /sys/bus/usb/devices — USB subsystem?)"
        return 0
    fi
    found=0
    for _d in /sys/bus/usb/devices/*-*; do
        [ -d "$_d" ] || continue
        found=1
        _id="${_d##*/}"
        _vid="$(cat "$_d/idVendor" 2>/dev/null || echo "?")"
        _pid="$(cat "$_d/idProduct" 2>/dev/null || echo "?")"
        _mfg="$(cat "$_d/manufacturer" 2>/dev/null || true)"
        _prod="$(cat "$_d/product" 2>/dev/null || true)"
        printf '  %s  %s:%s' "$_id" "$_vid" "$_pid"
        [ -n "$_mfg$_prod" ] && printf '  %s %s' "$_mfg" "$_prod"
        printf '\n'
    done
    [ "$found" = "1" ] || printf '%s\n' "  (нет устройств *-* на шине — модем не опрошен ядром)"
}

modem_lib_usb_lines() {
    if modem_lib_have_cmd lsusb; then
        lsusb 2>/dev/null || true
        return 0
    fi
    if [ -r /sys/kernel/debug/usb/devices ]; then
        sed -n '1,200p' /sys/kernel/debug/usb/devices 2>/dev/null | \
            grep -E '^(T:|P:|S:)' || true
        return 0
    fi
    printf '%s\n' "(lsusb и /sys/kernel/debug/usb/devices недоступны)"
}

modem_lib_dmesg_modem_lines() {
    if ! modem_lib_have_cmd dmesg; then
        printf '%s\n' "(dmesg недоступен)"
        return 0
    fi
    dmesg 2>/dev/null | grep -iE \
        'qmi_wwan|cdc_mbim|cdc_ether|huawei_cdc|cdc_ncm|option[0-9]|usbserial|cdc-wdm|mbim|hilink|12d1:|2c7c:' | \
        tail -n 50 || true
}

modem_lib_grep_dmesg() {
    pattern="$1"
    modem_lib_have_cmd dmesg || return 1
    dmesg 2>/dev/null | grep -qiE "$pattern"
}

modem_lib_lsusb_match() {
    pattern="$1"
    lines="$(modem_lib_usb_lines)"
    printf '%s\n' "$lines" | grep -qiE "$pattern"
}

modem_detect_run() {
    MODEM_DETECT_MODE="unknown"
    MODEM_DETECT_CONFIDENCE="low"
    MODEM_DETECT_HINTS=""

    has_wdm=0
    if [ -d /dev ] && ls /dev/cdc-wdm* >/dev/null 2>&1; then
        has_wdm=1
        MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}есть /dev/cdc-wdm*; "
    fi

    has_tty=0
    if ls /dev/ttyUSB* >/dev/null 2>&1; then
        has_tty=1
        MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}есть /dev/ttyUSB*; "
    fi

    has_cdc_eth=0
    if modem_lib_grep_dmesg 'cdc_ether|cdc ether|huawei.*ether'; then
        has_cdc_eth=1
        MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}dmesg: cdc_ether; "
    fi

    has_qmi=0
    if modem_lib_grep_dmesg 'qmi_wwan'; then
        has_qmi=1
        MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}dmesg: qmi_wwan; "
    fi

    has_mbim=0
    if modem_lib_grep_dmesg 'cdc_mbim'; then
        has_mbim=1
        MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}dmesg: cdc_mbim; "
    fi

    has_ncm=0
    if modem_lib_grep_dmesg 'huawei_cdc_ncm|cdc_ncm'; then
        has_ncm=1
        MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}dmesg: NCM; "
    fi

    has_huawei_hilink=0
    if modem_lib_lsusb_match '12d1:14|Huawei.*E3372|HiLink'; then
        has_huawei_hilink=1
        MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}USB: Huawei HiLink/E3372-подобный; "
    fi

    # Приоритет: явный драйвер в ядре > USB ID > wdm/tty
    if [ "$has_qmi" = "1" ] || { [ "$has_wdm" = "1" ] && [ "$has_mbim" = "0" ]; }; then
        MODEM_DETECT_MODE="qmi"
        MODEM_DETECT_CONFIDENCE="high"
        [ "$has_qmi" = "1" ] || MODEM_DETECT_CONFIDENCE="medium"
        return 0
    fi

    if [ "$has_mbim" = "1" ]; then
        MODEM_DETECT_MODE="mbim"
        MODEM_DETECT_CONFIDENCE="high"
        return 0
    fi

    if [ "$has_ncm" = "1" ]; then
        MODEM_DETECT_MODE="ncm"
        MODEM_DETECT_CONFIDENCE="high"
        return 0
    fi

    if [ "$has_cdc_eth" = "1" ] || [ "$has_huawei_hilink" = "1" ]; then
        MODEM_DETECT_MODE="hilink"
        MODEM_DETECT_CONFIDENCE="high"
        [ "$has_cdc_eth" = "1" ] || MODEM_DETECT_CONFIDENCE="medium"
        return 0
    fi

    if [ "$has_tty" = "1" ]; then
        MODEM_DETECT_MODE="serial-3g"
        MODEM_DETECT_CONFIDENCE="medium"
        MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}возможен PPP/3G (wiki 3gdongle); "
        return 0
    fi

    MODEM_DETECT_MODE="unknown"
    MODEM_DETECT_CONFIDENCE="low"
    MODEM_DETECT_HINTS="${MODEM_DETECT_HINTS}подключите модем и повторите; при mass-storage попробуйте usb-modeswitch"
}

modem_detect_mode_label() {
    case "${MODEM_DETECT_MODE:-unknown}" in
        hilink)     printf '%s' "HiLink / CDC-Ethernet (DHCP на eth*, не QMI)" ;;
        qmi)        printf '%s' "QMI (/dev/cdc-wdm*, uqmi)" ;;
        mbim)       printf '%s' "MBIM (/dev/cdc-wdm*, umbim)" ;;
        ncm)        printf '%s' "CDC-NCM" ;;
        serial-3g)  printf '%s' "Serial / 3G-PPP (ttyUSB)" ;;
        unknown)    printf '%s' "не определён" ;;
        *)          printf '%s' "${MODEM_DETECT_MODE:-unknown}" ;;
    esac
}

MODEM_DETECT_PRIMARY_PRESET=""
MODEM_DETECT_SECONDARY_PRESET=""

modem_detect_recommended_presets() {
    MODEM_DETECT_PRIMARY_PRESET=""
    MODEM_DETECT_SECONDARY_PRESET=""
    case "${MODEM_DETECT_MODE:-unknown}" in
        hilink)
            MODEM_DETECT_PRIMARY_PRESET="hilink-rec"
            MODEM_DETECT_SECONDARY_PRESET="hilink-min"
            ;;
        qmi)
            MODEM_DETECT_PRIMARY_PRESET="qmi-wiki"
            MODEM_DETECT_SECONDARY_PRESET="qmi-extra"
            ;;
        mbim)
            MODEM_DETECT_PRIMARY_PRESET="mbim-wiki"
            MODEM_DETECT_SECONDARY_PRESET="mbim-extra"
            ;;
        ncm)
            MODEM_DETECT_PRIMARY_PRESET="ncm-wiki"
            ;;
        serial-3g)
            ;;
        *)
            # Модем не определён (типично E3372 до установки пакетов) — полный HiLink-набор
            MODEM_DETECT_PRIMARY_PRESET="hilink-setup"
            MODEM_DETECT_SECONDARY_PRESET="usb-foundation"
            ;;
    esac
}
