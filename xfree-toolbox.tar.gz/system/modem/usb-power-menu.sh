#!/bin/sh
# shellcheck shell=sh
# Backward-compat: мониторинг перенесён в uplink-monitor/ (xft → 11).
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"
exec sh "$ROOT_DIR/uplink-monitor/menu.sh" ui
