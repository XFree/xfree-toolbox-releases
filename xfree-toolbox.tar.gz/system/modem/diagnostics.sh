#!/bin/sh
# shellcheck shell=sh
# Диагностика USB-модема и рекомендация набора пакетов.
# Usage: diagnostics.sh [--out FILE]
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/packages.sh"
. "$SCRIPT_DIR/lib.sh"

OUT_FILE=""
while [ $# -gt 0 ]; do
    case "$1" in
        --out)
            shift
            OUT_FILE="${1:-}"
            [ -n "$OUT_FILE" ] || die "diagnostics.sh: --out requires a path"
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--out FILE]"
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
done

PM_CAN_CHECK=0
if [ -f "$ROOT_DIR/lib/pkgmgr.sh" ]; then
  # shellcheck disable=SC1090
  . "$ROOT_DIR/lib/pkgmgr.sh" 2>/dev/null && PM_CAN_CHECK=1 || PM_CAN_CHECK=0
fi

_emit() {
    if [ -n "$OUT_FILE" ]; then
        printf '%s\n' "$*" >>"$OUT_FILE"
    else
        printf '%s\n' "$*"
    fi
}

_section() {
    _emit ""
    _emit "=== $* ==="
}

modem_diag_pkg_status_simple() {
    pkg="$1"
    if [ "$PM_CAN_CHECK" = "1" ] && pm_is_installed "$pkg" 2>/dev/null; then
        printf '%s' "установлен"
    elif [ "$PM_CAN_CHECK" = "1" ]; then
        printf '%s' "нет"
    else
        printf '%s' "?"
    fi
}

modem_diag_pkg_status_line() {
    preset="$1"
    modem_pkg_set_list "$preset" | while read -r pkg; do
        [ -n "$pkg" ] || continue
        if [ "$PM_CAN_CHECK" = "1" ] && pm_is_installed "$pkg" 2>/dev/null; then
            st="установлен"
        elif [ "$PM_CAN_CHECK" = "1" ]; then
            st="нет"
        else
            st="?"
        fi
        _emit "  $pkg — $st — $(modem_pkg_package_role "$pkg")"
    done
}

if [ -n "$OUT_FILE" ]; then
    : >"$OUT_FILE"
fi

modem_detect_run

modem_detect_recommended_presets
primary_preset="${MODEM_DETECT_PRIMARY_PRESET:-}"
secondary_preset="${MODEM_DETECT_SECONDARY_PRESET:-}"

_section "Рекомендация"
_emit "Режим (эвристика): $(modem_detect_mode_label)"
_emit "Уверенность: ${MODEM_DETECT_CONFIDENCE:-low}"
_emit "Подсказки: ${MODEM_DETECT_HINTS:-—}"
_emit ""

if [ -n "${primary_preset:-}" ]; then
    _emit "Рекомендуемый набор: $(modem_pkg_set_label "$primary_preset")"
    _emit "  Назначение: $(modem_pkg_set_purpose "$primary_preset")"
    _emit "  $(modem_pkg_format_install_cmd "$primary_preset")"
    if [ -n "${secondary_preset:-}" ]; then
        _emit ""
        _emit "Альтернатива: $(modem_pkg_set_label "$secondary_preset")"
        _emit "  Назначение: $(modem_pkg_set_purpose "$secondary_preset")"
        _emit "  $(modem_pkg_format_install_cmd "$secondary_preset")"
    fi
else
    _emit "Автоматический набор не выбран (serial/3G — см. wiki 3gdongle)."
    _emit "Подключите модем или выберите набор вручную из справки ниже."
fi
if [ "${MODEM_DETECT_MODE:-unknown}" = "unknown" ]; then
    _emit ""
    _emit "Для Huawei E3372h-320 (HiLink) в меню: «★ HiLink E3372 — установить всё» (hilink-setup)."
    _emit "  $(modem_pkg_format_install_cmd hilink-setup)"
fi

_emit ""
case "${MODEM_DETECT_MODE:-unknown}" in
    hilink)
        _emit "После установки: перезагрузка, новый eth* → меню «Создать интерфейс LTE» или LuCI DHCP."
        _emit "Админка модема (типично): http://192.168.8.1"
        ;;
    qmi|mbim)
        _emit "После установки: перезагрузка, проверьте ls -l /dev/cdc-wdm*"
        _emit "LuCI: Network → Add interface → $( [ "$MODEM_DETECT_MODE" = "qmi" ] && printf '%s' QMI || printf '%s' MBIM ) Cellular"
        ;;
    ncm)
        _emit "После установки: LuCI → luci-proto-ncm, см. wiki CDC-NCM."
        ;;
esac

usb_guest=0
if modem_lib_usb_has_non_hub_device; then
    usb_guest=1
fi

_section "Базовая поддержка USB (шина)"
if [ "$PM_CAN_CHECK" = "1" ]; then
    for pkg in $MODEM_PKG_USB_FOUNDATION; do
        _emit "  $pkg — $(modem_diag_pkg_status_simple "$pkg") — $(modem_pkg_package_role "$pkg")"
    done
else
    _emit "  (проверка opkg/apk недоступна — см. opkg list-installed | grep usb)"
fi
if modem_lib_have_cmd lsmod; then
    _emit ""
    _emit "Модули ядра (lsmod | grep usb):"
    lsmod 2>/dev/null | grep -i usb | while read -r line; do
        _emit "  $line"
    done || _emit "  (нет строк usb в lsmod)"
fi
_emit ""
if [ "$usb_guest" = "0" ]; then
    _emit "На USB-шине не видно устройств кроме корневого хаба."
    _emit "Мигающий модем ≠ опрос USB роутером. Проверьте:"
    _emit "  • порт USB на роутере (другой порт; host USB — kmod-usb-core/xhci обычно уже в прошивке)"
    _emit "  • кабель с линиями данных (не «только зарядка»)"
    _emit "  • питание донгла (хаб с питанием при слабом порте)"
    _emit "  • воткните модем и сразу: dmesg | tail -30  (новые строки usb/new device)"
    _emit "Сначала добейтесь строки в lsusb (Huawei 12d1:…), затем ставьте hilink-rec."
else
    _emit "USB-устройство на шине есть — можно ставить набор под режим модема (HiLink/QMI/MBIM)."
fi

_section "Наборы пакетов (справка, OpenWrt wiki)"
modem_pkg_print_sets_reference | while read -r line; do
    _emit "$line"
done

if [ -n "${primary_preset:-}" ]; then
    _section "Статус пакетов (рекомендуемый набор)"
    modem_diag_pkg_status_line "$primary_preset"
fi

_section "USB power (обёртка xfree)"
if [ -f "$ROOT_DIR/system/hardware/usb-power.sh" ]; then
    sh "$ROOT_DIR/system/hardware/usb-power.sh" status 2>/dev/null | while read -r line; do
        _emit "$line"
    done || _emit "  (ошибка usb-power.sh status)"
else
    _emit "  (нет system/hardware/usb-power.sh)"
fi

_section "USB (lsusb / debug)"
modem_lib_usb_lines | while read -r line; do
    _emit "$line"
done
_emit ""
_emit "sysfs (/sys/bus/usb/devices):"
modem_lib_usb_sysfs_summary | while read -r line; do
    _emit "$line"
done

_section "Ядро (фрагмент dmesg, модем)"
modem_lib_dmesg_modem_lines | while read -r line; do
    _emit "$line"
done

_section "Ядро (фрагмент dmesg, USB)"
if modem_lib_have_cmd dmesg; then
    dmesg 2>/dev/null | grep -iE 'usb|new device|disconnect' | tail -n 25 | while read -r line; do
        _emit "$line"
    done || _emit "(пусто)"
else
    _emit "(dmesg недоступен)"
fi

_section "Устройства"
if ls /dev/cdc-wdm* >/dev/null 2>&1; then
    ls -l /dev/cdc-wdm* 2>/dev/null | while read -r line; do _emit "$line"; done
else
    _emit "(нет /dev/cdc-wdm*)"
fi
if ls /dev/ttyUSB* >/dev/null 2>&1; then
    ls -l /dev/ttyUSB* 2>/dev/null | while read -r line; do _emit "$line"; done
else
    _emit "(нет /dev/ttyUSB*)"
fi

_section "Сетевые интерфейсы (ip link)"
if command -v ip >/dev/null 2>&1; then
    ip -br link 2>/dev/null | while read -r line; do _emit "$line"; done || _emit "(ip link: ошибка)"
else
    _emit "(ip не найден)"
fi

_section "usbmode"
if command -v usbmode >/dev/null 2>&1; then
    usbmode -l 2>/dev/null | while read -r line; do _emit "$line"; done || _emit "(usbmode -l: пусто или ошибка)"
else
    _emit "(usbmode не установлен — при mass-storage может понадобиться usb-modeswitch)"
fi

_emit ""
_emit "--- конец отчёта ---"
