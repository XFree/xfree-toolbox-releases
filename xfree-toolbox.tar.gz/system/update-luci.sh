#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"

MODE_AUTO=0
MODE_NO_BACKUP=0
MODE_DRY_RUN=0
YES=0
FORCE=0
SILENT=0
SCOPE="luci"
BACKUP_ROOT="${BACKUP_ROOT:-$(common_backup_root)}"
BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"

usage() {
  echo "Использование: $(common_basename) [--scope luci|all] [--auto] [--yes] [--force] [--silent] [--no-backup] [--dry-run]"
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --auto) MODE_AUTO=1 ;;
    --no-backup) MODE_NO_BACKUP=1 ;;
    --dry-run) MODE_DRY_RUN=1 ;;
    --scope)
      shift
      [ "$#" -gt 0 ] || die "--scope требует значение"
      SCOPE="$1"
      ;;
    --yes) YES=1 ;;
    --force) FORCE=1 ;;
    --silent) SILENT=1 ;;
    --help|-h) usage; exit 0 ;;
    *) die "Неизвестный параметр: $1" ;;
  esac
  shift
done

case "$SCOPE" in
  luci|all) ;;
  *) die "Неизвестный scope: $SCOPE (ожидается: luci|all)" ;;
esac

TS="$(timestamp_now)"
LOG_DIR="/var/log"
LOG_FILE="${LOG_DIR}/luci-upgrade-${TS}.log"
mkdir -p "$LOG_DIR" 2>/dev/null || true

if [ "$SCOPE" = "all" ]; then
  echo "== System upgrade started at ${TS} ==" | tee -a "$LOG_FILE"
else
  echo "== LuCI upgrade started at ${TS} ==" | tee -a "$LOG_FILE"
fi
pm_print | tee -a "$LOG_FILE"

echo "[*] Обновление списков пакетов..." | tee -a "$LOG_FILE"
pm_update >>"$LOG_FILE" 2>&1

if [ "$SCOPE" = "all" ]; then
  echo "[*] Поиск всех обновляемых пакетов..." | tee -a "$LOG_FILE"
  UPGRADE_PKGS="$(pm_list_upgradable_names | sort -u)"
  [ -n "$UPGRADE_PKGS" ] || { echo "[*] Нет обновляемых пакетов" | tee -a "$LOG_FILE"; exit 0; }
else
  echo "[*] Поиск обновляемых пакетов luci-*..." | tee -a "$LOG_FILE"
  UPGRADE_PKGS="$(pm_list_upgradable_names | awk '/^luci/ {print}' | sort -u)"
  [ -n "$UPGRADE_PKGS" ] || { echo "[*] Нет обновляемых пакетов luci-*" | tee -a "$LOG_FILE"; exit 0; }
fi

echo "[*] Найдены пакеты:" | tee -a "$LOG_FILE"
echo "$UPGRADE_PKGS" | tee -a "$LOG_FILE"

if [ "$MODE_DRY_RUN" -eq 1 ]; then
  echo "[dry-run] Обновление не выполняется."
  exit 0
fi

if [ "$MODE_NO_BACKUP" -eq 1 ]; then
  echo "[*] Бэкап отключён (--no-backup)" | tee -a "$LOG_FILE"
else
  if [ "$SCOPE" = "luci" ]; then
    for cfg in /etc/config/luci /etc/config/uhttpd; do
      [ -f "$cfg" ] || continue
      # Backup policy: LuCI config backup under common root; rotated by common_backup_rotate.
      backup="$(common_backup_file "$cfg" system "$(basename "$cfg")" "$BACKUP_KEEP" backup)"
      echo "[*] Бэкап создан: $backup" | tee -a "$LOG_FILE"
    done
  else
    echo "[*] Scope=all: отдельный backup конфигов LuCI не выполняется" | tee -a "$LOG_FILE"
  fi
fi

if [ "$MODE_AUTO" -eq 0 ]; then
  confirm_or_exit 'Продолжить обновление?'
fi

FAILED=0
_UPGRADE_LOG="${TMPDIR:-/tmp}/xfree-luci-upgrade.$$"
if [ "$SCOPE" = "all" ]; then
  echo "[*] Выполняется пакетное обновление всех пакетов (как в LuCI)..." | tee -a "$LOG_FILE"
  pm_upgrade_all >>"$_UPGRADE_LOG" 2>&1 || true
else
  echo "[*] Выполняется обновление luci-пакетов..." | tee -a "$LOG_FILE"
  [ "$PM" = "apk" ] && pm_apk_sanitize_world_qpins >>"$_UPGRADE_LOG" 2>&1 || true
  for pkg in $UPGRADE_PKGS; do
    echo "[*] Обновление $pkg" | tee -a "$LOG_FILE"
    pm_upgrade "$pkg" >>"$_UPGRADE_LOG" 2>&1 || true
  done
fi
cat "$_UPGRADE_LOG" >>"$LOG_FILE" 2>/dev/null || true
rm -f "$_UPGRADE_LOG" 2>/dev/null || true

if [ "$SCOPE" = "all" ]; then
  REMAINING="$(pm_list_upgradable_names | sort -u)"
else
  REMAINING="$(pm_list_upgradable_names | awk '/^luci/ {print}' | sort -u)"
fi
if [ -n "$REMAINING" ]; then
  echo "[*] После обновления остались пакеты:" | tee -a "$LOG_FILE"
  echo "$REMAINING" | tee -a "$LOG_FILE"
  FAILED=1
fi

if [ "$SCOPE" = "all" ]; then
  echo "== System upgrade finished at $(timestamp_now) ==" | tee -a "$LOG_FILE"
else
  echo "== LuCI upgrade finished at $(timestamp_now) ==" | tee -a "$LOG_FILE"
fi

echo "[*] Перезапуск uhttpd и rpcd..." | tee -a "$LOG_FILE"
if /etc/init.d/uhttpd restart >>"$LOG_FILE" 2>&1; then echo '    -> uhttpd restarted OK' | tee -a "$LOG_FILE"; else echo '    -> uhttpd restart FAILED' | tee -a "$LOG_FILE"; fi
if /etc/init.d/rpcd restart >>"$LOG_FILE" 2>&1; then echo '    -> rpcd restarted OK' | tee -a "$LOG_FILE"; else echo '    -> rpcd restart FAILED' | tee -a "$LOG_FILE"; fi

if [ "$FAILED" -eq 1 ]; then
  echo "ВНИМАНИЕ: возникли ошибки при обновлении пакетов." | tee -a "$LOG_FILE"
  echo "Смотрите лог: $LOG_FILE"
  exit 1
fi

if [ "$SCOPE" = "all" ]; then
  echo "Все обновляемые пакеты успешно обновлены." | tee -a "$LOG_FILE"
else
  echo "Все пакеты LuCI успешно обновлены." | tee -a "$LOG_FILE"
fi
