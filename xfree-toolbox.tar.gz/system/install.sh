#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"
. "$SCRIPT_DIR/base-packages.sh"
. "$SCRIPT_DIR/lib/base-packages-check.sh"

YES=0
FORCE=0
SILENT=0
DO_UPDATE=1
SKIP_RU=0

# LuCI / shell locale (used only for log hints).
xfree_lang_looks_russian() {
  if command -v uci >/dev/null 2>&1; then
    luci_lang="$(uci -q get luci.main.lang 2>/dev/null || true)"
    if [ -n "$luci_lang" ]; then
      ll="$(printf '%s' "$luci_lang" | tr 'A-Z' 'a-z')"
      case "$ll" in
        ru|ru_*) return 0 ;;
      esac
    fi
  fi

  case "${LC_ALL:-}" in
    [Rr][Uu]_*) return 0 ;;
  esac
  case "${LANG:-}" in
    [Rr][Uu]_*) return 0 ;;
  esac

  return 1
}

PM_REFRESH_DNSMASQ=0

ensure_dnsmasq_full() {
  if [ "${XFREE_BG_TASK:-0}" = "1" ]; then
    info "dnsmasq-full: пропуск в фоновой задаче (не меняем DNS/DHCP во время WPS sync)"
    return 0
  fi

  if pm_is_installed dnsmasq-full; then
    info "dnsmasq-full уже установлен"
    return 0
  fi

  if pm_is_installed dnsmasq; then
    warn "Требуется dnsmasq-full (поддержка nftset). Пытаюсь заменить dnsmasq -> dnsmasq-full"
    pm_replace_exclusive_package dnsmasq-full dnsmasq || die "Не удалось установить dnsmasq-full"
    PM_REFRESH_DNSMASQ=1
    return 0
  fi

  info "Устанавливаю dnsmasq-full"
  pm_install dnsmasq-full || die "Не удалось установить dnsmasq-full"
  PM_REFRESH_DNSMASQ=1
}

ensure_upnp_enabled() {
  if ! pm_is_installed luci-app-upnp 2>/dev/null; then
    if ! pm_is_installed miniupnpd 2>/dev/null; then
      return 0
    fi
  fi

  command -v uci >/dev/null 2>&1 || {
    warn "uci не найден — пропуск настройки UPnP"
    return 0
  }

  if ! uci -q get upnpd.config >/dev/null 2>&1; then
    warn "Секция upnpd.config не найдена — пропуск включения UPnP (пакет установлен?)"
    return 0
  fi

  info "UPnP: upnpd.config.enabled=1, miniupnpd enable + start"
  uci set upnpd.config.enabled='1'
  uci commit upnpd

  if [ -x /etc/init.d/miniupnpd ]; then
    /etc/init.d/miniupnpd enable 2>/dev/null || true
    /etc/init.d/miniupnpd start 2>/dev/null || warn "miniupnpd start не удался"
    success "UPnP (miniupnpd) включён"
  else
    warn "/etc/init.d/miniupnpd не найден — uci сохранён, сервис не запущен"
  fi
}

usage() {
  cat <<USAGE
Использование:
  $(common_basename) [--yes] [--force] [--silent] [--no-update] [--no-ru]

  [1/2] Базовые пакеты (system/base-packages.sh) + dnsmasq-full + UPnP
  [2/2] RU LuCI — luci-i18n для уже установленных luci-app-* (install-luci-i18n-ru.sh)

  wpad-mesh-mbedtls — отдельно: меню Система или system/install-wpad-mesh.sh
  mesh-узел (отключить dnsmasq/odhcpd/firewall): system/prepare-mesh-node.sh --yes

  --no-ru   не ставить пакеты русификации LuCI (шаг 2)
  --with-ru устарело: шаг 2 выполняется по умолчанию
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --force) FORCE=1 ;;
    --silent) SILENT=1 ;;
    --no-update) DO_UPDATE=0 ;;
    --no-ru) SKIP_RU=1 ;;
    --with-ru) ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный параметр: $1" ;;
  esac
  shift
done

pm_print
if [ "$DO_UPDATE" = "1" ]; then
  info "Обновление списков пакетов..."
  pm_update || warn "Индексы пакетов не обновлены; продолжаю установку базовых пакетов"
fi

[ "$SILENT" = "0" ] && info "=== [1/2] Базовые пакеты ==="

# shellcheck disable=SC2086
pm_install_or_upgrade_packages $( [ "$FORCE" = "1" ] && printf '%s' -- '--force' ) -- $BASE_PACKAGES_REQUIRED || {
  rc=$?
  [ "$rc" -eq 0 ] || [ "$rc" -eq 1 ] || die "Не удалось обработать обязательные пакеты (код $rc)."
}

# shellcheck disable=SC2086
pm_install_or_upgrade_packages $( [ "$FORCE" = "1" ] && printf '%s' -- '--force' ) -- $BASE_PACKAGES_OPTIONAL || {
  rc=$?
  [ "$rc" -eq 0 ] || [ "$rc" -eq 1 ] || warn "Необязательные пакеты не установлены (код $rc): $BASE_PACKAGES_OPTIONAL"
}

if ! base_package_upnp_satisfied 2>/dev/null; then
  if pm_repo_has miniupnpd 2>/dev/null; then
    info "luci-app-upnp не установлен — пробую miniupnpd"
    pm_install miniupnpd || warn "miniupnpd не установлен"
  fi
fi

ensure_dnsmasq_full
ensure_upnp_enabled

_pm_refresh_sh="$SCRIPT_DIR/pm-post-install-refresh.sh"
if [ -f "$_pm_refresh_sh" ] && [ "$PM_REFRESH_DNSMASQ" = "1" ]; then
  # shellcheck disable=SC1090
  . "$_pm_refresh_sh"
  pm_post_install_refresh "$ROOT_DIR" "$SILENT" "$PM_REFRESH_DNSMASQ" 0 || \
    warn "Индексы после базовых пакетов: см. сообщения выше"
fi

if [ "$SKIP_RU" = "0" ]; then
  ru_i18n_script="$SCRIPT_DIR/install-luci-i18n-ru.sh"
  [ -f "$ru_i18n_script" ] || die "Не найден скрипт русификации: $ru_i18n_script"
  [ -x "$ru_i18n_script" ] || chmod +x "$ru_i18n_script" 2>/dev/null || true

  [ "$SILENT" = "0" ] && info "=== [2/2] RU LuCI (переводы для установленных luci-app-*) ==="
  if xfree_lang_looks_russian; then
    [ "$SILENT" = "0" ] && info "Язык хоста/LuCI русский — luci.main.lang=ru после установки i18n"
  fi

  if [ "$FORCE" = "1" ]; then
    "$ru_i18n_script" --no-update --force || die "Не удалось установить RU-пакеты LuCI."
  else
    "$ru_i18n_script" --no-update || die "Не удалось установить RU-пакеты LuCI."
  fi
else
  [ "$SILENT" = "0" ] && info "=== [2/2] RU LuCI — пропуск (--no-ru) ==="
  info "Пакеты обработаны, перезапускаю сервисы LuCI..."
  restart_service_if_exists rpcd
  restart_service_if_exists uhttpd
  success "Сервисы LuCI перезапущены."
fi

success "Установка базовых системных пакетов завершена."
exit 0
