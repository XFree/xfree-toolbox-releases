#!/bin/sh
# Восстановление DNS/сети после сбоя install-from-cloud, ensure-base-packages или apk.
# Сообщение «Failed to send request: Operation not permitted» у apk/wget обычно = нет DNS/маршрута, не SELinux.
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
FULL=0
SKIP_APK=0
SILENT=0

usage() {
  cat <<'USAGE'
Usage: recover-apk-network.sh [--root <toolbox-dir>] [--full] [--no-apk] [--silent]

Перезапускает локальный DNS (dnsmasq, https-dns-proxy). Если имена не резолвятся:
останавливает zapret, при необходимости ставит временный 1.1.1.1/8.8.8.8, проверяет
имя фида (xfree-cloud или raw.githubusercontent.com) и downloads.openwrt.org, обновляет xfree-toolbox / https-dns-proxy /
zapret, возвращает DoH и start zapret (если сервис не был запущен — start, не только restart).

  --full     дополнительно: /etc/init.d/network restart и ожидание маршрута/DNS
  --no-apk   не обновлять пакеты (только DNS/сеть/стоп zapret/временный DNS)
USAGE
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --root)
            shift
            [ "$#" -gt 0 ] || { echo "[-] --root требует путь" >&2; exit 1; }
            ROOT_DIR="$(CDPATH= cd -- "$1" && pwd -P)"
            ;;
        --full) FULL=1 ;;
        --no-apk) SKIP_APK=1 ;;
        --silent) SILENT=1 ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "[-] Неизвестный аргумент: $1" >&2
            usage >&2
            exit 1
            ;;
    esac
    shift
done

COMMON_SH="$ROOT_DIR/lib/common.sh"
PKGMGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
RECOVER_LIB="$ROOT_DIR/system/lib/recover-network.sh"
[ -f "$COMMON_SH" ] || { echo "[-] Не найден common.sh: $COMMON_SH" >&2; exit 1; }
[ -f "$RECOVER_LIB" ] || { echo "[-] Не найден recover-network.sh: $RECOVER_LIB" >&2; exit 1; }
# shellcheck disable=SC1090
. "$COMMON_SH"
if [ -f "$PKGMGR_SH" ]; then
    # shellcheck disable=SC1090
    . "$PKGMGR_SH"
fi
# shellcheck disable=SC1090
. "$RECOVER_LIB"

export SKIP_APK SILENT ROOT_DIR

recover_cleanup() {
    recover_temp_dns_restore
}
trap recover_cleanup EXIT INT TERM

[ "$SILENT" = "0" ] && info "Восстановление DNS/сети (без reboot)…"
[ "$SILENT" = "0" ] && warn "apk «Failed to send request: Operation not permitted» чаще всего = нет DNS или default route, не отказ root."

recover_apk_sanitize_world_qpins
recover_ensure_dnsmasq_present
if [ -f "$ROOT_DIR/dns-routing/lib/restart-stack.sh" ]; then
    # shellcheck disable=SC1090
    . "$ROOT_DIR/dns-routing/lib/restart-stack.sh"
    dns_routing_restart_resolver_stack || true
fi

if [ "$FULL" = "1" ] && [ -x /etc/init.d/network ]; then
    [ "$SILENT" = "0" ] && info "Перезапуск network…"
    /etc/init.d/network restart || warn "network restart завершился с ошибкой"
    if command -v common_wait_network_after_restart >/dev/null 2>&1; then
        common_wait_network_after_restart 90 || warn "Сеть не стала готова за 90s"
    else
        sleep 5
    fi
fi

recover_network_diagnose

if [ "$RECOVER_NEED_PACKAGES" = "1" ]; then
    recover_refresh_packages
elif [ "$SKIP_APK" = "0" ] && command -v apk >/dev/null 2>&1; then
    [ "$SILENT" = "0" ] && info "Пробую apk update…"
    _apk_out="/tmp/xfree-recover-apk-update.$$"
    if apk update --force-missing-repositories >"$_apk_out" 2>&1; then
        [ "$SILENT" = "0" ] && cat "$_apk_out"
        success "apk update успешен"
        rm -f "$_apk_out" 2>/dev/null || true
    else
        _apk_rc=$?
        [ "$SILENT" = "0" ] && cat "$_apk_out"
        if grep -q 'distinct packages available' "$_apk_out" 2>/dev/null; then
            warn "apk update: частичный успех (часто недоступен только xfree feed — см. wget выше)"
            _apk_rc=0
        else
            warn "apk update не удался — при необходимости перезагрузите роутер или повторите после восстановления WAN"
        fi
        rm -f "$_apk_out" 2>/dev/null || true
        [ "$_apk_rc" -ne 0 ] && [ "$RECOVER_WAN_OK" != "1" ] && exit 1
    fi
fi

recover_temp_dns_restore

if [ -f "$ROOT_DIR/dns-routing/lib/restart-stack.sh" ]; then
    dns_routing_restart_resolver_stack || true
fi
if [ -f "$ROOT_DIR/https-dns-proxy/lib/service.sh" ]; then
    # shellcheck disable=SC1090
    . "$ROOT_DIR/https-dns-proxy/lib/service.sh"
    https_dns_proxy_restart_service restart || true
fi

recover_zapret_ensure_after

if [ "$SILENT" = "0" ]; then
    if recover_probe_cloud; then
        success "Повторно: $RECOVER_CLOUD_HOST резолвится"
    else
        warn "Повторно: $RECOVER_CLOUD_HOST всё ещё не резолвится"
    fi
fi

recover_probe_xfree_feed || true

success "recover-apk-network завершён"
exit 0
