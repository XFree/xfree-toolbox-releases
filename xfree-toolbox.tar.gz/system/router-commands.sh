#!/bin/sh
# shellcheck shell=sh
# Проверка / установка симлинков toolbox в PATH (xft, usb-modem-power-cycle).
#
# Usage:
#   router-commands.sh --check
#   router-commands.sh --install
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/router-commands-lib.sh"

MODE=""
LAUNCHER="${XFREE_LAUNCHER_NAME:-xft}"

while [ $# -gt 0 ]; do
    case "$1" in
        --check) MODE=check ;;
        --install) MODE=install ;;
        -h|--help)
            cat <<EOF
Usage: $0 --check | --install

  --check    Проверить, что xft и usb-modem-power-cycle в PATH и указывают на этот toolbox
  --install  Создать/обновить симлинки в /usr/bin или /usr/sbin

Toolbox root: $ROOT_DIR
Launcher: $LAUNCHER
EOF
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
    shift
done

[ -n "$MODE" ] || die "Укажите --check или --install"

printf 'Router commands (%s)\n' "$MODE"
printf 'Toolbox: %s\n\n' "$ROOT_DIR"

case "$MODE" in
    check)
        if ! router_cmd_check_all "$ROOT_DIR" "$LAUNCHER"; then
            printf '\nИтог: есть проблемы (см. FAIL выше).\n'
            exit 1
        fi
        printf '\nИтог: OK.\n'
        ;;
    install)
        if router_cmd_check_all "$ROOT_DIR" "$LAUNCHER" >/dev/null 2>&1; then
            printf '\nИтог: команды уже в PATH.\n'
            exit 0
        fi
        if router_cmd_install_all "$ROOT_DIR" "$LAUNCHER"; then
            die "Не удалось настроить одну или несколько команд (нет прав на /usr/bin, /usr/sbin?)"
        fi
        printf '\nПовторная проверка:\n'
        if ! router_cmd_check_all "$ROOT_DIR" "$LAUNCHER"; then
            exit 1
        fi
        success "Команды в PATH настроены."
        ;;
esac
