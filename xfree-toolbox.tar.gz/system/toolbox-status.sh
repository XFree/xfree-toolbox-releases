#!/bin/sh
# shellcheck shell=sh
# Local toolbox version + last update-check cache for LuCI/CLI.
# Usage:
#   toolbox-status.sh              # print human report + KEY= lines (fast, no network)
#   toolbox-status.sh --check      # self-update --check-only, refresh cache, print report
#   toolbox-status.sh --upgrade    # self-update --preserve-profiles (apk/tar)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
STATUS_FILE="${XFREE_TOOLBOX_UPDATE_STATUS:-$STATE_ROOT/system/toolbox-update.status}"
SELF_UPDATE_SH="$SCRIPT_DIR/self-update.sh"
MODE="${1:-}"

toolbox_status_local_version() {
	if [ -f "$ROOT_DIR/VERSION" ]; then
		head -n1 "$ROOT_DIR/VERSION" | tr -d '\r\n\t '
		return 0
	fi
	printf ''
}

toolbox_status_kv_get() {
	_file="$1"
	_key="$2"
	_def="${3:-}"
	[ -f "$_file" ] || {
		printf '%s' "$_def"
		return 0
	}
	awk -F= -v k="$_key" -v d="$_def" '
		$1 == k {
			sub(/^[^=]*=/, "")
			gsub(/\r/, "")
			print
			found = 1
			exit
		}
		END { if (!found) print d }
	' "$_file"
}

toolbox_status_write() {
	_ver="$1"
	_channel="$2"
	_update="$3"
	_installed="$4"
	_available="$5"
	_summary="$6"
	_checked="$7"
	mkdir -p "$(dirname -- "$STATUS_FILE")" 2>/dev/null || true
	{
		printf '%s\n' "# toolbox update status (KEY=value). Refresh: system/toolbox-status.sh --check"
		printf 'CHECKED_AT=%s\n' "$_checked"
		printf 'LOCAL_VERSION=%s\n' "$_ver"
		printf 'CHANNEL=%s\n' "$_channel"
		printf 'UPDATE=%s\n' "$_update"
		printf 'INSTALLED=%s\n' "$_installed"
		printf 'AVAILABLE=%s\n' "$_available"
		printf 'SUMMARY=%s\n' "$_summary"
	} >"${STATUS_FILE}.tmp"
	mv -f "${STATUS_FILE}.tmp" "$STATUS_FILE"
}

toolbox_status_parse_check_out() {
	_out="$1"
	_rc="$2"
	TB_CHANNEL="$(printf '%s\n' "$_out" | sed -n 's/^\[\*\] Channel[[:space:]]*:[[:space:]]*//p' | head -n1)"
	TB_INSTALLED="$(printf '%s\n' "$_out" | sed -n 's/^\[\*\] Installed[[:space:]]*:[[:space:]]*//p' | head -n1)"
	TB_AVAILABLE="$(printf '%s\n' "$_out" | sed -n 's/^\[\*\] Available[[:space:]]*:[[:space:]]*//p' | head -n1)"
	TB_ACTION="$(printf '%s\n' "$_out" | sed -n 's/^\[\*\] Action[[:space:]]*:[[:space:]]*//p' | head -n1)"
	TB_LOCAL="$(printf '%s\n' "$_out" | sed -n 's/^\[\*\] Local version[[:space:]]*:[[:space:]]*//p' | head -n1)"
	[ -n "${TB_LOCAL:-}" ] && [ "$TB_LOCAL" != "<none>" ] || TB_LOCAL="$(toolbox_status_local_version)"
	[ -n "${TB_CHANNEL:-}" ] || TB_CHANNEL="?"
	case "$_rc" in
	0)
		TB_UPDATE=none
		TB_SUMMARY="Обновлений нет"
		;;
	10)
		TB_UPDATE=available
		if [ "${TB_ACTION:-}" = "add" ]; then
			TB_SUMMARY="В фиде есть пакет (apk add)"
		else
			TB_SUMMARY="Доступно обновление"
		fi
		;;
	*)
		TB_UPDATE=error
		TB_SUMMARY="Ошибка проверки"
		;;
	esac
	[ -n "${TB_INSTALLED:-}" ] || TB_INSTALLED=""
	[ -n "${TB_AVAILABLE:-}" ] || TB_AVAILABLE=""
	case "$TB_AVAILABLE" in
	'<none>' | '<unknown>') TB_AVAILABLE="" ;;
	esac
}

toolbox_status_print() {
	_ver="$(toolbox_status_local_version)"
	_checked="$(toolbox_status_kv_get "$STATUS_FILE" CHECKED_AT "")"
	_channel="$(toolbox_status_kv_get "$STATUS_FILE" CHANNEL "")"
	_update="$(toolbox_status_kv_get "$STATUS_FILE" UPDATE "unknown")"
	_installed="$(toolbox_status_kv_get "$STATUS_FILE" INSTALLED "")"
	_available="$(toolbox_status_kv_get "$STATUS_FILE" AVAILABLE "")"
	_summary="$(toolbox_status_kv_get "$STATUS_FILE" SUMMARY "")"
	_cache_ver="$(toolbox_status_kv_get "$STATUS_FILE" LOCAL_VERSION "")"
	[ -n "$_ver" ] || _ver="$_cache_ver"
	[ -n "$_ver" ] || _ver="?"

	case "$_update" in
	none) _upd_h="актуально" ;;
	available) _upd_h="есть обновление" ;;
	error) _upd_h="ошибка проверки" ;;
	*) _upd_h="не проверено" ; _update=unknown ;;
	esac
	[ -n "$_summary" ] || _summary="$_upd_h"

	printf '=== xfree-toolbox ===\n'
	printf 'Версия:     %s\n' "$_ver"
	printf 'Обновления: %s\n' "$_upd_h"
	if [ -n "$_summary" ] && [ "$_summary" != "$_upd_h" ]; then
		printf 'Детали:     %s\n' "$_summary"
	fi
	if [ -n "$_channel" ]; then
		printf 'Канал:      %s\n' "$_channel"
	fi
	if [ -n "$_installed" ]; then
		printf 'Installed:  %s\n' "$_installed"
	fi
	if [ -n "$_available" ]; then
		printf 'Available:  %s\n' "$_available"
	fi
	if [ -n "$_checked" ]; then
		printf 'Проверено:  %s\n' "$_checked"
	else
		printf 'Проверено:  ещё не было (кнопка «Проверить» или CLI: xft → 2 → 1)\n'
	fi
	printf '\n'
	# Machine lines for LuCI overview parser
	printf 'TOOLBOX_VERSION=%s\n' "$_ver"
	printf 'TOOLBOX_UPDATE=%s\n' "$_update"
	printf 'TOOLBOX_UPDATE_LABEL=%s\n' "$_upd_h"
	printf 'TOOLBOX_CHANNEL=%s\n' "${_channel:-}"
	printf 'TOOLBOX_AVAILABLE=%s\n' "${_available:-}"
	printf 'TOOLBOX_CHECKED_AT=%s\n' "${_checked:-}"
	printf 'TOOLBOX_SUMMARY=%s\n' "$_summary"
}

toolbox_status_run_check() {
	_out=""
	_rc=0
	_tmp=""
	[ -f "$SELF_UPDATE_SH" ] || {
		printf 'Нет %s\n' "$SELF_UPDATE_SH" >&2
		return 1
	}
	_tmp="$(mktemp 2>/dev/null || mktemp -t xfree-tb-check)"
	_rc=0
	sh "$SELF_UPDATE_SH" --check-only --silent >"$_tmp" 2>&1 || _rc=$?
	_out="$(cat "$_tmp" 2>/dev/null || true)"
	rm -f "$_tmp"
	toolbox_status_parse_check_out "$_out" "$_rc"
	_when="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"
	toolbox_status_write "$TB_LOCAL" "$TB_CHANNEL" "$TB_UPDATE" \
		"$TB_INSTALLED" "$TB_AVAILABLE" "$TB_SUMMARY" "$_when"
	printf '%s\n' "$_out"
	printf '\n'
	toolbox_status_print
	# Report always succeeds for LuCI; UPDATE=* carries the state.
	return 0
}

toolbox_status_run_upgrade() {
	[ -f "$SELF_UPDATE_SH" ] || {
		printf 'Нет %s\n' "$SELF_UPDATE_SH" >&2
		return 1
	}
	printf '=== Обновление xfree-toolbox ===\n'
	sh "$SELF_UPDATE_SH" --preserve-profiles --silent
	_rc=$?
	# Refresh cache after upgrade attempt
	toolbox_status_run_check >/dev/null 2>&1 || true
	return "$_rc"
}

case "$MODE" in
'' | --status | status)
	toolbox_status_print
	;;
--check | check)
	toolbox_status_run_check
	;;
--upgrade | upgrade)
	toolbox_status_run_upgrade
	;;
*)
	printf 'usage: %s [--status|--check|--upgrade]\n' "$(basename -- "$0")" >&2
	exit 2
	;;
esac
