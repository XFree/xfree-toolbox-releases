#!/bin/sh
# System performance & resilience tuning for xfree-toolbox / OpenWrt
# - Dynamically tunes uhttpd max_requests based on router RAM (/proc/meminfo)
# - Ensures holdoff=30 on PPPoE WAN to prevent flapping storms
# - Ensures rpcd timeout=180
# - Patches telemt respawn to prevent 100% CPU lock on outage
# - Fast-filters netdev-* modprobe calls so offline tunnels never cause kernel D-state
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"

tune_uhttpd() {
    if ! command -v uci >/dev/null 2>&1 || ! uci -q get uhttpd.main >/dev/null 2>&1; then
        return 0
    fi

    _mem_kb="$(awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null || echo 0)"
    case "$_mem_kb" in
        ''|*[!0-9]*) _mem_kb=0 ;;
    esac

    # Dynamic threshold:
    # >= 450 MB (512MB+ devices) -> 8 workers
    # >= 220 MB (256MB devices) -> 6 workers
    # < 220 MB (64-128MB devices) -> 3 workers (safe default)
    _target_requests=3
    if [ "$_mem_kb" -ge 450000 ]; then
        _target_requests=8
    elif [ "$_mem_kb" -ge 220000 ]; then
        _target_requests=6
    fi

    _current="$(uci -q get uhttpd.main.max_requests || echo "")"
    if [ "$_current" != "$_target_requests" ]; then
        echo "[*] uhttpd: тюнинг max_requests=$_target_requests (RAM: $((_mem_kb / 1024)) MB, было: ${_current:-дефолт})"
        uci set uhttpd.main.max_requests="$_target_requests"
        uci commit uhttpd 2>/dev/null || true
        [ -x /etc/init.d/uhttpd ] && /etc/init.d/uhttpd reload >/dev/null 2>&1 || true
    fi
}

tune_pppoe_wan() {
    if ! command -v uci >/dev/null 2>&1; then
        return 0
    fi

    _proto="$(uci -q get network.wan.proto || echo "")"
    if [ "$_proto" = "pppoe" ]; then
        _current_holdoff="$(uci -q get network.wan.holdoff || echo 0)"
        case "$_current_holdoff" in
            ''|*[!0-9]*) _current_holdoff=0 ;;
        esac
        if [ "$_current_holdoff" -lt 30 ]; then
            echo "[*] network.wan (pppoe): установка holdoff=30 для защиты от шторма при авариях провайдера"
            uci set network.wan.holdoff=30
            uci commit network 2>/dev/null || true
        fi
    fi
}

tune_rpcd() {
    if ! command -v uci >/dev/null 2>&1 || ! uci -q get rpcd.@rpcd[0] >/dev/null 2>&1; then
        return 0
    fi

    _cur_to="$(uci -q get rpcd.@rpcd[0].timeout || echo 30)"
    case "$_cur_to" in
        ''|*[!0-9]*) _cur_to=30 ;;
    esac
    if [ "$_cur_to" -lt 180 ]; then
        echo "[*] rpcd: таймаут увеличен до 180s"
        uci set rpcd.@rpcd[0].timeout=180
        uci commit rpcd 2>/dev/null || true
        [ -x /etc/init.d/rpcd ] && /etc/init.d/rpcd reload >/dev/null 2>&1 || true
    fi
}

tune_telemt() {
    if [ -f /etc/init.d/telemt ]; then
        if grep -q 'respawn 3600 30 0' /etc/init.d/telemt 2>/dev/null; then
            echo "[*] telemt: патч respawn 3600 60 5 для защиты от 100% CPU при аварии WAN"
            sed -i 's/respawn 3600 30 0/respawn 3600 60 5/' /etc/init.d/telemt 2>/dev/null || true
        fi
    fi
}

tune_netdev_modprobe() {
    # OpenWrt kmodloader scans the entire module tree on every phantom netdev-* request.
    # Virtual tunnels (WireGuard, AmneziaWG, OpenVPN) never have netdev-*.ko drivers.
    # A lightweight filter wrapper ensures netdev-* exits immediately with 0.
    # IMPORTANT: kmodloader dispatches based on argv[0] == "modprobe". When wrapping,
    # we must use 'exec -a modprobe /sbin/kmodloader "$@"' so kmodloader acts as modprobe.
    if [ -f /sbin/modprobe ] && [ ! -L /sbin/modprobe ]; then
        if grep -q 'netdev-' /sbin/modprobe 2>/dev/null && grep -q 'exec -a modprobe' /sbin/modprobe 2>/dev/null; then
            return 0
        fi
    fi

    if [ -x /sbin/kmodloader ]; then
        echo "[*] modprobe: установка быстрого фильтра netdev-* для защиты от зависаний ядром"
        cat << 'EOF' > /sbin/modprobe.new
#!/bin/sh
case "$*" in
    *netdev-*) exit 0 ;;
esac
exec -a modprobe /sbin/kmodloader "$@"
EOF
        chmod 755 /sbin/modprobe.new
        mv /sbin/modprobe.new /sbin/modprobe
    fi
}

main() {
    tune_uhttpd
    tune_pppoe_wan
    tune_rpcd
    tune_telemt
    tune_netdev_modprobe
}

main "$@"
