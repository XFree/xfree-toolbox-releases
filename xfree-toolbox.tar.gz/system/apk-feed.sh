#!/bin/sh
# shellcheck shell=sh
# Enable/disable xfree apk feed and switch Nextcloud / GitHub source.
#
# Usage:
#   apk-feed.sh status
#   apk-feed.sh enable [--no-update]
#   apk-feed.sh disable [--no-update]
#   apk-feed.sh source cloud|github [--no-update]
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/apk-registry.sh"

DO_UPDATE=1

usage() {
	cat <<EOF
Usage: $(basename "$0") status|enable|disable|source [--no-update]

  status              файл фида, источник (Nextcloud/GitHub), pubkey
  enable              раскомментировать URL выбранного источника
  disable             закомментировать URL (apk update больше не ждёт фид)
  source cloud|github  источник packages.adb (overlay \$XFREE_STATE_ROOT/apk-feed.env)

  --no-update         не вызывать apk update

Ключ /etc/apk/keys/xfree-toolbox.pub при выключении не трогаем.
OpenWrt 24 (нет apk): меняется только файл списка, если он есть.
EOF
}

apk_feed_cli_update() {
	[ "$DO_UPDATE" = "1" ] || {
		echo "[*] apk update пропущен (--no-update)"
		return 0
	}
	if ! command -v apk >/dev/null 2>&1; then
		echo "[*] apk нет — обновлён только файл фида (OpenWrt 24?)"
		return 0
	fi
	echo "[*] apk update"
	apk update
}

cmd_status() {
	xfree_apk_feed_load_state
	_repo="$(xfree_apk_registry_repo_file)"
	_pub="$(xfree_apk_registry_pubkey_file)"
	_url="$(xfree_apk_feed_active_url 2>/dev/null || true)"
	_en='выкл'
	xfree_apk_feed_is_enabled && _en='вкл'
	echo "[*] Фид xfree: $_en"
	echo "[*] Источник: $(xfree_apk_feed_source_label) ($XFREE_APK_FEED_SOURCE)"
	echo "[*] URL: ${_url:-<не задан>}"
	echo "[*] Список: $_repo"
	if [ -f "$_repo" ]; then
		echo "---"
		cat "$_repo"
		echo "---"
	else
		echo "[*] Список отсутствует"
	fi
	if [ -f "$_pub" ]; then
		echo "[*] Pubkey: $_pub"
	else
		echo "[*] Pubkey нет: $_pub"
	fi
}

cmd_enable() {
	if ! xfree_apk_feed_enable; then
		echo "[-] Не удалось включить фид (проверьте XFREE_APK_FEED_PUBLIC_BASE / GitHub URL)" >&2
		return 1
	fi
	echo "[+] Фид включён: $(xfree_apk_feed_active_url)"
	apk_feed_cli_update
}

cmd_disable() {
	if ! xfree_apk_feed_disable; then
		echo "[-] Не удалось выключить фид" >&2
		return 1
	fi
	echo "[+] Фид выключен (строка в $(xfree_apk_registry_repo_file) закомментирована)"
	echo "[*] Ключ подписи не удалялся"
	apk_feed_cli_update
}

cmd_source() {
	_src="${1:-}"
	case "$_src" in
		cloud|github) ;;
		*)
			echo "[-] source: укажите cloud или github" >&2
			return 1
			;;
	esac
	if ! xfree_apk_feed_set_source "$_src"; then
		echo "[-] Не удалось сменить источник на $_src" >&2
		return 1
	fi
	echo "[+] Источник фида: $(xfree_apk_feed_source_label) ($_src)"
	echo "[*] URL: $(xfree_apk_feed_active_url)"
	if xfree_apk_feed_is_enabled; then
		apk_feed_cli_update
	else
		echo "[*] Фид выключен — apk update не вызывался"
	fi
}

args=""
src_arg=""
for arg in "$@"; do
	case "$arg" in
		--no-update) DO_UPDATE=0 ;;
		-h|--help|help) usage; exit 0 ;;
		status|enable|disable)
			[ -z "$args" ] || {
				usage >&2
				exit 1
			}
			args="$arg"
			;;
		source)
			[ -z "$args" ] || {
				usage >&2
				exit 1
			}
			args="source"
			;;
		cloud|github)
			src_arg="$arg"
			;;
		*)
			echo "[!] Unknown argument: $arg" >&2
			usage >&2
			exit 1
			;;
	esac
done

case "${args:-}" in
	status) cmd_status ;;
	enable) cmd_enable ;;
	disable) cmd_disable ;;
	source) cmd_source "$src_arg" ;;
	*)
		usage >&2
		exit 1
		;;
esac
