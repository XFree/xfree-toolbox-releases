#!/bin/sh
# shellcheck shell=sh
# Cron install/remove для auto-update-run.sh.
#
# Usage:
#   auto-update-cron.sh install
#   auto-update-cron.sh remove
#   auto-update-cron.sh status
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

export AUTO_UPDATE_ROOT_DIR="$ROOT_DIR"
export XFREE_TOOLBOX_ROOT="$ROOT_DIR"

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/auto-update-lib.sh"

usage() {
	cat <<EOF
Usage: $(basename "$0") install|remove|status

  install — cron по SCHEDULE_* из $(auto_update_conf_path)
  remove  — убрать задачу
  status  — crontab + конфиг
EOF
}

cmd_install() {
	if auto_update_cron_install; then
		auto_update_load_config
		echo "[+] auto-update: cron установлен (${AUTO_UPDATE_SCHEDULE_HOUR}:${AUTO_UPDATE_SCHEDULE_MINUTE}, MODE=$AUTO_UPDATE_MODE)"
		return 0
	fi
	echo "[-] auto-update: не удалось установить cron" >&2
	return 1
}

cmd_remove() {
	if auto_update_cron_remove; then
		echo "[+] auto-update: cron снят, ENABLED=0"
		return 0
	fi
	echo "[-] auto-update: не удалось снять cron" >&2
	return 1
}

cmd_status() {
	auto_update_status_text
	printf '\n--- crontab (auto-update lines) ---\n'
	auto_update_crontab_read | grep -F 'auto-update' || printf '(нет)\n'
}

case "${1:-}" in
	install) cmd_install ;;
	remove) cmd_remove ;;
	status) cmd_status ;;
	-h|--help|help) usage ;;
	*)
		usage >&2
		exit 1
		;;
esac
