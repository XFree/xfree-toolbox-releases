#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"

: "${XFREE_STATE_ROOT:=/etc/xfree-toolbox}"
: "${XFREE_BACKUP_ROOT:=${BACKUP_ROOT:-$XFREE_STATE_ROOT/backups}}"
: "${BACKUP_KEEP:=$(common_backup_keep)}"
: "${INSTALL_BACKUP_KEEP:=$BACKUP_KEEP}"

MODE="preview"
ACTION=""
QUIET="${QUIET:-0}"

usage() {
    cat <<EOF
Usage: $(common_basename) --action rotate|cleanup|purge [--preview|--apply] [--quiet]
EOF
}

while [ $# -gt 0 ]; do
    case "$1" in
        --action)
            ACTION="${2:-}"
            shift 2
            ;;
        --preview)
            MODE="preview"
            shift
            ;;
        --apply)
            MODE="apply"
            shift
            ;;
        --quiet)
            QUIET=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            error "Неизвестный аргумент: $1"
            usage
            exit 1
            ;;
    esac
done

case "$ACTION" in
    rotate|cleanup|purge) ;;
    *)
        error "Нужно указать --action rotate|cleanup|purge"
        usage
        exit 1
        ;;
esac

case "$BACKUP_KEEP" in
    ''|*[!0-9]*) BACKUP_KEEP=2 ;;
esac
[ "$BACKUP_KEEP" -ge 0 ] || BACKUP_KEEP=2

case "$INSTALL_BACKUP_KEEP" in
    ''|*[!0-9]*) INSTALL_BACKUP_KEEP=2 ;;
esac
[ "$INSTALL_BACKUP_KEEP" -ge 0 ] || INSTALL_BACKUP_KEEP=2

TMP_ROOT="$(mktemp -d)"
trap 'rm -rf "$TMP_ROOT"' EXIT INT TERM
ITEMS_FILE="$TMP_ROOT/items.lst"
: > "$ITEMS_FILE"

say_mode() {
    [ "$QUIET" = "1" ] && return 0
    printf '%s\n' "$*"
}

append_items_from_pattern() {
    parent_dir="$1"
    pattern="$2"
    label="$3"
    keep_count="${4:-$BACKUP_KEEP}"

    [ -d "$parent_dir" ] || return 0
    [ -n "$pattern" ] || return 0

    tmp_matches="$TMP_ROOT/matches.$$"
    find "$parent_dir" -mindepth 1 -maxdepth 1 -name "$pattern" 2>/dev/null | sort -r > "$tmp_matches" || true
    if [ ! -s "$tmp_matches" ]; then
        rm -f "$tmp_matches"
        return 0
    fi

    awk -v keep="$keep_count" 'NR > keep { print }' "$tmp_matches" | while IFS= read -r candidate; do
        [ -n "$candidate" ] || continue
        printf '%s|%s\n' "$label" "$candidate" >> "$ITEMS_FILE"
    done
    rm -f "$tmp_matches"
}

append_items_cleanup_router_junk() {
    new_install_dir="${XFREE_ROOT_DIR:-/root/xfree-toolbox}"

    # Dev/accidental trees inside live toolbox directory on router
    if [ -d "$new_install_dir" ]; then
        for sub in \
            "mgmt-hub/src" \
            "mgmt-hub/.venv" \
            "mgmt-hub/vm" \
            "mgmt-hub/windows" \
            "mgmt-hub/data" \
            "profile-generator" \
            "profile-generator-label" \
            ".tmp-luci-shots" \
            "ci" \
            "agents" \
            "docs" \
            ".cursor" \
            ".idea" \
            ".vscode" \
            ".forgejo" \
            ".githooks"
        do
            [ -e "$new_install_dir/$sub" ] || continue
            printf '%s|%s\n' "router junk ($sub)" "$new_install_dir/$sub" >> "$ITEMS_FILE"
        done

        # Unit test directories inside live toolbox directory on router
        find "$new_install_dir" -type d -name "tests" 2>/dev/null | while IFS= read -r tdir; do
            [ -n "$tdir" ] || continue
            printf '%s|%s\n' "router tests ($tdir)" "$tdir" >> "$ITEMS_FILE"
        done

        # Legacy profile templates removed from repository
        for old_tpl in "default" "default-with-proton" "default-with-proton-ai"; do
            [ -d "$new_install_dir/profile-templates/$old_tpl" ] || continue
            printf '%s|%s\n' "legacy profile template ($old_tpl)" "$new_install_dir/profile-templates/$old_tpl" >> "$ITEMS_FILE"
        done
    fi

    # Unused legacy upstream dumps in /opt/zapret/ipset
    for zdump in \
        "/opt/zapret/ipset/ipset-discord.txt" \
        "/opt/zapret/ipset/ipset-roblox.txt"
    do
        [ -f "$zdump" ] || continue
        printf '%s|%s\n' "unused zapret dump" "$zdump" >> "$ITEMS_FILE"
    done

    # Stray temporary files in install root
    find "${ROUTER_BACKUP_ROOT:-/root}" -maxdepth 1 -name ".tmp*" 2>/dev/null | while IFS= read -r tmpf; do
        [ -n "$tmpf" ] || continue
        printf '%s|%s\n' "stray temp file" "$tmpf" >> "$ITEMS_FILE"
    done
}

append_items_cleanup_legacy() {
    # Legacy backup storages moved by migration to canonical backup root.
    for p in \
        "/etc/xfree-utils/backups" \
        "/etc/domain-routing/backup" \
        "/etc/xfree-utils/domain-routing/backup" \
        "${XFREE_STATE_ROOT}/domain-routing/backup"
    do
        [ -e "$p" ] || continue
        printf '%s|%s\n' "legacy backup storage" "$p" >> "$ITEMS_FILE"
    done

    # Legacy suffixes in canonical backup roots.
    append_items_from_pattern "$XFREE_BACKUP_ROOT/iface-routing" "*.dir" "legacy iface-routing *.dir" "0"
    append_items_from_pattern "$XFREE_BACKUP_ROOT/install" "*.legacy.*.dir" "legacy install *.dir" "0"
    append_items_from_pattern "$XFREE_BACKUP_ROOT/zapret" "*.bak" "legacy zapret *.bak" "0"

    append_items_cleanup_router_junk
}

append_items_install_snapshots() {
    # $1 = keep count (BACKUP_KEEP for rotate, 0 for full purge)
    keep_count="${1:-$BACKUP_KEEP}"
    install_backup_root="${ROUTER_BACKUP_ROOT:-/root}"
    new_install_dir="${XFREE_ROOT_DIR:-/root/xfree-toolbox}"
    legacy_install_dir="${LEGACY_INSTALL_DIR:-/root/xfree-utils}"
    new_install_base="$(basename -- "$new_install_dir")"
    legacy_install_base="$(basename -- "$legacy_install_dir")"

    # self-update / install-from-cloud: /root/xfree-toolbox.backup.YYYYMMDD-HHMMSS
    append_items_from_pattern "$install_backup_root" "$new_install_base.backup.*" "install .backup snapshots" "$keep_count"
    append_items_from_pattern "$install_backup_root" "$legacy_install_base.backup.*" "legacy install .backup snapshots" "$keep_count"
    # older deploy naming without ".backup." infix
    append_items_from_pattern "$install_backup_root" "$new_install_base.[0-9]*-[0-9]*" "deploy backups" "$keep_count"
    append_items_from_pattern "$install_backup_root" "$new_install_base.self-update.*" "self-update backups" "$keep_count"
    append_items_from_pattern "$install_backup_root" "$legacy_install_base.[0-9]*-[0-9]*" "legacy deploy backups" "$keep_count"
    append_items_from_pattern "$install_backup_root" "$legacy_install_base.self-update.*" "legacy self-update backups" "$keep_count"
}

append_items_rotate_known_families() {
    append_items_install_snapshots "$INSTALL_BACKUP_KEEP"
    append_items_from_pattern "$XFREE_BACKUP_ROOT/iface-routing" "runtime.*" "iface-routing runtime backups"
    append_items_from_pattern "$XFREE_BACKUP_ROOT/iface-routing" "network.before.*" "network.before uci backups"
    append_items_from_pattern "$XFREE_BACKUP_ROOT/iface-routing" "firewall.before.*" "firewall.before uci backups"
    append_items_from_pattern "$XFREE_BACKUP_ROOT/install" "*.legacy.*" "migration install backups"
    append_items_from_pattern "$XFREE_BACKUP_ROOT/zapret" "ipset.*" "zapret ipset backups"
    append_items_cleanup_router_junk
}

append_items_purge_all_backups() {
    # State backups under /etc/xfree-toolbox/backups
    if [ -d "$XFREE_BACKUP_ROOT" ]; then
        find "$XFREE_BACKUP_ROOT" -mindepth 1 -maxdepth 1 2>/dev/null | sort | while IFS= read -r candidate; do
            [ -n "$candidate" ] || continue
            printf '%s|%s\n' "full backup purge" "$candidate" >> "$ITEMS_FILE"
        done
    fi
    # Install snapshots next to live tree (/root/xfree-toolbox.backup.*) — often the bulk of overlay use
    append_items_install_snapshots 0
    append_items_cleanup_router_junk
}

if [ "$ACTION" = "rotate" ]; then
    append_items_rotate_known_families
elif [ "$ACTION" = "purge" ]; then
    append_items_purge_all_backups
else
    append_items_cleanup_legacy
fi

if [ ! -s "$ITEMS_FILE" ]; then
    say_mode "[*] Нечего удалять: action=$ACTION, mode=$MODE"
    exit 0
fi

say_mode "[*] Backup root: $XFREE_BACKUP_ROOT"
say_mode "[*] Install snapshots: ${ROUTER_BACKUP_ROOT:-/root}/$(basename -- "${XFREE_ROOT_DIR:-/root/xfree-toolbox}").backup.*"
say_mode "[*] BACKUP_KEEP: $BACKUP_KEEP"
say_mode "[*] action: $ACTION"
say_mode "[*] mode: $MODE"
say_mode ""
say_mode "[*] Кандидаты на удаление:"

awk -F'|' '{ printf "  - [%s] %s\n", $1, $2 }' "$ITEMS_FILE"
total_count="$(awk 'END{print NR}' "$ITEMS_FILE")"
say_mode ""
say_mode "[*] Итого кандидатов: $total_count"

[ "$MODE" = "apply" ] || exit 0

awk -F'|' '{ print $2 }' "$ITEMS_FILE" | while IFS= read -r target; do
    [ -n "$target" ] || continue
    if [ -d "$target" ] && [ ! -L "$target" ]; then
        rm -rf "$target"
    else
        rm -f "$target"
    fi
done

say_mode "[✓] Удаление завершено. Удалено: $total_count"
