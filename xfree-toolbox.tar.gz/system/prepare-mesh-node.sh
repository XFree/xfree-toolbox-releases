#!/bin/sh
# shellcheck shell=sh
# Mesh/AP satellite: stop extra services. Does not create Wi-Fi or LAN.
# Reference node: dnsmasq, odhcpd, firewall disabled; operator builds mesh in LuCI.
set -eu

YES=0

usage() {
  cat <<USAGE
Usage: prepare-mesh-node.sh --yes

Отключает службы, не нужные на mesh-узле (satellite / dump AP):
  dnsmasq, odhcpd, firewall
  miniupnpd — если toolbox его включил

Wi-Fi, LAN, mesh iface не трогает. Сеть настраиваете сами.

  --yes  выполнить (без флага — только справка)
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    -h | --help)
      usage
      exit 0
      ;;
    *)
      echo "[!] Неизвестный параметр: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift
done

if [ "$YES" != "1" ]; then
  usage >&2
  exit 1
fi

mesh_disable_svc() {
  name="$1"
  if [ ! -x "/etc/init.d/$name" ]; then
    echo "[*] mesh-node: $name нет — пропуск"
    return 0
  fi
  /etc/init.d/"$name" stop 2>/dev/null || true
  /etc/init.d/"$name" disable 2>/dev/null || true
  echo "[ok] mesh-node: $name stop+disable"
}

for svc in dnsmasq odhcpd firewall miniupnpd; do
  mesh_disable_svc "$svc"
done

echo "[ok] mesh-node: лишние службы отключены (сеть не менялась)"
