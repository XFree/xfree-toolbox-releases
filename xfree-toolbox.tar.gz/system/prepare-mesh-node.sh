#!/bin/sh
# shellcheck shell=sh
# Mesh/AP satellite: stop extra services and join WAN into br-lan.
# Reference node: dnsmasq, odhcpd, firewall disabled; WAN joined to br-lan; DHCP ignored on LAN.
set -eu

YES=0
LAN_IP=""
GATEWAY=""
NO_RELOAD=0

usage() {
  cat <<USAGE
Usage: prepare-mesh-node.sh --yes [--lan-ip <ip>] [--gateway <ip>] [--no-reload]

Настройка узла для mesh / dumb AP:
  - Отключает службы: dnsmasq, odhcpd, firewall, miniupnpd
  - Отключает DHCP на LAN (dhcp.lan.ignore=1)
  - Добавляет физический порт WAN в bridge br-lan
  - Удаляет интерфейсы wan и wan6
  - Очищает правила трафика, forwardings, перенаправления и зону wan (defaults=ACCEPT)
  - Опционально: устанавливает новый статический LAN IP и шлюз/DNS

Wi-Fi и 802.11s mesh настраиваются оператором в LuCI или configure-mesh.sh.

  --yes           выполнить (без флага — только справка)
  --lan-ip <ip>   новый статический IP адрес LAN (напр. 192.168.10.2)
  --gateway <ip>  шлюз по умолчанию и DNS (основной роутер)
  --no-reload     не перезапускать сеть немедленно (перезапуск выполнит родитель)
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --no-reload) NO_RELOAD=1 ;;
    --lan-ip)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --lan-ip" >&2; exit 1; }
      LAN_IP="$2"
      shift
      ;;
    --gateway)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --gateway" >&2; exit 1; }
      GATEWAY="$2"
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    *)
      echo "[!] Неизвестный параметр: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
  shift
done

if [ "$YES" != "1" ]; then
  usage >&2
  exit 1
fi

mesh_disable_svc() {
  name="$1"
  if [ ! -x "/etc/init.d/$name" ]; then
    echo "[*] mesh-node: $name нет — пропуск"
    return 0
  fi
  /etc/init.d/"$name" stop 2>/dev/null || true
  /etc/init.d/"$name" disable 2>/dev/null || true
  echo "[ok] mesh-node: $name stop+disable"
}

mesh_configure_dhcp() {
  command -v uci >/dev/null 2>&1 || return 0
  [ -f /etc/config/dhcp ] || return 0

  if uci -q get dhcp.lan >/dev/null 2>&1; then
    uci set dhcp.lan.ignore='1'
    uci commit dhcp
    echo "[ok] mesh-node: dhcp.lan.ignore=1 (отключение DHCP на LAN)"
  fi
}

mesh_configure_network_ports() {
  command -v uci >/dev/null 2>&1 || return 0
  [ -f /etc/config/network ] || return 0

  # 1. Определяем физический порт WAN
  wan_dev="$(uci -q get network.wan.device || true)"
  [ -z "$wan_dev" ] && wan_dev="$(uci -q get network.wan.ifname || true)"
  [ -z "$wan_dev" ] && wan_dev="$(uci -q get network.wan6.device || true)"
  [ -z "$wan_dev" ] && wan_dev="$(uci -q get network.wan6.ifname || true)"
  if [ -z "$wan_dev" ] && [ -e /sys/class/net/wan ]; then
    wan_dev="wan"
  fi
  [ -n "$wan_dev" ] || wan_dev="wan"

  # 2. Добавляем порт WAN в bridge br-lan
  br_sec=""
  for sec in $(uci show network 2>/dev/null | grep -E "=device$" | cut -d= -f1); do
    if [ "$(uci -q get "${sec}.name")" = "br-lan" ]; then
      br_sec="$sec"
      break
    fi
  done

  added_to_bridge=0
  if [ -n "$br_sec" ]; then
    in_bridge=0
    for p in $(uci -q get "${br_sec}.ports"); do
      if [ "$p" = "$wan_dev" ]; then
        in_bridge=1
        break
      fi
    done
    if [ "$in_bridge" = "0" ]; then
      uci add_list "${br_sec}.ports=$wan_dev"
      added_to_bridge=1
    fi
  elif [ "$(uci -q get network.lan.type)" = "bridge" ]; then
    in_bridge=0
    for p in $(uci -q get network.lan.ifname); do
      if [ "$p" = "$wan_dev" ]; then
        in_bridge=1
        break
      fi
    done
    if [ "$in_bridge" = "0" ]; then
      uci add_list network.lan.ifname="$wan_dev"
      added_to_bridge=1
    fi
  fi

  if [ "$added_to_bridge" = "1" ]; then
    echo "[ok] mesh-node: порт '$wan_dev' добавлен в bridge br-lan"
  else
    echo "[*] mesh-node: порт '$wan_dev' уже в bridge br-lan"
  fi

  # 3. Удаляем логические интерфейсы wan и wan6
  deleted_wan=0
  if uci -q get network.wan >/dev/null 2>&1; then
    uci -q delete network.wan
    deleted_wan=1
  fi
  if uci -q get network.wan6 >/dev/null 2>&1; then
    uci -q delete network.wan6
    deleted_wan=1
  fi

  # 4. Если задан новый LAN IP
  cur_lan_ip="$(uci -q get network.lan.ipaddr || true)"
  ip_changed=0
  if [ -n "$LAN_IP" ]; then
    if [ "$cur_lan_ip" != "$LAN_IP" ]; then
      uci set network.lan.ipaddr="$LAN_IP"
      ip_changed=1
      echo "[ok] mesh-node: LAN IP изменён $cur_lan_ip -> $LAN_IP"
    fi
    if [ -n "$GATEWAY" ]; then
      uci set network.lan.gateway="$GATEWAY"
      uci -q delete network.lan.dns 2>/dev/null || true
      uci add_list network.lan.dns="$GATEWAY"
      echo "[ok] mesh-node: шлюз и DNS направлены на $GATEWAY"
    fi
  fi

  uci commit network

  # Применяем изменения сети
  if [ "$NO_RELOAD" = "1" ]; then
    echo "[*] mesh-node: изменения сети записаны в UCI (перезапуск сети отложен)"
    return 0
  fi

  if [ "$ip_changed" = "1" ]; then
    echo "[*] mesh-node: смена IP запланирована (SSH переподключится по $LAN_IP)"
    (
      sleep 2
      if [ -x /sbin/ifdown ] && [ -x /sbin/ifup ]; then
        ifdown lan 2>/dev/null || true
        ifup lan 2>/dev/null || /etc/init.d/network reload
      else
        /etc/init.d/network reload
      fi
      if [ -x /etc/init.d/dropbear ]; then
        /etc/init.d/dropbear restart 2>/dev/null || true
      fi
    ) >/dev/null 2>&1 &
  elif [ -x /etc/init.d/network ]; then
    /etc/init.d/network reload 2>/dev/null || true
  fi
}

mesh_configure_firewall() {
  command -v uci >/dev/null 2>&1 || return 0
  [ -f /etc/config/firewall ] || return 0

  # 1. Удаляем ВСЕ forwardings через while delete (индексы сдвигаются)
  while uci -q delete firewall.@forwarding[0]; do :; done

  # 2. Удаляем ВСЕ traffic rules (правила трафика)
  while uci -q delete firewall.@rule[0]; do :; done

  # 3. Удаляем ВСЕ redirects (перенаправления портов)
  while uci -q delete firewall.@redirect[0]; do :; done

  # 4. Удаляем ВСЕ nat rules
  while uci -q delete firewall.@nat[0]; do :; done

  # 5. Удаляем именованную зону wan, если была
  uci -q delete firewall.wan 2>/dev/null || true

  # 6. Удаляем любые зоны кроме lan
  while true; do
    idx_to_del=""
    i=0
    while true; do
      z_name="$(uci -q get "firewall.@zone[$i].name" || true)"
      [ -n "$z_name" ] || break
      if [ "$z_name" != "lan" ]; then
        idx_to_del="$i"
        break
      fi
      i=$((i + 1))
    done
    [ -n "$idx_to_del" ] || break
    uci -q delete "firewall.@zone[$idx_to_del]"
  done

  # 7. Зону lan открываем полностью и очищаем ссылки на wan
  i=0
  while true; do
    z_name="$(uci -q get "firewall.@zone[$i].name" || true)"
    [ -n "$z_name" ] || break
    if [ "$z_name" = "lan" ]; then
      uci -q set "firewall.@zone[$i].input=ACCEPT"
      uci -q set "firewall.@zone[$i].output=ACCEPT"
      uci -q set "firewall.@zone[$i].forward=ACCEPT"
      uci -q delete "firewall.@zone[$i].out" 2>/dev/null || true
      uci -q delete "firewall.@zone[$i].out_zone" 2>/dev/null || true
      uci -q delete "firewall.@zone[$i].network" 2>/dev/null || true
      uci add_list "firewall.@zone[$i].network=lan"
    fi
    i=$((i + 1))
  done

  # 8. В defaults ставим прозрачный режим ACCEPT
  if uci -q get firewall.@defaults[0] >/dev/null 2>&1; then
    uci -q set firewall.@defaults[0].input='ACCEPT'
    uci -q set firewall.@defaults[0].output='ACCEPT'
    uci -q set firewall.@defaults[0].forward='ACCEPT'
    uci -q set firewall.@defaults[0].syn_flood='0'
  fi

  uci commit firewall

  # 9. Сброс кэша LuCI и reload firewall
  rm -f /tmp/luci-indexcache* /tmp/luci-modulecache/* 2>/dev/null || true
  if [ -x /sbin/luci-reload ]; then
    /sbin/luci-reload firewall 2>/dev/null || true
  fi
  if [ -x /etc/init.d/firewall ]; then
    /etc/init.d/firewall reload 2>/dev/null || /etc/init.d/firewall restart 2>/dev/null || true
  fi
  echo "[ok] mesh-node: правила трафика, forwardings, redirects и зона wan удалены, firewall перезагружен (ACCEPT)"
}

# Отключаем лишние службы
for svc in dnsmasq odhcpd firewall miniupnpd; do
  mesh_disable_svc "$svc"
done

# Настраиваем конфигурацию сателлита
mesh_configure_dhcp
mesh_configure_network_ports
mesh_configure_firewall

echo "[ok] mesh-node: узел сконфигурирован под mesh (WAN в br-lan, DHCP отключен, WAN firewall удалён)"
