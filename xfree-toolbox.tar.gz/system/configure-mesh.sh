#!/bin/sh
# shellcheck shell=sh
# Configure OpenWrt router for 802.11s mesh & Ethernet backhaul.
# Actions:
#   mesh-setup      - configure 802.11s mesh backhaul, 5GHz fixed channel, STP/IGMP snooping
#   mesh-disable    - disable 802.11s mesh interface (use wired Ethernet backhaul)
#   roaming-setup   - configure 802.11r/k/v fast roaming on selected (or all) Wi-Fi APs
#   roaming-disable - disable 802.11r fast roaming
#   master          - full master gateway configuration (mesh + roaming + STP)
#   satellite       - full dumb AP configuration (mesh + roaming + STP + bridge)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

ACTION=""
ROLE=""
MESH_ID=""
MESH_KEY=""
MOBILITY_DOMAIN=""
SSID_2G=""
KEY_2G=""
ENCRYPTION_2G=""
SSID_5G=""
KEY_5G=""
ENCRYPTION_5G=""
CHANNEL_5G=""
LAN_IP=""
GATEWAY=""
IFACES_LIST=""
SSIDS_LIST=""
YES=0

usage() {
  cat <<USAGE
Usage: configure-mesh.sh [action|--role master|satellite] [options]

Настройка роутера для 802.11s Mesh, Fast Roaming и Ethernet Backhaul.

Действия:
  --action <act>           действие: mesh-setup, mesh-disable, roaming-setup,
                           roaming-disable, master, satellite
  --role master|satellite  устаревший алиас для --action master|satellite

Параметры Fast Roaming (802.11r / 802.11k / 802.11v):
  --mobility-domain <hex>  4 hex-символа для 802.11r FT (напр. 4f2a)
  --ifaces <list>          список wifi-iface секций через запятую (напр. default_radio0,default_radio1)
  --ssids <list>           список SSID через запятую для участия в FT

Параметры Mesh и Wi-Fi бэкхола (802.11s):
  --mesh-id <id>           имя mesh-сети (по умолчанию: <ssid>-mesh)
  --mesh-key <key>         ключ WPA3-SAE для mesh (по умолчанию: Wi-Fi пароль)
  --channel-5g <chan>      фиксированный канал 5 GHz (напр. 36 или 44)
  --ssid-2g <ssid>         SSID для точки доступа 2.4 GHz
  --key-2g <key>           пароль для 2.4 GHz
  --encryption-2g <enc>    шифрование для 2.4 GHz
  --ssid-5g <ssid>         SSID для точки доступа 5 GHz
  --key-5g <key>           пароль для 5 GHz
  --encryption-5g <enc>    шифрование для 5 GHz

Параметры сателлита (только для satellite):
  --lan-ip <ip>            новый статический LAN IP (напр. 192.168.10.2)
  --gateway <ip>           шлюз и DNS (IP основного роутера, напр. 192.168.10.1)

Флаги:
  --yes                    выполнить без подтверждения
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --action)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --action" >&2; exit 1; }
      ACTION="$2"
      shift 2
      ;;
    --role)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --role" >&2; exit 1; }
      ROLE="$2"
      shift 2
      ;;
    --ifaces)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --ifaces" >&2; exit 1; }
      IFACES_LIST="$2"
      shift 2
      ;;
    --ssids)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --ssids" >&2; exit 1; }
      SSIDS_LIST="$2"
      shift 2
      ;;
    --mesh-id)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --mesh-id" >&2; exit 1; }
      MESH_ID="$2"
      shift 2
      ;;
    --mesh-key)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --mesh-key" >&2; exit 1; }
      MESH_KEY="$2"
      shift 2
      ;;
    --mobility-domain)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --mobility-domain" >&2; exit 1; }
      MOBILITY_DOMAIN="$2"
      shift 2
      ;;
    --ssid-2g)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --ssid-2g" >&2; exit 1; }
      SSID_2G="$2"
      shift 2
      ;;
    --key-2g)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --key-2g" >&2; exit 1; }
      KEY_2G="$2"
      shift 2
      ;;
    --encryption-2g)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --encryption-2g" >&2; exit 1; }
      ENCRYPTION_2G="$2"
      shift 2
      ;;
    --ssid-5g)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --ssid-5g" >&2; exit 1; }
      SSID_5G="$2"
      shift 2
      ;;
    --key-5g)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --key-5g" >&2; exit 1; }
      KEY_5G="$2"
      shift 2
      ;;
    --encryption-5g)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --encryption-5g" >&2; exit 1; }
      ENCRYPTION_5G="$2"
      shift 2
      ;;
    --channel-5g)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --channel-5g" >&2; exit 1; }
      CHANNEL_5G="$2"
      shift 2
      ;;
    --lan-ip)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --lan-ip" >&2; exit 1; }
      LAN_IP="$2"
      shift 2
      ;;
    --gateway)
      [ "$#" -ge 2 ] || { echo "[!] Требуется значение для --gateway" >&2; exit 1; }
      GATEWAY="$2"
      shift 2
      ;;
    --yes)
      YES=1
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    *)
      echo "[!] Неизвестный параметр: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

# Обратная совместимость с --role
if [ -z "$ACTION" ] && [ -n "$ROLE" ]; then
  ACTION="$ROLE"
fi

case "$ACTION" in
  master | satellite | mesh-setup | mesh-disable | roaming-setup | roaming-disable) ;;
  *)
    echo "[!] Не указано действие (--action mesh-setup|mesh-disable|roaming-setup|roaming-disable или --role master|satellite)" >&2
    usage >&2
    exit 1
    ;;
esac

if [ "$YES" != "1" ]; then
  usage >&2
  exit 1
fi

echo "=== Конфигурация беспроводной сети (действие: $ACTION) ==="

# 0. Проверка наличия пакета wpad-mesh-mbedtls (только если настраиваем mesh)
if [ "$ACTION" = "master" ] || [ "$ACTION" = "satellite" ] || [ "$ACTION" = "mesh-setup" ]; then
  if command -v apk >/dev/null 2>&1; then
    if ! apk info -e wpad-mesh-mbedtls >/dev/null 2>&1; then
      echo "[!] ВНИМАНИЕ: wpad-mesh-mbedtls не установлен! (802.11s и WPA3-SAE не поднимутся)" >&2
      echo "[!] Установите: system/install-wpad-mesh.sh --yes" >&2
    fi
  elif command -v opkg >/dev/null 2>&1; then
    if ! opkg list-installed wpad-mesh-mbedtls 2>/dev/null | grep -q '^wpad-mesh-mbedtls'; then
      echo "[!] ВНИМАНИЕ: wpad-mesh-mbedtls не установлен! (802.11s и WPA3-SAE не поднимутся)" >&2
      echo "[!] Установите: system/install-wpad-mesh.sh --yes" >&2
    fi
  fi
fi

# 1. Если действие satellite — вызываем базовую подготовку сателлита
if [ "$ACTION" = "satellite" ]; then
  echo "[*] Подготовка сателлита: WAN в br-lan, отключение DHCP, firewall..."
  _prep_sh="$SCRIPT_DIR/prepare-mesh-node.sh"
  [ -f "$_prep_sh" ] || { echo "[-] не найден $_prep_sh" >&2; exit 1; }
  _prep_args="--yes --no-reload"
  [ -n "$LAN_IP" ] && _prep_args="$_prep_args --lan-ip $LAN_IP"
  [ -n "$GATEWAY" ] && _prep_args="$_prep_args --gateway $GATEWAY"
  # shellcheck disable=SC2086
  sh "$_prep_sh" $_prep_args
fi

# 2. Настройка br-lan: включение STP и IGMP Snooping
if [ "$ACTION" = "master" ] || [ "$ACTION" = "satellite" ] || [ "$ACTION" = "mesh-setup" ] || [ "$ACTION" = "roaming-setup" ]; then
  if command -v uci >/dev/null 2>&1 && [ -f /etc/config/network ]; then
    br_sec=""
    for sec in $(uci show network 2>/dev/null | grep -E "=device$" | cut -d= -f1); do
      if [ "$(uci -q get "${sec}.name")" = "br-lan" ]; then
        br_sec="$sec"
        break
      fi
    done
    if [ -n "$br_sec" ]; then
      uci -q set "${br_sec}.stp=1"
      uci -q set "${br_sec}.igmp_snooping=1"
      uci commit network
      echo "[ok] br-lan: STP=1 (защита от петель backhaul), IGMP Snooping=1"
    fi
  fi
fi

in_comma_list() {
  _val="$1"
  _list="$2"
  case ",${_list}," in
    *",${_val},"*) return 0 ;;
    *) return 1 ;;
  esac
}

norm_band() {
  _b="$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]')"
  case "$_b" in
    2.4g | 2g | 2ghz) printf '2g' ;;
    5g | 5ghz) printf '5g' ;;
    *) printf '%s' "$_b" ;;
  esac
}

radio_band() {
  _r="$1"
  _b="$(uci -q get "wireless.$_r.band" 2>/dev/null || true)"
  if [ -z "$_b" ]; then
    _ht="$(uci -q get "wireless.$_r.htmode" 2>/dev/null || true)"
    case "$_ht" in
      *VHT* | *HE* | *EHT*) _b="5g" ;;
      *) _b="2g" ;;
    esac
  fi
  norm_band "$_b"
}

if command -v uci >/dev/null 2>&1 && [ -f /etc/config/wireless ]; then
  radio_5g=""
  radio_2g=""

  for r in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-device$/\1/p' | cut -d. -f2); do
    b="$(radio_band "$r")"
    if [ "$b" = "5g" ] && [ -z "$radio_5g" ]; then
      radio_5g="$r"
    elif [ "$b" = "2g" ] && [ -z "$radio_2g" ]; then
      radio_2g="$r"
    fi
  done

  # Считываем существующие параметры AP и Mesh из UCI
  _cur_ssid_5g="" _cur_key_5g="" _cur_enc_5g=""
  _cur_ssid_2g="" _cur_key_2g="" _cur_enc_2g=""
  _cur_mobility_domain=""
  mesh_sec=""

  for iface in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-iface$/\1/p' | cut -d. -f2); do
    _m="$(uci -q get "wireless.$iface.mode" || true)"
    if [ "$_m" = "mesh" ]; then
      mesh_sec="$iface"
    elif [ "$_m" = "ap" ]; then
      _d="$(uci -q get "wireless.$iface.device" || true)"
      _b="$(radio_band "$_d")"
      _mob="$(uci -q get "wireless.$iface.mobility_domain" || true)"
      [ -n "$_mob" ] && [ -z "$_cur_mobility_domain" ] && _cur_mobility_domain="$_mob"

      if [ "$_b" = "5g" ] && [ -z "$_cur_ssid_5g" ]; then
        _cur_ssid_5g="$(uci -q get "wireless.$iface.ssid" || true)"
        _cur_key_5g="$(uci -q get "wireless.$iface.key" || true)"
        _cur_enc_5g="$(uci -q get "wireless.$iface.encryption" || true)"
      elif [ "$_b" = "2g" ] && [ -z "$_cur_ssid_2g" ]; then
        _cur_ssid_2g="$(uci -q get "wireless.$iface.ssid" || true)"
        _cur_key_2g="$(uci -q get "wireless.$iface.key" || true)"
        _cur_enc_2g="$(uci -q get "wireless.$iface.encryption" || true)"
      fi
    fi
  done

  # Подхватываем существующие значения если аргументы CLI не заданы
  [ -z "$SSID_5G" ] && SSID_5G="$_cur_ssid_5g"
  [ -z "$KEY_5G" ] && KEY_5G="$_cur_key_5g"
  [ -z "$ENCRYPTION_5G" ] && ENCRYPTION_5G="$_cur_enc_5g"
  [ -z "$SSID_2G" ] && SSID_2G="$_cur_ssid_2g"
  [ -z "$KEY_2G" ] && KEY_2G="$_cur_key_2g"
  [ -z "$ENCRYPTION_2G" ] && ENCRYPTION_2G="$_cur_enc_2g"

  if [ -z "$MESH_ID" ] && [ -n "$mesh_sec" ]; then
    MESH_ID="$(uci -q get "wireless.$mesh_sec.mesh_id" || true)"
  fi
  if [ -z "$MESH_KEY" ] && [ -n "$mesh_sec" ]; then
    MESH_KEY="$(uci -q get "wireless.$mesh_sec.key" || true)"
  fi
  if [ -z "$MOBILITY_DOMAIN" ]; then
    MOBILITY_DOMAIN="$_cur_mobility_domain"
  fi

  # Если mesh_id всё ещё не задан — формируем из базового SSID
  if [ -z "$MESH_ID" ]; then
    base_ssid="${SSID_5G:-${SSID_2G:-openwrt}}"
    case "$base_ssid" in
      *-5G | *_5G | *-5g | *_5g) base_ssid="${base_ssid%[_-][55][Gg]}" ;;
      *-2.4G | *_2.4G | *-2.4g | *_2.4g) base_ssid="${base_ssid%[_-]2.4[Gg]}" ;;
      *-2G | *_2G | *-2g | *_2g) base_ssid="${base_ssid%[_-]2[Gg]}" ;;
    esac
    MESH_ID="${base_ssid}-MESH"
  fi
  [ -n "$MESH_KEY" ] || MESH_KEY="${KEY_5G:-${KEY_2G:-mesh12345678}}"

  # Если mobility_domain всё ещё не задан — генерируем (4 hex-символа) от MESH_ID
  if [ -z "$MOBILITY_DOMAIN" ]; then
    _seed="${MESH_ID:-${SSID_5G:-${SSID_2G:-mesh}}}"
    MOBILITY_DOMAIN="$(printf '%s' "$_seed" | md5sum 2>/dev/null | cut -c1-4 || echo "4f2a")"
  fi

  # Настройка канала 5 GHz (для mesh частота должна быть фиксированной и одинаковой!)
  if [ "$ACTION" = "master" ] || [ "$ACTION" = "satellite" ] || [ "$ACTION" = "mesh-setup" ]; then
    if [ -n "$radio_5g" ]; then
      if [ -n "$CHANNEL_5G" ]; then
        uci -q set "wireless.$radio_5g.channel=$CHANNEL_5G"
        echo "[ok] $radio_5g (5 GHz): канал зафиксирован на $CHANNEL_5G"
      else
        cur_chan="$(uci -q get "wireless.$radio_5g.channel" || true)"
        if [ -z "$cur_chan" ] || [ "$cur_chan" = "0" ] || [ "$cur_chan" = "auto" ]; then
          uci -q set "wireless.$radio_5g.channel=36"
          echo "[ok] $radio_5g (5 GHz): канал auto заменён на 36 (для mesh)"
        fi
      fi
      uci -q delete "wireless.$radio_5g.disabled" 2>/dev/null || true
    fi
    [ -n "$radio_2g" ] && uci -q delete "wireless.$radio_2g.disabled" 2>/dev/null || true
  fi

  # 3. Настройка Fast Roaming (802.11r/k/v)
  if [ "$ACTION" = "master" ] || [ "$ACTION" = "satellite" ] || [ "$ACTION" = "roaming-setup" ]; then
    echo "[*] Конфигурация Fast Roaming (Mobility Domain: $MOBILITY_DOMAIN)..."
    for iface in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-iface$/\1/p' | cut -d. -f2); do
      mode="$(uci -q get "wireless.$iface.mode" || true)"
      [ "$mode" = "ap" ] || continue

      dev="$(uci -q get "wireless.$iface.device" || true)"
      band="$(radio_band "$dev")"
      ssid="$(uci -q get "wireless.$iface.ssid" || true)"

      # Применяем SSID/пароль если явно переданы в CLI
      if [ "$band" = "5g" ] && [ -n "$SSID_5G" ] && [ "$ACTION" != "roaming-setup" ]; then
        uci -q set "wireless.$iface.ssid=$SSID_5G"
        [ -n "$KEY_5G" ] && uci -q set "wireless.$iface.key=$KEY_5G"
        [ -n "$ENCRYPTION_5G" ] && uci -q set "wireless.$iface.encryption=$ENCRYPTION_5G"
      elif [ "$band" = "2g" ] && [ -n "$SSID_2G" ] && [ "$ACTION" != "roaming-setup" ]; then
        uci -q set "wireless.$iface.ssid=$SSID_2G"
        [ -n "$KEY_2G" ] && uci -q set "wireless.$iface.key=$KEY_2G"
        [ -n "$ENCRYPTION_2G" ] && uci -q set "wireless.$iface.encryption=$ENCRYPTION_2G"
      fi

      # Проверка участия этой сети в Fast Roaming
      _participates=0
      if [ -n "$IFACES_LIST" ]; then
        if in_comma_list "$iface" "$IFACES_LIST"; then
          _participates=1
        fi
      elif [ -n "$SSIDS_LIST" ]; then
        if in_comma_list "$ssid" "$SSIDS_LIST"; then
          _participates=1
        fi
      else
        _participates=1
      fi

      if [ "$_participates" = "1" ]; then
        # Если задан ключ, но шифрование не задано или none — гарантируем psk2+ccmp
        cur_enc="$(uci -q get "wireless.$iface.encryption" || true)"
        cur_key="$(uci -q get "wireless.$iface.key" || true)"
        if [ -n "$cur_key" ] && { [ -z "$cur_enc" ] || [ "$cur_enc" = "none" ]; }; then
          uci -q set "wireless.$iface.encryption=psk2+ccmp"
        fi

        # Включаем 802.11r Fast Transition, 802.11k RRM, 802.11v BSS Transition
        uci -q set "wireless.$iface.ieee80211r=1"
        uci -q set "wireless.$iface.ft_psk_generate_local=1"
        uci -q set "wireless.$iface.ft_over_ds=1"
        uci -q set "wireless.$iface.mobility_domain=$MOBILITY_DOMAIN"
        uci -q set "wireless.$iface.ieee80211k=1"
        uci -q set "wireless.$iface.ieee80211v=1"
        uci -q set "wireless.$iface.bss_transition=1"
        uci -q delete "wireless.$iface.disabled" 2>/dev/null || true

        echo "[ok] AP $iface ($band, '$ssid'): Fast Roaming (802.11r/k/v) ВКЛЮЧЕН (domain=$MOBILITY_DOMAIN)"
      else
        # Сеть исключена пользователем (напр. IoT или Guest)
        uci -q delete "wireless.$iface.ieee80211r" 2>/dev/null || true
        uci -q delete "wireless.$iface.ft_psk_generate_local" 2>/dev/null || true
        uci -q delete "wireless.$iface.ft_over_ds" 2>/dev/null || true
        uci -q delete "wireless.$iface.mobility_domain" 2>/dev/null || true
        echo "[ok] AP $iface ($band, '$ssid'): 802.11r FT ВЫКЛЮЧЕН (исключен из роуминга)"
      fi
    done
  elif [ "$ACTION" = "roaming-disable" ]; then
    echo "[*] Отключение Fast Roaming на точках доступа..."
    for iface in $(uci show wireless 2>/dev/null | sed -n 's/^\(wireless\.[^=]*\)=wifi-iface$/\1/p' | cut -d. -f2); do
      mode="$(uci -q get "wireless.$iface.mode" || true)"
      [ "$mode" = "ap" ] || continue
      ssid="$(uci -q get "wireless.$iface.ssid" || true)"

      _disable_this=1
      if [ -n "$IFACES_LIST" ]; then
        in_comma_list "$iface" "$IFACES_LIST" || _disable_this=0
      fi

      if [ "$_disable_this" = "1" ]; then
        uci -q delete "wireless.$iface.ieee80211r" 2>/dev/null || true
        uci -q delete "wireless.$iface.ft_psk_generate_local" 2>/dev/null || true
        uci -q delete "wireless.$iface.ft_over_ds" 2>/dev/null || true
        uci -q delete "wireless.$iface.mobility_domain" 2>/dev/null || true
        echo "[ok] AP $iface ('$ssid'): 802.11r FT отключен"
      fi
    done
  fi

  # 4. Настройка 802.11s Mesh интерфейса на 5 GHz
  if [ "$ACTION" = "master" ] || [ "$ACTION" = "satellite" ] || [ "$ACTION" = "mesh-setup" ]; then
    if [ -n "$radio_5g" ]; then
      if [ -z "$mesh_sec" ]; then
        mesh_sec="mesh5g"
        uci -q set "wireless.$mesh_sec=wifi-iface"
      fi

      uci -q set "wireless.$mesh_sec.device=$radio_5g"
      uci -q set "wireless.$mesh_sec.mode=mesh"
      uci -q set "wireless.$mesh_sec.mesh_id=$MESH_ID"
      uci -q set "wireless.$mesh_sec.mesh_fwding=1"
      uci -q set "wireless.$mesh_sec.network=lan"
      uci -q set "wireless.$mesh_sec.encryption=sae"
      uci -q set "wireless.$mesh_sec.key=$MESH_KEY"
      uci -q delete "wireless.$mesh_sec.disabled" 2>/dev/null || true

      echo "[ok] 802.11s Mesh: $mesh_sec на $radio_5g, mesh_id='$MESH_ID' (WPA3-SAE)"
    fi
  elif [ "$ACTION" = "mesh-disable" ]; then
    if [ -n "$mesh_sec" ]; then
      uci -q set "wireless.$mesh_sec.disabled=1"
      echo "[ok] 802.11s Mesh интерфейс ($mesh_sec) отключен (используется кабельный бэкхол)"
    else
      echo "[*] Активный 802.11s Mesh интерфейс не найден"
    fi
  fi

  uci commit wireless

fi

echo "[ok] Конфигурация ($ACTION) успешно применена!"

if [ -n "$LAN_IP" ] && [ "$ACTION" = "satellite" ]; then
  echo "[*] Переключение сети на $LAN_IP и перезапуск Wi-Fi через 2с..."
  (
    sleep 2
    if command -v wifi >/dev/null 2>&1; then
      wifi reload 2>/dev/null || true
    fi
    if [ -x /sbin/ifdown ] && [ -x /sbin/ifup ]; then
      ifdown lan 2>/dev/null || true
      ifup lan 2>/dev/null || /etc/init.d/network reload
    else
      /etc/init.d/network reload
    fi
    if [ -x /etc/init.d/dropbear ]; then
      /etc/init.d/dropbear restart 2>/dev/null || true
    fi
  ) >/dev/null 2>&1 &
elif command -v wifi >/dev/null 2>&1; then
  (
    sleep 1
    wifi reload 2>/dev/null || true
  ) >/dev/null 2>&1 &
fi

if [ -n "$LAN_IP" ] && [ "$ROLE" = "satellite" ]; then
  echo "[*] Переключение сети на $LAN_IP и перезапуск Wi-Fi через 2с..."
  (
    sleep 2
    if command -v wifi >/dev/null 2>&1; then
      wifi reload 2>/dev/null || true
    fi
    if [ -x /sbin/ifdown ] && [ -x /sbin/ifup ]; then
      ifdown lan 2>/dev/null || true
      ifup lan 2>/dev/null || /etc/init.d/network reload
    else
      /etc/init.d/network reload
    fi
    if [ -x /etc/init.d/dropbear ]; then
      /etc/init.d/dropbear restart 2>/dev/null || true
    fi
  ) >/dev/null 2>&1 &
elif command -v wifi >/dev/null 2>&1; then
  (
    sleep 1
    wifi reload 2>/dev/null || true
  ) >/dev/null 2>&1 &
fi
