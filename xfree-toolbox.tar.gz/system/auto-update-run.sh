#!/bin/sh
# shellcheck shell=sh
# Cron work: автообновление по MODE из auto-update.conf.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

export AUTO_UPDATE_ROOT_DIR="$ROOT_DIR"
export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
export XFREE_BG_TASK=1

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/auto-update-lib.sh"

PIPELINE_SH="$ROOT_DIR/templates/update-and-apply-pipeline.sh"
ONCE_FLAG="/tmp/xfree-auto-update.once"

auto_update_log() {
	_msg="$*"
	logger -t xfree-auto-update "$_msg" 2>/dev/null || true
	printf '%s\n' "$_msg" >&2
}

auto_update_run_upstream_lists() {
	_with_package="$1"
	# shellcheck disable=SC1091
	. "$PIPELINE_SH"
	if [ "$_with_package" = "1" ]; then
		# Канон: проба → upgrade → снова проба → HTTP (self-update может рестартнуть DoH).
		templates_run_upgrade_and_upstream_preflight "$ROOT_DIR" 1
		return $?
	fi
	templates_pipeline_prepare_uplink "$ROOT_DIR" || return 1
	templates_run_upstream_preflight_core "$ROOT_DIR" 1
}

auto_update_run_templates_sync() {
	# shellcheck disable=SC1091
	. "$PIPELINE_SH"
	_targets="$(templates_resolve_active_sync_targets "$ROOT_DIR" 2>/dev/null || true)"
	[ -n "${_targets:-}" ] || {
		auto_update_log "error: active profile not ready for sync (EXPORT-META.txt / profiles/)"
		return 1
	}
	_template="$(printf '%s' "$_targets" | cut -f1)"
	_profile="$(printf '%s' "$_targets" | cut -f2)"
	auto_update_log "pipeline: template=$_template profile=$_profile mode=sync"
	templates_sync_update_apply_pipeline \
		"$ROOT_DIR" "$_template" "$_profile" 1 1 \
		"auto-update: $_template"
}

case "$0" in
	*auto-update-run.sh) ;;
	*) return 0 2>/dev/null || exit 0 ;;
esac

if [ -f "$ONCE_FLAG" ]; then
	auto_update_log "skip: already started (remove $ONCE_FLAG to retry)"
	exit 0
fi
: >"$ONCE_FLAG" 2>/dev/null || true

auto_update_load_config
if [ "$AUTO_UPDATE_ENABLED" != "1" ]; then
	auto_update_log "skip: ENABLED=0"
	rm -f "$ONCE_FLAG" 2>/dev/null || true
	exit 0
fi

auto_update_log "start: mode=$AUTO_UPDATE_MODE pid=$$"

_rc=0
case "$AUTO_UPDATE_MODE" in
	"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS")
		auto_update_run_upstream_lists 0 || _rc=1
		;;
	"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS_PACKAGE")
		auto_update_run_upstream_lists 1 || _rc=1
		;;
	"$AUTO_UPDATE_MODE_TEMPLATES_SYNC")
		auto_update_run_templates_sync || _rc=1
		;;
	*)
		auto_update_log "error: unknown MODE=$AUTO_UPDATE_MODE"
		_rc=1
		;;
esac

if [ "$_rc" -eq 0 ]; then
	auto_update_log "done: mode=$AUTO_UPDATE_MODE"
else
	auto_update_log "error: mode=$AUTO_UPDATE_MODE failed"
fi

rm -f "$ONCE_FLAG" 2>/dev/null || true
exit "$_rc"
