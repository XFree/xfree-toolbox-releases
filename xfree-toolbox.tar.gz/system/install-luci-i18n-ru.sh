#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"

DO_UPDATE=1
FORCE=0
SET_LANG=1

usage() {
  cat <<'USAGE'
Использование:
  install-luci-i18n-ru.sh [--no-update] [--force] [--no-set-lang] [-h|--help]

Параметры:
  --no-update    не обновлять индексы пакетов перед установкой
  --force        переустановить пакеты переводов принудительно
  --no-set-lang  не менять uci luci.main.lang (по умолчанию ставится ru)
  -h, --help     показать эту справку
USAGE
}

repo_has_pkg() {
  pkg="$1"

  case "$PM" in
    opkg)
      opkg list 2>/dev/null | awk '{print $1}' | grep -Fxq "$pkg"
      ;;
    apk)
      apk search -x "$pkg" 2>/dev/null \
        | sed 's/-[0-9][A-Za-z0-9._~+-]*$//' \
        | grep -Fxq "$pkg"
      ;;
    *)
      die "PM=$PM not supported"
      ;;
  esac
}

map_luci_pkg_to_ru_i18n() {
  pkg="$1"

  case "$pkg" in
    luci-i18n-*)
      return 1
      ;;
    luci-base)
      printf 'luci-i18n-base-ru\n'
      return 0
      ;;
    luci-app-*)
      printf 'luci-i18n-%s-ru\n' "${pkg#luci-app-}"
      return 0
      ;;
    luci-proto-*)
      printf 'luci-i18n-%s-ru\n' "${pkg#luci-proto-}"
      return 0
      ;;
    luci-theme-*)
      printf 'luci-i18n-%s-ru\n' "${pkg#luci-theme-}"
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

pm_installed_pkg_version() {
  pkg="$1"
  case "$PM" in
    opkg)
      opkg info "$pkg" 2>/dev/null | awk -F': ' '/^Version:/{print $2; exit}'
      ;;
    apk)
      apk info -e "$pkg" 2>/dev/null | head -n 1 | sed 's/^[^-]*-//'
      ;;
    *)
      return 1
      ;;
  esac
}

pm_pkg_installed_files() {
  pkg="$1"
  case "$PM" in
    opkg)
      opkg files "$pkg" 2>/dev/null
      ;;
    apk)
      apk info -L "$pkg" 2>/dev/null | sed '1d'
      ;;
    *)
      return 1
      ;;
  esac
}

luci_i18n_version_prefix() {
  ver="$1"
  printf '%s' "$ver" | sed -n 's/^\([0-9][0-9]*\.[0-9][0-9]*\).*/\1/p'
}

ensure_luci_language_ru() {
  [ "$SET_LANG" -eq 1 ] || return 0

  cur="$(uci -q get luci.main.lang 2>/dev/null || true)"
  if [ "$cur" = "ru" ]; then
    info "LuCI: язык интерфейса уже ru (uci luci.main.lang)."
    return 0
  fi

  uci set luci.main.lang='ru'
  uci commit luci
  info "LuCI: установлен язык интерфейса ru (Система → Язык и стиль)."
}

luci_clear_runtime_cache() {
  rm -f /tmp/luci-indexcache 2>/dev/null || true
  rm -rf /tmp/luci-* 2>/dev/null || true
}

luci_i18n_restart_services() {
  info "Перезапуск сервисов LuCI…"
  luci_clear_runtime_cache
  restart_service_if_exists rpcd
  restart_service_if_exists uhttpd
  restart_service_if_exists nginx
  success "Сервисы LuCI перезапущены."
}

luci_i18n_report_one() {
  app_pkg="$1"
  i18n_pkg="$2"

  if ! pm_is_installed "$i18n_pkg"; then
    warn "[ru] $app_pkg → $i18n_pkg: пакет перевода не установлен."
    return 1
  fi

  i18n_ver="$(pm_installed_pkg_version "$i18n_pkg" 2>/dev/null || true)"
  app_ver=""
  if pm_is_installed "$app_pkg"; then
    app_ver="$(pm_installed_pkg_version "$app_pkg" 2>/dev/null || true)"
  fi

  i18n_files="$(pm_pkg_installed_files "$i18n_pkg" 2>/dev/null | head -n 3 | tr '\n' ' ')"
  [ -n "$i18n_files" ] || i18n_files="(файлы перевода не найдены — возможно битая установка)"

  if [ -n "$app_ver" ] && [ -n "$i18n_ver" ]; then
    app_pf="$(luci_i18n_version_prefix "$app_ver")"
    i18n_pf="$(luci_i18n_version_prefix "$i18n_ver")"
    if [ -n "$app_pf" ] && [ -n "$i18n_pf" ] && [ "$app_pf" != "$i18n_pf" ]; then
      warn "[ru] $app_pkg ($app_ver) и $i18n_pkg ($i18n_ver): разные ветки версий — перевод может не подхватиться. Попробуйте: $0 --force"
    fi
  fi

  say "[ru] $app_pkg → $i18n_pkg${i18n_ver:+ ($i18n_ver)}"
  say "     $i18n_files"
  return 0
}

luci_i18n_finalize() {
  ensure_luci_language_ru
  luci_i18n_restart_services

  cur_lang="$(uci -q get luci.main.lang 2>/dev/null || true)"
  info "Проверка установленных переводов (luci.main.lang=${cur_lang:-?})…"

  for pkg in $INSTALLED_LUCI_PKGS; do
    i18n_pkg="$(map_luci_pkg_to_ru_i18n "$pkg" || true)"
    [ -n "$i18n_pkg" ] || continue
    luci_i18n_report_one "$pkg" "$i18n_pkg" || true
  done

  if [ "$cur_lang" != "ru" ]; then
    warn "Язык LuCI не ru — переводы в браузере не появятся. Задайте: uci set luci.main.lang=ru; uci commit luci"
  else
    info "Если отдельная страница всё ещё на английском: выйдите из LuCI, обновите вкладку (Ctrl+F5), снова войдите."
  fi
}

append_pkg_unique() {
  current_list="$1"
  new_pkg="$2"

  if [ -z "$new_pkg" ]; then
    printf '%s' "$current_list"
    return 0
  fi

  if [ -n "$current_list" ] && printf '%s\n' "$current_list" | grep -Fxq "$new_pkg"; then
    printf '%s' "$current_list"
    return 0
  fi

  if [ -n "$current_list" ]; then
    printf '%s\n%s' "$current_list" "$new_pkg"
  else
    printf '%s' "$new_pkg"
  fi
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --no-update)
      DO_UPDATE=0
      ;;
    --force)
      FORCE=1
      ;;
    --no-set-lang)
      SET_LANG=0
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Неизвестный параметр: $1"
      ;;
  esac
  shift
done

pm_print

if [ "$DO_UPDATE" -eq 1 ]; then
  info "Обновление списков пакетов..."
  pm_update
else
  info "Пропуск обновления списков пакетов..."
fi

info "Поиск установленных LuCI пакетов..."
INSTALLED_LUCI_PKGS="$(pm_list_installed_luci || true)"

if [ -z "$INSTALLED_LUCI_PKGS" ]; then
  warn "Установленные LuCI пакеты не найдены. Устанавливать переводы не для чего."
  exit 0
fi

info "Найдены установленные LuCI пакеты:"
printf '%s\n\n' "$INSTALLED_LUCI_PKGS"

RU_PKGS=""
SKIPPED_PKGS=""

# Базовый перевод LuCI обрабатываем явно
if repo_has_pkg "luci-i18n-base-ru"; then
  if [ "$FORCE" -eq 1 ] || ! pm_is_installed "luci-i18n-base-ru"; then
    RU_PKGS="$(append_pkg_unique "$RU_PKGS" "luci-i18n-base-ru")"
  fi
else
  SKIPPED_PKGS="$(append_pkg_unique "$SKIPPED_PKGS" "luci-i18n-base-ru")"
fi

for pkg in $INSTALLED_LUCI_PKGS; do
  [ -n "$pkg" ] || continue

  i18n_pkg="$(map_luci_pkg_to_ru_i18n "$pkg" || true)"
  [ -n "$i18n_pkg" ] || continue
  [ "$i18n_pkg" = "luci-i18n-base-ru" ] && continue

  if [ "$FORCE" -ne 1 ] && pm_is_installed "$i18n_pkg"; then
    continue
  fi

  if repo_has_pkg "$i18n_pkg"; then
    RU_PKGS="$(append_pkg_unique "$RU_PKGS" "$i18n_pkg")"
  else
    SKIPPED_PKGS="$(append_pkg_unique "$SKIPPED_PKGS" "$i18n_pkg")"
  fi
done

if [ -n "$SKIPPED_PKGS" ]; then
  warn "Следующие пакеты переводов отсутствуют в репозитории и будут пропущены:"
  printf '%s\n' "$SKIPPED_PKGS" | sort -u | while IFS= read -r pkg; do
    [ -n "$pkg" ] || continue
    say "[-] $pkg"
  done
  echo
fi

RU_PKGS="$(printf '%s\n' "$RU_PKGS" | awk 'NF' | sort -u)"

if [ -z "$RU_PKGS" ]; then
  success "Все доступные русские переводы уже установлены."
  luci_i18n_finalize
  exit 0
fi

info "Будут обработаны пакеты русификации:"
printf '%s\n' "$RU_PKGS" | while IFS= read -r pkg; do
  [ -n "$pkg" ] || continue
  say "[+] $pkg"
done
echo

# shellcheck disable=SC2086
pm_install_or_upgrade_packages $( [ "$FORCE" -eq 1 ] && printf '%s' -- '--force' ) -- $RU_PKGS || {
  rc=$?
  # pm_install_or_upgrade_packages: 0 = всё уже было, 1 = установлено/обновлено, иначе — ошибка
  [ "$rc" -eq 1 ] || die "Не удалось установить один или несколько пакетов переводов (код $rc)."
}

luci_i18n_finalize
success "Обработка переводов LuCI завершена."
exit 0