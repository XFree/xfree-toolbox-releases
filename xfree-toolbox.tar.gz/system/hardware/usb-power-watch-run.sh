#!/bin/sh
# shellcheck shell=sh
# Cron (раз в INTERVAL_MIN): сессия probe каждые PROBE_INTERVAL_SEC на PROBE_IFACE.
# FAIL_COUNT — по сбоям probe, не по числу запусков cron.
# USB power-cycle: только сбои TEST_URL; PARTIAL и CYCLE_LOCK — без cycle.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"
export USB_WATCH_ROOT_DIR="$ROOT_DIR"
. "$SCRIPT_DIR/usb-power-watch-lib.sh"
. "$ROOT_DIR/lib/led/led-lib.sh"
. "$SCRIPT_DIR/internet-status-led-lib.sh"
. "$SCRIPT_DIR/lib-board.sh"

USB_WATCH_LED_CYCLE="$SCRIPT_DIR/usb-power-watch-led-cycle.sh"
export USB_WATCH_LED_CYCLE_SH="$USB_WATCH_LED_CYCLE"

USB_WATCH_RUN_LOCK="${TMPDIR:-/tmp}/xfree-usb-watch-run.lock"

_usb_watch_run_exit() {
    _rc="${1:-0}"
    usb_watch_log_line "session: exit rc=$_rc"
    exit "$_rc"
}

_usb_watch_run_unlock() {
    rmdir "$USB_WATCH_RUN_LOCK" 2>/dev/null || true
}

usb_watch_load_config
usb_watch_state_set LAST_TICK "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"
usb_watch_maybe_reset_after_reboot || true

if [ "$USB_WATCH_ENABLED" != "1" ]; then
    usb_watch_log_line "session: skip ENABLED=$USB_WATCH_ENABLED (ожидается 1)"
    internet_status_led_disable 2>/dev/null || true
    _usb_watch_run_exit 0
fi

if ! mkdir "$USB_WATCH_RUN_LOCK" 2>/dev/null; then
    usb_watch_log_line "session: skip (предыдущий run ещё активен)"
    _usb_watch_run_exit 0
fi
trap '_usb_watch_run_unlock' EXIT INT TERM

if ! usb_watch_cron_installed; then
    usb_watch_log_line "session: WARNING — cron не установлен (Мониторинг канала → Включить периодическую проверку канала); ручной запуск"
fi

usb_watch_log_line "session: begin script=$0 root=$ROOT_DIR iface=$(usb_watch_probe_iface_label)"

case "$USB_WATCH_INTERVAL_MIN" in
    ''|*[!0-9]*) USB_WATCH_INTERVAL_MIN=3 ;;
esac
usb_watch_normalize_probe_interval
case "$USB_WATCH_FAIL_MAX" in
    ''|*[!0-9]*) USB_WATCH_FAIL_MAX=3 ;;
esac
case "$USB_WATCH_CYCLE_MAX" in
    ''|*[!0-9]*) USB_WATCH_CYCLE_MAX=3 ;;
esac
case "$USB_WATCH_OFF_SEC" in
    ''|*[!0-9]*) USB_WATCH_OFF_SEC=8 ;;
esac
case "$USB_WATCH_ON_SEC" in
    ''|*[!0-9]*) USB_WATCH_ON_SEC=5 ;;
esac
case "$USB_WATCH_SETTLE_SEC" in
    ''|*[!0-9]*) USB_WATCH_SETTLE_SEC=90 ;;
esac

if usb_watch_in_settle_period; then
    usb_watch_log_line "cooldown: probe skipped (~$(usb_watch_settle_remaining_sec)s left, SETTLE_SEC=$USB_WATCH_SETTLE_SEC after cycle)"
    _usb_watch_run_exit 0
fi

if usb_watch_try_auto_reset_exhaust_lock; then
    usb_watch_log_line "session: CYCLE_LOCK auto-reset перед probe"
fi

_period_sec="$(usb_watch_session_period_sec)"
_now="$(date +%s 2>/dev/null || echo 0)"
_deadline=$((_now + _period_sec))
_probe_n=0

usb_watch_log_line "session: period=${_period_sec}s probe_every=${USB_WATCH_PROBE_INTERVAL_SEC}s cron=${USB_WATCH_INTERVAL_MIN}min"

while :; do
    _now="$(date +%s 2>/dev/null || echo 0)"
    [ "$_now" -ge "$_deadline" ] 2>/dev/null && break

    _probe_n=$((_probe_n + 1))
    usb_watch_log_line "session: probe #$_probe_n"
    if usb_watch_handle_probe_tick; then
        :
    else
        _usb_watch_run_exit 0
    fi

    _now="$(date +%s 2>/dev/null || echo 0)"
    [ "$_now" -ge "$_deadline" ] 2>/dev/null && break

    sleep "$USB_WATCH_PROBE_INTERVAL_SEC" 2>/dev/null || sleep 20
done

usb_watch_log_line "session: end probes=$_probe_n period=${_period_sec}s"
_usb_watch_run_exit 0
