#!/bin/sh
# shellcheck shell=sh
# Tunnel ICMP + handshake probe when WAN is full (eval=0).
# Mirrors USB uplink policy:
#   TUNNEL_ICMP_FAIL_MAX (like FAIL_MAX) — consecutive ICMP FAIL before bounce/renew;
#   TUNNEL_BOUNCE_MAX (like CYCLE_MAX) — max reloads, then probe-only / log.
# Handshake is status-only; pass/fail is ICMP.

USB_WATCH_TUNNEL_PROBE_LIB_SOURCED="${USB_WATCH_TUNNEL_PROBE_LIB_SOURCED:-}"
[ -n "$USB_WATCH_TUNNEL_PROBE_LIB_SOURCED" ] && return 0
USB_WATCH_TUNNEL_PROBE_LIB_SOURCED=1

usb_watch_tunnel_conf_value() {
    _cfg="$1"
    _key="$2"
    [ -f "$_cfg" ] || return 0
    awk -F= -v key="$_key" '
        $1 == key {
            val=$2
            sub(/^[[:space:]]*/, "", val)
            sub(/[[:space:]]*$/, "", val)
            gsub(/^\047|\047$/, "", val)
            print val
            exit
        }
    ' "$_cfg"
}

usb_watch_tunnel_state_key_last() {
    printf 'TUNNEL_LAST_%s' "$1"
}

usb_watch_tunnel_state_key_bounce_count() {
    printf 'TUNNEL_BOUNCE_COUNT_%s' "$1"
}

usb_watch_tunnel_state_key_last_action() {
    printf 'TUNNEL_LAST_ACTION_%s' "$1"
}

usb_watch_tunnel_state_key_hs() {
    printf 'TUNNEL_HS_%s' "$1"
}

usb_watch_tunnel_state_key_ping() {
    printf 'TUNNEL_PING_%s' "$1"
}

usb_watch_tunnel_state_key_icmp_fail() {
    printf 'TUNNEL_ICMP_FAIL_%s' "$1"
}

# Legacy (pre multi-bounce): treat as exhausted when set.
usb_watch_tunnel_state_key_bounce_done() {
    printf 'TUNNEL_BOUNCE_DONE_%s' "$1"
}

usb_watch_tunnel_sanitize_iface() {
    printf '%s' "${1:-}" | tr -c 'A-Za-z0-9_' '_'
}

usb_watch_tunnel_handshake_lib_load() {
    [ "${USB_WATCH_TUNNEL_HS_LIB_LOADED:-0}" = "1" ] && return 0
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _lib="$_root/iface-routing/lib/vpn-handshake.sh"
    [ -f "$_lib" ] || return 1
    # shellcheck disable=SC1090
    . "$_lib"
    USB_WATCH_TUNNEL_HS_LIB_LOADED=1
    return 0
}

usb_watch_tunnel_interfaces_dir() {
    if [ -n "${USB_WATCH_TUNNEL_INTERFACES_DIR:-}" ]; then
        printf '%s\n' "$USB_WATCH_TUNNEL_INTERFACES_DIR"
        return 0
    fi
    if usb_watch_recovery_lib_load 2>/dev/null; then
        [ -n "${RECOVERY_SCHEDULER_INTERFACES_DIR:-}" ] && {
            printf '%s\n' "$RECOVERY_SCHEDULER_INTERFACES_DIR"
            return 0
        }
    fi
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -z "$_root" ] && return 1
    if [ -z "${PROFILE_DIR:-}" ]; then
        if command -v usb_watch_ensure_profile_dir >/dev/null 2>&1; then
            usb_watch_ensure_profile_dir "$_root" || true
        elif ! command -v common_profile_dir >/dev/null 2>&1; then
            # Fallback when sourced without usb-power-watch-lib.sh
            # shellcheck disable=SC1091
            [ -f "$_root/lib/common.sh" ] && . "$_root/lib/common.sh"
            if command -v load_base_config >/dev/null 2>&1; then
                load_base_config "$_root" 2>/dev/null || true
            fi
            if command -v common_profile_dir >/dev/null 2>&1; then
                PROFILE_DIR="$(common_profile_dir "$_root" 2>/dev/null || true)"
            fi
        else
            PROFILE_DIR="$(common_profile_dir "$_root" 2>/dev/null || true)"
        fi
    fi
    [ -n "${PROFILE_DIR:-}" ] && printf '%s\n' "$PROFILE_DIR/iface-routing/interfaces"
}

usb_watch_tunnel_list_profile_ifaces() {
    _dir="$(usb_watch_tunnel_interfaces_dir 2>/dev/null || true)"
    [ -n "$_dir" ] && [ -d "$_dir" ] || return 0
    for _d in "$_dir"/*/config/iface.conf; do
        [ -f "$_d" ] || continue
        _dirname="$(dirname "$(dirname "$_d")")"
        basename "$_dirname"
    done | sort -u
}

usb_watch_tunnel_upstream_dep() {
    _iface="$1"
    _dir="$(usb_watch_tunnel_interfaces_dir 2>/dev/null || true)"
    [ -n "$_dir" ] || return 0
    _cfg="$_dir/$_iface/config/iface.conf"
    usb_watch_tunnel_conf_value "$_cfg" SELF_ROUTE_VIA
}

usb_watch_tunnel_order_lib_load() {
    [ "${USB_WATCH_TUNNEL_ORDER_LOADED:-0}" = "1" ] && return 0
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _lib="$_root/iface-routing/lib/iface-order.sh"
    [ -f "$_lib" ] || return 1
    # shellcheck disable=SC1090
    . "$_lib"
    USB_WATCH_TUNNEL_ORDER_LOADED=1
    return 0
}

usb_watch_tunnel_ordered_ifaces() {
    _all="$(usb_watch_tunnel_list_profile_ifaces || true)"
    [ -n "$_all" ] || return 0
    if usb_watch_tunnel_order_lib_load && command -v iface_build_order_by_dependency >/dev/null 2>&1; then
        iface_build_order_by_dependency "$_all" usb_watch_tunnel_upstream_dep
        return 0
    fi
    printf '%s\n' "$_all"
}

usb_watch_tunnel_uci_iface_disabled() {
    _iface="$1"
    command -v uci >/dev/null 2>&1 || return 1
    case "$(uci -q get "network.${_iface}.disabled" 2>/dev/null || true)" in
        1|true|on|yes|TRUE|ON) return 0 ;;
    esac
    return 1
}

usb_watch_tunnel_read_target() {
    _cfg="$1"
    _ping="$(usb_watch_tunnel_conf_value "$_cfg" PING_TARGET_IP)"
    [ -n "$_ping" ] || _ping="$(usb_watch_tunnel_conf_value "$_cfg" TEST_IP)"
    [ -n "$_ping" ] || _ping='1.1.1.1'
    printf '%s\n' "$_ping"
}

usb_watch_tunnel_read_vpn_dev() {
    _iface="$1"
    _cfg="$2"
    _dev="$(usb_watch_tunnel_conf_value "$_cfg" VPN_DEV)"
    [ -n "$_dev" ] || _dev="$(usb_watch_tunnel_conf_value "$_cfg" INTERFACE_NAME)"
    [ -n "$_dev" ] || _dev="$_iface"
    printf '%s\n' "$_dev"
}

usb_watch_tunnel_bounce_max() {
    case "${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}" in
        ''|*[!0-9]*) printf '3\n' ;;
        0) printf '1\n' ;;
        *) printf '%s\n' "${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}" ;;
    esac
}

# Consecutive ICMP FAIL before bounce (mirrors FAIL_MAX for uplink/USB).
usb_watch_tunnel_icmp_fail_max() {
    case "${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-3}" in
        ''|*[!0-9]*) printf '3\n' ;;
        0) printf '1\n' ;;
        *) printf '%s\n' "${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-3}" ;;
    esac
}

usb_watch_tunnel_get_icmp_fail() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    _c="$(usb_watch_state_get "$(usb_watch_tunnel_state_key_icmp_fail "$_tok")" 0)"
    case "$_c" in
        ''|*[!0-9]*) _c=0 ;;
    esac
    printf '%s\n' "$_c"
}

usb_watch_tunnel_set_icmp_fail() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    usb_watch_state_set "$(usb_watch_tunnel_state_key_icmp_fail "$_tok")" "$2"
}

usb_watch_tunnel_clear_icmp_fail() {
    usb_watch_tunnel_set_icmp_fail "$1" 0
}

# Override in tests: usb_watch_tunnel_probe_ping(dev, target) -> 0 ok.
usb_watch_tunnel_probe_ping() {
    _dev="$1"
    _target="$2"
    [ -n "$_dev" ] && [ -n "$_target" ] || return 1
    command -v ping >/dev/null 2>&1 || return 1
    ip link show "$_dev" >/dev/null 2>&1 || return 1
    ping -I "$_dev" -c 1 -W 8 "$_target" >/dev/null 2>&1
}

usb_watch_tunnel_probe_iface() {
    _iface="$1"
    _dir="$(usb_watch_tunnel_interfaces_dir 2>/dev/null || true)"
    [ -n "$_dir" ] || return 1
    _cfg="$_dir/$_iface/config/iface.conf"
    [ -f "$_cfg" ] || return 1
    case "$(usb_watch_tunnel_conf_value "$_cfg" ROUTING_MODE)" in
        ''|vpn) ;;
        *) return 1 ;;
    esac
    if usb_watch_tunnel_uci_iface_disabled "$_iface"; then
        return 1
    fi
    _dev="$(usb_watch_tunnel_read_vpn_dev "$_iface" "$_cfg")"
    _target="$(usb_watch_tunnel_read_target "$_cfg")"
    usb_watch_tunnel_probe_ping "$_dev" "$_target"
}

usb_watch_tunnel_bounce_iface() {
    _iface="$1"
    # Ensure recovery helpers are loaded (not only via interfaces_dir).
    if ! command -v recovery_scheduler_bounce_iface >/dev/null 2>&1; then
        usb_watch_recovery_lib_load 2>/dev/null || true
    fi
    if command -v recovery_scheduler_bounce_iface >/dev/null 2>&1; then
        _common="${RECOVERY_SCHEDULER_COMMON_SH:-}"
        [ -n "$_common" ] && [ -f "$_common" ] || {
            _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
            _common="${_root}/lib/common.sh"
        }
        recovery_scheduler_bounce_iface "$_iface" "$_common"
        return $?
    fi
    return 1
}

usb_watch_tunnel_set_last() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    usb_watch_state_set "$(usb_watch_tunnel_state_key_last "$_tok")" "$2"
}

usb_watch_tunnel_get_last() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    usb_watch_state_get "$(usb_watch_tunnel_state_key_last "$_tok")" ""
}

usb_watch_tunnel_get_bounce_count() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    _c="$(usb_watch_state_get "$(usb_watch_tunnel_state_key_bounce_count "$_tok")" 0)"
    # Migrate legacy single-shot flag → count=max (exhausted).
    if [ "$_c" = "0" ] && [ "$(usb_watch_state_get "$(usb_watch_tunnel_state_key_bounce_done "$_tok")" 0)" = "1" ]; then
        _c="$(usb_watch_tunnel_bounce_max)"
        usb_watch_state_set "$(usb_watch_tunnel_state_key_bounce_count "$_tok")" "$_c"
    fi
    case "$_c" in
        ''|*[!0-9]*) _c=0 ;;
    esac
    printf '%s\n' "$_c"
}

usb_watch_tunnel_set_bounce_count() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    usb_watch_state_set "$(usb_watch_tunnel_state_key_bounce_count "$_tok")" "$2"
    # Clear legacy flag when using counter.
    usb_watch_state_set "$(usb_watch_tunnel_state_key_bounce_done "$_tok")" 0
}

usb_watch_tunnel_set_last_action() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    usb_watch_state_set "$(usb_watch_tunnel_state_key_last_action "$_tok")" "$2"
}

usb_watch_tunnel_get_last_action() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    usb_watch_state_get "$(usb_watch_tunnel_state_key_last_action "$_tok")" "none"
}

usb_watch_tunnel_record_diag() {
    _iface="$1"
    _ping_st="$2"
    _tok="$(usb_watch_tunnel_sanitize_iface "$_iface")"
    usb_watch_state_set "$(usb_watch_tunnel_state_key_ping "$_tok")" "$_ping_st"

    _dir="$(usb_watch_tunnel_interfaces_dir 2>/dev/null || true)"
    _cfg="${_dir:+$_dir/$_iface/config/iface.conf}"
    _dev="$(usb_watch_tunnel_read_vpn_dev "$_iface" "${_cfg:-/dev/null}")"
    _hs='unknown'
    if usb_watch_tunnel_handshake_lib_load 2>/dev/null && command -v vpn_handshake_status >/dev/null 2>&1; then
        _hs="$(vpn_handshake_status "$_dev" 2>/dev/null | sed -n '1p' || true)"
        [ -n "$_hs" ] || _hs=unknown
    fi
    case "$_hs" in
        ok|stale|none|down|unknown) ;;
        *) _hs=unknown ;;
    esac
    usb_watch_state_set "$(usb_watch_tunnel_state_key_hs "$_tok")" "$_hs"
}

usb_watch_tunnel_clear_recovery_state() {
    _iface="$1"
    usb_watch_tunnel_set_bounce_count "$_iface" 0
    usb_watch_tunnel_set_last_action "$_iface" none
    usb_watch_tunnel_clear_icmp_fail "$_iface"
}

usb_watch_tunnel_settle_sec() {
    case "${USB_WATCH_TUNNEL_PROBE_SETTLE_SEC:-15}" in
        ''|*[!0-9]*) printf '15\n' ;;
        *) printf '%s\n' "${USB_WATCH_TUNNEL_PROBE_SETTLE_SEC:-15}" ;;
    esac
}

usb_watch_tunnel_probe_enabled() {
    case "${USB_WATCH_TUNNEL_PROBE_ENABLED:-1}" in
        0|n|N|no|NO|false|FALSE|off|OFF) return 1 ;;
    esac
    return 0
}

usb_watch_proton_guest_renew_lib_load() {
    [ "${USB_WATCH_PROTON_GUEST_RENEW_LIB_LOADED:-0}" = "1" ] && return 0
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _lib="$_root/iface-routing/vpn/lib/proton-guest-renew.sh"
    [ -f "$_lib" ] || return 1
    # shellcheck disable=SC1090
    . "$_lib"
    USB_WATCH_PROTON_GUEST_RENEW_LIB_LOADED=1
    return 0
}

usb_watch_tunnel_state_key_proton_renew_ts() {
    printf 'TUNNEL_PROTON_RENEW_TS_%s' "$1"
}

usb_watch_proton_guest_renew_cooldown_ok() {
    _tok="$(usb_watch_tunnel_sanitize_iface "$1")"
    _cd="${USB_WATCH_PROTON_GUEST_RENEW_COOLDOWN_SEC:-1800}"
    case "$_cd" in
        ''|*[!0-9]*) _cd=1800 ;;
    esac
    [ "$_cd" -eq 0 ] && return 0
    _last="$(usb_watch_state_get "$(usb_watch_tunnel_state_key_proton_renew_ts "$_tok")" 0)"
    case "$_last" in
        ''|*[!0-9]*) _last=0 ;;
    esac
    _now="$(date +%s 2>/dev/null || echo 0)"
    [ $((_now - _last)) -ge "$_cd" ]
}

usb_watch_proton_guest_renew_try() {
    _iface="$1"
    _why="${2:-}"
    usb_watch_proton_guest_renew_lib_load || return 1
    command -v proton_guest_renew_execute >/dev/null 2>&1 || return 1
    proton_guest_renew_can_renew_iface "$_iface" || return 1
    usb_watch_proton_guest_renew_cooldown_ok "$_iface" || {
        usb_watch_log_line "proton guest renew: $_iface skip (cooldown $_why)"
        return 1
    }
    _tok="$(usb_watch_tunnel_sanitize_iface "$_iface")"
    usb_watch_state_set "$(usb_watch_tunnel_state_key_proton_renew_ts "$_tok")" "$(date +%s 2>/dev/null || echo 0)"
    usb_watch_log_line "proton guest renew: $_iface start ($_why)"
    if proton_guest_renew_execute "$_iface"; then
        usb_watch_tunnel_set_last_action "$_iface" guest-renew
        usb_watch_log_line "proton guest renew: $_iface OK ($_why)"
        _sec="$(usb_watch_tunnel_settle_sec)"
        [ "$_sec" -gt 0 ] 2>/dev/null && sleep "$_sec"
        return 0
    fi
    usb_watch_tunnel_set_last_action "$_iface" guest-renew-error
    usb_watch_log_line "proton guest renew: $_iface FAIL ($_why)"
    return 1
}

usb_watch_proton_guest_renew_maybe_expiry() {
    _iface="$1"
    usb_watch_proton_guest_renew_lib_load || return 1
    proton_guest_renew_mode_has_expiry "${USB_WATCH_PROTON_GUEST_RENEW:-expiry}" || return 1
    proton_guest_renew_can_renew_iface "$_iface" || return 1
    proton_guest_renew_cert_due_iface "$_iface" "${USB_WATCH_PROTON_GUEST_RENEW_SKEW_SEC:-600}" || return 1
    usb_watch_proton_guest_renew_try "$_iface" expiry
}

usb_watch_proton_guest_renew_maybe_tunnel_fail() {
    _iface="$1"
    usb_watch_proton_guest_renew_lib_load || return 1
    proton_guest_renew_mode_has_tunnel_fail "${USB_WATCH_PROTON_GUEST_RENEW:-expiry}" || return 1
    proton_guest_renew_can_renew_iface "$_iface" || return 1
    usb_watch_proton_guest_renew_try "$_iface" tunnel-fail
}

usb_watch_tunnel_handle_iface() {
    _iface="$1"
    [ -n "$_iface" ] || return 0

    _dir="$(usb_watch_tunnel_interfaces_dir 2>/dev/null || true)"
    _cfg="${_dir:+$_dir/$_iface/config/iface.conf}"
    _target="$(usb_watch_tunnel_read_target "${_cfg:-/dev/null}")"
    _prev="$(usb_watch_tunnel_get_last "$_iface")"
    _tb_max="$(usb_watch_tunnel_bounce_max)"
    _fail_max="$(usb_watch_tunnel_icmp_fail_max)"
    _bc="$(usb_watch_tunnel_get_bounce_count "$_iface")"
    _fc="$(usb_watch_tunnel_get_icmp_fail "$_iface")"

    usb_watch_proton_guest_renew_maybe_expiry "$_iface" || true

    if usb_watch_tunnel_probe_iface "$_iface"; then
        if [ "$_prev" != "ok" ]; then
            if [ "$_prev" = "fail" ] || [ "$_prev" = "exhausted" ]; then
                usb_watch_log_line "tunnel probe: $_iface OK → $_target (restored)"
            else
                usb_watch_log_line "tunnel probe: $_iface OK → $_target"
            fi
        fi
        usb_watch_tunnel_record_diag "$_iface" ok
        usb_watch_tunnel_set_last "$_iface" ok
        usb_watch_tunnel_clear_recovery_state "$_iface"
        return 0
    fi

    usb_watch_tunnel_record_diag "$_iface" fail
    _hs_lbl="$(usb_watch_tunnel_hs_label_cached "$_iface")"

    _fc=$((_fc + 1))
    usb_watch_tunnel_set_icmp_fail "$_iface" "$_fc"

    # Confirm outage like FAIL_MAX before renew/bounce (pauses between ticks = PROBE_INTERVAL).
    if [ "$_fc" -lt "$_fail_max" ] 2>/dev/null; then
        usb_watch_log_line "tunnel probe: $_iface FAIL → $_target ${_hs_lbl} (confirm ${_fc}/${_fail_max}; no bounce yet)"
        usb_watch_tunnel_set_last "$_iface" fail
        return 0
    fi

    if usb_watch_proton_guest_renew_maybe_tunnel_fail "$_iface"; then
        if usb_watch_tunnel_probe_iface "$_iface"; then
            usb_watch_log_line "proton guest renew: $_iface OK after rebuild → $_target"
            usb_watch_tunnel_record_diag "$_iface" ok
            usb_watch_tunnel_set_last "$_iface" ok
            usb_watch_tunnel_clear_recovery_state "$_iface"
            return 0
        fi
        usb_watch_log_line "proton guest renew: $_iface still FAIL after rebuild → $_target"
        usb_watch_tunnel_record_diag "$_iface" fail
        _hs_lbl="$(usb_watch_tunnel_hs_label_cached "$_iface")"
    fi

    if [ "$_bc" -ge "$_tb_max" ] 2>/dev/null; then
        if [ "$_prev" != "exhausted" ]; then
            usb_watch_log_line "tunnel probe: $_iface FAIL → $_target ${_hs_lbl} (bounce paused ${_bc}/${_tb_max}; probe continues)"
        fi
        usb_watch_tunnel_set_last "$_iface" exhausted
        return 0
    fi

    _next=$((_bc + 1))
    usb_watch_log_line "tunnel probe: $_iface FAIL → $_target ${_hs_lbl} (WAN full; bounce ${_next}/${_tb_max} after confirm ${_fc}/${_fail_max})"
    if usb_watch_tunnel_bounce_iface "$_iface"; then
        usb_watch_tunnel_set_last_action "$_iface" bounce
        _sec="$(usb_watch_tunnel_settle_sec)"
        [ "$_sec" -gt 0 ] 2>/dev/null && sleep "$_sec"
        if usb_watch_tunnel_probe_iface "$_iface"; then
            usb_watch_log_line "tunnel bounce: $_iface OK after reload → $_target (${_next}/${_tb_max})"
            usb_watch_tunnel_record_diag "$_iface" ok
            usb_watch_tunnel_set_last "$_iface" ok
            usb_watch_tunnel_clear_recovery_state "$_iface"
            return 0
        fi
        usb_watch_log_line "tunnel bounce: $_iface still FAIL → $_target (${_next}/${_tb_max})"
        usb_watch_tunnel_record_diag "$_iface" fail
    else
        usb_watch_log_line "tunnel bounce: $_iface reload error → $_target (${_next}/${_tb_max})"
        usb_watch_tunnel_set_last_action "$_iface" reload-error
        usb_watch_tunnel_record_diag "$_iface" fail
    fi

    # Confirmed episode continues: keep fail streak at max so next tick can bounce again
    # until TUNNEL_BOUNCE_MAX, without re-waiting full confirm each reload.
    usb_watch_tunnel_set_icmp_fail "$_iface" "$_fail_max"
    usb_watch_tunnel_set_bounce_count "$_iface" "$_next"
    if [ "$_next" -ge "$_tb_max" ] 2>/dev/null; then
        usb_watch_tunnel_set_last "$_iface" exhausted
        usb_watch_log_line "tunnel probe: $_iface bounce exhausted ${_next}/${_tb_max}"
    else
        usb_watch_tunnel_set_last "$_iface" fail
    fi
    return 0
}

usb_watch_tunnel_probe_tick() {
    usb_watch_tunnel_probe_enabled || return 0
    _ifaces="$(usb_watch_tunnel_ordered_ifaces || true)"
    [ -n "$_ifaces" ] || return 0
    while IFS= read -r _iface; do
        [ -n "$_iface" ] || continue
        usb_watch_tunnel_handle_iface "$_iface" || true
    done <<EOF
$_ifaces
EOF
    return 0
}

usb_watch_tunnel_clear_runtime_state() {
    _sf="$(usb_watch_state_path)"
    [ -f "$_sf" ] || return 0
    _tmp="${_sf}.tunnel-clear.$$"
    awk '!/^(TUNNEL_LAST_|TUNNEL_BOUNCE_|TUNNEL_HS_|TUNNEL_PING_|TUNNEL_ICMP_FAIL_|TUNNEL_PROTON_RENEW_)/ { print }' "$_sf" >"$_tmp" 2>/dev/null || return 0
    mv -f "$_tmp" "$_sf" 2>/dev/null || rm -f "$_tmp" 2>/dev/null || true
}

usb_watch_tunnel_hs_label_cached() {
    _iface="$1"
    _tok="$(usb_watch_tunnel_sanitize_iface "$_iface")"
    _hs="$(usb_watch_state_get "$(usb_watch_tunnel_state_key_hs "$_tok")" "")"
    case "$_hs" in
        ok) printf 'hs=ok' ;;
        stale) printf 'hs=stale' ;;
        none) printf 'hs=none' ;;
        down) printf 'hs=down' ;;
        unknown) printf 'hs=?' ;;
        '')
            # Live fallback when status opened before first tick.
            _dir="$(usb_watch_tunnel_interfaces_dir 2>/dev/null || true)"
            _cfg="${_dir:+$_dir/$_iface/config/iface.conf}"
            _dev="$(usb_watch_tunnel_read_vpn_dev "$_iface" "${_cfg:-/dev/null}")"
            if usb_watch_tunnel_handshake_lib_load 2>/dev/null && command -v vpn_handshake_status_label >/dev/null 2>&1; then
                vpn_handshake_status_label "$_dev"
            else
                printf 'hs=?'
            fi
            ;;
        *) printf 'hs=?' ;;
    esac
}

usb_watch_tunnel_format_status_lines() {
    _ifaces="$(usb_watch_tunnel_list_profile_ifaces || true)"
    [ -n "$_ifaces" ] || {
        printf '  TUNNEL_PROBE : (нет интерфейсов в профиле)\n'
        return 0
    }
    if ! usb_watch_tunnel_probe_enabled; then
        printf '  TUNNEL_PROBE : выкл. (TUNNEL_PROBE_ENABLED=0)\n'
        return 0
    fi
    _tb_max="$(usb_watch_tunnel_bounce_max)"
    _fail_max="$(usb_watch_tunnel_icmp_fail_max)"
    _pgr="${USB_WATCH_PROTON_GUEST_RENEW:-expiry}"
    printf '  TUNNEL_PROBE : ICMP+handshake (WAN full); fail max %s; bounce max %s; guest renew=%s\n' \
        "$_fail_max" "$_tb_max" "$_pgr"
    printf '%s\n' "$_ifaces" | while IFS= read -r _iface; do
        [ -n "$_iface" ] || continue
        _tok="$(usb_watch_tunnel_sanitize_iface "$_iface")"
        _last="$(usb_watch_tunnel_get_last "$_iface")"
        _bc="$(usb_watch_tunnel_get_bounce_count "$_iface")"
        _fc="$(usb_watch_tunnel_get_icmp_fail "$_iface")"
        _act="$(usb_watch_tunnel_get_last_action "$_iface")"
        _ping="$(usb_watch_state_get "$(usb_watch_tunnel_state_key_ping "$_tok")" "")"
        _hs_lbl="$(usb_watch_tunnel_hs_label_cached "$_iface")"

        case "$_ping" in
            ok) _ping_lbl='ping=ok' ;;
            fail) _ping_lbl='ping=FAIL' ;;
            *) _ping_lbl='ping=—' ;;
        esac

        case "$_act" in
            bounce) _act_lbl='last=bounce' ;;
            reload-error) _act_lbl='last=reload-error' ;;
            guest-renew) _act_lbl='last=guest-renew' ;;
            guest-renew-error|guest-renew-error) _act_lbl='last=guest-renew-error' ;;
            *) _act_lbl='last=none' ;;
        esac
        _marker=""
        if command -v proton_guest_renew_marker_line >/dev/null 2>&1 || usb_watch_proton_guest_renew_lib_load 2>/dev/null; then
            _marker="$(proton_guest_renew_marker_line "$_iface" 2>/dev/null || true)"
        fi
        [ -n "$_marker" ] && _act_lbl="${_act_lbl} ${_marker}"

        case "$_last" in
            ok)
                _lbl="OK  ${_ping_lbl} ${_hs_lbl} ${_act_lbl}"
                ;;
            exhausted)
                _lbl="FAIL paused  ${_ping_lbl} ${_hs_lbl} fail=${_fc}/${_fail_max} bounce=${_bc}/${_tb_max} ${_act_lbl}"
                ;;
            fail)
                _lbl="FAIL  ${_ping_lbl} ${_hs_lbl} fail=${_fc}/${_fail_max} bounce=${_bc}/${_tb_max} ${_act_lbl}"
                ;;
            '')
                _lbl="—  ${_hs_lbl}"
                ;;
            *)
                _lbl="${_last}  ${_ping_lbl} ${_hs_lbl} fail=${_fc}/${_fail_max} bounce=${_bc}/${_tb_max} ${_act_lbl}"
                ;;
        esac
        printf '    - %s : %s\n' "$_iface" "$_lbl"
    done
}
