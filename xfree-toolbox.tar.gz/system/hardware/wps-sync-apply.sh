#!/bin/sh
# shellcheck shell=sh
# WPS work: пайплайн «1 Обновить и применить» (sync + upgrade + upstream preflight).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"
XFREE_TOOLBOX_ROOT="${XFREE_TOOLBOX_ROOT:-$ROOT_DIR}"

. "$XFREE_TOOLBOX_ROOT/lib/common.sh"
load_base_config "$XFREE_TOOLBOX_ROOT"

ONCE_FLAG="/tmp/xfree-wps-sync-apply.once"
WPS_LOG_FILE="${XFREE_BG_TASK_LOG_FILE:-${XFREE_WPS_SYNC_APPLY_LOG_FILE:-${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}/wps-sync-apply.log}}"
PIPELINE_SH="$XFREE_TOOLBOX_ROOT/templates/update-and-apply-pipeline.sh"

FACTORY_PUBLIC_BASE="${FACTORY_PUBLIC_BASE:-${XFREE_FACTORY_PUBLIC_BASE:-}}"
INSTALL_SCRIPT_NAME="${INSTALL_SCRIPT_NAME:-${XFREE_INSTALL_SCRIPT_NAME:-install-from-cloud.sh}}"
LOCAL_INSTALL_SCRIPT="$XFREE_TOOLBOX_ROOT/system/install-from-cloud.sh"
APK_REGISTRY_SH="$XFREE_TOOLBOX_ROOT/lib/apk-registry.sh"
if [ -f "$APK_REGISTRY_SH" ]; then
    # shellcheck disable=SC1090
    . "$APK_REGISTRY_SH"
fi

wps_log() {
    _msg="$*"
    logger -t xfree-wps-sync-apply "$_msg" 2>/dev/null || true
    printf '%s\n' "$_msg" >&2
}

wps_trim_trailing_slash() {
    _v="$1"
    while :; do
        case "$_v" in
            */) _v="${_v%/}" ;;
            *) break ;;
        esac
    done
    printf '%s' "$_v"
}

wps_resolve_install_script() {
    _name="$INSTALL_SCRIPT_NAME"
    _tmp="/tmp/${_name}.wps.$$"
    _url=""

    if command -v xfree_apk_feed_install_url >/dev/null 2>&1; then
        _url="$(xfree_apk_feed_install_url 2>/dev/null || true)"
    fi
    if [ -z "$_url" ]; then
        _factory="$(wps_trim_trailing_slash "${FACTORY_PUBLIC_BASE:-}")"
        [ -n "$_factory" ] && _url="$_factory/$_name"
    fi

    if [ -n "$_url" ]; then
        wps_log "cloud: wget $_url"
        if command -v curl >/dev/null 2>&1; then
            if curl --http1.1 -fL --retry 3 --connect-timeout 15 -o "$_tmp" "$_url" 2>/dev/null && [ -s "$_tmp" ]; then
                chmod +x "$_tmp" 2>/dev/null || true
                printf '%s\n' "$_tmp"
                return 0
            fi
        elif command -v wget >/dev/null 2>&1; then
            if wget -q -O "$_tmp" "$_url" 2>/dev/null && [ -s "$_tmp" ]; then
                chmod +x "$_tmp" 2>/dev/null || true
                printf '%s\n' "$_tmp"
                return 0
            fi
        fi
        rm -f "$_tmp" 2>/dev/null || true
        wps_log "cloud: remote download failed, trying local install-from-cloud"
    else
        wps_log "cloud: no factory/GitHub install URL, using local install-from-cloud"
    fi

    if [ -f "$LOCAL_INSTALL_SCRIPT" ]; then
        printf '%s\n' "$LOCAL_INSTALL_SCRIPT"
        return 0
    fi

    return 1
}

# Main — только при прямом запуске (не при source из тестов).
case "$0" in
    *wps-sync-apply.sh) ;;
    *) return 0 2>/dev/null || exit 0 ;;
esac

if [ -f "$ONCE_FLAG" ]; then
    wps_log "skip: already started (remove $ONCE_FLAG to retry)"
    exit 0
fi
: >"$ONCE_FLAG" 2>/dev/null || true

wps_log "start: wps-sync-apply log=$WPS_LOG_FILE pid=$$"
export XFREE_BG_TASK=1

[ -f "$PIPELINE_SH" ] || {
    wps_log "error: pipeline not found: $PIPELINE_SH"
    rm -f "$ONCE_FLAG" 2>/dev/null || true
    exit 1
}
# shellcheck disable=SC1091
. "$PIPELINE_SH"

_targets="$(templates_resolve_active_sync_targets "$XFREE_TOOLBOX_ROOT" 2>/dev/null || true)"
if [ -z "${_targets:-}" ]; then
    wps_log "error: active profile not ready for sync (config.sh / EXPORT-META.txt / profiles/)"
    rm -f "$ONCE_FLAG" 2>/dev/null || true
    exit 1
fi

_template_name="$(printf '%s' "$_targets" | cut -f1)"
_profile_name="$(printf '%s' "$_targets" | cut -f2)"

wps_log "pipeline: template=$_template_name profile=$_profile_name mode=sync"

if ! templates_sync_update_apply_pipeline \
    "$XFREE_TOOLBOX_ROOT" \
    "$_template_name" \
    "$_profile_name" \
    1 \
    1 \
    "WPS: обновить и применить ($_template_name)"; then
    wps_log "error: sync-update-apply pipeline failed"
    rm -f "$ONCE_FLAG" 2>/dev/null || true
    exit 1
fi

wps_log "done: sync-update-apply pipeline (template=$_template_name profile=$_profile_name)"
rm -f "$ONCE_FLAG" 2>/dev/null || true
exit 0
