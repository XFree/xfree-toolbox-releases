#!/bin/sh
# shellcheck shell=sh
# Hotplug profile-sync: отключить stock WPS (50-wps) + установить 90-xfree-wps-sync-apply.
#
# Канонический deploy (apk postinst, bootstrap, self-update):
#   install-button-hooks.sh --install [root]
#
# Проверка и доделка только при пропуске (старт xft, apply pipeline):
#   install-button-hooks.sh --ensure [--quiet] [root]
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
WPS_SYNC_HOOK_FILE="${WPS_SYNC_HOOK_FILE:-/etc/hotplug.d/button/90-xfree-wps-sync-apply}"

# shellcheck source=system/hardware/lib-sync-button.sh
. "$SCRIPT_DIR/lib-sync-button.sh"
# shellcheck source=system/hardware/lib-stock-wps-guard.sh
. "$SCRIPT_DIR/lib-stock-wps-guard.sh"

# Profile sync: pressed — latch (stamp); released — sync только при SEEN >= WPS_SYNC_HOLD_SEC (по умолчанию 3).
WPS_SYNC_HOLD_SEC="${WPS_SYNC_HOLD_SEC:-3}"
WPS_PRESS_STAMP="/tmp/xfree-wps-press.epoch"

button_hooks_usage() {
  cat <<'USAGE'
Usage: install-button-hooks.sh --install [root_dir]
       install-button-hooks.sh --ensure [--quiet] [root_dir]
       install-button-hooks.sh --remove
       install-button-hooks.sh --disable-stock-wps [root_dir]

  --install   postinst / deploy: stock WPS off + хук sync (перезаписывает хук)
  --ensure    проверка; если stock WPS активен или хука нет — тот же --install
  --remove    убрать хук xfree, восстановить stock WPS
USAGE
}

hardware_wps_sync_hook_is_installed() {
  [ -f "$WPS_SYNC_HOOK_FILE" ] && [ -x "$WPS_SYNC_HOOK_FILE" ]
}

# 0 = stock WPS off и хук на месте
button_hooks_satisfied() {
  hardware_wps_sync_hook_is_installed || return 1
  if hardware_sync_button_has_name wps 2>/dev/null \
    && hardware_stock_wps_hotplug_is_active 2>/dev/null; then
    return 1
  fi
  return 0
}

install_wps_sync_apply_hook() {
  root_dir="${1:-/root/xfree-toolbox}"
  quiet="${2:-0}"
  hook_file="$WPS_SYNC_HOOK_FILE"
  hook_dir="$(dirname -- "$hook_file")"
  runner="$root_dir/system/hardware/wps-sync-apply.sh"
  bg_run="$root_dir/lib/bg-task-run.sh"
  bg_lib="$root_dir/lib/background-tasks.sh"
  hold_sec="$WPS_SYNC_HOLD_SEC"
  sync_buttons="$(hardware_sync_button_resolve_list)"

  hardware_disable_stock_wps_hotplug

  mkdir -p "$hook_dir"
  chmod +x "$runner" 2>/dev/null || true
  chmod +x "$bg_run" 2>/dev/null || true
  _hotplug_log="/tmp/xfree-wps-hotplug.log"
  _press_stamp="$WPS_PRESS_STAMP"
  {
    cat <<EOF
#!/bin/sh
# xfree-toolbox: install-from-cloud --apply-mode sync on released при SEEN >= ${hold_sec}
# buttons: ${sync_buttons}

EOF
    hardware_sync_button_hotplug_guard_lines
    cat <<EOF

EOF
    hardware_sync_button_wps_hold_snippet
    cat <<EOF

_press_stamp="$_press_stamp"
_hold_need=$hold_sec
_hotplug_log="$_hotplug_log"

if [ "\${ACTION:-}" = "pressed" ]; then
  if _wps_press_latch "\$_press_stamp"; then
    _msg="pressed BUTTON=\${BUTTON:-?} SEEN=\${SEEN:-?} stamp=\$(cat "\$_press_stamp" 2>/dev/null || echo ?) (start)"
  else
    _msg="pressed BUTTON=\${BUTTON:-?} SEEN=\${SEEN:-?} stamp kept (debounce, <3s)"
  fi
  printf '[%s] %s\n' "\$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)" "\$_msg" >>"\$_hotplug_log" 2>/dev/null || true
  logger -t xfree-wps-sync-apply "\$_msg" 2>/dev/null || true
  exit 0
fi

[ "\${ACTION:-}" = "released" ] || exit 0

_seen_raw="\${SEEN:-?}"
_seen_n="\${SEEN:-0}"
case "\$_seen_n" in
  ''|*[!0-9]*) _seen_n="\$(_wps_seen_num "\${SEEN:-0}")" ;;
esac
case "\$_seen_n" in ''|*[!0-9]*) _seen_n=0 ;; esac

# Дребезг: released без SEEN — stamp не сбрасываем (latch на pressed).
if [ "\$_seen_n" -eq 0 ] 2>/dev/null; then
  printf '[%s] released bounce BUTTON=%s SEEN_raw=%s seen_n=%s stamp kept\n' "\$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)" "\${BUTTON:-?}" "\$_seen_raw" "\$_seen_n" >>"\$_hotplug_log" 2>/dev/null || true
  logger -t xfree-wps-sync-apply "released bounce seen_n=\${_seen_n} (stamp kept)" 2>/dev/null || true
  exit 0
fi

rm -f "\$_press_stamp" 2>/dev/null || true

  printf '[%s] released BUTTON=%s SEEN_raw=%s seen_n=%s need>=%s\n' "\$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)" "\${BUTTON:-?}" "\$_seen_raw" "\$_seen_n" "\$_hold_need" >>"\$_hotplug_log" 2>/dev/null || true

if [ "\$_seen_n" -lt "\$_hold_need" ] 2>/dev/null; then
  logger -t xfree-wps-sync-apply "skip: seen_n=\${_seen_n} need>=\$_hold_need" 2>/dev/null || true
  exit 0
fi

if [ -f "$bg_lib" ]; then
  if ( # shellcheck disable=SC1090
    . "$bg_lib" 2>/dev/null
    bg_tasks_is_running
  ); then
    logger -t xfree-wps-sync-apply "skip: background task already running" 2>/dev/null || true
    exit 0
  fi
fi

if [ -f "$bg_run" ] && [ -f "$runner" ]; then
  logger -t xfree-wps-sync-apply "launch: bg-task-run wps-sync-apply BUTTON=\${BUTTON:-?} seen_n=\${_seen_n}s" 2>/dev/null || true
  (
    sh "$bg_run" wps-sync-apply -- sh "$runner"
  ) >>"\$_hotplug_log" 2>&1 &
elif [ -f "$runner" ]; then
  logger -t xfree-wps-sync-apply "launch: wps-sync-apply (no bg-task-run) seen_n=\${_seen_n}s" 2>/dev/null || true
  ( sh "$runner" ) >>"\$_hotplug_log" 2>&1 &
else
  logger -t xfree-wps-sync-apply "error: missing $runner" 2>/dev/null || true
fi
exit 0
EOF
  } >"$hook_file"
  chmod +x "$hook_file" 2>/dev/null || true
  if [ "$quiet" = "0" ]; then
    echo "Installed: $hook_file (buttons: $sync_buttons)"
  fi
}

ensure_wps_sync_button_hooks() {
  root_dir="${1:-/root/xfree-toolbox}"
  quiet="${2:-0}"

  if button_hooks_satisfied; then
    [ "$quiet" = "0" ] && echo "WPS sync hotplug: OK (stock WPS off, хук на месте)"
    return 0
  fi

  [ "$quiet" = "0" ] && echo "WPS sync hotplug: доделка (stock WPS / хук)…"
  install_wps_sync_apply_hook "$root_dir" "$quiet"
  return 0
}

remove_wps_sync_apply_hook() {
  hook_file="$WPS_SYNC_HOOK_FILE"
  [ -f "$hook_file" ] || return 0
  rm -f "$hook_file" 2>/dev/null || true
  hardware_restore_stock_wps_hotplug
}

ROOT_ARG="/root/xfree-toolbox"
QUIET=0
MODE=""

while [ "$#" -gt 0 ]; do
  case "$1" in
    --install|--ensure|--remove|--disable-stock-wps)
      MODE="$1"
      ;;
    --quiet) QUIET=1 ;;
    -h|--help)
      button_hooks_usage
      exit 0
      ;;
    --root)
      shift
      [ "$#" -gt 0 ] || { button_hooks_usage >&2; exit 2; }
      ROOT_ARG="$(CDPATH= cd -- "$1" && pwd -P)"
      ;;
    *)
      ROOT_ARG="$(CDPATH= cd -- "$1" && pwd -P)"
      ;;
  esac
  shift
done

case "$MODE" in
  --install)
    install_wps_sync_apply_hook "$ROOT_ARG" "$QUIET"
    ;;
  --ensure)
    ensure_wps_sync_button_hooks "$ROOT_ARG" "$QUIET"
    ;;
  --remove)
    remove_wps_sync_apply_hook
    ;;
  --disable-stock-wps)
    if hardware_sync_button_has_name wps 2>/dev/null; then
      hardware_disable_stock_wps_hotplug
      [ "$QUIET" = "0" ] && echo "Stock WPS hotplug отключён (если был активен)"
    else
      [ "$QUIET" = "0" ] && echo "Кнопка sync не WPS — stock WPS не трогаем"
    fi
    ;;
  *)
    button_hooks_usage >&2
    exit 1
    ;;
esac

exit 0
