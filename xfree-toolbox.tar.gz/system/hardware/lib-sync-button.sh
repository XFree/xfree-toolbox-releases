#!/bin/sh
# shellcheck shell=sh
# Resolve hardware button name(s) for profile sync+apply hotplug.
set -eu

[ -n "${SCRIPT_DIR:-}" ] || SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
HARDWARE_KNOWN_ROUTER_DIR="$SCRIPT_DIR"

# shellcheck source=system/hardware/lib-known-router.sh
. "$SCRIPT_DIR/lib-known-router.sh"

hardware_sync_button_known_db() {
  hardware_known_router_db
}

hardware_sync_button_wps_hold_snippet() {
  awk '/WPS_HOLD_SNIPPET_START/{p=1;next} /WPS_HOLD_SNIPPET_END/{p=0;next} p' \
    "$SCRIPT_DIR/wps-hold-hotplug.inc.sh"
}

# Space-separated button names accepted by hotplug (e.g. "wps" or "mesh" or "wps mesh").
hardware_sync_button_resolve_list() {
  if [ -n "${XFREE_SYNC_BUTTON:-}" ]; then
    printf '%s\n' "$XFREE_SYNC_BUTTON"
    return 0
  fi

  _sync="$(hardware_known_router_sync_button 2>/dev/null || true)"
  if [ -n "$_sync" ]; then
    printf '%s\n' "$_sync"
    return 0
  fi

  printf '%s\n' "wps mesh"
}

hardware_sync_button_resolve_primary() {
  _list="$(hardware_sync_button_resolve_list)"
  # shellcheck disable=SC2086
  set -- $_list
  printf '%s\n' "${1:-wps}"
}

hardware_sync_button_has_name() {
  _want="$1"
  _list="$(hardware_sync_button_resolve_list)"
  for _b in $_list; do
    [ "$_b" = "$_want" ] && return 0
  done
  return 1
}

# Prints a case block for hotplug: match listed BUTTON values or exit 0.
# BusyBox ash: multiple patterns must be on one line (mesh|BTN_9), not stacked.
hardware_sync_button_hotplug_guard_lines() {
  _buttons="$(hardware_sync_button_resolve_list)"
  _patterns=""
  # shellcheck disable=SC2086
  for _b in $_buttons; do
    if [ -n "$_patterns" ]; then
      _patterns="${_patterns}|${_b}"
    else
      _patterns="$_b"
    fi
  done
  printf '%s\n' 'case "${BUTTON:-}" in'
  printf '  %s)\n' "$_patterns"
  cat <<'EOF'
    ;;
  *)
    exit 0
    ;;
esac
EOF
}

hardware_sync_button_menu_label() {
  _primary="$(hardware_sync_button_resolve_primary)"
  case "$_primary" in
    mesh) printf '%s\n' "Mesh" ;;
    wps) printf '%s\n' "WPS" ;;
    BTN_0|mode) printf '%s\n' "Mode" ;;
    *) printf '%s\n' "$_primary" ;;
  esac
}

case "${1:-}" in
  --primary)
    hardware_sync_button_resolve_primary
    exit 0
    ;;
  --list)
    hardware_sync_button_resolve_list
    exit 0
    ;;
  --menu-label)
    hardware_sync_button_menu_label
    exit 0
    ;;
  --has-wps)
    hardware_sync_button_has_name wps && printf '1\n' || printf '0\n'
    exit 0
    ;;
  --has-mesh)
    if hardware_sync_button_has_name mesh || hardware_sync_button_has_name BTN_9; then
      printf '1\n'
    else
      printf '0\n'
    fi
    exit 0
    ;;
esac
