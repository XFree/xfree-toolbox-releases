# shellcheck shell=sh
# Фрагмент для встраивания в hotplug (не вызывать напрямую).
# Проблема gpio-keys: серия pressed/released; каждый pressed перезаписывал stamp → hold занижен.
#
# WPS_HOLD_SNIPPET_START
_wps_now_sec() {
  date +%s 2>/dev/null || echo 0
}

# pressed: только первое нажатие в серии (повторные pressed <3s не сдвигают старт).
_wps_press_latch() {
  _stamp="$1"
  _n="$(_wps_now_sec)"
  if [ -f "$_stamp" ]; then
    _p="$(cat "$_stamp" 2>/dev/null || true)"
    case "$_p" in
      ''|*[!0-9]*) ;;
      *)
        if [ "$_n" -ge "$_p" ] && [ $(( _n - _p )) -lt 3 ]; then
          return 1
        fi
        ;;
    esac
  fi
  printf '%s\n' "$_n" >"$_stamp" 2>/dev/null || true
  return 0
}

# Только цифры из SEEN (без tr — на части OpenWrt tr -cd ломается / даёт пусто).
_wps_seen_num() {
  _in="${1:-0}"
  _out=""
  _rest="$_in"
  while [ -n "$_rest" ]; do
    _ch="${_rest%"${_rest#?}"}"
    _rest="${_rest#?}"
    case "$_ch" in
      0|1|2|3|4|5|6|7|8|9) _out="${_out}${_ch}" ;;
    esac
  done
  [ -n "$_out" ] || _out=0
  printf '%s\n' "$_out"
}

# released: порог sync — SEEN >= $1 (секунды от gpio-keys на released).
_wps_seen_ge_threshold() {
  _need="$1"
  _seen="${2:-${SEEN:-0}}"
  case "$_need" in
    ''|*[!0-9]*) _need="$(_wps_seen_num "$_need")" ;;
  esac
  case "$_seen" in
    ''|*[!0-9]*) _seen="$(_wps_seen_num "$_seen")" ;;
  esac
  case "$_need" in ''|*[!0-9]*) _need=0 ;; esac
  case "$_seen" in ''|*[!0-9]*) _seen=0 ;; esac
  [ "$_seen" -ge "$_need" ]
}

# Справочно (не для порога sync): hold = max(epoch, SEEN). Порог sync — только SEEN на released.
_wps_hold_sec() {
  _stamp="$1"
  _seen="$(_wps_seen_num "${2:-${SEEN:-0}}")"
  _n="$(_wps_now_sec)"
  _p="$(cat "$_stamp" 2>/dev/null || true)"
  case "$_p" in ''|*[!0-9]*) _p=0 ;; esac
  if [ "$_p" -eq 0 ] && [ "$_seen" -gt 0 ]; then
    printf '%s\n' "$_seen"
    return 0
  fi
  _epoch=0
  if [ "$_n" -gt 0 ] && [ "$_p" -gt 0 ] && [ "$_n" -ge "$_p" ]; then
    _epoch=$(( _n - _p ))
  fi
  if [ "$_epoch" -ge "$_seen" ]; then
    printf '%s\n' "$_epoch"
  else
    printf '%s\n' "$_seen"
  fi
}
# WPS_HOLD_SNIPPET_END
