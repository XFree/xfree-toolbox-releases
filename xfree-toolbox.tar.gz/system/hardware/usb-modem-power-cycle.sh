#!/bin/sh
# shellcheck shell=sh
# Публичная команда на роутере: /usr/sbin/usb-modem-power-cycle → этот скрипт.
# Usage: usb-modem-power-cycle [off_sec] [on_sec]
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

exec sh "$ROOT_DIR/system/hardware/usb-power.sh" cycle "$@"
