#!/bin/sh
# shellcheck shell=sh
# Отключение штатного OpenWrt WPS/mesh (hotplug + rc.button + rc.wps) когда та же кнопка — profile sync.
# Иначе pressed → hostapd wps_pbc / multi_ap mesh рвёт STA uplink на том же radio (wwan).
# На Cudy/OpenWrt 25 часто нет hotplug.d/button/50-wps — WPS идёт через /etc/rc.button/wps.
# wpad-mesh-mbedtls переустанавливает rc.button/wps и /etc/rc.wps/* — guard должен отключать повторно.

STOCK_WPS_DISABLED_LIST="${STOCK_WPS_DISABLED_LIST:-/etc/xfree-toolbox.stock-wps-disabled.list}"
STOCK_WPS_HOTPLUG_DIR="${STOCK_WPS_HOTPLUG_DIR:-/etc/hotplug.d/button}"
STOCK_WPS_RC_BUTTON_DIR="${STOCK_WPS_RC_BUTTON_DIR:-/etc/rc.button}"
STOCK_WPS_RC_WPS_DIR="${STOCK_WPS_RC_WPS_DIR:-/etc/rc.wps}"

hardware_stock_wps_hotplug_names() {
  printf '%s\n' 50-wps wps
}

hardware_stock_mesh_hotplug_names() {
  printf '%s\n' 50-mesh mesh
}

hardware_stock_wps_rc_button_names() {
  printf '%s\n' wps
}

hardware_stock_mesh_rc_button_names() {
  printf '%s\n' mesh
}

hardware_stock_wps_disable_one() {
  _src="$1"
  [ -f "$_src" ] || return 1
  _bak="${_src}.xfree-stock.bak"
  if [ -f "$_bak" ]; then
    # wpad/wifi-scripts переустановили handler рядом с бэкапом
    rm -f "$_bak" || return 1
  fi
  mv "$_src" "$_bak" || return 1
  grep -Fxq "$_src" "$STOCK_WPS_DISABLED_LIST" 2>/dev/null \
    || printf '%s\n' "$_src" >>"$STOCK_WPS_DISABLED_LIST"
  printf 'Disabled stock button handler: %s → %s\n' "$_src" "$_bak"
  return 0
}

hardware_stock_wps_disable_dir_entries() {
  _dir="$1"
  _changed=0
  [ -d "$_dir" ] || return 1
  _entry=""
  for _entry in "$_dir"/*; do
    [ -f "$_entry" ] || continue
    case "$_entry" in
      *.xfree-stock.bak) continue ;;
    esac
    if hardware_stock_wps_disable_one "$_entry"; then
      _changed=1
    fi
  done
  [ "$_changed" = "1" ] && return 0
  return 1
}

# Есть ли активный штатный обработчик WPS/mesh (hotplug, rc.button, rc.wps).
hardware_stock_wps_hotplug_is_active() {
  _name=""
  for _name in $(hardware_stock_wps_hotplug_names); do
    [ -f "$STOCK_WPS_HOTPLUG_DIR/$_name" ] && return 0
  done
  for _name in $(hardware_stock_mesh_hotplug_names); do
    [ -f "$STOCK_WPS_HOTPLUG_DIR/$_name" ] && return 0
  done
  for _name in $(hardware_stock_wps_rc_button_names); do
    [ -f "$STOCK_WPS_RC_BUTTON_DIR/$_name" ] && return 0
  done
  for _name in $(hardware_stock_mesh_rc_button_names); do
    [ -f "$STOCK_WPS_RC_BUTTON_DIR/$_name" ] && return 0
  done
  if [ -d "$STOCK_WPS_RC_WPS_DIR" ]; then
    for _entry in "$STOCK_WPS_RC_WPS_DIR"/*; do
      [ -f "$_entry" ] || continue
      case "$_entry" in
        *.xfree-stock.bak) continue ;;
      esac
      return 0
    done
  fi
  return 1
}

hardware_disable_stock_wps_hotplug() {
  _disabled=0

  if ! hardware_sync_button_has_name wps 2>/dev/null; then
    return 0
  fi

  mkdir -p "$(dirname -- "$STOCK_WPS_DISABLED_LIST")" 2>/dev/null || true
  : >>"$STOCK_WPS_DISABLED_LIST" 2>/dev/null || true

  _name=""
  for _name in $(hardware_stock_wps_hotplug_names) $(hardware_stock_mesh_hotplug_names); do
    if hardware_stock_wps_disable_one "$STOCK_WPS_HOTPLUG_DIR/$_name"; then
      _disabled=1
    fi
  done
  for _name in $(hardware_stock_wps_rc_button_names) $(hardware_stock_mesh_rc_button_names); do
    if hardware_stock_wps_disable_one "$STOCK_WPS_RC_BUTTON_DIR/$_name"; then
      _disabled=1
    fi
  done
  if hardware_stock_wps_disable_dir_entries "$STOCK_WPS_RC_WPS_DIR"; then
    _disabled=1
  fi

  if [ "$_disabled" = "1" ]; then
    logger -t xfree-wps-sync-apply \
      "stock WPS/mesh disabled (profile sync uses same button)" 2>/dev/null || true
  fi
  return 0
}

hardware_restore_stock_wps_hotplug() {
  [ -f "$STOCK_WPS_DISABLED_LIST" ] || return 0

  while IFS= read -r _src || [ -n "${_src:-}" ]; do
    [ -n "$_src" ] || continue
    _bak="${_src}.xfree-stock.bak"
    [ -f "$_bak" ] || continue
    mv "$_bak" "$_src" 2>/dev/null || true
  done <"$STOCK_WPS_DISABLED_LIST"

  rm -f "$STOCK_WPS_DISABLED_LIST" 2>/dev/null || true
  return 0
}
