#!/bin/sh
# shellcheck shell=sh
# Интерактивный тест LED:
# - snapshot всех LED
# - blackout (погасить все)
# - по одному: мигание
# - проверка pair-blink (WAN↔WPS) через общий runtime
# - восстановление исходного состояния
#
# Usage: led-test.sh [--delay SEC] [--list-only] [--out FILE]
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib-board.sh"
. "$ROOT_DIR/lib/led/led-lib.sh"

DELAY=5
OUT_FILE=""
LIST_ONLY=0
BLINK_HALF_SEC=1

while [ $# -gt 0 ]; do
    case "$1" in
        --delay)
            shift
            DELAY="${1:-5}"
            shift
            ;;
        --out)
            shift
            OUT_FILE="${1:-}"
            [ -n "$OUT_FILE" ] || die "led-test.sh: --out requires a path"
            shift
            ;;
        --list-only)
            LIST_ONLY=1
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--delay SEC] [--list-only] [--out FILE]"
            exit 0
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
done

_emit() {
    if [ -n "$OUT_FILE" ]; then
        printf '%s\n' "$*" >>"$OUT_FILE"
    else
        printf '%s\n' "$*"
    fi
}

_ts() {
    date '+%H:%M:%S' 2>/dev/null || echo "--:--:--"
}

_log() {
    _emit "[$(_ts)] $*"
}

if [ -n "$OUT_FILE" ]; then
    : >"$OUT_FILE"
fi

_emit ""
_log "Тест LED-индикаторов ($(hardware_board_summary_line))"
_log "Источник: все записи в /sys/class/leds/"
_log "План: snapshot -> blackout -> по одному мигание -> pair-blink -> restore."
_log "Каждый индикатор: мигание примерно ${DELAY} секунд."
_emit ""

if [ ! -d /sys/class/leds ]; then
    die "Нет /sys/class/leds — LED subsystem недоступен"
fi

led_count=0
for _n in $(hardware_led_list_sysfs_sorted); do
    [ -n "$_n" ] && led_count=$((led_count + 1))
done

if [ "$led_count" -eq 0 ]; then
    die "В /sys/class/leds/ нет LED"
fi

_log "Найдено LED: $led_count"
_emit ""

if [ "$LIST_ONLY" = "1" ]; then
    _log "LED в /sys/class/leds:"
    hardware_led_list_sysfs_sorted | while read -r n; do
        [ -n "$n" ] || continue
        _emit "  $n"
    done
    exit 0
fi

_log "[1/5] Захватываю исходное состояние всех LED..."
for name in $(hardware_led_list_sysfs_sorted); do
    [ -n "$name" ] || continue
    hardware_led_capture_state "$name" 2>/dev/null || true
done
_log "  OK"
_emit ""

_log "[2/5] Blackout: гашу все LED..."
for name in $(hardware_led_list_sysfs_sorted); do
    [ -n "$name" ] || continue
    hardware_led_off "$name" 2>/dev/null || true
done
sleep 1
_log "  OK"
_emit ""

_log "[3/5] Поочерёдный тест LED (мигание)..."
for name in $(hardware_led_list_sysfs_sorted); do
    [ -n "$name" ] || continue
    LED="/sys/class/leds/$name"

    _emit "============================================================"
    hardware_led_describe "$name" | while read -r line; do
        _log "$line"
    done
    _emit ""

    _log "Текущее состояние перед тестом:"
    _log "trigger: $(cat "$LED/trigger" 2>/dev/null || echo '?')"
    _log "brightness: $(cat "$LED/brightness" 2>/dev/null || echo '?')"
    _emit ""

    _log "Мигаю $name примерно ${DELAY} секунд..."
    hardware_led_on "$name" 2>/dev/null || _log "(!) не удалось включить $name"
    _cycles=$((DELAY / BLINK_HALF_SEC))
    [ "$_cycles" -lt 1 ] && _cycles=1
    _i=0
    while [ "$_i" -lt "$_cycles" ]; do
        if [ $((_i % 2)) -eq 0 ]; then
            hardware_led_on "$name" 2>/dev/null || true
        else
            hardware_led_off "$name" 2>/dev/null || true
        fi
        sleep "$BLINK_HALF_SEC"
        _i=$((_i + 1))
    done

    _log "Восстанавливаю $name (trigger/brightness из сохранённого или UCI)."
    if hardware_led_release "$name"; then
        _log "  OK"
    else
        _log "  (!) не удалось — будет общий restore в конце"
    fi
    _emit ""

    sleep 1
done

_emit ""
_log "[4/5] Проверка pair-blink (пара из known-routers.tsv)..."
if _pair="$(hardware_led_bg_task_pair_resolve 2>/dev/null)" && hardware_led_bg_task_blink_start 2>/dev/null; then
    _a="${_pair%%	*}"
    _b="${_pair#*	}"
    _log "  Pair-blink ${_a}↔${_b}, жду 4 сек..."
    sleep 4
    hardware_led_bg_task_blink_stop 2>/dev/null || true
    _log "  Pair-blink остановлен."
else
    _log "  Pair-blink недоступен на этой плате (пропуск)."
fi

_emit ""
_log "[5/5] Финальное восстановление LED-состояния..."
for name in $(hardware_led_list_sysfs_sorted); do
    [ -n "$name" ] || continue
    hardware_led_release "$name" 2>/dev/null || true
done
_log "Восстанавливаю LED-настройки из UCI, если служба led доступна."

if hardware_led_restore_uci; then
    _log "Служба led перезапущена."
else
    _log "Служба led недоступна — проверьте /etc/config/system вручную."
fi

_log "Готово. Исходные состояния LED восстановлены."
