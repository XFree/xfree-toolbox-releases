#!/bin/sh
# shellcheck shell=sh
exec sh "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)/usb-power-watch-upgrade.sh" "$@"
