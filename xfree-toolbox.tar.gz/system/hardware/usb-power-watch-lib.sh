#!/bin/sh
# shellcheck shell=sh
# Конфиг, state и логика мониторинга uplink (probe на PROBE_IFACE → LED → опц. USB cycle → recovery).

USB_WATCH_CRON_MARKER='# xfree-toolbox-usb-power-watch'
CONNECTIVITY_WATCH_CRON_MARKER='# xfree-toolbox-connectivity-watch'

USB_WATCH_RUNTIME_CONF_KEYS="
FAIL_COUNT
LAST_TICK
LAST_PROBE_BASE
LAST_PROBE_ALT
LAST_PROBE_EVAL
CONNECTIVITY_DEGRADED
LAST_CYCLE_EPOCH
CYCLE_COUNT
CYCLE_EXHAUSTED
EXHAUST_AUTO_LEVEL
EXHAUST_LOCK_EPOCH
NET_LED_MODE
BOOT_RESET_DONE
"

USB_WATCH_EXHAUST_RETRY_MINUTES="5 10 15 30 60"

if [ -n "${USB_WATCH_ROOT_DIR:-}" ]; then
    _usb_watch_toolbox_root="$USB_WATCH_ROOT_DIR"
elif [ -n "${XFREE_TOOLBOX_ROOT:-}" ]; then
    _usb_watch_toolbox_root="$XFREE_TOOLBOX_ROOT"
else
    _usb_watch_lib_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    _usb_watch_toolbox_root="$(CDPATH= cd -- "$_usb_watch_lib_dir/../.." && pwd -P)"
fi
if [ -f "$_usb_watch_toolbox_root/system/hardware/lib-uplink-detect.sh" ]; then
    # shellcheck disable=SC1091
    . "$_usb_watch_toolbox_root/system/hardware/lib-uplink-detect.sh"
fi
if [ -f "$_usb_watch_toolbox_root/lib/log-ring.sh" ]; then
    # shellcheck disable=SC1091
    . "$_usb_watch_toolbox_root/lib/log-ring.sh"
fi
if [ -f "$_usb_watch_toolbox_root/system/hardware/usb-watch-tunnel-probe.sh" ]; then
    # shellcheck disable=SC1091
    . "$_usb_watch_toolbox_root/system/hardware/usb-watch-tunnel-probe.sh"
fi

# PROFILE_DIR for tunnel/recovery when common.sh is not preloaded (e.g. «Проверить сейчас» subprocess).
# Must source common.sh *before* requiring common_profile_dir — otherwise list stays empty while cron/status work.
usb_watch_ensure_profile_dir() {
    [ -n "${PROFILE_DIR:-}" ] && return 0
    _root="${1:-}"
    [ -n "$_root" ] || _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    if ! command -v common_profile_dir >/dev/null 2>&1; then
        [ -f "$_root/lib/common.sh" ] || return 1
        # shellcheck disable=SC1090
        . "$_root/lib/common.sh"
        if command -v load_base_config >/dev/null 2>&1; then
            load_base_config "$_root" 2>/dev/null || true
        fi
    fi
    command -v common_profile_dir >/dev/null 2>&1 || return 1
    PROFILE_DIR="$(common_profile_dir "$_root" 2>/dev/null || true)"
    [ -n "${PROFILE_DIR:-}" ]
}

usb_watch_conf_path() {
    printf '%s/system/usb-power-watch.conf' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

usb_watch_state_path() {
    printf '%s/system/usb-power-watch.state' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

usb_watch_run_log_path() {
    printf '%s/system/usb-power-watch.log' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

usb_watch_conf_get() {
    file="$1"
    key="$2"
    default="${3:-}"
    [ -f "$file" ] || {
        printf '%s' "$default"
        return 0
    }
    val="$(awk -F= -v want="$key" '
        $1 == want {
            v = substr($0, index($0, "=") + 1)
            gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
            gsub(/^\047|\047$/, "", v)
            print v
            exit
        }
    ' "$file" 2>/dev/null || true)"
    val="$(printf '%s' "${val:-}" | tr -d '\r')"
    [ -n "${val:-}" ] && printf '%s' "$val" || printf '%s' "$default"
}

usb_watch_conf_kv_set() {
    file="$1"
    key="$2"
    value="$3"
    mkdir -p "$(dirname "$file")" 2>/dev/null || true
    tmp="${file}.tmp.$$"
    if [ -f "$file" ]; then
        awk -v key="$key" -v value="$value" '
            BEGIN { done = 0 }
            $0 ~ ("^[[:space:]]*" key "[[:space:]]*=") {
                print key "=\047" value "\047"
                done = 1
                next
            }
            { print }
            END {
                if (!done) print key "=\047" value "\047"
            }
        ' "$file" >"$tmp"
    else
        printf '%s=\047%s\047\n' "$key" "$value" >"$tmp"
    fi
    mv -f "$tmp" "$file"
}

usb_watch_conf_set() {
    file="$1"
    key="$2"
    value="$3"
    if [ "$file" = "$(usb_watch_conf_path)" ]; then
        mkdir -p "$(dirname "$(usb_watch_conf_path)")" 2>/dev/null || true
        if [ ! -f "$file" ]; then
            usb_watch_conf_ensure
        fi
    fi
    usb_watch_conf_kv_set "$file" "$key" "$value"
}

usb_watch_conf_delete_key() {
    file="$1"
    key="$2"
    [ -f "$file" ] || return 0
    tmp="${file}.tmp.$$"
    awk -v key="$key" '$0 !~ ("^[[:space:]]*" key "[[:space:]]*=") { print }' "$file" >"$tmp" 2>/dev/null || return 1
    mv -f "$tmp" "$file"
}

usb_watch_conf_default_pairs() {
    cat <<'EOF'
TEST_URL|https://ya.ru/
TEST_URL_ALT|https://github.com/
PROBE_IFACE|auto
POWER_CYCLE|auto
INTERVAL_MIN|3
PROBE_INTERVAL_SEC|20
FAIL_MAX|3
CYCLE_MAX|3
OFF_SEC|8
ON_SEC|5
SETTLE_SEC|90
LED_STATUS|1
PARTIAL_CYCLE_SEC|5
PARTIAL_FAULT_SEC|2
TUNNEL_PROBE_ENABLED|1
TUNNEL_PROBE_SETTLE_SEC|15
TUNNEL_ICMP_FAIL_MAX|3
TUNNEL_BOUNCE_MAX|3
PROTON_GUEST_RENEW|expiry
PROTON_GUEST_RENEW_SKEW_SEC|600
PROTON_GUEST_RENEW_COOLDOWN_SEC|1800
PROTON_GUEST_RENEW_DEFAULTS_REV|1
EOF
}

usb_watch_conf_has_key() {
    file="$1"
    key="$2"
    [ -f "$file" ] && grep -qE "^[[:space:]]*${key}[[:space:]]*=" "$file" 2>/dev/null
}

usb_watch_conf_enabled_default() {
    if usb_watch_cron_installed; then
        printf '1\n'
    else
        printf '0\n'
    fi
}

# Перенести runtime-ключи из conf в state (legacy) и убрать из conf.
usb_watch_conf_sanitize_runtime_pollution() {
    _f="$(usb_watch_conf_path)"
    [ -f "$_f" ] || return 0
    _sf="$(usb_watch_state_path)"
    for _k in $USB_WATCH_RUNTIME_CONF_KEYS; do
        [ -n "$_k" ] || continue
        grep -qE "^[[:space:]]*${_k}[[:space:]]*=" "$_f" 2>/dev/null || continue
        _val="$(usb_watch_conf_get "$_f" "$_k" "")"
        if [ -n "$_val" ]; then
            _cur="$(usb_watch_conf_get "$_sf" "$_k" "")"
            [ -z "$_cur" ] && usb_watch_conf_kv_set "$_sf" "$_k" "$_val"
        fi
        usb_watch_conf_delete_key "$_f" "$_k"
    done
}

# Дописать в существующий conf ключи, появившиеся в новых версиях toolbox.
# PROTON_GUEST_RENEW: старый shipped default был off — один раз поднять до expiry
# (guest .conf живёт ~7 суток). После DEFAULTS_REV=1 явное off больше не трогаем.
usb_watch_conf_migrate_proton_guest_renew_default() {
    file="$(usb_watch_conf_path)"
    [ -f "$file" ] || return 0
    usb_watch_conf_has_key "$file" PROTON_GUEST_RENEW_DEFAULTS_REV && return 0
    _cur="$(usb_watch_conf_get "$file" PROTON_GUEST_RENEW "")"
    case "$_cur" in
        ''|off|OFF)
            usb_watch_conf_kv_set "$file" PROTON_GUEST_RENEW expiry
            ;;
    esac
    usb_watch_conf_kv_set "$file" PROTON_GUEST_RENEW_DEFAULTS_REV 1
}

usb_watch_conf_migrate_missing_keys() {
    file="$(usb_watch_conf_path)"
    [ -f "$file" ] || return 0
    usb_watch_conf_migrate_proton_guest_renew_default
    usb_watch_conf_default_pairs | while IFS='|' read -r _key _default; do
        [ -n "$_key" ] || continue
        usb_watch_conf_has_key "$file" "$_key" && continue
        usb_watch_conf_kv_set "$file" "$_key" "$_default"
    done
    usb_watch_conf_has_key "$file" ENABLED || \
        usb_watch_conf_kv_set "$file" ENABLED "$(usb_watch_conf_enabled_default)"
}

usb_watch_conf_ensure() {
    file="$(usb_watch_conf_path)"
    mkdir -p "$(dirname "$file")" 2>/dev/null || true
    if [ -f "$file" ]; then
        [ "${USB_WATCH_CONF_ENSURE_BUSY:-0}" = "1" ] && return 0
        USB_WATCH_CONF_ENSURE_BUSY=1
        usb_watch_conf_migrate_missing_keys
        usb_watch_conf_sanitize_runtime_pollution
        USB_WATCH_CONF_ENSURE_BUSY=0
        return 0
    fi
    _enabled_default="$(usb_watch_conf_enabled_default)"
    cat >"$file" <<EOF
# USB power watch (Keenetic-like: probe -> fail count -> xhci cycle)
ENABLED=${_enabled_default}
TEST_URL=https://ya.ru/
TEST_URL_ALT=https://github.com/
PROBE_IFACE=auto
POWER_CYCLE=auto
INTERVAL_MIN=3
PROBE_INTERVAL_SEC=20
FAIL_MAX=3
CYCLE_MAX=3
OFF_SEC=8
ON_SEC=5
SETTLE_SEC=90
LED_STATUS=1
PARTIAL_CYCLE_SEC=5
PARTIAL_FAULT_SEC=2
TUNNEL_PROBE_ENABLED=1
TUNNEL_PROBE_SETTLE_SEC=15
TUNNEL_ICMP_FAIL_MAX=3
TUNNEL_BOUNCE_MAX=3
PROTON_GUEST_RENEW=expiry
PROTON_GUEST_RENEW_SKEW_SEC=600
PROTON_GUEST_RENEW_COOLDOWN_SEC=1800
PROTON_GUEST_RENEW_DEFAULTS_REV=1
EOF
}

usb_watch_normalize_loaded_config() {
    USB_WATCH_ENABLED="$(printf '%s' "${USB_WATCH_ENABLED:-}" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
    case "${USB_WATCH_ENABLED:-}" in 1) USB_WATCH_ENABLED=1 ;; *) USB_WATCH_ENABLED=0 ;; esac
    [ -n "${USB_WATCH_TEST_URL:-}" ] || USB_WATCH_TEST_URL='https://ya.ru/'
    [ -n "${USB_WATCH_TEST_URL_ALT:-}" ] || USB_WATCH_TEST_URL_ALT='https://github.com/'
    [ -n "${USB_WATCH_PROBE_IFACE_RAW:-}" ] || USB_WATCH_PROBE_IFACE_RAW='auto'
    [ -n "${USB_WATCH_PROBE_IFACE:-}" ] || USB_WATCH_PROBE_IFACE='auto'
    case "${USB_WATCH_INTERVAL_MIN:-}" in ''|*[!0-9]*) USB_WATCH_INTERVAL_MIN=3 ;; esac
    case "${USB_WATCH_PROBE_INTERVAL_SEC:-}" in ''|*[!0-9]*) USB_WATCH_PROBE_INTERVAL_SEC=20 ;; esac
    case "${USB_WATCH_FAIL_MAX:-}" in ''|*[!0-9]*) USB_WATCH_FAIL_MAX=3 ;; esac
    case "${USB_WATCH_CYCLE_MAX:-}" in ''|*[!0-9]*) USB_WATCH_CYCLE_MAX=3 ;; esac
    case "${USB_WATCH_OFF_SEC:-}" in ''|*[!0-9]*) USB_WATCH_OFF_SEC=8 ;; esac
    case "${USB_WATCH_ON_SEC:-}" in ''|*[!0-9]*) USB_WATCH_ON_SEC=5 ;; esac
    case "${USB_WATCH_SETTLE_SEC:-}" in ''|*[!0-9]*) USB_WATCH_SETTLE_SEC=90 ;; esac
    case "${USB_WATCH_LED_STATUS:-}" in 0) ;; *) USB_WATCH_LED_STATUS=1 ;; esac
    case "${USB_WATCH_PARTIAL_CYCLE_SEC:-}" in ''|*[!0-9]*) USB_WATCH_PARTIAL_CYCLE_SEC=5 ;; esac
    case "${USB_WATCH_PARTIAL_FAULT_SEC:-}" in ''|*[!0-9]*) USB_WATCH_PARTIAL_FAULT_SEC=2 ;; esac
    case "${USB_WATCH_TUNNEL_PROBE_ENABLED:-1}" in 0|n|N|no|NO|false|FALSE|off|OFF) USB_WATCH_TUNNEL_PROBE_ENABLED=0 ;; *) USB_WATCH_TUNNEL_PROBE_ENABLED=1 ;; esac
    case "${USB_WATCH_TUNNEL_PROBE_SETTLE_SEC:-15}" in ''|*[!0-9]*) USB_WATCH_TUNNEL_PROBE_SETTLE_SEC=15 ;; esac
    case "${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-3}" in ''|*[!0-9]*) USB_WATCH_TUNNEL_ICMP_FAIL_MAX=3 ;; esac
    [ "${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-0}" -ge 1 ] 2>/dev/null || USB_WATCH_TUNNEL_ICMP_FAIL_MAX=3
    case "${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}" in ''|*[!0-9]*) USB_WATCH_TUNNEL_BOUNCE_MAX=3 ;; esac
    [ "${USB_WATCH_TUNNEL_BOUNCE_MAX:-0}" -ge 1 ] 2>/dev/null || USB_WATCH_TUNNEL_BOUNCE_MAX=3
    _pgr="$(printf '%s' "${USB_WATCH_PROTON_GUEST_RENEW:-expiry}" | tr '[:upper:]' '[:lower:]' | tr -d '\r')"
    [ -n "$_pgr" ] || _pgr=expiry
    case "$_pgr" in
        expiry|on-expiry|cert|ttl|expired) USB_WATCH_PROTON_GUEST_RENEW=expiry ;;
        tunnel-fail|fail|probe-fail|on-fail) USB_WATCH_PROTON_GUEST_RENEW=tunnel-fail ;;
        both|all|on) USB_WATCH_PROTON_GUEST_RENEW=both ;;
        off) USB_WATCH_PROTON_GUEST_RENEW=off ;;
        *) USB_WATCH_PROTON_GUEST_RENEW=expiry ;;
    esac
    case "${USB_WATCH_PROTON_GUEST_RENEW_SKEW_SEC:-600}" in ''|*[!0-9]*) USB_WATCH_PROTON_GUEST_RENEW_SKEW_SEC=600 ;; esac
    case "${USB_WATCH_PROTON_GUEST_RENEW_COOLDOWN_SEC:-1800}" in ''|*[!0-9]*) USB_WATCH_PROTON_GUEST_RENEW_COOLDOWN_SEC=1800 ;; esac
    USB_WATCH_POWER_CYCLE="$(printf '%s' "${USB_WATCH_POWER_CYCLE:-auto}" | tr '[:upper:]' '[:lower:]' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
    case "$USB_WATCH_POWER_CYCLE" in
        on|off|auto) ;;
        *) USB_WATCH_POWER_CYCLE=auto ;;
    esac
}

usb_watch_load_config() {
    usb_watch_conf_ensure
    _f="$(usb_watch_conf_path)"
    USB_WATCH_ENABLED="$(usb_watch_conf_get "$_f" ENABLED 0)"
    USB_WATCH_TEST_URL="$(usb_watch_conf_get "$_f" TEST_URL https://ya.ru/)"
    USB_WATCH_TEST_URL_ALT="$(usb_watch_conf_get "$_f" TEST_URL_ALT https://github.com/)"
    USB_WATCH_PROBE_IFACE_RAW="$(usb_watch_conf_get "$_f" PROBE_IFACE auto)"
    USB_WATCH_PROBE_IFACE="$(usb_watch_detect_probe_iface "$USB_WATCH_PROBE_IFACE_RAW")"
    USB_WATCH_POWER_CYCLE="$(usb_watch_conf_get "$_f" POWER_CYCLE auto)"
    USB_WATCH_INTERVAL_MIN="$(usb_watch_conf_get "$_f" INTERVAL_MIN 3)"
    USB_WATCH_PROBE_INTERVAL_SEC="$(usb_watch_conf_get "$_f" PROBE_INTERVAL_SEC 20)"
    USB_WATCH_FAIL_MAX="$(usb_watch_conf_get "$_f" FAIL_MAX 3)"
    USB_WATCH_CYCLE_MAX="$(usb_watch_conf_get "$_f" CYCLE_MAX 3)"
    USB_WATCH_OFF_SEC="$(usb_watch_conf_get "$_f" OFF_SEC 8)"
    USB_WATCH_ON_SEC="$(usb_watch_conf_get "$_f" ON_SEC 5)"
    USB_WATCH_SETTLE_SEC="$(usb_watch_conf_get "$_f" SETTLE_SEC 90)"
    USB_WATCH_LED_STATUS="$(usb_watch_conf_get "$_f" LED_STATUS 1)"
    USB_WATCH_PARTIAL_CYCLE_SEC="$(usb_watch_conf_get "$_f" PARTIAL_CYCLE_SEC 5)"
    USB_WATCH_PARTIAL_FAULT_SEC="$(usb_watch_conf_get "$_f" PARTIAL_FAULT_SEC 2)"
    USB_WATCH_TUNNEL_PROBE_ENABLED="$(usb_watch_conf_get "$_f" TUNNEL_PROBE_ENABLED 1)"
    USB_WATCH_TUNNEL_PROBE_SETTLE_SEC="$(usb_watch_conf_get "$_f" TUNNEL_PROBE_SETTLE_SEC 15)"
    USB_WATCH_TUNNEL_ICMP_FAIL_MAX="$(usb_watch_conf_get "$_f" TUNNEL_ICMP_FAIL_MAX 3)"
    USB_WATCH_TUNNEL_BOUNCE_MAX="$(usb_watch_conf_get "$_f" TUNNEL_BOUNCE_MAX 3)"
    USB_WATCH_PROTON_GUEST_RENEW="$(usb_watch_conf_get "$_f" PROTON_GUEST_RENEW expiry)"
    USB_WATCH_PROTON_GUEST_RENEW_SKEW_SEC="$(usb_watch_conf_get "$_f" PROTON_GUEST_RENEW_SKEW_SEC 600)"
    USB_WATCH_PROTON_GUEST_RENEW_COOLDOWN_SEC="$(usb_watch_conf_get "$_f" PROTON_GUEST_RENEW_COOLDOWN_SEC 1800)"
    usb_watch_normalize_loaded_config
}

# Меню и subshell probe: load_config с fallback и дефолты (совместимость со старым conf).
usb_watch_menu_ensure_vars() {
    usb_watch_load_config 2>/dev/null || true
    : "${USB_WATCH_ENABLED:=0}"
    : "${USB_WATCH_TEST_URL:=https://ya.ru/}"
    : "${USB_WATCH_TEST_URL_ALT:=https://github.com/}"
    : "${USB_WATCH_PROBE_IFACE_RAW:=auto}"
    : "${USB_WATCH_PROBE_IFACE:=auto}"
    : "${USB_WATCH_POWER_CYCLE:=auto}"
    : "${USB_WATCH_INTERVAL_MIN:=3}"
    : "${USB_WATCH_PROBE_INTERVAL_SEC:=20}"
    : "${USB_WATCH_FAIL_MAX:=3}"
    : "${USB_WATCH_CYCLE_MAX:=3}"
    : "${USB_WATCH_OFF_SEC:=8}"
    : "${USB_WATCH_ON_SEC:=5}"
    : "${USB_WATCH_SETTLE_SEC:=90}"
    : "${USB_WATCH_LED_STATUS:=1}"
    : "${USB_WATCH_PARTIAL_CYCLE_SEC:=5}"
    : "${USB_WATCH_PARTIAL_FAULT_SEC:=2}"
    : "${USB_WATCH_TUNNEL_PROBE_ENABLED:=1}"
    : "${USB_WATCH_TUNNEL_PROBE_SETTLE_SEC:=15}"
    : "${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:=3}"
    : "${USB_WATCH_TUNNEL_BOUNCE_MAX:=3}"
    : "${USB_WATCH_PROTON_GUEST_RENEW:=expiry}"
    : "${USB_WATCH_PROTON_GUEST_RENEW_SKEW_SEC:=600}"
    : "${USB_WATCH_PROTON_GUEST_RENEW_COOLDOWN_SEC:=1800}"
    USB_WATCH_PROBE_IFACE="$(usb_watch_detect_probe_iface "${USB_WATCH_PROBE_IFACE_RAW:-$USB_WATCH_PROBE_IFACE}")"
}

usb_watch_state_get() {
    key="$1"
    default="${2:-0}"
    file="$(usb_watch_state_path)"
    [ -f "$file" ] || {
        printf '%s' "$default"
        return 0
    }
    usb_watch_conf_get "$file" "$key" "$default"
}

usb_watch_state_set() {
    key="$1"
    value="$2"
    usb_watch_conf_kv_set "$(usb_watch_state_path)" "$key" "$value"
}

usb_watch_log_line() {
    msg="$1"
    ts="$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)"
    line="[$ts] $msg"
    _log_max="${USB_WATCH_LOG_MAX_LINES:-${LOG_RING_MAX_LINES:-100}}"
    printf '%s\n' "$line"
    if command -v log_ring_append >/dev/null 2>&1; then
        log_ring_append "$(usb_watch_run_log_path)" "$line" "$_log_max"
    else
        printf '%s\n' "$line" >>"$(usb_watch_run_log_path)" 2>/dev/null || true
    fi
    if command -v logger >/dev/null 2>&1; then
        logger -t usb-power-watch "$msg"
    fi
}

usb_watch_interval_valid() {
    val="$1"
    case "$val" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$val" -ge 1 ] 2>/dev/null && [ "$val" -le 60 ] 2>/dev/null
}

usb_watch_probe_interval_valid() {
    val="$1"
    max="$2"
    case "$val" in
        ''|*[!0-9]*) return 1 ;;
    esac
    case "$max" in
        ''|*[!0-9]*) max=1800 ;;
    esac
    [ "$val" -ge 3 ] 2>/dev/null && [ "$val" -le "$max" ] 2>/dev/null
}

usb_watch_normalize_probe_interval() {
    case "$USB_WATCH_INTERVAL_MIN" in
        ''|*[!0-9]*) USB_WATCH_INTERVAL_MIN=3 ;;
    esac
    case "$USB_WATCH_PROBE_INTERVAL_SEC" in
        ''|*[!0-9]*) USB_WATCH_PROBE_INTERVAL_SEC=20 ;;
    esac
    _max=$((USB_WATCH_INTERVAL_MIN * 60))
    [ "$_max" -lt 3 ] && _max=3
    if [ "$USB_WATCH_PROBE_INTERVAL_SEC" -lt 3 ] 2>/dev/null; then
        USB_WATCH_PROBE_INTERVAL_SEC=3
    fi
    if [ "$USB_WATCH_PROBE_INTERVAL_SEC" -gt "$_max" ] 2>/dev/null; then
        USB_WATCH_PROBE_INTERVAL_SEC="$_max"
    fi
}

usb_watch_session_period_sec() {
    case "$USB_WATCH_INTERVAL_MIN" in
        ''|*[!0-9]*) printf '180\n'; return 0 ;;
    esac
    printf '%s\n' $((USB_WATCH_INTERVAL_MIN * 60))
}

usb_watch_cron_schedule_for_interval() {
    interval="$1"
    case "$interval" in
        ''|*[!0-9]*) return 1 ;;
    esac
    if [ "$interval" -ge 60 ] 2>/dev/null; then
        printf '%s\n' '0 * * * *'
        return 0
    fi
    printf '%s\n' "*/${interval} * * * *"
}

usb_watch_toolbox_root_dir() {
    if [ -n "${USB_WATCH_ROOT_DIR:-}" ]; then
        printf '%s\n' "$USB_WATCH_ROOT_DIR"
        return 0
    fi
    if [ -n "${XFREE_TOOLBOX_ROOT:-}" ]; then
        printf '%s\n' "$XFREE_TOOLBOX_ROOT"
        return 0
    fi
    return 1
}

usb_watch_deps_load() {
    [ "${USB_WATCH_DEPS_LOADED:-0}" = "1" ] && return 0
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    if [ -n "$_root" ] && [ -f "$_root/lib/cmd-timeout.sh" ]; then
        # shellcheck disable=SC1091
        . "$_root/lib/cmd-timeout.sh"
    fi
    USB_WATCH_DEPS_LOADED=1
}

# OpenWrt: читать /etc/crontabs/root (crontab -l на части сборок ломается).
usb_watch_crontab_read() {
    if [ -r /etc/crontabs/root ]; then
        cat /etc/crontabs/root
        return 0
    fi
    usb_watch_deps_load
    cmd_timeout 5 crontab -l 2>/dev/null || true
}

usb_watch_crontab_has_watch_job() {
    _ct="$(usb_watch_crontab_read)"
    printf '%s\n' "$_ct" | grep -qF "$USB_WATCH_CRON_MARKER" || \
        printf '%s\n' "$_ct" | grep -qF "$CONNECTIVITY_WATCH_CRON_MARKER" || \
        printf '%s\n' "$_ct" | grep -qF 'usb-power-watch-run.sh' || \
        printf '%s\n' "$_ct" | grep -qF 'connectivity-watch-run.sh'
}

usb_watch_crontab_filter_to_file() {
    _dest="$1"
    : >"$_dest"
    usb_watch_crontab_read | grep -vF "$USB_WATCH_CRON_MARKER" | \
        grep -vF "$CONNECTIVITY_WATCH_CRON_MARKER" | \
        grep -vF 'usb-power-watch-run.sh' | \
        grep -vF 'connectivity-watch-run.sh' >>"$_dest" || true
}

usb_watch_crontab_apply_file() {
    _src="$1"
    [ -f "$_src" ] || return 1
    if [ -d /etc/crontabs ] 2>/dev/null; then
        mkdir -p /etc/crontabs 2>/dev/null || true
        cp "$_src" /etc/crontabs/root
        /etc/init.d/cron enabled 2>/dev/null && /etc/init.d/cron restart >/dev/null 2>&1 || true
        return 0
    fi
    crontab "$_src"
}

# Снять только строки watch (без ENABLED=0 и без сброса LED — для апгрейда toolbox).
usb_watch_crontab_suspend_watch() {
    _tmp="$(mktemp 2>/dev/null || echo /tmp/usb-watch-suspend.$$)"
    usb_watch_crontab_filter_to_file "$_tmp"
    usb_watch_crontab_apply_file "$_tmp" || {
        rm -f "$_tmp"
        return 1
    }
    rm -f "$_tmp"
    return 0
}

# Вернуть строку cron после апгрейда (без LED UCI / recovery — только crontab).
usb_watch_crontab_restore_watch_job() {
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _run="$_root/system/hardware/usb-power-watch-run.sh"
    [ -f "$_run" ] || return 1

    usb_watch_load_config 2>/dev/null || true
    case "${USB_WATCH_INTERVAL_MIN:-3}" in
        ''|*[!0-9]*) USB_WATCH_INTERVAL_MIN=3 ;;
    esac
    _body="$(usb_watch_cron_schedule_for_interval "$USB_WATCH_INTERVAL_MIN")" || return 1

    _log="$(usb_watch_run_log_path)"
    mkdir -p "$(dirname "$_log")" 2>/dev/null || true

    _tmp="$(mktemp 2>/dev/null || echo /tmp/usb-watch-restore.$$)"
    usb_watch_crontab_filter_to_file "$_tmp"
    {
        cat "$_tmp"
        printf '%s\n' "$USB_WATCH_CRON_MARKER"
        printf '%s /bin/sh %s >>%s 2>&1\n' "$_body" "$_run" "$_log"
    } >"${_tmp}.new"
    if ! usb_watch_crontab_apply_file "${_tmp}.new"; then
        rm -f "$_tmp" "${_tmp}.new"
        return 1
    fi
    rm -f "$_tmp" "${_tmp}.new"
    return 0
}

usb_watch_conf_migrate_only() {
    usb_watch_conf_ensure
}

usb_watch_cron_installed() {
    usb_watch_crontab_has_watch_job
}

usb_watch_target_to_host() {
    target="$1"
    [ -n "$target" ] || return 1
    case "$target" in
        http://*|https://*)
            _h="${target#*://}"
            _h="${_h%%/*}"
            _h="${_h%%:*}"
            [ -n "$_h" ] || return 1
            printf '%s\n' "$_h"
            ;;
        *)
            printf '%s\n' "${target%%/*}"
            ;;
    esac
}

usb_watch_alt_enabled() {
    _alt="${USB_WATCH_TEST_URL_ALT:-}"
    [ -n "$_alt" ] || return 1
    case "$_alt" in
        -|none|off|0) return 1 ;;
    esac
    # Alt probe (PARTIAL) is only relevant when the current uplink is a USB/LTE modem.
    # When the uplink is not a USB modem, disable alt to avoid transient PARTIAL
    # and keep "full internet" semantics aligned with LTE monitoring.
    usb_watch_probe_l2_is_usb_modem || return 1
    return 0
}

usb_watch_ping_supports_ipv4() {
    ping -4 -c 1 -W 1 127.0.0.1 >/dev/null 2>&1
}

usb_watch_ping_host() {
    host="$1"
    dev="${2:-}"
    _ping_args="-c 1 -W 8"
    if usb_watch_ping_supports_ipv4; then
        _ping_args="-4 $_ping_args"
    fi
    if [ -n "$dev" ] && usb_watch_net_dev_exists "$dev"; then
        # shellcheck disable=SC2086
        ping $_ping_args -I "$dev" "$host" >/dev/null 2>&1
        return $?
    fi
    # shellcheck disable=SC2086
    ping $_ping_args "$host" >/dev/null 2>&1
}

usb_watch_probe_iface_l2() {
    iface="${USB_WATCH_PROBE_IFACE:-auto}"
    case "$iface" in
        ''|auto) printf '\n'; return 0 ;;
        eth*|wwan*|usb*|ppp*) printf '%s\n' "$iface"; return 0 ;;
    esac
    _l3="$(usb_watch_ubus_iface_l3_device "$iface" 2>/dev/null || true)"
    if [ -n "$_l3" ]; then
        printf '%s\n' "$_l3"
        return 0
    fi
    if command -v uci >/dev/null 2>&1; then
        _proto="$(uci -q get "network.${iface}.proto" 2>/dev/null || true)"
        case "$_proto" in
            pppoe|ppp|pptp|l2tp|pppoa)
                if usb_watch_net_dev_exists "pppoe-${iface}"; then
                    printf 'pppoe-%s\n' "$iface"
                    return 0
                fi
                ;;
        esac
        _dev="$(uci -q get "network.${iface}.device" 2>/dev/null || true)"
        [ -n "$_dev" ] || _dev="$(uci -q get "network.${iface}.ifname" 2>/dev/null || true)"
        if [ -n "$_dev" ] && usb_watch_net_dev_exists "$_dev"; then
            printf '%s\n' "$_dev"
            return 0
        fi
    fi
    if usb_watch_net_dev_exists "$iface"; then
        printf '%s\n' "$iface"
        return 0
    fi
    printf '\n'
}

usb_watch_probe_iface_label() {
    _raw="${USB_WATCH_PROBE_IFACE_RAW:-${USB_WATCH_PROBE_IFACE:-auto}}"
    _uci="${USB_WATCH_PROBE_IFACE:-lte}"
    _l2="$(usb_watch_probe_iface_l2)"
    case "$_raw" in
        auto|'')
            if [ -n "$_l2" ] && [ "$_l2" != "$_uci" ]; then
                printf 'auto → %s → dev %s (ping -I)\n' "$_uci" "$_l2"
            elif [ -n "$_l2" ]; then
                printf 'auto → %s (ping -I %s)\n' "$_uci" "$_l2"
            else
                printf 'auto → %s (ping без -I)\n' "$_uci"
            fi
            ;;
        *)
            if [ -n "$_l2" ] && [ "$_l2" != "$_uci" ]; then
                printf '%s → dev %s (ping -I)\n' "$_uci" "$_l2"
            elif [ -n "$_l2" ]; then
                printf '%s (ping -I %s)\n' "$_uci" "$_l2"
            else
                printf '%s (ping без -I)\n' "$_uci"
            fi
            ;;
    esac
}

usb_watch_probe_host() {
    host="$1"
    [ -n "$host" ] || return 1
    _dev="$(usb_watch_probe_iface_l2)"
    if command -v ping >/dev/null 2>&1; then
        usb_watch_ping_host "$host" "$_dev"
        return $?
    fi
    return 1
}

# Базовый uplink OK (TEST_URL → ping hostname). Для common_wait_network_after_restart /
# prepare — тот же алгоритм и домены, что у мониторинга uplink (без soft ping на IP).
usb_watch_uplink_base_ready() {
    usb_watch_menu_ensure_vars
    usb_watch_probe_target "${USB_WATCH_TEST_URL:-https://ya.ru/}"
}

usb_watch_probe_target() {
    target="$1"
    [ -n "$target" ] || return 1
    _host="$(usb_watch_target_to_host "$target" 2>/dev/null || true)"
    [ -n "$_host" ] || return 1
    case "$target" in
        http://*|https://*)
            usb_watch_probe_host "$_host"
            return $?
            ;;
    esac
    usb_watch_probe_host "$_host"
}

# eval: 0=full, 2=partial, 1=base fail
usb_watch_eval_capture() {
    _var="$1"
    _base_ok=0
    _alt_ok=0
    _alt_enabled=0

    if usb_watch_alt_enabled; then
        _alt_enabled=1
    fi

    if usb_watch_probe_target "$USB_WATCH_TEST_URL"; then
        _base_ok=1
    fi

    if [ "$_base_ok" -eq 1 ] && [ "$_alt_enabled" -eq 1 ]; then
        if usb_watch_probe_target "$USB_WATCH_TEST_URL_ALT"; then
            _alt_ok=1
        fi
        _ev=2
        [ "$_alt_ok" -eq 1 ] && _ev=0
    elif [ "$_base_ok" -eq 1 ]; then
        _ev=0
    else
        _ev=1
    fi

    usb_watch_state_set LAST_PROBE_BASE "$_base_ok"
    usb_watch_state_set LAST_PROBE_ALT_ENABLED "$_alt_enabled"
    usb_watch_state_set LAST_PROBE_ALT "$_alt_ok"

    eval "$_var=\$_ev"
}

usb_watch_exhaust_retry_sec() {
    level="$1"
    case "$level" in
        ''|*[!0-9]*) level=1 ;;
    esac
    [ "$level" -lt 1 ] && level=1
    _n=1
    _min=5
    for _m in $USB_WATCH_EXHAUST_RETRY_MINUTES; do
        [ "$_n" -eq "$level" ] && {
            printf '%s\n' $((_m * 60))
            return 0
        }
        _min="$_m"
        _n=$((_n + 1))
    done
    printf '%s\n' $((_min * 60))
}

usb_watch_maybe_reset_after_reboot() {
    _uptime="$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 9999)"
    [ "$_uptime" -le 180 ] 2>/dev/null || return 0
    _done="$(usb_watch_state_get BOOT_RESET_DONE 0)"
    [ "$_done" = "1" ] && return 0
    usb_watch_state_set CYCLE_COUNT 0
    usb_watch_state_set CYCLE_EXHAUSTED 0
    usb_watch_state_set EXHAUST_AUTO_LEVEL 0
    usb_watch_state_set EXHAUST_LOCK_EPOCH 0
    usb_watch_state_set FAIL_COUNT 0
    usb_watch_state_set LAST_PROBE_EVAL 0
    usb_watch_state_set CONNECTIVITY_DEGRADED 0
    usb_watch_state_set BOOT_RESET_DONE 1
    if command -v usb_watch_tunnel_clear_runtime_state >/dev/null 2>&1; then
        usb_watch_tunnel_clear_runtime_state
    fi
    usb_watch_log_line "reboot: сброс CYCLE_LOCK / EXHAUST_AUTO_LEVEL / FAIL_COUNT (uptime=${_uptime}s)"
}

usb_watch_in_settle_period() {
    _epoch="$(usb_watch_state_get LAST_CYCLE_EPOCH 0)"
    case "$_epoch" in
        ''|0|*[!0-9]*) return 1 ;;
    esac
    _now="$(date +%s 2>/dev/null || echo 0)"
    [ "$_now" -gt 0 ] || return 1
    _left=$((_epoch + USB_WATCH_SETTLE_SEC - _now))
    [ "$_left" -gt 0 ] 2>/dev/null
}

usb_watch_settle_remaining_sec() {
    _epoch="$(usb_watch_state_get LAST_CYCLE_EPOCH 0)"
    _now="$(date +%s 2>/dev/null || echo 0)"
    case "$_epoch" in
        ''|0|*[!0-9]*) printf '0\n'; return 0 ;;
    esac
    _left=$((_epoch + USB_WATCH_SETTLE_SEC - _now))
    [ "$_left" -lt 0 ] && _left=0
    printf '%s\n' "$_left"
}

usb_watch_clear_settle_cooldown() {
    usb_watch_state_set LAST_CYCLE_EPOCH 0
}

usb_watch_mark_settle_cooldown() {
    _now="$(date +%s 2>/dev/null || echo 0)"
    usb_watch_state_set LAST_CYCLE_EPOCH "$_now"
}

usb_watch_try_auto_reset_exhaust_lock() {
    _exhausted="$(usb_watch_state_get CYCLE_EXHAUSTED 0)"
    [ "$_exhausted" = "1" ] || return 1
    _lock_epoch="$(usb_watch_state_get EXHAUST_LOCK_EPOCH 0)"
    case "$_lock_epoch" in
        ''|0|*[!0-9]*) return 1 ;;
    esac
    _level="$(usb_watch_state_get EXHAUST_AUTO_LEVEL 1)"
    _need="$(usb_watch_exhaust_retry_sec "$_level")"
    _now="$(date +%s 2>/dev/null || echo 0)"
    [ "$_now" -ge $((_lock_epoch + _need)) ] 2>/dev/null || return 1
    usb_watch_reset_cycle_lock
    _next=$((_level + 1))
    [ "$_next" -gt 6 ] && _next=6
    usb_watch_state_set EXHAUST_AUTO_LEVEL "$_next"
    usb_watch_log_line "CYCLE_LOCK: auto-reset (уровень $_level → retry через $(($_need / 60)) мин истёк)"
    return 0
}

usb_watch_on_probe_success() {
    usb_watch_state_set FAIL_COUNT 0
    _exhausted="$(usb_watch_state_get CYCLE_EXHAUSTED 0)"
    if [ "$_exhausted" = "1" ] || [ "$(usb_watch_state_get EXHAUST_AUTO_LEVEL 0)" != "0" ]; then
        usb_watch_state_set CYCLE_COUNT 0
        usb_watch_state_set CYCLE_EXHAUSTED 0
        usb_watch_state_set EXHAUST_LOCK_EPOCH 0
        usb_watch_state_set EXHAUST_AUTO_LEVEL 0
        usb_watch_log_line "probe OK: сброс CYCLE_LOCK / EXHAUST_AUTO_LEVEL"
    fi
}

usb_watch_recovery_lib_load() {
    [ "${USB_WATCH_RECOVERY_LIB_LOADED:-0}" = "1" ] && return 0
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _lib="$_root/iface-routing/lib/recovery-scheduler.sh"
    [ -f "$_lib" ] || return 1
    RECOVERY_SCHEDULER_ROOT_DIR="$_root"
    RECOVERY_SCHEDULER_COMMON_SH="$_root/lib/common.sh"
    if [ -z "${PROFILE_DIR:-}" ]; then
        usb_watch_ensure_profile_dir "$_root" || true
    fi
    RECOVERY_SCHEDULER_INTERFACES_DIR="${INTERFACES_DIR:-${PROFILE_DIR:+${PROFILE_DIR}/iface-routing/interfaces}}"
    # shellcheck disable=SC1090
    . "$_lib"
    USB_WATCH_RECOVERY_LIB_LOADED=1
    return 0
}

usb_watch_recovery_enable_if_needed() {
    usb_watch_recovery_lib_load || return 1
    recovery_scheduler_conf_ensure
    _cf="$(recovery_scheduler_conf_path)"
    _en="$(recovery_scheduler_conf_get "$_cf" ENABLED 0)"
    case "$_en" in
        1|y|Y|yes|YES|true|TRUE|on|ON) return 0 ;;
    esac
    if usb_watch_cron_installed && [ "${USB_WATCH_ENABLED:-0}" = "1" ]; then
        recovery_scheduler_conf_kv_set "$_cf" ENABLED 1
        usb_watch_log_line "recovery: ENABLED=1 (usb-watch cron)"
        return 0
    fi
    return 1
}

# Установить cron + ENABLED=1 (без whiptail). Идемпотентно, если cron уже есть.
usb_watch_cron_install_quiet() {
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _cron="$_root/system/hardware/usb-power-watch-cron.sh"
    [ -f "$_cron" ] || return 1
    export USB_WATCH_ROOT_DIR="$_root"
    sh "$_cron" install
}

# После apply-template / install-from-cloud --apply-template: probe WAN+VPN, recovery, tunnel probe.
usb_watch_enable_connectivity_watch_default() {
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1

    usb_watch_conf_migrate_only
    usb_watch_conf_set "$(usb_watch_conf_path)" ENABLED 1
    usb_watch_load_config

    if usb_watch_cron_installed; then
        usb_watch_recovery_enable_if_needed 2>/dev/null || true
        usb_watch_log_line "connectivity-watch: cron уже установлен, ENABLED=1"
        return 0
    fi

    if usb_watch_cron_install_quiet; then
        usb_watch_log_line "connectivity-watch: cron установлен после apply-template"
        return 0
    fi

    usb_watch_log_line "connectivity-watch: не удалось установить cron (Мониторинг канала → Включить периодическую проверку канала)"
    return 1
}

# Transition alone is not an outage. recover_stack waits for CONNECTIVITY_DEGRADED,
# set only when FAIL_COUNT reaches FAIL_MAX.
usb_watch_connectivity_recovery_wanted() {
    return 1
}

usb_watch_should_schedule_connectivity_recovery() {
    _new="$2"
    _degraded="$3"
    [ "$_new" = "0" ] || return 1
    [ "$_degraded" = "1" ]
}

# USB power-cycle only for LTE/USB uplink probes — not for wan/eth watchdog.
usb_watch_probe_l2_is_usb_modem() {
    _dev="$(usb_watch_probe_iface_l2)"
    [ -n "$_dev" ] || return 1
    case "$_dev" in
        ppp*|tap*|tun*|br-*|lan|wan) return 1 ;;
    esac
    usb_watch_net_dev_is_usb "$_dev"
}

usb_watch_usb_power_lib_load() {
    [ "${USB_WATCH_USB_POWER_LIB_LOADED:-0}" = "1" ] && return 0
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _lib="$_root/system/hardware/usb-power-lib.sh"
    [ -f "$_lib" ] || return 1
    # shellcheck disable=SC1090
    . "$_lib"
    USB_WATCH_USB_POWER_LIB_LOADED=1
    return 0
}

usb_watch_usb_power_backend_available() {
    usb_watch_usb_power_lib_load || return 1
    USB_POWER_METHOD=""
    USB_POWER_LAST_ERROR=""
    usb_power_pick_method auto
}

usb_watch_known_router_lib_load() {
    [ "${USB_WATCH_KNOWN_ROUTER_LIB_LOADED:-0}" = "1" ] && return 0
    _root="$(usb_watch_toolbox_root_dir 2>/dev/null || true)"
    [ -n "$_root" ] || return 1
    _lib="$_root/system/hardware/lib-known-router.sh"
    [ -f "$_lib" ] || return 1
    HARDWARE_KNOWN_ROUTER_DIR="$_root/system/hardware"
    # shellcheck disable=SC1090
    . "$_lib"
    USB_WATCH_KNOWN_ROUTER_LIB_LOADED=1
    return 0
}

usb_watch_platform_usb_power_supported() {
    usb_watch_known_router_lib_load || return 0
    hardware_known_router_usb_power_supported "$@"
}

# POWER_CYCLE: auto = USB-бэкенд + probe L2 на USB; on = только бэкенд; off = никогда.
usb_watch_power_cycle_eligible() {
    case "${USB_WATCH_POWER_CYCLE:-auto}" in
        off|0|n|no|false) return 1 ;;
        on|1|y|yes|true)
            usb_watch_platform_usb_power_supported || return 1
            usb_watch_usb_power_backend_available
            ;;
        *)
            usb_watch_platform_usb_power_supported || return 1
            usb_watch_usb_power_backend_available || return 1
            usb_watch_probe_l2_is_usb_modem
            ;;
    esac
}

usb_watch_power_cycle_eligible_label() {
    case "${USB_WATCH_POWER_CYCLE:-auto}" in
        off|0|n|no|false) printf 'off\n'; return 0 ;;
        on|1|y|yes|true)
            if ! usb_watch_platform_usb_power_supported; then
                printf 'on (платформа без USB power-cycle)\n'
                return 0
            fi
            if usb_watch_usb_power_backend_available; then
                printf 'on (бэкенд %s)\n' "${USB_POWER_METHOD:-?}"
            else
                printf 'on (бэкенд недоступен)\n'
            fi
            return 0
            ;;
    esac
    if ! usb_watch_platform_usb_power_supported; then
        printf 'auto (платформа без USB power-cycle)\n'
        return 0
    fi
    if ! usb_watch_probe_l2_is_usb_modem; then
        printf 'auto (probe L2 не USB-модем — cycle выкл.)\n'
        return 0
    fi
    if usb_watch_usb_power_backend_available; then
        _l2="$(usb_watch_probe_iface_l2)"
        printf 'auto (USB L2 %s, бэкенд %s)\n' "$_l2" "${USB_POWER_METHOD:-?}"
    else
        printf 'auto (нет USB power-бэкенда)\n'
    fi
}

# Back-compat alias (tests / внешние вызовы).
usb_watch_probe_iface_power_cycle_eligible() {
    usb_watch_power_cycle_eligible
}

usb_watch_mark_connectivity_degraded() {
    usb_watch_state_set CONNECTIVITY_DEGRADED 1
}

usb_watch_schedule_iface_recovery_event() {
    _event="$1"
    if ! usb_watch_recovery_enable_if_needed; then
        usb_watch_log_line "recovery: skip $_event (iface-recovery недоступен или выключен)"
        return 0
    fi
    if ! command -v schedule_recovery_event >/dev/null 2>&1; then
        usb_watch_log_line "recovery: skip $_event (schedule_recovery_event missing)"
        return 0
    fi
    schedule_recovery_event "$_event"
    if command -v recovery_scheduler_tick_background >/dev/null 2>&1; then
        recovery_scheduler_tick_background 0 || true
    fi
    usb_watch_log_line "recovery: scheduled $_event (digest-bg)"
    return 0
}

usb_watch_eval_label() {
    case "$1" in
        0) printf 'full\n' ;;
        1) printf 'fail\n' ;;
        2) printf 'partial\n' ;;
        *) printf 'unknown\n' ;;
    esac
}

usb_watch_on_probe_eval_transition() {
    _new="$1"
    case "$_new" in
        0|1|2) ;;
        *) return 0 ;;
    esac
    _prev="$(usb_watch_state_get LAST_PROBE_EVAL "")"
    case "$_prev" in
        0|1|2) ;;
        *) _prev="" ;;
    esac
    if [ "$_prev" != "$_new" ]; then
        _prev_lbl="$(usb_watch_eval_label "$_prev")"
        _new_lbl="$(usb_watch_eval_label "$_new")"
        if [ -n "$_prev" ]; then
            usb_watch_log_line "connectivity: eval $_prev ($_prev_lbl) → $_new ($_new_lbl) iface=$(usb_watch_probe_iface_label)"
        else
            usb_watch_log_line "connectivity: eval init → $_new ($_new_lbl) iface=$(usb_watch_probe_iface_label)"
        fi
    fi
    _degraded="$(usb_watch_state_get CONNECTIVITY_DEGRADED 0)"
    case "$_new" in
        0)
            if usb_watch_should_schedule_connectivity_recovery "$_prev" "$_new" "$_degraded"; then
                usb_watch_schedule_iface_recovery_event connectivity_up
            fi
            usb_watch_state_set CONNECTIVITY_DEGRADED 0
            ;;
    esac
    usb_watch_state_set LAST_PROBE_EVAL "$_new"
}

usb_watch_cycle_locked() {
    [ "$(usb_watch_state_get CYCLE_EXHAUSTED 0)" = "1" ]
}

usb_watch_do_power_cycle() {
    _cycle_sh="${USB_WATCH_LED_CYCLE_SH:-}"
    [ -n "$_cycle_sh" ] && [ -f "$_cycle_sh" ] || {
        usb_watch_log_line "cycle: USB_WATCH_LED_CYCLE_SH не задан"
        return 1
    }
    usb_watch_log_line "cycle: start OFF=${USB_WATCH_OFF_SEC}s ON=${USB_WATCH_ON_SEC}s"
    if sh "$_cycle_sh" "$USB_WATCH_OFF_SEC" "$USB_WATCH_ON_SEC" 1; then
        usb_watch_mark_settle_cooldown
        usb_watch_state_set FAIL_COUNT 0
        _cc="$(usb_watch_state_get CYCLE_COUNT 0)"
        case "$_cc" in
            ''|*[!0-9]*) _cc=0 ;;
        esac
        _cc=$((_cc + 1))
        usb_watch_state_set CYCLE_COUNT "$_cc"
        usb_watch_log_line "cycle: OK (${_cc}/${USB_WATCH_CYCLE_MAX})"
        if [ "$_cc" -ge "$USB_WATCH_CYCLE_MAX" ] 2>/dev/null; then
            _now="$(date +%s 2>/dev/null || echo 0)"
            usb_watch_state_set CYCLE_EXHAUSTED 1
            usb_watch_state_set EXHAUST_LOCK_EPOCH "$_now"
            _lvl="$(usb_watch_state_get EXHAUST_AUTO_LEVEL 0)"
            [ "$_lvl" = "0" ] && usb_watch_state_set EXHAUST_AUTO_LEVEL 1
            usb_watch_log_line "cycle: CYCLE_LOCK ${_cc}/${USB_WATCH_CYCLE_MAX} (probe продолжается)"
        fi
        usb_watch_schedule_iface_recovery_event modem_recovered
        return 0
    fi
    usb_watch_log_line "cycle: FAILED"
    return 1
}

# Общий мониторинг uplink: после FAIL_MAX подряд FAIL базы — подтверждённый outage.
# Реакции (не отдельные «режимы»): сброс VPN bounce; USB power-cycle если eligible.
# Ставит USB_WATCH_OUTAGE_CYCLE_STARTED=1, если стартовал USB cycle.
usb_watch_on_confirmed_uplink_outage() {
    USB_WATCH_OUTAGE_CYCLE_STARTED=0
    usb_watch_log_line "uplink: outage confirmed (FAIL_MAX=${USB_WATCH_FAIL_MAX})"
    # Один FAIL базы — не «интернет пропал». Защёлка только здесь (FAIL_MAX),
    # чтобы следующий full probe поставил connectivity_up.
    usb_watch_mark_connectivity_degraded
    if command -v usb_watch_tunnel_clear_runtime_state >/dev/null 2>&1; then
        usb_watch_tunnel_clear_runtime_state
        usb_watch_log_line "uplink→vpn: bounce counters reset"
    fi
    if usb_watch_cycle_locked; then
        usb_watch_log_line "uplink→usb: CYCLE_LOCK — power-cycle пропущен"
        return 0
    fi
    if usb_watch_power_cycle_eligible; then
        if usb_watch_do_power_cycle; then
            USB_WATCH_OUTAGE_CYCLE_STARTED=1
        fi
        return 0
    fi
    usb_watch_log_line "uplink→usb: power-cycle пропущен (POWER_CYCLE=${USB_WATCH_POWER_CYCLE:-auto}; $(usb_watch_power_cycle_eligible_label | tr '\n' ' '))"
    return 0
}

usb_watch_handle_probe_tick() {
    usb_watch_eval_capture _ev
    _cycle_started=0
    case "$_ev" in
        0|2)
            usb_watch_on_probe_success
            ;;
        *)
            _fc="$(usb_watch_state_get FAIL_COUNT 0)"
            case "$_fc" in
                ''|*[!0-9]*) _fc=0 ;;
            esac
            _fc=$((_fc + 1))
            usb_watch_state_set FAIL_COUNT "$_fc"
            usb_watch_log_line "uplink probe: base FAIL (${_fc}/${USB_WATCH_FAIL_MAX})"
            if [ "$_fc" -ge "$USB_WATCH_FAIL_MAX" ] 2>/dev/null; then
                usb_watch_state_set FAIL_COUNT 0
                usb_watch_on_confirmed_uplink_outage
                _cycle_started="${USB_WATCH_OUTAGE_CYCLE_STARTED:-0}"
            fi
            ;;
    esac

    usb_watch_on_probe_eval_transition "$_ev"

    if [ "$_ev" = "0" ]; then
        if command -v usb_watch_tunnel_probe_tick >/dev/null 2>&1; then
            usb_watch_tunnel_probe_tick || true
        fi
    fi

    if [ "$_cycle_started" = "1" ]; then
        return 1
    fi

    if command -v internet_status_led_apply_from_eval >/dev/null 2>&1; then
        internet_status_led_apply_from_eval "$_ev" 2>/dev/null || true
    fi
    return 0
}

usb_watch_wait_internet_after_cycle() {
    _deadline="$(($(date +%s 2>/dev/null || echo 0) + USB_WATCH_SETTLE_SEC))"
    while :; do
        _now="$(date +%s 2>/dev/null || echo 0)"
        [ "$_now" -ge "$_deadline" ] 2>/dev/null && break
        usb_watch_eval_capture _ev
        case "$_ev" in
            0|2)
                usb_watch_clear_settle_cooldown
                usb_watch_on_probe_success
                usb_watch_on_probe_eval_transition "$_ev"
                if command -v internet_status_led_apply_from_eval >/dev/null 2>&1; then
                    internet_status_led_modem_blink_teardown 2>/dev/null || true
                    internet_status_led_apply_from_eval "$_ev" 2>/dev/null || true
                fi
                usb_watch_log_line "settle: интернет OK (eval=$_ev)"
                return 0
                ;;
        esac
        sleep 3 2>/dev/null || sleep 1
    done
    if command -v internet_status_led_apply_from_eval >/dev/null 2>&1; then
        internet_status_led_modem_blink_teardown 2>/dev/null || true
        usb_watch_eval_capture _ev
        usb_watch_on_probe_eval_transition "$_ev"
        internet_status_led_apply_from_eval "$_ev" 2>/dev/null || true
    fi
    usb_watch_log_line "settle: таймаут ${USB_WATCH_SETTLE_SEC}s"
    return 1
}

usb_watch_reset_cycle_lock() {
    usb_watch_state_set CYCLE_COUNT 0
    usb_watch_state_set CYCLE_EXHAUSTED 0
    usb_watch_state_set EXHAUST_LOCK_EPOCH 0
    usb_watch_state_set FAIL_COUNT 0
    usb_watch_state_set EXHAUST_AUTO_LEVEL 0
    if command -v usb_watch_tunnel_clear_runtime_state >/dev/null 2>&1; then
        usb_watch_tunnel_clear_runtime_state
    fi
}

usb_watch_conf_runtime_keys_present() {
    _f="$(usb_watch_conf_path)"
    [ -f "$_f" ] || return 1
    _found=""
    for _k in $USB_WATCH_RUNTIME_CONF_KEYS; do
        [ -n "$_k" ] || continue
        grep -qE "^[[:space:]]*${_k}[[:space:]]*=" "$_f" 2>/dev/null || continue
        _found="${_found}${_found:+, }${_k}"
    done
    [ -n "$_found" ] && printf '%s\n' "$_found"
}

usb_watch_reset_monitor_storage() {
    _f="$(usb_watch_conf_path)"
    _removed=0
    if [ -f "$_f" ]; then
        for _k in $USB_WATCH_RUNTIME_CONF_KEYS; do
            [ -n "$_k" ] || continue
            grep -qE "^[[:space:]]*${_k}[[:space:]]*=" "$_f" 2>/dev/null || continue
            usb_watch_conf_delete_key "$_f" "$_k"
            _removed=$((_removed + 1))
        done
    fi
    _sf="$(usb_watch_state_path)"
    mkdir -p "$(dirname "$_sf")" 2>/dev/null || true
    printf '# usb-power-watch runtime state\n' >"$_sf"
    printf '%s\n' "$_removed"
}

# Краткая сводка для меню (установка cron, подтверждения) — как ключевые строки статуса.
usb_watch_uplink_operational_summary() {
    usb_watch_load_config 2>/dev/null || true
    usb_watch_normalize_probe_interval 2>/dev/null || true
    printf 'PROBE_IFACE : %s\n' "$(usb_watch_probe_iface_label)"
    printf 'POWER_CYCLE : %s\n' "$(usb_watch_power_cycle_eligible_label | tr -d '\n' | sed 's/[[:space:]]*$//')"
    if usb_watch_power_cycle_eligible 2>/dev/null; then
        printf '  → при FAIL≥%s: USB power-cycle модема\n' "${USB_WATCH_FAIL_MAX:-3}"
    else
        printf '  → USB cycle нет: probe + LED + recovery VPN\n'
    fi
    printf 'PROBE       : %s с, сессия cron %s мин\n' \
        "${USB_WATCH_PROBE_INTERVAL_SEC:-20}" "${USB_WATCH_INTERVAL_MIN:-3}"
    if usb_watch_alt_enabled; then
        printf 'URL         : %s + доп. %s (LED partial)\n' \
            "${USB_WATCH_TEST_URL:-?}" "${USB_WATCH_TEST_URL_ALT:-?}"
    else
        printf 'URL         : %s\n' "${USB_WATCH_TEST_URL:-?}"
    fi
    if usb_watch_recovery_lib_load 2>/dev/null; then
        recovery_scheduler_conf_ensure 2>/dev/null || true
        _re="$(recovery_scheduler_conf_get "$(recovery_scheduler_conf_path)" ENABLED 0)"
        case "$_re" in
            1|y|Y|yes|YES|true|TRUE|on|ON)
                printf 'RECOVERY    : iface-recovery-scheduler вкл.\n'
                ;;
            *)
                printf 'RECOVERY    : вкл. при установке cron (VPN stack)\n'
                ;;
        esac
    else
        printf 'RECOVERY    : iface-recovery недоступен\n'
    fi
}

usb_watch_format_status() {
    usb_watch_load_config
    usb_watch_normalize_probe_interval
    printf '=== Connectivity watch (usb-power-watch) ===\n'
    printf '  ENABLED      : %s\n' "$USB_WATCH_ENABLED"
    if usb_watch_cron_installed && [ "$USB_WATCH_ENABLED" != "1" ]; then
        printf '  NOTE         : cron установлен, но ENABLED=0 — probe не выполняется (настройки → вкл. мониторинг)\n'
    fi
    printf '  CRON         : '
    if usb_watch_cron_installed; then
        printf 'установлен (INTERVAL_MIN=%s)\n' "$USB_WATCH_INTERVAL_MIN"
    else
        printf 'НЕ установлен (Мониторинг канала → Включить периодическую проверку канала)\n'
    fi
    printf '  PROBE_IFACE  : %s\n' "$(usb_watch_probe_iface_label)"
    printf '  POWER_CYCLE  : %s\n' "$(usb_watch_power_cycle_eligible_label | sed 's/[[:space:]]*$//')"
    printf '  TEST_URL     : %s (cycle / fail)\n' "$USB_WATCH_TEST_URL"
    if usb_watch_alt_enabled; then
        printf '  TEST_URL_ALT : %s (LED partial)\n' "$USB_WATCH_TEST_URL_ALT"
    else
        printf '  TEST_URL_ALT : выкл.\n'
    fi
    printf '  PROBE_EVERY  : %s с (сессия %s мин)\n' "$USB_WATCH_PROBE_INTERVAL_SEC" "$USB_WATCH_INTERVAL_MIN"
    printf '  FAIL_MAX     : %s (порог outage uplink → USB + recovery)\n' "$USB_WATCH_FAIL_MAX"
    printf '  CYCLE_MAX    : %s\n' "$USB_WATCH_CYCLE_MAX"
    printf '  OFF/ON       : %s / %s с\n' "$USB_WATCH_OFF_SEC" "$USB_WATCH_ON_SEC"
    printf '  SETTLE_SEC   : %s\n' "$USB_WATCH_SETTLE_SEC"
    printf '  TUNNEL_FAIL  : %s (ICMP подряд до VPN restart)\n' "${USB_WATCH_TUNNEL_ICMP_FAIL_MAX:-3}"
    printf '  TUNNEL_BOUNCE: %s (макс. VPN restart, потом только лог)\n' "${USB_WATCH_TUNNEL_BOUNCE_MAX:-3}"
    printf '  LED_STATUS   : %s\n' "$USB_WATCH_LED_STATUS"
    printf '  FAIL_COUNT   : %s / %s\n' "$(usb_watch_state_get FAIL_COUNT 0)" "$USB_WATCH_FAIL_MAX"
    printf '  CYCLE_COUNT  : %s / %s\n' "$(usb_watch_state_get CYCLE_COUNT 0)" "$USB_WATCH_CYCLE_MAX"
    printf '  CYCLE_LOCK   : %s\n' "$(usb_watch_state_get CYCLE_EXHAUSTED 0)"
    printf '  EXHAUST_LVL  : %s\n' "$(usb_watch_state_get EXHAUST_AUTO_LEVEL 0)"
    _tick="$(usb_watch_state_get LAST_TICK unknown)"
    printf '  LAST_TICK    : %s\n' "$_tick"
    if usb_watch_in_settle_period; then
        printf '  COOLDOWN     : ~%s с (SETTLE после cycle)\n' "$(usb_watch_settle_remaining_sec)"
    else
        printf '  COOLDOWN     : нет\n'
    fi
    if [ -f "${TMPDIR:-/tmp}/xfree-usb-watch-run.lock" ]; then
        printf '  RUN_LOCK     : активен\n'
    else
        printf '  RUN_LOCK     : нет\n'
    fi
    if command -v internet_status_led_uci_quarantine_status_line >/dev/null 2>&1; then
        internet_status_led_uci_quarantine_status_line
    fi
    _polluted="$(usb_watch_conf_runtime_keys_present 2>/dev/null || true)"
    if [ -n "$_polluted" ]; then
        printf '  CONF_WARN    : в conf лишние ключи состояния: %s\n' "$_polluted"
    fi
    if command -v usb_watch_tunnel_format_status_lines >/dev/null 2>&1; then
        usb_watch_tunnel_format_status_lines
    fi
    printf '  conf         : %s\n' "$(usb_watch_conf_path)"
    printf '  state        : %s\n' "$(usb_watch_state_path)"
    printf '  log          : %s\n' "$(usb_watch_run_log_path)"
}
