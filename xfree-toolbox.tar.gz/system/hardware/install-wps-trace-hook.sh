#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck source=system/hardware/lib-sync-button.sh
. "$SCRIPT_DIR/lib-sync-button.sh"

WPS_TRACE_LOG="${WPS_TRACE_LOG:-/tmp/xfree-wps-trace.log}"
WPS_PRESS_STAMP="${WPS_PRESS_STAMP:-/tmp/xfree-wps-press.epoch}"
WPS_SYNC_HOLD_SEC="${WPS_SYNC_HOLD_SEC:-3}"
HOOK_DIR="/etc/hotplug.d/button"
HOOK_FILE="$HOOK_DIR/89-xfree-wps-trace"

install_wps_trace_hook() {
  hold_sec="$WPS_SYNC_HOLD_SEC"
  trace_log="$WPS_TRACE_LOG"
  press_stamp="$WPS_PRESS_STAMP"
  sync_buttons="$(hardware_sync_button_resolve_list)"

  mkdir -p "$HOOK_DIR"
  {
    cat <<EOF
#!/bin/sh
# xfree-toolbox debug: trace profile-sync button (before 90-xfree-wps-sync-apply)
# buttons: ${sync_buttons}
TRACE_LOG="$trace_log"
PRESS_STAMP="$press_stamp"
HOLD_SEC=$hold_sec

EOF
    hardware_sync_button_hotplug_guard_lines
    cat <<EOF

EOF
    hardware_sync_button_wps_hold_snippet
    cat <<'TRACE_EOF'

_ts() { date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date; }

_trace() {
  printf '[%s] pid=%s %s\n' "$(_ts)" "$$" "$*" >>"$TRACE_LOG"
  logger -t xfree-wps-trace "$*" 2>/dev/null || true
}

case "${ACTION:-}" in
  pressed)
    if _wps_press_latch "$PRESS_STAMP"; then
      _trace "pressed BUTTON=${BUTTON:-?} SEEN=${SEEN:-?} stamp=$(cat "$PRESS_STAMP" 2>/dev/null || echo '?') START"
    else
      _trace "pressed BUTTON=${BUTTON:-?} SEEN=${SEEN:-?} stamp=$(cat "$PRESS_STAMP" 2>/dev/null || echo '?') KEEP (<3s debounce)"
    fi
    ;;
  released)
    _seen_raw="${SEEN:-?}"
    _seen_n="${SEEN:-0}"
    case "$_seen_n" in
      ''|*[!0-9]*) _seen_n="$(_wps_seen_num "${SEEN:-0}")" ;;
    esac
    case "$_seen_n" in ''|*[!0-9]*) _seen_n=0 ;; esac
    if [ "$_seen_n" -eq 0 ] 2>/dev/null; then
      _trace "released BUTTON=${BUTTON:-?} SEEN_raw=$_seen_raw seen_n=${_seen_n} BOUNCE (stamp kept)"
      exit 0
    fi
    if [ "$_seen_n" -ge "$HOLD_SEC" ] 2>/dev/null; then
      _verdict="WOULD_TRIGGER_90"
    else
      _verdict="SKIP seen_n=${_seen_n} need>=${HOLD_SEC}"
    fi
    _trace "released BUTTON=${BUTTON:-?} SEEN_raw=$_seen_raw seen_n=${_seen_n} -> $_verdict"
    ;;
  *)
    _trace "event BUTTON=${BUTTON:-?} ACTION=${ACTION:-?} SEEN=${SEEN:-?}"
    ;;
esac
exit 0
TRACE_EOF
  } >"$HOOK_FILE"
  chmod +x "$HOOK_FILE" 2>/dev/null || true
  : >>"$trace_log" 2>/dev/null || true
  printf '[%s] trace hook installed: %s buttons=%s (hold>=%ss, latch+debounce)\n' \
    "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date)" "$HOOK_FILE" "$sync_buttons" "$hold_sec" >>"$trace_log"
  echo "Installed: $HOOK_FILE (buttons: $sync_buttons)"
  echo "Log: $trace_log"
}

remove_wps_trace_hook() {
  rm -f "$HOOK_FILE" 2>/dev/null || true
  echo "Removed: $HOOK_FILE"
}

case "${1:-}" in
  --install) install_wps_trace_hook ;;
  --remove) remove_wps_trace_hook ;;
  *)
    echo "Usage: $0 --install | --remove" >&2
    exit 1
    ;;
esac
