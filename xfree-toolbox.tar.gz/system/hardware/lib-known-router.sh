#!/bin/sh
# shellcheck shell=sh
# Lookup known-router profile by board_name (exact or family: strip -ubootmod/-stock).
# No set -eu: this file is sourced from other libraries (e.g. lib/led/led-lib.sh).

_hardware_known_router_dir() {
  if [ -n "${HARDWARE_KNOWN_ROUTER_DIR:-}" ]; then
    printf '%s\n' "$HARDWARE_KNOWN_ROUTER_DIR"
    return 0
  fi
  if [ -n "${SCRIPT_DIR:-}" ] && [ -f "$SCRIPT_DIR/known-routers.tsv" ]; then
    printf '%s\n' "$SCRIPT_DIR"
    return 0
  fi
  return 1
}

if [ -z "${HARDWARE_KNOWN_ROUTER_LIB_BOARD_LOADED:-}" ]; then
  _kr_dir="$(_hardware_known_router_dir 2>/dev/null || true)"
  if [ -n "$_kr_dir" ]; then
    # shellcheck source=system/hardware/lib-board.sh
    . "$_kr_dir/lib-board.sh"
    HARDWARE_KNOWN_ROUTER_LIB_BOARD_LOADED=1
  fi
fi

hardware_known_router_db() {
  _dir="$(_hardware_known_router_dir)" || return 1
  printf '%s\n' "$_dir/known-routers.tsv"
}

# Normalize board_name for family match (same hardware, different flash layout).
hardware_board_family_key() {
  _b="$1"
  case "$_b" in
    cudy_wr3000s-v1*) _b="cudy,wr3000s-v1${_b#cudy_wr3000s-v1}" ;;
    cudy_wr3000e-v1*) _b="cudy,wr3000e-v1${_b#cudy_wr3000e-v1}" ;;
    cudy_wr3000p-v1*) _b="cudy,wr3000p-v1${_b#cudy_wr3000p-v1}" ;;
  esac
  case "$_b" in
    *-ubootmod) _b="${_b%-ubootmod}" ;;
    *-stock) _b="${_b%-stock}" ;;
  esac
  printf '%s\n' "$_b"
}

_hardware_known_router_row_nth() {
  _row="$1"
  _idx="$2"
  printf '%s\n' "$_row" | awk -F'\t' -v n="$_idx" '{
    if (n >= 1 && n <= NF) print $n
  }'
}

# Prints one TSV row (sync_button … watch_usb_power) or nothing.
hardware_known_router_lookup_row() {
  _board="${1:-$(hardware_board_name)}"
  _db="${2:-$(hardware_known_router_db)}"
  [ -f "$_db" ] || return 1
  [ -n "$_board" ] || return 1
  [ "$_board" != "unknown" ] || return 1

  awk -F'\t' -v board="$_board" '
    function norm(b,    t) {
      t = b
      if (t ~ /^cudy_wr3000s-v1/) sub(/^cudy_wr3000s-v1/, "cudy,wr3000s-v1", t)
      if (t ~ /^cudy_wr3000e-v1/) sub(/^cudy_wr3000e-v1/, "cudy,wr3000e-v1", t)
      if (t ~ /^cudy_wr3000p-v1/) sub(/^cudy_wr3000p-v1/, "cudy,wr3000p-v1", t)
      sub(/-ubootmod$/, "", t)
      sub(/-stock$/, "", t)
      return t
    }
    function row_match(key, b) {
      return key == b || norm(key) == norm(b)
    }
    function col(n) {
      return (n <= NF && $n != "" ? $n : "")
    }
    $1 !~ /^#/ && $1 != "" && row_match($1, board) {
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n", col(2), col(3), col(4), col(5), col(6), col(7), col(8)
      exit 0
    }
  ' "$_db"
}

hardware_known_router_row_field() {
  _n="$1"
  shift
  _row="$(hardware_known_router_lookup_row "$@" 2>/dev/null || true)"
  [ -n "$_row" ] || return 1
  case "$_n" in
    2|sync) _hardware_known_router_row_nth "$_row" 1 ;;
    3|bg_a) _hardware_known_router_row_nth "$_row" 2 ;;
    4|bg_b) _hardware_known_router_row_nth "$_row" 3 ;;
    5|watch_wan) _hardware_known_router_row_nth "$_row" 4 ;;
    6|watch_fault) _hardware_known_router_row_nth "$_row" 5 ;;
    7|watch_cycle) _hardware_known_router_row_nth "$_row" 6 ;;
    8|watch_usb_power) _hardware_known_router_row_nth "$_row" 7 ;;
    *) return 1 ;;
  esac
}

hardware_known_router_sync_button() {
  hardware_known_router_row_field 2 "$@" 2>/dev/null || return 1
}

hardware_known_router_bg_led_candidates_a() {
  hardware_known_router_row_field 3 "$@" 2>/dev/null || return 1
}

hardware_known_router_bg_led_candidates_b() {
  hardware_known_router_row_field 4 "$@" 2>/dev/null || return 1
}

hardware_known_router_watch_wan_online_candidates() {
  hardware_known_router_row_field 5 "$@" 2>/dev/null || return 1
}

hardware_known_router_watch_fault_led() {
  hardware_known_router_row_field 6 "$@" 2>/dev/null || return 1
}

hardware_known_router_watch_cycle_wan_led() {
  hardware_known_router_row_field 7 "$@" 2>/dev/null || return 1
}

hardware_known_router_watch_usb_power_field() {
  hardware_known_router_row_field 8 "$@" 2>/dev/null || true
}

# 0 = USB power-cycle разрешён на уровне платформы; 1 = нет (WR3000S и т.п.).
hardware_known_router_usb_power_supported() {
  _v="$(hardware_known_router_watch_usb_power_field "$@" 2>/dev/null || true)"
  [ -n "$_v" ] || return 0
  case "$_v" in
    no|0|n|N|false|off|'-'|--) return 1 ;;
  esac
  return 0
}
