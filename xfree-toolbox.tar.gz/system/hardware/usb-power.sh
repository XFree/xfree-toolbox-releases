#!/bin/sh
# shellcheck shell=sh
# Обёртка: перезагрузка USB по питанию (вызывать из меню и скриптов модема).
#
# Usage:
#   usb-power.sh status
#   usb-power.sh cycle [off_sec] [on_sec] [--method auto|xhci-mtk|gpio|uhubctl]
#   usb-power.sh test [off_sec] [on_sec]
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib-board.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/lib/cmd-timeout.sh"
. "$SCRIPT_DIR/usb-power-lib.sh"

CMD="${1:-status}"
shift || true

OFF_SEC=8
ON_SEC=5
METHOD="auto"

while [ $# -gt 0 ]; do
    case "$1" in
        --method)
            shift
            METHOD="${1:-auto}"
            shift || true
            ;;
        -h|--help)
            cat <<'EOF'
Usage:
  usb-power.sh status
  usb-power.sh cycle [off_sec] [on_sec] [--method auto|xhci-mtk|gpio|uhubctl]
  usb-power.sh test [off_sec] [on_sec]

  cycle — production: отключить/включить USB (автовыбор бэкенда).
  test  — диагностика: before/after lsusb, regulator, dmesg tail.

Defaults: off=8s on=5s (как в ТЗ Cudy xhci-mtk).
EOF
            exit 0
            ;;
        *)
            if [ -z "${_arg1_set:-}" ]; then
                OFF_SEC="$1"
                _arg1_set=1
            elif [ -z "${_arg2_set:-}" ]; then
                ON_SEC="$1"
                _arg2_set=1
            else
                die "Unknown argument: $1"
            fi
            shift
            ;;
    esac
done

case "$CMD" in
    status)
        usb_power_print_status
        exit 0
        ;;
    cycle)
        info "USB power-cycle: method=$METHOD off=${OFF_SEC}s on=${ON_SEC}s ($(hardware_board_summary_line))"
        if usb_power_cycle "$OFF_SEC" "$ON_SEC" "$METHOD"; then
            success "USB power-cycle завершён (метод: ${USB_POWER_METHOD:-?})"
            exit 0
        fi
        die "${USB_POWER_LAST_ERROR:-USB power-cycle failed}"
        ;;
    test)
        info "=== USB power-cycle TEST ($(hardware_board_summary_line)) ==="
        info "Паузы: off=${OFF_SEC}s on=${ON_SEC}s"
        printf '\n'
        usb_power_print_status
        printf '\n=== regulator (usb) ===\n'
        usb_power_regulator_snippet
        printf '\n=== Before ===\n'
        if command -v lsusb >/dev/null 2>&1; then
            lsusb 2>/dev/null || true
        else
            warn "lsusb недоступен (apk add usbutils)"
        fi
        printf '\n'
        if ! usb_power_pick_method auto; then
            die "${USB_POWER_LAST_ERROR:-нет бэкенда для теста}"
        fi
        info "Метод теста: $USB_POWER_METHOD"
        info "Unbind / power-off..."
        if ! usb_power_cycle "$OFF_SEC" "$ON_SEC" "$USB_POWER_METHOD"; then
            die "${USB_POWER_LAST_ERROR:-cycle failed}"
        fi
        printf '\n=== After ===\n'
        if command -v lsusb >/dev/null 2>&1; then
            lsusb 2>/dev/null || true
        fi
        if command -v dmesg >/dev/null 2>&1; then
            printf '\n=== dmesg (tail, usb) ===\n'
            dmesg 2>/dev/null | tail -n 40 | grep -iE 'usb|xhci|disconnect|new device' || \
                dmesg 2>/dev/null | tail -n 20 || true
        fi
        printf '\n'
        success "Тест завершён. Проверьте: модем исчез и появился в lsusb; при возможности — снятие 5V на порту."
        info "Сохраните вывод и при необходимости: logread | grep usb-power"
        exit 0
        ;;
    *)
        die "Unknown command: $CMD (use status|cycle|test)"
        ;;
esac
