#!/bin/sh
# shellcheck shell=sh
# LED по probe (TEST_URL + TEST_URL_ALT на PROBE_IFACE).
# Перезаписывает UCI/trigger (в т.ч. «online по трафику») — ручное sysfs, пока ENABLED+LED_STATUS.
#
# Профили (system/hardware/known-routers.tsv: watch_wan_online, watch_fault, watch_cycle_wan):
#   dual (WBR3000UAX): wan-online + fault; partial — fault N с ↔ wan-online M с; fail — fault on.
#   wan-online-only (WR3000S): только wan-online; partial — off N с ↔ on M с; fail — off.

INTERNET_STATUS_LED_WAN_ONLINE="blue:wan-online"
INTERNET_STATUS_LED_FAULT="red:fault"
INTERNET_STATUS_LED_BLUE_WAN="blue:wan"
INTERNET_STATUS_LED_WAN_ONLY="0"
INTERNET_STATUS_LED_PROFILE_LOADED="0"
INTERNET_STATUS_LED_PARTIAL_PID="${TMPDIR:-/tmp}/xfree-internet-partial-led.pid"
INTERNET_STATUS_LED_MODE_KEY="NET_LED_MODE"
INTERNET_STATUS_LED_UCI_BACKUP_NAME="usb-power-watch-uci-led.backup"
INTERNET_STATUS_LED_UCI_QUARANTINE_SYSFS=""
INTERNET_STATUS_LED_UCI_BACKUP_OPTS="trigger sysfs name default dev mode delayon delayoff blink signal port inverted gpio pin interval"

internet_status_led_profile_quarantine_sysfs_rebuild() {
    INTERNET_STATUS_LED_UCI_QUARANTINE_SYSFS="
${INTERNET_STATUS_LED_WAN_ONLINE}
${INTERNET_STATUS_LED_FAULT}
${INTERNET_STATUS_LED_BLUE_WAN}
"
    _seen=""
    _list=""
    for _led in $INTERNET_STATUS_LED_UCI_QUARANTINE_SYSFS; do
        [ -n "$_led" ] || continue
        case "$_seen" in
            *" $_led "*) continue ;;
        esac
        _seen="$_seen $_led "
        _list="$_list $_led"
    done
    INTERNET_STATUS_LED_UCI_QUARANTINE_SYSFS="$_list"
}

internet_status_led_profile_load() {
    [ "${INTERNET_STATUS_LED_PROFILE_LOADED:-}" = "1" ] && return 0

    _wan_c="blue:wan-online white:wan-online"
    _fault_c="red:fault"
    _cycle_c="blue:wan"
    _root="${USB_WATCH_ROOT_DIR:-}"
    if [ -n "$_root" ] && [ -f "$_root/system/hardware/lib-known-router.sh" ]; then
        HARDWARE_KNOWN_ROUTER_DIR="$_root/system/hardware"
        # shellcheck source=system/hardware/lib-known-router.sh
        . "$_root/system/hardware/lib-known-router.sh"
        _row_wan="$(hardware_known_router_watch_wan_online_candidates 2>/dev/null || true)"
        _row_fault="$(hardware_known_router_watch_fault_led 2>/dev/null || true)"
        _row_cycle="$(hardware_known_router_watch_cycle_wan_led 2>/dev/null || true)"
        [ -n "$_row_wan" ] && [ "$_row_wan" != "-" ] && _wan_c="$_row_wan"
        [ -n "$_row_fault" ] && [ "$_row_fault" != "-" ] && _fault_c="$_row_fault"
        [ -n "$_row_cycle" ] && [ "$_row_cycle" != "-" ] && _cycle_c="$_row_cycle"
        if [ "$_row_fault" = "-" ]; then
            INTERNET_STATUS_LED_WAN_ONLY="1"
            INTERNET_STATUS_LED_FAULT=""
            INTERNET_STATUS_LED_BLUE_WAN=""
        fi
    fi

    if command -v hardware_led_pair_pick_existing >/dev/null 2>&1; then
        _picked="$(hardware_led_pair_pick_existing "$_wan_c" 2>/dev/null || true)"
        [ -n "$_picked" ] && INTERNET_STATUS_LED_WAN_ONLINE="$_picked"
        if [ "${INTERNET_STATUS_LED_WAN_ONLY:-0}" != "1" ]; then
            case "$_fault_c" in
                ''|-) INTERNET_STATUS_LED_WAN_ONLY="1"; INTERNET_STATUS_LED_FAULT="" ;;
                *)
                    if [ -d "/sys/class/leds/$_fault_c" ]; then
                        INTERNET_STATUS_LED_FAULT="$_fault_c"
                    else
                        INTERNET_STATUS_LED_WAN_ONLY="1"
                        INTERNET_STATUS_LED_FAULT=""
                    fi
                    ;;
            esac
            if [ -n "${INTERNET_STATUS_LED_FAULT:-}" ] && [ -d "/sys/class/leds/$_cycle_c" ]; then
                INTERNET_STATUS_LED_BLUE_WAN="$_cycle_c"
            else
                INTERNET_STATUS_LED_BLUE_WAN=""
            fi
        fi
    fi

    internet_status_led_profile_quarantine_sysfs_rebuild
    INTERNET_STATUS_LED_PROFILE_LOADED="1"
    return 0
}

internet_status_led_available() {
    internet_status_led_profile_load
    [ -d "/sys/class/leds/$INTERNET_STATUS_LED_WAN_ONLINE" ] || return 1
    if [ "${INTERNET_STATUS_LED_WAN_ONLY:-0}" = "1" ]; then
        return 0
    fi
    [ -n "${INTERNET_STATUS_LED_FAULT:-}" ] && \
        [ -d "/sys/class/leds/$INTERNET_STATUS_LED_FAULT" ]
}

internet_status_led_enabled() {
    case "${USB_WATCH_LED_STATUS:-1}" in
        0|n|N|no|NO|false|FALSE|off|OFF) return 1 ;;
    esac
    internet_status_led_available
}

internet_status_led_modem_cycle_active() {
    [ -f "${HARDWARE_LED_MODEM_BLINK_PID:-/tmp/xfree-modem-cycle-led.pid}" ] && \
        kill -0 "$(cat "${HARDWARE_LED_MODEM_BLINK_PID}" 2>/dev/null)" 2>/dev/null
}

internet_status_led_takeover() {
    internet_status_led_profile_load
    hardware_led_capture_state "$INTERNET_STATUS_LED_WAN_ONLINE" 2>/dev/null || true
    if [ -n "${INTERNET_STATUS_LED_FAULT:-}" ]; then
        hardware_led_capture_state "$INTERNET_STATUS_LED_FAULT" 2>/dev/null || true
    fi
}

internet_status_led_wan_online_force_on() {
    hardware_led_on "$INTERNET_STATUS_LED_WAN_ONLINE" 2>/dev/null || true
}

internet_status_led_wan_online_force_off() {
    _path="$(hardware_led_sysfs_path "$INTERNET_STATUS_LED_WAN_ONLINE")" || return 1
    echo none >"$_path/trigger" 2>/dev/null || true
    echo 0 >"$_path/brightness" 2>/dev/null || true
}

internet_status_led_fault_force_on() {
    [ -n "${INTERNET_STATUS_LED_FAULT:-}" ] || return 0
    _path="$(hardware_led_sysfs_path "$INTERNET_STATUS_LED_FAULT")" || return 1
    hardware_led_capture_state "$INTERNET_STATUS_LED_FAULT" 2>/dev/null || true
    echo none >"$_path/trigger" 2>/dev/null || true
    echo 1 >"$_path/brightness" 2>/dev/null || true
}

internet_status_led_fault_force_off() {
    [ -n "${INTERNET_STATUS_LED_FAULT:-}" ] || return 0
    _path="$(hardware_led_sysfs_path "$INTERNET_STATUS_LED_FAULT")" || return 1
    echo none >"$_path/trigger" 2>/dev/null || true
    echo 0 >"$_path/brightness" 2>/dev/null || true
}

# Только фоновый цикл PARTIAL; не трогает яркость fault (иначе при fail мигает каждый probe).
internet_status_led_partial_loop_stop() {
    if [ -f "$INTERNET_STATUS_LED_PARTIAL_PID" ]; then
        _pid="$(cat "$INTERNET_STATUS_LED_PARTIAL_PID" 2>/dev/null || true)"
        case "$_pid" in
            ''|*[!0-9]*) ;;
            *)
                kill "$_pid" 2>/dev/null || true
                wait "$_pid" 2>/dev/null || true
                ;;
        esac
        rm -f "$INTERNET_STATUS_LED_PARTIAL_PID" 2>/dev/null || true
    fi
}

internet_status_led_partial_stop() {
    internet_status_led_partial_loop_stop 2>/dev/null || true
    internet_status_led_fault_force_off 2>/dev/null || true
}

internet_status_led_partial_loop() {
    _cycle="${USB_WATCH_PARTIAL_CYCLE_SEC:-5}"
    _fault="${USB_WATCH_PARTIAL_FAULT_SEC:-2}"
    case "$_cycle" in ''|*[!0-9]*) _cycle=5 ;; esac
    case "$_fault" in ''|*[!0-9]*) _fault=2 ;; esac
    if [ "$_fault" -ge "$_cycle" ] 2>/dev/null; then
        _fault=$((_cycle - 1))
        [ "$_fault" -lt 1 ] && _fault=1
    fi
    _pause=$((_cycle - _fault))
    [ "$_pause" -lt 0 ] && _pause=0

    while [ "$(usb_watch_state_get "$INTERNET_STATUS_LED_MODE_KEY" "")" = "partial" ]; do
        if [ "${INTERNET_STATUS_LED_WAN_ONLY:-0}" = "1" ]; then
            internet_status_led_wan_online_force_off
            sleep "$_fault"
            internet_status_led_wan_online_force_on
            [ "$_pause" -gt 0 ] && sleep "$_pause"
        else
            internet_status_led_wan_online_force_off
            internet_status_led_fault_force_on
            sleep "$_fault"
            internet_status_led_fault_force_off
            internet_status_led_wan_online_force_on
            [ "$_pause" -gt 0 ] && sleep "$_pause"
        fi
    done
}

internet_status_led_partial_start() {
    internet_status_led_partial_stop 2>/dev/null || true
    usb_watch_state_set "$INTERNET_STATUS_LED_MODE_KEY" "partial"
    ( internet_status_led_partial_loop ) &
    printf '%s\n' "$!" >"$INTERNET_STATUS_LED_PARTIAL_PID"
}

internet_status_led_apply_full() {
    internet_status_led_partial_stop 2>/dev/null || true
    usb_watch_state_set "$INTERNET_STATUS_LED_MODE_KEY" "full"
    internet_status_led_fault_force_off 2>/dev/null || true
    internet_status_led_wan_online_force_on
}

internet_status_led_apply_fail() {
    internet_status_led_partial_loop_stop 2>/dev/null || true
    usb_watch_state_set "$INTERNET_STATUS_LED_MODE_KEY" "fail"
    internet_status_led_wan_online_force_off
    if [ "${INTERNET_STATUS_LED_WAN_ONLY:-0}" != "1" ]; then
        internet_status_led_fault_force_on
    fi
}

internet_status_led_apply_from_eval() {
    _ev="$1"
    internet_status_led_profile_load
    internet_status_led_enabled || return 0
    internet_status_led_modem_cycle_active && return 0

    internet_status_led_takeover
    internet_status_led_uci_netdev_hint 2>/dev/null || true

    case "$_ev" in
        0)
            internet_status_led_apply_full
            if [ "${INTERNET_STATUS_LED_WAN_ONLY:-0}" = "1" ]; then
                _alt_enabled="$(usb_watch_state_get LAST_PROBE_ALT_ENABLED 0)"
                if [ "$_alt_enabled" = "1" ]; then
                    usb_watch_log_line "LED: full (base ok, alt ok) → ${INTERNET_STATUS_LED_WAN_ONLINE} on [override UCI]"
                else
                    usb_watch_log_line "LED: full (base ok) → ${INTERNET_STATUS_LED_WAN_ONLINE} on [override UCI]"
                fi
            else
                _alt_enabled="$(usb_watch_state_get LAST_PROBE_ALT_ENABLED 0)"
                if [ "$_alt_enabled" = "1" ]; then
                    usb_watch_log_line "LED: full (base ok, alt ok) → ${INTERNET_STATUS_LED_WAN_ONLINE} on, ${INTERNET_STATUS_LED_FAULT} off [override UCI]"
                else
                    usb_watch_log_line "LED: full (base ok) → ${INTERNET_STATUS_LED_WAN_ONLINE} on, ${INTERNET_STATUS_LED_FAULT} off [override UCI]"
                fi
            fi
            ;;
        2)
            internet_status_led_partial_start
            if [ "${INTERNET_STATUS_LED_WAN_ONLY:-0}" = "1" ]; then
                usb_watch_log_line "LED: partial (база OK, alt FAIL) → ${INTERNET_STATUS_LED_WAN_ONLINE} off ${USB_WATCH_PARTIAL_FAULT_SEC:-2}s ↔ on, период ${USB_WATCH_PARTIAL_CYCLE_SEC:-5}s [override UCI]"
            else
                usb_watch_log_line "LED: partial (база OK, alt FAIL) → fault ${USB_WATCH_PARTIAL_FAULT_SEC:-2}s (только red) ↔ wan-online (только blue), период ${USB_WATCH_PARTIAL_CYCLE_SEC:-5}s [override UCI]"
            fi
            ;;
        *)
            internet_status_led_apply_fail
            if [ "${INTERNET_STATUS_LED_WAN_ONLY:-0}" = "1" ]; then
                usb_watch_log_line "LED: base FAIL → ${INTERNET_STATUS_LED_WAN_ONLINE} off [override UCI]"
            else
                usb_watch_log_line "LED: base FAIL → ${INTERNET_STATUS_LED_FAULT} on, ${INTERNET_STATUS_LED_WAN_ONLINE} off [override UCI]"
            fi
            ;;
    esac
    return 0
}

# Сброс ручного sysfs (run при ENABLED=0). UCI backup не трогаем — только «Снять cron».
internet_status_led_disable() {
    internet_status_led_profile_load
    internet_status_led_partial_stop 2>/dev/null || true
    usb_watch_state_set "$INTERNET_STATUS_LED_MODE_KEY" "" 2>/dev/null || true
    if [ -n "${INTERNET_STATUS_LED_FAULT:-}" ]; then
        hardware_led_release "$INTERNET_STATUS_LED_FAULT" 2>/dev/null || true
    fi
    hardware_led_release "$INTERNET_STATUS_LED_WAN_ONLINE" 2>/dev/null || true
    if [ -n "${INTERNET_STATUS_LED_BLUE_WAN:-}" ]; then
        hardware_led_release "$INTERNET_STATUS_LED_BLUE_WAN" 2>/dev/null || true
    fi
    if ! internet_status_led_uci_quarantine_active; then
        hardware_led_restore_uci 2>/dev/null || true
    fi
    return 0
}

# Полное восстановление LuCI (вызывать из usb-power-watch-cron.sh remove).
internet_status_led_disable_full() {
    internet_status_led_disable 2>/dev/null || true
    if internet_status_led_uci_quarantine_active; then
        internet_status_led_uci_quarantine_restore 2>/dev/null || return 1
        return 0
    fi
    hardware_led_restore_uci 2>/dev/null || return 1
}

internet_status_led_uci_backup_path() {
    _root="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
    mkdir -p "$_root/system" 2>/dev/null || true
    printf '%s/system/%s' "$_root" "$INTERNET_STATUS_LED_UCI_BACKUP_NAME"
}

internet_status_led_uci_quarantine_active() {
    [ -f "$(internet_status_led_uci_backup_path)" ]
}

# Все system.* секции led, привязанные к sysfs или name.
internet_status_led_uci_sections_for_sysfs() {
    _want="$1"
    [ -n "$_want" ] || return 0
    command -v uci >/dev/null 2>&1 || return 1
    for _s in $(uci -q show system 2>/dev/null | sed -n 's/^\(system\.[^=]*\)=led$/\1/p'); do
        _sf="$(uci -q get "${_s}.sysfs" 2>/dev/null)" || true
        _nm="$(uci -q get "${_s}.name" 2>/dev/null)" || true
        if [ "$_sf" = "$_want" ] || [ "$_nm" = "$_want" ]; then
            printf '%s\n' "$_s"
        fi
    done
}

internet_status_led_uci_collect_quarantine_sections() {
    internet_status_led_profile_load
    _seen=""
    for _led in $INTERNET_STATUS_LED_UCI_QUARANTINE_SYSFS; do
        [ -n "$_led" ] || continue
        for _s in $(internet_status_led_uci_sections_for_sysfs "$_led" 2>/dev/null); do
            case "$_seen" in
                *" $_s "*) continue ;;
            esac
            _seen="$_seen $_s "
            printf '%s\n' "$_s"
        done
    done
}

internet_status_led_uci_backup_section() {
    _section="$1"
    _file="$2"
    [ -n "$_section" ] && [ -n "$_file" ] || return 1
    {
        printf 'section=%s\n' "$_section"
        for _opt in $INTERNET_STATUS_LED_UCI_BACKUP_OPTS; do
            _val="$(uci -q get "${_section}.${_opt}" 2>/dev/null)" || continue
            printf 'option=%s\n' "$_opt"
            printf 'value=%s\n' "$_val"
        done
        printf -- '--\n'
    } >>"$_file"
}

internet_status_led_uci_apply_trigger_none() {
    _section="$1"
    [ -n "$_section" ] || return 1
    uci -q set "${_section}.trigger=none" 2>/dev/null || return 1
    for _opt in dev mode delayon delayoff blink signal; do
        uci -q delete "${_section}.${_opt}" 2>/dev/null || true
    done
    return 0
}

# Сброс /tmp/xfree-led-state/* — иначе release после cycle вернёт старый netdev.
internet_status_led_drop_sysfs_captures() {
    internet_status_led_profile_load
    _stdir="${HARDWARE_LED_STATE_DIR:-/tmp/xfree-led-state}"
    for _led in $INTERNET_STATUS_LED_UCI_QUARANTINE_SYSFS; do
        [ -n "$_led" ] || continue
        _slug="$(hardware_led_state_slug "$_led" 2>/dev/null)" || continue
        rm -rf "$_stdir/$_slug" 2>/dev/null || true
    done
}

# blue:wan только на время USB cycle; после — выкл., UCI quarantine не трогаем.
internet_status_led_blue_wan_park() {
    [ -n "${INTERNET_STATUS_LED_BLUE_WAN:-}" ] || return 0
    _path="$(hardware_led_sysfs_path "$INTERNET_STATUS_LED_BLUE_WAN")" || return 1
    echo none >"$_path/trigger" 2>/dev/null || true
    echo 0 >"$_path/brightness" 2>/dev/null || true
    return 0
}

# Конец мигания fault↔wan: не restore blue:wan из старого capture; fault — в apply_from_eval.
internet_status_led_modem_blink_teardown() {
    internet_status_led_profile_load
    if internet_status_led_uci_quarantine_active; then
        internet_status_led_blue_wan_park 2>/dev/null || true
        if [ -n "${INTERNET_STATUS_LED_BLUE_WAN:-}" ]; then
            _slug="$(hardware_led_state_slug "$INTERNET_STATUS_LED_BLUE_WAN" 2>/dev/null)" || true
            rm -rf "${HARDWARE_LED_STATE_DIR:-/tmp/xfree-led-state}/$_slug" 2>/dev/null || true
            if command -v usb_watch_log_line >/dev/null 2>&1; then
                usb_watch_log_line "LED: ${INTERNET_STATUS_LED_BLUE_WAN} park (после cycle-blink, UCI quarantine)"
            fi
        fi
        return 0
    fi
    if [ -n "${INTERNET_STATUS_LED_FAULT:-}" ]; then
        hardware_led_release "$INTERNET_STATUS_LED_FAULT" 2>/dev/null || true
    fi
    if [ -n "${INTERNET_STATUS_LED_BLUE_WAN:-}" ]; then
        hardware_led_release "$INTERNET_STATUS_LED_BLUE_WAN" 2>/dev/null || true
    fi
    return 0
}

internet_status_led_uci_led_service_reload() {
    if [ -x /etc/init.d/led ]; then
        /etc/init.d/led restart >/dev/null 2>&1 && return 0
        /etc/init.d/led stop >/dev/null 2>&1 || true
        sleep 1
        /etc/init.d/led start >/dev/null 2>&1 && return 0
    fi
    if [ -x /etc/init.d/system ]; then
        /etc/init.d/system reload >/dev/null 2>&1 && return 0
    fi
    return 1
}

# При install cron: сохранить UCI LED и выставить trigger=none (без netdev/timer).
internet_status_led_uci_quarantine_install() {
    internet_status_led_profile_load
    command -v uci >/dev/null 2>&1 || {
        echo "[!] LED UCI: uci недоступен — правила LuCI не изменены" >&2
        return 1
    }

    _backup="$(internet_status_led_uci_backup_path)"
    _sections="$(internet_status_led_uci_collect_quarantine_sections)"
    if [ -z "$_sections" ]; then
        echo "[*] LED UCI: нет секций led для watch-LED ($(printf '%s' "$INTERNET_STATUS_LED_UCI_QUARANTINE_SYSFS" | tr '\n' ' '))"
        return 0
    fi

    if [ ! -f "$_backup" ]; then
        : >"$_backup"
        printf '# xfree-toolbox usb-power-watch UCI LED backup\n' >>"$_backup"
        for _s in $_sections; do
            internet_status_led_uci_backup_section "$_s" "$_backup" || true
        done
    fi

    _changed=0
    for _s in $_sections; do
        _tr="$(uci -q get "${_s}.trigger" 2>/dev/null)" || _tr=""
        if internet_status_led_uci_apply_trigger_none "$_s"; then
            _changed=1
            _log_msg="LED UCI: ${_s} trigger ${_tr:-?} → none (cron watch)"
            if command -v usb_watch_log_line >/dev/null 2>&1; then
                usb_watch_log_line "$_log_msg"
            else
                echo "[+] $_log_msg"
            fi
        fi
    done

    if [ "$_changed" = "1" ]; then
        uci -q commit system 2>/dev/null || {
            echo "[-] LED UCI: commit system не удался" >&2
            return 1
        }
        internet_status_led_uci_led_service_reload || true
    fi

    for _led in $INTERNET_STATUS_LED_UCI_QUARANTINE_SYSFS; do
        [ -d "/sys/class/leds/$_led" ] || continue
        _path="/sys/class/leds/$_led"
        echo none >"$_path/trigger" 2>/dev/null || true
    done
    internet_status_led_drop_sysfs_captures 2>/dev/null || true
    return 0
}

internet_status_led_uci_quarantine_restore() {
    _backup="$(internet_status_led_uci_backup_path)"
    [ -f "$_backup" ] || return 0
    command -v uci >/dev/null 2>&1 || return 1

    _section=""
    _opt=""
    _changed=0
    while IFS= read -r _line || [ -n "$_line" ]; do
        case "$_line" in
            ''|'#'*) continue ;;
            section=*)
                _section="${_line#section=}"
                ;;
            option=*)
                _opt="${_line#option=}"
                ;;
            value=*)
                [ -n "$_section" ] && [ -n "$_opt" ] || continue
                _val="${_line#value=}"
                if uci -q set "${_section}.${_opt}=${_val}" 2>/dev/null; then
                    _changed=1
                fi
                _opt=""
                ;;
            --)
                _section=""
                _opt=""
                ;;
        esac
    done <"$_backup"

    rm -f "$_backup" 2>/dev/null || true

    if [ "$_changed" = "1" ]; then
        uci -q commit system 2>/dev/null || true
        internet_status_led_uci_led_service_reload || true
        _log_msg="LED UCI: правила LuCI восстановлены из backup (cron снят)"
        if command -v usb_watch_log_line >/dev/null 2>&1; then
            usb_watch_log_line "$_log_msg"
        else
            echo "[+] $_log_msg"
        fi
    fi
    return 0
}

internet_status_led_uci_quarantine_status_line() {
    if internet_status_led_uci_quarantine_active; then
        printf '  UCI LED      : quarantine (backup есть, trigger=none для watch)\n'
    else
        printf '  UCI LED      : без backup (LuCI как настроено)\n'
    fi
}

# Подсказка, если quarantine не ставили (cron вручную / старый конфиг).
internet_status_led_uci_netdev_hint() {
    internet_status_led_profile_load
    internet_status_led_uci_quarantine_active && return 0
    command -v uci >/dev/null 2>&1 || return 0
    _led="$INTERNET_STATUS_LED_WAN_ONLINE"
    for s in $(uci -q show system 2>/dev/null | sed -n 's/^\(system\.[^=]*\)=led$/\1/p'); do
        sysfs="$(uci -q get "${s}.sysfs" 2>/dev/null)" || true
        name="$(uci -q get "${s}.name" 2>/dev/null)" || true
        [ "$sysfs" = "$_led" ] || [ "$name" = "$_led" ] || continue
        trig="$(uci -q get "${s}.trigger" 2>/dev/null)" || true
        dev="$(uci -q get "${s}.dev" 2>/dev/null)" || true
        if [ "$trig" = "netdev" ] && [ -z "$dev" ]; then
            usb_watch_log_line "LED: UCI ${s} trigger=netdev без dev — установите cron (меню п.6) для авто-quarantine"
        fi
        return 0
    done
}

internet_status_led_profile_summary_line() {
    internet_status_led_profile_load
    if [ "${INTERNET_STATUS_LED_WAN_ONLY:-0}" = "1" ]; then
        printf 'wan-online-only (%s)\n' "$INTERNET_STATUS_LED_WAN_ONLINE"
    else
        printf 'dual (%s + %s)\n' "$INTERNET_STATUS_LED_WAN_ONLINE" "$INTERNET_STATUS_LED_FAULT"
    fi
}
