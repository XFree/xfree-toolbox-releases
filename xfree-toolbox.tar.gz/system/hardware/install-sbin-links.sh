#!/bin/sh
# shellcheck shell=sh
# Симлинки в /usr/sbin для аппаратных утилит (вызывается из postinst / install-bootstrap / self-update).

_install_sbin_lib="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)/../router-commands-lib.sh"
if [ -f "$_install_sbin_lib" ]; then
    # shellcheck disable=SC1091
    . "$_install_sbin_lib"
fi

install_hardware_sbin_links() {
    root="${1:-/root/xfree-toolbox}"
    if command -v router_cmd_install_usb_modem >/dev/null 2>&1; then
        router_cmd_install_usb_modem "$root" || return 1
        return 0
    fi
    return 1
}

case "${1:-}" in
    install)
        install_hardware_sbin_links "${2:-/root/xfree-toolbox}"
        ;;
    -h|--help)
        echo "Usage: $0 install [toolbox_root]"
        echo "  or: . install-sbin-links.sh && install_hardware_sbin_links /root/xfree-toolbox"
        ;;
esac
