#!/bin/sh
# shellcheck shell=sh
# Обратная совместимость: делегирует install-button-hooks.sh --ensure.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="/root/xfree-toolbox"
QUIET=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --root)
      shift
      [ "$#" -gt 0 ] || exit 2
      ROOT_DIR="$(CDPATH= cd -- "$1" && pwd -P)"
      ;;
    --quiet) QUIET=1 ;;
    -h|--help)
      exec sh "$SCRIPT_DIR/install-button-hooks.sh" --help
      ;;
    *)
      ROOT_DIR="$(CDPATH= cd -- "$1" && pwd -P)"
      ;;
  esac
  shift
done

_exec="$SCRIPT_DIR/install-button-hooks.sh"
[ -f "$_exec" ] || { echo "[-] не найден $_exec" >&2; exit 1; }
set -- sh "$_exec" --ensure --root "$ROOT_DIR"
[ "$QUIET" = "1" ] && set -- "$@" --quiet
exec "$@"
