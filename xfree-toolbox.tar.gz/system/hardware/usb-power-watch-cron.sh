#!/bin/sh
# shellcheck shell=sh
# Cron для usb-power-watch-run.sh (интервал из конфига при install).
#
# Usage:
#   usb-power-watch-cron.sh install
#   usb-power-watch-cron.sh remove
#   usb-power-watch-cron.sh status
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"
. "$SCRIPT_DIR/usb-power-watch-lib.sh"
. "$ROOT_DIR/lib/led/led-lib.sh"
. "$SCRIPT_DIR/internet-status-led-lib.sh"

RUN_ABS="$(CDPATH= cd -- "$SCRIPT_DIR" && pwd -P)/usb-power-watch-run.sh"
MARKER="$USB_WATCH_CRON_MARKER"

usage() {
    cat <<EOF
Usage: $(basename "$0") install|remove|status

  install — cron по INTERVAL_MIN из $(usb_watch_conf_path)
  remove  — убрать задачу
  status  — crontab + конфиг
EOF
}

cron_body_for_interval() {
    interval="$1"
    if ! usb_watch_cron_schedule_for_interval "$interval"; then
        echo "[-] INTERVAL_MIN: целое 1–60 (минуты; 60 = раз в час), сейчас: $interval" >&2
        return 1
    fi
}

install_cron() {
    usb_watch_load_config
    case "$USB_WATCH_INTERVAL_MIN" in
        ''|*[!0-9]*) USB_WATCH_INTERVAL_MIN=3 ;;
    esac

    body="$(cron_body_for_interval "$USB_WATCH_INTERVAL_MIN")" || return 1
    [ -x "$RUN_ABS" ] || chmod +x "$RUN_ABS" 2>/dev/null || true

    _log="$(usb_watch_run_log_path)"
    mkdir -p "$(dirname "$_log")" 2>/dev/null || true

    tmp_ct="$(mktemp 2>/dev/null || echo /tmp/usb-watch-cron.$$)"
    usb_watch_crontab_filter_to_file "$tmp_ct"
    {
        cat "$tmp_ct"
        printf '%s\n' "$MARKER"
        # stderr/stdout в лог — иначе сбой до usb_watch_log_line не виден в .log
        printf '%s /bin/sh %s >>%s 2>&1\n' "$body" "$RUN_ABS" "$_log"
    } >"${tmp_ct}.new"
    if ! usb_watch_crontab_apply_file "${tmp_ct}.new"; then
        echo "[-] crontab: не удалось установить задачу (проверьте права и /etc/crontabs/root)" >&2
        rm -f "$tmp_ct" "${tmp_ct}.new"
        return 1
    fi
    rm -f "$tmp_ct" "${tmp_ct}.new"

    /etc/init.d/cron enabled 2>/dev/null && /etc/init.d/cron restart >/dev/null 2>&1 || true

    usb_watch_conf_set "$(usb_watch_conf_path)" ENABLED 1
    usb_watch_load_config

    export USB_WATCH_ROOT_DIR="$ROOT_DIR"
    if usb_watch_recovery_enable_if_needed 2>/dev/null; then
        echo "[+] iface-recovery-scheduler: ENABLED=1"
    fi

    if internet_status_led_uci_quarantine_install; then
        echo "[+] LED UCI: конфликтующие правила LuCI (netdev/timer) → trigger=none, backup в $(internet_status_led_uci_backup_path)"
    fi

    echo "[+] USB power watch: cron $body (каждые ${USB_WATCH_INTERVAL_MIN} мин)"
    echo "    Скрипт: $RUN_ABS"
    echo "    ENABLED=1 в $(usb_watch_conf_path)"
}

usb_watch_restore_internet_leds() {
    usb_watch_load_config 2>/dev/null || true
    if internet_status_led_disable_full; then
        echo "[+] LED: sysfs и UCI LuCI восстановлены (служба led)"
        return 0
    fi
    echo "[!] LED: не удалось полностью восстановить — проверьте /etc/init.d/led" >&2
    return 1
}

remove_cron() {
    tmp_ct="$(mktemp 2>/dev/null || echo /tmp/usb-watch-cron.$$)"
    usb_watch_crontab_filter_to_file "$tmp_ct"
    if ! usb_watch_crontab_apply_file "$tmp_ct"; then
        echo "[-] crontab: не удалось обновить (пустой crontab допустим)" >&2
        rm -f "$tmp_ct"
        return 1
    fi
    rm -f "$tmp_ct"
    usb_watch_conf_set "$(usb_watch_conf_path)" ENABLED 0
    echo "[+] Задача usb-power-watch удалена из crontab"
    usb_watch_restore_internet_leds || true
}

show_status() {
    usb_watch_format_status
    printf '\n=== crontab (usb-power-watch) ===\n'
    usb_watch_crontab_read | grep -E 'usb-power-watch|xfree-toolbox-usb-power|connectivity-watch|xfree-toolbox-connectivity' || \
        printf '(нет записей)\n'
}

cmd="${1:-}"
case "$cmd" in
    install) install_cron ;;
    remove) remove_cron ;;
    status) show_status ;;
    -h|--help) usage ;;
    *)
        usage >&2
        exit 2
        ;;
esac
