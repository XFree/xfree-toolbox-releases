#!/bin/sh
# shellcheck shell=sh
# Бэкенды управления питанием USB (разные модели роутеров).
# Используется через system/hardware/usb-power.sh

_USB_POWER_LIB_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
_USB_POWER_LIB_ROOT="$(CDPATH= cd -- "$_USB_POWER_LIB_DIR/../.." && pwd -P)"
# shellcheck disable=SC1091
. "$_USB_POWER_LIB_ROOT/lib/cmd-timeout.sh"

USB_POWER_METHOD=""
USB_POWER_LAST_ERROR=""

usb_power_log() {
    if command -v logger >/dev/null 2>&1; then
        logger -t usb-power "$*"
    fi
}

usb_power_have_cmd() {
    command -v "$1" >/dev/null 2>&1
}

# uhubctl на части плат зависает без таймаута — не блокировать меню/статус.
usb_power_cmd_timeout() {
    _sec="$1"
    shift
    cmd_timeout "$_sec" "$@"
}

# --- xhci-mtk (Cudy WBR3000UAX и аналоги MediaTek) ---

usb_power_xhci_driver_dir() {
    printf '%s' "/sys/bus/platform/drivers/xhci-mtk"
}

usb_power_xhci_find_device() {
    drv="$(usb_power_xhci_driver_dir)"
    [ -d "$drv" ] || return 1
    for x in "$drv"/*; do
        [ -L "$x" ] || continue
        basename "$x"
        return 0
    done
    return 1
}

usb_power_xhci_available() {
    dev="$(usb_power_xhci_find_device 2>/dev/null || true)"
    [ -n "$dev" ] && [ -w "$(usb_power_xhci_driver_dir)/unbind" ] 2>/dev/null
}

usb_power_xhci_cycle() {
    off_sec="${1:-8}"
    on_sec="${2:-5}"
    drv="$(usb_power_xhci_driver_dir)"
    dev="$(usb_power_xhci_find_device)" || {
        USB_POWER_LAST_ERROR="xhci-mtk: контроллер не найден в $drv"
        return 1
    }

    usb_power_log "xhci-mtk cycle $dev: off ${off_sec}s, on ${on_sec}s"
    printf '%s\n' "$dev" > "$drv/unbind" 2>/dev/null || {
        USB_POWER_LAST_ERROR="xhci-mtk: unbind failed for $dev"
        return 1
    }
    sleep "$off_sec"
    printf '%s\n' "$dev" > "$drv/bind" 2>/dev/null || {
        USB_POWER_LAST_ERROR="xhci-mtk: bind failed for $dev"
        return 1
    }
    sleep "$on_sec"
    return 0
}

# --- gpio_switch из UCI (некоторые платы) ---

usb_power_gpio_find_uci_section() {
    command -v uci >/dev/null 2>&1 || return 1
    for sec in $(uci -q show system 2>/dev/null | sed -n 's/^system\.\([^=]*\)=gpio_switch$/\1/p'); do
        pin="$(uci -q get "system.$sec.gpio_pin" 2>/dev/null || true)"
        name="$(uci -q get "system.$sec.name" 2>/dev/null || true)"
        case "$pin$name" in
            *usb*|*USB*|*modem*|*Modem*|*lte*|*LTE*)
                printf '%s\n' "$sec"
                return 0
                ;;
        esac
    done
    return 1
}

usb_power_gpio_sysfs_path() {
    pin="$1"
    [ -n "$pin" ] || return 1
    if [ -d "/sys/class/gpio/$pin" ]; then
        printf '%s' "/sys/class/gpio/$pin"
        return 0
    fi
    if [ -d "/sys/class/gpio/gpio${pin}" ]; then
        printf '%s' "/sys/class/gpio/gpio${pin}"
        return 0
    fi
    return 1
}

usb_power_gpio_available() {
    sec="$(usb_power_gpio_find_uci_section 2>/dev/null | head -n1)" || return 1
    [ -n "$sec" ] || return 1
    pin="$(uci -q get "system.$sec.gpio_pin" 2>/dev/null || true)"
    usb_power_gpio_sysfs_path "$pin" >/dev/null 2>&1
}

usb_power_gpio_cycle() {
    off_sec="${1:-3}"
    on_sec="${2:-3}"
    sec="$(usb_power_gpio_find_uci_section 2>/dev/null | head -n1)" || {
        USB_POWER_LAST_ERROR="gpio: нет gpio_switch для USB в UCI"
        return 1
    }
    pin="$(uci -q get "system.$sec.gpio_pin" 2>/dev/null || true)"
    gpath="$(usb_power_gpio_sysfs_path "$pin")" || {
        USB_POWER_LAST_ERROR="gpio: sysfs для pin=$pin не найден"
        return 1
    }

    usb_power_log "gpio cycle section=$sec pin=$pin: off ${off_sec}s, on ${on_sec}s"
    if [ -w "${gpath}/value" ]; then
        echo 0 > "${gpath}/value" 2>/dev/null || true
        sleep "$off_sec"
        echo 1 > "${gpath}/value" 2>/dev/null || true
        sleep "$on_sec"
        return 0
    fi
    if [ -w "${gpath}/direction" ]; then
        echo low > "${gpath}/direction" 2>/dev/null || true
        sleep "$off_sec"
        echo high > "${gpath}/direction" 2>/dev/null || true
        sleep "$on_sec"
        return 0
    fi
    USB_POWER_LAST_ERROR="gpio: нет value/direction в $gpath"
    return 1
}

# --- uhubctl (внешний smart hub; редко на встроенном порте) ---

usb_power_uhubctl_available() {
    usb_power_have_cmd uhubctl || return 1
    _out="$(usb_power_cmd_timeout 3 uhubctl 2>/dev/null)" || return 1
    printf '%s' "$_out" | grep -q .
}

usb_power_uhubctl_cycle() {
    off_sec="${1:-8}"
    on_sec="${2:-5}"
    usb_power_have_cmd uhubctl || {
        USB_POWER_LAST_ERROR="uhubctl: не установлен"
        return 1
    }
    usb_power_log "uhubctl cycle -d $off_sec (hub default port)"
    usb_power_cmd_timeout $((off_sec + 15)) uhubctl -a cycle -d "$off_sec" 2>/dev/null || {
        USB_POWER_LAST_ERROR="uhubctl: cycle failed (порт может не поддерживать VBUS off)"
        return 1
    }
    sleep "$on_sec"
    return 0
}

# --- выбор метода ---

usb_power_list_methods() {
    usb_power_xhci_available && printf '%s\n' "xhci-mtk"
    usb_power_gpio_available && printf '%s\n' "gpio-switch"
    usb_power_uhubctl_available && printf '%s\n' "uhubctl"
}

usb_power_pick_method() {
    prefer="${1:-auto}"
    case "$prefer" in
        xhci-mtk|xhci)
            if usb_power_xhci_available; then
                USB_POWER_METHOD="xhci-mtk"
                return 0
            fi
            USB_POWER_LAST_ERROR="xhci-mtk недоступен"
            return 1
            ;;
        gpio|gpio-switch)
            if usb_power_gpio_available; then
                USB_POWER_METHOD="gpio-switch"
                return 0
            fi
            USB_POWER_LAST_ERROR="gpio-switch недоступен"
            return 1
            ;;
        uhubctl)
            if usb_power_uhubctl_available; then
                USB_POWER_METHOD="uhubctl"
                return 0
            fi
            USB_POWER_LAST_ERROR="uhubctl недоступен"
            return 1
            ;;
        auto|"")
            if usb_power_xhci_available; then
                USB_POWER_METHOD="xhci-mtk"
                return 0
            fi
            if usb_power_gpio_available; then
                USB_POWER_METHOD="gpio-switch"
                return 0
            fi
            if usb_power_uhubctl_available; then
                USB_POWER_METHOD="uhubctl"
                return 0
            fi
            USB_POWER_LAST_ERROR="нет подходящего бэкенда (xhci-mtk / gpio-switch / uhubctl)"
            return 1
            ;;
        *)
            USB_POWER_LAST_ERROR="неизвестный метод: $prefer"
            return 1
            ;;
    esac
}

usb_power_cycle() {
    off_sec="${1:-8}"
    on_sec="${2:-5}"
    method="${3:-auto}"

    usb_power_pick_method "$method" || return 1

    case "$USB_POWER_METHOD" in
        xhci-mtk)
            usb_power_xhci_cycle "$off_sec" "$on_sec"
            ;;
        gpio-switch)
            usb_power_gpio_cycle "$off_sec" "$on_sec"
            ;;
        uhubctl)
            usb_power_uhubctl_cycle "$off_sec" "$on_sec"
            ;;
        *)
            USB_POWER_LAST_ERROR="внутренняя ошибка: метод не выбран"
            return 1
            ;;
    esac
}

usb_power_print_status() {
    _board_line="board=?"
    if command -v hardware_board_summary_line >/dev/null 2>&1; then
        _board_line="$(hardware_board_summary_line)"
    fi
    printf '%s\n' "=== USB power ($_board_line) ==="
    printf 'Доступные бэкенды:\n'
    listed=0
    for m in xhci-mtk gpio-switch uhubctl; do
        case "$m" in
            xhci-mtk)
                if usb_power_xhci_available; then
                    dev="$(usb_power_xhci_find_device 2>/dev/null || true)"
                    printf '  xhci-mtk: да (устройство %s)\n' "${dev:-?}"
                    listed=1
                else
                    printf '  xhci-mtk: нет\n'
                fi
                ;;
            gpio-switch)
                if usb_power_gpio_available; then
                    sec="$(usb_power_gpio_find_uci_section 2>/dev/null | head -n1)"
                    printf '  gpio-switch: да (UCI system.%s)\n' "${sec:-?}"
                    listed=1
                else
                    printf '  gpio-switch: нет\n'
                fi
                ;;
            uhubctl)
                if usb_power_uhubctl_available; then
                    printf '  uhubctl: да (smart hub в lsusb)\n'
                    listed=1
                else
                    printf '  uhubctl: нет\n'
                fi
                ;;
        esac
    done
    if [ "$listed" = "0" ]; then
        printf '  (ни один бэкенд не готов — cycle не сработает)\n'
    fi
    if usb_power_pick_method auto 2>/dev/null; then
        printf 'Автовыбор для cycle: %s\n' "$USB_POWER_METHOD"
    else
        printf 'Автовыбор: недоступен (%s)\n' "${USB_POWER_LAST_ERROR:-?}"
    fi
    printf '\n'
    if usb_power_have_cmd lsusb; then
        printf 'lsusb:\n'
        lsusb 2>/dev/null | while read -r line; do
            printf '  %s\n' "$line"
        done
    fi
}

usb_power_mount_debugfs_if_needed() {
    mount | grep -q ' /sys/kernel/debug ' && return 0
    [ -d /sys/kernel/debug ] || return 1
    mount -t debugfs none /sys/kernel/debug 2>/dev/null || true
}

usb_power_regulator_snippet() {
    usb_power_mount_debugfs_if_needed
    if [ -r /sys/kernel/debug/regulator/regulator_summary ]; then
        grep -i -A8 -B8 'usb' /sys/kernel/debug/regulator/regulator_summary 2>/dev/null || \
            printf '%s\n' "(строк usb в regulator_summary не найдены)"
    else
        printf '%s\n' "(regulator_summary недоступен — смонтируйте debugfs)"
    fi
}
