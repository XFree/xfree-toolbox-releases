#!/bin/sh
# shellcheck shell=sh
# Backward-compat shim: hardware LED runtime moved to lib/led/led-lib.sh.

_LED_LIB_THIS_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
_LED_LIB_ROOT_DIR="$(CDPATH= cd -- "$_LED_LIB_THIS_DIR/../.." && pwd -P)"
_LED_LIB_CANONICAL="$_LED_LIB_ROOT_DIR/lib/led/led-lib.sh"

if [ -f "$_LED_LIB_CANONICAL" ]; then
    # shellcheck disable=SC1090
    . "$_LED_LIB_CANONICAL"
    return 0 2>/dev/null || exit 0
fi

echo "[-] LED lib not found: $_LED_LIB_CANONICAL" >&2
return 1 2>/dev/null || exit 1
