#!/bin/sh
# shellcheck shell=sh
# Alias for usb-power-watch-cron.sh
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
exec sh "$SCRIPT_DIR/usb-power-watch-cron.sh" "$@"
