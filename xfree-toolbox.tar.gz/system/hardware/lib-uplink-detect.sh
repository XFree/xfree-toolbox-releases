#!/bin/sh
# shellcheck shell=sh
# Canonical uplink (PROBE_IFACE auto) detection: wan / wwan / lte / default-route L3.
# Shared by usb-watch and iface recovery hotplug. Do not duplicate this logic.
#
# usb_watch_ifup_should_recover: netifd ifup of this logical iface should bounce VPN.

USB_WATCH_UPLINK_DETECT_LIB_SOURCED="${USB_WATCH_UPLINK_DETECT_LIB_SOURCED:-}"
[ -n "$USB_WATCH_UPLINK_DETECT_LIB_SOURCED" ] && return 0
USB_WATCH_UPLINK_DETECT_LIB_SOURCED=1

usb_watch_sysfs_root() {
    printf '%s' "${USB_WATCH_SYSFS_ROOT:-/sys}"
}

usb_watch_net_dev_sysfs_dir() {
    printf '%s/class/net' "$(usb_watch_sysfs_root)"
}

usb_watch_net_dev_exists() {
    _dev="$1"
    [ -n "$_dev" ] || return 1
    [ -d "$(usb_watch_net_dev_sysfs_dir)/$_dev" ]
}

usb_watch_uci_network_section_exists() {
    _sec="$1"
    [ -n "$_sec" ] || return 1
    command -v uci >/dev/null 2>&1 || return 1
    uci -q get "network.${_sec}" >/dev/null 2>&1
}

usb_watch_uci_iface_is_up() {
    _iface="$1"
    [ -n "$_iface" ] || return 1
    command -v ubus >/dev/null 2>&1 || return 1
    _st="$(ubus call "network.interface.${_iface}" status 2>/dev/null || true)"
    case "$_st" in
        *'"up": true'*|*'"up":true'*) return 0 ;;
    esac
    return 1
}

usb_watch_default_route_dev4() {
    command -v ip >/dev/null 2>&1 || return 1
    ip -4 route show default 2>/dev/null | awk '/default/ {
        for (i = 1; i <= NF; i++)
            if ($i == "dev") { print $(i + 1); exit }
    }'
}

usb_watch_read_sysfs_carrier() {
    _dev="$1"
    _path="$(usb_watch_net_dev_sysfs_dir)/$_dev/carrier"
    [ -f "$_path" ] || return 1
    [ "$(cat "$_path" 2>/dev/null | tr -d '\r\n')" = "1" ]
}

usb_watch_read_sysfs_oper_up() {
    _dev="$1"
    _path="$(usb_watch_net_dev_sysfs_dir)/$_dev/operstate"
    [ -f "$_path" ] || return 1
    case "$(cat "$_path" 2>/dev/null | tr -d '\r\n')" in
        up|unknown) return 0 ;;
    esac
    return 1
}

# L2 link: eth* — carrier; wwan* — carrier или operstate; ppp/usb — operstate; прочее — не блокируем.
usb_watch_net_dev_link_ready() {
    _dev="$1"
    [ -n "$_dev" ] || return 1
    usb_watch_net_dev_exists "$_dev" || return 1
    case "$_dev" in
        eth*)
            usb_watch_read_sysfs_carrier "$_dev"
            ;;
        wwan*)
            if usb_watch_read_sysfs_carrier "$_dev" 2>/dev/null; then
                return 0
            fi
            usb_watch_read_sysfs_oper_up "$_dev"
            ;;
        ppp*|usb*)
            usb_watch_read_sysfs_oper_up "$_dev"
            ;;
        *)
            return 0
            ;;
    esac
}

# OpenWrt runtime L3 netdev for UCI logical iface (wan → pppoe-wan, eth1, …).
usb_watch_ubus_iface_l3_device() {
    iface="$1"
    [ -n "$iface" ] || return 1
    command -v ubus >/dev/null 2>&1 || return 1
    _st="$(ubus call "network.interface.$iface" status 2>/dev/null || true)"
    [ -n "$_st" ] || return 1
    _dev="$(printf '%s\n' "$_st" | sed -n 's/.*"l3_device": "\([^"]*\)".*/\1/p' | head -n1)"
    [ -n "$_dev" ] && usb_watch_net_dev_exists "$_dev" || return 1
    printf '%s\n' "$_dev"
}

# Для UCI wan/wwan/lte: L3 netdev + carrier (только fallback auto, не default route).
usb_watch_uci_iface_link_ready() {
    _iface="$1"
    _l3=""
    [ -n "$_iface" ] || return 1
    _l3="$(usb_watch_ubus_iface_l3_device "$_iface" 2>/dev/null || true)"
    if [ -z "$_l3" ] && command -v uci >/dev/null 2>&1; then
        _l3="$(uci -q get "network.${_iface}.device" 2>/dev/null || true)"
        [ -n "$_l3" ] || _l3="$(uci -q get "network.${_iface}.ifname" 2>/dev/null || true)"
    fi
    if [ -z "$_l3" ]; then
        case "$_iface" in
            eth*|wwan*|ppp*) _l3="$_iface" ;;
        esac
    fi
    [ -n "$_l3" ] || return 0
    usb_watch_net_dev_link_ready "$_l3"
}

# 1 = L2-интерфейс probe висит на USB (cdc_ether, qmi_wwan, …), не по имени UCI.
usb_watch_net_dev_is_usb() {
    _dev="$1"
    [ -n "$_dev" ] || return 1
    _net_base="$(usb_watch_net_dev_sysfs_dir)"
    [ -d "$_net_base/$_dev" ] || return 1
    _dev_link="$_net_base/$_dev/device"
    [ -L "$_dev_link" ] || [ -d "$_dev_link" ] || return 1
    _real="$(readlink -f "$_dev_link" 2>/dev/null || true)"
    case "$_real" in
        */usb[0-9]*/*|*/usb/*) return 0 ;;
    esac
    if [ -f "$_dev_link/driver/name" ]; then
        _driver="$(cat "$_dev_link/driver/name" 2>/dev/null || true)"
    else
        _driver="$(readlink -f "$_dev_link/driver" 2>/dev/null || true)"
        _driver="$(basename "$_driver" 2>/dev/null || true)"
    fi
    case "$_driver" in
        cdc_ether|qmi_wwan|cdc_ncm|cdc_mbim|cdc_wdm|option|rndis_host|asix|*cdc*|*wwan*)
            return 0
            ;;
    esac
    return 1
}

usb_watch_uplink_detect_load_known_router() {
    command -v usb_watch_known_router_lib_load >/dev/null 2>&1 && {
        usb_watch_known_router_lib_load 2>/dev/null || true
        return 0
    }
    [ "${USB_WATCH_KNOWN_ROUTER_LIB_LOADED:-0}" = "1" ] && return 0
    _root="${USB_WATCH_ROOT_DIR:-${XFREE_TOOLBOX_ROOT:-}}"
    [ -n "$_root" ] || return 1
    _lib="$_root/system/hardware/lib-known-router.sh"
    [ -f "$_lib" ] || return 1
    HARDWARE_KNOWN_ROUTER_DIR="$_root/system/hardware"
    # shellcheck disable=SC1090
    . "$_lib"
    USB_WATCH_KNOWN_ROUTER_LIB_LOADED=1
    return 0
}

# LTE/wwan в auto: yes из known-routers.tsv; unknown board — только если network.lte на USB.
usb_watch_lte_auto_allowed() {
    usb_watch_uplink_detect_load_known_router 2>/dev/null || true
    if command -v hardware_known_router_watch_usb_power_field >/dev/null 2>&1; then
        _v="$(hardware_known_router_watch_usb_power_field 2>/dev/null || true)"
        case "$_v" in
            no|0|n|N|false|off|'-'|'--') return 1 ;;
            yes|y|Y|1|true|on) return 0 ;;
        esac
    fi
    usb_watch_uci_network_section_exists lte || return 1
    _l3="$(usb_watch_ubus_iface_l3_device lte 2>/dev/null || true)"
    [ -n "$_l3" ] && usb_watch_net_dev_is_usb "$_l3"
}

usb_watch_ubus_logical_iface_for_l3() {
    _want="$1"
    [ -n "$_want" ] || return 1
    for _iface in wan wwan lte; do
        case "$_iface" in
            lte) usb_watch_lte_auto_allowed || continue ;;
        esac
        usb_watch_uci_network_section_exists "$_iface" || continue
        _l3="$(usb_watch_ubus_iface_l3_device "$_iface" 2>/dev/null || true)"
        [ "$_l3" = "$_want" ] || continue
        printf '%s\n' "$_iface"
        return 0
    done
    return 1
}

# Разрешить PROBE_IFACE: auto → default route (wan / wwan / lte), lte только на USB-платформах.
usb_watch_detect_probe_iface() {
    _raw="${1:-auto}"
    case "$_raw" in
        auto|'')
            ;;
        *)
            printf '%s\n' "$_raw"
            return 0
            ;;
    esac

    _dr="$(usb_watch_default_route_dev4 2>/dev/null || true)"
    if [ -n "$_dr" ]; then
        _logical="$(usb_watch_ubus_logical_iface_for_l3 "$_dr" 2>/dev/null || true)"
        if [ -n "$_logical" ]; then
            printf '%s\n' "$_logical"
            return 0
        fi
        case "$_dr" in
            eth*|wwan*|usb*|ppp*)
                printf '%s\n' "$_dr"
                return 0
                ;;
        esac
    fi

    for _cand in wan wwan; do
        if usb_watch_uci_network_section_exists "$_cand" && usb_watch_uci_iface_is_up "$_cand" \
            && usb_watch_uci_iface_link_ready "$_cand"; then
            printf '%s\n' "$_cand"
            return 0
        fi
    done
    if usb_watch_lte_auto_allowed && usb_watch_uci_network_section_exists lte && usb_watch_uci_iface_is_up lte \
        && usb_watch_uci_iface_link_ready lte; then
        printf '%s\n' lte
        return 0
    fi

    for _cand in wan wwan; do
        if usb_watch_uci_network_section_exists "$_cand" && usb_watch_uci_iface_link_ready "$_cand"; then
            printf '%s\n' "$_cand"
            return 0
        fi
    done
    if usb_watch_lte_auto_allowed && usb_watch_uci_network_section_exists lte \
        && usb_watch_uci_iface_link_ready lte; then
        printf '%s\n' lte
        return 0
    fi

    printf '%s\n' wan
}

# ifup of this UCI iface should schedule recover_stack (VPN bounce).
# Matches usb_watch_detect_probe_iface auto, plus wan/wwan/lte while default route still lags.
usb_watch_ifup_should_recover() {
    _iface="$1"
    case "$_iface" in
        ''|*[!A-Za-z0-9_-]*) return 1 ;;
    esac
    _detected="$(usb_watch_detect_probe_iface auto 2>/dev/null || true)"
    [ -n "$_detected" ] && [ "$_iface" = "$_detected" ] && return 0
    case "$_iface" in
        wan|wwan|lte) return 0 ;;
    esac
    return 1
}
