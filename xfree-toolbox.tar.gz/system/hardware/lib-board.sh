#!/bin/sh
# shellcheck shell=sh
# Сведения о плате (только для сообщений; пункты меню не скрываем).

hardware_board_name() {
    if [ -r /tmp/sysinfo/board_name ]; then
        tr -d '\r\n' < /tmp/sysinfo/board_name
        return 0
    fi
    printf '%s' "unknown"
}

hardware_model_name() {
    if [ -r /tmp/sysinfo/model ]; then
        tr -d '\r\n' < /tmp/sysinfo/model
        return 0
    fi
    hardware_board_name
}

hardware_board_summary_line() {
    printf 'board=%s model=%s' "$(hardware_board_name)" "$(hardware_model_name)"
}
