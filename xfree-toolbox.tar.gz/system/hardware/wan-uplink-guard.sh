#!/bin/sh
# shellcheck shell=sh
# WAN Uplink Guard: validates and reconciles WAN/LAN network & firewall invariants.
# Enforces:
#   1. WAN IPv6 disabled on all detected WAN interfaces (including PPPoE noipv6 & wan6 disabled=1, auto=0).
#   2. LAN IPv6 ULA preserved with ra_default='0' (clients get local IPv6, no default IPv6 gateway).
#   3. Firewall zone 'vpn' has both IPv4 and IPv6 masquerading (masq=1, masq6=1).
#   4. Android Private DNS DoT (TCP 853) is rejected on WAN to prevent dnsmasq bypass.
# Batched: inspects all, commits modified configs atomically, reloads services in order:
#   network -> firewall -> odhcpd.
set -eu

_wan_guard_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
_wan_guard_root="$(CDPATH= cd -- "$_wan_guard_dir/../.." && pwd -P)"
if [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/lib/common.sh" ]; then
    _wan_guard_root="$ROOT_DIR"
elif [ -n "${XFREE_ROOT_DIR:-}" ] && [ -f "$XFREE_ROOT_DIR/lib/common.sh" ]; then
    _wan_guard_root="$XFREE_ROOT_DIR"
fi

for _r_cand in "$_wan_guard_root" "${XFREE_ROOT_DIR:-/root/xfree-toolbox}" "$PWD"; do
    if [ -f "$_r_cand/lib/common.sh" ]; then
        # shellcheck disable=SC1090
        . "$_r_cand/lib/common.sh"
    fi
    if [ -f "$_r_cand/lib/wan6-policy.sh" ]; then
        # shellcheck disable=SC1090
        . "$_r_cand/lib/wan6-policy.sh"
        break
    fi
done

wan_guard_log() {
    _msg="$1"
    if command -v logger >/dev/null 2>&1; then
        logger -t 'xfree-wan-guard' "$_msg"
    fi
    if [ "${WAN_GUARD_SILENT:-0}" != "1" ]; then
        echo "[wan-guard] $_msg"
    fi
}

wan_guard_find_wan_interfaces() {
    _uci="${UCI_CMD:-uci}"
    _found=""

    # 1. Inspect firewall zone 'wan' for member networks
    _zone_idx=0
    while true; do
        _zname="$($_uci -q get "firewall.@zone[$_zone_idx].name" 2>/dev/null || true)"
        [ -n "$_zname" ] || break
        if [ "$_zname" = "wan" ]; then
            _nets="$($_uci -q get "firewall.@zone[$_zone_idx].network" 2>/dev/null || true)"
            for _n in $_nets; do
                _found="$_found $_n"
            done
        fi
        _zone_idx=$((_zone_idx + 1))
    done

    # 2. Inspect network interfaces by naming pattern and proto
    _iface_dump="$($_uci show network 2>/dev/null | grep -E '^network\.[^.]+=interface$' || true)"
    for _line in $_iface_dump; do
        _ifname="$(printf '%s\n' "$_line" | sed -n 's/^network\.\([^.]*\)=interface$/\1/p')"
        [ -n "$_ifname" ] || continue
        case "$_ifname" in
            wan*|wwan*|modem*|lte*)
                _found="$_found $_ifname"
                ;;
            *)
                _proto="$($_uci -q get "network.$_ifname.proto" 2>/dev/null || true)"
                if [ "$_proto" = "dhcpv6" ]; then
                    _found="$_found $_ifname"
                fi
                ;;
        esac
    done

    printf '%s\n' $_found | sort -u | grep -v '^$' || true
}

wan_guard_find_wan_devices() {
    _uci="${UCI_CMD:-uci}"
    _devs=""
    _dev_idx=0
    while true; do
        _dname="$($_uci -q get "network.@device[$_dev_idx].name" 2>/dev/null || true)"
        [ -n "$_dname" ] || break
        case "$_dname" in
            wan*|eth1|eth0.2)
                _devs="$_devs $_dev_idx"
                ;;
        esac
        _dev_idx=$((_dev_idx + 1))
    done
    printf '%s\n' $_devs | sort -u | grep -v '^$' || true
}

wan_guard_ensure_dot_reject_rule() {
    _uci="${UCI_CMD:-uci}"
    _rule_idx=0
    _found_rule=""
    while true; do
        _rname="$($_uci -q get "firewall.@rule[$_rule_idx].name" 2>/dev/null || true)"
        [ -n "$_rname" ] || break
        if [ "$_rname" = "Reject-DoT-wan" ] || [ "$_rname" = "Drop-DoT-wan" ]; then
            _found_rule="firewall.@rule[$_rule_idx]"
            break
        fi
        _rule_idx=$((_rule_idx + 1))
    done

    if [ -z "$_found_rule" ]; then
        wan_guard_log "Adding firewall rule to reject DoT (port 853) on WAN"
        _sname="firewall.reject_dot_wan"
        $_uci set "$_sname=rule"
        $_uci set "$_sname.name=Reject-DoT-wan"
        $_uci set "$_sname.src=lan"
        $_uci set "$_sname.dest=wan"
        $_uci set "$_sname.proto=tcp"
        $_uci set "$_sname.dest_port=853"
        $_uci set "$_sname.target=REJECT"
        return 1
    fi
    return 0
}

wan_uplink_guard_reconcile() {
    _uci="${UCI_CMD:-uci}"
    if ! command -v "$_uci" >/dev/null 2>&1 && [ -z "${UCI_CMD:-}" ]; then
        return 0
    fi

    _autoreconcile="${WAN_GUARD_AUTORECONCILE:-}"
    if [ -z "$_autoreconcile" ]; then
        _cf="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/system/usb-power-watch.conf"
        if [ -f "$_cf" ]; then
            _autoreconcile="$(sed -n 's/^WAN_GUARD_AUTORECONCILE=//p' "$_cf" | head -n1 | tr -d '\r')"
        fi
    fi
    [ -n "$_autoreconcile" ] || _autoreconcile=1

    _auto_fix=1
    case "$_autoreconcile" in
        0|no|NO|off|OFF|false|FALSE)
            _auto_fix=0
            wan_guard_log "Auto-reconcile is OFF (WAN_GUARD_AUTORECONCILE=$_autoreconcile); report-only mode"
            ;;
    esac

    violations=0
    dirty_network=0
    dirty_dhcp=0
    dirty_firewall=0

    _wan6_mode="auto"
    _wan6_eff="off"
    if command -v wan6_policy_load >/dev/null 2>&1; then
        wan6_policy_load
        _wan6_mode="${XFREE_WAN6_MODE:-auto}"
        _wan6_eff="$(wan6_policy_effective_mode)"
    fi

    if [ "$_wan6_mode" != "off" ]; then
        wan_guard_log "WAN6 policy mode=$_wan6_mode (effective=$_wan6_eff) — ensuring WAN/LAN IPv6 is enabled on all interfaces"
        _wan_ifaces="$(wan_guard_find_wan_interfaces)"
        for _iface in $_wan_ifaces; do
            _proto="$($_uci -q get "network.$_iface.proto" 2>/dev/null || true)"
            if [ "$_proto" = "dhcpv6" ]; then
                _auto="$($_uci -q get "network.$_iface.auto" 2>/dev/null || echo "1")"
                _disabled="$($_uci -q get "network.$_iface.disabled" 2>/dev/null || echo "0")"
                if [ "$_auto" != "1" ] || [ "$_disabled" != "0" ]; then
                    violations=$((violations + 1))
                    if [ "$_auto_fix" -eq 1 ]; then
                        wan_guard_log "Activating dhcpv6 interface: $_iface (disabled=0, auto=1)"
                        $_uci set "network.$_iface.disabled=0"
                        $_uci set "network.$_iface.auto=1"
                        dirty_network=1
                    else
                        wan_guard_log "[WARN] dhcpv6 interface $_iface is disabled (auto-fix is OFF)"
                    fi
                fi
            else
                _v6="$($_uci -q get "network.$_iface.ipv6" 2>/dev/null || true)"
                if [ "$_v6" = "0" ]; then
                    violations=$((violations + 1))
                    if [ "$_auto_fix" -eq 1 ]; then
                        wan_guard_log "Setting ipv6='auto' on WAN interface: $_iface (proto: $_proto)"
                        $_uci set "network.$_iface.ipv6=auto"
                        dirty_network=1
                    else
                        wan_guard_log "[WARN] WAN interface $_iface has ipv6='0' (auto-fix is OFF)"
                    fi
                fi
            fi
        done

        _wan_devs="$(wan_guard_find_wan_devices)"
        for _didx in $_wan_devs; do
            _v6="$($_uci -q get "network.@device[$_didx].ipv6" 2>/dev/null || true)"
            if [ "$_v6" = "0" ]; then
                _dname="$($_uci -q get "network.@device[$_didx].name" 2>/dev/null || true)"
                violations=$((violations + 1))
                if [ "$_auto_fix" -eq 1 ]; then
                    wan_guard_log "Setting ipv6='1' on device: @device[$_didx] ($_dname)"
                    $_uci set "network.@device[$_didx].ipv6=1"
                    dirty_network=1
                else
                    wan_guard_log "[WARN] Device @device[$_didx] ($_dname) has ipv6='0' (auto-fix is OFF)"
                fi
            fi
        done

        if $_uci -q get dhcp.lan >/dev/null 2>&1; then
            for _opt in ra dhcpv6; do
                _cur="$($_uci -q get "dhcp.lan.$_opt" 2>/dev/null || true)"
                if [ "$_cur" != "server" ]; then
                    violations=$((violations + 1))
                    if [ "$_auto_fix" -eq 1 ]; then
                        wan_guard_log "Setting dhcp.lan.$_opt='server'"
                        $_uci set "dhcp.lan.$_opt=server"
                        dirty_dhcp=1
                    else
                        wan_guard_log "[WARN] dhcp.lan.$_opt is not server (auto-fix is OFF)"
                    fi
                fi
            done
            _ra_def="$($_uci -q get dhcp.lan.ra_default 2>/dev/null || true)"
            if [ "$_ra_def" = "0" ]; then
                violations=$((violations + 1))
                if [ "$_auto_fix" -eq 1 ]; then
                    wan_guard_log "Removing dhcp.lan.ra_default='0' so WAN6 default route can be advertised"
                    $_uci delete dhcp.lan.ra_default 2>/dev/null || true
                    dirty_dhcp=1
                else
                    wan_guard_log "[WARN] dhcp.lan.ra_default=0 blocks IPv6 default route (auto-fix is OFF)"
                fi
            fi
        fi
    else
    # --- 1. WAN IPv6 Check & Reconcile ---
    _wan_ifaces="$(wan_guard_find_wan_interfaces)"
    for _iface in $_wan_ifaces; do
        _proto="$($_uci -q get "network.$_iface.proto" 2>/dev/null || true)"
        if [ "$_proto" = "dhcpv6" ]; then
            _auto="$($_uci -q get "network.$_iface.auto" 2>/dev/null || echo "1")"
            _disabled="$($_uci -q get "network.$_iface.disabled" 2>/dev/null || echo "0")"
            if [ "$_auto" != "0" ] || [ "$_disabled" != "1" ]; then
                violations=$((violations + 1))
                if [ "$_auto_fix" -eq 1 ]; then
                    wan_guard_log "Deactivating dhcpv6 interface: $_iface (disabled=1, auto=0)"
                    $_uci set "network.$_iface.disabled=1"
                    $_uci set "network.$_iface.auto=0"
                    dirty_network=1
                else
                    wan_guard_log "[WARN] dhcpv6 interface $_iface is active (auto-fix is OFF)"
                fi
            fi
        else
            _v6="$($_uci -q get "network.$_iface.ipv6" 2>/dev/null || true)"
            if [ "$_v6" != "0" ]; then
                violations=$((violations + 1))
                if [ "$_auto_fix" -eq 1 ]; then
                    wan_guard_log "Setting ipv6='0' on WAN interface: $_iface (proto: $_proto)"
                    $_uci set "network.$_iface.ipv6=0"
                    dirty_network=1
                else
                    wan_guard_log "[WARN] WAN interface $_iface has ipv6 enabled (auto-fix is OFF)"
                fi
            fi
        fi
    done

    _wan_devs="$(wan_guard_find_wan_devices)"
    for _didx in $_wan_devs; do
        _v6="$($_uci -q get "network.@device[$_didx].ipv6" 2>/dev/null || true)"
        if [ "$_v6" != "0" ]; then
            _dname="$($_uci -q get "network.@device[$_didx].name" 2>/dev/null || true)"
            violations=$((violations + 1))
            if [ "$_auto_fix" -eq 1 ]; then
                wan_guard_log "Setting ipv6='0' on device: @device[$_didx] ($_dname)"
                $_uci set "network.@device[$_didx].ipv6=0"
                dirty_network=1
            else
                wan_guard_log "[WARN] Device @device[$_didx] ($_dname) has ipv6 enabled (auto-fix is OFF)"
            fi
        fi
    done

    # --- 2. LAN IPv6 ULA Check (ra_default='0') ---
    if $_uci -q get dhcp.lan >/dev/null 2>&1; then
        _ra_def="$($_uci -q get dhcp.lan.ra_default 2>/dev/null || true)"
        if [ "$_ra_def" != "0" ]; then
            violations=$((violations + 1))
            if [ "$_auto_fix" -eq 1 ]; then
                wan_guard_log "Setting dhcp.lan.ra_default='0' (preventing default IPv6 gateway advertisement)"
                $_uci set dhcp.lan.ra_default=0
                dirty_dhcp=1
            else
                wan_guard_log "[WARN] dhcp.lan.ra_default is not 0 (auto-fix is OFF)"
            fi
        fi
    fi
    fi

    # --- 3. Firewall Zone 'vpn' NAT66 (masq=1, masq6=1) ---
    _zone_ref=""
    _zidx=0
    while true; do
        _zname="$($_uci -q get "firewall.@zone[$_zidx].name" 2>/dev/null || true)"
        [ -n "$_zname" ] || break
        if [ "$_zname" = "vpn" ]; then
            _zone_ref="firewall.@zone[$_zidx]"
            break
        fi
        _zidx=$((_zidx + 1))
    done

    if [ -n "$_zone_ref" ]; then
        _m4="$($_uci -q get "${_zone_ref}.masq" 2>/dev/null || true)"
        if [ "$_m4" != "1" ]; then
            violations=$((violations + 1))
            if [ "$_auto_fix" -eq 1 ]; then
                wan_guard_log "Enforcing masq='1' on ${_zone_ref}"
                $_uci set "${_zone_ref}.masq=1"
                dirty_firewall=1
            else
                wan_guard_log "[WARN] ${_zone_ref}.masq is not 1 (auto-fix is OFF)"
            fi
        fi
        _m6="$($_uci -q get "${_zone_ref}.masq6" 2>/dev/null || true)"
        if [ "$_m6" != "1" ]; then
            violations=$((violations + 1))
            if [ "$_auto_fix" -eq 1 ]; then
                wan_guard_log "Enforcing masq6='1' on ${_zone_ref} (NAT66)"
                $_uci set "${_zone_ref}.masq6=1"
                dirty_firewall=1
            else
                wan_guard_log "[WARN] ${_zone_ref}.masq6 is not 1 (auto-fix is OFF)"
            fi
        fi
    fi

    # --- 4. Android DoT Reject Rule (TCP 853) ---
    _rule_idx=0
    _found_rule=""
    while true; do
        _rname="$($_uci -q get "firewall.@rule[$_rule_idx].name" 2>/dev/null || true)"
        [ -n "$_rname" ] || break
        if [ "$_rname" = "Reject-DoT-wan" ] || [ "$_rname" = "Drop-DoT-wan" ]; then
            _found_rule="firewall.@rule[$_rule_idx]"
            break
        fi
        _rule_idx=$((_rule_idx + 1))
    done

    if [ -z "$_found_rule" ]; then
        violations=$((violations + 1))
        if [ "$_auto_fix" -eq 1 ]; then
            wan_guard_log "Adding firewall rule to reject DoT (port 853) on WAN"
            _sname="firewall.reject_dot_wan"
            $_uci set "$_sname=rule"
            $_uci set "$_sname.name=Reject-DoT-wan"
            $_uci set "$_sname.src=lan"
            $_uci set "$_sname.dest=wan"
            $_uci set "$_sname.proto=tcp"
            $_uci set "$_sname.dest_port=853"
            $_uci set "$_sname.target=REJECT"
            dirty_firewall=1
        else
            wan_guard_log "[WARN] Firewall rule Reject-DoT-wan missing (auto-fix is OFF)"
        fi
    fi

    if [ "$_auto_fix" -eq 0 ]; then
        if [ "$violations" -gt 0 ]; then
            wan_guard_log "Auto-reconcile is OFF. Found $violations invariant violations; manual configuration preserved without changes."
        else
            wan_guard_log "All WAN/LAN invariants verified OK"
        fi
        return 0
    fi

    # --- 5. Atomic Commits ---
    if [ "$dirty_network" -eq 1 ]; then
        wan_guard_log "Committing network config"
        $_uci commit network
    fi
    if [ "$dirty_firewall" -eq 1 ]; then
        wan_guard_log "Committing firewall config"
        $_uci commit firewall
    fi
    if [ "$dirty_dhcp" -eq 1 ]; then
        wan_guard_log "Committing dhcp config"
        $_uci commit dhcp
    fi

    # --- 6. Ordered Batched Reloads ---
    if [ "$dirty_network" -eq 1 ]; then
        if [ -x /etc/init.d/network ]; then
            wan_guard_log "Reloading network subsystem"
            /etc/init.d/network reload >/dev/null 2>&1 || true
        fi
    fi
    if [ "$dirty_firewall" -eq 1 ]; then
        if [ -x /etc/init.d/firewall ]; then
            wan_guard_log "Reloading firewall subsystem (fw4)"
            /etc/init.d/firewall reload >/dev/null 2>&1 || true
        fi
    fi
    if [ "$dirty_dhcp" -eq 1 ]; then
        if [ -x /etc/init.d/odhcpd ]; then
            wan_guard_log "Reloading odhcpd subsystem"
            /etc/init.d/odhcpd reload >/dev/null 2>&1 || true
        fi
    fi

    if [ "$dirty_network" -eq 0 ] && [ "$dirty_dhcp" -eq 0 ] && [ "$dirty_firewall" -eq 0 ]; then
        wan_guard_log "All WAN/LAN invariants verified OK (no changes required)"
    else
        wan_guard_log "Invariants reconciled successfully"
    fi
    return 0
}

# If executed directly as a script
if [ "$(basename -- "$0")" = "wan-uplink-guard.sh" ]; then
    case "${1:-}" in
        --help|-h)
            echo "Usage: $0 [--apply|--check]"
            exit 0
            ;;
        --check)
            WAN_GUARD_SILENT=0
            echo "=== WAN Uplink Invariants Check ==="
            wan_uplink_guard_reconcile
            ;;
        *)
            WAN_GUARD_SILENT=0
            wan_uplink_guard_reconcile
            ;;
    esac
fi
