#!/bin/sh
# shellcheck shell=sh
# USB power-cycle с миганием red:fault <-> blue:wan (0.5 с) и ожиданием интернета (SETTLE_SEC).
# Используется cron-watch и ручным пунктом меню.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
export USB_WATCH_ROOT_DIR="$ROOT_DIR"
. "$SCRIPT_DIR/usb-power-watch-lib.sh"
. "$SCRIPT_DIR/usb-power-lib.sh"
. "$ROOT_DIR/lib/led/led-lib.sh"
. "$SCRIPT_DIR/lib-board.sh"

usb_watch_load_config

off_sec="${1:-$USB_WATCH_OFF_SEC}"
on_sec="${2:-$USB_WATCH_ON_SEC}"
do_wait="${3:-1}"

case "$off_sec" in ''|*[!0-9]*) off_sec="${USB_WATCH_OFF_SEC:-8}" ;; esac
case "$on_sec" in ''|*[!0-9]*) on_sec="${USB_WATCH_ON_SEC:-5}" ;; esac

led_blink=0
if hardware_led_modem_cycle_blink_start 2>/dev/null; then
    led_blink=1
    usb_watch_log_line "LED: blink ${HARDWARE_LED_MODEM_BLINK_A} <-> ${HARDWARE_LED_MODEM_BLINK_B} (0.5s)"
else
    usb_watch_log_line "LED: blink skipped (no red:fault/blue:wan in sysfs)"
fi

_cycle_ok=0
if usb_power_cycle "$off_sec" "$on_sec" auto; then
    _cycle_ok=1
fi

if [ "$led_blink" = "1" ]; then
    if [ "$_cycle_ok" = "1" ] && [ "$do_wait" = "1" ]; then
        usb_watch_wait_internet_after_cycle || true
    fi
    hardware_led_modem_cycle_blink_stop || true
fi

if [ "$_cycle_ok" = "1" ]; then
    exit 0
fi
usb_watch_log_line "cycle FAILED: ${USB_POWER_LAST_ERROR:-?}"
exit 1
