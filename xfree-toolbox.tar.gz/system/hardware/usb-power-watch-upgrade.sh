#!/bin/sh
# shellcheck shell=sh
# Явная миграция usb-power-watch при установке/обновлении toolbox.
#
# Usage:
#   usb-power-watch-upgrade.sh --on-deploy [ROOT_DIR]
#   usb-power-watch-upgrade.sh --migrate-conf [ROOT_DIR]
#
# --on-deploy:
#   1) если в crontab есть старый hook watch — снять (без ENABLED=0 / LED)
#   2) мигрировать usb-power-watch.conf (дописать новые ключи)
#   3) если hook был — поставить cron заново на новом коде

set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd -P)"
MODE="on-deploy"
QUIET=0

usage() {
    cat <<EOF
Usage: $(basename "$0") --on-deploy|--migrate-conf [ROOT_DIR]

  --on-deploy     suspend cron hook → migrate conf → reinstall cron if was active
  --migrate-conf  только migrate conf/state keys (без crontab)
  --quiet         без сообщений в stdout
EOF
}

log_line() {
    [ "$QUIET" = "1" ] || printf '%s\n' "$*"
}

while [ $# -gt 0 ]; do
    case "$1" in
        --on-deploy|--migrate-conf)
            MODE="${1#--}"
            shift
            ;;
        --quiet)
            QUIET=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            ROOT_DIR="$(CDPATH= cd -- "$1" && pwd -P)"
            shift
            ;;
    esac
done

# shellcheck disable=SC1091
. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"
export USB_WATCH_ROOT_DIR="$ROOT_DIR"
export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/usb-power-watch-lib.sh"

migrate_conf_only() {
    usb_watch_conf_migrate_only
}

on_deploy() {
    _had_hook=0
    if usb_watch_crontab_has_watch_job; then
        _had_hook=1
        log_line "[*] usb-watch upgrade: снимаем cron-hook на время миграции"
        usb_watch_crontab_suspend_watch || log_line "[!] usb-watch upgrade: не удалось снять cron (продолжаем migrate)"
    fi

    migrate_conf_only
    log_line "[+] usb-watch upgrade: conf мигрирован ($(usb_watch_conf_path))"

    if [ "$_had_hook" = "1" ]; then
        log_line "[*] usb-watch upgrade: восстанавливаем cron (только строка в crontab)"
        if usb_watch_crontab_restore_watch_job; then
            log_line "[+] usb-watch upgrade: cron восстановлен"
        else
            log_line "[!] usb-watch upgrade: cron restore не удался — Мониторинг канала → Включить периодическую проверку канала"
        fi
    fi
    return 0
}

case "$MODE" in
    on-deploy) on_deploy ;;
    migrate-conf) migrate_conf_only ;;
    *)
        usage >&2
        exit 2
        ;;
esac
