#!/bin/sh
# shellcheck shell=sh
# Alias for usb-power-watch-lib.sh (connectivity / uplink monitor).
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/usb-power-watch-lib.sh"
