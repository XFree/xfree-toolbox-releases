#!/bin/sh
# Снимок температуры (thermal/hwmon) и занятости ФС для UI/CLI.
# Usage: show-host-resources.sh [--out FILE]
# shellcheck shell=sh
set -eu

OUT_FILE=""
while [ $# -gt 0 ]; do
    case "$1" in
        --out)
            shift
            OUT_FILE="${1:-}"
            [ -n "$OUT_FILE" ] || {
                echo "show-host-resources: --out requires a path" >&2
                exit 1
            }
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--out FILE]"
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            exit 1
            ;;
    esac
done

# width of ASCII fill bar (0–100 %)
BAR_WIDTH=22

ui_bar_filled() {
    pct="$1"
    case "$pct" in
        ''|*[!0-9]*) pct=0 ;;
    esac
    [ "$pct" -gt 100 ] 2>/dev/null && pct=100
    [ "$pct" -lt 0 ] 2>/dev/null && pct=0
    filled=$((pct * BAR_WIDTH / 100))
    empty=$((BAR_WIDTH - filled))
    bar=""
    i=0
    while [ "$i" -lt "$filled" ]; do
        bar="${bar}█"
        i=$((i + 1))
    done
    i=0
    while [ "$i" -lt "$empty" ]; do
        bar="${bar}░"
        i=$((i + 1))
    done
    printf '%s' "$bar"
}

# sysfs: temp в миллиградусах Цельсия (68900 = 68.9 °C)
temp_level_label() {
    millideg="$1"
    case "$millideg" in
        ''|*[!0-9]*) printf '%s' "нет данных" ;;
        *)
            if [ "$millideg" -lt 75000 ]; then
                printf '%s' "норма"
            elif [ "$millideg" -lt 85000 ]; then
                printf '%s' "тепло"
            else
                printf '%s' "критично"
            fi
            ;;
    esac
}

temp_marker() {
    millideg="$1"
    case "$millideg" in
        ''|*[!0-9]*) printf '%s' " ? " ;;
        *)
            if [ "$millideg" -lt 75000 ]; then
                printf '%s' " ● "
            elif [ "$millideg" -lt 85000 ]; then
                printf '%s' " ▲ "
            else
                printf '%s' " !! "
            fi
            ;;
    esac
}

format_temp_c() {
    millideg="$1"
    case "$millideg" in
        ''|*[!0-9-]*) printf '%s' "—" ;;
        *)
            if [ "$millideg" -lt 0 ] 2>/dev/null; then
                printf '%s' "—"
                return
            fi
            awk -v m="$millideg" 'BEGIN { printf "%.1f", m / 1000 }'
            ;;
    esac
}

collect_thermal_lines() {
    found=0
    if [ -d /sys/class/thermal ]; then
        for tz in /sys/class/thermal/thermal_zone*; do
            [ -d "$tz" ] || continue
            found=1
            name="$(cat "$tz/type" 2>/dev/null | tr -d '\r\n' || true)"
            [ -n "$name" ] || name="$(basename "$tz")"
            raw="$(cat "$tz/temp" 2>/dev/null | tr -d '\r\n ' || true)"
            c="$(format_temp_c "$raw")"
            marker="$(temp_marker "$raw")"
            level="$(temp_level_label "$raw")"
            printf '%s %6s °C  %-22s  %s\n' "$marker" "$c" "$name" "$level"
        done
    fi

    if [ -d /sys/class/hwmon ]; then
        for chip in /sys/class/hwmon/hwmon*; do
            [ -d "$chip" ] || continue
            chip_name="$(cat "$chip/name" 2>/dev/null | tr -d '\r\n' || true)"
            [ -n "$chip_name" ] || chip_name="$(basename "$chip")"
            for temp_f in "$chip"/temp*_input; do
                [ -f "$temp_f" ] || continue
                found=1
                label="$chip_name"
                base="${temp_f##*/}"
                suffix="${base%_input}"
                if [ -f "$chip/${suffix}_label" ]; then
                    extra="$(cat "$chip/${suffix}_label" 2>/dev/null | tr -d '\r\n' || true)"
                    [ -n "$extra" ] && label="${chip_name}:${extra}"
                fi
                raw="$(cat "$temp_f" 2>/dev/null | tr -d '\r\n ' || true)"
                c="$(format_temp_c "$raw")"
                marker="$(temp_marker "$raw")"
                level="$(temp_level_label "$raw")"
                printf '%s %6s °C  %-22s  %s\n' "$marker" "$c" "$label" "$level"
            done
        done
    fi

    [ "$found" -eq 1 ] && return 0

    printf '%s\n' "  (датчики не найдены: нет /sys/class/thermal и hwmon)"
    printf '%s\n' "  Подсказка: на части устройств температура доступна только в LuCI или через sensors."
    return 0
}

human_kib() {
    kib="$1"
    case "$kib" in
        ''|*[!0-9]*) printf '%s' "—" ;;
        *)
            if [ "$kib" -ge 1048576 ] 2>/dev/null; then
                awk -v k="$kib" 'BEGIN { printf "%.2f GiB", k / 1048576 }'
            elif [ "$kib" -ge 1024 ] 2>/dev/null; then
                awk -v k="$kib" 'BEGIN { printf "%.2f MiB", k / 1024 }'
            else
                printf '%s KiB' "$kib"
            fi
            ;;
    esac
}

capture_df_table() {
    out_file="$1"
    if df -kP >"$out_file" 2>/dev/null && [ -s "$out_file" ]; then
        return 0
    fi
    if df -k >"$out_file" 2>/dev/null && [ -s "$out_file" ]; then
        return 0
    fi
    : >"$out_file"
    return 1
}

print_disk_row() {
    fs="$1"
    total_k="$2"
    used_k="$3"
    avail_k="$4"
    pct_raw="$5"
    mount="$6"

    pct="${pct_raw%%%}"
    case "$pct" in
        ''|*[!0-9]*) pct=0 ;;
    esac

    bar="$(ui_bar_filled "$pct")"
    total_h="$(human_kib "$total_k")"
    used_h="$(human_kib "$used_k")"
    avail_h="$(human_kib "$avail_k")"

    printf '\n'
    printf '  %-12s  %3s%%  [%s]\n' "$mount" "$pct" "$bar"
    printf '  %-12s  занято %s  ·  свободно %s  ·  всего %s\n' "" "$used_h" "$avail_h" "$total_h"
    printf '  %-12s  %s\n' "" "$fs"
}

collect_disk_lines() {
    df_lines="${TMPDIR:-/tmp}/xfree-df-lines.$$"
    df_all="${TMPDIR:-/tmp}/xfree-df-all.$$"

    if ! capture_df_table "$df_all"; then
        printf '%s\n' "  (df недоступен)"
        rm -f "$df_all" "$df_lines" 2>/dev/null || true
        return 0
    fi

    awk '
        NR == 1 { next }
        {
            mount = $NF
            pct = $(NF - 1)
            gsub(/%/, "", pct)
            fs = $1
            total = $2
            used = $3
            avail = $4
            if (fs ~ /^\/dev\// || fs ~ /^\/dev\/mapper\// || fs ~ /^\/dev\/ubiblock/ \
                || mount == "/" || mount ~ /^\/overlay/ || mount ~ /^\/mnt\//) {
                print fs, total, used, avail, pct "%", mount
            }
        }
    ' "$df_all" >"$df_lines"

    if [ ! -s "$df_lines" ]; then
        awk '
            NR == 1 { next }
            {
                mount = $NF
                pct = $(NF - 1)
                gsub(/%/, "", pct)
                print $1, $2, $3, $4, pct "%", mount
            }
        ' "$df_all" >"$df_lines"
        printf '%s\n' "  (нет типичных разделов — показан полный список df)"
    fi

    while IFS= read -r line; do
        set -- $line
        print_disk_row "$1" "$2" "$3" "$4" "$5" "$6"
    done <"$df_lines"

    rm -f "$df_all" "$df_lines" 2>/dev/null || true
    return 0
}

emit_report() {
    host="$(uname -n 2>/dev/null || hostname 2>/dev/null || printf '%s' "?")"
    now="$(date '+%Y-%m-%d %H:%M:%S %Z' 2>/dev/null || date 2>/dev/null || true)"
    uptime_line="$(uptime 2>/dev/null | sed 's/^[[:space:]]*//' || true)"

    printf '%s\n' "══════════════════════════════════════════════════════════"
    printf '%s\n' "  Состояние устройства"
    printf '%s\n' "══════════════════════════════════════════════════════════"
    printf '\n'
    printf '  Хост: %s\n' "$host"
    [ -n "${now:-}" ] && printf '  Время: %s\n' "$now"
    [ -n "${uptime_line:-}" ] && printf '  %s\n' "$uptime_line"
    printf '\n'
    printf '%s\n' "──────────────────────────────────────────────────────────"
    printf '%s\n' "  ТЕМПЕРАТУРА"
    printf '%s\n' "  ● норма (<75°C)   ▲ тепло   !! критично (≥85°C)"
    printf '%s\n' "──────────────────────────────────────────────────────────"
    collect_thermal_lines
    printf '\n'
    printf '%s\n' "──────────────────────────────────────────────────────────"
    printf '%s\n' "  ДИСК (занято / свободно)"
    printf '%s\n' "  [████…] — доля занятого тома"
    printf '%s\n' "──────────────────────────────────────────────────────────"
    collect_disk_lines
    printf '\n'
    printf '%s\n' "══════════════════════════════════════════════════════════"
    printf '%s\n' "  Обновить: снова выберите этот пункт в меню «Система»."
    printf '%s\n' "══════════════════════════════════════════════════════════"
}

if [ -n "$OUT_FILE" ]; then
    emit_report >"$OUT_FILE"
else
    emit_report
fi
