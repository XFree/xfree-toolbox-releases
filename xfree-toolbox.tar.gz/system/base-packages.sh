#!/bin/sh
# shellcheck shell=sh

# Обязательные для ensure-base-packages / apply-template.
# drill — luci-app-ddns TCP DNS; busybox nslookup TCP не умеет (альтернативы bind-host/knot-host крупнее).
# ca-certificates — логический слот CA; фактическое имя: opkg→ca-bundle, apk→ca-certificates
# (см. base_packages_ca_pkg / base_packages_resolve_pkg — ветка PM).
BASE_PACKAGES_REQUIRED="
ip-tiny
curl
ca-certificates
whiptail
jq
jsonfilter
drill
"

# Ставим при install.sh, но отсутствие не блокирует ensure-base-packages
# (24.x/25.x: busybox install/base64/diff/unzip вместо coreutils/unzip; vi вместо nano; UPnP — luci-app-upnp или miniupnpd).
BASE_PACKAGES_OPTIONAL="
unzip
nano
diffutils
coreutils-base64
coreutils-install
coreutils-sha512sum
luci-app-upnp
"

# install.sh: полный bulk (required + optional).
BASE_PACKAGES="$BASE_PACKAGES_REQUIRED $BASE_PACKAGES_OPTIONAL"

# Замена через ensure_* в install.sh (dnsmasq→dnsmasq-full).
# wpad-mesh-mbedtls — отдельно: system/install-wpad-mesh.sh (меню Система).
# Не добавлять в bulk: apk world конфликтует с заводским wpad-basic-mbedtls / dnsmasq.
INSTALL_ENSURE_PACKAGES="
dnsmasq-full
"
