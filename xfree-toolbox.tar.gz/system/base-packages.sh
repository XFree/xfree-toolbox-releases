#!/bin/sh
# shellcheck shell=sh

# Обязательные для ensure-base-packages / apply-template.
# drill — luci-app-ddns TCP DNS; busybox nslookup TCP не умеет (альтернативы bind-host/knot-host крупнее).
BASE_PACKAGES_REQUIRED="
ip-tiny
curl
ca-certificates
unzip
whiptail
jq
jsonfilter
nano
diffutils
coreutils-base64
coreutils-sha512sum
drill
"

# Ставим при install.sh, но отсутствие не блокирует ensure-base-packages
# (24.x: busybox install вместо coreutils-install; UPnP — luci-app-upnp или miniupnpd).
BASE_PACKAGES_OPTIONAL="
coreutils-install
luci-app-upnp
"

# install.sh: полный bulk (required + optional).
BASE_PACKAGES="$BASE_PACKAGES_REQUIRED $BASE_PACKAGES_OPTIONAL"

# Замена через ensure_* в install.sh (dnsmasq→dnsmasq-full).
# wpad-mesh-mbedtls — отдельно: system/install-wpad-mesh.sh (меню Система).
# Не добавлять в bulk: apk world конфликтует с заводским wpad-basic-mbedtls / dnsmasq.
INSTALL_ENSURE_PACKAGES="
dnsmasq-full
"
