#!/bin/sh
# shellcheck shell=sh
# Опционально: wpad-basic* → wpad-mesh-mbedtls (802.11s). НЕ часть ensure-base-packages.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"

TARGET=wpad-mesh-mbedtls
YES=0
SILENT=0

usage() {
  cat <<USAGE
Usage: install-wpad-mesh.sh [--yes] [--silent]

Замена wpad-basic* → wpad-mesh-mbedtls (802.11s mesh).
Отдельно от базовых пакетов: возможен обрыв Wi-Fi uplink; при сбое — откат из apk fetch.
После успешной замены — reboot (network restart radio не поднимает).

  --yes     без доп. подтверждения в скрипте (меню спрашивает отдельно)
  --silent  меньше сообщений
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --silent) SILENT=1 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный параметр: $1" ;;
  esac
  shift
done

pm_print

# SSH по Wi-Fi обрывается при замене wpad; HUP не должен рвать apk до reboot.
trap '' HUP

if [ "${XFREE_BG_TASK:-0}" = "1" ]; then
  die "wpad-mesh: не запускать в фоновой задаче (WPS sync / uplink)"
fi

if pm_is_installed "$TARGET"; then
  info "$TARGET уже установлен"
  exit 0
fi

old_pkgs="$(pm_list_installed_names | grep -E '^wpad-' | grep -vFx "$TARGET" || true)"
if [ -z "${old_pkgs:-}" ]; then
  die "Нет установленного wpad — Wi-Fi пакеты отсутствуют на образе"
fi

rollback_pkg="$(printf '%s\n' "$old_pkgs" | sed -n '1p')"
[ -n "$rollback_pkg" ] || die "Не удалось определить пакет для отката"

warn "Замена wpad → $TARGET. Откат при сбое: $rollback_pkg"

case "$PM" in
  apk)
    pm_apk_preflight_repository \
      || die "Репозиторий apk недоступен. sh $ROOT_DIR/system/recover-apk-network.sh --full"
    # shellcheck disable=SC2086
    pm_apk_prepare_exclusive_world "$TARGET" $old_pkgs
    ;;
  opkg)
    pm_update_index_optional
    ;;
esac

_fetch_dir="$(mktemp -d /tmp/xfree-wpad-fetch.XXXXXX)"
_fetch_list="${TMPDIR:-/tmp}/xfree-wpad-fetch-list.$$"
_apk_log="${TMPDIR:-/tmp}/xfree-wpad-install.$$"

wpad_mesh_cleanup() {
  rm -f "$_fetch_list" "$_apk_log"
  rm -rf "$_fetch_dir"
}
trap wpad_mesh_cleanup EXIT INT TERM

: >"$_fetch_list"
case "$PM" in
  apk)
    pm_apk_collect_fetch_package_names "$TARGET" "$_fetch_list"
    grep -Fxq hostapd-common "$_fetch_list" 2>/dev/null \
      || printf '%s\n' hostapd-common >>"$_fetch_list"
    printf '%s\n' "$rollback_pkg" >>"$_fetch_list"
    sort -u "$_fetch_list" -o "$_fetch_list"
    info "Скачиваю пакеты (apk fetch): $(tr '\n' ' ' <"$_fetch_list")"
    # shellcheck disable=SC2046
    pm_apk_fetch_packages "$_fetch_dir" $(cat "$_fetch_list") \
      || die "apk fetch не удался — проверьте сеть"
    ;;
  opkg)
    printf '%s\n' "$TARGET" "$rollback_pkg" >>"$_fetch_list"
    info "Скачиваю $TARGET и $rollback_pkg (opkg download)"
    pm_download "$TARGET" "$_fetch_dir" || die "opkg download $TARGET не удался"
    pm_download "$rollback_pkg" "$_fetch_dir" || die "opkg download $rollback_pkg не удался"
    ;;
esac

wpad_mesh_build_install_files() {
  _out="$1"
  : >"$_out"
  case "$PM" in
    apk)
      while read -r _pkg; do
        [ -n "$_pkg" ] || continue
        [ "$_pkg" = "$rollback_pkg" ] && continue
        _f="$(pm_apk_find_fetched_file "$_fetch_dir" "$_pkg" || true)"
        [ -n "${_f:-}" ] || continue
        printf '%s\n' "$_f" >>"$_out"
      done <<EOF
$(cat "$_fetch_list")
EOF
      ;;
    opkg)
      _f="$(ls "$_fetch_dir"/"${TARGET}"*.ipk 2>/dev/null | sed -n '1p')"
      [ -n "${_f:-}" ] && printf '%s\n' "$_f" >>"$_out"
      ;;
  esac
}

wpad_mesh_try_install_local() {
  _list="$(mktemp "${TMPDIR:-/tmp}/xfree-wpad-install-list.XXXXXX")"
  wpad_mesh_build_install_files "$_list"
  if [ ! -s "$_list" ]; then
    warn "нет локальных apk/ipk для $TARGET в $_fetch_dir"
    ls -la "$_fetch_dir" 2>/dev/null || true
    rm -f "$_list"
    return 1
  fi
  info "Устанавливаю $TARGET из локальных пакетов"
  case "$PM" in
    apk)
      _args=""
      while read -r _f; do
        [ -n "$_f" ] || continue
        _args="$_args $_f"
      done <"$_list"
      rm -f "$_list"
      # shellcheck disable=SC2086
      pm_apk_add_files_logged "$_apk_log" $_args
      ;;
    opkg)
      _ipk="$(sed -n '1p' "$_list")"
      rm -f "$_list"
      pm_install_file "$_ipk"
      ;;
  esac
}

wpad_mesh_rollback_local() {
  case "$PM" in
    apk)
      pm_apk_scrub_stale_world_package "$TARGET"
      _rb="$(pm_apk_find_fetched_file "$_fetch_dir" "$rollback_pkg" || true)"
      [ -n "${_rb:-}" ] || return 1
      warn "Откат: $rollback_pkg из локального apk"
      pm_apk_add_files_logged "$_apk_log" "$_rb"
      ;;
    opkg)
      _rb="$(ls "$_fetch_dir"/"${rollback_pkg}"*.ipk 2>/dev/null | sed -n '1p')"
      [ -n "${_rb:-}" ] || return 1
      warn "Откат: $rollback_pkg из локального ipk"
      pm_install_file "$_rb"
      ;;
  esac
}

wpad_mesh_remove_old_wpad() {
  for _old in $old_pkgs; do
    [ -n "$_old" ] || continue
    pm_is_installed "$_old" || continue
    info "Удаляю $_old"
    pm_remove "$_old" || true
  done
}

_ok=0
if wpad_mesh_try_install_local; then
  _ok=1
elif [ "$PM" = "apk" ] && pm_apk_error_log_is_solver_failure "$_apk_log"; then
  warn "apk solver: очистка world и повтор"
  # shellcheck disable=SC2086
  pm_apk_prepare_exclusive_world "$TARGET" $old_pkgs
  if wpad_mesh_try_install_local; then
    _ok=1
  else
    wpad_mesh_remove_old_wpad
    wpad_mesh_try_install_local && _ok=1
  fi
elif [ "$PM" = "apk" ] && pm_apk_error_log_is_network_failure "$_apk_log"; then
  die "Сбой сети при установке из локальных apk (неожиданно) — sh $ROOT_DIR/system/recover-apk-network.sh --full"
else
  wpad_mesh_remove_old_wpad
  wpad_mesh_try_install_local && _ok=1
fi

if [ "$_ok" != "1" ] || ! pm_is_installed "$TARGET"; then
  warn "Установка $TARGET не удалась"
  if wpad_mesh_rollback_local && pm_is_installed "$rollback_pkg"; then
    die "$TARGET не установлен; восстановлен $rollback_pkg. Может понадобиться reboot."
  fi
  die "Откат не удался — reboot и sh $ROOT_DIR/system/recover-apk-network.sh --full"
fi

success "$TARGET установлен"

wpad_mesh_cleanup
trap - EXIT INT TERM
trap '' HUP

_pm_refresh_sh="$SCRIPT_DIR/pm-post-install-refresh.sh"
if [ -f "$_pm_refresh_sh" ]; then
  # shellcheck disable=SC1090
  . "$_pm_refresh_sh"
  # WPS --ensure, затем reboot (network restart radio не поднимает).
  pm_post_install_refresh "$ROOT_DIR" "$SILENT" 0 1
fi

exit 0
