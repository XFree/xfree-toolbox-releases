#!/bin/sh
# shellcheck shell=sh
# Normalize CRLF → LF for shell scripts and paths marked eol=lf in .gitattributes.
#
# Usage:
#   fix-crlf.sh [path ...]     directories and/or files (default: repo root)
#   fix-crlf.sh --git-staged   only git index (pre-commit)
#   fix-crlf.sh --git-changed  staged + unstaged vs HEAD (CI / run-all)
#   fix-crlf.sh --all          all tracked files that should use LF
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"

MODE="paths"
GIT_READD=0
fixed=0
checked=0

usage() {
  cat <<'EOF'
Usage: system/fix-crlf.sh [--git-staged | --git-changed | --all] [path ...]

  --git-staged   Fix staged files only; re-stage after fix (pre-commit).
  --git-changed  Fix staged and modified tracked files vs HEAD.
  --all          Fix all tracked files with eol=lf / *.sh.
  path ...       Fix under given dirs or explicit files (default: repo root).
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --git-staged)
      MODE="git-staged"
      GIT_READD=1
      shift
      ;;
    --git-changed)
      MODE="git-changed"
      shift
      ;;
    --all)
      MODE="all"
      shift
      ;;
    -h | --help)
      usage
      exit 0
      ;;
    --)
      shift
      break
      ;;
    -*)
      die "unknown option: $1"
      ;;
    *)
      break
      ;;
  esac
done

fix_crlf_should_skip_path() {
  rel="$1"
  case "$rel" in
    */.git/* | */node_modules/* | */.venv/* | */__pycache__/*) return 0 ;;
  esac
  return 1
}

fix_crlf_rel_path() {
  abs="$1"
  case "$abs" in
    "$ROOT_DIR"/*) printf '%s\n' "${abs#"$ROOT_DIR"/}" ;;
    /*) printf '%s\n' "$abs" ;;
    *) printf '%s\n' "$abs" ;;
  esac
}

fix_crlf_should_fix_rel() {
  rel="$1"
  fix_crlf_should_skip_path "$rel" && return 1

  case "$rel" in
    *.sh) return 0 ;;
    */zapret/sections/*/config/section.conf | */zapret/sections/*/config/section.text) return 0 ;;
    zapret/sections/*/config/section.conf | zapret/sections/*/config/section.text) return 0 ;;
    */dns.conf | dns.conf) return 0 ;;
  esac

  if command -v git >/dev/null 2>&1 \
    && git -C "$ROOT_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    _attr="$(git -C "$ROOT_DIR" check-attr eol -- "$rel" 2>/dev/null \
      | awk -F: '{gsub(/^[ \t]+|[ \t\r]+$/, "", $3); print $3}' \
      | head -n 1)"
    [ "$_attr" = "lf" ] && return 0
  fi

  return 1
}

fix_crlf_should_fix_abs() {
  abs="$1"
  [ -f "$abs" ] || return 1
  rel="$(fix_crlf_rel_path "$abs")"
  fix_crlf_should_fix_rel "$rel"
}

fix_crlf_file() {
  file="$1"
  rel="${2:-$(fix_crlf_rel_path "$file")}"

  [ -f "$file" ] || return 0
  checked=$((checked + 1))

  if ! awk 'sub(/\r$/, "") { found=1 } END { exit(found ? 0 : 1) }' "$file" 2>/dev/null; then
    return 0
  fi

  tmp_file="${file}.lf.$$"
  awk '{ sub(/\r$/, ""); print }' "$file" > "$tmp_file"
  mv "$tmp_file" "$file"
  chmod +x "$file" 2>/dev/null || true
  fixed=$((fixed + 1))
  info "CRLF->LF: $rel"

  if [ "$GIT_READD" -eq 1 ] && command -v git >/dev/null 2>&1; then
    git -C "$ROOT_DIR" add -- "$rel" 2>/dev/null || true
  fi
}

fix_crlf_collect_git_names() {
  _mode="$1"
  case "$_mode" in
    git-staged)
      git -C "$ROOT_DIR" diff --cached --name-only --diff-filter=ACMR 2>/dev/null || true
      ;;
    git-changed)
      {
        git -C "$ROOT_DIR" diff --cached --name-only --diff-filter=ACMR 2>/dev/null || true
        git -C "$ROOT_DIR" diff --name-only --diff-filter=ACMR 2>/dev/null || true
      } | awk '!seen[$0]++'
      ;;
    all)
      git -C "$ROOT_DIR" ls-files 2>/dev/null || true
      ;;
  esac
}

fix_crlf_collect_paths() {
  for target in "$@"; do
    [ -n "$target" ] || continue
    case "$target" in
      /*) abs="$target" ;;
      *) abs="$ROOT_DIR/$target" ;;
    esac

    if [ -d "$abs" ]; then
      find "$abs" -type f \( \
        -name '*.sh' -o \
        -name 'section.conf' -o \
        -name 'section.text' -o \
        -name 'dns.conf' \
      \) 2>/dev/null || true
      continue
    fi

    if [ -f "$abs" ]; then
      printf '%s\n' "$abs"
    fi
  done
}

case "$MODE" in
  git-staged | git-changed | all)
  command -v git >/dev/null 2>&1 \
    || die "git required for --$MODE"
  git -C "$ROOT_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1 \
    || die "not a git work tree: $ROOT_DIR"
  files="$(fix_crlf_collect_git_names "$MODE")"
  ;;
  paths)
  if [ $# -eq 0 ]; then
    set -- "$ROOT_DIR"
  fi
  files="$(fix_crlf_collect_paths "$@")"
  ;;
esac

while IFS= read -r entry; do
  [ -n "$entry" ] || continue

  case "$MODE" in
    git-staged | git-changed | all)
      rel="$entry"
      fix_crlf_should_skip_path "$rel" && continue
      fix_crlf_should_fix_rel "$rel" || continue
      abs="$ROOT_DIR/$rel"
      ;;
    *)
      abs="$entry"
      rel="$(fix_crlf_rel_path "$abs")"
      fix_crlf_should_fix_abs "$abs" || continue
      ;;
  esac

  fix_crlf_file "$abs" "$rel"
done <<EOF
$files
EOF

success "CRLF check complete: checked=$checked fixed=$fixed"
