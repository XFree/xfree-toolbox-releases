#!/bin/sh
# Запись человекочитаемого снимка состояния (версия тулбокса + окружение) в state.
# Не требует git/CI. Вызывать после деплоя или вручную: sh system/sync-runtime-status.sh
# Переменные: XFREE_TOOLBOX_ROOT, XFREE_STATE_ROOT, XFREE_RUNTIME_STATUS_FILE
# shellcheck shell=sh
set -eu

: "${XFREE_STATE_ROOT:=/etc/xfree-toolbox}"
: "${XFREE_RUNTIME_STATUS_FILE:=$XFREE_STATE_ROOT/runtime-status.env}"

root="${XFREE_TOOLBOX_ROOT:-}"
if [ -z "$root" ]; then
    root="${1:-}"
fi
if [ -z "$root" ]; then
    for d in /root/xfree-toolbox /root/xfree-utils; do
        if [ -d "$d" ] && [ -f "$d/VERSION" ]; then
            root="$d"
            break
        fi
    done
fi

if [ -z "$root" ] || [ ! -d "$root" ]; then
    printf '%s\n' "[!] sync-runtime-status: каталог тулбокса не найден (задайте XFREE_TOOLBOX_ROOT или положите VERSION в /root/xfree-toolbox)" >&2
    exit 1
fi

mkdir -p "$XFREE_STATE_ROOT"

ts_utc="$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date -u +"%Y-%m-%dT%H:%M:%SZ")"
ver=""
if [ -f "$root/VERSION" ]; then
    ver="$(head -n1 "$root/VERSION" | tr -d '\r\n\t ')"
fi

hostname_val="$(uname -n 2>/dev/null || hostname 2>/dev/null || printf '%s\n' "")"
dist_line=""
if [ -f /etc/openwrt_release ]; then
    # shellcheck disable=SC1091
    . /etc/openwrt_release 2>/dev/null || true
    dist_line="${DISTRIB_DESCRIPTION:-}${DISTRIB_DESCRIPTION:+ }${DISTRIB_RELEASE:-}"
    dist_line="$(printf '%s' "$dist_line" | tr '\r\n' '  ' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
fi

# Однострочные значения без кавычек: только печатные ASCII и обычные пробелы для глаза и grep.
sanitize_line() {
    printf '%s' "$1" | tr -cd '[:print:]' | tr '|' '/' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//'
}

ver_s="$(sanitize_line "$ver")"
host_s="$(sanitize_line "$hostname_val")"
dist_s="$(sanitize_line "$dist_line")"

profile_hint=""
if [ -f "$root/config.sh" ]; then
    profile_hint="$(grep '^XFREE_PROFILE=' "$root/config.sh" 2>/dev/null | head -n1 | sed "s/^XFREE_PROFILE=//; s/^'//; s/'$//")"
    profile_hint="$(sanitize_line "$profile_hint")"
fi

applied_hint=""
if [ -f "$XFREE_STATE_ROOT/applied-profile.env" ]; then
    applied_hint="$(sed -n 's/^XFREE_APPLIED_PROFILE=//p' "$XFREE_STATE_ROOT/applied-profile.env" 2>/dev/null | head -n1)"
    applied_hint="$(printf '%s' "$applied_hint" | sed "s/^['\"]//; s/['\"]$//")"
    applied_hint="$(sanitize_line "$applied_hint")"
fi

{
    printf '%s\n' "# xfree-toolbox runtime status (semver + окружение). Формат: KEY=value. Обновить: $root/system/sync-runtime-status.sh"
    printf '%s\n' "XFREE_STATUS_GENERATED_AT_UTC=$ts_utc"
    printf '%s\n' "XFREE_TOOLBOX_ROOT=$root"
    printf '%s\n' "XFREE_STATE_ROOT=$XFREE_STATE_ROOT"
    printf '%s\n' "XFREE_VERSION_SEMVER=$ver_s"
    printf '%s\n' "XFREE_HOSTNAME=$host_s"
    printf '%s\n' "XFREE_OPENWRT=$dist_s"
    if [ -n "$profile_hint" ]; then
        printf '%s\n' "XFREE_ACTIVE_PROFILE=$profile_hint"
    fi
    if [ -n "$applied_hint" ]; then
        printf '%s\n' "XFREE_APPLIED_PROFILE=$applied_hint"
    fi
} >"${XFREE_RUNTIME_STATUS_FILE}.tmp"
mv -f "${XFREE_RUNTIME_STATUS_FILE}.tmp" "$XFREE_RUNTIME_STATUS_FILE"

printf '%s\n' "[*] runtime-status -> $XFREE_RUNTIME_STATUS_FILE"
