#!/bin/sh
# shellcheck shell=sh
set -eu

# Developer note:
# This script is intentionally "full-state materialize only".
# It must not anonymize/scrub profile data. Any template/privacy cleanup
# belongs to local template pipeline scripts (not here).
# Layout is copied from toolbox state roots (e.g. dns-routing/state/*),
# not from generated runtime under /etc — runtime is derived from state on apply.

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/state-sync.sh"
load_base_config "$ROOT_DIR"

STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
OUTPUT_DIR=""
EXPORT_NAME=""
MODE="full"
STRICT_IFACE_EXPORT_CONTRACT=1
PROTON_SESSION_EXPORT_MODE="include"
SYSTEM_HTTPS_DNS_PROXY_FILE="${SYSTEM_HTTPS_DNS_PROXY_FILE:-/etc/config/https-dns-proxy}"

usage() {
    cat <<EOF
Usage: $(basename "$0") --output <dir> [options]

Materialize profile-like layout from applied state.

Options:
  --output <dir>      Target directory for materialized layout.
  --state-root <dir>  Source state root. Default: $STATE_ROOT
  --name <name>       Logical export/profile name for metadata. Default: active profile
  --mode <full>
                      full     Copy state as-is into profile-like layout.
  --with-proton-session
                      Keep Proton session state in exported layout.
  --without-proton-session
                      Remove Proton session state from exported layout.
  --no-strict-iface-export-contract
                      Do not fail if iface.conf exists without network.uci (restore from live state).
  -h, --help
EOF
}

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

drop_proton_sessions() {
    export_root="$1"
    rm -rf "$export_root/vpn/proton/sessions" 2>/dev/null || true
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --output)
            shift
            [ "$#" -gt 0 ] || die "--output требует путь"
            OUTPUT_DIR="$1"
            ;;
        --state-root)
            shift
            [ "$#" -gt 0 ] || die "--state-root требует путь"
            STATE_ROOT="$1"
            ;;
        --name)
            shift
            [ "$#" -gt 0 ] || die "--name требует имя"
            EXPORT_NAME="$1"
            ;;
        --mode)
            shift
            [ "$#" -gt 0 ] || die "--mode требует значение"
            MODE="$1"
            ;;
        --with-proton-session)
            PROTON_SESSION_EXPORT_MODE="include"
            ;;
        --without-proton-session)
            PROTON_SESSION_EXPORT_MODE="exclude"
            ;;
        --no-strict-iface-export-contract)
            STRICT_IFACE_EXPORT_CONTRACT=0
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift || true
done

[ -n "$OUTPUT_DIR" ] || die "Не указан --output"
[ -d "$STATE_ROOT" ] || die "State root не найден: $STATE_ROOT"

case "$MODE" in
    full) ;;
    *) die "Неизвестный режим: $MODE (поддерживается только full)" ;;
esac

case "$PROTON_SESSION_EXPORT_MODE" in
    include|exclude) ;;
    *) die "Неизвестный режим экспорта Proton session: $PROTON_SESSION_EXPORT_MODE" ;;
esac

EXPORT_NAME="${EXPORT_NAME:-$(common_active_profile_name "$ROOT_DIR")}"
EXPORT_NAME="$(sanitize_name "$EXPORT_NAME")"
[ -n "$EXPORT_NAME" ] || die "Имя export пустое"

rm -rf "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR"

state_sync_profile_iface_routing "$STATE_ROOT" "$OUTPUT_DIR"
state_sync_profile_dns_routing "$STATE_ROOT" "$OUTPUT_DIR"
state_sync_profile_https_dns_proxy "$SYSTEM_HTTPS_DNS_PROXY_FILE" "$OUTPUT_DIR"
state_sync_profile_zapret "$STATE_ROOT" "$OUTPUT_DIR"
state_sync_profile_awg_ingress "$STATE_ROOT" "$OUTPUT_DIR"
state_sync_profile_vpn "$STATE_ROOT" "$OUTPUT_DIR"
state_sync_profile_vk_turn "$STATE_ROOT" "$OUTPUT_DIR"
state_sync_validate_iface_export_contract "$OUTPUT_DIR/iface-routing/interfaces" "$STRICT_IFACE_EXPORT_CONTRACT"

{
    echo "EXPORT_KIND=router-state-profile"
    echo "EXPORT_MODE=$MODE"
    echo "EXPORT_NAME=$EXPORT_NAME"
    echo "SOURCE_STATE_ROOT=$STATE_ROOT"
    echo "PROTON_SESSION_EXPORT=$PROTON_SESSION_EXPORT_MODE"
    echo "GENERATED_AT_UTC=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date)"
} > "$OUTPUT_DIR/EXPORT-META.txt"

if [ "$PROTON_SESSION_EXPORT_MODE" = "exclude" ]; then
    drop_proton_sessions "$OUTPUT_DIR"
fi

success "Profile layout materialized from state: $OUTPUT_DIR"
