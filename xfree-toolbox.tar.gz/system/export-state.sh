#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"

MODE="full"
OUTPUT=""
PROFILE_NAME="${XFREE_PROFILE:-default}"
PROFILES_DIR="$(common_profiles_dir "$ROOT_DIR")"
PROFILE_DIR="$(common_profile_dir "$ROOT_DIR")"
STATE_ROOT="${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
DIST_EXPORTS_DIR="$ROOT_DIR/dist/exports"
MATERIALIZE_SCRIPT="$ROOT_DIR/system/materialize-profile-layout-from-state.sh"

usage() {
    cat <<EOF
Usage: $(basename "$0") [options]

Options:
  --mode <full>
  --output <path>
  -h, --help
EOF
}

sanitize_name() {
    printf '%s\n' "$1" | tr -cd 'A-Za-z0-9._-'
}

ensure_tar() {
    require_cmd tar
}

archive_dir() {
    src_parent="$1"
    src_name="$2"
    out_file="$3"

    mkdir -p "$(dirname -- "$out_file")"
    tar -czf "$out_file" -C "$src_parent" "$src_name"
}

archive_state_materialized_profile() {
    output_file="$1"
    tmp_dir="$(mktemp -d)"
    trap 'rm -rf "$tmp_dir"' EXIT HUP INT TERM

    [ -f "$MATERIALIZE_SCRIPT" ] || die "Не найден materialize script: $MATERIALIZE_SCRIPT"

    args="--state-root $(quote_sh "$STATE_ROOT") --output $(quote_sh "$tmp_dir/$PROFILE_NAME") --name $(quote_sh "$PROFILE_NAME") --mode full"

    sh -c "$(quote_sh "$MATERIALIZE_SCRIPT") $args"
    archive_dir "$tmp_dir" "$PROFILE_NAME" "$output_file"

    rm -rf "$tmp_dir"
    trap - EXIT HUP INT TERM
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --mode)
            shift
            [ "$#" -gt 0 ] || die "--mode требует значение"
            MODE="$1"
            ;;
        --output)
            shift
            [ "$#" -gt 0 ] || die "--output требует путь"
            OUTPUT="$1"
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift || true
done

PROFILE_NAME="$(sanitize_name "$PROFILE_NAME")"
[ -n "$PROFILE_NAME" ] || die "Имя профиля пустое"
PROFILE_DIR="$PROFILES_DIR/$PROFILE_NAME"

stamp="$(backup_stamp_now)"
mkdir -p "$DIST_EXPORTS_DIR"
ensure_tar

case "$MODE" in
    full) ;;
    *) die "Неизвестный режим: $MODE (поддерживается только full)" ;;
esac

[ -d "$STATE_ROOT" ] || die "State root не найден: $STATE_ROOT"
[ -n "$OUTPUT" ] || OUTPUT="$DIST_EXPORTS_DIR/${PROFILE_NAME}.full.${stamp}.tar.gz"
info "Экспортирую full profile layout из state: $STATE_ROOT"
archive_state_materialized_profile "$OUTPUT"

success "Экспорт завершён: $OUTPUT"
