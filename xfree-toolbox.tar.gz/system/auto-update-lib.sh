#!/bin/sh
# shellcheck shell=sh
# Конфиг и cron для ночного автообновления (upstream / toolbox / apply-template).

AUTO_UPDATE_CRON_MARKER='# xfree-toolbox-auto-update'

AUTO_UPDATE_MODE_UPSTREAMS_LISTS='upstreams-lists'
AUTO_UPDATE_MODE_UPSTREAMS_LISTS_PACKAGE='upstreams-lists-package'
AUTO_UPDATE_MODE_TEMPLATES_SYNC='templates-sync-apply'

auto_update_toolbox_root() {
	if [ -n "${AUTO_UPDATE_ROOT_DIR:-}" ]; then
		printf '%s\n' "$AUTO_UPDATE_ROOT_DIR"
		return 0
	fi
	if [ -n "${XFREE_TOOLBOX_ROOT:-}" ]; then
		printf '%s\n' "$XFREE_TOOLBOX_ROOT"
		return 0
	fi
	_lib_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
	CDPATH= cd -- "$_lib_dir/.." && pwd -P
}

auto_update_conf_path() {
	printf '%s/system/auto-update.conf' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

auto_update_log_path() {
	printf '%s/system/auto-update.log' "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}"
}

auto_update_conf_get() {
	file="$1"
	key="$2"
	default="${3:-}"
	[ -f "$file" ] || {
		printf '%s' "$default"
		return 0
	}
	val="$(awk -F= -v want="$key" '
		$1 == want {
			v = substr($0, index($0, "=") + 1)
			gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
			gsub(/^\047|\047$/, "", v)
			print v
			exit
		}
	' "$file" 2>/dev/null || true)"
	val="$(printf '%s' "${val:-}" | tr -d '\r')"
	[ -n "${val:-}" ] && printf '%s' "$val" || printf '%s' "$default"
}

auto_update_conf_kv_set() {
	file="$1"
	key="$2"
	value="$3"
	mkdir -p "$(dirname "$file")" 2>/dev/null || true
	tmp="${file}.tmp.$$"
	if [ -f "$file" ]; then
		awk -v key="$key" -v value="$value" '
			BEGIN { done = 0 }
			$0 ~ ("^[[:space:]]*" key "[[:space:]]*=") {
				print key "=\047" value "\047"
				done = 1
				next
			}
			{ print }
			END {
				if (!done) print key "=\047" value "\047"
			}
		' "$file" >"$tmp"
	else
		printf '%s=\047%s\047\n' "$key" "$value" >"$tmp"
	fi
	mv -f "$tmp" "$file"
}

auto_update_conf_set() {
	auto_update_conf_kv_set "$1" "$2" "$3"
}

auto_update_conf_has_key() {
	file="$1"
	key="$2"
	[ -f "$file" ] && grep -qE "^[[:space:]]*${key}[[:space:]]*=" "$file" 2>/dev/null
}

auto_update_conf_default_pairs() {
	cat <<'EOF'
MODE|upstreams-lists-package
SCHEDULE_HOUR|2
SCHEDULE_MINUTE|0
DEFAULTS_REV|1
EOF
}

auto_update_conf_migrate_missing_keys() {
	file="$(auto_update_conf_path)"
	[ -f "$file" ] || return 0
	if ! auto_update_conf_has_key "$file" DEFAULTS_REV; then
		_mode="$(auto_update_conf_get "$file" MODE "")"
		case "$_mode" in
			""|"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS")
				auto_update_conf_kv_set "$file" MODE "$AUTO_UPDATE_MODE_UPSTREAMS_LISTS_PACKAGE"
				;;
		esac
		auto_update_conf_kv_set "$file" DEFAULTS_REV 1
	fi
	auto_update_conf_default_pairs | while IFS='|' read -r _key _default; do
		[ -n "$_key" ] || continue
		auto_update_conf_has_key "$file" "$_key" && continue
		auto_update_conf_kv_set "$file" "$_key" "$_default"
	done
	auto_update_conf_has_key "$file" ENABLED || \
		auto_update_conf_kv_set "$file" ENABLED "$(auto_update_conf_enabled_default)"
}

auto_update_conf_enabled_default() {
	printf '1\n'
}

auto_update_conf_ensure() {
	file="$(auto_update_conf_path)"
	mkdir -p "$(dirname "$file")" 2>/dev/null || true
	if [ -f "$file" ]; then
		auto_update_conf_migrate_missing_keys
		return 0
	fi
	cat >"$file" <<'EOF'
# xfree-toolbox auto-update (cron, local time)
ENABLED='1'
MODE='upstreams-lists-package'
SCHEDULE_HOUR='2'
SCHEDULE_MINUTE='0'
DEFAULTS_REV='1'
EOF
}

auto_update_load_config() {
	auto_update_conf_ensure
	_cf="$(auto_update_conf_path)"
	case "$(auto_update_conf_get "$_cf" ENABLED 1)" in
		1|yes|true|on) AUTO_UPDATE_ENABLED=1 ;;
		*) AUTO_UPDATE_ENABLED=0 ;;
	esac
	AUTO_UPDATE_MODE="$(auto_update_conf_get "$_cf" MODE "$AUTO_UPDATE_MODE_UPSTREAMS_LISTS_PACKAGE")"
	AUTO_UPDATE_SCHEDULE_HOUR="$(auto_update_conf_get "$_cf" SCHEDULE_HOUR 2)"
	AUTO_UPDATE_SCHEDULE_MINUTE="$(auto_update_conf_get "$_cf" SCHEDULE_MINUTE 0)"
}

auto_update_mode_label() {
	case "${1:-}" in
		"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS")
			printf '%s' 'Списки upstream (без пакета)'
			;;
		"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS_PACKAGE")
			printf '%s' 'Списки upstream + пакет toolbox'
			;;
		"$AUTO_UPDATE_MODE_TEMPLATES_SYNC")
			printf '%s' 'Обновить и применить (как в шаблонах)'
			;;
		*)
			printf '%s' "${1:-?}"
			;;
	esac
}

# Короткие метки для заголовков меню (whiptail width).
# Документация: README.md → «Автообновление (меню Система)».
auto_update_mode_label_short() {
	case "${1:-}" in
		"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS")
			printf '%s' 'lists'
			;;
		"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS_PACKAGE")
			printf '%s' 'lists+pkg'
			;;
		"$AUTO_UPDATE_MODE_TEMPLATES_SYNC")
			printf '%s' 'tpl-sync'
			;;
		*)
			printf '%s' "${1:-?}"
			;;
	esac
}

auto_update_normalize_mode() {
	case "${1:-}" in
		"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS"|\
		"$AUTO_UPDATE_MODE_UPSTREAMS_LISTS_PACKAGE"|\
		"$AUTO_UPDATE_MODE_TEMPLATES_SYNC")
			printf '%s\n' "$1"
			return 0
			;;
		*)
			return 1
			;;
	esac
}

auto_update_normalize_schedule_part() {
	val="$1"
	min="$2"
	max="$3"
	case "$val" in
		''|*[!0-9]*) return 1 ;;
	esac
	[ "$val" -ge "$min" ] 2>/dev/null && [ "$val" -le "$max" ] 2>/dev/null || return 1
	printf '%s\n' "$val"
}

auto_update_cron_schedule_line() {
	hour="$(auto_update_normalize_schedule_part "${1:-2}" 0 23)" || return 1
	minute="$(auto_update_normalize_schedule_part "${2:-0}" 0 59)" || return 1
	printf '%s %s * * *\n' "$minute" "$hour"
}

# Полная команда cron: bg-task-run (lock/LED/meta) → auto-update-run.sh.
# Лог: auto_update_log_path (permanent; виден в меню логов toolbox).
auto_update_cron_job_command() {
	_root="${1:-}"
	_log="${2:-}"
	[ -n "$_root" ] || _root="$(auto_update_toolbox_root)"
	[ -n "$_log" ] || _log="$(auto_update_log_path)"
	_bg="$_root/lib/bg-task-run.sh"
	_run="$_root/system/auto-update-run.sh"
	[ -f "$_bg" ] || return 1
	[ -f "$_run" ] || return 1
	printf '/bin/sh %s auto-update --log %s -- /bin/sh %s\n' "$_bg" "$_log" "$_run"
}

auto_update_crontab_read() {
	if [ -r /etc/crontabs/root ]; then
		cat /etc/crontabs/root
		return 0
	fi
	_root="$(auto_update_toolbox_root 2>/dev/null || true)"
	if [ -n "$_root" ] && [ -f "$_root/lib/cmd-timeout.sh" ]; then
		# shellcheck disable=SC1091
		. "$_root/lib/cmd-timeout.sh"
		cmd_timeout 5 crontab -l 2>/dev/null || true
		return 0
	fi
	crontab -l 2>/dev/null || true
}

auto_update_crontab_has_job() {
	_ct="$(auto_update_crontab_read)"
	printf '%s\n' "$_ct" | grep -qF "$AUTO_UPDATE_CRON_MARKER" || \
		printf '%s\n' "$_ct" | grep -qF 'auto-update-run.sh'
}

auto_update_cron_installed() {
	auto_update_crontab_has_job
}

auto_update_crontab_filter_to_file() {
	_dest="$1"
	: >"$_dest"
	auto_update_crontab_read | grep -vF "$AUTO_UPDATE_CRON_MARKER" | \
		grep -vF 'auto-update-run.sh' >>"$_dest" || true
}

auto_update_crontab_apply_file() {
	_src="$1"
	[ -f "$_src" ] || return 1
	if [ -d /etc/crontabs ] 2>/dev/null; then
		mkdir -p /etc/crontabs 2>/dev/null || true
		cp "$_src" /etc/crontabs/root
		/etc/init.d/cron enabled 2>/dev/null && /etc/init.d/cron restart >/dev/null 2>&1 || true
		return 0
	fi
	crontab "$_src"
}

auto_update_cron_install() {
	_root="$(auto_update_toolbox_root)"
	auto_update_load_config
	_run="$_root/system/auto-update-run.sh"
	_bg="$_root/lib/bg-task-run.sh"
	[ -f "$_run" ] || return 1
	[ -f "$_bg" ] || return 1
	[ -x "$_run" ] || chmod +x "$_run" 2>/dev/null || true
	[ -x "$_bg" ] || chmod +x "$_bg" 2>/dev/null || true

	_body="$(auto_update_cron_schedule_line "$AUTO_UPDATE_SCHEDULE_HOUR" "$AUTO_UPDATE_SCHEDULE_MINUTE")" || return 1
	_log="$(auto_update_log_path)"
	_job="$(auto_update_cron_job_command "$_root" "$_log")" || return 1
	mkdir -p "$(dirname "$_log")" 2>/dev/null || true

	_tmp="$(mktemp 2>/dev/null || echo /tmp/auto-update-cron.$$)"
	auto_update_crontab_filter_to_file "$_tmp"
	{
		cat "$_tmp"
		printf '%s\n' "$AUTO_UPDATE_CRON_MARKER"
		# Без >> в тот же log: bg-task-run сам пишет в --log (truncate на старте = последний прогон).
		printf '%s %s\n' "$_body" "$_job"
	} >"${_tmp}.new"
	if ! auto_update_crontab_apply_file "${_tmp}.new"; then
		rm -f "$_tmp" "${_tmp}.new"
		return 1
	fi
	rm -f "$_tmp" "${_tmp}.new"
	auto_update_conf_kv_set "$(auto_update_conf_path)" ENABLED 1
	return 0
}

# После apply-template: ENABLED=1 + cron. Идемпотентно, если cron уже есть.
auto_update_enable_default() {
	auto_update_conf_ensure
	auto_update_conf_kv_set "$(auto_update_conf_path)" ENABLED 1
	auto_update_load_config

	if auto_update_cron_installed; then
		return 0
	fi
	auto_update_cron_install
}

auto_update_cron_remove() {
	_tmp="$(mktemp 2>/dev/null || echo /tmp/auto-update-cron-rm.$$)"
	auto_update_crontab_filter_to_file "$_tmp"
	if ! auto_update_crontab_apply_file "$_tmp"; then
		rm -f "$_tmp"
		return 1
	fi
	rm -f "$_tmp"
	auto_update_conf_kv_set "$(auto_update_conf_path)" ENABLED 0
	return 0
}

auto_update_status_text() {
	auto_update_load_config
	printf 'ENABLED=%s\n' "$AUTO_UPDATE_ENABLED"
	printf 'MODE=%s (%s)\n' "$AUTO_UPDATE_MODE" "$(auto_update_mode_label "$AUTO_UPDATE_MODE")"
	printf 'SCHEDULE=%02d:%02d (local)\n' "$AUTO_UPDATE_SCHEDULE_HOUR" "$AUTO_UPDATE_SCHEDULE_MINUTE"
	if auto_update_cron_installed; then
		printf 'cron=installed\n'
	else
		printf 'cron=not installed\n'
	fi
	printf 'conf=%s\n' "$(auto_update_conf_path)"
	printf 'log=%s\n' "$(auto_update_log_path)"
}
