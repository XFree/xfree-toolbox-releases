#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
scp "${SCP_OPTS[@]}" \
  system/backup-maintenance.sh \
  system/menu.handlers.sh \
  "$SSH_TARGET:$TB/system/"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
TB=/root/xfree-toolbox
echo "=== purge preview ==="
sh "$TB/system/backup-maintenance.sh" --action purge --preview
echo
echo "=== purge apply ==="
sh "$TB/system/backup-maintenance.sh" --action purge --apply
echo
echo "=== after ==="
ls -lah /root/ | grep -E 'xfree-toolbox' || true
df -h /overlay /
REMOTE
