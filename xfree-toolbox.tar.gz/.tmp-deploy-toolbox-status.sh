#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
BASE=build/openwrt/luci-app-xfree-toolbox/htdocs/luci-static/resources
ACL=build/openwrt/luci-app-xfree-toolbox/root/usr/share/rpcd/acl.d/luci-app-xfree-toolbox.json
scp "${SCP_OPTS[@]}" \
  system/toolbox-status.sh \
  system/luci-rpc.sh \
  "$SSH_TARGET:$TB/system/"
scp "${SCP_OPTS[@]}" \
  build/openwrt/xfree-toolbox/files/usr/libexec/rpcd/xfree-toolbox \
  "$SSH_TARGET:/usr/libexec/rpcd/xfree-toolbox"
scp "${SCP_OPTS[@]}" "$ACL" \
  "$SSH_TARGET:/usr/share/rpcd/acl.d/luci-app-xfree-toolbox.json"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/luci-routes.js" \
  "$BASE/xfree-toolbox/luci-ui.js" \
  "$SSH_TARGET:/www/luci-static/resources/xfree-toolbox/"
scp "${SCP_OPTS[@]}" \
  "$BASE/view/xfree-toolbox/shell.js" \
  "$SSH_TARGET:/www/luci-static/resources/view/xfree-toolbox/shell.js"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
chmod +x /root/xfree-toolbox/system/toolbox-status.sh \
  /root/xfree-toolbox/system/luci-rpc.sh \
  /usr/libexec/rpcd/xfree-toolbox
chmod 644 /usr/share/rpcd/acl.d/luci-app-xfree-toolbox.json \
  /www/luci-static/resources/xfree-toolbox/luci-routes.js \
  /www/luci-static/resources/xfree-toolbox/luci-ui.js \
  /www/luci-static/resources/view/xfree-toolbox/shell.js
/etc/init.d/rpcd reload 2>/dev/null || true
sh /root/xfree-toolbox/system/toolbox-status.sh --status | head -20
ubus -v list xfree-toolbox 2>/dev/null | grep -E 'systemMenu|report' || true
grep -n "v=20261004o\|system.toolbox\|systemMenu\|TOOLBOX_VERSION" \
  /www/luci-static/resources/view/xfree-toolbox/shell.js \
  /usr/libexec/rpcd/xfree-toolbox | head -20
REMOTE
