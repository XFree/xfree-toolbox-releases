#!/bin/sh
# shellcheck shell=sh
# Управление сервисом https-dns-proxy (OpenWrt init.d).
# init.d restart часто возвращает ненулевой exit code при успешном старте (✓ в stdout;
# см. logread -e https-dns-proxy). Не полагаться на exit code init.d — ждать running.

: "${HTTPS_DNS_PROXY_INITD_SCRIPT:=/etc/init.d/https-dns-proxy}"
: "${HTTPS_DNS_PROXY_READY_TIMEOUT:=20}"

https_dns_proxy_initd_script() {
  printf '%s\n' "$HTTPS_DNS_PROXY_INITD_SCRIPT"
}

https_dns_proxy_service_is_running() {
  init_script="$(https_dns_proxy_initd_script)"
  [ -x "$init_script" ] || return 1
  "$init_script" running >/dev/null 2>&1 || return 1
  return 0
}

# init.d restart/start часто возвращает управление до procd running.
# HTTPS_DNS_PROXY_READY_TIMEOUT — секунды (по умолчанию 20).
# running ≠ готовность DNS: после рестарта стека/apply — common_wait_network_after_restart.
https_dns_proxy_wait_running() {
  timeout="${HTTPS_DNS_PROXY_READY_TIMEOUT:-20}"
  case "$timeout" in
    '' | *[!0-9]*) timeout=20 ;;
  esac
  if https_dns_proxy_service_is_running; then
    return 0
  fi
  info "Жду https-dns-proxy running (до ${timeout}s)…"
  i=0
  while [ "$i" -lt "$timeout" ]; do
    sleep 1
    i=$((i + 1))
    if https_dns_proxy_service_is_running; then
      return 0
    fi
  done
  warn "https-dns-proxy не running после ${timeout}s"
  return 1
}

# restart | stop-start
# restart на остановленном сервисе часто no-op — тогда start.
https_dns_proxy_restart_service() {
  mode="${1:-restart}"
  init_script="$(https_dns_proxy_initd_script)"
  [ -x "$init_script" ] || return 0

  case "$mode" in
    restart)
      if https_dns_proxy_service_is_running; then
        info "Перезапускаю https-dns-proxy…"
        "$init_script" restart 2>/dev/null || true
      else
        info "https-dns-proxy не запущен — start"
        "$init_script" start 2>/dev/null || true
      fi
      ;;
    stop-start)
      "$init_script" stop 2>/dev/null || true
      sleep 1
      "$init_script" start 2>/dev/null || true
      ;;
    *)
      die "https_dns_proxy_restart_service: неподдерживаемый режим '$mode'"
      ;;
  esac
  https_dns_proxy_wait_running
}
