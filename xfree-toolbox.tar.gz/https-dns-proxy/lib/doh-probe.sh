#!/bin/sh
# shellcheck shell=sh
# Parse https-dns-proxy UCI and probe local DoH stubs (drill @127.0.0.1 -p PORT).

# UCI file → lines: listen_addr|listen_port|resolver_url
https_dns_proxy_parse_uci_instances() {
	_f="${1:-}"
	[ -n "$_f" ] && [ -f "$_f" ] || return 1
	awk '
		function unquote(s) {
			gsub(/^'\''|'\''$/, "", s)
			gsub(/^"|"$/, "", s)
			return s
		}
		function flush() {
			if (port != "") {
				if (addr == "") addr = "127.0.0.1"
				print addr "|" port "|" url
			}
			addr = ""
			port = ""
			url = ""
		}
		/^config https-dns-proxy([[:space:]]|$)/ { flush(); in_inst = 1; next }
		/^config / { if (in_inst) flush(); in_inst = 0; next }
		!in_inst { next }
		$1 == "option" && $2 == "listen_addr" { addr = unquote($3); next }
		$1 == "option" && $2 == "listen_port" { port = unquote($3); next }
		$1 == "option" && $2 == "resolver_url" { url = unquote($3); next }
		END { if (in_inst) flush() }
	' "$_f"
}

# $1=drill stdout text. stdout: rcode|msec|a  (msec/a = "-" if missing)
https_dns_proxy_drill_extract_text() {
	_txt="${1:-}"
	_rcode="$(printf '%s\n' "$_txt" | sed -n 's/.*rcode:[[:space:]]*\([A-Z0-9][A-Z0-9]*\).*/\1/p' | head -n 1)"
	_msec="$(printf '%s\n' "$_txt" | sed -n 's/.*[Qq]uery time:[[:space:]]*\([0-9][0-9]*\).*/\1/p' | head -n 1)"
	_a="$(printf '%s\n' "$_txt" | awk '$4 == "A" && $5 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ { print $5; exit }')"
	[ -n "$_rcode" ] || _rcode="?"
	[ -n "$_msec" ] || _msec="-"
	[ -n "$_a" ] || _a="-"
	printf '%s|%s|%s\n' "$_rcode" "$_msec" "$_a"
}

# $1=addr $2=port $3=qname
# stdout: OK rcode=… msec=… a=… | FAIL reason [msec=… a=…]
https_dns_proxy_drill_query_timed() {
	_addr="${1:-127.0.0.1}"
	_port="${2:-}"
	_qname="${3:-example.com}"
	_sec="${XFREE_DNS_CHECK_TIMEOUT:-4}"
	case "$_sec" in
		'' | *[!0-9]*) _sec=4 ;;
	esac
	[ -n "$_port" ] || {
		printf 'FAIL no-port msec=- a=-\n'
		return 1
	}
	if ! command -v drill >/dev/null 2>&1; then
		printf 'FAIL no-drill msec=- a=-\n'
		return 1
	fi
	_out=""
	_rc=0
	_out="$(cmd_timeout "$_sec" drill "@${_addr}" -p "$_port" "$_qname" A 2>&1)" || _rc=$?
	_out="$(printf '%s' "$_out" | tr -d '\r')"
	_parsed="$(https_dns_proxy_drill_extract_text "$_out")"
	_rcode="${_parsed%%|*}"
	_rest="${_parsed#*|}"
	_msec="${_rest%%|*}"
	_a="${_rest#*|}"
	if [ "$_rc" -eq 124 ]; then
		_ms=$((_sec * 1000))
		printf 'FAIL timeout msec=%s a=-\n' "$_ms"
		return 1
	fi
	if [ "$_rc" -ne 0 ]; then
		case "$_out" in
			*[Rr]efused* | *connection*)
				printf 'FAIL refused msec=%s a=%s\n' "$_msec" "$_a"
				return 1
				;;
		esac
		printf 'FAIL drill=%s msec=%s a=%s\n' "$_rc" "$_msec" "$_a"
		return 1
	fi
	case "$_rcode" in
		NOERROR)
			printf 'OK rcode=%s msec=%s a=%s\n' "$_rcode" "$_msec" "$_a"
			return 0
			;;
		*)
			printf 'FAIL rcode=%s msec=%s a=%s\n' "$_rcode" "$_msec" "$_a"
			return 1
			;;
	esac
}

# $1=addr $2=port $3=qname  stdout: OK rcode=… | FAIL reason
https_dns_proxy_drill_query() {
	_line=""
	_rc=0
	_line="$(https_dns_proxy_drill_query_timed "$1" "$2" "$3")" || _rc=$?
	_status="${_line%% *}"
	_rest="${_line#* }"
	_rcode_kv=""
	for _tok in $_rest; do
		case "$_tok" in
			rcode=*) _rcode_kv="$_tok" ;;
		esac
	done
	if [ "$_status" = "OK" ]; then
		printf 'OK %s\n' "${_rcode_kv:-rcode=?}"
		return 0
	fi
	case "$_rest" in
		no-port*) printf 'FAIL no-port\n' ;;
		no-drill*) printf 'FAIL no-drill\n' ;;
		timeout*) printf 'FAIL timeout\n' ;;
		refused*) printf 'FAIL refused\n' ;;
		*)
			if [ -n "$_rcode_kv" ]; then
				printf 'FAIL %s\n' "$_rcode_kv"
			else
				# drill=N / other
				printf 'FAIL %s\n' "${_rest%% msec=*}"
			fi
			;;
	esac
	return "$_rc"
}

# $1=fqdn.lst or dir of lists. Return 0 if host is listed.
https_dns_proxy_host_in_doh_list() {
	_host="${1:-}"
	_src="${2:-}"
	[ -n "$_host" ] && [ -n "$_src" ] || return 1
	_want="$(common_lower_ascii "$_host")"
	if [ -d "$_src" ]; then
		grep -RhiE '^[^#[:space:]]' "$_src"/*.lst "$_src"/*.txt 2>/dev/null \
			| tr -d '\r' | common_lower_ascii_stream | grep -Fxq "$_want"
		return $?
	fi
	[ -f "$_src" ] || return 1
	tr -d '\r' <"$_src" | common_lower_ascii_stream | grep -Fxq "$_want"
}

https_dns_proxy_filter_tcp_line() {
	_text="${1:-}"
	[ -f "$_text" ] || return 1
	grep -E '^--filter-tcp=' "$_text" | head -n 1 | tr -d '\r'
}
