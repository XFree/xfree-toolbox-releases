#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"

YES=0
FORCE=0
SILENT=0
DO_UPDATE=1

usage() {
  cat <<USAGE
Использование:
  $(common_basename) [--yes] [--force] [--silent] [--no-update]
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --force) FORCE=1 ;;
    --silent) SILENT=1 ;;
    --no-update) DO_UPDATE=0 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный параметр: $1" ;;
  esac
  shift
done

PACKAGES="
https-dns-proxy
luci-app-https-dns-proxy
"

pm_print
if [ "$DO_UPDATE" = "1" ]; then
  info "Обновление списков пакетов..."
  pm_update
fi

CHANGED=0

for pkg in $PACKAGES; do
  if pm_is_installed "$pkg" && [ "$FORCE" != "1" ]; then
    say "[=] Уже установлен: $pkg"
    continue
  fi

  if [ "$FORCE" = "1" ] && pm_is_installed "$pkg"; then
    info "Переустановка: $pkg"
  else
    info "Установка: $pkg"
  fi

  pm_install "$pkg" || die "Не удалось установить: $pkg"
  CHANGED=1
done

if [ "$CHANGED" -eq 1 ]; then
  info "Перезапуск сервисов LuCI..."
  restart_service_if_exists rpcd
  restart_service_if_exists uhttpd
  success "Сервисы LuCI перезапущены."
else
  say "[=] Изменений нет, перезапуск не требуется."
fi

success "Установка https-dns-proxy завершена."
