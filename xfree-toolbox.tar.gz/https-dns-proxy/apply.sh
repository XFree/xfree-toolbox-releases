#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib/service.sh"

INSTALL_SCRIPT="${INSTALL_SCRIPT:-$SCRIPT_DIR/install.sh}"
COPY_SCRIPT="${COPY_SCRIPT:-$SCRIPT_DIR/copy-config.sh}"

YES=0
DO_INSTALL=1
DO_COPY=1
BEST_EFFORT_INSTALL=0
RESTART=1

usage() {
  cat <<EOF
Usage: $(basename "$0") [options]

Options:
  --yes                 Non-interactive mode
  --install-only        Only install https-dns-proxy packages
  --copy-only           Only copy profile config
  --best-effort-install Do not fail whole run if install fails
  --no-restart          Do not restart https-dns-proxy service at end
  -h, --help            Show help
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --install-only) DO_COPY=0 ;;
    --copy-only) DO_INSTALL=0 ;;
    --best-effort-install) BEST_EFFORT_INSTALL=1 ;;
    --no-restart) RESTART=0 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный аргумент: $1" ;;
  esac
  shift
done

[ "$DO_INSTALL" = "1" ] || [ "$DO_COPY" = "1" ] || die "Нечего выполнять: выбраны --install-only и --copy-only одновременно"

[ -f "$INSTALL_SCRIPT" ] || die "Не найден install script: $INSTALL_SCRIPT"
[ -f "$COPY_SCRIPT" ] || die "Не найден copy-config script: $COPY_SCRIPT"

if [ "$DO_INSTALL" = "1" ]; then
  if [ "$YES" = "1" ]; then
    set -- "$INSTALL_SCRIPT" --yes
  else
    set -- "$INSTALL_SCRIPT"
  fi
  if ! sh "$@"; then
    if [ "$BEST_EFFORT_INSTALL" = "1" ]; then
      warn "Установка https-dns-proxy завершилась с ошибкой, продолжаю по best-effort."
    else
      die "Не удалось установить https-dns-proxy"
    fi
  fi
fi

if [ "$DO_COPY" = "1" ]; then
  sh "$COPY_SCRIPT" || die "Не удалось скопировать конфиг https-dns-proxy"
fi

if [ "$RESTART" = "1" ]; then
  https_dns_proxy_restart_service restart
  # running ≠ DNS: проба маршрута/uplink (канон common_wait_network_after_restart), потом дальше.
  if command -v common_wait_network_after_restart >/dev/null 2>&1; then
    common_wait_network_after_restart "${XFREE_DNS_STACK_WAIT_SEC:-${HTTPS_DNS_PROXY_READY_TIMEOUT:-20}}" || \
      warn "https-dns-proxy running, сеть ещё не готова (маршрут/uplink)"
  fi
fi

success "https-dns-proxy apply: выполнено"
