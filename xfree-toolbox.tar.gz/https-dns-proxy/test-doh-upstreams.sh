#!/bin/sh
# shellcheck shell=sh
# Probe local https-dns-proxy stubs (5060 Yandex / 5061 Quad9 / …).
# Optional A/B: zapret section dot-tls (doh-foreign, TCP 853) off then on.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/cmd-timeout.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/doh-probe.sh"
# shellcheck disable=SC1091
. "$ROOT_DIR/zapret/lib/probe-access.sh"

YES=0
DO_AB=0
NO_AB=0
PRINT_ONLY=0
FROM_FILE=""
QUERY="${XFREE_DOH_TEST_QUERY:-example.com}"
SECTION="${XFREE_DOH_TEST_SECTION:-dot-tls}"
AB_RESTORED=0
AB_SNAP=""

usage() {
	cat <<EOF
Usage: $(basename "$0") [options]

Проверка DoH-инстансов https-dns-proxy (drill на listen_port + HTTPS на resolver).
С --ab: выключить zapret/$SECTION, промерить, вернуть как было.

Options:
  --yes           без confirm
  --ab            A/B zapret секции $SECTION (выкл → замер → вкл)
  --no-ab         только текущее состояние
  --print-only    инстансы и заметки, без drill/curl
  --from-file F   UCI https-dns-proxy (шаблон), без uci на роутере
  --query HOST    DNS-запрос (default: $QUERY)
  -h, --help
EOF
}

while [ "$#" -gt 0 ]; do
	case "$1" in
		--yes) YES=1 ;;
		--ab) DO_AB=1 ;;
		--no-ab) NO_AB=1 ;;
		--print-only) PRINT_ONLY=1 ;;
		--from-file)
			[ "$#" -ge 2 ] || die "--from-file: нужен путь"
			FROM_FILE="$2"
			shift
			;;
		--query)
			[ "$#" -ge 2 ] || die "--query: нужен хост"
			QUERY="$2"
			shift
			;;
		-h | --help)
			usage
			exit 0
			;;
		*) die "Неизвестный аргумент: $1" ;;
	esac
	shift
done

[ "$NO_AB" -eq 1 ] && DO_AB=0

list_instances() {
	if [ -n "$FROM_FILE" ]; then
		https_dns_proxy_parse_uci_instances "$FROM_FILE"
		return 0
	fi
	command -v uci >/dev/null 2>&1 || die "Нет uci и не задан --from-file"
	uci show https-dns-proxy >/dev/null 2>&1 || die "нет UCI https-dns-proxy"
	for idx in $(
		uci show https-dns-proxy 2>/dev/null \
			| sed -n 's/^https-dns-proxy\.@https-dns-proxy\[\([0-9][0-9]*\)\]\.listen_port=.*/\1/p'
	); do
		base="https-dns-proxy.@https-dns-proxy[$idx]"
		url="$(uci -q get "$base.resolver_url" || true)"
		addr="$(uci -q get "$base.listen_addr" || true)"
		port="$(uci -q get "$base.listen_port" || true)"
		[ -n "$port" ] || continue
		[ -n "$addr" ] || addr="127.0.0.1"
		[ -n "$url" ] || url="https-dns-proxy-$idx"
		printf '%s|%s|%s\n' "$addr" "$port" "$url"
	done
}

print_strategy_notes() {
	_tpl="$ROOT_DIR/profile-templates/default"
	_text="$_tpl/zapret/sections/$SECTION/config/section.text"
	_lst="$_tpl/zapret/sections/$SECTION/fqdn.d/user__service__dns__doh-foreign__fqdn.lst"
	info "5060 = Яндекс DoH (common.dot.dns.yandex.net), в шаблонах DNS_REDIRECT=1 (catch-all dnsmasq)"
	info "5061 = Quad9 DoH (dns.quad9.net)"
	if [ -f "$_text" ]; then
		_flt="$(https_dns_proxy_filter_tcp_line "$_text" || true)"
		info "zapret/$SECTION: ${_flt:---filter-tcp не найден} (DoH у https-dns-proxy идёт на 443, не 853)"
	fi
	if [ -f "$_lst" ]; then
		if https_dns_proxy_host_in_doh_list "common.dot.dns.yandex.net" "$_lst"; then
			info "doh-foreign: common.dot.dns.yandex.net есть в списке"
		else
			info "doh-foreign: Яндекс DoH нет в списке (только зарубежные: Quad9, Cloudflare, …)"
		fi
		if https_dns_proxy_host_in_doh_list "dns.quad9.net" "$_lst"; then
			info "doh-foreign: dns.quad9.net есть в списке"
		fi
	fi
}

probe_https_host() {
	_host="$1"
	[ -n "$_host" ] || {
		printf 'skip\n'
		return 0
	}
	XFREE_ZAPRET_TEST_CONNECT_TIMEOUT="${XFREE_ZAPRET_TEST_CONNECT_TIMEOUT:-4}"
	XFREE_ZAPRET_TEST_MAX_TIME="${XFREE_ZAPRET_TEST_MAX_TIME:-8}"
	export XFREE_ZAPRET_TEST_CONNECT_TIMEOUT XFREE_ZAPRET_TEST_MAX_TIME
	zapret_probe_one_host "$_host" || true
}

run_probe_round() {
	_label="$1"
	printf '\n=== %s  query=%s ===\n' "$_label" "$QUERY"
	_tmp="$(mktemp)"
	list_instances >"$_tmp"
	if [ ! -s "$_tmp" ]; then
		rm -f "$_tmp"
		die "нет инстансов https-dns-proxy"
	fi
	while IFS='|' read -r addr port url; do
		[ -n "$port" ] || continue
		host="$(common_url_host "$url")"
		id="$(common_dns_id_from_url "$url")"
		if [ "$PRINT_ONLY" -eq 1 ]; then
			printf '%s#%s  %s  %s\n' "$addr" "$port" "$id" "$url"
			continue
		fi
		dns_res="$(https_dns_proxy_drill_query "$addr" "$port" "$QUERY")" || true
		https_res="$(probe_https_host "$host")"
		mark=""
		case "$port" in
			5060) mark=" [Yandex catch-all]" ;;
			5061) mark=" [Quad9]" ;;
		esac
		printf '%s#%s  %s\n  DNS   %s\n  HTTPS %s%s\n' \
			"$addr" "$port" "$id" "$dns_res" "$https_res" "$mark"
	done <"$_tmp"
	rm -f "$_tmp"
}

section_enabled_now() {
	_conf="$1"
	[ -f "$_conf" ] || return 1
	_zapret_section_enabled_quick "$_conf"
}

set_section_enabled() {
	_conf="$1"
	_val="$2"
	_tmp="${_conf}.tmp.$$"
	awk -v val="$_val" '
		BEGIN { set=0 }
		/^ZAPRET_SECTION_ENABLED=/ { print "ZAPRET_SECTION_ENABLED='\''" val "'\''"; set=1; next }
		{ print }
		END { if (set==0) print "ZAPRET_SECTION_ENABLED='\''" val "'\''" }
	' "$_conf" >"$_tmp"
	mv "$_tmp" "$_conf"
}

ab_cleanup() {
	[ "$AB_RESTORED" -eq 1 ] && return 0
	[ -n "$AB_SNAP" ] || return 0
	[ -f "$AB_CONF" ] || return 0
	warn "тест прерван — восстанавливаем $SECTION=$AB_SNAP"
	set_section_enabled "$AB_CONF" "$AB_SNAP"
	ZAPRET_RESTART_QUIET=1
	export ZAPRET_RESTART_QUIET
	zapret_apply_profile_to_runtime || true
	AB_RESTORED=1
}

print_strategy_notes

if [ "$PRINT_ONLY" -eq 1 ]; then
	run_probe_round "instances"
	exit 0
fi

if [ "$DO_AB" -eq 0 ]; then
	run_probe_round "current"
	exit 0
fi

. "$ROOT_DIR/zapret/lib.sh"

AB_CONF="$(zapret_sections_root)/$SECTION/config/section.conf"
[ -f "$AB_CONF" ] || die "нет секции zapret/$SECTION: $AB_CONF"

if section_enabled_now "$AB_CONF"; then
	AB_SNAP=1
else
	AB_SNAP=0
fi

if [ "$YES" -ne 1 ]; then
	printf 'A/B: выключить zapret/%s (сейчас ENABLED=%s), промерить, вернуть. Продолжить? [y/N] ' "$SECTION" "$AB_SNAP"
	read -r _ans || _ans=""
	case "$_ans" in
		y | Y | yes | YES) ;;
		*) die "отменено" ;;
	esac
fi

trap ab_cleanup EXIT INT TERM

run_probe_round "current (dot-tls ENABLED=$AB_SNAP)"

info "выключаю zapret/$SECTION…"
set_section_enabled "$AB_CONF" 0
ZAPRET_RESTART_QUIET=1
export ZAPRET_RESTART_QUIET
zapret_apply_profile_to_runtime
sleep 1
run_probe_round "dot-tls OFF"

info "восстанавливаю zapret/$SECTION ENABLED=$AB_SNAP…"
set_section_enabled "$AB_CONF" "$AB_SNAP"
zapret_apply_profile_to_runtime
sleep 1
run_probe_round "restored (dot-tls ENABLED=$AB_SNAP)"
AB_RESTORED=1
trap - EXIT INT TERM

success "A/B zapret/$SECTION завершён — сравните DNS/HTTPS по 5060 и 5061"
