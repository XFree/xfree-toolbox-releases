#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
COMMON_SH="$ROOT_DIR/lib/common.sh"

[ -f "$COMMON_SH" ] || {
  echo "[-] common.sh не найден: $COMMON_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
HTTPS_DNS_PROXY_PROFILE_DIR="${HTTPS_DNS_PROXY_PROFILE_DIR:-$PROFILE_DIR/https-dns-proxy}"
SRC_FILE_PROFILE="${HTTPS_DNS_PROXY_CONFIG_FILE:-$HTTPS_DNS_PROXY_PROFILE_DIR/https-dns-proxy}"
SRC_FILE_LOCAL="$SCRIPT_DIR/https-dns-proxy"
SRC_FILE_LEGACY="$ROOT_DIR/zapret/https-dns-proxy"
DST_DIR="/etc/config"
DST_FILE="$DST_DIR/https-dns-proxy"
TMP_FILE="${DST_FILE}.tmp"

cleanup() {
  rm -f "$TMP_FILE" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

if [ -f "$SRC_FILE_PROFILE" ]; then
  SRC_FILE="$SRC_FILE_PROFILE"
elif [ -f "$SRC_FILE_LOCAL" ]; then
  SRC_FILE="$SRC_FILE_LOCAL"
elif [ -f "$SRC_FILE_LEGACY" ]; then
  SRC_FILE="$SRC_FILE_LEGACY"
else
  warn "Не найден шаблон конфига. Ожидался один из файлов:"
  say "    $SRC_FILE_PROFILE"
  say "    $SRC_FILE_LOCAL"
  say "    $SRC_FILE_LEGACY"
  exit 1
fi

say "== Копирование конфига https-dns-proxy =="
info "Профиль https-dns-proxy: $HTTPS_DNS_PROXY_PROFILE_DIR"
mkdir -p "$DST_DIR"
cp -f "$SRC_FILE" "$TMP_FILE"
chmod 600 "$TMP_FILE"
mv -f "$TMP_FILE" "$DST_FILE"

success "Конфиг https-dns-proxy успешно скопирован: $DST_FILE"
