#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo '=== profile youtube_29 ==='
P=/root/xfree-toolbox/profiles/default/zapret/sections/youtube_29
ls -la "$P/config" "$P/fqdn.d" 2>&1 | head -30
cat "$P/config/section.conf" 2>&1 || true
echo 'fqdn lines:' $(wc -l <"$P/fqdn.d"/*.lst 2>/dev/null || echo 0)
grep -c 'cdn.youtube.com' "$P/fqdn.d"/*.lst 2>/dev/null || true
echo '=== state sections WITH section.conf (count) ==='
n=0
for d in /etc/xfree-toolbox/zapret/state/sections/*/config/section.conf; do
  [ -f "$d" ] || continue
  n=$((n+1))
done
echo "with_conf=$n"
echo '=== sample state with conf ==='
ls /etc/xfree-toolbox/zapret/state/sections/*/config/section.conf 2>/dev/null | head -15
echo '=== NFQWS_OPT hostlist lines ==='
uci get zapret.config.NFQWS_OPT 2>/dev/null | tr ' ' '\n' | grep -E 'hostlist|hostlist-domains|new' | head -80
echo '=== does NFQWS_OPT reference google/youtube hostfiles? ==='
uci get zapret.config.NFQWS_OPT 2>/dev/null | tr ' ' '\n' | grep -iE 'google|youtube|youtu' | head -40
echo '=== xfree-google-hosts vs zapret-hosts-google ==='
wc -l /opt/zapret/ipset/xfree-google-hosts.txt /opt/zapret/ipset/zapret-hosts-google.txt /opt/zapret/ipset/google.txt 2>&1
echo '=== generated section configs present? ==='
ls /etc/xfree-toolbox/zapret/generated/sections/youtube_29/config/ 2>&1
cat /etc/xfree-toolbox/zapret/generated/sections/youtube_29/config/section.conf 2>&1 | head -20 || true
echo '=== nft set zapret members sample ==='
nft list set inet zapret zapret 2>/dev/null | head -30 || true
REMOTE
