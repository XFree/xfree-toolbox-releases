#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS

TB=/root/xfree-toolbox
scp "${SCP_OPTS[@]}" \
  lib/selection/json.sh \
  lib/selection/upstream-selection.sh \
  lib/selection/target-zapret.sh \
  lib/selection/luci-rpc.sh \
  "$SSH_TARGET:$TB/lib/selection/"
scp "${SCP_OPTS[@]}" \
  zapret/apply-changed-sections.sh \
  zapret/luci-rpc.sh \
  "$SSH_TARGET:$TB/zapret/"
scp "${SCP_OPTS[@]}" \
  build/openwrt/xfree-toolbox/files/usr/libexec/rpcd/xfree-toolbox \
  "$SSH_TARGET:/usr/libexec/rpcd/xfree-toolbox"

ssh "${SSH_OPTS[@]}" "$SSH_TARGET" 'sh -s' <<'REMOTE'
set -eu
chmod 755 /usr/libexec/rpcd/xfree-toolbox
/etc/init.d/rpcd reload 2>/dev/null || true
sleep 1
echo "--- matrix timed (3x) ---"
for i in 1 2 3; do
  /usr/bin/time -f "real=%e sec" ubus call xfree-toolbox upstreamSelection \
    '{"action":"matrix","target":"-","scope":"-","mode":"-","tags_json":""}' \
    >/tmp/xfree-matrix-out.json 2>/tmp/xfree-matrix-time.txt || true
  cat /tmp/xfree-matrix-time.txt
  echo -n "Zapret cols: "
  jsonfilter -i /tmp/xfree-matrix-out.json -e '@.columns[@.target="zapret"].label' 2>/dev/null || true
  break
done
echo "--- files.tsv size ---"
find /tmp -name 'files.tsv' 2>/dev/null | head -5
ls -la /tmp/xfree-selection-catalog/*/files.tsv 2>/dev/null | head -5 || true
ls -la /tmp/xfree-*catalog*/files.tsv 2>/dev/null | head -5 || true
find /tmp -path '*selection*files.tsv' 2>/dev/null | head -10
wc -l "$(find /tmp -name files.tsv 2>/dev/null | head -1)" 2>/dev/null || true
REMOTE
