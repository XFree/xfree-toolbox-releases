#!/bin/sh
# shellcheck shell=sh

# Общие настройки проекта xfree-toolbox.
# Этот файл должен содержать только действительно общие переменные,
# без domain-specific параметров модулей.

: "${XFREE_MODE:=PROD}"
: "${XFREE_TOOLBOX_NAME:=xfree-toolbox}"
: "${XFREE_TMP_ROOT:=/tmp/$XFREE_TOOLBOX_NAME}"
: "${XFREE_STATE_ROOT:=/etc/$XFREE_TOOLBOX_NAME}"
: "${XFREE_BACKUP_ROOT:=$XFREE_STATE_ROOT/backups}"
: "${XFREE_PROFILE:=default}"
: "${BACKUP_KEEP:=3}"

# Базовые каталоги
: "${XFREE_ROOT_DIR:=/root/xfree-toolbox}"
: "${XFREE_LIB_DIR:=$XFREE_ROOT_DIR/lib}"
: "${XFREE_UPDATE_URL:=https://xfree-cloud.duckdns.org/public.php/dav/files/xkwFs6doydiM4Pw}"
# Публичная папка apk-фида на Nextcloud (без /s/…)
: "${XFREE_APK_FEED_PUBLIC_BASE:=https://xfree-cloud.duckdns.org/public.php/dav/files/GFqGBrf6giHzpZQ}"
# Зеркало apk-фида: публичный репозиторий артефактов + raw.githubusercontent.com (без 30x).
# Приватный XFree/xfree-toolbox для чужих запросов отвечает 404 — исходники туда не кладём.
# apk/uclient-fetch не ходит за редиректами github.com/releases/download.
: "${XFREE_APK_FEED_GITHUB_REPO:=XFree/xfree-toolbox-releases}"
: "${XFREE_APK_FEED_GITHUB_BRANCH:=main}"
: "${XFREE_APK_FEED_GITHUB_TAG:=$XFREE_APK_FEED_GITHUB_BRANCH}"
: "${XFREE_APK_FEED_GITHUB_PUBLIC_BASE:=https://raw.githubusercontent.com/XFree/xfree-toolbox-releases/main}"
if [ -r "$XFREE_STATE_ROOT/apk-feed.env" ]; then
    # shellcheck disable=SC1090
    . "$XFREE_STATE_ROOT/apk-feed.env"
fi
# Share factory (cold install: install-from-cloud.sh + xfree-toolbox.pub; не путать с XFREE_UPDATE_URL / tar)
: "${XFREE_FACTORY_PUBLIC_BASE:=https://xfree-cloud.duckdns.org/public.php/dav/files/L982AaEEYAHYtTj}"
: "${XFREE_INSTALL_SCRIPT_NAME:=install-from-cloud.sh}"

# System state roots. Keep names domain-specific, but put state under the toolbox root.
: "${XFREE_IFACE_ROUTING_ROOT:=$XFREE_STATE_ROOT/iface-routing}"
: "${XFREE_DNS_ROUTING_ROOT:=$XFREE_STATE_ROOT/dns-routing}"
: "${XFREE_VPN_ROOT:=$XFREE_STATE_ROOT/vpn}"
: "${XFREE_DOMAIN_ROUTING_ROOT:=$XFREE_STATE_ROOT/domain-routing}"

# UI / runtime defaults
: "${UI_TMP_ROOT:=$XFREE_TMP_ROOT}"
: "${DNSMASQ_RESTART_SLEEP:=1}"

# GitHub githubusercontent.com: default напрямую (0). Таймаут CDN —
# повтор через https://gh-proxy.com. github.com / codeload не трогаем.
# Всегда зеркало для githubusercontent: XFREE_GITHUB_PROXY=1.
# Overlay переживает self-update: /etc/xfree-toolbox/github-proxy.env
if [ -r "$XFREE_STATE_ROOT/github-proxy.env" ]; then
    # shellcheck disable=SC1090
    . "$XFREE_STATE_ROOT/github-proxy.env"
fi
: "${XFREE_GITHUB_PROXY:=0}"

# Общие сетевые значения по умолчанию, которые модули могут переопределить
: "${VPN_DEV:=warp}"

# Создаём базовые каталоги, если нужно
mkdir -p "$XFREE_TMP_ROOT" "$XFREE_STATE_ROOT" 2>/dev/null || true
