#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
common_load_project_config "$ROOT_DIR"

MAP="${DNS_ROUTING_MAP_FILE:-${XFREE_DNS_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/dns-routing}/generated/dns-redirects.map}"

check_domain() {
    grep "^$1|" "$MAP" || echo "not found"
}

case "${1:-}" in
    lookup)
        check_domain "$2"
        ;;
    multi)
        awk -F'|' '{c[$1]++} END {for (d in c) if (c[d]>1) print d}' "$MAP"
        ;;
    *)
        echo "Usage:"
        echo "  $0 lookup domain.com"
        echo "  $0 multi"
        ;;
esac
