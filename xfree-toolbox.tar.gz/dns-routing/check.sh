#!/bin/sh
# shellcheck shell=sh
# Проверка DNS для сайтов (меню): live A-запросы через diagnostics/dns-check.sh
# (общие probe-имена × секции dns-routing). Subcommands lookup/multi — отладка map.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
common_load_project_config "$ROOT_DIR"

MAP="${DNS_ROUTING_MAP_FILE:-${XFREE_DNS_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/dns-routing}/generated/dns-redirects.map}"
DIAG_CHECK="$ROOT_DIR/diagnostics/dns-check.sh"

check_domain() {
	grep "^$1|" "$MAP" || echo "not found"
}

case "${1:-}" in
	lookup)
		[ "$#" -ge 2 ] || die "lookup: нужен domain.com"
		check_domain "$2"
		;;
	multi)
		[ -f "$MAP" ] || die "нет map: $MAP"
		awk -F'|' '{c[$1]++} END {for (d in c) if (c[d]>1) print d}' "$MAP"
		;;
	*)
		# Канон: diagnostics/dns-check.sh (ya.ru/google/… по всем секциям, без перебора списков).
		[ -f "$DIAG_CHECK" ] || die "нет $DIAG_CHECK"
		exec sh "$DIAG_CHECK" "$@"
		;;
esac
