#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"

info "Пункт удаления DNS-маршрутизации пока не реализован."
info "Здесь будет удаление только применённого системного слоя DNS-routing без удаления рабочей конфигурации."
