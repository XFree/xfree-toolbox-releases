#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib.sh"
# shellcheck disable=SC1090
. "$SCRIPT_DIR/lib/restart-stack.sh"
# shellcheck disable=SC1090
. "$ROOT_DIR/lib/iface-vpn-dns-cover.sh"

PROFILE_DIR_ARG="${PROFILE_DIR:-}"
PROFILE_DIR=""
DNS_ROOT=""

OUTPUT_DIR="/etc/dnsmasq.d/xfree-toolbox-routing"
OUTPUT_FILE="$OUTPUT_DIR/90-xfree-toolbox-dns-redirects.conf"

common_load_project_config "$ROOT_DIR"
STATE_DNS_DIR="${DNS_ROUTING_STATE_DNS_DIR:-${XFREE_DNS_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/dns-routing}/state/dns}"
GEN_DIR="${DNS_ROUTING_GENERATED_DIR:-${XFREE_DNS_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/dns-routing}/generated}"
MAP_FILE="$GEN_DIR/dns-redirects.map"
SUMMARY_FILE="$GEN_DIR/dns-redirects.summary"
BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"

CHECK_ONLY=0
NO_RESTART=0
PRINT_OUTPUT=0

while [ $# -gt 0 ]; do
    case "$1" in
        --check-only)
            CHECK_ONLY=1
            ;;
        --no-restart)
            NO_RESTART=1
            ;;
        --print-output)
            PRINT_OUTPUT=1
            ;;
        --dns-root)
            shift
            [ $# -gt 0 ] || die "Missing value for --dns-root"
            DNS_ROOT="$1"
            ;;
        --profile-dir)
            shift
            [ $# -gt 0 ] || die "Missing value for --profile-dir"
            PROFILE_DIR_ARG="$1"
            ;;
        --output)
            shift
            [ $# -gt 0 ] || die "Missing value for --output"
            OUTPUT_FILE="$1"
            OUTPUT_DIR="$(dirname -- "$OUTPUT_FILE")"
            ;;
        *)
            die "Unknown argument: $1"
            ;;
    esac
    shift
done

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "$PROFILE_DIR_ARG")"
DNS_ROOT="${DNS_ROOT:-$PROFILE_DIR/dns-routing/dns}"

info "Сборка DNS redirect конфигурации"
info "SCRIPT_DIR: $SCRIPT_DIR"
info "DNS root: $DNS_ROOT"

[ -d "$DNS_ROOT" ] || die "Каталог DNS не найден: $DNS_ROOT"

if [ "$CHECK_ONLY" -eq 0 ]; then
    dns_routing_scrub_unowned_dns_dirs "$DNS_ROOT" "$PROFILE_DIR" "$STATE_DNS_DIR"
fi

mkdir -p "$OUTPUT_DIR"
chmod 0755 "$OUTPUT_DIR" 2>/dev/null || true
case "$OUTPUT_DIR" in
    /etc/dnsmasq.d/*) chmod 0755 "/etc/dnsmasq.d" 2>/dev/null || true ;;
esac
mkdir -p "$GEN_DIR"

TMP_FILE="$(mktemp)"
TMP_MAP="$(mktemp)"
TMP_SUMMARY="$(mktemp)"
TMP_VALID_TARGETS="$(mktemp)"
TMP_REDIRECT_TARGETS="$(mktemp)"
TMP_MANAGED_DHCP_TOKENS="$(mktemp)"
TMP_IFACE_FQDNS="$(mktemp)"
trap 'rm -f "$TMP_FILE" "$TMP_MAP" "$TMP_SUMMARY" "$TMP_VALID_TARGETS" "$TMP_REDIRECT_TARGETS" "$TMP_MANAGED_DHCP_TOKENS" "$TMP_IFACE_FQDNS"' EXIT INT TERM

: > "$TMP_FILE"
: > "$TMP_MAP"
: > "$TMP_SUMMARY"
: > "$TMP_VALID_TARGETS"
: > "$TMP_REDIRECT_TARGETS"
: > "$TMP_MANAGED_DHCP_TOKENS"

dns_count=0
list_count=0
rule_count=0
skipped_count=0

# Пересечение с WAN DNS только по именам, которые остались в туннеле после exclude.
info "Анализ FQDN туннелей (сбор исключений)..."
iface_vpn_dns_collect_profile_fqdns "$PROFILE_DIR" > "$TMP_IFACE_FQDNS"
iface_skip_n="$(wc -l < "$TMP_IFACE_FQDNS" | awk '{print $1}')"
info "iface-routing FQDN after exclude (tunnel DNS, skip WAN redirect): $iface_skip_n"

normalize_line() {
    printf '%s' "$1" | tr -d '\r' | sed 's/[[:space:]]*$//'
}

domain_matches_cleanup() {
    domain="$1"
    cleanup_domains="$2"
    DOMAIN_CLEANUP_MATCH_KIND=""
    DOMAIN_CLEANUP_MATCH_BASE=""

    for cleanup_domain in $cleanup_domains; do
        if [ "$domain" = "$cleanup_domain" ]; then
            DOMAIN_CLEANUP_MATCH_KIND="exact"
            DOMAIN_CLEANUP_MATCH_BASE="$cleanup_domain"
            return 0
        fi

        case "$domain" in
            *."$cleanup_domain")
                DOMAIN_CLEANUP_MATCH_KIND="subdomain"
                DOMAIN_CLEANUP_MATCH_BASE="$cleanup_domain"
                return 0
                ;;
        esac
    done

    return 1
}

parse_dhcp_server_token() {
    token="$1"
    PARSED_DOMAIN=""
    PARSED_TARGET=""

    case "$token" in
        /*/*)
            PARSED_DOMAIN="${token#/}"
            PARSED_DOMAIN="${PARSED_DOMAIN%%/*}"
            PARSED_TARGET="${token#*/}"
            PARSED_TARGET="${PARSED_TARGET#*/}"
            ;;
        *#*)
            PARSED_TARGET="$token"
            ;;
    esac
}

dhcp_server_token_should_remove() {
    token="$1"
    cleanup_domains="$2"
    all_valid_targets_file="$3"
    redirect_targets_file="$4"
    known_canary_domains="$5"
    enabled_canary_domains="$6"
    DHCP_SERVER_REMOVE_REASON=""

    parse_dhcp_server_token "$token"
    dom="$PARSED_DOMAIN"
    target="$PARSED_TARGET"

    if [ -n "$dom" ] && domain_matches_cleanup "$dom" "$cleanup_domains"; then
        DHCP_SERVER_REMOVE_REASON="domain:${DOMAIN_CLEANUP_MATCH_KIND}:${DOMAIN_CLEANUP_MATCH_BASE}"
        return 0
    fi

    if [ -n "$dom" ] && dns_routing_domain_in_space_list "$dom" "$known_canary_domains"; then
        if ! dns_routing_domain_in_space_list "$dom" "$enabled_canary_domains"; then
            DHCP_SERVER_REMOVE_REASON="canary-disabled:$dom"
            return 0
        fi
        return 1
    fi

    case "$target" in
        *#*)
            if dns_routing_valid_target_in_list "$target" "$all_valid_targets_file"; then
                if ! dns_routing_valid_target_in_list "$target" "$redirect_targets_file"; then
                    DHCP_SERVER_REMOVE_REASON="dns-redirect-disabled:$target"
                    return 0
                fi
            else
                DHCP_SERVER_REMOVE_REASON="orphan-target:$target"
                return 0
            fi
            ;;
    esac

    return 1
}

dhcp_server_token_present() {
    token="$1"
    token_list="$2"

    for existing in $token_list; do
        [ "$existing" = "$token" ] && return 0
    done

    return 1
}

sync_dhcp_server_list() {
    domains_to_cleanup="$(
        awk -F'|' '{print $1}' "$TMP_MAP" | sort -u | tr '\n' ' '
    )"
    dhcp_server_conf="$(dns_routing_dhcp_server_conf_path "$PROFILE_DIR")"

    dns_routing_collect_valid_targets_for_apply "$DNS_ROOT" "$PROFILE_DIR" "$TMP_VALID_TARGETS"
    dns_routing_collect_redirect_targets_from_root "$DNS_ROOT" > "$TMP_REDIRECT_TARGETS"
    dns_routing_collect_managed_dhcp_tokens "$DNS_ROOT" "$dhcp_server_conf" "$TMP_MANAGED_DHCP_TOKENS"

    dns_routing_load_dhcp_server_conf "$dhcp_server_conf"
    known_canary_domains="$(
        dns_routing_known_canary_domains | tr '\n' ' '
    )"
    enabled_canary_domains="$(
        dns_routing_enabled_canary_domains \
            "${CANARY_DOMAINS_ICLOUD:-1}" \
            "${CANARY_DOMAINS_MOZILLA:-1}" | tr '\n' ' '
    )"

    valid_target_count="$(wc -l < "$TMP_VALID_TARGETS" | awk '{print $1}')"
    redirect_target_count="$(wc -l < "$TMP_REDIRECT_TARGETS" | awk '{print $1}')"
    managed_token_count="$(wc -l < "$TMP_MANAGED_DHCP_TOKENS" | awk '{print $1}')"
    info "dhcp.server sync: valid targets=$valid_target_count redirect targets=$redirect_target_count managed tokens=$managed_token_count"
    info "  dhcp-server.conf: ${dhcp_server_conf}"
    info "  dns-routing: $DNS_ROOT"
    info "  https-dns-proxy: $(dns_routing_https_dns_proxy_profile_dir "$PROFILE_DIR")/https-dns-proxy"
    while IFS= read -r valid_target; do
        [ -n "$valid_target" ] || continue
        info "  target: $valid_target"
    done < "$TMP_VALID_TARGETS"
    while IFS= read -r managed_token; do
        [ -n "$managed_token" ] || continue
        info "  managed: $managed_token"
    done < "$TMP_MANAGED_DHCP_TOKENS"

    dnsmasq_indices="$(
        uci show dhcp 2>/dev/null | awk -F'[][]' '/=dnsmasq/{print $2}'
    )"
    [ -n "${dnsmasq_indices:-}" ] || return 0

    total_removed=0
    total_added=0
    for dnsmasq_index in $dnsmasq_indices; do
        current_server="$(uci -q get "dhcp.@dnsmasq[$dnsmasq_index].server" 2>/dev/null || true)"
        kept_tokens=""
        removed_count=0
        added_count=0
        removed_tokens=""

        if [ -n "${current_server:-}" ]; then
            set -- $current_server
            for tok in "$@"; do
                clean_tok="$(printf '%s' "$tok" | tr -d '\r' | sed -e "s/^'//" -e "s/'$//" -e 's/^"//' -e 's/"$//')"

                if dhcp_server_token_should_remove \
                    "$clean_tok" \
                    "$domains_to_cleanup" \
                    "$TMP_VALID_TARGETS" \
                    "$TMP_REDIRECT_TARGETS" \
                    "$known_canary_domains" \
                    "$enabled_canary_domains"; then
                    removed_count=$((removed_count + 1))
                    removed_tokens="$removed_tokens ${clean_tok}[${DHCP_SERVER_REMOVE_REASON}]"
                    continue
                fi

                kept_tokens="$kept_tokens $clean_tok"
            done
        fi

        while IFS= read -r managed_token; do
            [ -n "$managed_token" ] || continue
            if ! dhcp_server_token_present "$managed_token" "$kept_tokens"; then
                kept_tokens="$kept_tokens $managed_token"
                added_count=$((added_count + 1))
            fi
        done < "$TMP_MANAGED_DHCP_TOKENS"

        if [ "$removed_count" -gt 0 ] || [ "$added_count" -gt 0 ]; then
            uci -q delete "dhcp.@dnsmasq[$dnsmasq_index].server" 2>/dev/null || true
            for token in $kept_tokens; do
                uci add_list "dhcp.@dnsmasq[$dnsmasq_index].server=$token"
            done
            total_removed=$((total_removed + removed_count))
            total_added=$((total_added + added_count))
            if [ "$removed_count" -gt 0 ]; then
                info "Удалены записи из dhcp.@dnsmasq[$dnsmasq_index].server: $removed_count"
                for removed_token in $removed_tokens; do
                    info "  - $removed_token"
                done
            fi
            if [ "$added_count" -gt 0 ]; then
                info "Добавлены записи в dhcp.@dnsmasq[$dnsmasq_index].server: $added_count"
            fi
        fi

        if dns_routing_noresolv_enabled; then
            current_noresolv="$(uci -q get "dhcp.@dnsmasq[$dnsmasq_index].noresolv" 2>/dev/null || true)"
            if [ "$current_noresolv" != "1" ]; then
                uci set "dhcp.@dnsmasq[$dnsmasq_index].noresolv=1"
                info "dhcp.@dnsmasq[$dnsmasq_index].noresolv: установлен в 1 (защита от утечек на DNS провайдера)"
            fi
        fi

        if dns_routing_rebind_msftncsi_enabled; then
            current_rebind_domains="$(uci -q get "dhcp.@dnsmasq[$dnsmasq_index].rebind_domain" 2>/dev/null || true)"
            if ! dhcp_server_token_present "dns.msftncsi.com" "$current_rebind_domains"; then
                uci add_list "dhcp.@dnsmasq[$dnsmasq_index].rebind_domain=dns.msftncsi.com"
                info "dhcp.@dnsmasq[$dnsmasq_index].rebind_domain: добавлен dns.msftncsi.com (Windows NCSI)"
            fi
        fi

        uci -q delete "dhcp.@dnsmasq[$dnsmasq_index].doh_backup_server" 2>/dev/null || true
    done

    info "dhcp.server sync: удалено=$total_removed добавлено=$total_added"
    info "Очищены dhcp.@dnsmasq[*].doh_backup_server (https-backup)"
}

extract_domain() {
    line="$1"

    case "$line" in
        ""|\#*)
            return 1
            ;;
        /*)
            # legacy format: /domain/127.0.0.1#5054
            printf '%s' "$line" | cut -d/ -f2
            ;;
        *)
            printf '%s' "$line"
            ;;
    esac
}

for instance_dir in "$DNS_ROOT"/*; do
    [ -d "$instance_dir" ] || continue

    dns_id="$(basename "$instance_dir")"
    dns_conf="$instance_dir/config/dns.conf"
    fqdn_dir="$instance_dir/fqdn.d"

    if [ ! -f "$dns_conf" ]; then
        info "Пропускаю $dns_id: нет config/dns.conf"
        continue
    fi
    if [ ! -d "$fqdn_dir" ]; then
        info "Пропускаю $dns_id: нет каталога fqdn.d — назначьте списки (dns-routing/select-lists.sh) или добавьте .lst вручную"
        continue
    fi

    unset \
        DNS_ID \
        DNS_HOST \
        DNS_TARGET \
        DNS_RESOLVER_URL \
        DNS_BOOTSTRAP_DNS \
        DNS_LISTEN_ADDR \
        DNS_LISTEN_PORT \
        DNS_REDIRECT \
        DNS_FILTER_AAAA \
        2>/dev/null || true

    # shellcheck disable=SC1090
    . "$dns_conf"
    DNS_ID="$(dns_routing_strip_cr "${DNS_ID:-}")"
    DNS_HOST="$(dns_routing_strip_cr "${DNS_HOST:-}")"
    DNS_TARGET="$(dns_routing_strip_cr "${DNS_TARGET:-}")"
    DNS_LISTEN_PORT="$(dns_routing_strip_cr "${DNS_LISTEN_PORT:-}")"
    DNS_REDIRECT="$(dns_routing_strip_cr "${DNS_REDIRECT:-}")"

    [ -n "${DNS_ID:-}" ] || die "dns.conf: не задан DNS_ID ($dns_conf)"
    [ -n "${DNS_TARGET:-}" ] || die "dns.conf: не задан DNS_TARGET ($dns_conf)"

    target="$DNS_TARGET"
    dns_count=$((dns_count + 1))

    found_any_list=0
    for lst in "$fqdn_dir"/*.lst; do
        [ -f "$lst" ] || continue
        found_any_list=1
        list_count=$((list_count + 1))
    done

    if [ "$found_any_list" -eq 0 ]; then
        info "В $dns_id нет .lst файлов"
        continue
    fi

    _awk_stat="$(awk -v cov_file="$TMP_IFACE_FQDNS" \
        -v target="$target" \
        -v dns_id="$dns_id" \
        -v out_file="$TMP_FILE" \
        -v map_file="$TMP_MAP" '
        BEGIN {
            if (cov_file != "") {
                while ((getline l < cov_file) > 0) {
                    sub(/\r$/, "", l)
                    sub(/[[:space:]]*#.*/, "", l)
                    gsub(/^[ \t]+|[ \t]+$/, "", l)
                    if (l != "") {
                        gsub(/^\*\./, "", l)
                        gsub(/^\./, "", l)
                        cov[tolower(l)] = 1
                    }
                }
                close(cov_file)
            }
            rules = 0
            skipped = 0
        }
        {
            line = $0
            sub(/\r$/, "", line)
            sub(/[[:space:]]*#.*/, "", line)
            gsub(/^[ \t]+|[ \t]+$/, "", line)
            if (line == "" || line ~ /^;/) next

            if (line ~ /^\//) {
                split(line, parts, "/")
                d = parts[2]
            } else {
                d = line
            }
            gsub(/^[ \t]+|[ \t]+$/, "", d)
            gsub(/^\*\./, "", d)
            gsub(/^\./, "", d)
            d = tolower(d)
            if (d == "") next

            is_cov = 0
            cand = d
            while (cand != "") {
                if (cand in cov) { is_cov = 1; break }
                p = index(cand, ".")
                if (p > 0) cand = substr(cand, p + 1)
                else cand = ""
            }

            if (is_cov) {
                skipped++
            } else {
                rules++
                list_name = FILENAME
                sub(/.*\//, "", list_name)
                print "server=/" d "/" target >> out_file
                print d "|" target "|" dns_id "|" list_name >> map_file
            }
        }
        END {
            close(out_file)
            close(map_file)
            print rules " " skipped
        }
    ' "$fqdn_dir"/*.lst)"

    _inst_rules="${_awk_stat%% *}"
    _inst_skipped="${_awk_stat##* }"
    rule_count=$((rule_count + ${_inst_rules:-0}))
    skipped_count=$((skipped_count + ${_inst_skipped:-0}))
done

[ "$dns_count" -gt 0 ] || die "Не найдено ни одного валидного DNS-инстанса в $DNS_ROOT"
[ "$list_count" -gt 0 ] || die "Не найдено ни одного .lst файла в DNS-инстансах"
if [ "$rule_count" -eq 0 ]; then
    if [ "$skipped_count" -gt 0 ]; then
        info "Все DNS server= пропущены: покрыты iface-routing FQDN ($skipped_count)"
    else
        die "Не собрано ни одного redirect-правила"
    fi
fi

sort -u "$TMP_FILE" -o "$TMP_FILE"
sort -u "$TMP_MAP" -o "$TMP_MAP"

# Legacy global FILTER_AAAA is ignored (broke AAAA via VPN). Per-FQDN AAAA
# sidecars are retired: catch-all DoH already returns AAAA; clients Happy-Eyeballs.
dns_routing_load_dhcp_server_conf "$(dns_routing_dhcp_server_conf_path "$PROFILE_DIR")"
if dns_routing_truthy "${FILTER_AAAA:-0}"; then
    warn "FILTER_AAAA в dhcp-server.conf устарел и игнорируется (ломал AAAA для VPN)."
fi

unique_rules="$(wc -l < "$TMP_FILE" | awk '{print $1}')"
unique_map="$(wc -l < "$TMP_MAP" | awk '{print $1}')"

info "DNS-инстансов: $dns_count"
info "Списков: $list_count"
info "Правил собрано: $rule_count"
info "Пропущено (iface-routing FQDN): $skipped_count"
info "Уникальных server-правил: $unique_rules"
info "Уникальных map-записей: $unique_map"

awk -F'|' '
{
    domain=$1
    target=$2
    dns_id=$3

    if (!(seen_target[domain SUBSEP target]++)) {
        if (targets[domain] == "") {
            targets[domain] = target
        } else {
            targets[domain] = targets[domain] "," target
        }
        target_count[domain]++
    }

    if (!(seen_dns[domain SUBSEP dns_id]++)) {
        if (dns_ids[domain] == "") {
            dns_ids[domain] = dns_id
        } else {
            dns_ids[domain] = dns_ids[domain] "," dns_id
        }
    }

    source_count[domain]++
}
END {
    for (d in target_count) {
        print d "|" target_count[d] "|" targets[d] "|" dns_ids[d] "|" source_count[d]
    }
}
' "$TMP_MAP" | sort > "$TMP_SUMMARY"

if dns_routing_rebind_msftncsi_enabled; then
    printf 'rebind-domain-ok=/dns.msftncsi.com/\n' >> "$TMP_FILE"
fi

if [ "$PRINT_OUTPUT" -eq 1 ]; then
    cat "$TMP_FILE"
fi

if [ "$CHECK_ONLY" -eq 1 ]; then
    if command -v uci >/dev/null 2>&1; then
        for idx in $(uci show dhcp 2>/dev/null | awk -F'[][]' '/=dnsmasq/{print $2}'); do
            nr="$(uci -q get "dhcp.@dnsmasq[$idx].noresolv" 2>/dev/null || true)"
            if [ "$nr" != "1" ]; then
                warn "Check-only: dhcp.@dnsmasq[$idx].noresolv != 1 (рекомендуется noresolv=1 для защиты от утечек на DNS провайдера)"
            else
                info "Check-only: dhcp.@dnsmasq[$idx].noresolv = 1 (OK)"
            fi
        done
    fi
    info "Check-only режим: изменения не применены"
    exit 0
fi

# Backup current runtime artifacts before overwrite.
existing_backup="$(common_backup_file "$OUTPUT_FILE" "dns-routing" "dns-redirects.conf" "$BACKUP_KEEP" "bak" || true)"
if [ -n "${existing_backup:-}" ]; then
    info "Создан backup DNS redirects: $existing_backup"
fi

existing_map_backup="$(common_backup_file "$MAP_FILE" "dns-routing" "dns-redirects.map" "$BACKUP_KEEP" "bak" || true)"
if [ -n "${existing_map_backup:-}" ]; then
    info "Создан backup DNS map: $existing_map_backup"
fi

existing_summary_backup="$(common_backup_file "$SUMMARY_FILE" "dns-routing" "dns-redirects.summary" "$BACKUP_KEEP" "bak" || true)"
if [ -n "${existing_summary_backup:-}" ]; then
    info "Создан backup DNS summary: $existing_summary_backup"
fi

if [ "${DNS_ROOT%/}" != "${STATE_DNS_DIR%/}" ]; then
    _state_needs_update=1
    if [ -d "$STATE_DNS_DIR" ] && ! dns_routing_any_lists_out_of_sync "$DNS_ROOT" "$STATE_DNS_DIR"; then
        STATE_DNS_ROUTING_ROOT="$(dirname -- "$STATE_DNS_DIR")"
        PROFILE_DNS_ROUTING_CONFIG="$PROFILE_DIR/dns-routing/config"
        STATE_DNS_ROUTING_CONFIG="$STATE_DNS_ROUTING_ROOT/config"
        if [ ! -d "$PROFILE_DNS_ROUTING_CONFIG" ] || diff -r -q "$PROFILE_DNS_ROUTING_CONFIG" "$STATE_DNS_ROUTING_CONFIG" >/dev/null 2>&1; then
            _state_needs_update=0
        fi
    fi

    if [ "$_state_needs_update" = "1" ]; then
        state_backup="$(common_backup_dir "$STATE_DNS_DIR" "dns-routing" "state-dns" "$BACKUP_KEEP" "" || true)"
        if [ -n "${state_backup:-}" ]; then
            info "Создан backup DNS state: $state_backup"
        fi
        rm -rf "$STATE_DNS_DIR"
        mkdir -p "$STATE_DNS_DIR"
        cp -a "$DNS_ROOT/." "$STATE_DNS_DIR/"

        STATE_DNS_ROUTING_ROOT="$(dirname -- "$STATE_DNS_DIR")"
        PROFILE_DNS_ROUTING_CONFIG="$PROFILE_DIR/dns-routing/config"
        STATE_DNS_ROUTING_CONFIG="$STATE_DNS_ROUTING_ROOT/config"
        if [ -d "$PROFILE_DNS_ROUTING_CONFIG" ]; then
            mkdir -p "$STATE_DNS_ROUTING_CONFIG"
            cp -a "$PROFILE_DNS_ROUTING_CONFIG/." "$STATE_DNS_ROUTING_CONFIG/"
        fi
    else
        info "DNS state актуален (списки не менялись, пропуск копирования state)"
    fi
else
    mkdir -p "$STATE_DNS_DIR"
fi

common_atomic_write_dnsmasq_conf "$TMP_FILE" "$OUTPUT_FILE" || \
    die "Ошибка записи/проверки dnsmasq-конфига: $OUTPUT_FILE (предыдущий конфиг сохранён)"
rm -f "$OUTPUT_DIR/90-dns-redirects.conf" 2>/dev/null || true
common_atomic_write_file "$TMP_MAP" "$MAP_FILE" 0644
common_atomic_write_file "$TMP_SUMMARY" "$SUMMARY_FILE" 0644

current_confdir="$(uci -q get dhcp.@dnsmasq[0].confdir 2>/dev/null || true)"
confdir_exists=0
for confdir in $current_confdir; do
    if [ "$confdir" = "$OUTPUT_DIR" ]; then
        confdir_exists=1
    elif [ "$confdir" = "/etc/dnsmasq.d/domain-routing" ]; then
        uci del_list dhcp.@dnsmasq[0].confdir="$confdir" 2>/dev/null || true
    fi
done

if [ "$confdir_exists" -eq 0 ]; then
    uci add_list dhcp.@dnsmasq[0].confdir="$OUTPUT_DIR"
fi

sync_dhcp_server_list

uci commit dhcp

# Optional leftover cleanup. Same approach in other apply: <module>/lib/apply-migrations.sh
# (delete that file when obsolete). See agents/conventions/apply-migrations.md.
if [ -f "$SCRIPT_DIR/lib/apply-migrations.sh" ]; then
    # shellcheck disable=SC1091
    . "$SCRIPT_DIR/lib/apply-migrations.sh"
    apply_migrations after_write || true
fi

if [ "$NO_RESTART" -eq 0 ]; then
    dns_routing_restart_resolver_stack || /etc/init.d/dnsmasq restart
    if [ -f "$SCRIPT_DIR/lib/apply-migrations.sh" ]; then
        apply_migrations after_restart || true
    fi
fi

if command -v uci >/dev/null 2>&1; then
    for idx in $(uci show dhcp 2>/dev/null | awk -F'[][]' '/=dnsmasq/{print $2}'); do
        nr="$(uci -q get "dhcp.@dnsmasq[$idx].noresolv" 2>/dev/null || true)"
        if [ "$nr" != "1" ]; then
            warn "Проверка dnsmasq: dhcp.@dnsmasq[$idx].noresolv=$nr (ВНИМАНИЕ: noresolv!=1, возможна утечка DNS на провайдера)"
        else
            info "Проверка dnsmasq: dhcp.@dnsmasq[$idx].noresolv=1 [OK] (защита от утечек на DNS провайдера активна)"
        fi
    done
fi

info "DNS redirect применён"
info "Конфиг: $OUTPUT_FILE"
info "Map: $MAP_FILE"
info "Summary: $SUMMARY_FILE"
