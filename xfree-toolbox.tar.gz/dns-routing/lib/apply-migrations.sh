#!/bin/sh
# shellcheck shell=sh
# Temporary leftover cleanup for dns-routing/apply.sh.
# Delete this file when leftover AAAA-filter sidecar is gone from routers.
# Pattern: agents/conventions/apply-migrations.md (per-module file, not shared lib).

apply_migrations() {
  case "$1" in
    after_write)
      # New redirects use DoH stubs. Drop autostart now; do not kill PIDs yet
      # (live dnsmasq may still have server= …#15xxx until restart).
      if dns_routing_aaaa_filter_autostart_present; then
        info "временно: снимаю leftover AAAA-filter sidecar с автозапуска"
        dns_routing_retire_aaaa_filter_autostart || true
      fi
      ;;
    after_restart)
      dns_routing_retire_aaaa_filter_leftovers || true
      ;;
  esac
}
