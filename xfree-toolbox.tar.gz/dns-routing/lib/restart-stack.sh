#!/bin/sh
# shellcheck shell=sh
# Перезапуск локального DNS-стека (https-dns-proxy + dnsmasq) после правок redirect/DHCP.
# https-dns-proxy: https-dns-proxy/lib/service.sh (как zapret/lib/service.sh).
# После bounce — common_wait_network_after_restart (проба маршрута/uplink).

dns_routing_aaaa_filter_initd_path() {
  printf '%s\n' "${XFREE_AAAA_FILTER_INITD:-/etc/init.d/xfree-aaaa-filter}"
}

dns_routing_aaaa_filter_rcd_dir() {
  printf '%s\n' "${XFREE_AAAA_FILTER_RCD_DIR:-/etc/rc.d}"
}

dns_routing_aaaa_filter_redirects_conf() {
  printf '%s\n' "${XFREE_DNS_REDIRECTS_CONF:-/etc/dnsmasq.d/xfree-toolbox-routing/90-xfree-toolbox-dns-redirects.conf}"
}

# Catch-all DoH (5060) already returns AAAA; leftover per-FQDN sidecars hang :53.
# Autostart retire must not stop PIDs: if dnsmasq still has server= …#15xxx/#16xxx,
# killing the sidecar before conf rewrite hangs resolver queries.
dns_routing_aaaa_filter_autostart_present() {
  initd="$(dns_routing_aaaa_filter_initd_path)"
  rcd="$(dns_routing_aaaa_filter_rcd_dir)"
  if [ -e "$initd" ] || [ -L "$initd" ]; then
    return 0
  fi
  for f in "$rcd"/S*xfree-aaaa-filter "$rcd"/K*xfree-aaaa-filter; do
    if [ -e "$f" ] || [ -L "$f" ]; then
      return 0
    fi
  done
  return 1
}

dns_routing_aaaa_filter_redirects_use_sidecar() {
  conf="$(dns_routing_aaaa_filter_redirects_conf)"
  [ -f "$conf" ] || return 1
  grep -qE '127\.0\.0\.1#(15|16)[0-9]{3}([[:space:]]|$)' "$conf"
}

dns_routing_retire_aaaa_filter_autostart() {
  initd="$(dns_routing_aaaa_filter_initd_path)"
  rcd="$(dns_routing_aaaa_filter_rcd_dir)"
  if [ -x "$initd" ]; then
    "$initd" disable >/dev/null 2>&1 || true
  fi
  rm -f "$initd"
  for f in "$rcd"/S*xfree-aaaa-filter "$rcd"/K*xfree-aaaa-filter; do
    if [ -e "$f" ] || [ -L "$f" ]; then
      rm -f "$f"
    fi
  done
}

dns_routing_retire_aaaa_filter_processes() {
  run_dir="${XFREE_AAAA_FILTER_RUN_DIR:-/var/run/xfree-aaaa-filter}"
  gen="${DNS_ROUTING_GENERATED_DIR:-${XFREE_DNS_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/dns-routing}/generated}"
  if [ -d "$run_dir" ]; then
    for pid_file in "$run_dir"/*.pid; do
      [ -f "$pid_file" ] || continue
      pid="$(cat "$pid_file" 2>/dev/null || true)"
      if [ -n "${pid:-}" ] && kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null || true
      fi
      rm -f "$pid_file"
    done
    rm -rf "$run_dir"
  fi
  rm -f "$gen/aaaa-filters.list" 2>/dev/null || true
}

dns_routing_retire_aaaa_filter_leftovers() {
  dns_routing_retire_aaaa_filter_autostart
  dns_routing_retire_aaaa_filter_processes
}

# After migration post-repair: never kill PIDs while redirects still use sidecar ports.
dns_routing_retire_aaaa_filter_leftovers_if_safe() {
  if dns_routing_aaaa_filter_redirects_use_sidecar; then
    return 0
  fi
  dns_routing_retire_aaaa_filter_leftovers
}

dns_routing_restart_resolver_stack() {
  toolbox_root="${ROOT_DIR:-${XFREE_ROOT_DIR:-}}"
  ok=0
  if [ -x /etc/init.d/https-dns-proxy ]; then
    _svc="${HTTPS_DNS_PROXY_SERVICE_LIB:-$toolbox_root/https-dns-proxy/lib/service.sh}"
    if [ -f "$_svc" ]; then
      # shellcheck disable=SC1090
      . "$_svc"
      https_dns_proxy_restart_service restart || warn "https-dns-proxy не running после рестарта"
    else
      /etc/init.d/https-dns-proxy restart 2>/dev/null || true
    fi
    ok=1
  fi
  if [ -x /etc/init.d/dnsmasq ]; then
    info "Перезапускаю dnsmasq…"
    /etc/init.d/dnsmasq restart || warn "Не удалось перезапустить dnsmasq"
    ok=1
  fi
  dns_routing_retire_aaaa_filter_leftovers || true
  # procd running ≠ DNS готов. Канон: проба маршрута/uplink, затем продолжаем apply.
  if command -v common_wait_network_after_restart >/dev/null 2>&1; then
    common_wait_network_after_restart "${XFREE_DNS_STACK_WAIT_SEC:-30}" || \
      warn "DNS-стек перезапущен, сеть ещё не готова (маршрут/uplink)"
  fi
  [ "$ok" = "1" ]
}
