#!/bin/sh
# OpenWrt (ash) script: profile dns-routing/hosts → toolbox state (canonical for
# export), then state → dnsmasq runtime (/etc/dnsmasq.d/hosts/), UCI addnhosts,
# dnsmasq restart. Same flow idea as dns-routing apply: profile → state → generated runtime.

set -eu


SCRIPT_PATH="$0"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

if [ -f "$ROOT_DIR/lib/common.sh" ]; then
  # shellcheck disable=SC1090
  . "$ROOT_DIR/lib/common.sh"
else
  echo "[-] common.sh не найден: $ROOT_DIR/lib/common.sh" >&2
  exit 1
fi

common_load_project_config "$ROOT_DIR"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
HOSTS_DIR="${HOSTS_DIR:-$PROFILE_DIR/dns-routing/hosts}"
DST_DIR="/etc/dnsmasq.d/hosts"
# Единственный hosts-файл, который apply-hosts снимает без общей метки «наш» в UCI.
MANAGED_HOST_REL="additional.hosts"
MANAGED_HOST_PATH="$DST_DIR/$MANAGED_HOST_REL"
DNS_ROUTING_BASE="${XFREE_DNS_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/dns-routing}"
STATE_HOSTS_DIR="${DNS_ROUTING_STATE_HOSTS_DIR:-$DNS_ROUTING_BASE/state/hosts}"
YES=0
BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"
TMP_LIST=""

cleanup_tmp_list() {
  [ -n "${TMP_LIST:-}" ] && [ -f "$TMP_LIST" ] && rm -f "$TMP_LIST"
}

trap cleanup_tmp_list EXIT HUP INT TERM

uci_addnhosts_present() {
  uci_path="$1"
  uci -q show dhcp.@dnsmasq[0].addnhosts 2>/dev/null | grep -Fq "'$uci_path'"
}

profile_has_managed_host() {
  [ -f "$HOSTS_DIR/$MANAGED_HOST_REL" ]
}

managed_host_needs_prune() {
  profile_has_managed_host && return 1
  uci_addnhosts_present "$MANAGED_HOST_PATH" && return 0
  [ -f "$MANAGED_HOST_PATH" ]
}

hosts_work_needed() {
  if [ -d "$HOSTS_DIR" ]; then
    find "$HOSTS_DIR" -type f 2>/dev/null | sed -n '1p' | grep -q . && return 0
  fi
  managed_host_needs_prune
}

prune_managed_additional_hosts() {
  profile_has_managed_host && return 0

  say "== Снятие $MANAGED_HOST_REL (нет в профиле) =="
  pruned=0

  while uci_addnhosts_present "$MANAGED_HOST_PATH"; do
    uci del_list dhcp.@dnsmasq[0].addnhosts="$MANAGED_HOST_PATH" 2>/dev/null || break
    say "Удалено: list addnhosts '$MANAGED_HOST_PATH'"
    pruned=1
  done

  if [ -f "$MANAGED_HOST_PATH" ]; then
    if [ "$YES" -ne 1 ]; then
      if ! ask_yn "Удалить runtime-файл $MANAGED_HOST_PATH?"; then
        warn "Оставлен на диске: $MANAGED_HOST_PATH"
        [ "$pruned" -eq 1 ]
        return $?
      fi
    fi
    hosts_backup="$(common_backup_file "$MANAGED_HOST_PATH" "dns-routing" "hosts-additional.hosts" "$BACKUP_KEEP" "bak" || true)"
    if [ -n "${hosts_backup:-}" ]; then
      info "Создан backup hosts: $hosts_backup"
    fi
    rm -f "$MANAGED_HOST_PATH"
    say "Удалён runtime: $MANAGED_HOST_PATH"
    pruned=1
  fi

  [ "$pruned" -eq 1 ]
}

sync_profile_hosts_to_state() {
  say "== Профиль → state (канон для materialize/export) =="
  rm -rf "$STATE_HOSTS_DIR"
  mkdir -p "$STATE_HOSTS_DIR"
  if [ -d "$HOSTS_DIR" ]; then
    cp -a "$HOSTS_DIR"/. "$STATE_HOSTS_DIR"/
  fi
  info "State hosts: $STATE_HOSTS_DIR"
}

deploy_hosts_file() {
  src="$1"
  rel="$2"
  dst="$DST_DIR/$rel"

  mkdir -p "$(dirname -- "$dst")"

  if [ -f "$dst" ]; then
    if cmp -s "$src" "$dst"; then
      info "Без изменений: $dst"
      return 0
    fi
    if [ "$YES" -ne 1 ]; then
      if ! ask_yn "Заменить существующий файл $dst?"; then
        info "Пропуск (оставлен старый): $dst"
        return 1
      fi
    fi
    backup_tag="hosts-$(printf '%s' "$rel" | tr '/' '_')"
    hosts_backup="$(common_backup_file "$dst" "dns-routing" "$backup_tag" "$BACKUP_KEEP" "bak" || true)"
    if [ -n "${hosts_backup:-}" ]; then
      info "Создан backup hosts: $hosts_backup"
    fi
  fi

  cp -f "$src" "$dst"
  chmod 0644 "$dst" 2>/dev/null || true
  info "Установлено: $dst"
  return 0
}

normalize_answer() {
  printf '%s' "$1" \
    | tr -d '\r\010\177' \
    | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' \
    | common_lower_ascii_stream
}

is_yes() {
  ans="$(normalize_answer "$1")"
  case "$ans" in
    y|yes|д|да|н) return 0 ;;
    *) return 1 ;;
  esac
}

is_no() {
  ans="$(normalize_answer "$1")"
  case "$ans" in
    n|no|нет|т|"") return 0 ;;
    *) return 1 ;;
  esac
}

ask_yn() {
  prompt="$1"

  if [ "$YES" -eq 1 ]; then
    return 0
  fi

  while true; do
    printf "%s [y/N]: " "$prompt" >&2
    IFS= read -r ans || ans=""

    if is_yes "$ans"; then
      return 0
    fi

    if is_no "$ans"; then
      return 1
    fi

    printf '%s\n' "Введите y/n, да/нет." >&2
  done
}

usage() {
  cat <<EOF2
Usage:
  $(basename "$0") [--yes]
EOF2
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    -h|--help) usage; exit 0 ;;
    *) printf 'Неизвестный параметр: %s\n' "$1" >&2; exit 1 ;;
  esac
  shift
done

say "== Проверка каталога hosts профиля =="
if ! hosts_work_needed; then
  say "Пропуск: нет hosts в профиле и не зарегистрирован $MANAGED_HOST_REL"
  exit 0
fi

if [ ! -d "$HOSTS_DIR" ]; then
  say "Каталог hosts отсутствует в профиле; будет снята регистрация $MANAGED_HOST_REL"
fi

TMP_LIST="$(mktemp "${TMPDIR:-/tmp}/xfree-apply-hosts.XXXXXX")"
if [ -d "$HOSTS_DIR" ]; then
  find "$HOSTS_DIR" -type f 2>/dev/null | sort > "$TMP_LIST"
else
  : > "$TMP_LIST"
fi
if [ ! -s "$TMP_LIST" ]; then
  say "В профиле нет файлов hosts; будет снята регистрация $MANAGED_HOST_REL"
else
  say "Найдены файлы (относительно $HOSTS_DIR):"
  while IFS= read -r src; do
    [ -n "$src" ] || continue
    say "  ${src#"$HOSTS_DIR"/}"
  done < "$TMP_LIST"
  if managed_host_needs_prune; then
    say "  (в профиле нет $MANAGED_HOST_REL — UCI/runtime будут сняты)"
  fi
fi

if ! ask_yn "Записать профиль в state $STATE_HOSTS_DIR, затем развернуть в $DST_DIR и обновить UCI addnhosts?"; then
  say "Отменено пользователем."
  exit 0
fi

say "== Подготовка каталогов назначения =="
mkdir -p "/etc/dnsmasq.d" "$DST_DIR"
chmod 0755 "/etc/dnsmasq.d" "$DST_DIR" 2>/dev/null || true

if ! uci -q get dhcp.@dnsmasq[0] >/dev/null 2>&1; then
  say "Не найдена секция dhcp.@dnsmasq[0] в /etc/config/dhcp."
  say "Проверьте конфигурацию dnsmasq."
  exit 1
fi

sync_profile_hosts_to_state

: > "$TMP_LIST"
find "$STATE_HOSTS_DIR" -type f 2>/dev/null | sort > "$TMP_LIST"

say "== State → runtime ($DST_DIR) =="
uci_commit_needed=0
while IFS= read -r src; do
  [ -n "$src" ] || continue
  rel="${src#"$STATE_HOSTS_DIR"/}"
  dst_path="$DST_DIR/$rel"

  if deploy_hosts_file "$src" "$rel"; then
    if ! uci_addnhosts_present "$dst_path"; then
      uci add_list dhcp.@dnsmasq[0].addnhosts="$dst_path"
      say "Добавлено: list addnhosts '$dst_path'"
      uci_commit_needed=1
    else
      say "Запись уже присутствует: list addnhosts '$dst_path'"
    fi
  else
    warn "Файл не обновлён (пропуск): $dst_path — UCI не трогаем для этой цели"
  fi
done < "$TMP_LIST"

if prune_managed_additional_hosts; then
  uci_commit_needed=1
fi

if [ "$uci_commit_needed" = "1" ]; then
  uci commit dhcp
fi

say "== Перезапуск dnsmasq =="
/etc/init.d/dnsmasq restart

say "Готово."
say "State (экспорт): $STATE_HOSTS_DIR"
say "Runtime: $DST_DIR"
