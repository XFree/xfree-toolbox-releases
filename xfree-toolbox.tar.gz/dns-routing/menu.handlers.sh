#!/bin/sh
# Hand-written handlers for cli.run component=custom in dns-routing/menu.yaml.
# shellcheck shell=sh

dns_menu_choice_1() {
	run_dns_script_with_output "Применение https-dns-proxy" "$DNS_MENU_hdp_apply"
	run_dns_script_with_output "Применение DNS для выбранных сайтов" "$DNS_MENU_apply_inner"
	run_dns_script_with_output "Подмена имён (hosts)" "$DNS_MENU_apply_hosts" --yes
}

# Как iface_lists_apply_title: звёздочка, когда profile fqdn.d ≠ state.
dns_apply_lists_title() {
	label="Применить DNS для выбранных сайтов"
	if dns_routing_any_lists_out_of_sync; then
		label="Применить DNS для выбранных сайтов *"
	fi
	printf '%s' "$label"
}
