#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/ui.sh"
. "$ROOT_DIR/lib/upstreams.sh"

DNS_LIB_SH="$SCRIPT_DIR/lib.sh"
[ -f "$DNS_LIB_SH" ] || die "Не найден dns-routing/lib.sh: $DNS_LIB_SH"
# shellcheck disable=SC1090
. "$DNS_LIB_SH"

BASE_DIR="$ROOT_DIR"
# Callers know the toolbox tree — pin upstreams here (same as iface-routing).
# Do not rely on common_detect_project_root discovering a parent split-root.
UPSTREAMS_DIR="$(common_resolve_path "$BASE_DIR" "${UPSTREAMS_DIR:-upstreams}")"
export UPSTREAMS_DIR

WORK_FQDN_DIR=""
DNS_ID=""
DNS_HOST=""
DNS_TARGET=""
DNS_RESOLVER_URL=""

load_dns_context() {
    dns_id="$1"
    [ -n "$dns_id" ] || die "Не указан dns_id"

    dns_routing_ensure_dns_workspace "$dns_id"

    dns_conf="$DNS_DIR/$dns_id/config/dns.conf"
    [ -f "$dns_conf" ] || die "Не найден dns.conf: $dns_conf"

    unset \
        DNS_ID \
        DNS_HOST \
        DNS_TARGET \
        DNS_RESOLVER_URL \
        DNS_BOOTSTRAP_DNS \
        DNS_LISTEN_ADDR \
        DNS_LISTEN_PORT \
        2>/dev/null || true

    # shellcheck disable=SC1090
    . "$dns_conf"

    [ -n "${DNS_ID:-}" ] || die "dns.conf: не задан DNS_ID"
    [ -n "${DNS_TARGET:-}" ] || die "dns.conf: не задан DNS_TARGET"

    WORK_FQDN_DIR="$DNS_DIR/$DNS_ID/fqdn.d"
    mkdir -p "$WORK_FQDN_DIR"
}

select_dns_instance() {
    tmp="$(mktemp)"
    trap 'rm -f "$tmp"' EXIT INT TERM

    dns_routing_list_instances_tsv > "$tmp"

    if [ ! -s "$tmp" ]; then
        ui_msgbox "Выбор DNS" "Не найдены DNS-инстансы ни в https-dns-proxy, ни в профиле."
        return 1
    fi

    set --
    while IFS='|' read -r idx dns_id host target resolver_url; do
        [ -n "${dns_id:-}" ] || continue
        desc="$host"
        set -- "$@" "$dns_id" "$desc"
    done < "$tmp"

    choice="$(ui_menu "Выбор DNS" "Выберите DNS" 20 100 12 "$@" || true)"
    [ -n "${choice:-}" ] || return 1

    printf '%s\n' "$choice"

    trap - EXIT INT TERM
    rm -f "$tmp"
}

select_lists_for_dns() {
    dns_id="$1"
    TMP="$(mktemp -d)"
    trap 'rm -rf "$TMP"' EXIT INT TERM

    load_dns_context "$dns_id"

    upstreams_build_model_tsv "$BASE_DIR" "$TMP/entities.tsv" "$TMP/files.tsv"

    if [ ! -s "$TMP/entities.tsv" ]; then
        ui_msgbox "Выбор списков" "Не найдены доступные upstream-списки."
        return 1
    fi

    map_tmp="$TMP/map.tsv"
    ui_upstreams_build_label_map "$TMP/entities.tsv" "$map_tmp" "fqdn_only"
    [ -s "$map_tmp" ] || {
        ui_msgbox "Выбор списков" "Не найдены FQDN-списки для выбора."
        return 1
    }

    enabled_tags_tsv="$TMP/enabled-tags.tsv"
    upstreams_build_enabled_tags_tsv \
        "dns" \
        "$TMP/files.tsv" \
        "$WORK_FQDN_DIR" \
        "" \
        "fqdn_only" > "$enabled_tags_tsv"

    # Avoid $(...) so slang/EXIT traps inside selection do not fight caller TMP.
    selected_file="$TMP/selected.tags"
    : > "$selected_file"
    if ! ui_upstreams_select_tags_from_model \
        "Выбор списков: $DNS_HOST" \
        "Выберите списки для DNS $DNS_HOST ($DNS_TARGET)" \
        "$TMP/entities.tsv" \
        "$TMP/files.tsv" \
        "fqdn_only" \
        "" \
        "$enabled_tags_tsv" > "$selected_file"; then
        # Отмена чеклиста: без записи в fqdn.d; 2 — снова выбор DNS (main).
        return 2
    fi
    selected_tags="$(cat "$selected_file" 2>/dev/null || true)"

    if ! ui_have_whiptail; then
        return 1
    fi

    staged_fqdn="$TMP/staged-fqdn"
    mkdir -p "$staged_fqdn"
    choices_file="$TMP/choices.lst"
    : > "$choices_file"

    if [ -n "${selected_tags:-}" ]; then
        printf '%s\n' "$selected_tags" > "$choices_file"
        printf '%s\n' "$selected_tags" | while IFS= read -r tag; do
            [ -n "${tag:-}" ] || continue
            upstreams_stage_tag_files_from_model \
                "dns" \
                "$tag" \
                "$TMP/files.tsv" \
                "$staged_fqdn" \
                "" \
                "fqdn_only"
        done
    fi

    if upstreams_staging_selection_mismatch "$choices_file" "$staged_fqdn" ""; then
        ui_msgbox "DNS: ошибка материализации" "$(upstreams_staging_mismatch_message "$choices_file")"
        return 1
    fi

    upstreams_replace_dir_from_staged "$WORK_FQDN_DIR" "$staged_fqdn"
}

main() {
    dns_id="${1:-}"
    fixed_dns_id="${dns_id:-}"

    while true; do
        if [ -z "$dns_id" ]; then
            dns_id="$(select_dns_instance || true)"
            [ -n "${dns_id:-}" ] || exit 0
        fi

        select_lists_for_dns "$dns_id"
        rc=$?
        if [ -n "$fixed_dns_id" ]; then
            exit "$rc"
        fi
        dns_id=""
        case "$rc" in
            2) continue ;;
            *) exit "$rc" ;;
        esac
    done
}

main "$@"
