#!/bin/sh
# shellcheck shell=sh

# $0 is wrong when this file is sourced from rpcd / lib/selection. Callers
# (LuCI) set DNS_ROUTING_LIB_DIR to dns-routing/. CLI scripts leave it unset.
if [ -z "${DNS_ROUTING_LIB_DIR:-}" ]; then
    DNS_ROUTING_LIB_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
fi
SCRIPT_DIR="$DNS_ROUTING_LIB_DIR"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
DNS_DIR="${DNS_DIR:-$PROFILE_DIR/dns-routing/dns}"
GENERATED_DIR="$SCRIPT_DIR/generated"

dns_routing_truthy() {
    case "${1:-0}" in
        1|yes|true|on|ON|YES|TRUE)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# BusyBox `. dns.conf` keeps CR inside quoted values (DNS_LISTEN_PORT=$'5054\r').
dns_routing_strip_cr() {
    printf '%s' "${1:-}" | tr -d '\r'
}

dns_routing_dns_redirect_enabled() {
    dns_routing_truthy "${DNS_REDIRECT:-0}"
}

dns_routing_dhcp_server_conf_path() {
    profile_dir="$1"
    printf '%s/dns-routing/config/dhcp-server.conf' "${profile_dir%/}"
}

dns_routing_load_dhcp_server_conf() {
    conf_path="$1"

    CANARY_DOMAINS_ICLOUD='1'
    CANARY_DOMAINS_MOZILLA='1'
    FILTER_AAAA='0'

    [ -f "$conf_path" ] || return 0

    # shellcheck disable=SC1090
    . "$conf_path"
}

dns_routing_known_canary_domains() {
    printf '%s\n' \
        'mask.icloud.com' \
        'mask-h2.icloud.com' \
        'use-application-dns.net'
}

dns_routing_enabled_canary_domains() {
    icloud_flag="${1:-0}"
    mozilla_flag="${2:-0}"

    if dns_routing_truthy "$icloud_flag"; then
        printf '%s\n' 'mask.icloud.com' 'mask-h2.icloud.com'
    fi
    if dns_routing_truthy "$mozilla_flag"; then
        printf '%s\n' 'use-application-dns.net'
    fi
}

dns_routing_canary_dhcp_token() {
    domain="$1"
    [ -n "$domain" ] || return 0
    printf '/%s/\n' "$domain"
}

dns_routing_domain_in_space_list() {
    domain="$1"
    domain_list="$2"

    for item in $domain_list; do
        [ "$domain" = "$item" ] && return 0
    done

    return 1
}

dns_routing_collect_redirect_targets_from_root() {
    dns_root="$1"
    [ -d "$dns_root" ] || return 0

    for dns_conf in "$dns_root"/*/config/dns.conf; do
        [ -f "$dns_conf" ] || continue

        unset \
            DNS_ID \
            DNS_HOST \
            DNS_TARGET \
            DNS_RESOLVER_URL \
            DNS_BOOTSTRAP_DNS \
            DNS_LISTEN_ADDR \
            DNS_LISTEN_PORT \
            DNS_KIND \
            DNS_REDIRECT \
            2>/dev/null || true

        # shellcheck disable=SC1090
        . "$dns_conf"

        [ -n "${DNS_TARGET:-}" ] || continue
        dns_routing_dns_redirect_enabled || continue
        printf '%s\n' "$DNS_TARGET"
    done | sort -u
}

dns_routing_collect_managed_dhcp_tokens() {
    dns_root="$1"
    dhcp_server_conf="$2"
    out_file="$3"

    : > "$out_file"

    dns_routing_load_dhcp_server_conf "$dhcp_server_conf"
    dns_routing_collect_redirect_targets_from_root "$dns_root" >> "$out_file"
    dns_routing_enabled_canary_domains \
        "${CANARY_DOMAINS_ICLOUD:-1}" \
        "${CANARY_DOMAINS_MOZILLA:-1}" \
        | while IFS= read -r domain; do
            [ -n "$domain" ] || continue
            dns_routing_canary_dhcp_token "$domain"
        done >> "$out_file"

    sort -u "$out_file" -o "$out_file"
}

dns_routing_list_indexes() {
    uci show https-dns-proxy 2>/dev/null \
        | sed -n 's/^https-dns-proxy\.@https-dns-proxy\[\([0-9][0-9]*\)\]\.listen_port=.*/\1/p'
}

# UI label from profile dns.conf DNS_HOST, else fallback (URL hostname).
dns_routing_profile_display_host() {
    dns_id="$1"
    fallback="$2"
    conf="$DNS_DIR/$dns_id/config/dns.conf"

    if [ -f "$conf" ]; then
        host="$(
            unset DNS_HOST 2>/dev/null || true
            # shellcheck disable=SC1090
            . "$conf"
            printf '%s' "${DNS_HOST:-}"
        )"
        if [ -n "$host" ]; then
            printf '%s\n' "$host"
            return 0
        fi
    fi

    printf '%s\n' "$fallback"
}

dns_routing_list_uci_instances_tsv() {
    for idx in $(dns_routing_list_indexes); do
        base="https-dns-proxy.@https-dns-proxy[$idx]"

        resolver_url="$(uci -q get "$base.resolver_url" || true)"
        listen_addr="$(uci -q get "$base.listen_addr" || true)"
        listen_port="$(uci -q get "$base.listen_port" || true)"

        [ -n "$listen_port" ] || continue
        [ -n "$listen_addr" ] || listen_addr="127.0.0.1"
        [ -n "$resolver_url" ] || resolver_url="https-dns-proxy-$idx"

        url_host="$(common_url_host "$resolver_url")"
        dns_id="$(common_dns_id_from_url "$resolver_url")"
        host="$(dns_routing_profile_display_host "$dns_id" "$url_host")"

        printf '%s|%s|%s|%s#%s|%s\n' \
            "$idx" \
            "$dns_id" \
            "$host" \
            "$listen_addr" \
            "$listen_port" \
            "$resolver_url"
    done
}

dns_routing_list_profile_instances_tsv() {
    for dns_conf in "$DNS_DIR"/*/config/dns.conf; do
        [ -f "$dns_conf" ] || continue

        unset \
            DNS_ID \
            DNS_HOST \
            DNS_TARGET \
            DNS_RESOLVER_URL \
            DNS_BOOTSTRAP_DNS \
            DNS_LISTEN_ADDR \
            DNS_LISTEN_PORT \
            DNS_KIND \
            DNS_REDIRECT \
            2>/dev/null || true

        # shellcheck disable=SC1090
        . "$dns_conf"

        [ -n "${DNS_ID:-}" ] || continue
        [ -n "${DNS_TARGET:-}" ] || continue

        host="${DNS_HOST:-$DNS_ID}"
        resolver_url="${DNS_RESOLVER_URL:-profile}"

        printf 'profile|%s|%s|%s|%s\n' \
            "$DNS_ID" \
            "$host" \
            "$DNS_TARGET" \
            "$resolver_url"
    done
}

dns_routing_list_instances_tsv() {
    tmp_uci="$(mktemp)"

    dns_routing_list_uci_instances_tsv > "$tmp_uci"
    cat "$tmp_uci"

    dns_routing_list_profile_instances_tsv \
        | awk -F'|' -v uci="$tmp_uci" '
            BEGIN {
                while ((getline line < uci) > 0) {
                    split(line, parts, "|")
                    if (parts[2] != "") {
                        uci_ids[parts[2]] = 1
                    }
                }
                close(uci)
            }
            {
                if (!($2 in uci_ids)) {
                    print $0
                }
            }
        '

    rm -f "$tmp_uci"
}

dns_routing_write_dns_conf() {
    dns_id="$1"
    dns_dir="$DNS_DIR/$dns_id"
    dns_conf="$dns_dir/config/dns.conf"

    match="$(dns_routing_list_uci_instances_tsv | awk -F'|' -v id="$dns_id" '$2==id { print; exit }')"
    [ -n "$match" ] || die "DNS не найден в https-dns-proxy: $dns_id"

    idx="$(printf '%s\n' "$match" | awk -F'|' '{print $1}')"
    host="$(printf '%s\n' "$match" | awk -F'|' '{print $3}')"
    target="$(printf '%s\n' "$match" | awk -F'|' '{print $4}')"
    resolver_url="$(printf '%s\n' "$match" | awk -F'|' '{print $5}')"

    base="https-dns-proxy.@https-dns-proxy[$idx]"
    bootstrap_dns="$(uci -q get "$base.bootstrap_dns" || true)"
    listen_addr="$(uci -q get "$base.listen_addr" || true)"
    listen_port="$(uci -q get "$base.listen_port" || true)"

    mkdir -p "$dns_dir/config" "$dns_dir/fqdn.d"

    cat > "$dns_conf" <<EOF
DNS_ID='$dns_id'
DNS_HOST='$host'
DNS_REDIRECT='1'
DNS_TARGET='$target'
DNS_RESOLVER_URL='$resolver_url'
DNS_BOOTSTRAP_DNS='${bootstrap_dns:-}'
DNS_LISTEN_ADDR='${listen_addr:-127.0.0.1}'
DNS_LISTEN_PORT='${listen_port:-}'
EOF
}

dns_routing_ensure_dns_workspace() {
    dns_id="$1"
    [ -n "$dns_id" ] || die "dns_routing_ensure_dns_workspace: dns_id не задан"

    mkdir -p "$DNS_DIR/$dns_id/config" "$DNS_DIR/$dns_id/fqdn.d"

    if [ ! -f "$DNS_DIR/$dns_id/config/dns.conf" ]; then
        dns_routing_write_dns_conf "$dns_id"
    fi
}

# DNS_TARGET из workspace, который сейчас apply'ится (профиль/state), без UCI.
dns_routing_list_valid_targets_from_root() {
    dns_root="$1"
    [ -d "$dns_root" ] || return 0

    for dns_conf in "$dns_root"/*/config/dns.conf; do
        [ -f "$dns_conf" ] || continue

        unset \
            DNS_ID \
            DNS_HOST \
            DNS_TARGET \
            DNS_RESOLVER_URL \
            DNS_BOOTSTRAP_DNS \
            DNS_LISTEN_ADDR \
            DNS_LISTEN_PORT \
            DNS_KIND \
            DNS_REDIRECT \
            2>/dev/null || true

        # shellcheck disable=SC1090
        . "$dns_conf"

        [ -n "${DNS_TARGET:-}" ] || continue
        printf '%s\n' "$DNS_TARGET"
    done | sort -u
}

dns_routing_valid_target_in_list() {
    target="$1"
    targets_file="$2"
    [ -n "${target:-}" ] || return 1
    [ -f "$targets_file" ] || return 1
    grep -Fxq "$target" "$targets_file" 2>/dev/null
}

dns_routing_https_dns_proxy_profile_dir() {
    profile_dir="$1"
    printf '%s' "${profile_dir%/}/https-dns-proxy"
}

dns_routing_list_valid_targets_from_https_dns_proxy_profile() {
    profile_dir="$1"
    config_dir="$(dns_routing_https_dns_proxy_profile_dir "$profile_dir")"
    config_file="$config_dir/https-dns-proxy"

    [ -f "$config_file" ] || return 0

    if command -v uci >/dev/null 2>&1; then
        for idx in $(
            uci -c "$config_dir" show https-dns-proxy 2>/dev/null \
                | sed -n 's/^https-dns-proxy\.@https-dns-proxy\[\([0-9]\+\)\]\.listen_port=.*/\1/p'
        ); do
            base="https-dns-proxy.@https-dns-proxy[$idx]"
            listen_addr="$(uci -c "$config_dir" -q get "$base.listen_addr" 2>/dev/null || true)"
            listen_port="$(uci -c "$config_dir" -q get "$base.listen_port" 2>/dev/null || true)"

            [ -n "$listen_port" ] || continue
            [ -n "$listen_addr" ] || listen_addr="127.0.0.1"
            printf '%s#%s\n' "$listen_addr" "$listen_port"
        done | sort -u
        return 0
    fi

    awk '
        /^config https-dns-proxy/ {
            if (listen_port != "") {
                if (listen_addr == "") listen_addr = "127.0.0.1"
                print listen_addr "#" listen_port
            }
            listen_addr = "127.0.0.1"
            listen_port = ""
            next
        }
        $1 == "option" && $2 == "listen_addr" {
            listen_addr = $3
            gsub(/\047/, "", listen_addr)
            next
        }
        $1 == "option" && $2 == "listen_port" {
            listen_port = $3
            gsub(/\047/, "", listen_port)
            next
        }
        END {
            if (listen_port != "") {
                if (listen_addr == "") listen_addr = "127.0.0.1"
                print listen_addr "#" listen_port
            }
        }
    ' "$config_file" | sort -u
}

dns_routing_collect_valid_targets_for_apply() {
    dns_root="$1"
    profile_dir="$2"
    out_file="$3"

    {
        dns_routing_list_valid_targets_from_root "$dns_root"
        dns_routing_list_valid_targets_from_https_dns_proxy_profile "$profile_dir"
    } | awk 'NF && !seen[$0]++' | sort -u > "$out_file"
}

# Runtime mirror of profile dns instances (see dns-routing/apply.sh).
dns_routing_state_dns_dir() {
    printf '%s\n' "${DNS_ROUTING_STATE_DNS_DIR:-${XFREE_DNS_ROUTING_ROOT:-${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/dns-routing}/state/dns}"
}

# Compare *.lst under one instance fqdn.d (profile work vs system state).
# Returns 0 if out of sync (needs apply), 1 if identical.
dns_routing_instance_lists_out_of_sync() {
    dns_id="$1"
    work_dns_root="$2"
    state_dns_root="$3"

    [ -n "${dns_id:-}" ] || return 1
    [ -n "${work_dns_root:-}" ] || return 1
    [ -n "${state_dns_root:-}" ] || return 1

    wd="$work_dns_root/$dns_id/fqdn.d"
    sd="$state_dns_root/$dns_id/fqdn.d"
    tw="$(mktemp -d)" || return 1
    ts="$(mktemp -d)" || {
        rm -rf "$tw"
        return 1
    }

    if [ -d "$wd" ]; then
        for f in "$wd"/*.lst; do
            [ -f "$f" ] || continue
            cp -f "$f" "$tw/"
        done
    fi
    mkdir -p "$sd" 2>/dev/null || true
    if [ -d "$sd" ]; then
        for f in "$sd"/*.lst; do
            [ -f "$f" ] || continue
            cp -f "$f" "$ts/"
        done
    fi

    diff_ok=0
    if diff -qr "$tw" "$ts" >/dev/null 2>&1; then
        diff_ok=1
    fi
    rm -rf "$tw" "$ts"
    [ "$diff_ok" -eq 1 ] && return 1
    return 0
}

# Returns 0 if any profile DNS instance fqdn.d differs from system state.
dns_routing_any_lists_out_of_sync() {
    work_dns_root="${1:-${DNS_DIR:-}}"
    state_dns_root="${2:-}"

    [ -n "$work_dns_root" ] || work_dns_root="$(common_profile_dir "$ROOT_DIR")/dns-routing/dns"
    [ -n "$state_dns_root" ] || state_dns_root="$(dns_routing_state_dns_dir)"

    [ -d "$work_dns_root" ] || return 1

    for idir in "$work_dns_root"/*; do
        [ -d "$idir" ] || continue
        dns_id="$(basename "$idir")"
        [ -f "$idir/config/dns.conf" ] || continue
        if dns_routing_instance_lists_out_of_sync "$dns_id" "$work_dns_root" "$state_dns_root"; then
            return 0
        fi
    done
    return 1
}
