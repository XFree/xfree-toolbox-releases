#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"

list_https_dns_proxy_indexes() {
  uci show https-dns-proxy 2>/dev/null \
    | sed -n 's/^https-dns-proxy\.@https-dns-proxy\[\([0-9]\+\)\]\.listen_port=.*/\1/p'
}

dns_host_from_url() {
  local url host
  url="$1"
  host="${url#*://}"
  host="${host%%/*}"
  printf '%s\n' "$host"
}

print_dns_instance() {
  idx="$1"
  base="https-dns-proxy.@https-dns-proxy[$idx]"

  resolver_url="$(uci -q get "$base.resolver_url" || true)"
  bootstrap_dns="$(uci -q get "$base.bootstrap_dns" || true)"
  listen_addr="$(uci -q get "$base.listen_addr" || true)"
  listen_port="$(uci -q get "$base.listen_port" || true)"
  user_name="$(uci -q get "$base.user" || true)"
  group_name="$(uci -q get "$base.group" || true)"

  [ -n "$listen_port" ] || return 0
  [ -n "$listen_addr" ] || listen_addr="127.0.0.1"
  [ -n "$resolver_url" ] || resolver_url="https-dns-proxy-$idx"

  host="$(common_url_host "$resolver_url")"
  dns_id="$(common_dns_id_from_url "$resolver_url")"

  printf '=== DNS #%s ===\n' "$idx"
  printf 'id           : %s\n' "$dns_id"
  printf 'host         : %s\n' "$host"
  printf 'target       : %s#%s\n' "$listen_addr" "$listen_port"
  printf 'resolver_url : %s\n' "$resolver_url"
  printf 'bootstrap_dns: %s\n' "${bootstrap_dns:--}"
  printf 'user/group   : %s/%s\n' "${user_name:--}" "${group_name:--}"
  printf '\n'
}

main() {
  require_cmd uci

  config_listen_addr="$(uci -q get https-dns-proxy.config.listen_addr || true)"
  force_dns="$(uci -q get https-dns-proxy.config.force_dns || true)"
  force_dns_port="$(uci -q get https-dns-proxy.config.force_dns_port || true)"
  force_dns_src_interface="$(uci -q get https-dns-proxy.config.force_dns_src_interface || true)"
  heartbeat_domain="$(uci -q get https-dns-proxy.config.heartbeat_domain || true)"

  printf '=== https-dns-proxy: общий конфиг ===\n'
  printf 'listen_addr         : %s\n' "${config_listen_addr:--}"
  printf 'force_dns           : %s\n' "${force_dns:--}"
  printf 'force_dns_port      : %s\n' "${force_dns_port:--}"
  printf 'force_dns_src_iface : %s\n' "${force_dns_src_interface:--}"
  printf 'heartbeat_domain    : %s\n' "${heartbeat_domain:--}"
  printf '\n'

  found="0"
  for idx in $(list_https_dns_proxy_indexes); do
    found="1"
    print_dns_instance "$idx"
  done

  [ "$found" = "1" ] || die "Не найдены DNS-инстансы https-dns-proxy с listen_port"
}

main "$@"
