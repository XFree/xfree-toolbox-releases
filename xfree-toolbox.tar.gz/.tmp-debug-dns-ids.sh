#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)"
TMP="$(mktemp -d)"
STATE="$TMP/state"
mkdir -p "$STATE/dns-routing/generated" \
	"$STATE/dns-routing/state/dns/cloudflare-dns/config" \
	"$STATE/dns-routing/state/dns/plain/config"
printf "DNS_ID='cloudflare-dns'\nDNS_TARGET='127.0.0.1#5054'\n" \
	>"$STATE/dns-routing/state/dns/cloudflare-dns/config/dns.conf"
printf "DNS_ID='plain'\nDNS_TARGET='1.1.1.1#53'\n" \
	>"$STATE/dns-routing/state/dns/plain/config/dns.conf"
printf 'x|127.0.0.1#5054|cloudflare-dns|x.lst\n' >"$STATE/dns-routing/generated/dns-redirects.map"
export XFREE_STATE_ROOT="$STATE"
export TRAFFIC_PATH_ROOT="$ROOT"
# shellcheck disable=SC1091
. "$ROOT/diagnostics/lib/traffic-path.sh"
traffic_path_init_paths
echo "SECTIONS=$TRAFFIC_PATH_DNS_SECTIONS"
echo "MAP=$TRAFFIC_PATH_DNS_MAP"
ls -la "$TRAFFIC_PATH_DNS_SECTIONS"
echo "IDS:"
traffic_path_list_dns_ids
rm -rf "$TMP"
