#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib.sh"
if [ -f "$SCRIPT_DIR/lib/service.sh" ]; then
    # shellcheck disable=SC1090
    . "$SCRIPT_DIR/lib/service.sh"
fi

SKIP_SYNC=0

usage() {
    cat <<'EOF'
Использование:
  restart.sh [--no-sync]

Перезапуск zapret как кнопка Restart в LuCI:
  $ZAPRET_SYNC_CONFIG_SCRIPT  (UCI → $ZAPRET_OPT_DIR/config)
  $ZAPRET_INITD_SCRIPT restart

Опции:
  --no-sync   Только init.d restart, без sync_config.sh
  -h, --help  Справка
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --no-sync) SKIP_SYNC=1 ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
    shift
done

[ "$SKIP_SYNC" = "1" ] && export ZAPRET_RESTART_SKIP_SYNC=1

info "== Zapret: перезапуск сервиса =="
zapret_restart_service
success "Zapret перезапущен (sync_config + restart)."
