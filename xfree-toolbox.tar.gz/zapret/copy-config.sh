#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
COMMON_SH="$ROOT_DIR/lib/common.sh"

[ -f "$COMMON_SH" ] || {
  echo "[-] common.sh не найден: $COMMON_SH" >&2
  exit 1
}

# shellcheck disable=SC1090
. "$COMMON_SH"
# shellcheck disable=SC1090
. "$SCRIPT_DIR/lib.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/engine.sh"
zapret_engine_apply_vars
ZAPRET_SERVICE_LIB_SH="$SCRIPT_DIR/lib/service.sh"
if [ -f "$ZAPRET_SERVICE_LIB_SH" ]; then
  # shellcheck disable=SC1090
  . "$ZAPRET_SERVICE_LIB_SH"
fi

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
ZAPRET_PROFILE_DIR="${ZAPRET_PROFILE_DIR:-$PROFILE_DIR/zapret}"
SRC_CONFIG_FILE="${ZAPRET_CONFIG_FILE:-$ZAPRET_PROFILE_DIR/zapret}"
# Профильный ipset; runtime-путь — ZAPRET_IPSET_DIR после zapret_engine_apply_vars.
SRC_IPSET_DIR="${ZAPRET_SRC_IPSET_DIR:-$ZAPRET_PROFILE_DIR/ipset}"
SRC_FAKE_DIR="${ZAPRET_SRC_FAKE_DIR:-$ROOT_DIR/zapret/files/fake}"

DST_CONFIG_DIR="/etc/config"
DST_CONFIG_FILE="${ZAPRET_RUNTIME_UCI_FILE:-$DST_CONFIG_DIR/zapret}"
DST_IPSET_DIR="${ZAPRET_IPSET_DIR:-/opt/zapret/ipset}"
DST_FAKE_DIR="${ZAPRET_FAKE_DIR:-/opt/zapret/files/fake}"

ZAPRET_FAKE_OVERLAY_SH="$SCRIPT_DIR/lib/fake-overlay.sh"
if [ -f "$ZAPRET_FAKE_OVERLAY_SH" ]; then
  # shellcheck disable=SC1090
  . "$ZAPRET_FAKE_OVERLAY_SH"
fi



YES=0
SILENT=0
BACKUP=1
RESTART=1
FAKE_ONLY=0
BACKUP_ROOT="${BACKUP_ROOT:-$(common_backup_root)}"
BACKUP_KEEP="${BACKUP_KEEP:-$(common_backup_keep)}"

normalize_answer() {
  printf '%s' "$1" \
    | tr -d '\r\010\177' \
    | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' \
    | common_lower_ascii_stream
}

is_yes() {
  ans="$(normalize_answer "$1")"
  case "$ans" in
    y|yes|д|да|н) return 0 ;;
    *) return 1 ;;
  esac
}

is_no() {
  ans="$(normalize_answer "$1")"
  case "$ans" in
    n|no|нет|т|"") return 0 ;;
    *) return 1 ;;
  esac
}

confirm() {
  prompt="$1"

  if [ "$YES" -eq 1 ]; then
    return 0
  fi

  while true; do
    printf '%s [y/N]: ' "$prompt" >&2
    IFS= read -r answer || answer=""

    if is_yes "$answer"; then
      return 0
    fi

    if is_no "$answer"; then
      die "Операция отменена."
    fi

    printf 'Введите y/n, да/нет.\n' >&2
  done
}

backup_target() {
  target="$1"
  [ "$BACKUP" -eq 1 ] || return 0
  [ -e "$target" ] || return 0

  # Backup policy: config/ipset backup under common root; rotated by common_backup_rotate.
  prefix="$(basename "$target")"
  if [ -d "$target" ]; then
    backup="$(common_backup_dir "$target" zapret "$prefix" "$BACKUP_KEEP")"
  else
    backup="$(common_backup_file "$target" zapret "$prefix" "$BACKUP_KEEP" bak)"
  fi
  if [ -n "${backup:-}" ]; then
    info "Создан бэкап: $backup"
  fi
}

usage() {
  cat <<EOF2
Использование:
  $(basename "$0") [--yes] [--silent] [--no-backup] [--no-restart] [--fake-only]

  --fake-only   только overlay zapret/files/fake/*.bin → \$ZAPRET_FAKE_DIR
                (одноимённые файлы перезаписываются; прочих пакетных fake не трогает)

Переменные:
  PROFILE_DIR          каталог активного профиля
  ZAPRET_PROFILE_DIR   каталог zapret в профиле
  ZAPRET_CONFIG_FILE   файл конфига zapret
  ZAPRET_SRC_IPSET_DIR каталог ipset в профиле (по умолчанию $ZAPRET_PROFILE_DIR/ipset)
  ZAPRET_IPSET_DIR     каталог ipset (runtime: /opt/zapret/ipset или /opt/zapret2/ipset)
  ZAPRET_SRC_FAKE_DIR  каталог fake *.bin в toolbox (по умолчанию zapret/files/fake)
  ZAPRET_FAKE_DIR      runtime fake dir (/opt/zapret/files/fake или /opt/zapret2/files/fake)
  ZAPRET_ENGINE        zapret | zapret2
EOF2
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --silent) SILENT=1 ;;
    --no-backup) BACKUP=0 ;;
    --no-restart) RESTART=0 ;;
    --fake-only) FAKE_ONLY=1 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный параметр: $1" ;;
  esac
  shift
done

zapret_copy_config_restart() {
  if [ "$RESTART" -eq 0 ]; then
    info "Перезапуск zapret отключён (--no-restart)."
    return 0
  fi
  ZAPRET_RESTART_SCRIPT="$SCRIPT_DIR/restart.sh"
  if [ -x "$ZAPRET_RESTART_SCRIPT" ]; then
    sh "$ZAPRET_RESTART_SCRIPT"
  else
    zapret_restart_service
  fi
}

zapret_copy_config_fake() {
  say "== Копирование fake *.bin =="
  [ -d "$SRC_FAKE_DIR" ] || die "Нет каталога fake: $SRC_FAKE_DIR"
  info "Источник: $SRC_FAKE_DIR"
  info "Назначение: $DST_FAKE_DIR"
  info "Одноимённые файлы будут перезаписаны; прочие пакетные fake не удаляются."
  confirm "Скопировать fake *.bin в $DST_FAKE_DIR?"
  if type zapret_copy_fake_overlay >/dev/null 2>&1; then
    zapret_copy_fake_overlay "$DST_FAKE_DIR" "$SRC_FAKE_DIR"
  else
    die "Нет zapret/lib/fake-overlay.sh — fake *.bin не скопированы"
  fi
  success "Fake *.bin скопированы в $DST_FAKE_DIR"
  zapret_copy_config_restart
}

if [ "$FAKE_ONLY" -eq 1 ]; then
  zapret_copy_config_fake
  exit 0
fi

say "== Копирование конфига zapret, ipset и fake =="
info "Профиль zapret: $ZAPRET_PROFILE_DIR"
[ -f "$SRC_CONFIG_FILE" ] || die "Не найден файл: $SRC_CONFIG_FILE"

confirm "Скопировать конфиг zapret, списки ipset и fake-payloads?"

mkdir -p "$DST_CONFIG_DIR"
mkdir -p "$DST_IPSET_DIR"

info "Копирую основной конфиг: $SRC_CONFIG_FILE -> $DST_CONFIG_FILE"
backup_target "$DST_CONFIG_FILE"
cp -f "$SRC_CONFIG_FILE" "$DST_CONFIG_FILE"
chmod 600 "$DST_CONFIG_FILE" 2>/dev/null || true

if [ -d "$SRC_IPSET_DIR" ]; then
  found_any=0
  for f in "$SRC_IPSET_DIR"/*; do
    [ -e "$f" ] || continue
    dst="$DST_IPSET_DIR/$(basename "$f")"
    info "Копирую ipset: $(basename "$f")"
    backup_target "$dst"
    cp -f "$f" "$dst"
    found_any=1
  done

  if [ "$found_any" -eq 1 ]; then
    success "Файлы ipset скопированы в $DST_IPSET_DIR"
  else
    warn "Каталог ipset существует, но файлов для копирования нет"
  fi
else
  warn "Каталог ipset отсутствует: $SRC_IPSET_DIR"
fi

if type zapret_copy_fake_overlay >/dev/null 2>&1; then
  zapret_copy_fake_overlay "$DST_FAKE_DIR" "$SRC_FAKE_DIR"
else
  warn "Нет zapret/lib/fake-overlay.sh — fake *.bin не скопированы"
fi

success "Конфиг zapret, ipset и fake успешно скопированы."

ZAPRET_LIB_SH="$ROOT_DIR/zapret/lib.sh"
if [ -f "$ZAPRET_LIB_SH" ]; then
  # shellcheck disable=SC1090
  . "$ZAPRET_LIB_SH"
  zapret_refresh_all_enabled_section_deployed_sigs 2>/dev/null || true
fi

zapret_copy_config_restart
