#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/ui.sh"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_CFG="${PROFILE_CFG:-$PROFILE_DIR/zapret/zapret}"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/engine.sh"
zapret_engine_apply_vars
APPLIED_CFG="${APPLIED_CFG:-$ZAPRET_RUNTIME_UCI_FILE}"

extract_option_value() {
  cfg="$1"
  opt="$2"
  [ -f "$cfg" ] || {
    printf '\n'
    return 0
  }
  awk -v name="$opt" '
    $0 ~ "^[[:space:]]*option[[:space:]]+" name "[[:space:]]+'\''" {
      line=$0
      sub("^[[:space:]]*option[[:space:]]+" name "[[:space:]]+'\''", "", line)
      sub(/'\''[[:space:]]*$/, "", line)
      print line
      exit
    }
  ' "$cfg"
}

port_token_overlap() {
  left="$1"
  right="$2"

  l_start="$left"
  l_end="$left"
  case "$left" in
    *-*) l_start="${left%-*}"; l_end="${left#*-}" ;;
  esac

  r_start="$right"
  r_end="$right"
  case "$right" in
    *-*) r_start="${right%-*}"; r_end="${right#*-}" ;;
  esac

  case "$l_start$l_end$r_start$r_end" in
    *[!0-9]*) return 1 ;;
  esac
  [ "$l_start" -le "$r_end" ] && [ "$r_start" -le "$l_end" ]
}

collect_firewall_redirect_ports() {
  command -v uci >/dev/null 2>&1 || return 0
  for sec in $(uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=redirect$/\1/p"); do
    [ -n "${sec:-}" ] || continue
    src_dport="$(uci -q get "$sec.src_dport" 2>/dev/null || true)"
    dest_port="$(uci -q get "$sec.dest_port" 2>/dev/null || true)"
    name="$(uci -q get "$sec.name" 2>/dev/null || true)"
    [ -n "$name" ] || name="$sec"
    for field in "$src_dport" "$dest_port"; do
      [ -n "${field:-}" ] || continue
      printf '%s\n' "$field" | tr ' ,' '\n\n' | sed 's/[[:space:]]//g; /^$/d' | while IFS= read -r token; do
        printf '%s|%s|%s\n' "$sec" "$name" "$token"
      done
    done
  done | sort -u
}

collect_forwarding_ports_csv() {
  ports="$(
    collect_firewall_redirect_ports \
      | awk -F'|' '{ print $3 }' \
      | sed '/^$/d' \
      | sort -u \
      | awk 'BEGIN{first=1} { if(!first) printf ","; printf "%s",$0; first=0 } END{ printf "\n" }'
  )"
  printf '%s\n' "${ports:-}"
}

find_conflicts() {
  ports_csv="$1"
  proto="$2"
  [ -n "${ports_csv:-}" ] || return 0

  tmp_ports="$(mktemp)"
  tmp_fw="$(mktemp)"
  printf '%s\n' "$ports_csv" | tr ',' '\n' | sed 's/[[:space:]]//g; /^$/d' | sort -u > "$tmp_ports"
  collect_firewall_redirect_ports > "$tmp_fw"

  while IFS='|' read -r sec name fw_port; do
    [ -n "${fw_port:-}" ] || continue
    while IFS= read -r nfq_port; do
      [ -n "${nfq_port:-}" ] || continue
      if port_token_overlap "$nfq_port" "$fw_port"; then
        printf '%s|%s|%s|%s|%s\n' "$proto" "$sec" "$name" "$fw_port" "$nfq_port"
      fi
    done < "$tmp_ports"
  done < "$tmp_fw" | sort -u

  rm -f "$tmp_ports" "$tmp_fw"
}

print_conflict_block() {
  title="$1"
  tcp_ports="$2"
  udp_ports="$3"

  echo "=== $title ==="
  echo "TCP ports: ${tcp_ports:-<empty>}"
  echo "UDP ports: ${udp_ports:-<empty>}"

  tcp_conflicts="$(find_conflicts "$tcp_ports" tcp || true)"
  udp_conflicts="$(find_conflicts "$udp_ports" udp || true)"
  all_conflicts="$(printf '%s\n%s\n' "$tcp_conflicts" "$udp_conflicts" | sed '/^$/d' | sort -u)"

  if [ -z "${all_conflicts:-}" ]; then
    echo "Port forwarding conflicts: none"
    echo
    return 0
  fi

  echo "Port forwarding conflicts:"
  printf '%s\n' "$all_conflicts" | while IFS='|' read -r proto sec name fw_port nfq_port; do
    echo "  - [$proto] $name ($sec): forwarding_port=$fw_port vs nfqws_port=$nfq_port"
  done
  echo
}

main() {
  report_file="$(mktemp)"
  trap 'rm -f "$report_file"' EXIT INT TERM

  if ! command -v uci >/dev/null 2>&1; then
    warn "uci не найден. Проверка port forwarding конфликтов недоступна."
    exit 0
  fi

  profile_tcp="$(extract_option_value "$PROFILE_CFG" "${ZAPRET_PORTS_TCP_KEY:-NFQWS_PORTS_TCP}")"
  profile_udp="$(extract_option_value "$PROFILE_CFG" "${ZAPRET_PORTS_UDP_KEY:-NFQWS_PORTS_UDP}")"
  applied_tcp="$(extract_option_value "$APPLIED_CFG" "${ZAPRET_PORTS_TCP_KEY:-NFQWS_PORTS_TCP}")"
  applied_udp="$(extract_option_value "$APPLIED_CFG" "${ZAPRET_PORTS_UDP_KEY:-NFQWS_PORTS_UDP}")"

  {
    fw_ports="$(collect_forwarding_ports_csv)"
    echo "PORT FORWARDING ports: ${fw_ports:-<none>}"
    echo
    [ -f "$PROFILE_CFG" ] || warn "Профильный конфиг не найден: $PROFILE_CFG"
    [ -f "$APPLIED_CFG" ] || warn "Примененный конфиг не найден: $APPLIED_CFG"
    print_conflict_block "PROFILE ($PROFILE_CFG)" "$profile_tcp" "$profile_udp"
    print_conflict_block "APPLIED ($APPLIED_CFG)" "$applied_tcp" "$applied_udp"
  } > "$report_file" 2>&1

  cat "$report_file"
  if ui_have_whiptail; then
    ui_show_textbox "Zapret: диагностика портов" "$report_file" 28 120
  fi
}

main "$@"

