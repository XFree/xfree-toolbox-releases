#!/bin/sh
# shellcheck shell=sh
# Движок zapret (nfqws1) vs zapret2 (nfqws2 / remittor master).
# Zapret2 только явно: env ZAPRET_ENGINE=zapret2 (меню zapret/menu-zapret2.sh).
# engine.conf — запись после apply, не источник истины (шаблоны/bootstrap всегда nfqws1).

zapret_engine_conf_path() {
    if [ -n "${ZAPRET_ENGINE_CONF:-}" ]; then
        printf '%s\n' "$ZAPRET_ENGINE_CONF"
        return 0
    fi
    if [ -n "${PROFILE_DIR:-}" ]; then
        printf '%s/zapret/engine.conf\n' "$PROFILE_DIR"
        return 0
    fi
    if type zapret_profile_root >/dev/null 2>&1; then
        printf '%s/engine.conf\n' "$(zapret_profile_root)"
        return 0
    fi
    printf '%s\n' ""
}

zapret_engine_normalize() {
    case "$1" in
        zapret2|2|nfqws2) printf '%s\n' "zapret2" ;;
        zapret|zapret1|1|nfqws|nfqws1|"") printf '%s\n' "zapret" ;;
        *) printf '%s\n' "zapret" ;;
    esac
}

zapret_engine_read_conf() {
    conf="$(zapret_engine_conf_path)"
    [ -n "$conf" ] && [ -f "$conf" ] || return 1
    awk -F"'" '
        /^ZAPRET_ENGINE=/ {
            v=$2
            if (v == "") {
                v=$0
                sub(/^ZAPRET_ENGINE=/, "", v)
                gsub(/["'\'']/, "", v)
            }
            gsub(/[[:space:]]/, "", v)
            print v
            exit
        }
    ' "$conf"
}

# stdout: zapret | zapret2
# Без явного env — всегда zapret (обновление шаблонов, bootstrap, CLI apply).
zapret_engine_name() {
    if [ -n "${ZAPRET_ENGINE:-}" ]; then
        zapret_engine_normalize "$ZAPRET_ENGINE"
        return 0
    fi
    printf '%s\n' "zapret"
}

zapret_engine_is_zapret2() {
    [ "$(zapret_engine_name)" = "zapret2" ]
}

zapret_engine_persist() {
    eng="$(zapret_engine_name)"
    conf="$(zapret_engine_conf_path)"
    [ -n "$conf" ] || return 0
    mkdir -p "$(dirname -- "$conf")"
    printf "ZAPRET_ENGINE='%s'\n" "$eng" >"$conf"
}

# Выставляет пути пакета/runtime под текущий движок (идемпотентно).
zapret_engine_apply_vars() {
    eng="$(zapret_engine_name)"
    export ZAPRET_ENGINE="$eng"

    if [ "$eng" = "zapret2" ]; then
        export ZAPRET_PKG_NAME="${ZAPRET_PKG_NAME_OVERRIDE:-zapret2}"
        export ZAPRET_LUCI_PKG_NAME="${ZAPRET_LUCI_PKG_NAME_OVERRIDE:-luci-app-zapret2}"
        export ZAPRET_OPT_DIR="${ZAPRET_OPT_DIR_OVERRIDE:-/opt/zapret2}"
        export ZAPRET_NFQWS_BIN="${ZAPRET_NFQWS_BIN_OVERRIDE:-/opt/zapret2/nfq2/nfqws2}"
        export ZAPRET_SYNC_SCRIPT="${ZAPRET_SYNC_SCRIPT_OVERRIDE:-/opt/zapret2/sync_config.sh}"
        export ZAPRET_SYNC_CONFIG_SCRIPT="$ZAPRET_SYNC_SCRIPT"
        export ZAPRET_INITD_SCRIPT="${ZAPRET_INITD_SCRIPT_OVERRIDE:-/etc/init.d/zapret2}"
        export ZAPRET_UCI_NAME="zapret2"
        export ZAPRET_RUNTIME_UCI_FILE="${ZAPRET_RUNTIME_UCI_FILE_OVERRIDE:-/etc/config/zapret2}"
        export ZAPRET_IPSET_DIR="${ZAPRET_IPSET_DIR_OVERRIDE:-/opt/zapret2/ipset}"
        export ZAPRET_FAKE_DIR="${ZAPRET_FAKE_DIR_OVERRIDE:-/opt/zapret2/files/fake}"
        export ZAPRET_OPT_KEY="NFQWS2_OPT"
        export ZAPRET_PORTS_TCP_KEY="NFQWS2_PORTS_TCP"
        export ZAPRET_PORTS_UDP_KEY="NFQWS2_PORTS_UDP"
        export PROFILE_CFG_TEMPLATE_NAME="${PROFILE_CFG_TEMPLATE_NAME_OVERRIDE:-zapret.template.v2}"
        export ZAPRET_OTHER_INITD="/etc/init.d/zapret"
        export ZAPRET_LABEL="Zapret2"
    else
        export ZAPRET_PKG_NAME="${ZAPRET_PKG_NAME_OVERRIDE:-zapret}"
        export ZAPRET_LUCI_PKG_NAME="${ZAPRET_LUCI_PKG_NAME_OVERRIDE:-luci-app-zapret}"
        export ZAPRET_OPT_DIR="${ZAPRET_OPT_DIR_OVERRIDE:-/opt/zapret}"
        export ZAPRET_NFQWS_BIN="${ZAPRET_NFQWS_BIN_OVERRIDE:-/opt/zapret/nfq/nfqws}"
        export ZAPRET_SYNC_SCRIPT="${ZAPRET_SYNC_SCRIPT_OVERRIDE:-/opt/zapret/sync_config.sh}"
        export ZAPRET_SYNC_CONFIG_SCRIPT="$ZAPRET_SYNC_SCRIPT"
        export ZAPRET_INITD_SCRIPT="${ZAPRET_INITD_SCRIPT_OVERRIDE:-/etc/init.d/zapret}"
        export ZAPRET_UCI_NAME="zapret"
        export ZAPRET_RUNTIME_UCI_FILE="${ZAPRET_RUNTIME_UCI_FILE_OVERRIDE:-/etc/config/zapret}"
        export ZAPRET_IPSET_DIR="${ZAPRET_IPSET_DIR_OVERRIDE:-/opt/zapret/ipset}"
        export ZAPRET_FAKE_DIR="${ZAPRET_FAKE_DIR_OVERRIDE:-/opt/zapret/files/fake}"
        export ZAPRET_OPT_KEY="NFQWS_OPT"
        export ZAPRET_PORTS_TCP_KEY="NFQWS_PORTS_TCP"
        export ZAPRET_PORTS_UDP_KEY="NFQWS_PORTS_UDP"
        export PROFILE_CFG_TEMPLATE_NAME="${PROFILE_CFG_TEMPLATE_NAME_OVERRIDE:-zapret.template}"
        export ZAPRET_OTHER_INITD="/etc/init.d/zapret2"
        export ZAPRET_LABEL="Zapret"
    fi
}

# Остановить/выключить противоположный пакет, чтобы два NFQUEUE не работали сразу.
zapret_engine_stop_other() {
    other="${ZAPRET_OTHER_INITD:-}"
    [ -n "$other" ] || return 0
    if [ -x "$other" ]; then
        "$other" stop >/dev/null 2>&1 || true
        "$other" disable >/dev/null 2>&1 || true
    elif [ -f "$other" ]; then
        sh "$other" stop >/dev/null 2>&1 || true
        sh "$other" disable >/dev/null 2>&1 || true
    fi
}
