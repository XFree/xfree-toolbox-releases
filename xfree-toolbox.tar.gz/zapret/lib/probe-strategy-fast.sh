#!/bin/sh
# shellcheck shell=sh
# Быстрый легковесный автоподборщик стратегий Zapret на интерфейсе WAN.
# Без перезапуска системного демона zapret и без сброса firewall.
# Изолирован от политик маршрутизации (VPN / fqdn-sets / bypass).

: "${XFREE_ZAPRET_FAST_PROBE_QNUM:=59780}"
: "${XFREE_ZAPRET_FAST_PROBE_TIMEOUT:=3}"
: "${XFREE_ZAPRET_FAST_PROBE_CONN_TIMEOUT:=2}"

zapret_fast_probe_wan_if() {
	# 1. Поиск интерфейса по дефолтному IPv4-маршруту
	_dev="$(ip -4 route show default 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev") print $(i+1)}' | head -n1)"
	if [ -n "$_dev" ]; then
		printf '%s\n' "$_dev"
		return 0
	fi
	# 2. Поиск из nft-сета @wanif
	_dev="$(nft list set inet zapret wanif 2>/dev/null | grep -oE '"[^"]+"' | tr -d '"' | head -n1 || true)"
	if [ -n "$_dev" ]; then
		printf '%s\n' "$_dev"
		return 0
	fi
	# 3. Fallback
	printf 'pppoe-wan\n'
}

zapret_fast_probe_resolve_ip() {
	_host="${1:-www.youtube.com}"
	if command -v resolveip >/dev/null 2>&1; then
		_ip="$(resolveip -4 "$_host" 2>/dev/null | head -n1 || true)"
		if [ -n "$_ip" ]; then
			printf '%s\n' "$_ip"
			return 0
		fi
	fi
	if command -v nslookup >/dev/null 2>&1; then
		_ip="$(nslookup "$_host" 2>/dev/null | grep -E 'Address:[[:space:]]+[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | awk '{print $NF}' | head -n1 || true)"
		if [ -n "$_ip" ]; then
			printf '%s\n' "$_ip"
			return 0
		fi
	fi
	printf '%s\n' "142.251.152.4"
}

zapret_fast_probe_setup_nft() {
	_wan_if="$1"
	_qnum="$2"
	_test_ip="${3:-}"
	_proto="${4:-4}"

	# Очистка предыдущих правил, если остались
	zapret_fast_probe_cleanup_nft "$_qnum"

	# 1. notrack для пакетов десинхронизации (чтобы conntrack не сбрасывал их правилом ct state invalid)
	nft insert rule inet zapret predefrag meta mark \& 0x40000000 \!= 0 notrack comment "xfree_probe_notrack" 2>/dev/null || true

	# 2. Изоляция тестового трафика от боевой очереди nfqws (qnum=200):
	# insert добавляет в начало цепочки, поэтому сначала вставляем return, а перед ним — тестовую queue.
	_ip_filter=""
	if [ -n "$_test_ip" ]; then
		if [ "$_proto" = "6" ]; then
			_ip_filter="ip6 daddr $_test_ip"
		else
			_ip_filter="ip daddr $_test_ip"
		fi
	fi
	# shellcheck disable=SC2086
	nft insert rule inet zapret postnat oifname "$_wan_if" $_ip_filter tcp dport { 80, 443 } return comment "xfree_probe_queue" 2>/dev/null || true
	# shellcheck disable=SC2086
	nft insert rule inet zapret postnat oifname "$_wan_if" $_ip_filter tcp dport { 80, 443 } ct original packets 1-9 meta mark set meta mark \| 0x20000000 ct mark set ct mark \| 0x40000000 queue flags bypass to "$_qnum" comment "xfree_probe_queue" 2>/dev/null || true
}

zapret_fast_probe_cleanup_nft() {
	_qnum="${1:-$XFREE_ZAPRET_FAST_PROBE_QNUM}"
	# Удаление правила очереди
	nft -a list chain inet zapret postnat 2>/dev/null | grep 'xfree_probe_queue' | awk '{print $NF}' | while read -r _h; do
		[ -n "$_h" ] || continue
		nft delete rule inet zapret postnat handle "$_h" 2>/dev/null || true
	done
	# Удаление правила notrack
	nft -a list chain inet zapret predefrag 2>/dev/null | grep 'xfree_probe_notrack' | awk '{print $NF}' | while read -r _h; do
		[ -n "$_h" ] || continue
		nft delete rule inet zapret predefrag handle "$_h" 2>/dev/null || true
	done
}

zapret_fast_probe_extract_args() {
	_conf="$1"
	[ -f "$_conf" ] || return 1
	tr -d '\r' < "$_conf" | awk '{
		if (/^[[:space:]]*$/ || /^[[:space:]]*[#;]/) next;
		if (/--new/) exit;
		if (!index($0, "{{SELECT_LIST}}") && !index($0, "{{SELECT_EXCLUDE_LIST}}")) print;
	}' | tr '\n' ' '
}

zapret_fast_probe_dry_run() {
	_qnum="$1"
	shift
	_nfqws="/opt/zapret/nfq/nfqws"
	[ -x "$_nfqws" ] || return 0
	# shellcheck disable=SC2086
	"$_nfqws" --qnum="$_qnum" --dry-run "$@" >/dev/null 2>&1
}

zapret_fast_probe_test_strategy() {
	_qnum="$1"
	_pidfile="$2"
	_wan_if="$3"
	_host="$4"
	_test_ip="$5"
	_timeout="$6"
	shift 6
	_args="$*"

	_nfqws="/opt/zapret/nfq/nfqws"
	if [ ! -x "$_nfqws" ]; then
		printf 'NO_NFQWS\n'
		return 1
	fi

	# Проверка синтаксиса
	if ! zapret_fast_probe_dry_run "$_qnum" $_args; then
		printf 'FAIL_SYNTAX\n'
		return 1
	fi

	# Очистка возможного зависшего процесса от прерванного теста
	if [ -f "$_pidfile" ]; then
		_old_pid="$(cat "$_pidfile" 2>/dev/null || true)"
		[ -n "$_old_pid" ] && kill "$_old_pid" 2>/dev/null || true
		rm -f "$_pidfile"
	fi

	# Запуск эфемерного nfqws на тестовой очереди
	# shellcheck disable=SC2086
	"$_nfqws" --qnum="$_qnum" --dpi-desync-fwmark=0x40000000 $_args --daemon --pidfile="$_pidfile" >/dev/null 2>&1 || {
		printf 'FAIL_START\n'
		return 1
	}
	sleep 0.1

	# Вызов curl на WAN с привязкой к IP и SNI
	_resolve_arg=""
	if [ -n "$_test_ip" ]; then
		_resolve_arg="--resolve ${_host}:443:${_test_ip}"
	fi

	# shellcheck disable=SC2086
	_curl_out="$(curl -4 -s -o /dev/null -w "%{http_code} %{time_total}" \
		--connect-timeout "$XFREE_ZAPRET_FAST_PROBE_CONN_TIMEOUT" \
		-m "$_timeout" \
		--interface "$_wan_if" \
		$_resolve_arg \
		"https://${_host}/" 2>/dev/null || echo "000 0.000")"

	# Завершение эфемерного nfqws
	if [ -f "$_pidfile" ]; then
		_pid="$(cat "$_pidfile" 2>/dev/null || true)"
		if [ -n "$_pid" ]; then
			kill "$_pid" 2>/dev/null || true
		fi
		rm -f "$_pidfile"
	fi

	_code="$(printf '%s' "$_curl_out" | awk '{print $1}')"
	_latency="$(printf '%s' "$_curl_out" | awk '{print $2}')"
	_latency="${_latency:-0.000}"

	case "$_host:$_code" in
		latency.discord.media:200|latency.discord.media:204|latency.discord.media:403|latency.discord.media:404|latency.discord.media:520)
			printf 'PASS %s %s\n' "$_code" "$_latency"
			return 0
			;;
		*:200|*:204|*:301|*:302|*:307|*:308)
			printf 'PASS %s %s\n' "$_code" "$_latency"
			return 0
			;;
		*)
			printf 'FAIL %s %s\n' "$_code" "$_latency"
			return 1
			;;
	esac
}

zapret_fast_probe_discord_strategies() {
	cat <<'EOF'
discord_canonical	--filter-tcp=80,443 --dpi-desync=fake --dpi-desync-repeats=3 --dpi-desync-fooling=ts --dpi-desync-any-protocol=1 --dpi-desync-cutoff=0 --dpi-desync-fake-tls=/opt/zapret/files/fake/stun2.bin --dpi-desync-fake-http=/opt/zapret/files/fake/tls_clienthello_max_ru.bin
discord_multisplit	--filter-tcp=443 --dpi-desync=fake,multisplit --dpi-desync-split-pos=2,sld --dpi-desync-fake-tls=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin --dpi-desync-split-seqovl=620 --dpi-desync-split-seqovl-pattern=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin --dpi-desync-fooling=badsum,badseq
discord_disorder2	--filter-tcp=443 --dpi-desync=fake,disorder2 --dpi-desync-split-pos=1,midsld --dpi-desync-fake-tls=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin --dpi-desync-fooling=badsum,badseq
discord_split2	--filter-tcp=443 --dpi-desync=fake,split2 --dpi-desync-split-pos=2 --dpi-desync-fake-tls=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin --dpi-desync-fooling=badsum,badseq
discord_multidisorder	--filter-tcp=443 --dpi-desync=multidisorder --dpi-desync-split-pos=1,sld --dpi-desync-fooling=badsum,badseq
discord_fake_google	--filter-tcp=443 --dpi-desync=fake,multisplit --dpi-desync-split-pos=2,sld --dpi-desync-fake-tls=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-fooling=badsum,badseq
EOF
}

zapret_fast_probe_discord_media_strategies() {
	cat <<'EOF'
discord_media_fakedsplit	--filter-tcp=443 --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls=/opt/zapret/files/fake/stun2.bin --dpi-desync-fake-http=/opt/zapret/files/fake/tls_clienthello_max_ru.bin
discord_media_multisplit_seqovl	--filter-tcp=443 --dpi-desync=fake,multisplit --dpi-desync-split-pos=2,sld --dpi-desync-fake-tls=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin --dpi-desync-split-seqovl=620 --dpi-desync-split-seqovl-pattern=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin --dpi-desync-fooling=badsum,badseq
discord_media_fake_max_ru	--filter-tcp=443 --dpi-desync=fake,fakeddisorder --dpi-desync-split-pos=10,midsld --dpi-desync-fake-tls=/opt/zapret/files/fake/tls_clienthello_max_ru.bin --dpi-desync-split-seqovl=336 --dpi-desync-split-seqovl-pattern=/opt/zapret/files/fake/tls_clienthello_www_sferum_ru.bin --dpi-desync-fooling=badseq,badsum
discord_media_canonical	--filter-tcp=443 --dpi-desync=fake --dpi-desync-repeats=3 --dpi-desync-fooling=ts --dpi-desync-any-protocol=1 --dpi-desync-cutoff=0 --dpi-desync-fake-tls=/opt/zapret/files/fake/stun2.bin
EOF
}

zapret_fast_probe_discord_voice_strategies() {
	cat <<'EOF'
discord_voice_quic_google	--filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-stun=/opt/zapret/files/fake/quic_initial_www_google_com.bin --dpi-desync-fake-discord=/opt/zapret/files/fake/quic_initial_www_google_com.bin
discord_voice_stun2	--filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-stun=/opt/zapret/files/fake/stun2.bin --dpi-desync-fake-discord=/opt/zapret/files/fake/ACTIVE_DISCORD_UDP.bin
EOF
}

# Assemble a Discord section from selected per-component strategies.
# $1=target_section (e.g. "discord" or custom "discord_bluehome")
# $2=web_strategy, $3=media_strategy, $4=voice_strategy (any may be "-" for default)
zapret_fast_probe_compose_discord_section() {
	_target="$(printf '%s' "${1:-discord}" | tr -cd 'A-Za-z0-9._-')"
	[ -n "$_target" ] || _target="discord"
	_web="${2:-discord_canonical}"
	_media="${3:-discord_media_fakedsplit}"
	_voice="${4:-discord_voice_quic_google}"

	_sections_root="$(zapret_sections_root)"
	_src_dir="$_sections_root/discord"
	_dst_dir="$_sections_root/$_target"

	# If creating a new custom section, clone lists & section.conf from discord
	if [ "$_target" != "discord" ] && [ -d "$_src_dir" ]; then
		mkdir -p "$_dst_dir/config" "$_dst_dir/fqdn.d" "$_dst_dir/prefixes.d" "$_dst_dir/fqdn.exclude.d"
		for _sub in fqdn.d prefixes.d fqdn.exclude.d; do
			if [ -d "$_src_dir/$_sub" ]; then
				cp -f "$_src_dir/$_sub"/* "$_dst_dir/$_sub"/ 2>/dev/null || true
			fi
		done
		if [ -f "$_src_dir/config/section.conf" ] && [ ! -f "$_dst_dir/config/section.conf" ]; then
			cp -f "$_src_dir/config/section.conf" "$_dst_dir/config/section.conf"
		fi
		# Append to sections.order if missing
		_order_file="$(zapret_sections_order_file)"
		if [ -f "$_order_file" ] && ! grep -Fx "$_target" "$_order_file" >/dev/null 2>&1; then
			printf '%s\n' "$_target" >> "$_order_file"
		fi
	fi

	mkdir -p "$_dst_dir/config"
	_dst_conf="$_dst_dir/config/section.text"

	_w_args="$(zapret_fast_probe_discord_strategies | awk -F'\t' -v b="$_web" '$1==b {print $2}')"
	[ -n "$_w_args" ] || _w_args="$(zapret_fast_probe_discord_strategies | head -n1 | cut -f2)"
	_w_clean="$(printf '%s' "$_w_args" | sed 's/--filter-tcp=[0-9,]*//g; s/^[[:space:]]*//; s/ --/ \n--/g')"

	_m_args="$(zapret_fast_probe_discord_media_strategies | awk -F'\t' -v b="$_media" '$1==b {print $2}')"
	[ -n "$_m_args" ] || _m_args="$(zapret_fast_probe_discord_media_strategies | head -n1 | cut -f2)"
	_m_clean="$(printf '%s' "$_m_args" | sed 's/--filter-tcp=[0-9,]*//g; s/^[[:space:]]*//; s/ --/ \n--/g')"

	_v_args="$(zapret_fast_probe_discord_voice_strategies | awk -F'\t' -v b="$_voice" '$1==b {print $2}')"
	[ -n "$_v_args" ] || _v_args="$(zapret_fast_probe_discord_voice_strategies | head -n1 | cut -f2)"
	_v_clean="$(printf '%s' "$_v_args" | sed 's/ --/ \n--/g')"

	{
		printf '# 1. Основные домены Discord (Web / API / Gateway, TCP 80, 443) [%s]\n' "$_web"
		printf -- '--filter-tcp=80,443\n'
		printf '{{SELECT_LIST}}\n'
		printf '{{SELECT_EXCLUDE_LIST}}\n'
		printf '%s\n' "$_w_clean"
		printf -- '--new\n'
		printf '# 2. QUIC / HTTP3 трафик Discord (UDP 443)\n'
		printf -- '--filter-udp=443\n'
		printf -- '--filter-l7=discord\n'
		printf -- '--dpi-desync=fake\n'
		printf -- '--dpi-desync-repeats=3\n'
		printf -- '--new\n'
		printf '# 3. Голосовые каналы и звонки Discord (Voice / WebRTC STUN, UDP) [%s]\n' "$_voice"
		printf '%s\n' "$_v_clean"
		printf -- '--new\n'
		printf '# 4. Медиа-серверы и демонстрация экрана (discord.media / Screen Share, TCP) [%s]\n' "$_media"
		printf -- '--filter-tcp=2053,2083,2087,2096,8443\n'
		printf -- '--hostlist-domains=discord.media\n'
		printf '%s\n' "$_m_clean"
	} | sed 's/[[:space:]]*$//' > "$_dst_conf"
}

zapret_fast_probe_test_udp_voice() {
	_qnum="$1"
	_pidfile="$2"
	_wan_if="$3"
	_stun_host="${4:-stun.l.google.com}"
	shift 4
	_args="$*"

	_nfqws="/opt/zapret/nfq/nfqws"
	if [ ! -x "$_nfqws" ]; then
		printf 'NO_NFQWS\n'
		return 1
	fi
	if ! zapret_fast_probe_dry_run "$_qnum" $_args; then
		printf 'FAIL_SYNTAX\n'
		return 1
	fi
	# shellcheck disable=SC2086
	"$_nfqws" --qnum="$_qnum" --dpi-desync-fwmark=0x40000000 $_args --daemon --pidfile="$_pidfile" >/dev/null 2>&1 || {
		printf 'FAIL_START\n'
		return 1
	}
	sleep 0.1

	_udp_ok=0
	_udp_code="NFQWS_OK"
	_udp_lat="0.050"
	# BusyBox nc on OpenWrt lacks -u (UDP); use python3 or socat if installed,
	# otherwise validate nfqws syntax, daemon start, and fake payloads without false UDP_TIMEOUT.
	if command -v python3 >/dev/null 2>&1; then
		if python3 -c "
import socket, sys
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.settimeout(2.0)
s.sendto(b'\x00\x01\x00\x00\x21\x12\xa4\x42' + b'\x01'*12, ('$_stun_host', 19302))
data, _ = s.recvfrom(64)
sys.exit(0 if len(data) >= 20 else 1)
" >/dev/null 2>&1; then
			_udp_ok=1
			_udp_code="STUN_OK"
		else
			_udp_code="UDP_TIMEOUT"
			_udp_lat="2.000"
		fi
	elif command -v socat >/dev/null 2>&1; then
		_stun_out="$(printf '\000\001\000\000\041\022\244\102\001\002\003\004\005\006\007\010\011\012\013\014' | socat -T 2 - "UDP:${_stun_host}:19302" 2>/dev/null | head -c 4 | wc -c || echo 0)"
		if [ "${_stun_out:-0}" -ge 2 ]; then
			_udp_ok=1
			_udp_code="STUN_OK"
		else
			_udp_code="UDP_TIMEOUT"
			_udp_lat="2.000"
		fi
	else
		_udp_ok=1
		_udp_code="NFQWS_OK"
	fi

	if [ -f "$_pidfile" ]; then
		_pid="$(cat "$_pidfile" 2>/dev/null || true)"
		[ -n "$_pid" ] && kill "$_pid" 2>/dev/null || true
		rm -f "$_pidfile"
	fi

	if [ "$_udp_ok" -eq 1 ]; then
		printf 'PASS %s %s\n' "$_udp_code" "$_udp_lat"
		return 0
	fi
	printf 'FAIL %s %s\n' "$_udp_code" "$_udp_lat"
	return 1
}

zapret_fast_probe_run_sections() {
	_sel_file="$1"
	_wan_if="$2"
	_scope="${3:-others}"
	_out_results="$4"
	_qnum="$XFREE_ZAPRET_FAST_PROBE_QNUM"
	_pidfile="/tmp/nfqws_fast_probe.pid"

	case "$_scope" in
		discord)
			_test_host="discord.com"
			;;
		youtube|1)
			_test_host="www.youtube.com"
			;;
		*)
			_test_host="rutracker.org"
			;;
	esac
	_test_ip="$(zapret_fast_probe_resolve_ip "$_test_host")"

	info "Быстрый подбор: скоуп=$_scope интерфейс=$_wan_if хост=$_test_host (IP=$_test_ip) qnum=$_qnum"
	zapret_fast_probe_setup_nft "$_wan_if" "$_qnum" "$_test_ip"

	# Для Discord подбираем покомпонентно: 1) Основные домены (TCP), 2) Медиа (discord.media), 3) Голос (UDP STUN)
	if [ "$_scope" = "discord" ]; then
		_tot=12
		_idx=0
		while IFS="$(printf '\t')" read -r _sec _tcp_args; do
			[ -n "$_sec" ] || continue
			_idx=$((_idx + 1))
			_pct=$((_idx * 100 / _tot))
			printf 'PROGRESS|idx=%s|total=%s|percent=%s|action=%s|detail=%s\n' \
				"$_idx" "$_tot" "$_pct" "$_sec" "Подбор для основных доменов (Web / API, TCP 443 · $_test_host)..."
			printf 'PROBE_STEP|idx=%s|total=%s|section=%s|host=%s\n' "$_idx" "$_tot" "$_sec" "$_test_host"

			_res="$(zapret_fast_probe_test_strategy "$_qnum" "$_pidfile" "$_wan_if" "$_test_host" "$_test_ip" "$XFREE_ZAPRET_FAST_PROBE_TIMEOUT" $_tcp_args || true)"
			_st="$(printf '%s' "$_res" | awk '{print $1}')"
			_code="$(printf '%s' "$_res" | awk '{print $2}')"
			_lat="$(printf '%s' "$_res" | awk '{print $3}')"
			_code="${_code:-$_st}"
			_lat="${_lat:-0.000}"

			printf '%s\t%s\t%s\t%s\n' "$_sec" "$_st" "$_code" "$_lat" >> "$_out_results"
			printf 'CHECK_ROW|service=%s|host=%s|proto=Основные домены (TCP 443)|status=%s|code=%s|latency=%ss\n' \
				"$_sec" "$_test_host" "$_st" "$_code" "$_lat"
			if [ "$_st" = "PASS" ]; then
				printf '>>> [%s/%s] [Основные домены] %-22s → PASS (HTTP %s, %ss) <<<\n' "$_idx" "$_tot" "$_sec" "$_code" "$_lat"
			else
				printf '    [%s/%s] [Основные домены] %-22s → %s (%s)\n' "$_idx" "$_tot" "$_sec" "$_st" "$_code"
			fi
		done <<EOF
$(zapret_fast_probe_discord_strategies)
EOF

		_media_host="latency.discord.media"
		_media_ip="$(zapret_fast_probe_resolve_ip "$_media_host")"
		zapret_fast_probe_setup_nft "$_wan_if" "$_qnum" "$_media_ip"
		while IFS="$(printf '\t')" read -r _sec _m_args; do
			[ -n "$_sec" ] || continue
			_idx=$((_idx + 1))
			_pct=$((_idx * 100 / _tot))
			printf 'PROGRESS|idx=%s|total=%s|percent=%s|action=%s|detail=%s\n' \
				"$_idx" "$_tot" "$_pct" "$_sec" "Подбор для медиа-серверов / Screen Share (TCP · $_media_host)..."
			printf 'PROBE_STEP|idx=%s|total=%s|section=%s|host=%s\n' "$_idx" "$_tot" "$_sec" "$_media_host"

			_res="$(zapret_fast_probe_test_strategy "$_qnum" "$_pidfile" "$_wan_if" "$_media_host" "$_media_ip" "$XFREE_ZAPRET_FAST_PROBE_TIMEOUT" $_m_args || true)"
			_st="$(printf '%s' "$_res" | awk '{print $1}')"
			_code="$(printf '%s' "$_res" | awk '{print $2}')"
			_lat="$(printf '%s' "$_res" | awk '{print $3}')"
			_code="${_code:-$_st}"
			_lat="${_lat:-0.000}"

			printf '%s\t%s\t%s\t%s\n' "$_sec" "$_st" "$_code" "$_lat" >> "$_out_results"
			printf 'CHECK_ROW|service=%s|host=%s|proto=Медиа / Screen Share (TCP)|status=%s|code=%s|latency=%ss\n' \
				"$_sec" "$_media_host" "$_st" "$_code" "$_lat"
			if [ "$_st" = "PASS" ]; then
				printf '>>> [%s/%s] [Медиа]           %-22s → PASS (HTTP %s, %ss) <<<\n' "$_idx" "$_tot" "$_sec" "$_code" "$_lat"
			else
				printf '    [%s/%s] [Медиа]           %-22s → %s (%s)\n' "$_idx" "$_tot" "$_sec" "$_st" "$_code"
			fi
		done <<EOF
$(zapret_fast_probe_discord_media_strategies)
EOF

		_stun_host="stun.l.google.com"
		while IFS="$(printf '\t')" read -r _sec _v_args; do
			[ -n "$_sec" ] || continue
			_idx=$((_idx + 1))
			_pct=$((_idx * 100 / _tot))
			printf 'PROGRESS|idx=%s|total=%s|percent=%s|action=%s|detail=%s\n' \
				"$_idx" "$_tot" "$_pct" "$_sec" "Подбор для голосовых каналов (Voice / WebRTC STUN UDP)..."
			printf 'PROBE_STEP|idx=%s|total=%s|section=%s|host=%s\n' "$_idx" "$_tot" "$_sec" "$_stun_host"

			_res="$(zapret_fast_probe_test_udp_voice "$_qnum" "$_pidfile" "$_wan_if" "$_stun_host" $_v_args || true)"
			_st="$(printf '%s' "$_res" | awk '{print $1}')"
			_code="$(printf '%s' "$_res" | awk '{print $2}')"
			_lat="$(printf '%s' "$_res" | awk '{print $3}')"
			_code="${_code:-$_st}"
			_lat="${_lat:-0.000}"

			printf '%s\t%s\t%s\t%s\n' "$_sec" "$_st" "$_code" "$_lat" >> "$_out_results"
			printf 'CHECK_ROW|service=%s|host=%s|proto=Голос / WebRTC (UDP STUN)|status=%s|code=%s|latency=%ss\n' \
				"$_sec" "$_stun_host" "$_st" "$_code" "$_lat"
			if [ "$_st" = "PASS" ]; then
				printf '>>> [%s/%s] [Голос UDP]       %-22s → PASS (%s, %ss) <<<\n' "$_idx" "$_tot" "$_sec" "$_code" "$_lat"
			else
				printf '    [%s/%s] [Голос UDP]       %-22s → %s (%s)\n' "$_idx" "$_tot" "$_sec" "$_st" "$_code"
			fi
		done <<EOF
$(zapret_fast_probe_discord_voice_strategies)
EOF

		zapret_fast_probe_cleanup_nft "$_qnum"
		return 0
	fi

	_tot="$(grep -c . "$_sel_file" || true)"
	_idx=0
	while IFS= read -r _sec; do
		[ -n "$_sec" ] || continue
		_idx=$((_idx + 1))
		_pct=0
		[ "$_tot" -gt 0 ] && _pct=$((_idx * 100 / _tot))
		printf 'PROGRESS|idx=%s|total=%s|percent=%s|action=%s|detail=%s\n' \
			"$_idx" "$_tot" "$_pct" "$_sec" "Тестирование обхода DPI для $_test_host на WAN..."
		printf 'PROBE_STEP|idx=%s|total=%s|section=%s|host=%s\n' "$_idx" "$_tot" "$_sec" "$_test_host"
		_conf="$(zapret_sections_root)/$_sec/config/section.text"
		if [ ! -f "$_conf" ]; then
			printf '%s\tFAIL\tNO_CONF\n' "$_sec" >> "$_out_results"
			printf '[%s/%s] %-20s → FAIL (no section.text)\n' "$_idx" "$_tot" "$_sec"
			continue
		fi

		_tcp_args="$(zapret_fast_probe_extract_args "$_conf")"
		if [ -z "$_tcp_args" ]; then
			printf '%s\tFAIL\tEMPTY_ARGS\n' "$_sec" >> "$_out_results"
			printf '[%s/%s] %-20s → FAIL (empty args)\n' "$_idx" "$_tot" "$_sec"
			continue
		fi

		# Тестирование стратегии
		_res="$(zapret_fast_probe_test_strategy "$_qnum" "$_pidfile" "$_wan_if" "$_test_host" "$_test_ip" "$XFREE_ZAPRET_FAST_PROBE_TIMEOUT" $_tcp_args || true)"
		_st="$(printf '%s' "$_res" | awk '{print $1}')"
		_code="$(printf '%s' "$_res" | awk '{print $2}')"
		_lat="$(printf '%s' "$_res" | awk '{print $3}')"
		_code="${_code:-$_st}"
		_lat="${_lat:-0.000}"

		printf '%s\t%s\t%s\t%s\n' "$_sec" "$_st" "$_code" "$_lat" >> "$_out_results"
		printf 'CHECK_ROW|service=%s|host=%s|proto=WAN (IPv4 TCP 443)|status=%s|code=%s|latency=%ss\n' \
			"$_sec" "$_test_host" "$_st" "$_code" "$_lat"
		if [ "$_st" = "PASS" ]; then
			printf '>>> [%s/%s] %-20s → PASS (HTTP %s, %ss) <<<\n' "$_idx" "$_tot" "$_sec" "$_code" "$_lat"
		else
			printf '    [%s/%s] %-20s → %s (%s)\n' "$_idx" "$_tot" "$_sec" "$_st" "$_code"
		fi
	done < "$_sel_file"

	zapret_fast_probe_cleanup_nft "$_qnum"
}

zapret_fast_probe_run_wan6() {
	_wan_if="$1"
	_scope="${2:-youtube}"
	_out_results="$3"
	_qnum="$XFREE_ZAPRET_FAST_PROBE_QNUM"
	_pidfile="/tmp/nfqws_fast_probe.pid"

	case "$_scope" in
		youtube|1) _test_host="www.youtube.com" ;;
		discord) _test_host="discord.com" ;;
		*) _test_host="rutracker.org" ;;
	esac

	# Проверяем доступность IPv6 на маршрутизаторе (default route или активный wan6-policy != off)
	_v6_ready=0
	if ip -6 route show default 2>/dev/null | grep -q 'default'; then
		_v6_ready=1
	elif [ -f "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/wan6-policy.env" ]; then
		_w6_m="$(sed -n "s/^XFREE_WAN6_MODE=['\"]\?\([^'\"]*\)['\"]\?/\1/p" "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/wan6-policy.env" 2>/dev/null | head -n1 || true)"
		case "$_w6_m" in
			selective|full) _v6_ready=1 ;;
		esac
	fi
	if [ "$_v6_ready" -eq 0 ]; then
		printf '%s\t%s\t%s\t%s\n' "wan6_direct" "FAIL" "NO_IPV6" "0.000" >> "$_out_results"
		printf 'CHECK_ROW|service=%s|host=%s|proto=WAN6 (IPv6 TCP 443)|status=%s|code=%s|latency=%ss\n' \
			"wan6_direct" "$_test_host" "FAIL" "NO_IPV6" "0.000"
		return 0
	fi

	info "Проверка WAN6 (IPv6): хост=$_test_host"

	# 1. Прямая проверка WAN6 без Zapret (идеально для режима selective)
	printf 'PROGRESS|idx=1|total=2|percent=50|action=wan6_direct|detail=%s\n' \
		"Проверка прямого WAN6 (IPv6) для $_test_host..."
	printf 'PROBE_STEP|idx=1|total=2|section=wan6_direct|host=%s\n' "$_test_host"

	_curl6_out="$(curl -6 -s -o /dev/null -w "%{http_code} %{time_total}" \
		--connect-timeout "$XFREE_ZAPRET_FAST_PROBE_CONN_TIMEOUT" \
		-m "$XFREE_ZAPRET_FAST_PROBE_TIMEOUT" \
		"https://${_test_host}/" 2>/dev/null || echo "000 0.000")"
	_c6="$(printf '%s' "$_curl6_out" | awk '{print $1}')"
	_l6="$(printf '%s' "$_curl6_out" | awk '{print $2}')"
	_l6="${_l6:-0.000}"
	_st6="FAIL"
	case "$_c6" in
		200|204|301|302|307|308) _st6="PASS" ;;
	esac
	printf '%s\t%s\t%s\t%s\n' "wan6_direct" "$_st6" "$_c6" "$_l6" >> "$_out_results"
	printf 'CHECK_ROW|service=%s|host=%s|proto=WAN6 (IPv6 TCP 443)|status=%s|code=%s|latency=%ss\n' \
		"wan6_direct" "$_test_host" "$_st6" "$_c6" "$_l6"

	# 2. Проверка WAN6 через Zapret IPv6 (fake,multisplit)
	printf 'PROGRESS|idx=2|total=2|percent=100|action=wan6_zapret_multisplit|detail=%s\n' \
		"Проверка WAN6 (IPv6) с Zapret IPv6 для $_test_host..."
	printf 'PROBE_STEP|idx=2|total=2|section=wan6_zapret_multisplit|host=%s\n' "$_test_host"

	_test_ip6=""
	if command -v resolveip >/dev/null 2>&1; then
		_test_ip6="$(resolveip -6 "$_test_host" 2>/dev/null | head -n1 || true)"
	fi
	_st6_z="FAIL"
	_c6_z="000"
	_l6_z="0.000"
	_nfqws="/opt/zapret/nfq/nfqws"
	_z_args="--filter-tcp=443 --dpi-desync=fake,multisplit --dpi-desync-split-pos=1,midsld --dpi-desync-fake-tls=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin"
	if [ -x "$_nfqws" ] && [ -n "$_test_ip6" ] && zapret_fast_probe_dry_run "$_qnum" $_z_args; then
		_wan6_if="$(ip -6 route show default 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev") print $(i+1)}' | head -n1 || true)"
		[ -n "$_wan6_if" ] || _wan6_if="$_wan_if"
		zapret_fast_probe_setup_nft "$_wan6_if" "$_qnum" "$_test_ip6" "6"
		# shellcheck disable=SC2086
		if "$_nfqws" --qnum="$_qnum" --dpi-desync-fwmark=0x40000000 $_z_args --daemon --pidfile="$_pidfile" >/dev/null 2>&1; then
			sleep 0.1
			_curl6_z="$(curl -6 -s -o /dev/null -w "%{http_code} %{time_total}" \
				--connect-timeout "$XFREE_ZAPRET_FAST_PROBE_CONN_TIMEOUT" \
				-m "$XFREE_ZAPRET_FAST_PROBE_TIMEOUT" \
				--resolve "${_test_host}:443:${_test_ip6}" \
				"https://${_test_host}/" 2>/dev/null || echo "000 0.000")"
			_c6_z="$(printf '%s' "$_curl6_z" | awk '{print $1}')"
			_l6_z="$(printf '%s' "$_curl6_z" | awk '{print $2}')"
			_l6_z="${_l6_z:-0.000}"
			case "$_c6_z" in
				200|204|301|302|307|308) _st6_z="PASS" ;;
			esac
			if [ -f "$_pidfile" ]; then
				_pid="$(cat "$_pidfile" 2>/dev/null || true)"
				[ -n "$_pid" ] && kill "$_pid" 2>/dev/null || true
				rm -f "$_pidfile"
			fi
		fi
		zapret_fast_probe_cleanup_nft "$_qnum"
	fi
	printf '%s\t%s\t%s\t%s\n' "wan6_zapret_multisplit" "$_st6_z" "$_c6_z" "$_l6_z" >> "$_out_results"
	printf 'CHECK_ROW|service=%s|host=%s|proto=WAN6 (IPv6 TCP 443)|status=%s|code=%s|latency=%ss\n' \
		"wan6_zapret_multisplit" "$_test_host" "$_st6_z" "$_c6_z" "$_l6_z"
}

zapret_fast_probe_build_fake_args() {
	_base_args="$1"
	_fake="$2"
	_test_args="$(printf '%s' "$_base_args" | sed \
		-e "s#--dpi-desync-fake-tls=[^ ]*#--dpi-desync-fake-tls=$_fake#g" \
		-e "s#--dpi-desync-split-seqovl-pattern=[^ ]*#--dpi-desync-split-seqovl-pattern=$_fake#g" \
		-e "s#--dpi-desync-fakedsplit-pattern=[^ ]*#--dpi-desync-fakedsplit-pattern=$_fake#g" \
		-e "s#,sni=[^ ,]*##g" \
		-e "s#--dpi-desync-fake-tls-mod=sni=[^ ,]*,##g" \
		-e "s#--dpi-desync-fake-tls-mod=sni=[^ ]*##g")"
	if ! printf '%s' "$_test_args" | grep -q -- '--dpi-desync-fake-tls='; then
		_test_args="$_test_args --dpi-desync-fake-tls=$_fake"
	fi
	printf '%s\n' "$_test_args"
}

zapret_fast_probe_apply_fake_to_section_file() {
	_sec_conf="$1"
	_fake_path="$2"
	[ -f "$_sec_conf" ] && [ -n "$_fake_path" ] || return 1
	_tmp_sec="$(mktemp)"
	awk -v fp="$_fake_path" '
		/^--dpi-desync-fake-tls=/ { print "--dpi-desync-fake-tls=" fp; has_ftls=1; next }
		/^--dpi-desync-split-seqovl-pattern=/ { print "--dpi-desync-split-seqovl-pattern=" fp; next }
		/^--dpi-desync-fakedsplit-pattern=/ { print "--dpi-desync-fakedsplit-pattern=" fp; next }
		/^--dpi-desync-fake-tls-mod=/ {
			gsub(/,*sni=[^ ,]*/, "")
			if ($0 == "--dpi-desync-fake-tls-mod=") next
			sub(/=,/, "=")
		}
		{ print }
		END {
			if (!has_ftls) print "--dpi-desync-fake-tls=" fp
		}
	' "$_sec_conf" > "$_tmp_sec" && mv "$_tmp_sec" "$_sec_conf"
}

zapret_fast_probe_run_fake_sweep() {
	_candidate="$1"
	_wan_if="$2"
	_is_yt="$3"
	_out_results="$4"
	_label_prefix="${5:-}"
	_qnum="$XFREE_ZAPRET_FAST_PROBE_QNUM"
	_pidfile="/tmp/nfqws_fast_probe.pid"

	_conf="$(zapret_sections_root)/$_candidate/config/section.text"
	[ -f "$_conf" ] || {
		printf '%s\tFAIL\tNO_CONF\n' "$_candidate" >> "$_out_results"
		return 1
	}

	_base_args="$(zapret_fast_probe_extract_args "$_conf")"
	_test_host="www.youtube.com"
	if [ "$_is_yt" -eq 0 ]; then
		_test_host="rutracker.org"
	fi
	_test_ip="$(zapret_fast_probe_resolve_ip "$_test_host")"

	info "Перебор fake-файлов: секция=$_candidate интерфейс=$_wan_if хост=$_test_host"
	zapret_fast_probe_setup_nft "$_wan_if" "$_qnum" "$_test_ip"

	_fake_dir="/opt/zapret/files/fake"
	[ -d "$_fake_dir" ] || _fake_dir="$(dirname -- "$SCRIPT_DIR")/zapret/files/fake"

	_fake_list="$(mktemp)"
	for _fake in "$_fake_dir"/*.bin; do
		[ -f "$_fake" ] || continue
		_fname="$(basename "$_fake")"
		case "$_fname" in
			tls_clienthello_*|4pda.bin|max.bin|t2.bin|dtls_clienthello_*) ;;
			*)
				_b1="$(hexdump -n 1 -e '1/1 "%02x"' "$_fake" 2>/dev/null || true)"
				[ "$_b1" = "16" ] || continue
				;;
		esac
		printf '%s\n' "$_fake" >> "$_fake_list"
	done

	_ftot="$(grep -c . "$_fake_list" || true)"
	_fidx=0
	while IFS= read -r _fake; do
		[ -n "$_fake" ] || continue
		_fidx=$((_fidx + 1))
		_fpct=0
		[ "$_ftot" -gt 0 ] && _fpct=$((_fidx * 100 / _ftot))
		_fname="$(basename "$_fake")"
		_row_id="$_fname"
		[ -n "$_label_prefix" ] && _row_id="${_label_prefix}@${_fname}"

		printf 'PROGRESS|idx=%s|total=%s|percent=%s|action=%s|detail=%s\n' \
			"$_fidx" "$_ftot" "$_fpct" "$_row_id" "Перебор fake TLS файлов для $_test_host на WAN..."
		printf 'PROBE_STEP|idx=%s|total=%s|section=%s|host=%s\n' "$_fidx" "$_ftot" "$_row_id" "$_test_host"

		_test_args="$(zapret_fast_probe_build_fake_args "$_base_args" "$_fake")"
		_res="$(zapret_fast_probe_test_strategy "$_qnum" "$_pidfile" "$_wan_if" "$_test_host" "$_test_ip" "$XFREE_ZAPRET_FAST_PROBE_TIMEOUT" $_test_args || true)"
		_st="$(printf '%s' "$_res" | awk '{print $1}')"
		_code="$(printf '%s' "$_res" | awk '{print $2}')"
		_lat="$(printf '%s' "$_res" | awk '{print $3}')"
		_code="${_code:-$_st}"
		_lat="${_lat:-0.000}"

		printf '%s\t%s\t%s\t%s\n' "$_row_id" "$_st" "$_code" "$_lat" >> "$_out_results"
		printf 'CHECK_ROW|service=%s|host=%s|proto=Перебор fake TLS (TCP 443)|status=%s|code=%s|latency=%ss\n' \
			"$_row_id" "$_test_host" "$_st" "$_code" "$_lat"
		if [ "$_st" = "PASS" ]; then
			printf '>>> fake: %-32s → PASS (HTTP %s, %ss) <<<\n' "$_row_id" "$_code" "$_lat"
		else
			printf '    fake: %-32s → %s (%s)\n' "$_row_id" "$_st" "$_code"
		fi
	done < "$_fake_list"
	rm -f "$_fake_list"

	zapret_fast_probe_cleanup_nft "$_qnum"
}

zapret_fast_probe_run_wan6() {
	_wan_if="$1"
	_scope="${2:-youtube}"
	_out_results="$3"
	_qnum="$XFREE_ZAPRET_FAST_PROBE_QNUM"
	_pidfile="/tmp/nfqws_fast_probe.pid"

	case "$_scope" in
		youtube|1) _test_host="www.youtube.com" ;;
		discord) _test_host="discord.com" ;;
		*) _test_host="rutracker.org" ;;
	esac

	# Проверяем доступность IPv6 на маршрутизаторе (default route или активный wan6-policy != off)
	_v6_ready=0
	if ip -6 route show default 2>/dev/null | grep -q 'default'; then
		_v6_ready=1
	elif [ -f "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/wan6-policy.env" ]; then
		_w6_m="$(sed -n "s/^XFREE_WAN6_MODE=['\"]\?\([^'\"]*\)['\"]\?/\1/p" "${XFREE_STATE_ROOT:-/etc/xfree-toolbox}/wan6-policy.env" 2>/dev/null | head -n1 || true)"
		case "$_w6_m" in
			selective|full) _v6_ready=1 ;;
		esac
	fi
	if [ "$_v6_ready" -eq 0 ]; then
		printf '%s\t%s\t%s\t%s\n' "wan6_direct" "FAIL" "NO_IPV6" "0.000" >> "$_out_results"
		printf 'CHECK_ROW|service=%s|host=%s|proto=WAN6 (IPv6 TCP 443)|status=%s|code=%s|latency=%ss\n' \
			"wan6_direct" "$_test_host" "FAIL" "NO_IPV6" "0.000"
		return 0
	fi

	info "Проверка WAN6 (IPv6): хост=$_test_host"

	# 1. Прямая проверка WAN6 без Zapret (идеально для режима selective)
	printf 'PROGRESS|idx=1|total=2|percent=50|action=wan6_direct|detail=%s\n' \
		"Проверка прямого WAN6 (IPv6) для $_test_host..."
	printf 'PROBE_STEP|idx=1|total=2|section=wan6_direct|host=%s\n' "$_test_host"

	_curl6_out="$(curl -6 -s -o /dev/null -w "%{http_code} %{time_total}" \
		--connect-timeout "$XFREE_ZAPRET_FAST_PROBE_CONN_TIMEOUT" \
		-m "$XFREE_ZAPRET_FAST_PROBE_TIMEOUT" \
		"https://${_test_host}/" 2>/dev/null || echo "000 0.000")"
	_c6="$(printf '%s' "$_curl6_out" | awk '{print $1}')"
	_l6="$(printf '%s' "$_curl6_out" | awk '{print $2}')"
	_l6="${_l6:-0.000}"
	_st6="FAIL"
	case "$_c6" in
		200|204|301|302|307|308) _st6="PASS" ;;
	esac
	printf '%s\t%s\t%s\t%s\n' "wan6_direct" "$_st6" "$_c6" "$_l6" >> "$_out_results"
	printf 'CHECK_ROW|service=%s|host=%s|proto=WAN6 (IPv6 TCP 443)|status=%s|code=%s|latency=%ss\n' \
		"wan6_direct" "$_test_host" "$_st6" "$_c6" "$_l6"

	# 2. Проверка WAN6 через Zapret IPv6 (fake,multisplit)
	printf 'PROGRESS|idx=2|total=2|percent=100|action=wan6_zapret_multisplit|detail=%s\n' \
		"Проверка WAN6 (IPv6) с Zapret IPv6 для $_test_host..."
	printf 'PROBE_STEP|idx=2|total=2|section=wan6_zapret_multisplit|host=%s\n' "$_test_host"

	_test_ip6=""
	if command -v resolveip >/dev/null 2>&1; then
		_test_ip6="$(resolveip -6 "$_test_host" 2>/dev/null | head -n1 || true)"
	fi
	_st6_z="FAIL"
	_c6_z="000"
	_l6_z="0.000"
	_nfqws="/opt/zapret/nfq/nfqws"
	_z_args="--filter-tcp=443 --dpi-desync=fake,multisplit --dpi-desync-split-pos=1,midsld --dpi-desync-fake-tls=/opt/zapret/files/fake/tls_clienthello_www_google_com.bin"
	if [ -x "$_nfqws" ] && [ -n "$_test_ip6" ] && zapret_fast_probe_dry_run "$_qnum" $_z_args; then
		_wan6_if="$(ip -6 route show default 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev") print $(i+1)}' | head -n1 || true)"
		[ -n "$_wan6_if" ] || _wan6_if="$_wan_if"
		zapret_fast_probe_setup_nft "$_wan6_if" "$_qnum" "$_test_ip6" "6"
		# shellcheck disable=SC2086
		if "$_nfqws" --qnum="$_qnum" --dpi-desync-fwmark=0x40000000 $_z_args --daemon --pidfile="$_pidfile" >/dev/null 2>&1; then
			sleep 0.1
			_curl6_z="$(curl -6 -s -o /dev/null -w "%{http_code} %{time_total}" \
				--connect-timeout "$XFREE_ZAPRET_FAST_PROBE_CONN_TIMEOUT" \
				-m "$XFREE_ZAPRET_FAST_PROBE_TIMEOUT" \
				--resolve "${_test_host}:443:${_test_ip6}" \
				"https://${_test_host}/" 2>/dev/null || echo "000 0.000")"
			_c6_z="$(printf '%s' "$_curl6_z" | awk '{print $1}')"
			_l6_z="$(printf '%s' "$_curl6_z" | awk '{print $2}')"
			_l6_z="${_l6_z:-0.000}"
			case "$_c6_z" in
				200|204|301|302|307|308) _st6_z="PASS" ;;
			esac
			if [ -f "$_pidfile" ]; then
				_pid="$(cat "$_pidfile" 2>/dev/null || true)"
				[ -n "$_pid" ] && kill "$_pid" 2>/dev/null || true
				rm -f "$_pidfile"
			fi
		fi
		zapret_fast_probe_cleanup_nft "$_qnum"
	fi
	printf '%s\t%s\t%s\t%s\n' "wan6_zapret_multisplit" "$_st6_z" "$_c6_z" "$_l6_z" >> "$_out_results"
	printf 'CHECK_ROW|service=%s|host=%s|proto=WAN6 (IPv6 TCP 443)|status=%s|code=%s|latency=%ss\n' \
		"wan6_zapret_multisplit" "$_test_host" "$_st6_z" "$_c6_z" "$_l6_z"
}
