#!/bin/sh
# shellcheck shell=sh
# Быстрый чекер курированных наборов сервисов Zapret (Discord, YouTube, Остальные сервисы).
# Выводит структурированный поток событий:
#   PROBE_STEP|idx=...|total=...|service=...|host=...
#   CHECK_ROW|service=...|host=...|proto=...|status=...|code=...|latency=...
# Совместим с BusyBox ash, не зависает, timeout 2s/4s.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ZAPRET_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$ZAPRET_DIR/.." && pwd -P)"
# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/wan6-policy.sh" ] && . "$ROOT_DIR/lib/wan6-policy.sh"

zapret_check_url() {
	_service="$1"
	_host="$2"
	_url="$3"
	_proto="${4:-TCP 443}"
	_expected="${5:-200|204|301|302|400|403|404|520}"
	_ip_flag="${6:--4}"

	_out="$(curl "$_ip_flag" -sS -I -o /dev/null -w '%{http_code} %{time_total}' \
		--connect-timeout 2 -m 4 \
		-A 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' \
		"$_url" 2>/dev/null || echo "000 0.000")"

	_code="$(printf '%s' "$_out" | awk '{print $1}')"
	_lat="$(printf '%s' "$_out" | awk '{print $2}')"

	_status="FAIL"
	case "$_code" in
		200|204|206|301|302|307|308|400|401|403|404|405|520)
			_status="PASS"
			;;
		000)
			_status="FAIL"
			;;
		*)
			_status="PASS"
			;;
	esac

	_lat_fmt=""
	[ -n "$_lat" ] && [ "$_lat" != "0.000" ] && _lat_fmt="${_lat}s"

	printf 'CHECK_ROW|service=%s|host=%s|proto=%s|status=%s|code=%s|latency=%s\n' \
		"$_service" "$_host" "$_proto" "$_status" "$_code" "$_lat_fmt"
}

run_check_discord() {
	printf '=== Проверка доступности Discord ===\n\n'

	printf 'PROGRESS|idx=1|total=4|percent=25|action=Discord Web/API|detail=Проверка https://discord.com/api/v9/gateway (TCP 443)\n'
	printf 'PROBE_STEP|idx=1|total=4|service=Discord Web/API|host=discord.com\n'
	zapret_check_url "Discord Web & API" "discord.com" "https://discord.com/api/v9/gateway" "TCP 443" "200"

	printf 'PROGRESS|idx=2|total=4|percent=50|action=Discord Gateway|detail=Проверка WSS endpoint https://gateway.discord.gg/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=2|total=4|service=Discord Gateway|host=gateway.discord.gg\n'
	zapret_check_url "Discord Gateway" "gateway.discord.gg" "https://gateway.discord.gg/" "TCP 443" "404"

	printf 'PROGRESS|idx=3|total=4|percent=75|action=Discord Media CDN|detail=Проверка CDN медиа https://cdn.discordapp.com/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=3|total=4|service=Discord Media CDN|host=cdn.discordapp.com\n'
	zapret_check_url "Discord Media" "cdn.discordapp.com" "https://cdn.discordapp.com/" "TCP 443" "403"

	printf 'PROGRESS|idx=4|total=4|percent=100|action=Discord Voice RTC|detail=Проверка Voice latency endpoint https://latency.discord.media/ (WebRTC Voice)\n'
	printf 'PROBE_STEP|idx=4|total=4|service=Discord Voice RTC|host=latency.discord.media\n'
	zapret_check_url "Discord Voice RTC" "latency.discord.media" "https://latency.discord.media/" "TCP 443 (Voice)" "520"

	printf '\n=== Проверка завершена ===\n'
}

run_check_others() {
	printf '=== Проверка доступности остальных сервисов ===\n\n'

	printf 'PROGRESS|idx=1|total=5|percent=20|action=Instagram|detail=Проверка https://www.instagram.com/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=1|total=5|service=Instagram|host=www.instagram.com\n'
	zapret_check_url "Instagram" "www.instagram.com" "https://www.instagram.com/" "TCP 443" "302"

	printf 'PROGRESS|idx=2|total=5|percent=40|action=X (Twitter)|detail=Проверка https://x.com/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=2|total=5|service=X (Twitter)|host=x.com\n'
	zapret_check_url "X (Twitter)" "x.com" "https://x.com/" "TCP 443" "200"

	printf 'PROGRESS|idx=3|total=5|percent=60|action=RuTracker|detail=Проверка https://rutracker.org/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=3|total=5|service=RuTracker|host=rutracker.org\n'
	zapret_check_url "RuTracker" "rutracker.org" "https://rutracker.org/" "TCP 443" "301"

	printf 'PROGRESS|idx=4|total=5|percent=80|action=Meduza|detail=Проверка https://meduza.io/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=4|total=5|service=Meduza|host=meduza.io\n'
	zapret_check_url "Meduza" "meduza.io" "https://meduza.io/" "TCP 443" "200"

	printf 'PROGRESS|idx=5|total=5|percent=100|action=Docker Hub|detail=Проверка https://hub.docker.com/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=5|total=5|service=Docker Hub|host=hub.docker.com\n'
	zapret_check_url "Docker Hub" "hub.docker.com" "https://hub.docker.com/" "TCP 443" "200"

	printf '\n=== Проверка завершена ===\n'
}

run_check_youtube() {
	printf '=== Проверка доступности YouTube ===\n\n'

	printf 'PROGRESS|idx=1|total=4|percent=25|action=YouTube Home|detail=Проверка https://www.youtube.com/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=1|total=4|service=YouTube Home|host=www.youtube.com\n'
	zapret_check_url "YouTube Home" "www.youtube.com" "https://www.youtube.com/" "TCP 443" "200"

	printf 'PROGRESS|idx=2|total=4|percent=50|action=YouTube Watch|detail=Проверка веб-страницы плеера https://www.youtube.com/watch (TCP 443)\n'
	printf 'PROBE_STEP|idx=2|total=4|service=YouTube Watch|host=www.youtube.com/watch\n'
	zapret_check_url "YouTube Watch" "www.youtube.com" "https://www.youtube.com/watch?v=dQw4w9WgXcQ" "TCP 443" "200"

	printf 'PROGRESS|idx=3|total=4|percent=75|action=YouTube Thumbnails|detail=Проверка превью https://i.ytimg.com/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=3|total=4|service=YouTube Thumbnails|host=i.ytimg.com\n'
	zapret_check_url "YouTube Thumbnails" "i.ytimg.com" "https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg" "TCP 443" "200"

	printf 'PROGRESS|idx=4|total=4|percent=100|action=Googlevideo CDN|detail=Проверка CDN детектора https://manifest.googlevideo.com/ (TCP 443)\n'
	printf 'PROBE_STEP|idx=4|total=4|service=Googlevideo CDN|host=manifest.googlevideo.com\n'
	zapret_check_url "Googlevideo CDN" "manifest.googlevideo.com" "https://manifest.googlevideo.com/api/manifest/dash/source/youtube" "TCP 443" "400"

	_has_v6=0
	if command -v wan6_policy_load >/dev/null 2>&1; then
		wan6_policy_load
		[ "${XFREE_WAN6_MODE:-off}" != "off" ] && _has_v6=1
	fi
	if [ "$_has_v6" -eq 0 ] && ip -6 route show default 2>/dev/null | grep -q 'default'; then
		_has_v6=1
	fi
	if [ "$_has_v6" -eq 1 ]; then
		printf 'PROBE_STEP|idx=5|total=5|service=YouTube IPv6 (WAN6)|host=www.youtube.com\n'
		zapret_check_url "YouTube IPv6 (WAN6)" "www.youtube.com" "https://www.youtube.com/" "WAN6 (IPv6 TCP 443)" "200" "-6"
	fi

	printf '\n=== Проверка завершена ===\n'
}

case "${1:-}" in
	discord)
		run_check_discord
		;;
	others)
		run_check_others
		;;
	youtube)
		run_check_youtube
		;;
	*)
		printf 'Usage: %s {discord|others|youtube}\n' "$0" >&2
		exit 1
		;;
esac
