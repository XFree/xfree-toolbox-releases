#!/bin/sh
# shellcheck shell=sh
# Состояние установки zapret-openwrt: core binary / пакет, версия, сравнение с latest.

: "${ZAPRET_PKG_NAME:=zapret}"
: "${ZAPRET_LUCI_PKG_NAME:=luci-app-zapret}"
: "${ZAPRET_NFQWS_BIN:=/opt/zapret/nfq/nfqws}"
: "${ZAPRET_SYNC_SCRIPT:=/opt/zapret/sync_config.sh}"
: "${ZAPRET_RESOLVE_RELEASE_SCRIPT:=}"

zapret_install_state_init() {
    [ -n "${ZAPRET_RESOLVE_RELEASE_SCRIPT:-}" ] && return 0
    # При source $0 — родительский скрипт (ensure-zapret.sh в zapret/), не install-state.sh.
    _zapret_script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    if [ -f "${_zapret_script_dir}/resolve-release.sh" ]; then
        ZAPRET_RESOLVE_RELEASE_SCRIPT="${_zapret_script_dir}/resolve-release.sh"
        return 0
    fi
    _zapret_lib_dir="$(CDPATH= cd -- "${_zapret_script_dir}/lib" 2>/dev/null && pwd -P || true)"
    if [ -n "${_zapret_lib_dir:-}" ] && [ -f "${_zapret_lib_dir}/../resolve-release.sh" ]; then
        ZAPRET_RESOLVE_RELEASE_SCRIPT="$(CDPATH= cd -- "${_zapret_lib_dir}/.." && pwd -P)/resolve-release.sh"
        return 0
    fi
    return 1
}

zapret_pm_installed_pkg_version() {
    pkg="$1"
    [ -n "${PM:-}" ] || return 1
    case "$PM" in
        opkg)
            opkg info "$pkg" 2>/dev/null | awk -F': ' '/^Version:/{print $2; exit}'
            ;;
        apk)
            _apk_line="$(apk info "$pkg" 2>/dev/null | head -n 1 | awk '{print $1}')"
            _apk_ver=""
            if [ -n "$_apk_line" ]; then
                _apk_ver="$(printf '%s' "$_apk_line" | sed -n "s/^${pkg}-\(.*\)-r[0-9][0-9]*\$/\1/p")"
            fi
            if [ -z "$_apk_ver" ]; then
                _apk_line="$(apk list -I 2>/dev/null | awk -v p="${pkg}-" '$1 ~ "^" p {print $1; exit}')"
                [ -n "$_apk_line" ] && _apk_ver="$(printf '%s' "$_apk_line" | sed -n "s/^${pkg}-\(.*\)-r[0-9][0-9]*\$/\1/p")"
            fi
            [ -n "$_apk_ver" ] && printf '%s\n' "$_apk_ver"
            ;;
        *)
            return 1
            ;;
    esac
}

zapret_version_normalize() {
    ver="$1"
    [ -n "$ver" ] || return 1
    ver="${ver#v}"
    ver="${ver%%-r*}"
    ver="${ver%%_*}"
    printf '%s\n' "$ver"
}

# 0 — ver_a старее ver_b; 1 — ver_a >= ver_b или сравнение невозможно.
zapret_version_is_older() {
    ver_a="$(zapret_version_normalize "$1")"
    ver_b="$(zapret_version_normalize "$2")"
    [ -n "$ver_a" ] && [ -n "$ver_b" ] || return 1
    [ "$ver_a" = "$ver_b" ] && return 1
    if command -v sort >/dev/null 2>&1; then
        [ "$(printf '%s\n%s\n' "$ver_a" "$ver_b" | sort -V | head -n1)" = "$ver_a" ]
        return $?
    fi
    # BusyBox без sort -V: сравниваем как строки (хуже, но редкий fallback).
    [ "$ver_a" \< "$ver_b" ]
}

# Путь runtime UCI (тесты: ZAPRET_RUNTIME_UCI_FILE).
zapret_runtime_uci_file() {
    printf '%s\n' "${ZAPRET_RUNTIME_UCI_FILE:-/etc/config/zapret}"
}

# 0 — core установлен и UCI zapret на роутере уже materialized; иначе 1.
zapret_runtime_ready() {
    uci_file="$(zapret_runtime_uci_file)"
    zapret_core_installed || return 1
    [ -f "$uci_file" ] || return 1
    [ -s "$uci_file" ] || return 1
    return 0
}

# 0 — core установлен; 1 — нет. Каталог /opt/zapret сам по себе не считается установкой.
zapret_core_installed() {
    [ -x "$ZAPRET_NFQWS_BIN" ] && return 0
    if command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed "$ZAPRET_PKG_NAME" 2>/dev/null; then
        return 0
    fi
    return 1
}

# 0 — luci-app-zapret установлен; 1 — нет / нельзя проверить (нет pm).
zapret_luci_installed() {
    if command -v pm_is_installed >/dev/null 2>&1; then
        pm_is_installed "$ZAPRET_LUCI_PKG_NAME" 2>/dev/null && return 0
        return 1
    fi
    return 1
}

# 0 — и core, и luci на месте; 1 — чего-то не хватает.
zapret_packages_installed() {
    zapret_core_installed || return 1
    zapret_luci_installed || return 1
    return 0
}

zapret_get_installed_version() {
    ver=""
    if command -v pm_is_installed >/dev/null 2>&1 && pm_is_installed "$ZAPRET_PKG_NAME" 2>/dev/null; then
        ver="$(zapret_pm_installed_pkg_version "$ZAPRET_PKG_NAME" 2>/dev/null || true)"
    fi
    if [ -n "$ver" ]; then
        printf '%s\n' "$ver"
        return 0
    fi
    if zapret_core_installed; then
        printf '%s\n' "unknown"
        return 0
    fi
    return 1
}

# stdout: latest version; exit 0 ok, 1 fail (offline / parse error).
zapret_resolve_latest_version() {
    zapret_install_state_init
    resolver="$ZAPRET_RESOLVE_RELEASE_SCRIPT"
    [ -f "$resolver" ] || return 1

    tmp_env="$(mktemp "${TMPDIR:-/tmp}/zapret-resolve.XXXXXX")"
    resolve_args="--emit-shell"
    if [ -n "${ZAPRET_ENGINE:-}" ]; then
        resolve_args="$resolve_args --engine $ZAPRET_ENGINE"
    fi
    if ! sh "$resolver" $resolve_args >"$tmp_env" 2>/dev/null; then
        rm -f "$tmp_env"
        return 1
    fi
    # shellcheck disable=SC1090
    . "$tmp_env"
    rm -f "$tmp_env"
    [ -n "${ZAPRET_VERSION:-}" ] || return 1
    printf '%s\n' "$ZAPRET_VERSION"
}

zapret_install_state_summary() {
    if zapret_core_installed; then
        ver="$(zapret_get_installed_version 2>/dev/null || true)"
        if [ -x "$ZAPRET_NFQWS_BIN" ]; then
            if [ -n "$ver" ]; then
                info "zapret core: установлен ($ZAPRET_NFQWS_BIN, пакет $ver)"
            else
                info "zapret core: установлен ($ZAPRET_NFQWS_BIN)"
            fi
        else
            info "zapret core: пакет $ZAPRET_PKG_NAME установлен (${ver:-версия неизвестна})"
        fi
        if zapret_luci_installed; then
            info "luci: пакет $ZAPRET_LUCI_PKG_NAME установлен"
        else
            warn "luci: пакет $ZAPRET_LUCI_PKG_NAME не установлен (меню LuCI zapret недоступно)"
        fi
        if [ -x /etc/init.d/zapret ]; then
            info "init.d: /etc/init.d/zapret"
        fi
        if [ -f "$ZAPRET_SYNC_SCRIPT" ]; then
            info "sync: $ZAPRET_SYNC_SCRIPT"
        fi
        zapret_luci_installed || return 1
        return 0
    fi

    if [ -d /opt/zapret ]; then
        warn "Каталог /opt/zapret есть, но core не установлен (нет $ZAPRET_NFQWS_BIN и пакета $ZAPRET_PKG_NAME)"
        warn "Вероятно, скопированы только профильные списки xfree-toolbox — нужна установка пакета zapret-openwrt"
    fi
    return 1
}
