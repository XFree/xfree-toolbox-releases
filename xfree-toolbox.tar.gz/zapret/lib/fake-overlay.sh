#!/bin/sh
# shellcheck shell=sh
# Overlay toolbox fake *.bin onto the zapret package fake dir.
# Never copies Windows binaries (exe/dll/sys).

zapret_src_fake_dir() {
	if [ -n "${ZAPRET_SRC_FAKE_DIR:-}" ]; then
		printf '%s\n' "$ZAPRET_SRC_FAKE_DIR"
		return 0
	fi
	if [ -n "${ROOT_DIR:-}" ]; then
		printf '%s\n' "$ROOT_DIR/zapret/files/fake"
		return 0
	fi
	printf '%s\n' ""
}

# dest [src] — copies only *.bin from src into dest.
zapret_copy_fake_overlay() {
	dest="${1:-${ZAPRET_FAKE_DIR:-}}"
	src="${2:-}"
	if [ -z "$src" ]; then
		src="$(zapret_src_fake_dir)"
	fi
	[ -n "$dest" ] || return 0
	[ -n "$src" ] && [ -d "$src" ] || return 0

	mkdir -p "$dest" || return 1
	found=0
	for f in "$src"/*; do
		[ -f "$f" ] || continue
		base="$(basename "$f")"
		case "$base" in
			*.bin) ;;
			*) continue ;;
		esac
		cp -f "$f" "$dest/$base"
		found=$((found + 1))
	done
	if [ "$found" -gt 0 ] && type info >/dev/null 2>&1; then
		info "Скопировано fake *.bin: $found → $dest"
	fi
	return 0
}
