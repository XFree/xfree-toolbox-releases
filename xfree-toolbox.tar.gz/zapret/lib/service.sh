#!/bin/sh
# shellcheck shell=sh
# Управление сервисом zapret-openwrt: sync UCI → $ZAPRET_OPT_DIR/config, init.d.
# Контракт как у LuCI «Service daemons → Restart»: sync_config.sh, затем init.d restart.

: "${ZAPRET_SYNC_CONFIG_SCRIPT:=/opt/zapret/sync_config.sh}"
: "${ZAPRET_INITD_SCRIPT:=/etc/init.d/zapret}"

zapret_sync_config_script() {
    printf '%s\n' "$ZAPRET_SYNC_CONFIG_SCRIPT"
}

zapret_initd_script() {
    printf '%s\n' "$ZAPRET_INITD_SCRIPT"
}

# 0 — синхронизация выполнена; 1 — скрипт отсутствует (пропуск).
zapret_sync_config() {
    sync_script="$(zapret_sync_config_script)"
    if [ ! -f "$sync_script" ]; then
        warn "Не найден $sync_script (установлен пакет zapret-openwrt?)."
        return 1
    fi
    info "Синхронизация UCI → ${ZAPRET_OPT_DIR:-/opt/zapret} (sync_config.sh)…"
    if [ -x "$sync_script" ]; then
        "$sync_script" || die "sync_config.sh завершился с ошибкой"
    else
        sh "$sync_script" || die "sync_config.sh завершился с ошибкой"
    fi
    return 0
}

zapret_sync_config_or_die() {
    zapret_sync_config || die "Синхронизация конфига zapret недоступна (нет $ZAPRET_SYNC_CONFIG_SCRIPT)"
}

# start | stop | restart | enable | disable
zapret_service_action() {
    action="$1"
    [ -n "$action" ] || die "zapret_service_action: не указано действие"

    init_script="$(zapret_initd_script)"
    if [ -x "$init_script" ]; then
        "$init_script" "$action" || die "Не удалось выполнить: $init_script $action"
        return 0
    fi
    if [ -f "$init_script" ]; then
        sh "$init_script" "$action" || die "Не удалось выполнить: sh $init_script $action"
        return 0
    fi
    die "Сервис zapret не найден: $init_script"
}

# 0 — процесс/procd instance жив. Нет init.d или нет команды running → не запущен.
zapret_service_is_running() {
    init_script="$(zapret_initd_script)"
    if [ -x "$init_script" ]; then
        "$init_script" running >/dev/null 2>&1 || return 1
        return 0
    fi
    if [ -f "$init_script" ]; then
        sh "$init_script" running >/dev/null 2>&1 || return 1
        return 0
    fi
    return 1
}

# restart если уже работает, иначе start (init.d restart на остановленном сервисе часто no-op).
zapret_service_start_or_restart() {
    quiet="${1:-0}"
    init_script="$(zapret_initd_script)"
    if [ ! -x "$init_script" ] && [ ! -f "$init_script" ]; then
        [ "$quiet" = "1" ] && return 0
        die "Сервис zapret не найден: $init_script"
    fi
    if zapret_service_is_running; then
        if [ "$quiet" = "1" ]; then
            if [ -x "$init_script" ]; then
                "$init_script" restart >/dev/null 2>&1 || true
            else
                sh "$init_script" restart >/dev/null 2>&1 || true
            fi
            return 0
        fi
        info "Перезапуск zapret (init.d restart)…"
        zapret_service_action restart
        return 0
    fi
    if [ "$quiet" = "1" ]; then
        if [ -x "$init_script" ]; then
            "$init_script" start >/dev/null 2>&1 || true
        else
            sh "$init_script" start >/dev/null 2>&1 || true
        fi
        return 0
    fi
    info "zapret не запущен — start"
    zapret_service_action start
}

# Как LuCI Restart: sync_config (если есть), затем restart.
# ZAPRET_RESTART_SKIP_SYNC=1 — только init.d restart (устаревшее поведение).
# ZAPRET_RESTART_QUIET=1 — без info и с подавлением вывода init.d (для apply-changed).
zapret_restart_service() {
    quiet="${ZAPRET_RESTART_QUIET:-0}"
    skip_sync="${ZAPRET_RESTART_SKIP_SYNC:-0}"

    if [ "$skip_sync" != "1" ]; then
        if [ "$quiet" = "1" ]; then
            sync_script="$(zapret_sync_config_script)"
            if [ -f "$sync_script" ]; then
                if [ -x "$sync_script" ]; then
                    "$sync_script" >/dev/null 2>&1 || die "sync_config.sh завершился с ошибкой"
                else
                    sh "$sync_script" >/dev/null 2>&1 || die "sync_config.sh завершился с ошибкой"
                fi
            else
                warn "Пропуск sync_config: $sync_script не найден"
            fi
        else
            zapret_sync_config || die "Перезапуск без sync_config.sh невозможен (как в LuCI)"
        fi
    fi

    zapret_service_start_or_restart "$quiet"
}

# --- Daemon health (как LuCI «Service daemons status: Запущено [N/M]») ---
# LuCI N/M = procd instances (ubus service list), НЕ число --new в NFQWS_OPT.
# --new внутри одного nfqws — это стратегии/фильтры в том же процессе.

zapret_runtime_uci_path() {
    printf '%s\n' "${ZAPRET_RUNTIME_UCI_FILE:-/etc/config/zapret}"
}

zapret_procd_svc_name() {
    printf '%s\n' "${ZAPRET_UCI_NAME:-zapret}"
}

zapret_nfqws_proc_name() {
    base="$(basename -- "${ZAPRET_NFQWS_BIN:-/opt/zapret/nfq/nfqws}" 2>/dev/null || true)"
    case "$base" in
        nfqws2) printf 'nfqws2\n' ;;
        *) printf 'nfqws\n' ;;
    esac
}

# Число --new-блоков в тексте OPT (информативно: strategy blocks, не procd daemons).
# Пустой opt → 0.
zapret_count_opt_strategy_blocks() {
    opt="$1"
    opt="$(printf '%s' "$opt" | tr -d '\r')"
    [ -n "$(printf '%s' "$opt" | sed '/^[[:space:]]*$/d')" ] || {
        printf '0\n'
        return 0
    }
    news="$(printf '%s\n' "$opt" | grep -c -E '^[[:space:]]*--new[[:space:]]*$' || true)"
    case "$news" in ''|*[!0-9]*) news=0 ;; esac
    printf '%s\n' "$((news + 1))"
}

# Совместимость со старым именем в тестах.
zapret_count_opt_daemons() {
    zapret_count_opt_strategy_blocks "$@"
}

# Multiline option KEY '…' из UCI-файла (как /etc/config/zapret).
zapret_uci_extract_option() {
    file="$1"
    key="$2"
    [ -f "$file" ] || return 1
    awk -v key="$key" '
        BEGIN { in_opt=0 }
        $1 == "option" && $2 == key {
            line=$0
            sub(/^[[:space:]]*option[[:space:]]+[^[:space:]]+[[:space:]]+'\''/, "", line)
            if (line ~ /'\''[[:space:]]*$/) {
                sub(/'\''[[:space:]]*$/, "", line)
                print line
                exit
            }
            print line
            in_opt=1
            next
        }
        in_opt {
            if ($0 ~ /'\''[[:space:]]*$/) {
                sub(/'\''[[:space:]]*$/, "", $0)
                print $0
                exit
            }
            print $0
        }
    ' "$file"
}

zapret_strategy_blocks_count() {
    uci_file="$(zapret_runtime_uci_path)"
    key="${ZAPRET_OPT_KEY:-NFQWS_OPT}"
    opt="$(zapret_uci_extract_option "$uci_file" "$key" 2>/dev/null || true)"
    zapret_count_opt_strategy_blocks "$opt"
}

# Число живых процессов nfqws/nfqws2 (fallback, не LuCI N/M).
zapret_running_nfqws_count() {
    if [ -n "${ZAPRET_NFQWS_RUNNING_COUNT:-}" ]; then
        printf '%s\n' "$ZAPRET_NFQWS_RUNNING_COUNT"
        return 0
    fi
    name="$(zapret_nfqws_proc_name)"
    pids=""
    if command -v pidof >/dev/null 2>&1; then
        pids="$(pidof "$name" 2>/dev/null || true)"
    fi
    if [ -z "$pids" ] && command -v pgrep >/dev/null 2>&1; then
        pids="$(pgrep -x "$name" 2>/dev/null || true)"
    fi
    [ -n "$pids" ] || {
        printf '0\n'
        return 0
    }
    # shellcheck disable=SC2086
    set -- $pids
    printf '%s\n' "$#"
}

# stdout: "WORKING TOTAL" — как LuCI decode_svc_info (procd instances).
# Тесты: ZAPRET_PROCD_WORKING / ZAPRET_PROCD_TOTAL.
zapret_procd_daemon_counts() {
    if [ -n "${ZAPRET_PROCD_WORKING:-}" ] && [ -n "${ZAPRET_PROCD_TOTAL:-}" ]; then
        printf '%s %s\n' "$ZAPRET_PROCD_WORKING" "$ZAPRET_PROCD_TOTAL"
        return 0
    fi
    # Старые overrides из unit-тестов.
    if [ -n "${ZAPRET_NFQWS_RUNNING_COUNT:-}" ] && [ -n "${ZAPRET_NFQWS_EXPECTED_COUNT:-}" ]; then
        printf '%s %s\n' "$ZAPRET_NFQWS_RUNNING_COUNT" "$ZAPRET_NFQWS_EXPECTED_COUNT"
        return 0
    fi

    svc="$(zapret_procd_svc_name)"
    raw=""
    if command -v ubus >/dev/null 2>&1; then
        raw="$(ubus call service list "{\"name\":\"$svc\",\"verbose\":1}" 2>/dev/null || true)"
    fi

    if [ -n "$raw" ] && printf '%s' "$raw" | grep -q "\"$svc\""; then
        # Считаем поля "running" у instances (как LuCI total / working≈running true).
        total="$(printf '%s\n' "$raw" | grep -c '"running"' || true)"
        working="$(printf '%s\n' "$raw" | grep -cE '"running"[[:space:]]*:[[:space:]]*true' || true)"
        case "$total" in ''|*[!0-9]*) total=0 ;; esac
        case "$working" in ''|*[!0-9]*) working=0 ;; esac
        printf '%s %s\n' "$working" "$total"
        return 0
    fi

    # Fallback без ubus: процессы nfqws → N/N; иначе 0/0.
    nfq="$(zapret_running_nfqws_count)"
    case "$nfq" in ''|*[!0-9]*) nfq=0 ;; esac
    if [ "$nfq" -gt 0 ]; then
        printf '%s %s\n' "$nfq" "$nfq"
    else
        printf '0 0\n'
    fi
}

# Пути fake *.bin из текста стратегии/NFQWS_OPT, которых нет на ФС.
# Проверяем только если каталог fake уже есть (на host без /opt/zapret — тихий skip).
# stdout: по одному пути на строку.
zapret_missing_fake_files_from_text() {
    text="$1"
    printf '%s\n' "$text" | tr -d '\r' | sed -n 's|.*\(/opt/zapret[0-9]*/files/fake/[^[:space:]]*\).*|\1|p' | sort -u | while IFS= read -r path; do
        [ -n "$path" ] || continue
        dir="$(dirname -- "$path")"
        [ -d "$dir" ] || continue
        [ -f "$path" ] || printf '%s\n' "$path"
    done
}

zapret_missing_fake_files_runtime() {
    uci_file="$(zapret_runtime_uci_path)"
    key="${ZAPRET_OPT_KEY:-NFQWS_OPT}"
    opt="$(zapret_uci_extract_option "$uci_file" "$key" 2>/dev/null || true)"
    zapret_missing_fake_files_from_text "$opt"
}

zapret_daemon_log_snippet() {
    name="$(zapret_nfqws_proc_name)"
    if command -v logread >/dev/null 2>&1; then
        # Без ifsets/ifup/ifdown (warp/proton flapping) — это не старт nfqws.
        logread -e "$name" 2>/dev/null | grep -viE 'ifsets|ifup|ifdown' | tail -n 16 || true
        logread -e zapret 2>/dev/null | grep -viE 'ifsets|ifup|ifdown' | grep -iE 'err|fail|nfqws|daemon|wrong|config|denied|no such|cannot|invalid|unknown' | tail -n 16 || true
        logread -e ZAPRET 2>/dev/null | grep -viE 'ifsets|ifup|ifdown' | tail -n 12 || true
    fi
    # DAEMON_LOG_ENABLE=1 → /tmp/zapret+… ; иначе файлов может не быть.
    for f in /tmp/zapret+*.log /tmp/zapret2+*.log /tmp/zapret*"$name"* /tmp/zapret2*"$name"*; do
        [ -f "$f" ] || continue
        printf '--- %s ---\n' "$f"
        tail -n 30 "$f" 2>/dev/null || true
    done
}

# Отсутствующие --hostlist=/--ipset=/--hostlist-exclude= пути (каталог должен существовать).
zapret_missing_list_paths_from_text() {
    text="$1"
    printf '%s\n' "$text" | tr -d '\r' | sed -n \
        -e 's|.*--hostlist=\([^[:space:]]*\).*|\1|p' \
        -e 's|.*--hostlist-exclude=\([^[:space:]]*\).*|\1|p' \
        -e 's|.*--ipset=\([^[:space:]]*\).*|\1|p' \
        -e 's|.*--ipset-exclude=\([^[:space:]]*\).*|\1|p' \
        | sort -u | while IFS= read -r path; do
        [ -n "$path" ] || continue
        case "$path" in
            /*) ;;
            *) continue ;;
        esac
        dir="$(dirname -- "$path")"
        [ -d "$dir" ] || continue
        [ -f "$path" ] || printf '%s\n' "$path"
    done
}

# stdout: строки "NAME\trunning|stopped" по procd instances (ubus verbose).
zapret_procd_instances_status() {
    if [ -n "${ZAPRET_PROCD_INSTANCES_TSV:-}" ] && [ -f "${ZAPRET_PROCD_INSTANCES_TSV}" ]; then
        cat "${ZAPRET_PROCD_INSTANCES_TSV}"
        return 0
    fi
    svc="$(zapret_procd_svc_name)"
    raw=""
    if command -v ubus >/dev/null 2>&1; then
        raw="$(ubus call service list "{\"name\":\"$svc\",\"verbose\":1}" 2>/dev/null || true)"
    fi
    [ -n "$raw" ] || return 0
    printf '%s\n' "$raw" | awk -v svc="$svc" '
        BEGIN { cur=""; in_svc=0; in_inst=0 }
        $0 ~ "\"" svc "\"" { in_svc=1 }
        !in_svc { next }
        /"instances"/ { in_inst=1; next }
        in_inst && /"[A-Za-z0-9_.:-]+"[[:space:]]*:[[:space:]]*\{/ {
            line=$0
            sub(/^[^"]*"/, "", line)
            sub(/".*$/, "", line)
            cur=line
            next
        }
        in_inst && cur != "" && /"running"/ {
            if ($0 ~ /true/) print cur "\trunning"
            else print cur "\tstopped"
            cur=""
            next
        }
    '
}

# Сжатый hint для summary: missing_fake|missing_list|procd_down:NAME|log:…
zapret_daemon_failure_hints() {
    hints=""
    miss_fake="$(zapret_missing_fake_files_runtime 2>/dev/null || true)"
    if [ -n "$miss_fake" ]; then
        one="$(printf '%s\n' "$miss_fake" | head -n1)"
        one="$(basename -- "$one" 2>/dev/null || printf '%s\n' "$one")"
        hints="${hints:+$hints,}missing_fake:$one"
    fi

    uci_file="$(zapret_runtime_uci_path)"
    key="${ZAPRET_OPT_KEY:-NFQWS_OPT}"
    opt="$(zapret_uci_extract_option "$uci_file" "$key" 2>/dev/null || true)"
    miss_list="$(zapret_missing_list_paths_from_text "$opt" 2>/dev/null || true)"
    if [ -n "$miss_list" ]; then
        one="$(printf '%s\n' "$miss_list" | head -n1)"
        one="$(basename -- "$one" 2>/dev/null || printf '%s\n' "$one")"
        hints="${hints:+$hints,}missing_list:$one"
    fi

    down=""
    while IFS="$(printf '\t')" read -r iname ist; do
        [ -n "${iname:-}" ] || continue
        [ "${ist:-}" = "stopped" ] || continue
        down="${down:+$down+}$iname"
    done <<EOF
$(zapret_procd_instances_status 2>/dev/null || true)
EOF
    [ -n "$down" ] && hints="${hints:+$hints,}procd_down:$down"

    # Короткий clue из логов (без ifup noise).
    log_clue=""
    if command -v logread >/dev/null 2>&1; then
        log_clue="$(
            {
                logread -e "$(zapret_nfqws_proc_name)" 2>/dev/null || true
                logread -e zapret 2>/dev/null || true
                logread -e ZAPRET 2>/dev/null || true
            } | grep -viE 'ifsets|ifup|ifdown|reloading nftables' \
              | grep -iE 'err|fail|wrong|cannot|no such|denied|invalid|unknown|option|open|file' \
              | tail -n1 | tr '\t' ' ' | cut -c1-120 || true
        )"
    fi
    if [ -z "$log_clue" ]; then
        for f in /tmp/zapret+*.log /tmp/zapret2+*.log; do
            [ -f "$f" ] || continue
            log_clue="$(grep -iE 'err|fail|cannot|no such|invalid|unknown|option' "$f" 2>/dev/null | tail -n1 | tr '\t' ' ' | cut -c1-120 || true)"
            [ -n "$log_clue" ] && break
        done
    fi
    if [ -n "$log_clue" ]; then
        log_clue="$(printf '%s' "$log_clue" | tr ',' ';' )"
        hints="${hints:+$hints,}log:$log_clue"
    fi

    printf '%s\n' "$hints"
}

# Многострочный отчёт для stderr при FAIL (что смотреть / чинить).
zapret_daemon_diagnose_report() {
    printf '--- zapret daemon diagnose ---\n'
    printf 'procd instances:\n'
    inst="$(zapret_procd_instances_status 2>/dev/null || true)"
    if [ -n "$inst" ]; then
        printf '%s\n' "$inst" | sed 's/^/  /; s/\t/ /'
    else
        printf '  (ubus/instances недоступны)\n'
    fi

    miss_fake="$(zapret_missing_fake_files_runtime 2>/dev/null || true)"
    if [ -n "$miss_fake" ]; then
        printf 'missing fake files:\n'
        printf '%s\n' "$miss_fake" | sed 's/^/  /'
    fi

    uci_file="$(zapret_runtime_uci_path)"
    key="${ZAPRET_OPT_KEY:-NFQWS_OPT}"
    opt="$(zapret_uci_extract_option "$uci_file" "$key" 2>/dev/null || true)"
    miss_list="$(zapret_missing_list_paths_from_text "$opt" 2>/dev/null || true)"
    if [ -n "$miss_list" ]; then
        printf 'missing hostlist/ipset paths:\n'
        printf '%s\n' "$miss_list" | sed 's/^/  /'
    fi

    printf 'recent relevant logs:\n'
    snip="$(zapret_daemon_log_snippet 2>/dev/null || true)"
    if [ -n "$snip" ]; then
        printf '%s\n' "$snip" | sed 's/^/  /' | head -n 28
    else
        printf '  (пусто; включите DAEMON_LOG_ENABLE=1 в UCI zapret для /tmp/zapret+*.log)\n'
    fi
}

# Однострочный статус:
#   OK daemons=2/2 nfqws=1 blocks=15
#   FAIL_DAEMON daemons=1/2 … reason=daemons_short hint=procd_down:…,missing_fake:…
# 0 = healthy (можно probe), 1 = unhealthy.
zapret_daemon_health_summary() {
    counts="$(zapret_procd_daemon_counts)"
    working="$(printf '%s\n' "$counts" | awk '{print $1}')"
    total="$(printf '%s\n' "$counts" | awk '{print $2}')"
    case "$working" in ''|*[!0-9]*) working=0 ;; esac
    case "$total" in ''|*[!0-9]*) total=0 ;; esac

    blocks="$(zapret_strategy_blocks_count 2>/dev/null || echo 0)"
    case "$blocks" in ''|*[!0-9]*) blocks=0 ;; esac

    nfq="$(zapret_running_nfqws_count)"
    case "$nfq" in ''|*[!0-9]*) nfq=0 ;; esac

    init_st="down"
    if zapret_service_is_running; then
        init_st="running"
    fi

    missing=""
    miss_list="$(zapret_missing_fake_files_runtime 2>/dev/null || true)"
    if [ -n "$miss_list" ]; then
        missing="$(printf '%s' "$miss_list" | tr '\n' ',' | sed 's/,$//')"
    fi

    reason=""
    ok=1

    if [ -n "$missing" ]; then
        ok=0
        reason="missing_fake"
    fi

    # Неполный procd (1/2 и т.п.) — стратегия/сервис не в норме, curl не запускаем.
    if [ "$total" -gt 0 ] && [ "$working" -lt "$total" ]; then
        ok=0
        reason="${reason:+$reason+}daemons_short"
    fi

    if [ "$blocks" -gt 0 ] && [ "$nfq" -eq 0 ] && [ "$working" -eq 0 ]; then
        ok=0
        reason="${reason:+$reason+}no_nfqws"
    fi

    if [ "$blocks" -gt 0 ] && [ "$total" -eq 0 ] && [ "$nfq" -eq 0 ]; then
        ok=0
        reason="${reason:+$reason+}no_procd_instances"
    fi

    # init.d running — вторично: валим только если нет ни nfqws, ни working.
    if [ "$blocks" -gt 0 ] && [ "$init_st" != "running" ] && [ "$nfq" -eq 0 ] && [ "$working" -eq 0 ]; then
        ok=0
        reason="${reason:+$reason+}init_down"
    fi

    if [ "$blocks" -eq 0 ] && [ "$nfq" -eq 0 ] && [ "$working" -eq 0 ] && [ "$init_st" != "running" ]; then
        ok=0
        reason="${reason:-init_down}"
    fi

    if [ "$ok" -eq 1 ]; then
        printf 'OK daemons=%s/%s nfqws=%s blocks=%s\n' "$working" "$total" "$nfq" "$blocks"
        return 0
    fi

    hint="$(zapret_daemon_failure_hints 2>/dev/null || true)"
    out="FAIL_DAEMON daemons=${working}/${total} nfqws=${nfq} blocks=${blocks} init=${init_st}"
    [ -n "$missing" ] && out="${out} missing_fake=${missing}"
    [ -n "$reason" ] && out="${out} reason=${reason}"
    [ -n "$hint" ] && out="${out} hint=${hint}"
    printf '%s\n' "$out"
    return 1
}

# Ждёт, пока daemons поднимутся после restart (как https-dns-proxy wait running).
# ZAPRET_DAEMON_READY_TIMEOUT (сек, default 12).
# stdout: итоговый zapret_daemon_health_summary; 0/1 как у summary.
zapret_wait_daemons_healthy() {
    timeout="${ZAPRET_DAEMON_READY_TIMEOUT:-12}"
    case "$timeout" in ''|*[!0-9]*) timeout=12 ;; esac
    i=0
    sum=""
    while [ "$i" -lt "$timeout" ]; do
        sum="$(zapret_daemon_health_summary 2>/dev/null || true)"
        case "$sum" in
            OK*)
                printf '%s\n' "$sum"
                return 0
                ;;
            *missing_fake=*|*hint=missing_*)
                # missing_* не «дозреет» — сразу диагностика.
                printf '%s\n' "$sum"
                return 1
                ;;
        esac
        i=$((i + 1))
        sleep 1
    done
    if [ -z "$sum" ]; then
        sum="$(zapret_daemon_health_summary 2>/dev/null || true)"
    fi
    printf '%s\n' "$sum"
    return 1
}
