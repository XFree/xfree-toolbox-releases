#!/bin/sh
# shellcheck shell=sh
# Управление сервисом zapret-openwrt: sync UCI → $ZAPRET_OPT_DIR/config, init.d.
# Контракт как у LuCI «Service daemons → Restart»: sync_config.sh, затем init.d restart.

: "${ZAPRET_SYNC_CONFIG_SCRIPT:=/opt/zapret/sync_config.sh}"
: "${ZAPRET_INITD_SCRIPT:=/etc/init.d/zapret}"

zapret_sync_config_script() {
    printf '%s\n' "$ZAPRET_SYNC_CONFIG_SCRIPT"
}

zapret_initd_script() {
    printf '%s\n' "$ZAPRET_INITD_SCRIPT"
}

# 0 — синхронизация выполнена; 1 — скрипт отсутствует (пропуск).
zapret_sync_config() {
    sync_script="$(zapret_sync_config_script)"
    if [ ! -f "$sync_script" ]; then
        warn "Не найден $sync_script (установлен пакет zapret-openwrt?)."
        return 1
    fi
    info "Синхронизация UCI → ${ZAPRET_OPT_DIR:-/opt/zapret} (sync_config.sh)…"
    if [ -x "$sync_script" ]; then
        "$sync_script" || die "sync_config.sh завершился с ошибкой"
    else
        sh "$sync_script" || die "sync_config.sh завершился с ошибкой"
    fi
    return 0
}

zapret_sync_config_or_die() {
    zapret_sync_config || die "Синхронизация конфига zapret недоступна (нет $ZAPRET_SYNC_CONFIG_SCRIPT)"
}

# start | stop | restart | enable | disable
zapret_service_action() {
    action="$1"
    [ -n "$action" ] || die "zapret_service_action: не указано действие"

    init_script="$(zapret_initd_script)"
    if [ -x "$init_script" ]; then
        "$init_script" "$action" || die "Не удалось выполнить: $init_script $action"
        return 0
    fi
    if [ -f "$init_script" ]; then
        sh "$init_script" "$action" || die "Не удалось выполнить: sh $init_script $action"
        return 0
    fi
    die "Сервис zapret не найден: $init_script"
}

# 0 — процесс/procd instance жив. Нет init.d или нет команды running → не запущен.
zapret_service_is_running() {
    init_script="$(zapret_initd_script)"
    if [ -x "$init_script" ]; then
        "$init_script" running >/dev/null 2>&1 || return 1
        return 0
    fi
    if [ -f "$init_script" ]; then
        sh "$init_script" running >/dev/null 2>&1 || return 1
        return 0
    fi
    return 1
}

# restart если уже работает, иначе start (init.d restart на остановленном сервисе часто no-op).
zapret_service_start_or_restart() {
    quiet="${1:-0}"
    init_script="$(zapret_initd_script)"
    if [ ! -x "$init_script" ] && [ ! -f "$init_script" ]; then
        [ "$quiet" = "1" ] && return 0
        die "Сервис zapret не найден: $init_script"
    fi
    if zapret_service_is_running; then
        if [ "$quiet" = "1" ]; then
            if [ -x "$init_script" ]; then
                "$init_script" restart >/dev/null 2>&1 || true
            else
                sh "$init_script" restart >/dev/null 2>&1 || true
            fi
            return 0
        fi
        info "Перезапуск zapret (init.d restart)…"
        zapret_service_action restart
        return 0
    fi
    if [ "$quiet" = "1" ]; then
        if [ -x "$init_script" ]; then
            "$init_script" start >/dev/null 2>&1 || true
        else
            sh "$init_script" start >/dev/null 2>&1 || true
        fi
        return 0
    fi
    info "zapret не запущен — start"
    zapret_service_action start
}

# Как LuCI Restart: sync_config (если есть), затем restart.
# ZAPRET_RESTART_SKIP_SYNC=1 — только init.d restart (устаревшее поведение).
# ZAPRET_RESTART_QUIET=1 — без info и с подавлением вывода init.d (для apply-changed).
zapret_restart_service() {
    quiet="${ZAPRET_RESTART_QUIET:-0}"
    skip_sync="${ZAPRET_RESTART_SKIP_SYNC:-0}"

    if [ "$skip_sync" != "1" ]; then
        if [ "$quiet" = "1" ]; then
            sync_script="$(zapret_sync_config_script)"
            if [ -f "$sync_script" ]; then
                if [ -x "$sync_script" ]; then
                    "$sync_script" >/dev/null 2>&1 || die "sync_config.sh завершился с ошибкой"
                else
                    sh "$sync_script" >/dev/null 2>&1 || die "sync_config.sh завершился с ошибкой"
                fi
            else
                warn "Пропуск sync_config: $sync_script не найден"
            fi
        else
            zapret_sync_config || die "Перезапуск без sync_config.sh невозможен (как в LuCI)"
        fi
    fi

    zapret_service_start_or_restart "$quiet"
}
