#!/bin/sh
# shellcheck shell=sh
# HTTPS probe for zapret FQDN lists (OpenWrt curl).
# Site "works" = TCP+TLS happened. HTTP 404/520 and curl 60 (CN mismatch) are OK.
# FAIL = resolve/connect/timeout/TLS handshake reset (typical DPI cut).

: "${XFREE_ZAPRET_TEST_PROBE_LIMIT:=0}"
: "${XFREE_ZAPRET_TEST_CONNECT_TIMEOUT:=4}"
: "${XFREE_ZAPRET_TEST_MAX_TIME:=8}"
: "${XFREE_ZAPRET_TEST_IP_FAMILY:=4}"
# Space-separated resolvers tried when default DNS leaves host not alive.
: "${XFREE_ZAPRET_PROBE_ALT_DNS:=1.1.1.1 8.8.8.8 9.9.9.9}"
# Max concurrent curl probes (host lists / YouTube suite). BusyBox-safe (no wait -n).
: "${XFREE_ZAPRET_PROBE_PARALLEL:=6}"

# Normalize parallel limit → stdout int in 1..32.
zapret_probe_parallel_limit() {
	n="${1:-$XFREE_ZAPRET_PROBE_PARALLEL}"
	case "$n" in
		''|*[!0-9]*) n=6 ;;
	esac
	[ "$n" -ge 1 ] || n=1
	[ "$n" -le 32 ] || n=32
	printf '%s\n' "$n"
}

# Global: space-separated background PIDs for probe helpers below.
PROBE_BG_PIDS=""

# Wait until fewer than $1 live jobs remain (BusyBox: no wait -n).
zapret_probe_bg_throttle() {
	max="$1"
	while :; do
		n=0
		# shellcheck disable=SC2086
		for p in $PROBE_BG_PIDS; do
			[ -n "$p" ] || continue
			if kill -0 "$p" 2>/dev/null; then
				n=$((n + 1))
			fi
		done
		[ "$n" -lt "$max" ] && break
		sleep 1
	done
	alive_pids=""
	# shellcheck disable=SC2086
	for p in $PROBE_BG_PIDS; do
		[ -n "$p" ] || continue
		if kill -0 "$p" 2>/dev/null; then
			alive_pids="$alive_pids $p"
		else
			wait "$p" 2>/dev/null || true
		fi
	done
	PROBE_BG_PIDS="$alive_pids"
}

# Reap all background probe jobs.
zapret_probe_bg_wait_all() {
	while [ -n "$(printf '%s' "$PROBE_BG_PIDS" | tr -d '[:space:]')" ]; do
		zapret_probe_bg_throttle 1
	done
	# shellcheck disable=SC2086
	for p in $PROBE_BG_PIDS; do
		[ -n "$p" ] || continue
		wait "$p" 2>/dev/null || true
	done
	PROBE_BG_PIDS=""
}

# Launch: $1=outfile; remaining args = command. Writes via .tmp then rename.
zapret_probe_bg_launch() {
	_out="$1"
	shift
	(
		"$@" >"$_out.tmp" 2>/dev/null || true
		mv -f "$_out.tmp" "$_out"
	) &
	PROBE_BG_PIDS="$PROBE_BG_PIDS $!"
}

zapret_probe_host_ok_syntax() {
	h="$1"
	[ -n "$h" ] || return 1
	case "$h" in
		\#*) return 1 ;;
		.*) return 1 ;;
		*[\ /]*) return 1 ;;
		*\**) return 1 ;;
	esac
	case "$h" in
		*[A-Za-z]*) ;;
		*) return 1 ;;
	esac
	case "$h" in
		*.*) ;;
		*) return 1 ;;
	esac
	return 0
}

zapret_probe_host_score() {
	h="$1"
	score=1
	dots=0
	rest="$h"
	while [ "$rest" != "${rest#*.}" ]; do
		dots=$((dots + 1))
		rest="${rest#*.}"
	done
	# Prefer registrable apex (youtube.com) and www over CDN 3+ labels.
	if [ "$dots" -eq 1 ]; then
		score=4
	elif [ "$dots" -ge 2 ]; then
		score=2
	fi
	case "$h" in
		www.*) score=5 ;;
	esac
	printf '%s\n' "$score"
}

# rc + http_code → "OK reason" | "FAIL reason". Return 0 if OK.
zapret_probe_classify_curl() {
	rc="$1"
	http_code="$2"
	case "$http_code" in
		[1-9][0-9][0-9])
			printf 'OK http=%s\n' "$http_code"
			return 0
			;;
	esac
	case "$rc" in
		0)
			printf 'OK http=%s\n' "${http_code:-000}"
			return 0
			;;
		60)
			printf 'OK tls-cert-mismatch\n'
			return 0
			;;
		6)
			printf 'FAIL dns\n'
			return 1
			;;
		7)
			printf 'FAIL connect\n'
			return 1
			;;
		28)
			printf 'FAIL timeout\n'
			return 1
			;;
		35)
			printf 'FAIL tls-handshake\n'
			return 1
			;;
		52|56)
			printf 'FAIL empty-or-reset\n'
			return 1
			;;
		*)
			printf 'FAIL curl=%s http=%s\n' "$rc" "${http_code:-000}"
			return 1
			;;
	esac
}

# Ranked unique curlable hosts from fqdn.d/*.lst → stdout (at most $2 lines).
# Optional $3: section name (youtube_29 → hint youtube) so youtube.com beats random 2-label CDNs.
zapret_probe_collect_fqdn_dir() {
	fqdn_dir="$1"
	limit="${2:-$XFREE_ZAPRET_TEST_PROBE_LIMIT}"
	hint="${3:-}"
	hrest="$hint"
	while [ -n "$hrest" ] && [ "$hrest" != "${hrest%_[0-9]*}" ]; do
		hrest="${hrest%_[0-9]*}"
	done
	[ -n "$hrest" ] && hint="$hrest"
	case "$hint" in
		user|cust|cust1|dot-tls) hint="" ;;
	esac
	tmp="$(mktemp)"
	: >"$tmp"
	if [ -d "$fqdn_dir" ]; then
		for f in "$fqdn_dir"/*.lst; do
			[ -f "$f" ] || continue
			while IFS= read -r line || [ -n "$line" ]; do
				line="$(printf '%s' "$line" | tr -d '\r' | sed 's/#.*//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
				zapret_probe_host_ok_syntax "$line" || continue
				sc="$(zapret_probe_host_score "$line")"
				if [ -n "$hint" ]; then
					case "$line" in
						"$hint".com|"$hint".net|"$hint".org|www."$hint".com|www."$hint".net)
							sc=$((sc + 20))
							;;
						*"$hint"*)
							sc=$((sc + 10))
							;;
					esac
				fi
				printf '%s\t%s\n' "$sc" "$line" >>"$tmp"
			done <"$f"
		done
	fi
	if [ ! -s "$tmp" ]; then
		rm -f "$tmp"
		return 0
	fi
	sort -t "$(printf '\t')" -k1,1nr -k2,2 "$tmp" |
		awk -F'\t' '!seen[$2]++ { print $2 }' |
		{
			# 0 / empty / all = no cap (probe every curlable FQDN in the section).
			case "$limit" in
				''|0|all|ALL) cat ;;
				*)
					if [ "$limit" -gt 0 ] 2>/dev/null; then
						head -n "$limit"
					else
						cat
					fi
					;;
			esac
		}
	rm -f "$tmp"
}

zapret_probe_curl_family_args() {
	case "${XFREE_ZAPRET_TEST_IP_FAMILY:-4}" in
		6) printf '%s\n' "-6" ;;
		any) ;;
		*) printf '%s\n' "-4" ;;
	esac
}

# Map classify result → alive=yes|no|unknown (dpi-checkers Alive column).
zapret_probe_alive_from_classify() {
	cls="$1"
	case "$cls" in
		OK*) printf 'yes\n' ;;
		FAIL\ dns|FAIL\ connect|FAIL\ timeout) printf 'no\n' ;;
		*) printf 'unknown\n' ;;
	esac
}

# Resolve A via dig/nslookup. $1=host $2=dns-server. stdout: IPv4 or empty.
zapret_probe_resolve_a() {
	host="$1"
	dns="$2"
	ip=""
	if command -v dig >/dev/null 2>&1; then
		ip="$(dig +time=2 +tries=1 +short A "$host" @"$dns" 2>/dev/null | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -n1 || true)"
	elif command -v nslookup >/dev/null 2>&1; then
		ip="$(nslookup "$host" "$dns" 2>/dev/null | awk '
			/^Address: / && $2 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ { print $2; exit }
			/^Address [0-9]+: / && $3 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ { print $3; exit }
		' || true)"
	fi
	printf '%s\n' "$ip"
}

# Try alt DNS list. stdout: "ip dns" or empty.
zapret_probe_resolve_a_alt() {
	host="$1"
	# shellcheck disable=SC2086
	for dns in $XFREE_ZAPRET_PROBE_ALT_DNS; do
		[ -n "$dns" ] || continue
		ip="$(zapret_probe_resolve_a "$host" "$dns")"
		if [ -n "$ip" ]; then
			printf '%s %s\n' "$ip" "$dns"
			return 0
		fi
	done
	return 1
}

# curl --resolve args for host:443 → ip (empty if no ip).
zapret_probe_curl_resolve_args() {
	host="$1"
	ip="$2"
	[ -n "$host" ] && [ -n "$ip" ] || return 0
	printf '%s\n' "--resolve" "${host}:443:${ip}"
}

# stdout: "OK   host  reason alive=…" | "FAIL host  reason alive=…".
# If default path is not alive (dns/connect/timeout), retry via alt DNS + --resolve.
zapret_probe_one_host() {
	host="$1"
	fam="$(zapret_probe_curl_family_args)"
	http_code=""
	rc=0
	# shellcheck disable=SC2086
	http_code="$(curl $fam -sS -o /dev/null -w "%{http_code}" \
		--connect-timeout "$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT" \
		-m "$XFREE_ZAPRET_TEST_MAX_TIME" \
		"https://$host" 2>/dev/null)" || rc=$?
	http_code="$(printf '%s' "$http_code" | tr -d '\r')"
	cls="$(zapret_probe_classify_curl "$rc" "$http_code")" || true
	alive="$(zapret_probe_alive_from_classify "$cls")"
	dns_note=""
	if [ "$alive" = "no" ]; then
		alt="$(zapret_probe_resolve_a_alt "$host" || true)"
		if [ -n "$alt" ]; then
			aip="$(printf '%s' "$alt" | awk '{print $1}')"
			adns="$(printf '%s' "$alt" | awk '{print $2}')"
			rc2=0
			# shellcheck disable=SC2086
			http_code="$(curl $fam -sS -o /dev/null -w "%{http_code}" \
				--connect-timeout "$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT" \
				-m "$XFREE_ZAPRET_TEST_MAX_TIME" \
				--resolve "${host}:443:${aip}" \
				"https://$host" 2>/dev/null)" || rc2=$?
			http_code="$(printf '%s' "$http_code" | tr -d '\r')"
			cls2="$(zapret_probe_classify_curl "$rc2" "$http_code")" || true
			alive2="$(zapret_probe_alive_from_classify "$cls2")"
			if [ "$alive2" = "yes" ]; then
				cls="$cls2"
				alive=yes
				dns_note=" dns=${adns}/${aip}"
			fi
		fi
	fi
	case "$cls" in
		OK*)
			printf 'OK   %s  %s alive=%s%s\n' "$host" "${cls#OK }" "$alive" "$dns_note"
			return 0
			;;
		*)
			printf 'FAIL %s  %s alive=%s%s\n' "$host" "${cls#FAIL }" "$alive" "$dns_note"
			return 1
			;;
	esac
}
