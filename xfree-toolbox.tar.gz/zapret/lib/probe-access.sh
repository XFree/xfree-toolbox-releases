#!/bin/sh
# shellcheck shell=sh
# HTTPS probe for zapret FQDN lists (OpenWrt curl).
# Site "works" = TCP+TLS happened. HTTP 404/520 and curl 60 (CN mismatch) are OK.
# FAIL = resolve/connect/timeout/TLS handshake reset (typical DPI cut).

: "${XFREE_ZAPRET_TEST_PROBE_LIMIT:=6}"
: "${XFREE_ZAPRET_TEST_CONNECT_TIMEOUT:=4}"
: "${XFREE_ZAPRET_TEST_MAX_TIME:=8}"
: "${XFREE_ZAPRET_TEST_IP_FAMILY:=4}"

zapret_probe_host_ok_syntax() {
	h="$1"
	[ -n "$h" ] || return 1
	case "$h" in
		\#*) return 1 ;;
		*[\ /]*) return 1 ;;
		*\**) return 1 ;;
	esac
	case "$h" in
		*[A-Za-z]*) ;;
		*) return 1 ;;
	esac
	case "$h" in
		*.*) ;;
		*) return 1 ;;
	esac
	return 0
}

zapret_probe_host_score() {
	h="$1"
	score=1
	dots=0
	rest="$h"
	while [ "$rest" != "${rest#*.}" ]; do
		dots=$((dots + 1))
		rest="${rest#*.}"
	done
	# Prefer registrable apex (youtube.com) and www over CDN 3+ labels.
	if [ "$dots" -eq 1 ]; then
		score=4
	elif [ "$dots" -ge 2 ]; then
		score=2
	fi
	case "$h" in
		www.*) score=5 ;;
	esac
	printf '%s\n' "$score"
}

# rc + http_code → "OK reason" | "FAIL reason". Return 0 if OK.
zapret_probe_classify_curl() {
	rc="$1"
	http_code="$2"
	case "$http_code" in
		[1-9][0-9][0-9])
			printf 'OK http=%s\n' "$http_code"
			return 0
			;;
	esac
	case "$rc" in
		0)
			printf 'OK http=%s\n' "${http_code:-000}"
			return 0
			;;
		60)
			printf 'OK tls-cert-mismatch\n'
			return 0
			;;
		6)
			printf 'FAIL dns\n'
			return 1
			;;
		7)
			printf 'FAIL connect\n'
			return 1
			;;
		28)
			printf 'FAIL timeout\n'
			return 1
			;;
		35)
			printf 'FAIL tls-handshake\n'
			return 1
			;;
		52|56)
			printf 'FAIL empty-or-reset\n'
			return 1
			;;
		*)
			printf 'FAIL curl=%s http=%s\n' "$rc" "${http_code:-000}"
			return 1
			;;
	esac
}

# Ranked unique curlable hosts from fqdn.d/*.lst → stdout (at most $2 lines).
# Optional $3: section name (youtube_29 → hint youtube) so youtube.com beats random 2-label CDNs.
zapret_probe_collect_fqdn_dir() {
	fqdn_dir="$1"
	limit="${2:-$XFREE_ZAPRET_TEST_PROBE_LIMIT}"
	hint="${3:-}"
	hrest="$hint"
	while [ -n "$hrest" ] && [ "$hrest" != "${hrest%_[0-9]*}" ]; do
		hrest="${hrest%_[0-9]*}"
	done
	[ -n "$hrest" ] && hint="$hrest"
	case "$hint" in
		user|cust|cust1|udp-dns|dot-tls) hint="" ;;
	esac
	tmp="$(mktemp)"
	: >"$tmp"
	if [ -d "$fqdn_dir" ]; then
		for f in "$fqdn_dir"/*.lst; do
			[ -f "$f" ] || continue
			while IFS= read -r line || [ -n "$line" ]; do
				line="$(printf '%s' "$line" | tr -d '\r' | sed 's/#.*//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
				zapret_probe_host_ok_syntax "$line" || continue
				sc="$(zapret_probe_host_score "$line")"
				if [ -n "$hint" ]; then
					case "$line" in
						"$hint".com|"$hint".net|"$hint".org|www."$hint".com|www."$hint".net)
							sc=$((sc + 20))
							;;
						*"$hint"*)
							sc=$((sc + 10))
							;;
					esac
				fi
				printf '%s\t%s\n' "$sc" "$line" >>"$tmp"
			done <"$f"
		done
	fi
	if [ ! -s "$tmp" ]; then
		rm -f "$tmp"
		return 0
	fi
	sort -t "$(printf '\t')" -k1,1nr -k2,2 "$tmp" |
		awk -F'\t' '!seen[$2]++ { print $2 }' |
		head -n "$limit"
	rm -f "$tmp"
}

zapret_probe_curl_family_args() {
	case "${XFREE_ZAPRET_TEST_IP_FAMILY:-4}" in
		6) printf '%s\n' "-6" ;;
		any) ;;
		*) printf '%s\n' "-4" ;;
	esac
}

# stdout: "OK   host  reason" | "FAIL host  reason". Return 0 if OK.
zapret_probe_one_host() {
	host="$1"
	fam="$(zapret_probe_curl_family_args)"
	http_code=""
	rc=0
	# shellcheck disable=SC2086
	http_code="$(curl $fam -sS -o /dev/null -w "%{http_code}" \
		--connect-timeout "$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT" \
		-m "$XFREE_ZAPRET_TEST_MAX_TIME" \
		"https://$host" 2>/dev/null)" || rc=$?
	http_code="$(printf '%s' "$http_code" | tr -d '\r')"
	cls="$(zapret_probe_classify_curl "$rc" "$http_code")" || true
	case "$cls" in
		OK*)
			printf 'OK   %s  %s\n' "$host" "${cls#OK }"
			return 0
			;;
		*)
			printf 'FAIL %s  %s\n' "$host" "${cls#FAIL }"
			return 1
			;;
	esac
}
