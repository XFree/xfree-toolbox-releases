#!/bin/sh
# shellcheck shell=sh
# Toolbox vs menu-created zapret sections.
# Absence of ZAPRET_SECTION_ORIGIN (or any value except manual) = toolbox-owned:
# overwritten on template sync, deleted if missing from sections.order.
# ZAPRET_SECTION_ORIGIN='manual' = created via menu; kept on update.

zapret_section_origin_manual_value() {
	printf '%s\n' 'manual'
}

zapret_section_conf_origin() {
	conf="$1"
	[ -f "$conf" ] || return 0
	awk -F"'" '
		$1 == "ZAPRET_SECTION_ORIGIN=" {
			v = $2
			gsub(/\r/, "", v)
			print v
			exit
		}
	' "$conf"
}

zapret_section_dir_is_manual() {
	section_dir="$1"
	origin="$(zapret_section_conf_origin "$section_dir/config/section.conf" || true)"
	[ "$origin" = "manual" ]
}

zapret_section_conf_set_origin() {
	conf="$1"
	origin="$2"
	[ -f "$conf" ] || return 1
	tmp="${conf}.tmp.$$"
	awk -v v="$origin" '
		BEGIN { set = 0 }
		/^ZAPRET_SECTION_ORIGIN=/ {
			print "ZAPRET_SECTION_ORIGIN='\''" v "'\''"
			set = 1
			next
		}
		{ print }
		END {
			if (set == 0) print "ZAPRET_SECTION_ORIGIN='\''" v "'\''"
		}
	' "$conf" >"$tmp"
	mv "$tmp" "$conf"
}
