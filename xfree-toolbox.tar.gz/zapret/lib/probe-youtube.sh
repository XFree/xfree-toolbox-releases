#!/bin/sh
# shellcheck shell=sh
# YouTube probe from router OUTPUT only:
#   home, watch, thumb-hq, googlevideo generate_204 (CDN liveness).
# No videoplayback / cdn-play — not reliable from router; video on LAN → check on PC.

: "${XFREE_ZAPRET_YT_HOME_URL:=https://www.youtube.com/}"
: "${XFREE_ZAPRET_YT_WATCH_URL:=https://www.youtube.com/watch?v=beTuZ0mlkn4&list=RDbeTuZ0mlkn4&start_radio=1}"
: "${XFREE_ZAPRET_YT_VIDEO_ID:=beTuZ0mlkn4}"
: "${XFREE_ZAPRET_YT_MEDIA_RANGE:=0-65535}"
: "${XFREE_ZAPRET_YT_MIN_BYTES:=2048}"
: "${XFREE_ZAPRET_YT_CDN_MAX:=4}"
: "${XFREE_ZAPRET_YT_EXTRA_HOSTS:=0}"
: "${XFREE_ZAPRET_YT_PARALLEL:=}"
: "${XFREE_ZAPRET_YT_UA:=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36}"
: "${XFREE_ZAPRET_YT_INNERTUBE_VER:=1.65.10}"
: "${XFREE_ZAPRET_YT_INNERTUBE_UA:=com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip}"
: "${XFREE_ZAPRET_YT_PLAYER_URL:=https://youtubei.googleapis.com/youtubei/v1/player}"
: "${XFREE_ZAPRET_YT_VISITOR_URL:=https://youtubei.googleapis.com/youtubei/v1/visitor_id}"

zapret_probe_youtube_target_p() {
	section="${1:-}"
	host_file="${2:-}"
	case "$section" in
		youtube|youtube_*|googlevideo) return 0 ;;
	esac
	case "$host_file" in
		*google*|*youtube*|*googlevideo*) return 0 ;;
	esac
	return 1
}

zapret_probe_youtube_core_hosts() {
	cat <<'EOF'
www.youtube.com
youtube.com
i.ytimg.com
i9.ytimg.com
s.ytimg.com
yt3.ggpht.com
yt4.ggpht.com
ggpht.com
manifest.googlevideo.com
youtubei.googleapis.com
EOF
}

zapret_probe_youtube_fallback_cdn_hosts() {
	cat <<'EOF'
rr1---sn-q4fl6n6y.googlevideo.com
rr2---sn-q4fl6ndl.googlevideo.com
rr4---sn-4g5e6nze.googlevideo.com
rr5---sn-n8v7knez.googlevideo.com
EOF
}

zapret_probe_youtube_extract_cdn_hosts() {
	body_file="$1"
	max="${2:-$XFREE_ZAPRET_YT_CDN_MAX}"
	[ -f "$body_file" ] || return 0
	tr '"' '\n' <"$body_file" |
		tr "'" '\n' |
		sed -n 's#^https*://\([^/]*googlevideo\.com\).*#\1#p; s#^\([^/]*googlevideo\.com\)$#\1#p' |
		grep -E '^[A-Za-z0-9._-]+\.googlevideo\.com$' |
		awk '!seen[$0]++' |
		head -n "$max"
}

# Kept for unit tests / callers that parse player JSON.
zapret_probe_youtube_extract_playback_url() {
	body_file="$1"
	[ -f "$body_file" ] || return 0
	u140="$(tr '"' '\n' <"$body_file" |
		grep -E '^https://[A-Za-z0-9._-]+\.googlevideo\.com/videoplayback' |
		grep 'itag=140' |
		head -n1 || true)"
	if [ -n "$u140" ]; then
		printf '%s\n' "$u140"
		return 0
	fi
	tr '"' '\n' <"$body_file" |
		grep -E '^https://[A-Za-z0-9._-]+\.googlevideo\.com/videoplayback' |
		head -n1 || true
}

zapret_probe_youtube_visitor_data() {
	fam="$(zapret_probe_curl_family_args)"
	tmp="$(mktemp)"
	# shellcheck disable=SC2086
	curl $fam -sS -L \
		-A "$XFREE_ZAPRET_YT_INNERTUBE_UA" \
		-H 'Content-Type: application/json' \
		--connect-timeout "$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT" \
		-m "$XFREE_ZAPRET_TEST_MAX_TIME" \
		-d '{"context":{"client":{"clientName":"ANDROID_VR","clientVersion":"'"$XFREE_ZAPRET_YT_INNERTUBE_VER"'"}}}' \
		-o "$tmp" \
		"$XFREE_ZAPRET_YT_VISITOR_URL" >/dev/null 2>&1 || true
	sed -n 's/.*"visitorData"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$tmp" | head -n1
	rm -f "$tmp"
}

# InnerTube player → googlevideo hostnames (for generate_204). stdout: host list.
zapret_probe_youtube_discover_cdn() {
	vid="${1:-$XFREE_ZAPRET_YT_VIDEO_ID}"
	cache="${XFREE_ZAPRET_YT_CDN_CACHE:-}"
	fam="$(zapret_probe_curl_family_args)"
	vd="$(zapret_probe_youtube_visitor_data)"
	body="$(mktemp)"
	out="$(mktemp)"
	hosts_out="$(mktemp)"
	: >"$hosts_out"

	cat >"$body" <<EOF
{"context":{"client":{"clientName":"ANDROID_VR","clientVersion":"$XFREE_ZAPRET_YT_INNERTUBE_VER","deviceMake":"Oculus","deviceModel":"Quest 3","androidSdkVersion":32,"osName":"Android","osVersion":"12L","visitorData":"$vd"}},"videoId":"$vid","contentCheckOk":true,"racyCheckOk":true}
EOF
	# shellcheck disable=SC2086
	curl $fam -sS -L \
		-A "$XFREE_ZAPRET_YT_INNERTUBE_UA" \
		-H 'Content-Type: application/json' \
		--connect-timeout "$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT" \
		-m "$XFREE_ZAPRET_TEST_MAX_TIME" \
		-d @"$body" \
		-o "$out" \
		"$XFREE_ZAPRET_YT_PLAYER_URL" >/dev/null 2>&1 || true
	rm -f "$body"

	zapret_probe_youtube_extract_cdn_hosts "$out" "$XFREE_ZAPRET_YT_CDN_MAX" >"$hosts_out"
	play_url="$(zapret_probe_youtube_extract_playback_url "$out" | head -n1 || true)"
	if [ -n "$play_url" ] && [ ! -s "$hosts_out" ]; then
		sed -n 's#^https://\([^/]*googlevideo\.com\)/.*#\1#p' <<EOF >"$hosts_out"
$play_url
EOF
	fi
	rm -f "$out"

	if [ ! -s "$hosts_out" ]; then
		zapret_probe_youtube_fallback_cdn_hosts >"$hosts_out"
	fi
	if [ -n "$cache" ]; then
		mkdir -p "$cache" 2>/dev/null || true
		cp -f "$hosts_out" "$cache/hosts" 2>/dev/null || true
	fi
	cat "$hosts_out"
	rm -f "$hosts_out"
}

zapret_probe_youtube_discover_cdn_hosts() {
	zapret_probe_youtube_discover_cdn "$@"
}

# Pick one googlevideo host for cdn-204 → stdout hostname.
zapret_probe_youtube_pick_cdn_host() {
	hosts_tmp="$(mktemp)"
	if [ "${XFREE_ZAPRET_YT_SKIP_DISCOVER:-0}" = "1" ]; then
		zapret_probe_youtube_fallback_cdn_hosts >"$hosts_tmp"
	elif [ -n "${XFREE_ZAPRET_YT_CDN_CACHE:-}" ] && [ -f "$XFREE_ZAPRET_YT_CDN_CACHE/hosts" ]; then
		cp -f "$XFREE_ZAPRET_YT_CDN_CACHE/hosts" "$hosts_tmp"
	else
		zapret_probe_youtube_discover_cdn >"$hosts_tmp" 2>/dev/null || true
		[ -s "$hosts_tmp" ] || zapret_probe_youtube_fallback_cdn_hosts >"$hosts_tmp"
	fi
	head -n1 "$hosts_tmp"
	rm -f "$hosts_tmp"
}

# label|url lines for router-feasible probes only.
zapret_probe_youtube_collect_urls() {
	vid="${XFREE_ZAPRET_YT_VIDEO_ID}"
	printf '%s|%s\n' 'home' "$XFREE_ZAPRET_YT_HOME_URL"
	printf '%s|%s\n' 'watch' "$XFREE_ZAPRET_YT_WATCH_URL"
	printf '%s|%s\n' 'thumb-hq' "https://i.ytimg.com/vi/${vid}/hqdefault.jpg"

	h="$(zapret_probe_youtube_pick_cdn_host)"
	if [ -n "$h" ] && zapret_probe_host_ok_syntax "$h"; then
		printf 'cdn-204|https://%s/generate_204\n' "$h"
	fi

	if [ "${XFREE_ZAPRET_YT_EXTRA_HOSTS:-0}" = "1" ]; then
		zapret_probe_youtube_core_hosts | while IFS= read -r hx; do
			[ -n "$hx" ] || continue
			case "$hx" in
				www.youtube.com|youtube.com|i.ytimg.com) continue ;;
			esac
			printf 'host|https://%s/\n' "$hx"
		done
	fi
}

zapret_probe_one_url_media() {
	label="$1"
	url="$2"
	fam="$(zapret_probe_curl_family_args)"
	ua="$XFREE_ZAPRET_YT_UA"
	max_t="$XFREE_ZAPRET_TEST_MAX_TIME"
	conn_t="$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT"

	http_code=""
	size=0
	rc=0
	# shellcheck disable=SC2086
	out="$(curl $fam -sS -L \
		-A "$ua" \
		-e 'https://www.youtube.com/' \
		--connect-timeout "$conn_t" \
		-m "$max_t" \
		--speed-time 5 \
		--speed-limit 1 \
		--range "$XFREE_ZAPRET_YT_MEDIA_RANGE" \
		-o /dev/null \
		-w '%{http_code} %{size_download}' \
		"$url" 2>/dev/null)" || rc=$?
	http_code="$(printf '%s' "$out" | awk '{print $1}' | tr -d '\r')"
	size="$(printf '%s' "$out" | awk '{print $2}' | tr -d '\r')"
	size="${size:-0}"
	alive=yes
	case "$rc" in
		28|7|6) alive=no ;;
		*)
			case "$http_code" in
				[1-9][0-9][0-9]) alive=yes ;;
				*) alive=unknown ;;
			esac
			;;
	esac
	if [ "$alive" = "no" ] && { [ -z "$http_code" ] || [ "$http_code" = "000" ]; }; then
		printf 'SKIP %s  alive=no\n' "$label"
		return 2
	fi
	case "$http_code" in
		[1-9][0-9][0-9])
			need="$XFREE_ZAPRET_YT_MIN_BYTES"
			case "$label" in
				thumb-*) need=1 ;;
				cdn-204)
					if [ "$http_code" = "204" ] || [ "$http_code" = "200" ]; then
						printf 'OK   %s  alive=%s http=%s bytes=%s\n' "$label" "$alive" "$http_code" "$size"
						return 0
					fi
					printf 'FAIL %s  alive=%s http=%s (want 204)\n' "$label" "$alive" "$http_code"
					return 1
					;;
				host)
					case "$http_code" in
						2*) need=1 ;;
						*)
							printf 'SKIP %s  alive=%s http=%s (host smoke)\n' "$label" "$alive" "$http_code"
							return 2
							;;
					esac
					;;
			esac
			if [ "$size" -ge "$need" ] 2>/dev/null; then
				printf 'OK   %s  alive=%s http=%s bytes=%s\n' "$label" "$alive" "$http_code" "$size"
				return 0
			fi
			case "$label" in
				home|watch)
					if [ "$size" -ge 1 ] 2>/dev/null || [ "$http_code" = "200" ]; then
						printf 'OK   %s  alive=%s http=%s bytes=%s\n' "$label" "$alive" "$http_code" "$size"
						return 0
					fi
					;;
			esac
			printf 'FAIL %s  alive=%s http=%s bytes=%s (need>=%s)\n' "$label" "$alive" "$http_code" "$size" "$need"
			return 1
			;;
	esac
	cls="$(zapret_probe_classify_curl "$rc" "$http_code")" || true
	case "$cls" in
		OK*)
			printf 'FAIL %s  alive=%s no-body %s\n' "$label" "$alive" "${cls#OK }"
			return 1
			;;
		*)
			printf 'FAIL %s  alive=%s %s\n' "$label" "$alive" "${cls#FAIL }"
			return 1
			;;
	esac
}

# page = home|watch, thumb = thumb-hq, cdn = cdn-204
zapret_probe_youtube_bucket_update() {
	label="$1"
	ok_line="$2"
	case "$ok_line" in
		OK*) ;;
		*) return 0 ;;
	esac
	case "$label" in
		home|watch) YT_BUCKET_PAGE=1 ;;
		thumb-hq) YT_BUCKET_THUMB=1 ;;
		cdn-204) YT_BUCKET_CDN=1 ;;
	esac
}

zapret_probe_youtube_run_suite() {
	if [ "${XFREE_ZAPRET_YT_SKIP_DISCOVER:-0}" != "1" ]; then
		printf '  YouTube: resolve CDN host (InnerTube)…\n'
		h="$(zapret_probe_youtube_pick_cdn_host)"
		[ -n "$h" ] && printf '  CDN host: %s\n' "$h"
	fi

	urls_file="$(mktemp)"
	zapret_probe_youtube_collect_urls >"$urls_file"
	ok=0
	total=0
	skip=0
	YT_BUCKET_PAGE=0
	YT_BUCKET_THUMB=0
	YT_BUCKET_CDN=0

	parall="$(zapret_probe_parallel_limit "${XFREE_ZAPRET_YT_PARALLEL:-$XFREE_ZAPRET_PROBE_PARALLEL}")"
	resdir="$(mktemp -d)"
	PROBE_BG_PIDS=""
	job=0
	while IFS='|' read -r label url; do
		[ -n "${url:-}" ] || continue
		job=$((job + 1))
		total=$((total + 1))
		printf '%s\n' "$label" >"$resdir/$job.label"
		zapret_probe_bg_throttle "$parall"
		zapret_probe_bg_launch "$resdir/$job.out" zapret_probe_one_url_media "$label" "$url"
	done <"$urls_file"
	zapret_probe_bg_wait_all

	idx=1
	while [ "$idx" -le "$job" ]; do
		label="$(cat "$resdir/$idx.label" 2>/dev/null || true)"
		line="$(cat "$resdir/$idx.out" 2>/dev/null || true)"
		[ -n "$line" ] || line="FAIL ${label:-?}  alive=no empty"
		printf '  %s\n' "$line"
		case "$line" in
			OK*) ok=$((ok + 1)) ;;
			SKIP*) skip=$((skip + 1)) ;;
		esac
		zapret_probe_youtube_bucket_update "$label" "$line"
		idx=$((idx + 1))
	done
	rm -f "$urls_file"
	rm -rf "$resdir"

	verdict=FAIL
	if [ "$YT_BUCKET_PAGE" -eq 1 ] && [ "$YT_BUCKET_THUMB" -eq 1 ] && [ "$YT_BUCKET_CDN" -eq 1 ]; then
		verdict=PASS
	fi
	printf '  buckets page=%s thumb=%s cdn=%s skip=%s parallel=%s → %s\n' \
		"$YT_BUCKET_PAGE" "$YT_BUCKET_THUMB" "$YT_BUCKET_CDN" "$skip" "$parall" "$verdict"
	if [ "$verdict" = "PASS" ]; then
		printf '  note: ответы с роутера OK; videoplayback с роутера не проверяем\n'
		printf '        воспроизведение видео — проверьте с компьютера (LAN)\n'
	fi
	printf '%s %s %s\n' "$ok" "$total" "$verdict"
}

# Compat: strategy sweep seeds CDN host cache once.
zapret_probe_youtube_refresh_playback() {
	zapret_probe_youtube_discover_cdn >/dev/null 2>&1 || true
}

# Compat: unused after router-only suite; tests may call.
zapret_probe_youtube_play_unwrap() {
	printf '%s\n' "$1"
}
