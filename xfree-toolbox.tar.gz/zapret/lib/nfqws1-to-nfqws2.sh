#!/bin/sh
# shellcheck shell=sh
# Конвертер nfqws1 section.text → nfqws2 (--lua-desync).
# Использование: nfqws1-to-nfqws2.sh [file]  (stdin, если файла нет)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"

usage() {
    cat <<'EOF'
Использование:
  nfqws1-to-nfqws2.sh [section.text]

Читает стратегию nfqws1 и пишет эквивалент nfqws2 (Lua desync) в stdout.
EOF
}

INFILE=""
while [ "$#" -gt 0 ]; do
    case "$1" in
        -h|--help) usage; exit 0 ;;
        *)
            [ -z "$INFILE" ] || { echo "лишний аргумент: $1" >&2; exit 1; }
            INFILE="$1"
            ;;
    esac
    shift
done

awk '
function trim(s) {
    gsub(/^[ \t\r]+|[ \t\r]+$/, "", s)
    return s
}
function blob_name(p,    n) {
    n = p
    gsub(/\\/, "/", n)
    sub(/^.*\//, "", n)
    sub(/\.[^.]*$/, "", n)
    if (n == "tls_clienthello_www_google_com") return "tls_google"
    if (n == "quic_initial_www_google_com") return "quic_google"
    if (n == "tls_clienthello_vk_com") return "tls_vk"
    if (n == "tls_clienthello_gosuslugi_ru") return "tls_gosuslugi"
    if (n == "tls_clienthello_max_ru") return "tls_max"
    if (n == "tls_clienthello_4pda_to") return "tls_4pda"
    if (n == "tls_clienthello_5ka_ru") return "tls_5ka"
    if (n == "tls_clienthello_sochi_park") return "tls_sochi"
    if (n == "quic_initial_4pda_to") return "quic_4pda"
    if (n == "quic_initial_5ka_ru") return "quic_5ka"
    if (n == "quic_initial_rutube_ru") return "quic_rutube"
    if (n == "quic_initial_steamcommunity_com") return "quic_steam"
    if (n == "quic_initial_tencent_com") return "quic_tencent"
    if (n == "stun") return "stun"
    if (n == "stun2") return "stun2"
    if (n == "ACTIVE_DISCORD_UDP") return "discord_udp"
    if (n == "ACTIVE_GAME_UDP") return "game_udp"
    if (n == "") return "blob"
    return n
}
function rewrite_opt_path(p) {
    gsub(/\/opt\/zapret\/files\//, "/opt/zapret2/files/", p)
    gsub(/\/opt\/zapret\/ipset\//, "/opt/zapret2/ipset/", p)
    return p
}
function is_hex_blob(v) {
    return (v ~ /^0x[0-9A-Fa-f]+$/)
}
function blob_ref(v,    p) {
    v = trim(v)
    if (v == "" || v == "!") return "fake_default_tls"
    if (is_hex_blob(v)) return v
    p = rewrite_opt_path(v)
    return blob_name(p)
}
function map_method(m) {
    if (m == "split2") return "multisplit"
    if (m == "disorder2") return "multidisorder"
    if (m == "split") return "multisplit"
    if (m == "disorder") return "multidisorder"
    return m
}
function autottl_args(v,    orig) {
    v = trim(v)
    orig = v
    sub(/:/, ",", orig)
    if (v ~ /:/) return "ip_autottl=" orig ":ip6_autottl=" orig
    return "ip_autottl=" v ",1-20:ip6_autottl=" v ",1-20"
}
function fooling_args(fool, incr,    n, a, i, f, out) {
    fool = trim(fool)
    if (fool == "") return ""
    out = ""
    n = split(fool, a, ",")
    for (i = 1; i <= n; i++) {
        f = trim(a[i])
        if (f == "md5sig") out = out ":tcp_md5"
        else if (f == "ts") out = out ":tcp_ts=-1000:tcp_ts_up"
        else if (f == "badsum") out = out ":badsum"
        else if (f == "datanoack") out = out ":tcp_flags_unset=ack"
        else if (f == "badack") out = out ":tcp_ack=-66000:tcp_ts_up"
        else if (f == "badseq") {
            if (incr == "") out = out ":tcp_seq=-10000:tcp_ack=-66000"
            else out = out ":tcp_seq=" incr
        }
    }
    return out
}
function hfs_mod_args(mod,    n, a, i, kv, k, v, out) {
    mod = trim(mod)
    if (mod == "") return ""
    out = ""
    n = split(mod, a, ",")
    for (i = 1; i <= n; i++) {
        kv = trim(a[i])
        k = kv
        v = ""
        if (index(kv, "=")) {
            k = substr(kv, 1, index(kv, "=") - 1)
            v = substr(kv, index(kv, "=") + 1)
        }
        k = trim(k)
        if (k == "altorder" && v == "1") out = out ":nofake1"
        else if (k == "altorder" && v == "2") out = out ":nofake2"
        else if (k != "") {
            if (v == "") out = out ":" k
            else out = out ":" k "=" v
        }
    }
    return out
}
function reset_block() {
    keep = ""
    filter_tcp = ""
    filter_udp = ""
    filter_l7 = ""
    methods = ""
    split_pos = ""
    seqovl = ""
    seqovl_pat = ""
    fooling = ""
    badseq_incr = ""
    repeats = ""
    any_proto = 0
    cutoff = ""
    ip_id = ""
    autottl = ""
    ttl = ""
    fake_tls_n = 0
    fake_http = ""
    fake_quic = ""
    fake_stun = ""
    fake_discord = ""
    fake_unknown_udp = ""
    fakedsplit_pat = ""
    hfs_mod = ""
    dup_n = ""
    dup_fool = ""
    dup_cutoff = ""
    last_was_fake_tls = 0
    pending_tls_mod = ""
    split("", fake_tls)
    split("", fake_tls_mod)
}
function add_keep(line) {
    if (keep != "") keep = keep "\n"
    keep = keep line
}
function common_extras(    e) {
    e = ""
    if (ip_id != "") e = e ":ip_id=" ip_id
    if (autottl != "") e = e ":" autottl_args(autottl)
    if (ttl != "") e = e ":ip_ttl=" ttl ":ip6_ttl=" ttl
    e = e fooling_args(fooling, badseq_incr)
    return e
}
function has_method(name,    n, a, i, m) {
    n = split(methods, a, ",")
    for (i = 1; i <= n; i++) {
        m = map_method(trim(a[i]))
        if (m == name) return 1
    }
    return 0
}
function infer_l7(    out) {
    if (filter_l7 != "") return filter_l7
    out = ""
    if (filter_tcp != "") {
        if (filter_tcp ~ /(^|,)80(,|$)/ && filter_tcp ~ /(^|,)443(,|$)/) out = "http,tls"
        else if (filter_tcp ~ /(^|,)80(,|$)/) out = "http"
        else if (filter_tcp ~ /853/) out = "tls"
        else out = "tls"
    } else if (filter_udp != "") {
        if (filter_udp ~ /(^|,)53(,|$)/) out = "unknown"
        else out = "quic"
    }
    return out
}
function infer_payload(l7,    out) {
    if (any_proto) return "all"
    out = ""
    if (l7 ~ /tls/) {
        if (out != "") out = out ","
        out = out "tls_client_hello"
    }
    if (l7 ~ /http/) {
        if (out != "") out = out ","
        out = out "http_req"
    }
    if (l7 ~ /quic/) {
        if (out != "") out = out ","
        out = out "quic_initial"
    }
    if (l7 ~ /discord/) {
        if (out != "") out = out ","
        out = out "discord_ip_discovery"
    }
    if (l7 ~ /stun/) {
        if (out != "") out = out ","
        out = out "stun"
    }
    if (l7 ~ /wireguard/) {
        if (out != "") out = out ","
        out = out "wireguard_initiation"
    }
    if (l7 ~ /unknown/) {
        if (out != "") out = out ","
        out = out "unknown"
    }
    if (out == "") {
        if (filter_udp != "") return "quic_initial"
        if (filter_tcp != "") return "tls_client_hello,http_req"
    }
    return out
}
function emit_lua(fname, specific, extras,    s) {
    s = "--lua-desync=" fname
    gsub(/^:+/, "", specific)
    if (specific != "") s = s ":" specific
    if (extras != "") s = s extras
    print s
}
function fake_blob_for_payload(pl) {
    if (pl == "http_req") {
        if (fake_http != "") return blob_ref(fake_http)
        return "fake_default_http"
    }
    if (pl == "quic_initial") {
        if (fake_quic != "") return blob_ref(fake_quic)
        return "fake_default_quic"
    }
    if (pl == "stun") {
        if (fake_stun != "") return blob_ref(fake_stun)
        if (fake_quic != "") return blob_ref(fake_quic)
        return "fake_default_quic"
    }
    if (pl == "discord_ip_discovery") {
        if (fake_discord != "") return blob_ref(fake_discord)
        if (fake_quic != "") return blob_ref(fake_quic)
        return "0x00000000000000000000000000000000"
    }
    if (pl == "unknown") {
        if (fake_unknown_udp != "") return blob_ref(fake_unknown_udp)
        if (fake_quic != "") return blob_ref(fake_quic)
        return "fake_default_quic"
    }
    return ""
}
function emit_fakes(payload, extras,    i, blob, spec, tmod, pl_item, pn, pa, pi, did) {
    did = 0
    if (payload ~ /tls_client_hello/ && fake_tls_n > 0) {
        for (i = 1; i <= fake_tls_n; i++) {
            blob = blob_ref(fake_tls[i])
            tmod = fake_tls_mod[i]
            spec = "blob=" blob
            if (tmod != "") spec = spec ":tls_mod=" tmod
            if (repeats != "") spec = spec ":repeats=" repeats
            emit_lua("fake", spec, extras)
            did = 1
        }
    }
    pn = split(payload, pa, ",")
    for (pi = 1; pi <= pn; pi++) {
        pl_item = trim(pa[pi])
        if (pl_item == "tls_client_hello") continue
        blob = fake_blob_for_payload(pl_item)
        if (blob == "") continue
        spec = "blob=" blob
        if (repeats != "") spec = spec ":repeats=" repeats
        emit_lua("fake", spec, extras)
        did = 1
    }
    if (did) return
    blob = "fake_default_tls"
    if (payload ~ /quic/) {
        if (fake_quic != "") blob = blob_ref(fake_quic)
        else blob = "fake_default_quic"
    } else if (payload ~ /http/) {
        if (fake_http != "") blob = blob_ref(fake_http)
        else blob = "fake_default_http"
    }
    spec = "blob=" blob
    if (repeats != "") spec = spec ":repeats=" repeats
    emit_lua("fake", spec, extras)
}
function emit_split_like(fname, extras,    spec) {
    spec = ""
    if (split_pos != "") spec = spec "pos=" split_pos
    if (seqovl != "") {
        if (spec != "") spec = spec ":"
        spec = spec "seqovl=" seqovl
    }
    if (seqovl_pat != "") {
        if (spec != "") spec = spec ":"
        if (is_hex_blob(seqovl_pat)) spec = spec "seqovl_pattern=" seqovl_pat
        else spec = spec "seqovl_pattern=" blob_ref(seqovl_pat)
    }
    if (fname ~ /faked/ && fakedsplit_pat != "") {
        if (spec != "") spec = spec ":"
        if (is_hex_blob(fakedsplit_pat)) spec = spec "pattern=" fakedsplit_pat
        else spec = spec "pattern=" blob_ref(fakedsplit_pat)
    }
    if (fname == "hostfakesplit") {
        spec = spec hfs_mod_args(hfs_mod)
    }
    if (repeats != "" && !has_method("fake")) {
        if (spec != "") spec = spec ":"
        spec = spec "repeats=" repeats
    }
    emit_lua(fname, spec, extras)
}
function flush_block(    i, l7, payload, extras, n, a, m, want_l7, lastmod) {
    if (keep == "" && methods == "" && filter_tcp == "" && filter_udp == "") return
    lastmod = pending_tls_mod
    for (i = 1; i <= fake_tls_n; i++) {
        if (fake_tls_mod[i] != "") lastmod = fake_tls_mod[i]
    }
    if (lastmod != "") {
        for (i = 1; i <= fake_tls_n; i++) {
            if (fake_tls_mod[i] == "") fake_tls_mod[i] = lastmod
        }
    }
    if (out_n++) print "--new"
    if (keep != "") print keep
    extras = common_extras()
    l7 = infer_l7()
    payload = infer_payload(l7)
    want_l7 = (filter_l7 == "" && l7 != "")
    if (want_l7) print "--filter-l7=" l7
    if (cutoff != "" && cutoff != "0") print "--out-range=-" cutoff
    if (dup_n != "") {
        if (dup_cutoff != "") print "--out-range=-" dup_cutoff
        dup_fooling = fooling
        if (dup_fool != "") dup_fooling = dup_fool
        dup_extra = fooling_args(dup_fooling, badseq_incr)
        if (ip_id != "") dup_extra = dup_extra ":ip_id=" ip_id
        emit_lua("send", "", dup_extra)
        if (dup_cutoff != "") print "--out-range=a"
    }
    if (payload != "" && methods != "") print "--payload=" payload
    n = split(methods, a, ",")
    for (i = 1; i <= n; i++) {
        m = map_method(trim(a[i]))
        if (m == "") continue
        if (m == "fake") emit_fakes(payload, extras)
        else if (m == "ipfrag2") {
            emit_lua("send", "ipfrag:ipfrag_pos_udp=8", extras)
            emit_lua("drop", "payload=known", "")
        }
        else emit_split_like(m, extras)
    }
}
BEGIN { reset_block(); out_n = 0 }
{
    line = $0
    sub(/\r$/, "", line)
    line = trim(line)
    if (line == "" || line ~ /^#/ || line ~ /^;/) next
    if (line == "--new") { flush_block(); reset_block(); next }

    if (line ~ /^\{\{/ || line ~ /^--filter-/ || line ~ /^--hostlist/ || line ~ /^--ipset/ || line ~ /^--comment/) {
        add_keep(line)
        if (line ~ /^--filter-tcp=/) { filter_tcp = substr(line, 14); sub(/^[^=]*=/, "", filter_tcp) }
        if (line ~ /^--filter-udp=/) { filter_udp = substr(line, 14); sub(/^[^=]*=/, "", filter_udp) }
        if (line ~ /^--filter-l7=/) { filter_l7 = substr(line, 13); sub(/^[^=]*=/, "", filter_l7) }
        next
    }
    if (line ~ /^--ip-id=/) { ip_id = substr(line, 9); next }

    key = line
    val = ""
    eq = index(line, "=")
    if (eq > 0) {
        key = substr(line, 1, eq - 1)
        val = substr(line, eq + 1)
    } else if (NF >= 2) {
        key = $1
        val = $0
        sub(/^[^ \t]+[ \t]+/, "", val)
    }
    key = trim(key)
    val = trim(val)

    if (key == "--dpi-desync") { methods = val; next }
    if (key == "--dpi-desync-split-pos") { split_pos = val; next }
    if (key == "--dpi-desync-split-seqovl") { seqovl = val; next }
    if (key == "--dpi-desync-split-seqovl-pattern") { seqovl_pat = val; next }
    if (key == "--dpi-desync-fooling") { fooling = val; next }
    if (key == "--dpi-desync-badseq-increment") { badseq_incr = val; next }
    if (key == "--dpi-desync-repeats") { repeats = val; next }
    if (key == "--dpi-desync-any-protocol") { any_proto = (val == "1" || val == "true"); next }
    if (key == "--dpi-desync-cutoff") { cutoff = val; next }
    if (key == "--dpi-desync-autottl") { autottl = val; next }
    if (key == "--dpi-desync-ttl") { ttl = val; next }
    if (key == "--dpi-desync-fake-tls") {
        fake_tls_n++
        fake_tls[fake_tls_n] = val
        fake_tls_mod[fake_tls_n] = pending_tls_mod
        last_was_fake_tls = 1
        next
    }
    if (key == "--dpi-desync-fake-tls-mod") {
        if (last_was_fake_tls && fake_tls_n > 0) fake_tls_mod[fake_tls_n] = val
        else {
            pending_tls_mod = val
            for (i = 1; i <= fake_tls_n; i++) {
                if (fake_tls_mod[i] == "") fake_tls_mod[i] = val
            }
        }
        last_was_fake_tls = 0
        next
    }
    if (key == "--dpi-desync-fake-http") { fake_http = val; next }
    if (key == "--dpi-desync-fake-quic") { fake_quic = val; next }
    if (key == "--dpi-desync-fake-stun") { fake_stun = val; next }
    if (key == "--dpi-desync-fake-discord") { fake_discord = val; next }
    if (key == "--dpi-desync-fake-unknown-udp") { fake_unknown_udp = val; next }
    if (key == "--dpi-desync-fakedsplit-pattern") { fakedsplit_pat = val; next }
    if (key == "--dpi-desync-hostfakesplit-mod") { hfs_mod = val; next }
    if (key == "--dup") { dup_n = val; next }
    if (key == "--dup-fooling") { dup_fool = val; next }
    if (key == "--dup-cutoff") { dup_cutoff = val; next }
    # неизвестные nfqws1-опции не роняем конвертер — пропускаем
}
END { flush_block() }
' ${INFILE:+"$INFILE"}
