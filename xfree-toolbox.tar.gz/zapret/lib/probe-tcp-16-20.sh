#!/bin/sh
# shellcheck shell=sh
# TCP 16-20 probe inspired by hyperion-cs/dpi-checkers (RU :: TCP 16-20).
# Method: host alive (small HTTPS) vs large POST (~64 KiB). Alive+POST timeout ⇒ DETECTED.
# Ref: https://github.com/hyperion-cs/dpi-checkers (Apache-2.0); browser checker uses POST 64KiB + long URI HEAD.

: "${XFREE_ZAPRET_TCP1620_TIMEOUT:=15}"
: "${XFREE_ZAPRET_TCP1620_BYTES:=65536}"
: "${XFREE_ZAPRET_TCP1620_CONNECT:=5}"
: "${XFREE_ZAPRET_TCP1620_PARALLEL:=6}"
: "${XFREE_ZAPRET_TCP1620_UA:=Mozilla/5.0 (compatible; xfree-tcp1620/1.0)}"

# alive: yes|no|unknown. Optional $2=IPv4 for curl --resolve.
zapret_probe_tcp1620_alive() {
	host="$1"
	ip="${2:-}"
	fam="$(zapret_probe_curl_family_args)"
	rc=0
	resolve=""
	[ -n "$ip" ] && resolve="--resolve ${host}:443:${ip}"
	# shellcheck disable=SC2086
	curl $fam -sS -I -L \
		-A "$XFREE_ZAPRET_TCP1620_UA" \
		--connect-timeout "$XFREE_ZAPRET_TCP1620_CONNECT" \
		-m "$XFREE_ZAPRET_TCP1620_TIMEOUT" \
		$resolve \
		-o /dev/null \
		"https://${host}/" >/dev/null 2>&1 || rc=$?
	case "$rc" in
		0) printf 'yes\n' ;;
		28|7|6) printf 'no\n' ;;
		*) printf 'unknown\n' ;;
	esac
}

# POST ~64KiB; stdout: ok|timeout|error. Optional $3=IPv4 for --resolve.
zapret_probe_tcp1620_huge_post() {
	host="$1"
	body="$2"
	ip="${3:-}"
	fam="$(zapret_probe_curl_family_args)"
	nonce="$(date +%s 2>/dev/null || echo 0)$$"
	rc=0
	resolve=""
	[ -n "$ip" ] && resolve="--resolve ${host}:443:${ip}"
	# shellcheck disable=SC2086
	curl $fam -sS -L \
		-A "$XFREE_ZAPRET_TCP1620_UA" \
		--connect-timeout "$XFREE_ZAPRET_TCP1620_CONNECT" \
		-m "$XFREE_ZAPRET_TCP1620_TIMEOUT" \
		$resolve \
		-X POST \
		--data-binary @"$body" \
		-o /dev/null \
		"https://${host}/?t=${nonce}" >/dev/null 2>&1 || rc=$?
	case "$rc" in
		0) printf 'ok\n' ;;
		28) printf 'timeout\n' ;;
		*) printf 'error\n' ;;
	esac
}

# Map alive + post → DETECTED|PROBABLY|POSSIBLE|UNLIKELY|NOT_DETECTED
zapret_probe_tcp1620_classify() {
	alive="$1"
	post="$2"
	case "$post" in
		ok) printf 'NOT_DETECTED\n' ;;
		timeout)
			case "$alive" in
				yes) printf 'DETECTED\n' ;;
				*) printf 'PROBABLY\n' ;;
			esac
			;;
		*)
			case "$alive" in
				yes) printf 'POSSIBLE\n' ;;
				*) printf 'UNLIKELY\n' ;;
			esac
			;;
	esac
}

# One host. stdout: "id\tprovider\thost\talive\tdpi"
# alive may be yes|yes@dns|no|unknown. If default not alive — try alt DNS, then DPI.
zapret_probe_tcp1620_one() {
	id="$1"
	provider="$2"
	host="$3"
	body="$4"
	alive="$(zapret_probe_tcp1620_alive "$host")"
	pin_ip=""
	alive_label="$alive"
	case "$alive" in
		no|unknown)
			alt="$(zapret_probe_resolve_a_alt "$host" || true)"
			if [ -n "$alt" ]; then
				pin_ip="$(printf '%s' "$alt" | awk '{print $1}')"
				adns="$(printf '%s' "$alt" | awk '{print $2}')"
				alive2="$(zapret_probe_tcp1620_alive "$host" "$pin_ip")"
				case "$alive2" in
					yes)
						alive=yes
						alive_label="yes@${adns}"
						;;
					*)
						pin_ip=""
						alive_label="$alive"
						;;
				esac
			fi
			;;
	esac
	case "$alive" in
		no)
			printf '%s\t%s\t%s\t%s\tSKIP\n' "$id" "$provider" "$host" "$alive_label"
			return 0
			;;
	esac
	post="$(zapret_probe_tcp1620_huge_post "$host" "$body" "$pin_ip")"
	dpi="$(zapret_probe_tcp1620_classify "$alive" "$post")"
	printf '%s\t%s\t%s\t%s\t%s\n' "$id" "$provider" "$host" "$alive_label" "$dpi"
}

zapret_probe_tcp1620_count_dpi() {
	dpi="$1"
	case "$dpi" in
		DETECTED) TCP1620_DET=$((TCP1620_DET + 1)) ;;
		PROBABLY) TCP1620_PROB=$((TCP1620_PROB + 1)) ;;
		POSSIBLE) TCP1620_POSS=$((TCP1620_POSS + 1)) ;;
		NOT_DETECTED) TCP1620_OK=$((TCP1620_OK + 1)) ;;
		SKIP) TCP1620_SKIP=$((TCP1620_SKIP + 1)) ;;
	esac
}

# Format raw TSV line → table row on stdout; updates counters.
zapret_probe_tcp1620_emit_line() {
	line="$1"
	[ -n "$line" ] || return 0
	dpi_raw="$(printf '%s' "$line" | cut -f5)"
	alive_raw="$(printf '%s' "$line" | cut -f4)"
	case "$dpi_raw" in
		DETECTED) dpi_show='Detected!' ;;
		NOT_DETECTED) dpi_show='No' ;;
		PROBABLY) dpi_show='Probably' ;;
		POSSIBLE) dpi_show='Possible' ;;
		UNLIKELY) dpi_show='Unlikely' ;;
		SKIP) dpi_show='Skip' ;;
		*) dpi_show="$dpi_raw" ;;
	esac
	case "$alive_raw" in
		yes) alive_show='Yes' ;;
		yes@*) alive_show="Yes(${alive_raw#yes@})" ;;
		no) alive_show='No' ;;
		*) alive_show='Unknown' ;;
	esac
	printf '%-14s %-16s %-36s %-8s %s\n' \
		"$(printf '%s' "$line" | cut -f1)" \
		"$(printf '%s' "$line" | cut -f2)" \
		"$(printf '%s' "$line" | cut -f3)" \
		"$alive_show" \
		"$dpi_show"
	zapret_probe_tcp1620_count_dpi "$dpi_raw"
	TCP1620_TOT=$((TCP1620_TOT + 1))
}

# Wait until fewer than $1 background jobs remain (BusyBox: no wait -n).
zapret_probe_tcp1620_throttle() {
	max="$1"
	while :; do
		n=0
		# shellcheck disable=SC2086
		for p in $TCP1620_PIDS; do
			[ -n "$p" ] || continue
			if kill -0 "$p" 2>/dev/null; then
				n=$((n + 1))
			fi
		done
		[ "$n" -lt "$max" ] && break
		sleep 1
	done
	# Reap finished; keep live pids.
	alive_pids=""
	# shellcheck disable=SC2086
	for p in $TCP1620_PIDS; do
		[ -n "$p" ] || continue
		if kill -0 "$p" 2>/dev/null; then
			alive_pids="$alive_pids $p"
		else
			wait "$p" 2>/dev/null || true
		fi
	done
	TCP1620_PIDS="$alive_pids"
}

# Print any new result files (by numeric name), remove them.
# Must not run in a pipe/subshell — updates TCP1620_* counters.
zapret_probe_tcp1620_flush_results() {
	resdir="$1"
	list="$(mktemp)"
	# shellcheck disable=SC2012
	ls "$resdir" 2>/dev/null | grep -E '^[0-9]+$' | sort -n >"$list" || true
	while IFS= read -r f; do
		[ -n "$f" ] || continue
		[ -f "$resdir/$f" ] || continue
		line="$(cat "$resdir/$f" 2>/dev/null || true)"
		[ -n "$line" ] || continue
		printf '%s' "$line" | awk -F'\t' 'NF>=5 { exit 0 } { exit 1 }' || continue
		zapret_probe_tcp1620_emit_line "$line"
		rm -f "$resdir/$f"
	done <"$list"
	rm -f "$list"
}

# Background one probe → write TSV to outfile when done (.tmp then rename).
zapret_probe_tcp1620_launch() {
	_id="$1"
	_prov="$2"
	_host="$3"
	_body="$4"
	_out="$5"
	(
		zapret_probe_tcp1620_one "$_id" "$_prov" "$_host" "$_body" >"$_out.tmp" 2>/dev/null || true
		mv -f "$_out.tmp" "$_out"
	) &
	TCP1620_PIDS="$TCP1620_PIDS $!"
}

# Run suite file. Optional extra host: XFREE_ZAPRET_TCP1620_HOST / PROVIDER.
# Parallelism: XFREE_ZAPRET_TCP1620_PARALLEL (default 6). Last line: detected=… total=…
# Exit 1 if any DETECTED.
zapret_probe_tcp1620_run_suite() {
	suite="${1:-}"
	[ -n "$suite" ] && [ -f "$suite" ] || {
		printf 'FAIL no suite file\n' >&2
		return 1
	}
	body="$(mktemp)"
	nblk=$((XFREE_ZAPRET_TCP1620_BYTES / 1024))
	[ "$nblk" -ge 1 ] || nblk=64
	if ! dd if=/dev/urandom of="$body" bs=1024 count="$nblk" 2>/dev/null; then
		dd if=/dev/zero of="$body" bs=1024 count="$nblk" 2>/dev/null || true
	fi

	parall="${XFREE_ZAPRET_TCP1620_PARALLEL:-6}"
	case "$parall" in
		''|*[!0-9]*) parall=6 ;;
	esac
	[ "$parall" -ge 1 ] || parall=1
	[ "$parall" -le 32 ] || parall=32

	TCP1620_DET=0
	TCP1620_PROB=0
	TCP1620_POSS=0
	TCP1620_OK=0
	TCP1620_SKIP=0
	TCP1620_TOT=0
	TCP1620_PIDS=""

	resdir="$(mktemp -d)"
	job=0

	printf '=== DPI TCP 16-20 (router curl; not dpi-ch) ===\n'
	printf 'ref: https://hyperion-cs.github.io/dpi-checkers/ru/tcp-16-20\n'
	printf 'timeout=%ss body=%sB parallel=%s\n' \
		"$XFREE_ZAPRET_TCP1620_TIMEOUT" "$XFREE_ZAPRET_TCP1620_BYTES" "$parall"
	printf 'alt-dns on not-alive: %s\n\n' "${XFREE_ZAPRET_PROBE_ALT_DNS:-1.1.1.1 8.8.8.8 9.9.9.9}"
	printf '%-14s %-16s %-36s %-8s %s\n' "ID" "PROVIDER" "HOST" "ALIVE" "TCP16-20"

	while IFS="$(printf '\t')" read -r id provider host _rest; do
		case "$id" in
			''|\#*) continue ;;
		esac
		[ -n "$host" ] || continue
		zapret_probe_tcp1620_throttle "$parall"
		zapret_probe_tcp1620_flush_results "$resdir"
		job=$((job + 1))
		zapret_probe_tcp1620_launch "$id" "$provider" "$host" "$body" "$resdir/$job"
	done <"$suite"

	if [ -n "${XFREE_ZAPRET_TCP1620_HOST:-}" ]; then
		zapret_probe_tcp1620_throttle "$parall"
		zapret_probe_tcp1620_flush_results "$resdir"
		job=$((job + 1))
		zapret_probe_tcp1620_launch "CUSTOM" "${XFREE_ZAPRET_TCP1620_PROVIDER:-Custom}" \
			"$XFREE_ZAPRET_TCP1620_HOST" "$body" "$resdir/$job"
	fi

	# Wait remaining workers; flush as they finish.
	while [ -n "$(printf '%s' "$TCP1620_PIDS" | tr -d '[:space:]')" ]; do
		zapret_probe_tcp1620_flush_results "$resdir"
		zapret_probe_tcp1620_throttle 1
	done
	# shellcheck disable=SC2086
	for p in $TCP1620_PIDS; do
		wait "$p" 2>/dev/null || true
	done
	zapret_probe_tcp1620_flush_results "$resdir"

	rm -f "$body"
	rm -rf "$resdir"
	printf '\n---\n'
	printf 'detected=%s probably=%s possible=%s ok=%s skip=%s total=%s\n' \
		"$TCP1620_DET" "$TCP1620_PROB" "$TCP1620_POSS" "$TCP1620_OK" "$TCP1620_SKIP" "$TCP1620_TOT"
	[ "$TCP1620_DET" -eq 0 ]
}
