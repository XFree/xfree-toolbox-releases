#!/bin/sh
# shellcheck shell=sh
# Тест доступности секций zapret:
#   A) перебор стратегий в профиле (HOST_FILE mutex + apply/restore)
#   B) проверка уже применённых секций из state (только curl)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/ui.sh"
. "$SCRIPT_DIR/lib.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/probe-access.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/probe-youtube.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/probe-tcp-16-20.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/probe-strategy-fast.sh"

PROBE_LIMIT="${XFREE_ZAPRET_TEST_PROBE_LIMIT:-0}"
DEFAULT_DOMAINS="${XFREE_ZAPRET_TEST_DOMAINS:-youtube.com www.youtube.com}"
CONNECT_TIMEOUT="${XFREE_ZAPRET_TEST_CONNECT_TIMEOUT:-4}"
MAX_TIME="${XFREE_ZAPRET_TEST_MAX_TIME:-8}"
XFREE_ZAPRET_TEST_PROBE_LIMIT="$PROBE_LIMIT"
XFREE_ZAPRET_TEST_CONNECT_TIMEOUT="$CONNECT_TIMEOUT"
XFREE_ZAPRET_TEST_MAX_TIME="$MAX_TIME"
export XFREE_ZAPRET_TEST_PROBE_LIMIT XFREE_ZAPRET_TEST_CONNECT_TIMEOUT XFREE_ZAPRET_TEST_MAX_TIME

TEST_MODE_CURRENT=0
TEST_MODE_STRATEGY=0
TEST_MODE_FAKE_SWEEP=0
TEST_MODE_TCP1620=0
TEST_YES=0
TEST_PRINT_HOSTS=0
TEST_YOUTUBE_ONLY=0
TEST_DISCORD_ONLY=0
TEST_OTHERS_ONLY=0
TEST_SOURCE="auto"

TEST_SNAP=""
TEST_RESTORED=0

test_die_host() {
	ui_msgbox "Zapret: тест секций" "На host (profile-generator) runtime-тест недоступен.

Запускайте на роутере: xft → Zapret → Тест секций."
	exit 0
}

# Respect --yes (non-interactive SSH / menu).
test_confirm() {
	title="$1"
	body="$2"
	if [ "${TEST_YES:-0}" -eq 1 ]; then
		return 0
	fi
	ui_confirm "$title" "$body"
}

test_conf_path_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/config/section.conf\n' "$(zapret_sections_root)" "$slug"
}

test_conf_path_state() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/config/section.conf\n' "$(zapret_state_sections_root)" "$slug"
}

test_fqdn_dir_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/fqdn.d\n' "$(zapret_sections_root)" "$slug"
}

test_fqdn_dir_state() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/fqdn.d\n' "$(zapret_state_sections_root)" "$slug"
}

test_enabled_status_from_conf() {
	conf_path="$1"
	if [ -f "$conf_path" ] && ! _zapret_section_enabled_quick "$conf_path"; then
		printf 'OFF\n'
	else
		printf 'ON\n'
	fi
}

test_set_enabled_profile() {
	section="$1"
	enabled="$2"
	conf_path="$(test_conf_path_profile "$section")"
	[ -f "$conf_path" ] || {
		warn "нет section.conf: $section"
		return 1
	}
	tmp="${conf_path}.tmp.$$"
	awk -v val="$enabled" '
		BEGIN { set=0 }
		/^ZAPRET_SECTION_ENABLED=/ { print "ZAPRET_SECTION_ENABLED='\''" val "'\''"; set=1; next }
		{ print }
		END { if (set==0) print "ZAPRET_SECTION_ENABLED='\''" val "'\''" }
	' "$conf_path" > "$tmp"
	mv "$tmp" "$conf_path"
}

test_host_file_for_section_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	zapret_section_host_file_quick "$(test_conf_path_profile "$section")" "$slug"
}

test_host_file_for_section_state() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	zapret_section_host_file_quick "$(test_conf_path_state "$section")" "$slug"
}

# Capture last summary line; mirror probe progress to tty when available.
test_probe_capture_summary() {
	if [ -c /dev/tty ] && (: >/dev/tty) 2>/dev/null; then
		"$@" 2>&1 | tee /dev/tty | tail -n1
	else
		"$@" | tail -n1
	fi
}

test_snapshot_all_profile() {
	out="$1"
	: > "$out"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		st="$(test_enabled_status_from_conf "$(test_conf_path_profile "$section")")"
		if [ "$st" = "ON" ]; then
			printf '%s\t1\n' "$section" >> "$out"
		else
			printf '%s\t0\n' "$section" >> "$out"
		fi
	done <<EOF
$(zapret_iter_sections)
EOF
}

test_restore_snapshot_profile() {
	snap="$1"
	[ -f "$snap" ] || return 0
	while IFS="$(printf '\t')" read -r section val; do
		[ -n "${section:-}" ] || continue
		test_set_enabled_profile "$section" "${val:-0}" || true
	done < "$snap"
}

test_apply_runtime() {
	info "zapret: apply профиля → runtime…"
	ZAPRET_RESTART_QUIET=1
	export ZAPRET_RESTART_QUIET
	zapret_apply_profile_to_runtime
}

# Статика до apply: в section.text кандидата нет отсутствующих fake *.bin (если путь под /opt).
# stdout: OK | FAIL_STATIC missing_fake=…
test_section_static_preflight() {
	candidate="$1"
	slug="$(common_normalize_token "$candidate")"
	text_file="$(zapret_sections_root)/$slug/config/section.text"
	[ -f "$text_file" ] || {
		printf 'FAIL_STATIC no_section_text\n'
		return 1
	}
	text="$(cat "$text_file" 2>/dev/null || true)"
	miss="$(zapret_missing_fake_files_from_text "$text" 2>/dev/null || true)"
	if [ -n "$miss" ]; then
		miss_csv="$(printf '%s' "$miss" | tr '\n' ',' | sed 's/,$//')"
		printf 'FAIL_STATIC missing_fake=%s\n' "$miss_csv"
		return 1
	fi
	printf 'OK\n'
	return 0
}

# После apply+restart: ждёт daemons.
# stdout: одна строка summary (OK / FAIL_DAEMON …); подробности — в stderr.
# 0 = healthy, 1 = unhealthy.
test_daemon_health_gate() {
	health="$(zapret_wait_daemons_healthy 2>/dev/null || true)"
	[ -n "$health" ] || health="FAIL_DAEMON reason=no_summary"
	# одна строка (wait уже печатает summary)
	health="$(printf '%s\n' "$health" | head -n1)"
	printf '%s\n' "$health"
	case "$health" in
		OK*) return 0 ;;
	esac
	printf '  daemon diagnose: %s\n' "$health" >&2
	zapret_daemon_diagnose_report 2>/dev/null | sed 's/^/  /' >&2 || true
	return 1
}

test_cleanup_trap() {
	[ "${TEST_RESTORED:-0}" = "1" ] && return 0
	[ -n "${TEST_SNAP:-}" ] && [ -f "${TEST_SNAP:-}" ] || return 0
	warn "тест прерван — восстанавливаем ENABLED и apply…"
	test_restore_snapshot_profile "$TEST_SNAP" || true
	test_apply_runtime || true
	TEST_RESTORED=1
	rm -f "$TEST_SNAP" 2>/dev/null || true
}

# Ranked curlable FQDNs from fqdn.d; fallback DEFAULT_DOMAINS.
test_collect_probe_domains() {
	fqdn_dir="$1"
	out="$2"
	hint="${3:-}"
	zapret_probe_collect_fqdn_dir "$fqdn_dir" "$PROBE_LIMIT" "$hint" >"$out"
	if [ ! -s "$out" ]; then
		# shellcheck disable=SC2086
		for d in $DEFAULT_DOMAINS; do
			printf '%s\n' "$d" >>"$out"
		done
	fi
}

# YouTube/google HOST_FILE → media suite (home/watch/thumbs/CDN), else fqdn.d hosts.
# source: profile|state (where to read HOST_FILE + fqdn.d for non-YouTube).
test_probe_section() {
	section="$1"
	domains_file="$2"
	source="${3:-profile}"
	if [ "$source" = "state" ]; then
		host_file="$(test_host_file_for_section_state "$section" 2>/dev/null || true)"
		fqdn_dir="$(test_fqdn_dir_state "$section")"
	else
		host_file="$(test_host_file_for_section_profile "$section" 2>/dev/null || true)"
		fqdn_dir="$(test_fqdn_dir_profile "$section")"
	fi
	if zapret_probe_youtube_target_p "$section" "$host_file"; then
		printf '  (YouTube media suite: home/watch/thumbs + googlevideo CDN)\n'
		zapret_probe_youtube_run_suite
		return 0
	fi
	test_collect_probe_domains "$fqdn_dir" "$domains_file" "$section"
	test_curl_domains_file "$domains_file"
}

# Scope filter: youtube-only | others-only | all (default).
# Return 0 if section should be probed.
test_section_in_scope() {
	section="$1"
	host_file="$2"
	is_yt=0
	if zapret_probe_youtube_target_p "$section" "$host_file"; then
		is_yt=1
	fi
	if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ]; then
		[ "$is_yt" -eq 1 ]
		return $?
	fi
	if [ "${TEST_DISCORD_ONLY:-0}" -eq 1 ]; then
		case "$section" in
			discord|discord_*) return 0 ;;
			*) return 1 ;;
		esac
	fi
	if [ "${TEST_OTHERS_ONLY:-0}" -eq 1 ]; then
		[ "$is_yt" -eq 0 ] || return 1
		case "$section" in
			discord|discord_*) return 1 ;;
			*) return 0 ;;
		esac
	fi
	return 0
}

test_filter_sections_file_scope() {
	# $1=infile $2=outfile  (profile host_file lookup)
	infile="$1"
	outfile="$2"
	: >"$outfile"
	while IFS= read -r s; do
		[ -n "$s" ] || continue
		hf="$(test_host_file_for_section_profile "$s" 2>/dev/null || true)"
		if test_section_in_scope "$s" "$hf"; then
			printf '%s\n' "$s" >>"$outfile"
		fi
	done <"$infile"
}

# PASS if any OK; YouTube: use suite verdict (page+thumb+cdn buckets) when present.
test_probe_verdict() {
	section="$1"
	host_file="$2"
	ok="$3"
	tot="$4"
	yt_verdict="${5:-}"
	if zapret_probe_youtube_target_p "$section" "$host_file"; then
		case "$yt_verdict" in
			PASS|FAIL) printf '%s\n' "$yt_verdict"; return 0 ;;
		esac
		# Fallback if old summary without verdict field.
		need=$(( (tot + 1) / 2 ))
		if [ "$tot" -gt 0 ] 2>/dev/null && [ "$ok" -ge "$need" ] 2>/dev/null; then
			printf 'PASS\n'
		else
			printf 'FAIL\n'
		fi
		return 0
	fi
	if [ "$ok" -gt 0 ] 2>/dev/null; then
		printf 'PASS\n'
	else
		printf 'FAIL\n'
	fi
}

test_curl_domains_file() {
	domains_file="$1"
	ok=0
	total=0
	alive_yes=0
	alive_no=0
	parall="$(zapret_probe_parallel_limit)"
	resdir="$(mktemp -d)"
	PROBE_BG_PIDS=""
	job=0
	while IFS= read -r domain; do
		[ -n "$domain" ] || continue
		job=$((job + 1))
		total=$((total + 1))
		zapret_probe_bg_throttle "$parall"
		zapret_probe_bg_launch "$resdir/$job.out" zapret_probe_one_host "$domain"
	done <"$domains_file"
	zapret_probe_bg_wait_all
	idx=1
	while [ "$idx" -le "$job" ]; do
		line="$(cat "$resdir/$idx.out" 2>/dev/null || true)"
		[ -n "$line" ] || line="FAIL (empty)"
		printf '  %s\n' "$line"
		case "$line" in
			OK*) ok=$((ok + 1)) ;;
		esac
		case "$line" in
			*alive=yes*) alive_yes=$((alive_yes + 1)) ;;
			*alive=no*) alive_no=$((alive_no + 1)) ;;
		esac
		idx=$((idx + 1))
	done
	rm -rf "$resdir"
	printf '  summary alive_yes=%s alive_no=%s parallel=%s\n' "$alive_yes" "$alive_no" "$parall"
	printf '%s %s\n' "$ok" "$total"
}

# Parallel host probes with optional cache file (host\tline). Sets TEST_HOST_OK / TEST_HOST_TOT.
# Prints one result line per host (cached marked). Uses global host_ok/host_fail when set.
test_probe_hosts_parallel_cached() {
	hosts_file="$1"
	cache_file="${2:-}"
	parall="$(zapret_probe_parallel_limit)"
	resdir="$(mktemp -d)"
	PROBE_BG_PIDS=""
	job=0
	order="$(mktemp)"
	: >"$order"
	TEST_HOST_OK=0
	TEST_HOST_TOT=0
	while IFS= read -r h; do
		[ -n "$h" ] || continue
		TEST_HOST_TOT=$((TEST_HOST_TOT + 1))
		cached=""
		if [ -n "$cache_file" ] && [ -f "$cache_file" ]; then
			cached="$(awk -F'\t' -v host="$h" '$1==host { print $2; exit }' "$cache_file")"
		fi
		if [ -n "$cached" ]; then
			printf 'C\t%s\t%s\n' "$h" "$cached" >>"$order"
			continue
		fi
		job=$((job + 1))
		printf 'J\t%s\t%s\n' "$h" "$job" >>"$order"
		zapret_probe_bg_throttle "$parall"
		zapret_probe_bg_launch "$resdir/$job.out" zapret_probe_one_host "$h"
	done <"$hosts_file"
	zapret_probe_bg_wait_all
	while IFS="$(printf '\t')" read -r kind h rest; do
		[ -n "$kind" ] || continue
		if [ "$kind" = "C" ]; then
			line="$rest"
			printf '  %s  (cached)\n' "$line"
			case "$line" in
				OK*) TEST_HOST_OK=$((TEST_HOST_OK + 1)) ;;
			esac
			# Cached hits do not bump unique host_ok/host_fail counters.
			continue
		fi
		jid="$rest"
		line="$(cat "$resdir/$jid.out" 2>/dev/null || true)"
		[ -n "$line" ] || line="FAIL $h  empty"
		printf '  %s\n' "$line"
		if [ -n "$cache_file" ]; then
			printf '%s\t%s\n' "$h" "$line" >>"$cache_file"
		fi
		case "$line" in
			OK*)
				TEST_HOST_OK=$((TEST_HOST_OK + 1))
				host_ok=$((${host_ok:-0} + 1))
				;;
			*)
				host_fail=$((${host_fail:-0} + 1))
				;;
		esac
	done <"$order"
	rm -f "$order"
	rm -rf "$resdir"
}

test_pick_sections_from_list() {
	# stdin: section names; uses conf_path_fn name via env TEST_CONF_FN=profile|state
	# optional: TEST_ONLY_ENABLED=1
	list_file="$1"
	mode_label="$2"
	only_enabled="${3:-0}"

	tmp_on="$(mktemp)"
	tmp_off="$(mktemp)"
	: > "$tmp_on"
	: > "$tmp_off"

	while IFS= read -r section; do
		[ -n "$section" ] || continue
		if [ "$TEST_CONF_FN" = "state" ]; then
			conf="$(test_conf_path_state "$section")"
		else
			conf="$(test_conf_path_profile "$section")"
		fi
		st="$(test_enabled_status_from_conf "$conf")"
		if [ "$only_enabled" = "1" ] && [ "$st" != "ON" ]; then
			continue
		fi
		if [ "$st" = "ON" ]; then
			printf '%s\n' "$section" >> "$tmp_on"
		else
			printf '%s\n' "$section" >> "$tmp_off"
		fi
	done < "$list_file"

	if [ ! -s "$tmp_on" ] && [ ! -s "$tmp_off" ]; then
		rm -f "$tmp_on" "$tmp_off"
		ui_msgbox "Zapret: тест" "Нет секций для выбора ($mode_label)."
		return 1
	fi

	choice="$(ui_menu "Zapret: тест — выбор" "$mode_label" 20 90 12 \
		"A" "Все из списка" \
		"S" "Выбрать несколько (checklist)" \
		"1" "Одна секция" \
		"0" "Назад" || true)"
	[ -n "${choice:-}" ] || {
		rm -f "$tmp_on" "$tmp_off"
		return 1
	}

	out_sel="$(mktemp)"
	case "$choice" in
		A)
			cat "$tmp_on" "$tmp_off" > "$out_sel"
			;;
		1)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			one="$(ui_menu "Zapret: одна секция" "Выберите секцию" 22 90 14 "$@" || true)"
			[ -n "${one:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$out_sel"
				return 1
			}
			eval "printf '%s\n' \"\${TSEC_$one}\"" > "$out_sel"
			;;
		S)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			tags="$(ui_checklist "Zapret: секции" "Отметьте секции для теста" 22 90 14 "$@" || true)"
			[ -n "${tags:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$out_sel"
				return 1
			}
			: > "$out_sel"
			for tag in $tags; do
				eval "printf '%s\n' \"\${TSEC_$tag}\"" >> "$out_sel"
			done
			;;
		*)
			rm -f "$tmp_on" "$tmp_off" "$out_sel"
			return 1
			;;
	esac

	rm -f "$tmp_on" "$tmp_off"
	[ -s "$out_sel" ] || {
		rm -f "$out_sel"
		return 1
	}
	printf '%s\n' "$out_sel"
}

test_apply_mutex_for_candidate() {
	candidate="$1"
	host_file="$(test_host_file_for_section_profile "$candidate")"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		hf="$(test_host_file_for_section_profile "$section")"
		if [ "$hf" = "$host_file" ]; then
			if [ "$section" = "$candidate" ]; then
				test_set_enabled_profile "$section" 1
			else
				test_set_enabled_profile "$section" 0
			fi
		fi
	done <<EOF
$(zapret_iter_sections)
EOF
}

run_mode_strategy_switch() {
	list_all="$(mktemp)"
	zapret_iter_sections > "$list_all"
	[ -s "$list_all" ] || {
		rm -f "$list_all"
		if [ "${TEST_YES:-0}" -eq 1 ]; then
			printf '%s\n' "В профиле нет секций zapret."
		else
			ui_msgbox "Zapret: тест" "В профиле нет секций zapret."
		fi
		return 0
	}

	if [ "${TEST_YES:-0}" -eq 1 ]; then
		sel_file="$list_all"
		list_all=""
	else
		TEST_CONF_FN=profile
		sel_file="$(test_pick_sections_from_list "$list_all" "Профиль: быстрый перебор стратегий" 0)" || {
			rm -f "$list_all"
			return 0
		}
		rm -f "$list_all"
	fi

	# Optional scope: youtube-only / discord-only / others-only.
	if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ] || [ "${TEST_DISCORD_ONLY:-0}" -eq 1 ] || [ "${TEST_OTHERS_ONLY:-0}" -eq 1 ]; then
		scoped="$(mktemp)"
		test_filter_sections_file_scope "$sel_file" "$scoped"
		rm -f "$sel_file"
		sel_file="$scoped"
		if [ ! -s "$sel_file" ]; then
			rm -f "$sel_file"
			if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ]; then
				printf '%s\n' "Нет youtube/google секций для перебора."
			elif [ "${TEST_DISCORD_ONLY:-0}" -eq 1 ]; then
				printf '%s\n' "Нет секций discord для перебора."
			else
				printf '%s\n' "Нет не-YouTube секций для перебора."
			fi
			return 0
		fi
	fi

	n="$(grep -c . "$sel_file" || true)"
	wan_if="$(zapret_fast_probe_wan_if)"
	if ! test_confirm "Zapret: быстрый перебор" \
"Кандидатов: $n
Интерфейс WAN: $wan_if

Быстрый подбор без перезапуска демона Zapret и без сброса firewall (~30 сек).
Тестирование выполняется напрямую на канале WAN в обход VPN-политик.

Продолжить?"; then
		rm -f "$sel_file"
		return 0
	fi

	results="$(mktemp)"
	: > "$results"

	scope="others"
	if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ]; then
		scope="youtube"
	elif [ "${TEST_DISCORD_ONLY:-0}" -eq 1 ]; then
		scope="discord"
	else
		while IFS= read -r s; do
			[ -n "$s" ] || continue
			hf="$(test_host_file_for_section_profile "$s" 2>/dev/null || true)"
			if zapret_probe_youtube_target_p "$s" "$hf"; then
				scope="youtube"
				break
			fi
		done <"$sel_file"
	fi

	trap 'zapret_fast_probe_cleanup_nft' EXIT INT TERM
	if [ -c /dev/tty ] && (: >/dev/tty) 2>/dev/null; then
		printf '\n=== Zapret: быстрый перебор стратегий (WAN: %s) ===\n\n' "$wan_if" >/dev/tty 2>/dev/null || true
	fi
	zapret_fast_probe_run_sections "$sel_file" "$wan_if" "$scope" "$results"
	if [ "$scope" != "discord" ] && ! awk -F'\t' '$2=="PASS" { found=1; exit } END { exit !found }' "$results"; then
		_sweep_base=""
		for _pref in youtube_5 youtube_1 youtube_3 others_1; do
			if grep -Fx "$_pref" "$sel_file" >/dev/null 2>&1; then
				_sweep_base="$_pref"
				break
			fi
		done
		[ -n "$_sweep_base" ] || _sweep_base="$(head -n1 "$sel_file" || true)"
		if [ -n "$_sweep_base" ]; then
			printf '\n[*] Ни одна базовая стратегия не подошла — запускаю перебор fake TLS файлов (база: %s)...\n' "$_sweep_base"
			zapret_fast_probe_run_fake_sweep "$_sweep_base" "$wan_if" "$is_yt" "$results" "$_sweep_base"
		fi
	fi
	if [ "$scope" != "discord" ]; then
		zapret_fast_probe_run_wan6 "$wan_if" "$scope" "$results" || true
	fi
	trap - EXIT INT TERM

	# Сортировка: сначала PASS (по возрастанию латентности), затем FAIL
	sorted_results="$(mktemp)"
	awk -F'\t' '
		$2 == "PASS" { print 1 "\t" $4 "\t" $0 }
		$2 != "PASS" { print 2 "\t" 999 "\t" $0 }
	' "$results" | sort -k1,1n -k2,2n | cut -f3- > "$sorted_results"

	report="$(mktemp)"
	{
		printf '=== Результаты быстрого подбора стратегий (WAN: %s) ===\n\n' "$wan_if"
		printf '%-22s %-8s %-10s %s\n' "SECTION" "RESULT" "HTTP_CODE" "LATENCY"
		printf '%s\n' "--------------------------------------------------------"
		while IFS="$(printf '\t')" read -r s st code lat; do
			lat_str=""
			[ -n "$lat" ] && [ "$lat" != "0.000" ] && lat_str="${lat}s"
			printf '%-22s %-8s %-10s %s\n' "$s" "$st" "$code" "$lat_str"
		done < "$sorted_results"
		if [ "$is_yt" -eq 1 ]; then
			printf '\nYouTube: PASS = успешный ответ сервера (HTTP 200/204/301/302) через WAN.\n'
			printf 'Примечание: воспроизведение видеопотока проверяется в браузере (LAN).\n'
		fi
	} > "$report"

	if [ "${TEST_YES:-0}" -eq 1 ]; then
		cat "$report"
		printf '\n'
	else
		ui_show_textbox "Zapret: результаты подбора" "$report" 28 100
	fi

	# Определение лучшей стратегии (для Discord — среди основных TCP-стратегий, не voice/media подкомпонентов)
	if [ "$scope" = "discord" ]; then
		best="$(awk -F'\t' '$2=="PASS" && $1 !~ /^discord_(media|voice)_/' "$sorted_results" | head -n1 | cut -f1)"
		best_code="$(awk -F'\t' '$2=="PASS" && $1 !~ /^discord_(media|voice)_/' "$sorted_results" | head -n1 | cut -f3)"
		best_lat="$(awk -F'\t' '$2=="PASS" && $1 !~ /^discord_(media|voice)_/' "$sorted_results" | head -n1 | cut -f4)"
	else
		best="$(awk -F'\t' '$2=="PASS" && $1 !~ /^wan6_/' "$sorted_results" | head -n1 | cut -f1)"
		best_code="$(awk -F'\t' '$2=="PASS" && $1 !~ /^wan6_/' "$sorted_results" | head -n1 | cut -f3)"
		best_lat="$(awk -F'\t' '$2=="PASS" && $1 !~ /^wan6_/' "$sorted_results" | head -n1 | cut -f4)"
		if [ -z "${best:-}" ]; then
			best="$(awk -F'\t' '$2=="PASS"' "$sorted_results" | head -n1 | cut -f1)"
			best_code="$(awk -F'\t' '$2=="PASS"' "$sorted_results" | head -n1 | cut -f3)"
			best_lat="$(awk -F'\t' '$2=="PASS"' "$sorted_results" | head -n1 | cut -f4)"
		fi
	fi

	if [ -n "${best:-}" ] && [ "${TEST_YES:-0}" -eq 0 ]; then
		prompt_msg="Найдена лучшая стратегия: $best (HTTP $best_code"
		[ -n "$best_lat" ] && [ "$best_lat" != "0.000" ] && prompt_msg="$prompt_msg, ${best_lat}s"
		prompt_msg="$prompt_msg)

Активировать секцию «$best» для YouTube и применить правила?"

		if ui_confirm "Zapret: активация лучшей стратегии" "$prompt_msg"; then
			test_apply_mutex_for_candidate "$best"
			test_apply_runtime || true
			ui_msgbox "Zapret: стратегия активирована" "Секция «$best» успешно включена и применена в Zapret."
		fi
	elif [ -n "${best:-}" ] && [ "${TEST_YES:-0}" -eq 1 ]; then
		printf 'best_pass=%s\n' "$best"
		if [ "${ACTIVATE_BEST:-0}" -eq 1 ]; then
			if [ "${TEST_DISCORD_ONLY:-0}" -eq 1 ]; then
				_d_conf="$(zapret_sections_root)/discord/config/section.text"
				if [ "$best" = "discord_canonical" ]; then
					cat > "$_d_conf" <<'EOF'
--filter-tcp=80,443
{{SELECT_LIST}}
{{SELECT_EXCLUDE_LIST}}
--dpi-desync=fake
--dpi-desync-repeats=3
--dpi-desync-fooling=ts
--dpi-desync-any-protocol=1
--dpi-desync-cutoff=0
--dpi-desync-fake-tls=/opt/zapret/files/fake/stun2.bin
--dpi-desync-fake-http=/opt/zapret/files/fake/tls_clienthello_max_ru.bin
--new
--filter-udp=443
--filter-l7=discord
--dpi-desync=fake
--dpi-desync-repeats=3
--new
--filter-udp=19294-19344,50000-50100
--filter-l7=discord,stun
--dpi-desync=fake
--dpi-desync-repeats=6
--dpi-desync-fake-stun=/opt/zapret/files/fake/quic_initial_www_google_com.bin
--dpi-desync-fake-discord=/opt/zapret/files/fake/quic_initial_www_google_com.bin
--new
--filter-tcp=2053,2083,2087,2096,8443
--hostlist-domains=discord.media
--dpi-desync=fake,fakedsplit
--dpi-desync-repeats=6
--dpi-desync-fooling=ts
--dpi-desync-fakedsplit-pattern=0x00
--dpi-desync-fake-tls=/opt/zapret/files/fake/stun2.bin
--dpi-desync-fake-http=/opt/zapret/files/fake/tls_clienthello_max_ru.bin
EOF
				else
					_d_args="$(zapret_fast_probe_discord_strategies | awk -F'\t' -v b="$best" '$1==b {print $2}')"
					if [ -n "$_d_args" ]; then
						_d_args_clean="$(printf '%s' "$_d_args" | sed 's/--filter-tcp=[0-9,]*//g' | tr -s ' ')"
						cat > "$_d_conf" <<EOF
--filter-tcp=80,443
{{SELECT_LIST}}
{{SELECT_EXCLUDE_LIST}}
$_d_args_clean
--new
--filter-udp=19294-19344,50000-50100
--filter-l7=discord,stun
--dpi-desync=fake
--dpi-desync-repeats=6
--dpi-desync-fake-stun=/opt/zapret/files/fake/quic_initial_www_google_com.bin
--dpi-desync-fake-discord=/opt/zapret/files/fake/quic_initial_www_google_com.bin
EOF
					fi
				fi
				test_set_enabled_profile "discord" 1
			else
				case "$best" in
					wan6_direct)
						sh "$ROOT_DIR/system/disable-wan-ipv6.sh" --enable --mode selective --apply || true
						sh "$ROOT_DIR/iface-routing/apply-routing.sh" || true
						;;
					wan6_zapret_multisplit)
						sh "$ROOT_DIR/system/disable-wan-ipv6.sh" --enable --mode full --zapret-ipv6 1 --apply || true
						sh "$ROOT_DIR/iface-routing/apply-routing.sh" || true
						;;
					*@*)
						_b_sec="${best%@*}"
						_b_fake="/opt/zapret/files/fake/${best#*@}"
						zapret_fast_probe_apply_fake_to_section_file "$(zapret_sections_root)/$_b_sec/config/section.text" "$_b_fake" || true
						test_apply_mutex_for_candidate "$_b_sec"
						;;
					*)
						test_apply_mutex_for_candidate "$best"
						;;
				esac
			fi
			test_apply_runtime || true
			printf 'activated_section=%s\n' "$best"
		fi
	else
		if [ "${TEST_YES:-0}" -eq 0 ]; then
			ui_msgbox "Zapret: результат" "Ни одна из протестированных стратегий не ответила успешно на интерфейсе $wan_if."
		fi
	fi

	rm -f "$sel_file" "$results" "$sorted_results" "$report"
}

run_mode_fake_sweep() {
	wan_if="$(zapret_fast_probe_wan_if)"
	list_all="$(mktemp)"
	zapret_iter_sections > "$list_all"
	[ -s "$list_all" ] || {
		rm -f "$list_all"
		printf '%s\n' "В профиле нет секций zapret."
		return 0
	}

	candidate=""
	if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ]; then
		candidate="youtube_1"
	fi

	if [ -z "$candidate" ]; then
		TEST_CONF_FN=profile
		sel_file="$(test_pick_sections_from_list "$list_all" "Выберите секцию для перебора fake файлов" 0)" || {
			rm -f "$list_all"
			return 0
		}
		candidate="$(head -n1 "$sel_file")"
		rm -f "$sel_file"
	fi
	rm -f "$list_all"

	[ -n "$candidate" ] || return 0

	if ! test_confirm "Zapret: перебор fake TLS" \
"Секция: $candidate
Интерфейс WAN: $wan_if

Быстрый перебор всех доступных файлов tls_clienthello_*.bin
на канале WAN без перезапуска Zapret.

Продолжить?"; then
		return 0
	fi

	results="$(mktemp)"
	: > "$results"

	is_yt=0
	hf="$(test_host_file_for_section_profile "$candidate" 2>/dev/null || true)"
	if zapret_probe_youtube_target_p "$candidate" "$hf"; then
		is_yt=1
	fi

	trap 'zapret_fast_probe_cleanup_nft' EXIT INT TERM
	if [ -c /dev/tty ] && (: >/dev/tty) 2>/dev/null; then
		printf '\n=== Zapret: перебор fake TLS файлов (секция: %s, WAN: %s) ===\n\n' "$candidate" "$wan_if" >/dev/tty 2>/dev/null || true
	fi
	zapret_fast_probe_run_fake_sweep "$candidate" "$wan_if" "$is_yt" "$results"
	trap - EXIT INT TERM

	# Сортировка: сначала PASS (по возрастанию латентности), затем FAIL
	sorted_results="$(mktemp)"
	awk -F'\t' '
		$2 == "PASS" { print 1 "\t" $4 "\t" $0 }
		$2 != "PASS" { print 2 "\t" 999 "\t" $0 }
	' "$results" | sort -k1,1n -k2,2n | cut -f3- > "$sorted_results"

	report="$(mktemp)"
	{
		printf '=== Результаты перебора fake TLS файлов (секция: %s, WAN: %s) ===\n\n' "$candidate" "$wan_if"
		printf '%-34s %-8s %-10s %s\n' "FAKE_FILE" "RESULT" "HTTP_CODE" "LATENCY"
		printf '%s\n' "------------------------------------------------------------------"
		while IFS="$(printf '\t')" read -r f st code lat; do
			lat_str=""
			[ -n "$lat" ] && [ "$lat" != "0.000" ] && lat_str="${lat}s"
			printf '%-34s %-8s %-10s %s\n' "$f" "$st" "$code" "$lat_str"
		done < "$sorted_results"
	} > "$report"

	if [ "${TEST_YES:-0}" -eq 1 ]; then
		cat "$report"
		printf '\n'
	else
		ui_show_textbox "Zapret: результаты перебора fake TLS" "$report" 28 100
	fi

	best="$(awk -F'\t' '$2=="PASS"' "$sorted_results" | head -n1 | cut -f1)"
	best_code="$(awk -F'\t' '$2=="PASS"' "$sorted_results" | head -n1 | cut -f3)"
	best_lat="$(awk -F'\t' '$2=="PASS"' "$sorted_results" | head -n1 | cut -f4)"

	if [ -n "${best:-}" ] && [ "${TEST_YES:-0}" -eq 0 ]; then
		prompt_msg="Найден лучший fake файл: $best (HTTP $best_code"
		[ -n "$best_lat" ] && [ "$best_lat" != "0.000" ] && prompt_msg="$prompt_msg, ${best_lat}s"
		prompt_msg="$prompt_msg)

Заменить fake TLS файл в секции «$candidate» на «$best» и применить к Zapret?"

		if ui_confirm "Zapret: применить fake файл?" "$prompt_msg"; then
			conf_text="$(zapret_sections_root)/$candidate/config/section.text"
			fake_path="/opt/zapret/files/fake/$best"
			if [ -f "$conf_text" ]; then
				sed -i "s#--dpi-desync-fake-tls=[^ ]*#--dpi-desync-fake-tls=$fake_path#g" "$conf_text"
				if grep -q -- '--dpi-desync-split-seqovl-pattern=' "$conf_text"; then
					sed -i "s#--dpi-desync-split-seqovl-pattern=[^ ]*#--dpi-desync-split-seqovl-pattern=$fake_path#g" "$conf_text"
				fi
				test_apply_runtime || true
				ui_msgbox "Zapret: fake применён" "Секция «$candidate» обновлена с файлом «$best» и правила применены."
			fi
		fi
	elif [ -n "${best:-}" ] && [ "${TEST_YES:-0}" -eq 1 ]; then
		printf 'best_fake=%s\n' "$best"
	else
		if [ "${TEST_YES:-0}" -eq 0 ]; then
			ui_msgbox "Zapret: результат" "Ни один fake файл для секции $candidate не дал успешного ответа."
		fi
	fi

	rm -f "$results" "$sorted_results" "$report"
}

run_mode_applied_state() {
	state_root="$(zapret_state_sections_root)"
	if [ ! -d "$state_root" ]; then
		ui_msgbox "Zapret: тест" "Нет применённого state:
$state_root

Сначала примените профиль (Zapret → Применить)."
		return 0
	fi

	list_all="$(mktemp)"
	zapret_iter_state_sections > "$list_all"
	if [ ! -s "$list_all" ]; then
		rm -f "$list_all"
		ui_msgbox "Zapret: тест" "В state нет секций:
$state_root"
		return 0
	fi

	tmp_on="$(mktemp)"
	tmp_off="$(mktemp)"
	: > "$tmp_on"
	: > "$tmp_off"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		st="$(test_enabled_status_from_conf "$(test_conf_path_state "$section")")"
		if [ "$st" = "ON" ]; then
			printf '%s\n' "$section" >> "$tmp_on"
		else
			printf '%s\n' "$section" >> "$tmp_off"
		fi
	done < "$list_all"
	rm -f "$list_all"

	if [ ! -s "$tmp_on" ] && [ ! -s "$tmp_off" ]; then
		rm -f "$tmp_on" "$tmp_off"
		ui_msgbox "Zapret: тест" "В state нет секций:
$state_root"
		return 0
	fi

	set -- \
		"E" "Все ENABLED в state" \
		"A" "Все секции в state" \
		"S" "Несколько (checklist)"
	idx=1
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		set -- "$@" "$idx" "[ON] $section"
		eval "TSEC_$idx='$section'"
		idx=$((idx + 1))
	done < "$tmp_on"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		set -- "$@" "$idx" "[OFF] $section"
		eval "TSEC_$idx='$section'"
		idx=$((idx + 1))
	done < "$tmp_off"
	set -- "$@" "0" "Назад"

	choice="$(ui_menu "Zapret: применённые" "Какую секцию проверить?
ENABLED сверху, дальше остальные из state." 22 90 14 "$@" || true)"
	[ -n "${choice:-}" ] || {
		rm -f "$tmp_on" "$tmp_off"
		return 0
	}

	sel_file="$(mktemp)"
	case "$choice" in
		E)
			cat "$tmp_on" > "$sel_file"
			;;
		A)
			cat "$tmp_on" "$tmp_off" > "$sel_file"
			;;
		S)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			tags="$(ui_checklist "Zapret: секции state" "Отметьте секции для проверки" 22 90 14 "$@" || true)"
			[ -n "${tags:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$sel_file"
				return 0
			}
			: > "$sel_file"
			for tag in $tags; do
				eval "printf '%s\n' \"\${TSEC_$tag}\"" >> "$sel_file"
			done
			;;
		0)
			rm -f "$tmp_on" "$tmp_off" "$sel_file"
			return 0
			;;
		*)
			eval "printf '%s\n' \"\${TSEC_$choice}\"" > "$sel_file"
			;;
	esac
	rm -f "$tmp_on" "$tmp_off"
	[ -s "$sel_file" ] || {
		rm -f "$sel_file"
		ui_msgbox "Zapret: тест" "Нет секций для проверки."
		return 0
	}

	n="$(grep -c . "$sel_file" || true)"
	if [ "$n" = "1" ]; then
		_one="$(head -n1 "$sel_file")"
		_confirm_body="Секция: $_one

Runtime не меняется (без apply/restart).
Curl: fqdn.d из state; YouTube — media-suite (home/watch/превью/CDN).

Продолжить?"
	else
		_confirm_body="Секций: $n

Runtime не меняется (без apply/restart).
Curl: fqdn.d из state; YouTube — media-suite (home/watch/превью/CDN).

Продолжить?"
	fi
	if ! test_confirm "Zapret: проверка state" "$_confirm_body"; then
		rm -f "$sel_file"
		return 0
	fi

	results="$(mktemp)"
	domains_tmp="$(mktemp)"
	: > "$results"

	printf '\n=== Zapret: проверка применённых (state) ===\n\n' >/dev/tty 2>/dev/null || true
	idx=0
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		idx=$((idx + 1))
		printf '\n[%s/%s] %s\n' "$idx" "$n" "$section"
		summary="$(test_probe_capture_summary test_probe_section "$section" "$domains_tmp" state)"
		ok="$(printf '%s' "$summary" | awk '{print $1}')"
		tot="$(printf '%s' "$summary" | awk '{print $2}')"
		ytv="$(printf '%s' "$summary" | awk '{print $3}')"
		ok="${ok:-0}"
		tot="${tot:-0}"
		host_file="$(test_host_file_for_section_state "$section" 2>/dev/null || true)"
		verdict="$(test_probe_verdict "$section" "$host_file" "$ok" "$tot" "$ytv")"
		printf '%s\t%s\t%s\t%s\n' "$section" "$ok" "$tot" "$verdict" >> "$results"
		printf '→ %s OK=%s/%s\n' "$verdict" "$ok" "$tot"
	done < "$sel_file"

	report="$(mktemp)"
	{
		printf 'Проверка применённых (state)\n\n'
		printf '%-24s %6s %6s %s\n' "SECTION" "OK" "TOTAL" "RESULT"
		printf '%s\n' "------------------------------------------------"
		sort -t"$(printf '\t')" -k2,2nr -k1,1 "$results" | while IFS="$(printf '\t')" read -r s ok tot v; do
			printf '%-24s %6s %6s %s\n' "$s" "$ok" "$tot" "$v"
		done
	} > "$report"
	ui_show_textbox "Zapret: результаты state" "$report" 28 100

	rm -f "$sel_file" "$results" "$domains_tmp" "$report"
}

test_current_conf_path() {
	section="$1"
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		test_conf_path_state "$section"
	else
		test_conf_path_profile "$section"
	fi
}

test_current_fqdn_dir() {
	section="$1"
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		test_fqdn_dir_state "$section"
	else
		test_fqdn_dir_profile "$section"
	fi
}

test_iter_current_sections() {
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		zapret_iter_state_sections
	else
		zapret_iter_sections
	fi
}

run_mode_current_config() {
	TEST_CURRENT_SRC="$TEST_SOURCE"
	if [ "$TEST_CURRENT_SRC" = "auto" ]; then
		if [ -d "$(zapret_state_sections_root)" ]; then
			TEST_CURRENT_SRC="state"
		else
			TEST_CURRENT_SRC="profile"
		fi
	fi

	if [ "$TEST_CURRENT_SRC" = "state" ] && [ ! -d "$(zapret_state_sections_root)" ]; then
		printf '%s\n' "Нет применённого state: $(zapret_state_sections_root)"
		printf '%s\n' "Сначала: xft → Zapret → Применить списки."
		return 1
	fi

	list_all="$(mktemp)"
	test_iter_current_sections >"$list_all"
	if [ ! -s "$list_all" ]; then
		rm -f "$list_all"
		printf '%s\n' "Нет секций ($TEST_CURRENT_SRC)."
		return 1
	fi

	if [ "$TEST_PRINT_HOSTS" -ne 1 ]; then
		_limit_label="$PROBE_LIMIT"
		case "$PROBE_LIMIT" in
			''|0|all|ALL) _limit_label='all' ;;
		esac
		printf '=== Zapret: текущая конфигурация (%s) ===\n' "$TEST_CURRENT_SRC"
		printf 'probe https://FQDN  family=%s  timeout=%ss/%ss  limit=%s/section\n' \
			"${XFREE_ZAPRET_TEST_IP_FAMILY:-4}" \
			"$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT" \
			"$XFREE_ZAPRET_TEST_MAX_TIME" \
			"$_limit_label"
	health="$(zapret_daemon_health_summary 2>/dev/null || true)"
	if [ -n "$health" ]; then
		printf 'daemons: %s\n' "$health"
		case "$health" in
			OK*) ;;
			*)
				printf 'предупреждение: daemons не healthy — curl-пробы мало информативны; смотрите стратегию/logread.\n'
				snippet="$(zapret_daemon_log_snippet 2>/dev/null || true)"
				[ -n "$snippet" ] && printf '%s\n' "$snippet" | sed 's/^/  /' | head -n 16
				;;
		esac
	elif pidof nfqws >/dev/null 2>&1 || pidof nfqws2 >/dev/null 2>&1; then
		printf 'nfqws: running\n'
	else
		printf 'nfqws: not found (пробы всё равно идут)\n'
	fi
		printf '\n'
	fi

	host_cache="$(mktemp)"
	sec_fp_cache="$(mktemp)"
	: >"$host_cache"
	: >"$sec_fp_cache"
	sec_pass=0
	sec_fail=0
	sec_skip=0
	host_ok=0
	host_fail=0
	any_fail=0

	while IFS= read -r section; do
		[ -n "$section" ] || continue
		conf="$(test_current_conf_path "$section")"
		st="$(test_enabled_status_from_conf "$conf")"
		[ "$st" = "ON" ] || continue

		if [ "$TEST_CURRENT_SRC" = "state" ]; then
			host_file="$(test_host_file_for_section_state "$section" 2>/dev/null || true)"
		else
			host_file="$(test_host_file_for_section_profile "$section" 2>/dev/null || true)"
		fi

		if ! test_section_in_scope "$section" "$host_file"; then
			continue
		fi

		# YouTube / google hostlist: media suite (home, watch, thumbs, CDN).
		if zapret_probe_youtube_target_p "$section" "$host_file"; then
			if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
				zapret_probe_youtube_collect_urls | while IFS='|' read -r _lab _url; do
					[ -n "${_url:-}" ] || continue
					printf '%s\t%s\n' "$section" "$_url"
				done
				continue
			fi
			printf '[%s] (YouTube media suite)\n' "$section"
			sec_fp='youtube-media-suite'
			prev_same="$(awk -F'\t' -v fp="$sec_fp" '$1==fp { print $2 "\t" $3 "\t" $4; exit }' "$sec_fp_cache")"
			if [ -n "$prev_same" ]; then
				prev_sec="$(printf '%s' "$prev_same" | cut -f1)"
				prev_ok="$(printf '%s' "$prev_same" | cut -f2)"
				prev_tot="$(printf '%s' "$prev_same" | cut -f3)"
				printf '  SKIP same YouTube suite as %s (%s/%s cached)\n\n' "$prev_sec" "$prev_ok" "$prev_tot"
				verdict="$(test_probe_verdict "$section" "$host_file" "$prev_ok" "$prev_tot")"
				if [ "$verdict" = "PASS" ]; then
					sec_pass=$((sec_pass + 1))
				else
					sec_fail=$((sec_fail + 1))
					any_fail=1
				fi
				continue
			fi
			yt_out="$(mktemp)"
			zapret_probe_youtube_run_suite | tee "$yt_out"
			summary="$(tail -n1 "$yt_out")"
			rm -f "$yt_out"
			sok="$(printf '%s' "$summary" | awk '{print $1}')"
			stot="$(printf '%s' "$summary" | awk '{print $2}')"
			ytv="$(printf '%s' "$summary" | awk '{print $3}')"
			sok="${sok:-0}"
			stot="${stot:-0}"
			printf '%s\t%s\t%s\t%s\n' "$sec_fp" "$section" "$sok" "$stot" >>"$sec_fp_cache"
			host_ok=$((host_ok + sok))
			host_fail=$((host_fail + stot - sok))
			verdict="$(test_probe_verdict "$section" "$host_file" "$sok" "$stot" "$ytv")"
			if [ "$verdict" = "PASS" ]; then
				printf '  → PASS %s/%s\n\n' "$sok" "$stot"
				sec_pass=$((sec_pass + 1))
			else
				printf '  → FAIL %s/%s\n\n' "$sok" "$stot"
				sec_fail=$((sec_fail + 1))
				any_fail=1
			fi
			continue
		fi

		hosts_tmp="$(mktemp)"
		zapret_probe_collect_fqdn_dir "$(test_current_fqdn_dir "$section")" "$PROBE_LIMIT" "$section" >"$hosts_tmp"
		if [ ! -s "$hosts_tmp" ]; then
			rm -f "$hosts_tmp"
			if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
				continue
			fi
			printf '[%s]\n' "$section"
			printf '  SKIP no curlable FQDN\n\n'
			sec_skip=$((sec_skip + 1))
			continue
		fi
		if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
			while IFS= read -r h; do
				[ -n "$h" ] || continue
				printf '%s\t%s\n' "$section" "$h"
			done <"$hosts_tmp"
			rm -f "$hosts_tmp"
			continue
		fi
		printf '[%s]\n' "$section"
		sec_fp="$(sort -u "$hosts_tmp" | cksum 2>/dev/null | awk '{print $1}')"
		[ -n "$sec_fp" ] || sec_fp="$(sort -u "$hosts_tmp" | wc -c | awk '{print $1}')"
		prev_same="$(awk -F'\t' -v fp="$sec_fp" '$1==fp { print $2 "\t" $3 "\t" $4; exit }' "$sec_fp_cache")"
		if [ -n "$prev_same" ]; then
			prev_sec="$(printf '%s' "$prev_same" | cut -f1)"
			prev_ok="$(printf '%s' "$prev_same" | cut -f2)"
			prev_tot="$(printf '%s' "$prev_same" | cut -f3)"
			printf '  SKIP same hosts as %s (%s/%s cached)\n\n' "$prev_sec" "$prev_ok" "$prev_tot"
			if [ "${prev_ok:-0}" -gt 0 ] 2>/dev/null; then
				sec_pass=$((sec_pass + 1))
			else
				sec_fail=$((sec_fail + 1))
				any_fail=1
			fi
			rm -f "$hosts_tmp"
			continue
		fi
		sok=0
		stot=0
		test_probe_hosts_parallel_cached "$hosts_tmp" "$host_cache"
		sok="${TEST_HOST_OK:-0}"
		stot="${TEST_HOST_TOT:-0}"
		rm -f "$hosts_tmp"
		printf '%s\t%s\t%s\t%s\n' "$sec_fp" "$section" "$sok" "$stot" >>"$sec_fp_cache"
		if [ "$sok" -gt 0 ]; then
			printf '  → PASS %s/%s\n\n' "$sok" "$stot"
			sec_pass=$((sec_pass + 1))
		else
			printf '  → FAIL %s/%s\n\n' "$sok" "$stot"
			sec_fail=$((sec_fail + 1))
			any_fail=1
		fi
	done <"$list_all"
	rm -f "$list_all" "$host_cache" "$sec_fp_cache"

	if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
		return 0
	fi

	printf '---\n'
	printf 'UNIQUE HOSTS  OK=%s FAIL=%s\n' "$host_ok" "$host_fail"
	printf 'SECTIONS      PASS=%s FAIL=%s SKIP=%s\n' "$sec_pass" "$sec_fail" "$sec_skip"
	if [ "$sec_pass" -eq 0 ] && [ "$sec_fail" -eq 0 ]; then
		printf 'Нет ENABLED-секций с curlable FQDN.\n'
		return 1
	fi
	[ "$any_fail" -eq 0 ]
}

run_mode_tcp1620() {
	suite="$SCRIPT_DIR/files/dpi-tcp-16-20-suite.tsv"
	if [ ! -f "$suite" ]; then
		printf '%s\n' "Нет suite: $suite" >&2
		return 1
	fi
	if ! test_confirm "Zapret: DPI TCP 16-20" \
"Лёгкая проверка на роутере (curl): alive HEAD + POST ~64 KiB.

Эталонный браузерный чекер (не ставим dpi-ch ~19MB):
https://hyperion-cs.github.io/dpi-checkers/ru/tcp-16-20
Репозиторий: https://github.com/hyperion-cs/dpi-checkers

Не меняет zapret/NFQWS.

Продолжить?"; then
		return 0
	fi
	printf 'Ref: https://hyperion-cs.github.io/dpi-checkers/ru/tcp-16-20\n\n'
	zapret_probe_tcp1620_run_suite "$suite"
}

usage() {
	cat <<EOF
Использование:
  $(basename "$0") --current [--yes] [--youtube-only|--others-only] [--print-hosts] [--source auto|state|profile]
  $(basename "$0") --strategy [--yes] [--youtube-only|--others-only]
  $(basename "$0") --tcp-16-20 [--yes]
  $(basename "$0")   # интерактивное меню

Режимы (взаимоисключающие):
  --current       текущие ENABLED-секции (state/profile), без apply
  --strategy      перебор стратегий профиля (mutex HOST_FILE + apply/restore;
                  до curl: daemons N/M + missing fake → FAIL_DAEMON/FAIL_STATIC)
  --tcp-16-20     лёгкий DPI TCP 16-20 (curl, parallel=${XFREE_ZAPRET_TCP1620_PARALLEL:-6}); эталон:
                  https://hyperion-cs.github.io/dpi-checkers/ru/tcp-16-20
  --youtube-only  только youtube_*/google HOST_FILE
  --others-only   все секции кроме YouTube/google
  --yes           без подтверждений (меню / SSH)
  --print-hosts   только список FQDN/URL (--current)
  --source        auto|state|profile (только --current)

YouTube PASS = ответы с роутера: page + thumb + CDN generate_204.
Videoplayback с роутера не проверяем; видео — с компьютера (LAN).
EOF
}

main() {
	while [ "$#" -gt 0 ]; do
		case "$1" in
			--activate-section)
				shift
				TEST_ACTIVATE_SECTION="${1:-}"
				;;
			--current) TEST_MODE_CURRENT=1 ;;
			--strategy) TEST_MODE_STRATEGY=1 ;;
			--fake-sweep|--fakes) TEST_MODE_FAKE_SWEEP=1 ;;
			--tcp-16-20|--tcp1620) TEST_MODE_TCP1620=1 ;;
			--youtube-only|--youtube) TEST_YOUTUBE_ONLY=1 ;;
			--discord-only|--discord) TEST_DISCORD_ONLY=1 ;;
			--others-only|--others|--no-youtube) TEST_OTHERS_ONLY=1 ;;
			--lan-confirm)
				# deprecated no-op (раньше спрашивали ПК; теперь только note)
				;;
			--yes) TEST_YES=1 ;;
			--print-hosts)
				TEST_PRINT_HOSTS=1
				TEST_MODE_CURRENT=1
				;;
			--source)
				shift
				TEST_SOURCE="${1:-auto}"
				;;
			-h|--help)
				usage
				exit 0
				;;
			*)
				printf 'Неизвестный параметр: %s\n' "$1" >&2
				usage >&2
				exit 1
				;;
		esac
		shift
	done

	if [ -n "${TEST_ACTIVATE_SECTION:-}" ]; then
		case "$TEST_ACTIVATE_SECTION" in
			compose:*)
				# Format: compose:<target_sec>:<web_sec>:<media_sec>:<voice_sec>
				_rest="${TEST_ACTIVATE_SECTION#compose:}"
				_c_target="${_rest%%:*}"; _rest="${_rest#*:}"
				_c_web="${_rest%%:*}"; _rest="${_rest#*:}"
				_c_media="${_rest%%:*}"; _c_voice="${_rest#*:}"
				[ -n "$_c_target" ] || _c_target="discord"
				zapret_fast_probe_compose_discord_section "$_c_target" "$_c_web" "$_c_media" "$_c_voice"
				if [ "$_c_target" != "discord" ]; then
					test_set_enabled_profile "discord" 0 2>/dev/null || true
				fi
				test_set_enabled_profile "$_c_target" 1
				test_apply_runtime || true
				printf 'activated_section=%s\n' "$_c_target"
				return 0
				;;
		esac
		if [ "$TEST_ACTIVATE_SECTION" = "discord" ] || [ "${TEST_ACTIVATE_SECTION#discord_}" != "$TEST_ACTIVATE_SECTION" ]; then
			_d_conf="$(zapret_sections_root)/discord/config/section.text"
			if [ "$TEST_ACTIVATE_SECTION" = "discord_canonical" ]; then
				cat > "$_d_conf" <<'EOF'
# 1. Основные домены Discord (Web / API / Gateway, TCP 80, 443)
--filter-tcp=80,443
{{SELECT_LIST}}
{{SELECT_EXCLUDE_LIST}}
--dpi-desync=fake
--dpi-desync-repeats=3
--dpi-desync-fooling=ts
--dpi-desync-any-protocol=1
--dpi-desync-cutoff=0
--dpi-desync-fake-tls=/opt/zapret/files/fake/stun2.bin
--dpi-desync-fake-http=/opt/zapret/files/fake/tls_clienthello_max_ru.bin
--new
# 2. QUIC / HTTP3 трафик Discord (UDP 443)
--filter-udp=443
--filter-l7=discord
--dpi-desync=fake
--dpi-desync-repeats=3
--new
# 3. Голосовые каналы и звонки Discord (Voice / WebRTC STUN, UDP)
--filter-udp=19294-19344,50000-50100
--filter-l7=discord,stun
--dpi-desync=fake
--dpi-desync-repeats=6
--dpi-desync-fake-stun=/opt/zapret/files/fake/quic_initial_www_google_com.bin
--dpi-desync-fake-discord=/opt/zapret/files/fake/quic_initial_www_google_com.bin
--new
# 4. Медиа-серверы и демонстрация экрана (discord.media / Screen Share, TCP)
--filter-tcp=2053,2083,2087,2096,8443
--hostlist-domains=discord.media
--dpi-desync=fake,fakedsplit
--dpi-desync-repeats=6
--dpi-desync-fooling=ts
--dpi-desync-fakedsplit-pattern=0x00
--dpi-desync-fake-tls=/opt/zapret/files/fake/stun2.bin
--dpi-desync-fake-http=/opt/zapret/files/fake/tls_clienthello_max_ru.bin
EOF
			else
				_d_args="$(zapret_fast_probe_discord_strategies | awk -F'\t' -v b="$TEST_ACTIVATE_SECTION" '$1==b {print $2}')"
				if [ -n "$_d_args" ]; then
					_d_args_clean="$(printf '%s' "$_d_args" | sed 's/--filter-tcp=[0-9,]*//g' | tr -s ' ')"
					cat > "$_d_conf" <<EOF
# 1. Основные домены Discord (Web / API / Gateway, TCP 80, 443)
--filter-tcp=80,443
{{SELECT_LIST}}
{{SELECT_EXCLUDE_LIST}}
$_d_args_clean
--new
# 2. Голосовые каналы и звонки Discord (Voice / WebRTC STUN, UDP)
--filter-udp=19294-19344,50000-50100
--filter-l7=discord,stun
--dpi-desync=fake
--dpi-desync-repeats=6
--dpi-desync-fake-stun=/opt/zapret/files/fake/quic_initial_www_google_com.bin
--dpi-desync-fake-discord=/opt/zapret/files/fake/quic_initial_www_google_com.bin
--new
# 3. Медиа-серверы и демонстрация экрана (discord.media / Screen Share, TCP)
--filter-tcp=2053,2083,2087,2096,8443
--hostlist-domains=discord.media
--dpi-desync=fake,fakedsplit
--dpi-desync-repeats=6
--dpi-desync-fooling=ts
--dpi-desync-fakedsplit-pattern=0x00
--dpi-desync-fake-tls=/opt/zapret/files/fake/stun2.bin
--dpi-desync-fake-http=/opt/zapret/files/fake/tls_clienthello_max_ru.bin
EOF
				fi
			fi
			test_set_enabled_profile "discord" 1
		else
			case "$TEST_ACTIVATE_SECTION" in
				wan6_direct)
					sh "$ROOT_DIR/system/disable-wan-ipv6.sh" --enable --mode selective --apply || true
					sh "$ROOT_DIR/iface-routing/apply-routing.sh" || true
					printf 'activated_section=%s\n' "$TEST_ACTIVATE_SECTION"
					return 0
					;;
				wan6_zapret_multisplit)
					sh "$ROOT_DIR/system/disable-wan-ipv6.sh" --enable --mode full --zapret-ipv6 1 --apply || true
					sh "$ROOT_DIR/iface-routing/apply-routing.sh" || true
					;;
				*@*)
					_base_sec="${TEST_ACTIVATE_SECTION%@*}"
					_fake_file="${TEST_ACTIVATE_SECTION#*@}"
					zapret_fast_probe_apply_fake_to_section_file "$(zapret_sections_root)/$_base_sec/config/section.text" "/opt/zapret/files/fake/$_fake_file" || true
					test_apply_mutex_for_candidate "$_base_sec"
					;;
				*)
					test_apply_mutex_for_candidate "$TEST_ACTIVATE_SECTION"
					;;
			esac
		fi
		test_apply_runtime || true
		printf 'activated_section=%s\n' "$TEST_ACTIVATE_SECTION"
		return 0
	fi

	modes=$((TEST_MODE_CURRENT + TEST_MODE_STRATEGY + TEST_MODE_FAKE_SWEEP + TEST_MODE_TCP1620))
	if [ "$modes" -gt 1 ]; then
		printf 'Укажите только один режим: --current | --strategy | --fake-sweep | --tcp-16-20\n' >&2
		exit 1
	fi
	scopes=$((TEST_YOUTUBE_ONLY + TEST_DISCORD_ONLY + TEST_OTHERS_ONLY))
	if [ "$scopes" -gt 1 ]; then
		printf 'Укажите только одну область: --youtube-only | --discord-only | --others-only\n' >&2
		exit 1
	fi

	if [ "$TEST_MODE_TCP1620" -eq 1 ]; then
		if zapret_is_profile_generator_host_lists; then
			test_die_host
		fi
		if ! command -v curl >/dev/null 2>&1; then
			printf '%s\n' "Нужен curl на роутере." >&2
			exit 1
		fi
		run_mode_tcp1620
		return "$?"
	fi

	if [ "$TEST_MODE_STRATEGY" -eq 1 ]; then
		if zapret_is_profile_generator_host_lists; then
			test_die_host
		fi
		if ! command -v curl >/dev/null 2>&1; then
			printf '%s\n' "Нужен curl на роутере." >&2
			exit 1
		fi
		if [ "$TEST_YES" -eq 0 ]; then
			ui_init
			ui_trap_cleanup_on_exit
		fi
		run_mode_strategy_switch
		return "$?"
	fi

	if [ "$TEST_MODE_FAKE_SWEEP" -eq 1 ]; then
		if zapret_is_profile_generator_host_lists; then
			test_die_host
		fi
		if ! command -v curl >/dev/null 2>&1; then
			printf '%s\n' "Нужен curl на роутере." >&2
			exit 1
		fi
		if [ "$TEST_YES" -eq 0 ]; then
			ui_init
			ui_trap_cleanup_on_exit
		fi
		run_mode_fake_sweep
		return "$?"
	fi

	if [ "${TEST_MODE_CURRENT:-0}" -eq 1 ]; then
		if [ "$TEST_PRINT_HOSTS" -eq 0 ]; then
			if zapret_is_profile_generator_host_lists; then
				test_die_host
			fi
			if ! command -v curl >/dev/null 2>&1; then
				printf '%s\n' "Нужен curl на роутере." >&2
				exit 1
			fi
		fi
		run_mode_current_config
		return "$?"
	fi

	ui_init
	ui_trap_cleanup_on_exit

	if zapret_is_profile_generator_host_lists; then
		test_die_host
	fi

	if ! command -v curl >/dev/null 2>&1; then
		ui_msgbox "Zapret: тест" "Нужен curl на роутере."
		exit 1
	fi

	while true; do
		mode="$(ui_menu "Zapret: тест секций" "YouTube и остальные — отдельно" 19 84 13 \
			"1" "YouTube: текущие ENABLED" \
			"2" "Остальные: текущие ENABLED" \
			"3" "YouTube: быстрый перебор стратегий" \
			"4" "Остальные: быстрый перебор стратегий" \
			"5" "YouTube: перебор fake TLS файлов" \
			"6" "DPI TCP 16-20" \
			"0" "Назад" || true)"
		case "$mode" in
			1)
				TEST_YOUTUBE_ONLY=1
				TEST_OTHERS_ONLY=0
				_cur_rep="$(mktemp)"
				run_mode_current_config >"$_cur_rep" 2>&1 || true
				ui_show_textbox "Zapret: YouTube (текущие)" "$_cur_rep" 28 100
				rm -f "$_cur_rep"
				;;
			2)
				TEST_YOUTUBE_ONLY=0
				TEST_OTHERS_ONLY=1
				_cur_rep="$(mktemp)"
				run_mode_current_config >"$_cur_rep" 2>&1 || true
				ui_show_textbox "Zapret: остальные (текущие)" "$_cur_rep" 28 100
				rm -f "$_cur_rep"
				;;
			3)
				TEST_YOUTUBE_ONLY=1
				TEST_OTHERS_ONLY=0
				run_mode_strategy_switch
				;;
			4)
				TEST_YOUTUBE_ONLY=0
				TEST_OTHERS_ONLY=1
				run_mode_strategy_switch
				;;
			5)
				TEST_YOUTUBE_ONLY=1
				TEST_OTHERS_ONLY=0
				run_mode_fake_sweep
				;;
			6)
				_dpi_rep="$(mktemp)"
				run_mode_tcp1620 >"$_dpi_rep" 2>&1 || true
				ui_show_textbox "Zapret: DPI TCP 16-20" "$_dpi_rep" 28 100
				rm -f "$_dpi_rep"
				;;
			*) exit 0 ;;
		esac
	done
}

main "$@"
