#!/bin/sh
# shellcheck shell=sh
# Тест доступности секций zapret:
#   A) перебор стратегий в профиле (HOST_FILE mutex + apply/restore)
#   B) проверка уже применённых секций из state (только curl)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/ui.sh"
. "$SCRIPT_DIR/lib.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/probe-access.sh"

PROBE_LIMIT="${XFREE_ZAPRET_TEST_PROBE_LIMIT:-6}"
DEFAULT_DOMAINS="${XFREE_ZAPRET_TEST_DOMAINS:-youtube.com www.youtube.com}"
CONNECT_TIMEOUT="${XFREE_ZAPRET_TEST_CONNECT_TIMEOUT:-4}"
MAX_TIME="${XFREE_ZAPRET_TEST_MAX_TIME:-8}"
XFREE_ZAPRET_TEST_PROBE_LIMIT="$PROBE_LIMIT"
XFREE_ZAPRET_TEST_CONNECT_TIMEOUT="$CONNECT_TIMEOUT"
XFREE_ZAPRET_TEST_MAX_TIME="$MAX_TIME"
export XFREE_ZAPRET_TEST_PROBE_LIMIT XFREE_ZAPRET_TEST_CONNECT_TIMEOUT XFREE_ZAPRET_TEST_MAX_TIME

TEST_YES=0
TEST_PRINT_HOSTS=0
TEST_SOURCE="auto"

TEST_SNAP=""
TEST_RESTORED=0

test_die_host() {
	ui_msgbox "Zapret: тест секций" "На host (profile-generator) runtime-тест недоступен.

Запускайте на роутере: xft → Zapret → Тест секций."
	exit 0
}

test_conf_path_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/config/section.conf\n' "$(zapret_sections_root)" "$slug"
}

test_conf_path_state() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/config/section.conf\n' "$(zapret_state_sections_root)" "$slug"
}

test_fqdn_dir_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/fqdn.d\n' "$(zapret_sections_root)" "$slug"
}

test_fqdn_dir_state() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/fqdn.d\n' "$(zapret_state_sections_root)" "$slug"
}

test_enabled_status_from_conf() {
	conf_path="$1"
	if [ -f "$conf_path" ] && ! _zapret_section_enabled_quick "$conf_path"; then
		printf 'OFF\n'
	else
		printf 'ON\n'
	fi
}

test_set_enabled_profile() {
	section="$1"
	enabled="$2"
	conf_path="$(test_conf_path_profile "$section")"
	[ -f "$conf_path" ] || {
		warn "нет section.conf: $section"
		return 1
	}
	tmp="${conf_path}.tmp.$$"
	awk -v val="$enabled" '
		BEGIN { set=0 }
		/^ZAPRET_SECTION_ENABLED=/ { print "ZAPRET_SECTION_ENABLED='\''" val "'\''"; set=1; next }
		{ print }
		END { if (set==0) print "ZAPRET_SECTION_ENABLED='\''" val "'\''" }
	' "$conf_path" > "$tmp"
	mv "$tmp" "$conf_path"
}

test_host_file_for_section_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	zapret_section_host_file_quick "$(test_conf_path_profile "$section")" "$slug"
}

test_snapshot_all_profile() {
	out="$1"
	: > "$out"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		st="$(test_enabled_status_from_conf "$(test_conf_path_profile "$section")")"
		if [ "$st" = "ON" ]; then
			printf '%s\t1\n' "$section" >> "$out"
		else
			printf '%s\t0\n' "$section" >> "$out"
		fi
	done <<EOF
$(zapret_iter_sections)
EOF
}

test_restore_snapshot_profile() {
	snap="$1"
	[ -f "$snap" ] || return 0
	while IFS="$(printf '\t')" read -r section val; do
		[ -n "${section:-}" ] || continue
		test_set_enabled_profile "$section" "${val:-0}" || true
	done < "$snap"
}

test_apply_runtime() {
	info "zapret: apply профиля → runtime…"
	ZAPRET_RESTART_QUIET=1
	export ZAPRET_RESTART_QUIET
	zapret_apply_profile_to_runtime
}

test_cleanup_trap() {
	[ "${TEST_RESTORED:-0}" = "1" ] && return 0
	[ -n "${TEST_SNAP:-}" ] && [ -f "${TEST_SNAP:-}" ] || return 0
	warn "тест прерван — восстанавливаем ENABLED и apply…"
	test_restore_snapshot_profile "$TEST_SNAP" || true
	test_apply_runtime || true
	TEST_RESTORED=1
	rm -f "$TEST_SNAP" 2>/dev/null || true
}

# Ranked curlable FQDNs from fqdn.d; fallback DEFAULT_DOMAINS.
test_collect_probe_domains() {
	fqdn_dir="$1"
	out="$2"
	hint="${3:-}"
	zapret_probe_collect_fqdn_dir "$fqdn_dir" "$PROBE_LIMIT" "$hint" >"$out"
	if [ ! -s "$out" ]; then
		# shellcheck disable=SC2086
		for d in $DEFAULT_DOMAINS; do
			printf '%s\n' "$d" >>"$out"
		done
	fi
}

test_curl_domains_file() {
	domains_file="$1"
	ok=0
	total=0
	while IFS= read -r domain; do
		[ -n "$domain" ] || continue
		total=$((total + 1))
		line="$(zapret_probe_one_host "$domain" || true)"
		printf '  %s\n' "$line"
		case "$line" in
			OK*) ok=$((ok + 1)) ;;
		esac
	done <"$domains_file"
	printf '%s %s\n' "$ok" "$total"
}

test_pick_sections_from_list() {
	# stdin: section names; uses conf_path_fn name via env TEST_CONF_FN=profile|state
	# optional: TEST_ONLY_ENABLED=1
	list_file="$1"
	mode_label="$2"
	only_enabled="${3:-0}"

	tmp_on="$(mktemp)"
	tmp_off="$(mktemp)"
	: > "$tmp_on"
	: > "$tmp_off"

	while IFS= read -r section; do
		[ -n "$section" ] || continue
		if [ "$TEST_CONF_FN" = "state" ]; then
			conf="$(test_conf_path_state "$section")"
		else
			conf="$(test_conf_path_profile "$section")"
		fi
		st="$(test_enabled_status_from_conf "$conf")"
		if [ "$only_enabled" = "1" ] && [ "$st" != "ON" ]; then
			continue
		fi
		if [ "$st" = "ON" ]; then
			printf '%s\n' "$section" >> "$tmp_on"
		else
			printf '%s\n' "$section" >> "$tmp_off"
		fi
	done < "$list_file"

	if [ ! -s "$tmp_on" ] && [ ! -s "$tmp_off" ]; then
		rm -f "$tmp_on" "$tmp_off"
		ui_msgbox "Zapret: тест" "Нет секций для выбора ($mode_label)."
		return 1
	fi

	choice="$(ui_menu "Zapret: тест — выбор" "$mode_label" 20 90 12 \
		"A" "Все из списка" \
		"S" "Выбрать несколько (checklist)" \
		"1" "Одна секция" \
		"0" "Назад" || true)"
	[ -n "${choice:-}" ] || {
		rm -f "$tmp_on" "$tmp_off"
		return 1
	}

	out_sel="$(mktemp)"
	case "$choice" in
		A)
			cat "$tmp_on" "$tmp_off" > "$out_sel"
			;;
		1)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			one="$(ui_menu "Zapret: одна секция" "Выберите секцию" 22 90 14 "$@" || true)"
			[ -n "${one:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$out_sel"
				return 1
			}
			eval "printf '%s\n' \"\${TSEC_$one}\"" > "$out_sel"
			;;
		S)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			tags="$(ui_checklist "Zapret: секции" "Отметьте секции для теста" 22 90 14 "$@" || true)"
			[ -n "${tags:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$out_sel"
				return 1
			}
			: > "$out_sel"
			for tag in $tags; do
				eval "printf '%s\n' \"\${TSEC_$tag}\"" >> "$out_sel"
			done
			;;
		*)
			rm -f "$tmp_on" "$tmp_off" "$out_sel"
			return 1
			;;
	esac

	rm -f "$tmp_on" "$tmp_off"
	[ -s "$out_sel" ] || {
		rm -f "$out_sel"
		return 1
	}
	printf '%s\n' "$out_sel"
}

test_apply_mutex_for_candidate() {
	candidate="$1"
	host_file="$(test_host_file_for_section_profile "$candidate")"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		hf="$(test_host_file_for_section_profile "$section")"
		if [ "$hf" = "$host_file" ]; then
			if [ "$section" = "$candidate" ]; then
				test_set_enabled_profile "$section" 1
			else
				test_set_enabled_profile "$section" 0
			fi
		fi
	done <<EOF
$(zapret_iter_sections)
EOF
}

run_mode_strategy_switch() {
	list_all="$(mktemp)"
	zapret_iter_sections > "$list_all"
	[ -s "$list_all" ] || {
		rm -f "$list_all"
		ui_msgbox "Zapret: тест" "В профиле нет секций zapret."
		return 0
	}

	TEST_CONF_FN=profile
	sel_file="$(test_pick_sections_from_list "$list_all" "Профиль: перебор стратегий" 0)" || {
		rm -f "$list_all"
		return 0
	}
	rm -f "$list_all"

	n="$(grep -c . "$sel_file" || true)"
	if ! ui_confirm "Zapret: перебор стратегий" \
"Кандидатов: $n

Для каждой: временно OFF все секции с тем же HOST_FILE, ON только кандидат → apply+restart → curl.
В конце — восстановление ENABLED и apply.

Продолжить?"; then
		rm -f "$sel_file"
		return 0
	fi

	TEST_SNAP="$(mktemp)"
	test_snapshot_all_profile "$TEST_SNAP"
	TEST_RESTORED=0
	trap 'test_cleanup_trap' EXIT INT TERM

	results="$(mktemp)"
	: > "$results"
	domains_tmp="$(mktemp)"

	printf '\n=== Zapret: перебор стратегий ===\n\n' >/dev/tty 2>/dev/null || true
	idx=0
	total_n="$n"
	while IFS= read -r candidate; do
		[ -n "$candidate" ] || continue
		idx=$((idx + 1))
		printf '\n[%s/%s] кандидат: %s (HOST_FILE=%s)\n' \
			"$idx" "$total_n" "$candidate" "$(test_host_file_for_section_profile "$candidate")"
		test_apply_mutex_for_candidate "$candidate"
		if ! test_apply_runtime; then
			printf '%s\t0\t0\tFAIL_APPLY\n' "$candidate" >> "$results"
			continue
		fi
		test_collect_probe_domains "$(test_fqdn_dir_profile "$candidate")" "$domains_tmp" "$candidate"
		summary="$(test_curl_domains_file "$domains_tmp" | tail -n1)"
		ok="$(printf '%s' "$summary" | awk '{print $1}')"
		tot="$(printf '%s' "$summary" | awk '{print $2}')"
		ok="${ok:-0}"
		tot="${tot:-0}"
		if [ "$ok" -gt 0 ] 2>/dev/null; then
			verdict=PASS
		else
			verdict=FAIL
		fi
		printf '%s\t%s\t%s\t%s\n' "$candidate" "$ok" "$tot" "$verdict" >> "$results"
		printf '→ %s OK=%s/%s\n' "$verdict" "$ok" "$tot"
	done < "$sel_file"

	info "восстановление исходных ENABLED…"
	test_restore_snapshot_profile "$TEST_SNAP"
	test_apply_runtime || true
	TEST_RESTORED=1
	trap - EXIT INT TERM

	report="$(mktemp)"
	{
		printf 'Перебор стратегий (профиль)\n\n'
		printf '%-24s %6s %6s %s\n' "SECTION" "OK" "TOTAL" "RESULT"
		printf '%s\n' "------------------------------------------------"
		sort -t"$(printf '\t')" -k2,2nr -k1,1 "$results" | while IFS="$(printf '\t')" read -r s ok tot v; do
			printf '%-24s %6s %6s %s\n' "$s" "$ok" "$tot" "$v"
		done
	} > "$report"
	ui_show_textbox "Zapret: результаты перебора" "$report" 28 100

	best="$(awk -F'\t' '$4=="PASS"' "$results" | sort -t"$(printf '\t')" -k2,2nr -k1,1 | head -n1 | cut -f1)"
	if [ -n "${best:-}" ]; then
		if ui_confirm "Zapret: активировать лучшую?" \
"Лучшая PASS: $best

Включить её и выключить остальные с тем же HOST_FILE?"; then
			test_apply_mutex_for_candidate "$best"
			test_apply_runtime || true
			ui_msgbox "Zapret: тест" "Активирована секция: $best"
		fi
	fi

	rm -f "$sel_file" "$results" "$domains_tmp" "$report" "$TEST_SNAP"
	TEST_SNAP=""
}

run_mode_applied_state() {
	state_root="$(zapret_state_sections_root)"
	if [ ! -d "$state_root" ]; then
		ui_msgbox "Zapret: тест" "Нет применённого state:
$state_root

Сначала примените профиль (Zapret → Применить)."
		return 0
	fi

	list_all="$(mktemp)"
	zapret_iter_state_sections > "$list_all"
	if [ ! -s "$list_all" ]; then
		rm -f "$list_all"
		ui_msgbox "Zapret: тест" "В state нет секций:
$state_root"
		return 0
	fi

	tmp_on="$(mktemp)"
	tmp_off="$(mktemp)"
	: > "$tmp_on"
	: > "$tmp_off"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		st="$(test_enabled_status_from_conf "$(test_conf_path_state "$section")")"
		if [ "$st" = "ON" ]; then
			printf '%s\n' "$section" >> "$tmp_on"
		else
			printf '%s\n' "$section" >> "$tmp_off"
		fi
	done < "$list_all"
	rm -f "$list_all"

	if [ ! -s "$tmp_on" ] && [ ! -s "$tmp_off" ]; then
		rm -f "$tmp_on" "$tmp_off"
		ui_msgbox "Zapret: тест" "В state нет секций:
$state_root"
		return 0
	fi

	set -- \
		"E" "Все ENABLED в state" \
		"A" "Все секции в state" \
		"S" "Несколько (checklist)"
	idx=1
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		set -- "$@" "$idx" "[ON] $section"
		eval "TSEC_$idx='$section'"
		idx=$((idx + 1))
	done < "$tmp_on"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		set -- "$@" "$idx" "[OFF] $section"
		eval "TSEC_$idx='$section'"
		idx=$((idx + 1))
	done < "$tmp_off"
	set -- "$@" "0" "Назад"

	choice="$(ui_menu "Zapret: применённые" "Какую секцию проверить?
ENABLED сверху, дальше остальные из state." 22 90 14 "$@" || true)"
	[ -n "${choice:-}" ] || {
		rm -f "$tmp_on" "$tmp_off"
		return 0
	}

	sel_file="$(mktemp)"
	case "$choice" in
		E)
			cat "$tmp_on" > "$sel_file"
			;;
		A)
			cat "$tmp_on" "$tmp_off" > "$sel_file"
			;;
		S)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			tags="$(ui_checklist "Zapret: секции state" "Отметьте секции для проверки" 22 90 14 "$@" || true)"
			[ -n "${tags:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$sel_file"
				return 0
			}
			: > "$sel_file"
			for tag in $tags; do
				eval "printf '%s\n' \"\${TSEC_$tag}\"" >> "$sel_file"
			done
			;;
		0)
			rm -f "$tmp_on" "$tmp_off" "$sel_file"
			return 0
			;;
		*)
			eval "printf '%s\n' \"\${TSEC_$choice}\"" > "$sel_file"
			;;
	esac
	rm -f "$tmp_on" "$tmp_off"
	[ -s "$sel_file" ] || {
		rm -f "$sel_file"
		ui_msgbox "Zapret: тест" "Нет секций для проверки."
		return 0
	}

	n="$(grep -c . "$sel_file" || true)"
	if [ "$n" = "1" ]; then
		_one="$(head -n1 "$sel_file")"
		_confirm_body="Секция: $_one

Runtime не меняется (без apply/restart).
Curl по fqdn.d из state против текущего NFQWS.

Продолжить?"
	else
		_confirm_body="Секций: $n

Runtime не меняется (без apply/restart).
Curl по fqdn.d из state против текущего NFQWS.

Продолжить?"
	fi
	if ! ui_confirm "Zapret: проверка state" "$_confirm_body"; then
		rm -f "$sel_file"
		return 0
	fi

	results="$(mktemp)"
	domains_tmp="$(mktemp)"
	: > "$results"

	printf '\n=== Zapret: проверка применённых (state) ===\n\n' >/dev/tty 2>/dev/null || true
	idx=0
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		idx=$((idx + 1))
		printf '\n[%s/%s] %s\n' "$idx" "$n" "$section"
		test_collect_probe_domains "$(test_fqdn_dir_state "$section")" "$domains_tmp" "$section"
		summary="$(test_curl_domains_file "$domains_tmp" | tail -n1)"
		ok="$(printf '%s' "$summary" | awk '{print $1}')"
		tot="$(printf '%s' "$summary" | awk '{print $2}')"
		ok="${ok:-0}"
		tot="${tot:-0}"
		if [ "$ok" -gt 0 ] 2>/dev/null; then
			verdict=PASS
		else
			verdict=FAIL
		fi
		printf '%s\t%s\t%s\t%s\n' "$section" "$ok" "$tot" "$verdict" >> "$results"
		printf '→ %s OK=%s/%s\n' "$verdict" "$ok" "$tot"
	done < "$sel_file"

	report="$(mktemp)"
	{
		printf 'Проверка применённых (state)\n\n'
		printf '%-24s %6s %6s %s\n' "SECTION" "OK" "TOTAL" "RESULT"
		printf '%s\n' "------------------------------------------------"
		sort -t"$(printf '\t')" -k2,2nr -k1,1 "$results" | while IFS="$(printf '\t')" read -r s ok tot v; do
			printf '%-24s %6s %6s %s\n' "$s" "$ok" "$tot" "$v"
		done
	} > "$report"
	ui_show_textbox "Zapret: результаты state" "$report" 28 100

	rm -f "$sel_file" "$results" "$domains_tmp" "$report"
}

test_current_conf_path() {
	section="$1"
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		test_conf_path_state "$section"
	else
		test_conf_path_profile "$section"
	fi
}

test_current_fqdn_dir() {
	section="$1"
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		test_fqdn_dir_state "$section"
	else
		test_fqdn_dir_profile "$section"
	fi
}

test_iter_current_sections() {
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		zapret_iter_state_sections
	else
		zapret_iter_sections
	fi
}

run_mode_current_config() {
	TEST_CURRENT_SRC="$TEST_SOURCE"
	if [ "$TEST_CURRENT_SRC" = "auto" ]; then
		if [ -d "$(zapret_state_sections_root)" ]; then
			TEST_CURRENT_SRC="state"
		else
			TEST_CURRENT_SRC="profile"
		fi
	fi

	if [ "$TEST_CURRENT_SRC" = "state" ] && [ ! -d "$(zapret_state_sections_root)" ]; then
		printf '%s\n' "Нет применённого state: $(zapret_state_sections_root)"
		printf '%s\n' "Сначала: xft → Zapret → Применить списки."
		return 1
	fi

	list_all="$(mktemp)"
	test_iter_current_sections >"$list_all"
	if [ ! -s "$list_all" ]; then
		rm -f "$list_all"
		printf '%s\n' "Нет секций ($TEST_CURRENT_SRC)."
		return 1
	fi

	if [ "$TEST_PRINT_HOSTS" -ne 1 ]; then
		printf '=== Zapret: текущая конфигурация (%s) ===\n' "$TEST_CURRENT_SRC"
		printf 'probe https://FQDN  family=%s  timeout=%ss/%ss  limit=%s/section\n' \
			"${XFREE_ZAPRET_TEST_IP_FAMILY:-4}" \
			"$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT" \
			"$XFREE_ZAPRET_TEST_MAX_TIME" \
			"$PROBE_LIMIT"
	if pidof nfqws >/dev/null 2>&1 || pidof nfqws2 >/dev/null 2>&1; then
		printf 'nfqws: running\n'
	else
		printf 'nfqws: not found (пробы всё равно идут)\n'
	fi
		printf '\n'
	fi

	host_cache="$(mktemp)"
	: >"$host_cache"
	sec_pass=0
	sec_fail=0
	sec_skip=0
	host_ok=0
	host_fail=0
	any_fail=0

	while IFS= read -r section; do
		[ -n "$section" ] || continue
		conf="$(test_current_conf_path "$section")"
		st="$(test_enabled_status_from_conf "$conf")"
		[ "$st" = "ON" ] || continue
		hosts_tmp="$(mktemp)"
		zapret_probe_collect_fqdn_dir "$(test_current_fqdn_dir "$section")" "$PROBE_LIMIT" "$section" >"$hosts_tmp"
		if [ ! -s "$hosts_tmp" ]; then
			rm -f "$hosts_tmp"
			if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
				continue
			fi
			printf '[%s]\n' "$section"
			printf '  SKIP no curlable FQDN\n\n'
			sec_skip=$((sec_skip + 1))
			continue
		fi
		if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
			while IFS= read -r h; do
				[ -n "$h" ] || continue
				printf '%s\t%s\n' "$section" "$h"
			done <"$hosts_tmp"
			rm -f "$hosts_tmp"
			continue
		fi
		printf '[%s]\n' "$section"
		sok=0
		stot=0
		while IFS= read -r h; do
			[ -n "$h" ] || continue
			stot=$((stot + 1))
			cached="$(awk -F'\t' -v host="$h" '$1==host { print $2; exit }' "$host_cache")"
			if [ -n "$cached" ]; then
				printf '  %s  (cached)\n' "$cached"
				case "$cached" in
					OK*) sok=$((sok + 1)) ;;
				esac
				continue
			fi
			line="$(zapret_probe_one_host "$h" || true)"
			printf '  %s\n' "$line"
			printf '%s\t%s\n' "$h" "$line" >>"$host_cache"
			case "$line" in
				OK*)
					sok=$((sok + 1))
					host_ok=$((host_ok + 1))
					;;
				*)
					host_fail=$((host_fail + 1))
					;;
			esac
		done <"$hosts_tmp"
		rm -f "$hosts_tmp"
		if [ "$sok" -gt 0 ]; then
			printf '  → PASS %s/%s\n\n' "$sok" "$stot"
			sec_pass=$((sec_pass + 1))
		else
			printf '  → FAIL %s/%s\n\n' "$sok" "$stot"
			sec_fail=$((sec_fail + 1))
			any_fail=1
		fi
	done <"$list_all"
	rm -f "$list_all" "$host_cache"

	if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
		return 0
	fi

	printf '---\n'
	printf 'UNIQUE HOSTS  OK=%s FAIL=%s\n' "$host_ok" "$host_fail"
	printf 'SECTIONS      PASS=%s FAIL=%s SKIP=%s\n' "$sec_pass" "$sec_fail" "$sec_skip"
	if [ "$sec_pass" -eq 0 ] && [ "$sec_fail" -eq 0 ]; then
		printf 'Нет ENABLED-секций с curlable FQDN.\n'
		return 1
	fi
	[ "$any_fail" -eq 0 ]
}

usage() {
	cat <<EOF
Использование:
  $(basename "$0") [--current] [--yes] [--print-hosts] [--source auto|state|profile]

  --current       проверить ENABLED-секции текущей конфигурации (без apply)
  --yes           без подтверждений (для меню / SSH)
  --print-hosts   только список FQDN, без curl
  --source        auto (state если есть) | state | profile

Без аргументов — интерактивное меню (перебор стратегий / выбор секций).
EOF
}

main() {
	while [ "$#" -gt 0 ]; do
		case "$1" in
			--current) TEST_MODE_CURRENT=1 ;;
			--yes) TEST_YES=1 ;;
			--print-hosts)
				TEST_PRINT_HOSTS=1
				TEST_MODE_CURRENT=1
				;;
			--source)
				shift
				TEST_SOURCE="${1:-auto}"
				;;
			-h|--help)
				usage
				exit 0
				;;
			*)
				printf 'Неизвестный параметр: %s\n' "$1" >&2
				usage >&2
				exit 1
				;;
		esac
		shift
	done

	if [ "${TEST_MODE_CURRENT:-0}" -eq 1 ]; then
		if [ "$TEST_PRINT_HOSTS" -eq 0 ]; then
			if zapret_is_profile_generator_host_lists; then
				test_die_host
			fi
			if ! command -v curl >/dev/null 2>&1; then
				printf '%s\n' "Нужен curl на роутере." >&2
				exit 1
			fi
		fi
		run_mode_current_config
		return "$?"
	fi

	ui_init
	ui_trap_cleanup_on_exit

	if zapret_is_profile_generator_host_lists; then
		test_die_host
	fi

	if ! command -v curl >/dev/null 2>&1; then
		ui_msgbox "Zapret: тест" "Нужен curl на роутере."
		exit 1
	fi

	while true; do
		mode="$(ui_menu "Zapret: тест секций" "Выберите режим" 18 84 10 \
			"1" "Текущая конфигурация (ENABLED, без apply)" \
			"2" "Перебор стратегий (профиль, apply)" \
			"3" "Выбрать секции из state" \
			"0" "Назад" || true)"
		case "$mode" in
			1)
				_cur_rep="$(mktemp)"
				run_mode_current_config >"$_cur_rep" 2>&1 || true
				ui_show_textbox "Zapret: текущая конфигурация" "$_cur_rep" 28 100
				rm -f "$_cur_rep"
				;;
			2) run_mode_strategy_switch ;;
			3) run_mode_applied_state ;;
			*) exit 0 ;;
		esac
	done
}

main "$@"
