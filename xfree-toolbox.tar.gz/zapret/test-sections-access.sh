#!/bin/sh
# shellcheck shell=sh
# Тест доступности секций zapret:
#   A) перебор стратегий в профиле (HOST_FILE mutex + apply/restore)
#   B) проверка уже применённых секций из state (только curl)
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/ui.sh"
. "$SCRIPT_DIR/lib.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/probe-access.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/probe-youtube.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/probe-tcp-16-20.sh"

PROBE_LIMIT="${XFREE_ZAPRET_TEST_PROBE_LIMIT:-0}"
DEFAULT_DOMAINS="${XFREE_ZAPRET_TEST_DOMAINS:-youtube.com www.youtube.com}"
CONNECT_TIMEOUT="${XFREE_ZAPRET_TEST_CONNECT_TIMEOUT:-4}"
MAX_TIME="${XFREE_ZAPRET_TEST_MAX_TIME:-8}"
XFREE_ZAPRET_TEST_PROBE_LIMIT="$PROBE_LIMIT"
XFREE_ZAPRET_TEST_CONNECT_TIMEOUT="$CONNECT_TIMEOUT"
XFREE_ZAPRET_TEST_MAX_TIME="$MAX_TIME"
export XFREE_ZAPRET_TEST_PROBE_LIMIT XFREE_ZAPRET_TEST_CONNECT_TIMEOUT XFREE_ZAPRET_TEST_MAX_TIME

TEST_MODE_CURRENT=0
TEST_MODE_STRATEGY=0
TEST_MODE_TCP1620=0
TEST_YES=0
TEST_PRINT_HOSTS=0
TEST_YOUTUBE_ONLY=0
TEST_OTHERS_ONLY=0
TEST_SOURCE="auto"

TEST_SNAP=""
TEST_RESTORED=0

test_die_host() {
	ui_msgbox "Zapret: тест секций" "На host (profile-generator) runtime-тест недоступен.

Запускайте на роутере: xft → Zapret → Тест секций."
	exit 0
}

# Respect --yes (non-interactive SSH / menu).
test_confirm() {
	title="$1"
	body="$2"
	if [ "${TEST_YES:-0}" -eq 1 ]; then
		return 0
	fi
	ui_confirm "$title" "$body"
}

test_conf_path_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/config/section.conf\n' "$(zapret_sections_root)" "$slug"
}

test_conf_path_state() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/config/section.conf\n' "$(zapret_state_sections_root)" "$slug"
}

test_fqdn_dir_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/fqdn.d\n' "$(zapret_sections_root)" "$slug"
}

test_fqdn_dir_state() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	printf '%s/%s/fqdn.d\n' "$(zapret_state_sections_root)" "$slug"
}

test_enabled_status_from_conf() {
	conf_path="$1"
	if [ -f "$conf_path" ] && ! _zapret_section_enabled_quick "$conf_path"; then
		printf 'OFF\n'
	else
		printf 'ON\n'
	fi
}

test_set_enabled_profile() {
	section="$1"
	enabled="$2"
	conf_path="$(test_conf_path_profile "$section")"
	[ -f "$conf_path" ] || {
		warn "нет section.conf: $section"
		return 1
	}
	tmp="${conf_path}.tmp.$$"
	awk -v val="$enabled" '
		BEGIN { set=0 }
		/^ZAPRET_SECTION_ENABLED=/ { print "ZAPRET_SECTION_ENABLED='\''" val "'\''"; set=1; next }
		{ print }
		END { if (set==0) print "ZAPRET_SECTION_ENABLED='\''" val "'\''" }
	' "$conf_path" > "$tmp"
	mv "$tmp" "$conf_path"
}

test_host_file_for_section_profile() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	zapret_section_host_file_quick "$(test_conf_path_profile "$section")" "$slug"
}

test_host_file_for_section_state() {
	section="$1"
	slug="$(common_normalize_token "$section")"
	zapret_section_host_file_quick "$(test_conf_path_state "$section")" "$slug"
}

# Capture last summary line; mirror probe progress to tty when available.
test_probe_capture_summary() {
	if [ -c /dev/tty ] 2>/dev/null; then
		"$@" 2>&1 | tee /dev/tty | tail -n1
	else
		"$@" | tail -n1
	fi
}

test_snapshot_all_profile() {
	out="$1"
	: > "$out"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		st="$(test_enabled_status_from_conf "$(test_conf_path_profile "$section")")"
		if [ "$st" = "ON" ]; then
			printf '%s\t1\n' "$section" >> "$out"
		else
			printf '%s\t0\n' "$section" >> "$out"
		fi
	done <<EOF
$(zapret_iter_sections)
EOF
}

test_restore_snapshot_profile() {
	snap="$1"
	[ -f "$snap" ] || return 0
	while IFS="$(printf '\t')" read -r section val; do
		[ -n "${section:-}" ] || continue
		test_set_enabled_profile "$section" "${val:-0}" || true
	done < "$snap"
}

test_apply_runtime() {
	info "zapret: apply профиля → runtime…"
	ZAPRET_RESTART_QUIET=1
	export ZAPRET_RESTART_QUIET
	zapret_apply_profile_to_runtime
}

# Статика до apply: в section.text кандидата нет отсутствующих fake *.bin (если путь под /opt).
# stdout: OK | FAIL_STATIC missing_fake=…
test_section_static_preflight() {
	candidate="$1"
	slug="$(common_normalize_token "$candidate")"
	text_file="$(zapret_sections_root)/$slug/config/section.text"
	[ -f "$text_file" ] || {
		printf 'FAIL_STATIC no_section_text\n'
		return 1
	}
	text="$(cat "$text_file" 2>/dev/null || true)"
	miss="$(zapret_missing_fake_files_from_text "$text" 2>/dev/null || true)"
	if [ -n "$miss" ]; then
		miss_csv="$(printf '%s' "$miss" | tr '\n' ',' | sed 's/,$//')"
		printf 'FAIL_STATIC missing_fake=%s\n' "$miss_csv"
		return 1
	fi
	printf 'OK\n'
	return 0
}

# После apply+restart: ждёт daemons.
# stdout: одна строка summary (OK / FAIL_DAEMON …); подробности — в stderr.
# 0 = healthy, 1 = unhealthy.
test_daemon_health_gate() {
	health="$(zapret_wait_daemons_healthy 2>/dev/null || true)"
	[ -n "$health" ] || health="FAIL_DAEMON reason=no_summary"
	# одна строка (wait уже печатает summary)
	health="$(printf '%s\n' "$health" | head -n1)"
	printf '%s\n' "$health"
	case "$health" in
		OK*) return 0 ;;
	esac
	printf '  daemon diagnose: %s\n' "$health" >&2
	zapret_daemon_diagnose_report 2>/dev/null | sed 's/^/  /' >&2 || true
	return 1
}

test_cleanup_trap() {
	[ "${TEST_RESTORED:-0}" = "1" ] && return 0
	[ -n "${TEST_SNAP:-}" ] && [ -f "${TEST_SNAP:-}" ] || return 0
	warn "тест прерван — восстанавливаем ENABLED и apply…"
	test_restore_snapshot_profile "$TEST_SNAP" || true
	test_apply_runtime || true
	TEST_RESTORED=1
	rm -f "$TEST_SNAP" 2>/dev/null || true
}

# Ranked curlable FQDNs from fqdn.d; fallback DEFAULT_DOMAINS.
test_collect_probe_domains() {
	fqdn_dir="$1"
	out="$2"
	hint="${3:-}"
	zapret_probe_collect_fqdn_dir "$fqdn_dir" "$PROBE_LIMIT" "$hint" >"$out"
	if [ ! -s "$out" ]; then
		# shellcheck disable=SC2086
		for d in $DEFAULT_DOMAINS; do
			printf '%s\n' "$d" >>"$out"
		done
	fi
}

# YouTube/google HOST_FILE → media suite (home/watch/thumbs/CDN), else fqdn.d hosts.
# source: profile|state (where to read HOST_FILE + fqdn.d for non-YouTube).
test_probe_section() {
	section="$1"
	domains_file="$2"
	source="${3:-profile}"
	if [ "$source" = "state" ]; then
		host_file="$(test_host_file_for_section_state "$section" 2>/dev/null || true)"
		fqdn_dir="$(test_fqdn_dir_state "$section")"
	else
		host_file="$(test_host_file_for_section_profile "$section" 2>/dev/null || true)"
		fqdn_dir="$(test_fqdn_dir_profile "$section")"
	fi
	if zapret_probe_youtube_target_p "$section" "$host_file"; then
		printf '  (YouTube media suite: home/watch/thumbs + googlevideo CDN)\n'
		zapret_probe_youtube_run_suite
		return 0
	fi
	test_collect_probe_domains "$fqdn_dir" "$domains_file" "$section"
	test_curl_domains_file "$domains_file"
}

# Scope filter: youtube-only | others-only | all (default).
# Return 0 if section should be probed.
test_section_in_scope() {
	section="$1"
	host_file="$2"
	is_yt=0
	if zapret_probe_youtube_target_p "$section" "$host_file"; then
		is_yt=1
	fi
	if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ]; then
		[ "$is_yt" -eq 1 ]
		return $?
	fi
	if [ "${TEST_OTHERS_ONLY:-0}" -eq 1 ]; then
		[ "$is_yt" -eq 0 ]
		return $?
	fi
	return 0
}

test_filter_sections_file_scope() {
	# $1=infile $2=outfile  (profile host_file lookup)
	infile="$1"
	outfile="$2"
	: >"$outfile"
	while IFS= read -r s; do
		[ -n "$s" ] || continue
		hf="$(test_host_file_for_section_profile "$s" 2>/dev/null || true)"
		if test_section_in_scope "$s" "$hf"; then
			printf '%s\n' "$s" >>"$outfile"
		fi
	done <"$infile"
}

# PASS if any OK; YouTube: use suite verdict (page+thumb+cdn buckets) when present.
test_probe_verdict() {
	section="$1"
	host_file="$2"
	ok="$3"
	tot="$4"
	yt_verdict="${5:-}"
	if zapret_probe_youtube_target_p "$section" "$host_file"; then
		case "$yt_verdict" in
			PASS|FAIL) printf '%s\n' "$yt_verdict"; return 0 ;;
		esac
		# Fallback if old summary without verdict field.
		need=$(( (tot + 1) / 2 ))
		if [ "$tot" -gt 0 ] 2>/dev/null && [ "$ok" -ge "$need" ] 2>/dev/null; then
			printf 'PASS\n'
		else
			printf 'FAIL\n'
		fi
		return 0
	fi
	if [ "$ok" -gt 0 ] 2>/dev/null; then
		printf 'PASS\n'
	else
		printf 'FAIL\n'
	fi
}

test_curl_domains_file() {
	domains_file="$1"
	ok=0
	total=0
	alive_yes=0
	alive_no=0
	parall="$(zapret_probe_parallel_limit)"
	resdir="$(mktemp -d)"
	PROBE_BG_PIDS=""
	job=0
	while IFS= read -r domain; do
		[ -n "$domain" ] || continue
		job=$((job + 1))
		total=$((total + 1))
		zapret_probe_bg_throttle "$parall"
		zapret_probe_bg_launch "$resdir/$job.out" zapret_probe_one_host "$domain"
	done <"$domains_file"
	zapret_probe_bg_wait_all
	idx=1
	while [ "$idx" -le "$job" ]; do
		line="$(cat "$resdir/$idx.out" 2>/dev/null || true)"
		[ -n "$line" ] || line="FAIL (empty)"
		printf '  %s\n' "$line"
		case "$line" in
			OK*) ok=$((ok + 1)) ;;
		esac
		case "$line" in
			*alive=yes*) alive_yes=$((alive_yes + 1)) ;;
			*alive=no*) alive_no=$((alive_no + 1)) ;;
		esac
		idx=$((idx + 1))
	done
	rm -rf "$resdir"
	printf '  summary alive_yes=%s alive_no=%s parallel=%s\n' "$alive_yes" "$alive_no" "$parall"
	printf '%s %s\n' "$ok" "$total"
}

# Parallel host probes with optional cache file (host\tline). Sets TEST_HOST_OK / TEST_HOST_TOT.
# Prints one result line per host (cached marked). Uses global host_ok/host_fail when set.
test_probe_hosts_parallel_cached() {
	hosts_file="$1"
	cache_file="${2:-}"
	parall="$(zapret_probe_parallel_limit)"
	resdir="$(mktemp -d)"
	PROBE_BG_PIDS=""
	job=0
	order="$(mktemp)"
	: >"$order"
	TEST_HOST_OK=0
	TEST_HOST_TOT=0
	while IFS= read -r h; do
		[ -n "$h" ] || continue
		TEST_HOST_TOT=$((TEST_HOST_TOT + 1))
		cached=""
		if [ -n "$cache_file" ] && [ -f "$cache_file" ]; then
			cached="$(awk -F'\t' -v host="$h" '$1==host { print $2; exit }' "$cache_file")"
		fi
		if [ -n "$cached" ]; then
			printf 'C\t%s\t%s\n' "$h" "$cached" >>"$order"
			continue
		fi
		job=$((job + 1))
		printf 'J\t%s\t%s\n' "$h" "$job" >>"$order"
		zapret_probe_bg_throttle "$parall"
		zapret_probe_bg_launch "$resdir/$job.out" zapret_probe_one_host "$h"
	done <"$hosts_file"
	zapret_probe_bg_wait_all
	while IFS="$(printf '\t')" read -r kind h rest; do
		[ -n "$kind" ] || continue
		if [ "$kind" = "C" ]; then
			line="$rest"
			printf '  %s  (cached)\n' "$line"
			case "$line" in
				OK*) TEST_HOST_OK=$((TEST_HOST_OK + 1)) ;;
			esac
			# Cached hits do not bump unique host_ok/host_fail counters.
			continue
		fi
		jid="$rest"
		line="$(cat "$resdir/$jid.out" 2>/dev/null || true)"
		[ -n "$line" ] || line="FAIL $h  empty"
		printf '  %s\n' "$line"
		if [ -n "$cache_file" ]; then
			printf '%s\t%s\n' "$h" "$line" >>"$cache_file"
		fi
		case "$line" in
			OK*)
				TEST_HOST_OK=$((TEST_HOST_OK + 1))
				host_ok=$((${host_ok:-0} + 1))
				;;
			*)
				host_fail=$((${host_fail:-0} + 1))
				;;
		esac
	done <"$order"
	rm -f "$order"
	rm -rf "$resdir"
}

test_pick_sections_from_list() {
	# stdin: section names; uses conf_path_fn name via env TEST_CONF_FN=profile|state
	# optional: TEST_ONLY_ENABLED=1
	list_file="$1"
	mode_label="$2"
	only_enabled="${3:-0}"

	tmp_on="$(mktemp)"
	tmp_off="$(mktemp)"
	: > "$tmp_on"
	: > "$tmp_off"

	while IFS= read -r section; do
		[ -n "$section" ] || continue
		if [ "$TEST_CONF_FN" = "state" ]; then
			conf="$(test_conf_path_state "$section")"
		else
			conf="$(test_conf_path_profile "$section")"
		fi
		st="$(test_enabled_status_from_conf "$conf")"
		if [ "$only_enabled" = "1" ] && [ "$st" != "ON" ]; then
			continue
		fi
		if [ "$st" = "ON" ]; then
			printf '%s\n' "$section" >> "$tmp_on"
		else
			printf '%s\n' "$section" >> "$tmp_off"
		fi
	done < "$list_file"

	if [ ! -s "$tmp_on" ] && [ ! -s "$tmp_off" ]; then
		rm -f "$tmp_on" "$tmp_off"
		ui_msgbox "Zapret: тест" "Нет секций для выбора ($mode_label)."
		return 1
	fi

	choice="$(ui_menu "Zapret: тест — выбор" "$mode_label" 20 90 12 \
		"A" "Все из списка" \
		"S" "Выбрать несколько (checklist)" \
		"1" "Одна секция" \
		"0" "Назад" || true)"
	[ -n "${choice:-}" ] || {
		rm -f "$tmp_on" "$tmp_off"
		return 1
	}

	out_sel="$(mktemp)"
	case "$choice" in
		A)
			cat "$tmp_on" "$tmp_off" > "$out_sel"
			;;
		1)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			one="$(ui_menu "Zapret: одна секция" "Выберите секцию" 22 90 14 "$@" || true)"
			[ -n "${one:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$out_sel"
				return 1
			}
			eval "printf '%s\n' \"\${TSEC_$one}\"" > "$out_sel"
			;;
		S)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			tags="$(ui_checklist "Zapret: секции" "Отметьте секции для теста" 22 90 14 "$@" || true)"
			[ -n "${tags:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$out_sel"
				return 1
			}
			: > "$out_sel"
			for tag in $tags; do
				eval "printf '%s\n' \"\${TSEC_$tag}\"" >> "$out_sel"
			done
			;;
		*)
			rm -f "$tmp_on" "$tmp_off" "$out_sel"
			return 1
			;;
	esac

	rm -f "$tmp_on" "$tmp_off"
	[ -s "$out_sel" ] || {
		rm -f "$out_sel"
		return 1
	}
	printf '%s\n' "$out_sel"
}

test_apply_mutex_for_candidate() {
	candidate="$1"
	host_file="$(test_host_file_for_section_profile "$candidate")"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		hf="$(test_host_file_for_section_profile "$section")"
		if [ "$hf" = "$host_file" ]; then
			if [ "$section" = "$candidate" ]; then
				test_set_enabled_profile "$section" 1
			else
				test_set_enabled_profile "$section" 0
			fi
		fi
	done <<EOF
$(zapret_iter_sections)
EOF
}

run_mode_strategy_switch() {
	list_all="$(mktemp)"
	zapret_iter_sections > "$list_all"
	[ -s "$list_all" ] || {
		rm -f "$list_all"
		if [ "${TEST_YES:-0}" -eq 1 ]; then
			printf '%s\n' "В профиле нет секций zapret."
		else
			ui_msgbox "Zapret: тест" "В профиле нет секций zapret."
		fi
		return 0
	}

	if [ "${TEST_YES:-0}" -eq 1 ]; then
		sel_file="$list_all"
		list_all=""
	else
		TEST_CONF_FN=profile
		sel_file="$(test_pick_sections_from_list "$list_all" "Профиль: перебор стратегий" 0)" || {
			rm -f "$list_all"
			return 0
		}
		rm -f "$list_all"
	fi

	# Optional scope: youtube-only / others-only.
	if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ] || [ "${TEST_OTHERS_ONLY:-0}" -eq 1 ]; then
		scoped="$(mktemp)"
		test_filter_sections_file_scope "$sel_file" "$scoped"
		rm -f "$sel_file"
		sel_file="$scoped"
		if [ ! -s "$sel_file" ]; then
			rm -f "$sel_file"
			if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ]; then
				printf '%s\n' "Нет youtube/google секций для перебора."
			else
				printf '%s\n' "Нет не-YouTube секций для перебора."
			fi
			return 0
		fi
	fi

	n="$(grep -c . "$sel_file" || true)"
	if ! test_confirm "Zapret: перебор стратегий" \
"Кандидатов: $n

Для каждой: временно OFF все секции с тем же HOST_FILE, ON только кандидат → apply+restart →
проверка daemons (как LuCI Запущено [N/M] + missing fake) → только потом curl.
YouTube: ответы с роутера (home/watch + thumb + CDN generate_204); videoplayback не проверяем. Видео на ПК — вручную.
В конце — восстановление ENABLED и apply.

Продолжить?"; then
		rm -f "$sel_file"
		return 0
	fi

	TEST_SNAP="$(mktemp)"
	test_snapshot_all_profile "$TEST_SNAP"
	TEST_RESTORED=0
	trap 'test_cleanup_trap' EXIT INT TERM

	results="$(mktemp)"
	: > "$results"
	domains_tmp="$(mktemp)"

	# One CDN discover seed for youtube candidates; each suite refreshes playback URL.
	YT_CACHE=""
	need_yt=0
	while IFS= read -r s; do
		[ -n "$s" ] || continue
		hf="$(test_host_file_for_section_profile "$s" 2>/dev/null || true)"
		if zapret_probe_youtube_target_p "$s" "$hf"; then
			need_yt=1
			break
		fi
	done <"$sel_file"
	if [ "$need_yt" -eq 1 ]; then
		YT_CACHE="$(mktemp -d)"
		export XFREE_ZAPRET_YT_CDN_CACHE="$YT_CACHE"
		printf 'YouTube: InnerTube CDN host (seed; suite uses generate_204)…\n'
		zapret_probe_youtube_discover_cdn >/dev/null 2>&1 || true
	fi

	printf '\n=== Zapret: перебор стратегий ===\n\n' >/dev/tty 2>/dev/null || true
	idx=0
	total_n="$n"
	while IFS= read -r candidate; do
		[ -n "$candidate" ] || continue
		idx=$((idx + 1))
		printf '\n[%s/%s] кандидат: %s (HOST_FILE=%s)\n' \
			"$idx" "$total_n" "$candidate" "$(test_host_file_for_section_profile "$candidate")"
		pre="$(test_section_static_preflight "$candidate" || true)"
		case "$pre" in
			OK*) ;;
			*)
				printf '→ %s (пропуск apply/curl — поправьте стратегию)\n' "$pre"
				printf '%s\t0\t0\t%s\n' "$candidate" "$pre" >> "$results"
				continue
				;;
		esac
		test_apply_mutex_for_candidate "$candidate"
		if ! test_apply_runtime; then
			printf '%s\t0\t0\tFAIL_APPLY\n' "$candidate" >> "$results"
			printf '→ FAIL_APPLY\n'
			continue
		fi
		health="$(test_daemon_health_gate || true)"
		health="$(printf '%s\n' "$health" | head -n1)"
		case "$health" in
			OK*)
				printf '  daemons: %s\n' "$health"
				;;
			*)
				printf '→ %s (пропуск curl — сервис/стратегия не поднялись)\n' "$health"
				printf '%s\t0\t0\t%s\n' "$candidate" "$health" >> "$results"
				continue
				;;
		esac
		summary="$(test_probe_capture_summary test_probe_section "$candidate" "$domains_tmp" profile)"
		ok="$(printf '%s' "$summary" | awk '{print $1}')"
		tot="$(printf '%s' "$summary" | awk '{print $2}')"
		ytv="$(printf '%s' "$summary" | awk '{print $3}')"
		ok="${ok:-0}"
		tot="${tot:-0}"
		host_file="$(test_host_file_for_section_profile "$candidate" 2>/dev/null || true)"
		verdict="$(test_probe_verdict "$candidate" "$host_file" "$ok" "$tot" "$ytv")"
		printf '%s\t%s\t%s\t%s\n' "$candidate" "$ok" "$tot" "$verdict" >> "$results"
		printf '→ %s OK=%s/%s\n' "$verdict" "$ok" "$tot"
	done < "$sel_file"

	[ -n "$YT_CACHE" ] && rm -rf "$YT_CACHE"
	unset XFREE_ZAPRET_YT_CDN_CACHE

	info "восстановление исходных ENABLED…"
	test_restore_snapshot_profile "$TEST_SNAP"
	test_apply_runtime || true
	TEST_RESTORED=1
	trap - EXIT INT TERM

	report="$(mktemp)"
	{
		printf 'Перебор стратегий (профиль)\n\n'
		printf '%-24s %6s %6s %s\n' "SECTION" "OK" "TOTAL" "RESULT"
		printf '%s\n' "------------------------------------------------"
		sort -t"$(printf '\t')" -k2,2nr -k1,1 "$results" | while IFS="$(printf '\t')" read -r s ok tot v; do
			printf '%-24s %6s %6s %s\n' "$s" "$ok" "$tot" "$v"
		done
		if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ] || [ "${need_yt:-0}" -eq 1 ]; then
			printf '\nYouTube: PASS = есть ответы (страница/thumb/CDN).\n'
			printf 'Воспроизведение видео проверьте с компьютера (LAN).\n'
		fi
	} > "$report"
	if [ "${TEST_YES:-0}" -eq 1 ]; then
		cat "$report"
		printf '\n'
	else
		ui_show_textbox "Zapret: результаты перебора" "$report" 28 100
	fi

	best="$(awk -F'\t' '$4=="PASS"' "$results" | sort -t"$(printf '\t')" -k2,2nr -k1,1 | head -n1 | cut -f1)"
	if [ -n "${best:-}" ] && [ "${TEST_YES:-0}" -eq 0 ]; then
		if ui_confirm "Zapret: активировать лучшую?" \
"Лучшая PASS: $best

Включить её и выключить остальные с тем же HOST_FILE?"; then
			test_apply_mutex_for_candidate "$best"
			test_apply_runtime || true
			ui_msgbox "Zapret: тест" "Активирована секция: $best"
		fi
	elif [ -n "${best:-}" ] && [ "${TEST_YES:-0}" -eq 1 ]; then
		printf 'best_pass=%s (not activated; re-run without --yes to apply)\n' "$best"
	fi

	rm -f "$sel_file" "$results" "$domains_tmp" "$report" "$TEST_SNAP"
	TEST_SNAP=""
}

run_mode_applied_state() {
	state_root="$(zapret_state_sections_root)"
	if [ ! -d "$state_root" ]; then
		ui_msgbox "Zapret: тест" "Нет применённого state:
$state_root

Сначала примените профиль (Zapret → Применить)."
		return 0
	fi

	list_all="$(mktemp)"
	zapret_iter_state_sections > "$list_all"
	if [ ! -s "$list_all" ]; then
		rm -f "$list_all"
		ui_msgbox "Zapret: тест" "В state нет секций:
$state_root"
		return 0
	fi

	tmp_on="$(mktemp)"
	tmp_off="$(mktemp)"
	: > "$tmp_on"
	: > "$tmp_off"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		st="$(test_enabled_status_from_conf "$(test_conf_path_state "$section")")"
		if [ "$st" = "ON" ]; then
			printf '%s\n' "$section" >> "$tmp_on"
		else
			printf '%s\n' "$section" >> "$tmp_off"
		fi
	done < "$list_all"
	rm -f "$list_all"

	if [ ! -s "$tmp_on" ] && [ ! -s "$tmp_off" ]; then
		rm -f "$tmp_on" "$tmp_off"
		ui_msgbox "Zapret: тест" "В state нет секций:
$state_root"
		return 0
	fi

	set -- \
		"E" "Все ENABLED в state" \
		"A" "Все секции в state" \
		"S" "Несколько (checklist)"
	idx=1
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		set -- "$@" "$idx" "[ON] $section"
		eval "TSEC_$idx='$section'"
		idx=$((idx + 1))
	done < "$tmp_on"
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		set -- "$@" "$idx" "[OFF] $section"
		eval "TSEC_$idx='$section'"
		idx=$((idx + 1))
	done < "$tmp_off"
	set -- "$@" "0" "Назад"

	choice="$(ui_menu "Zapret: применённые" "Какую секцию проверить?
ENABLED сверху, дальше остальные из state." 22 90 14 "$@" || true)"
	[ -n "${choice:-}" ] || {
		rm -f "$tmp_on" "$tmp_off"
		return 0
	}

	sel_file="$(mktemp)"
	case "$choice" in
		E)
			cat "$tmp_on" > "$sel_file"
			;;
		A)
			cat "$tmp_on" "$tmp_off" > "$sel_file"
			;;
		S)
			set --
			idx=1
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[ON] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_on"
			while IFS= read -r section; do
				[ -n "$section" ] || continue
				set -- "$@" "$idx" "[OFF] $section" "OFF"
				eval "TSEC_$idx='$section'"
				idx=$((idx + 1))
			done < "$tmp_off"
			tags="$(ui_checklist "Zapret: секции state" "Отметьте секции для проверки" 22 90 14 "$@" || true)"
			[ -n "${tags:-}" ] || {
				rm -f "$tmp_on" "$tmp_off" "$sel_file"
				return 0
			}
			: > "$sel_file"
			for tag in $tags; do
				eval "printf '%s\n' \"\${TSEC_$tag}\"" >> "$sel_file"
			done
			;;
		0)
			rm -f "$tmp_on" "$tmp_off" "$sel_file"
			return 0
			;;
		*)
			eval "printf '%s\n' \"\${TSEC_$choice}\"" > "$sel_file"
			;;
	esac
	rm -f "$tmp_on" "$tmp_off"
	[ -s "$sel_file" ] || {
		rm -f "$sel_file"
		ui_msgbox "Zapret: тест" "Нет секций для проверки."
		return 0
	}

	n="$(grep -c . "$sel_file" || true)"
	if [ "$n" = "1" ]; then
		_one="$(head -n1 "$sel_file")"
		_confirm_body="Секция: $_one

Runtime не меняется (без apply/restart).
Curl: fqdn.d из state; YouTube — media-suite (home/watch/превью/CDN).

Продолжить?"
	else
		_confirm_body="Секций: $n

Runtime не меняется (без apply/restart).
Curl: fqdn.d из state; YouTube — media-suite (home/watch/превью/CDN).

Продолжить?"
	fi
	if ! test_confirm "Zapret: проверка state" "$_confirm_body"; then
		rm -f "$sel_file"
		return 0
	fi

	results="$(mktemp)"
	domains_tmp="$(mktemp)"
	: > "$results"

	printf '\n=== Zapret: проверка применённых (state) ===\n\n' >/dev/tty 2>/dev/null || true
	idx=0
	while IFS= read -r section; do
		[ -n "$section" ] || continue
		idx=$((idx + 1))
		printf '\n[%s/%s] %s\n' "$idx" "$n" "$section"
		summary="$(test_probe_capture_summary test_probe_section "$section" "$domains_tmp" state)"
		ok="$(printf '%s' "$summary" | awk '{print $1}')"
		tot="$(printf '%s' "$summary" | awk '{print $2}')"
		ytv="$(printf '%s' "$summary" | awk '{print $3}')"
		ok="${ok:-0}"
		tot="${tot:-0}"
		host_file="$(test_host_file_for_section_state "$section" 2>/dev/null || true)"
		verdict="$(test_probe_verdict "$section" "$host_file" "$ok" "$tot" "$ytv")"
		printf '%s\t%s\t%s\t%s\n' "$section" "$ok" "$tot" "$verdict" >> "$results"
		printf '→ %s OK=%s/%s\n' "$verdict" "$ok" "$tot"
	done < "$sel_file"

	report="$(mktemp)"
	{
		printf 'Проверка применённых (state)\n\n'
		printf '%-24s %6s %6s %s\n' "SECTION" "OK" "TOTAL" "RESULT"
		printf '%s\n' "------------------------------------------------"
		sort -t"$(printf '\t')" -k2,2nr -k1,1 "$results" | while IFS="$(printf '\t')" read -r s ok tot v; do
			printf '%-24s %6s %6s %s\n' "$s" "$ok" "$tot" "$v"
		done
	} > "$report"
	ui_show_textbox "Zapret: результаты state" "$report" 28 100

	rm -f "$sel_file" "$results" "$domains_tmp" "$report"
}

test_current_conf_path() {
	section="$1"
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		test_conf_path_state "$section"
	else
		test_conf_path_profile "$section"
	fi
}

test_current_fqdn_dir() {
	section="$1"
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		test_fqdn_dir_state "$section"
	else
		test_fqdn_dir_profile "$section"
	fi
}

test_iter_current_sections() {
	if [ "$TEST_CURRENT_SRC" = "state" ]; then
		zapret_iter_state_sections
	else
		zapret_iter_sections
	fi
}

run_mode_current_config() {
	TEST_CURRENT_SRC="$TEST_SOURCE"
	if [ "$TEST_CURRENT_SRC" = "auto" ]; then
		if [ -d "$(zapret_state_sections_root)" ]; then
			TEST_CURRENT_SRC="state"
		else
			TEST_CURRENT_SRC="profile"
		fi
	fi

	if [ "$TEST_CURRENT_SRC" = "state" ] && [ ! -d "$(zapret_state_sections_root)" ]; then
		printf '%s\n' "Нет применённого state: $(zapret_state_sections_root)"
		printf '%s\n' "Сначала: xft → Zapret → Применить списки."
		return 1
	fi

	list_all="$(mktemp)"
	test_iter_current_sections >"$list_all"
	if [ ! -s "$list_all" ]; then
		rm -f "$list_all"
		printf '%s\n' "Нет секций ($TEST_CURRENT_SRC)."
		return 1
	fi

	if [ "$TEST_PRINT_HOSTS" -ne 1 ]; then
		_limit_label="$PROBE_LIMIT"
		case "$PROBE_LIMIT" in
			''|0|all|ALL) _limit_label='all' ;;
		esac
		printf '=== Zapret: текущая конфигурация (%s) ===\n' "$TEST_CURRENT_SRC"
		printf 'probe https://FQDN  family=%s  timeout=%ss/%ss  limit=%s/section\n' \
			"${XFREE_ZAPRET_TEST_IP_FAMILY:-4}" \
			"$XFREE_ZAPRET_TEST_CONNECT_TIMEOUT" \
			"$XFREE_ZAPRET_TEST_MAX_TIME" \
			"$_limit_label"
	health="$(zapret_daemon_health_summary 2>/dev/null || true)"
	if [ -n "$health" ]; then
		printf 'daemons: %s\n' "$health"
		case "$health" in
			OK*) ;;
			*)
				printf 'предупреждение: daemons не healthy — curl-пробы мало информативны; смотрите стратегию/logread.\n'
				snippet="$(zapret_daemon_log_snippet 2>/dev/null || true)"
				[ -n "$snippet" ] && printf '%s\n' "$snippet" | sed 's/^/  /' | head -n 16
				;;
		esac
	elif pidof nfqws >/dev/null 2>&1 || pidof nfqws2 >/dev/null 2>&1; then
		printf 'nfqws: running\n'
	else
		printf 'nfqws: not found (пробы всё равно идут)\n'
	fi
		printf '\n'
	fi

	host_cache="$(mktemp)"
	sec_fp_cache="$(mktemp)"
	: >"$host_cache"
	: >"$sec_fp_cache"
	sec_pass=0
	sec_fail=0
	sec_skip=0
	host_ok=0
	host_fail=0
	any_fail=0

	while IFS= read -r section; do
		[ -n "$section" ] || continue
		conf="$(test_current_conf_path "$section")"
		st="$(test_enabled_status_from_conf "$conf")"
		[ "$st" = "ON" ] || continue

		if [ "$TEST_CURRENT_SRC" = "state" ]; then
			host_file="$(test_host_file_for_section_state "$section" 2>/dev/null || true)"
		else
			host_file="$(test_host_file_for_section_profile "$section" 2>/dev/null || true)"
		fi

		if ! test_section_in_scope "$section" "$host_file"; then
			continue
		fi

		# YouTube / google hostlist: media suite (home, watch, thumbs, CDN).
		if zapret_probe_youtube_target_p "$section" "$host_file"; then
			if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
				zapret_probe_youtube_collect_urls | while IFS='|' read -r _lab _url; do
					[ -n "${_url:-}" ] || continue
					printf '%s\t%s\n' "$section" "$_url"
				done
				continue
			fi
			printf '[%s] (YouTube media suite)\n' "$section"
			sec_fp='youtube-media-suite'
			prev_same="$(awk -F'\t' -v fp="$sec_fp" '$1==fp { print $2 "\t" $3 "\t" $4; exit }' "$sec_fp_cache")"
			if [ -n "$prev_same" ]; then
				prev_sec="$(printf '%s' "$prev_same" | cut -f1)"
				prev_ok="$(printf '%s' "$prev_same" | cut -f2)"
				prev_tot="$(printf '%s' "$prev_same" | cut -f3)"
				printf '  SKIP same YouTube suite as %s (%s/%s cached)\n\n' "$prev_sec" "$prev_ok" "$prev_tot"
				verdict="$(test_probe_verdict "$section" "$host_file" "$prev_ok" "$prev_tot")"
				if [ "$verdict" = "PASS" ]; then
					sec_pass=$((sec_pass + 1))
				else
					sec_fail=$((sec_fail + 1))
					any_fail=1
				fi
				continue
			fi
			yt_out="$(mktemp)"
			zapret_probe_youtube_run_suite | tee "$yt_out"
			summary="$(tail -n1 "$yt_out")"
			rm -f "$yt_out"
			sok="$(printf '%s' "$summary" | awk '{print $1}')"
			stot="$(printf '%s' "$summary" | awk '{print $2}')"
			ytv="$(printf '%s' "$summary" | awk '{print $3}')"
			sok="${sok:-0}"
			stot="${stot:-0}"
			printf '%s\t%s\t%s\t%s\n' "$sec_fp" "$section" "$sok" "$stot" >>"$sec_fp_cache"
			host_ok=$((host_ok + sok))
			host_fail=$((host_fail + stot - sok))
			verdict="$(test_probe_verdict "$section" "$host_file" "$sok" "$stot" "$ytv")"
			if [ "$verdict" = "PASS" ]; then
				printf '  → PASS %s/%s\n\n' "$sok" "$stot"
				sec_pass=$((sec_pass + 1))
			else
				printf '  → FAIL %s/%s\n\n' "$sok" "$stot"
				sec_fail=$((sec_fail + 1))
				any_fail=1
			fi
			continue
		fi

		hosts_tmp="$(mktemp)"
		zapret_probe_collect_fqdn_dir "$(test_current_fqdn_dir "$section")" "$PROBE_LIMIT" "$section" >"$hosts_tmp"
		if [ ! -s "$hosts_tmp" ]; then
			rm -f "$hosts_tmp"
			if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
				continue
			fi
			printf '[%s]\n' "$section"
			printf '  SKIP no curlable FQDN\n\n'
			sec_skip=$((sec_skip + 1))
			continue
		fi
		if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
			while IFS= read -r h; do
				[ -n "$h" ] || continue
				printf '%s\t%s\n' "$section" "$h"
			done <"$hosts_tmp"
			rm -f "$hosts_tmp"
			continue
		fi
		printf '[%s]\n' "$section"
		sec_fp="$(sort -u "$hosts_tmp" | cksum 2>/dev/null | awk '{print $1}')"
		[ -n "$sec_fp" ] || sec_fp="$(sort -u "$hosts_tmp" | wc -c | awk '{print $1}')"
		prev_same="$(awk -F'\t' -v fp="$sec_fp" '$1==fp { print $2 "\t" $3 "\t" $4; exit }' "$sec_fp_cache")"
		if [ -n "$prev_same" ]; then
			prev_sec="$(printf '%s' "$prev_same" | cut -f1)"
			prev_ok="$(printf '%s' "$prev_same" | cut -f2)"
			prev_tot="$(printf '%s' "$prev_same" | cut -f3)"
			printf '  SKIP same hosts as %s (%s/%s cached)\n\n' "$prev_sec" "$prev_ok" "$prev_tot"
			if [ "${prev_ok:-0}" -gt 0 ] 2>/dev/null; then
				sec_pass=$((sec_pass + 1))
			else
				sec_fail=$((sec_fail + 1))
				any_fail=1
			fi
			rm -f "$hosts_tmp"
			continue
		fi
		sok=0
		stot=0
		test_probe_hosts_parallel_cached "$hosts_tmp" "$host_cache"
		sok="${TEST_HOST_OK:-0}"
		stot="${TEST_HOST_TOT:-0}"
		rm -f "$hosts_tmp"
		printf '%s\t%s\t%s\t%s\n' "$sec_fp" "$section" "$sok" "$stot" >>"$sec_fp_cache"
		if [ "$sok" -gt 0 ]; then
			printf '  → PASS %s/%s\n\n' "$sok" "$stot"
			sec_pass=$((sec_pass + 1))
		else
			printf '  → FAIL %s/%s\n\n' "$sok" "$stot"
			sec_fail=$((sec_fail + 1))
			any_fail=1
		fi
	done <"$list_all"
	rm -f "$list_all" "$host_cache" "$sec_fp_cache"

	if [ "$TEST_PRINT_HOSTS" -eq 1 ]; then
		return 0
	fi

	printf '---\n'
	printf 'UNIQUE HOSTS  OK=%s FAIL=%s\n' "$host_ok" "$host_fail"
	printf 'SECTIONS      PASS=%s FAIL=%s SKIP=%s\n' "$sec_pass" "$sec_fail" "$sec_skip"
	if [ "$sec_pass" -eq 0 ] && [ "$sec_fail" -eq 0 ]; then
		printf 'Нет ENABLED-секций с curlable FQDN.\n'
		return 1
	fi
	[ "$any_fail" -eq 0 ]
}

run_mode_tcp1620() {
	suite="$SCRIPT_DIR/files/dpi-tcp-16-20-suite.tsv"
	if [ ! -f "$suite" ]; then
		printf '%s\n' "Нет suite: $suite" >&2
		return 1
	fi
	if ! test_confirm "Zapret: DPI TCP 16-20" \
"Лёгкая проверка на роутере (curl): alive HEAD + POST ~64 KiB.

Эталонный браузерный чекер (не ставим dpi-ch ~19MB):
https://hyperion-cs.github.io/dpi-checkers/ru/tcp-16-20
Репозиторий: https://github.com/hyperion-cs/dpi-checkers

Не меняет zapret/NFQWS.

Продолжить?"; then
		return 0
	fi
	printf 'Ref: https://hyperion-cs.github.io/dpi-checkers/ru/tcp-16-20\n\n'
	zapret_probe_tcp1620_run_suite "$suite"
}

usage() {
	cat <<EOF
Использование:
  $(basename "$0") --current [--yes] [--youtube-only|--others-only] [--print-hosts] [--source auto|state|profile]
  $(basename "$0") --strategy [--yes] [--youtube-only|--others-only]
  $(basename "$0") --tcp-16-20 [--yes]
  $(basename "$0")   # интерактивное меню

Режимы (взаимоисключающие):
  --current       текущие ENABLED-секции (state/profile), без apply
  --strategy      перебор стратегий профиля (mutex HOST_FILE + apply/restore;
                  до curl: daemons N/M + missing fake → FAIL_DAEMON/FAIL_STATIC)
  --tcp-16-20     лёгкий DPI TCP 16-20 (curl, parallel=${XFREE_ZAPRET_TCP1620_PARALLEL:-6}); эталон:
                  https://hyperion-cs.github.io/dpi-checkers/ru/tcp-16-20
  --youtube-only  только youtube_*/google HOST_FILE
  --others-only   все секции кроме YouTube/google
  --yes           без подтверждений (меню / SSH)
  --print-hosts   только список FQDN/URL (--current)
  --source        auto|state|profile (только --current)

YouTube PASS = ответы с роутера: page + thumb + CDN generate_204.
Videoplayback с роутера не проверяем; видео — с компьютера (LAN).
EOF
}

main() {
	while [ "$#" -gt 0 ]; do
		case "$1" in
			--current) TEST_MODE_CURRENT=1 ;;
			--strategy) TEST_MODE_STRATEGY=1 ;;
			--tcp-16-20|--tcp1620) TEST_MODE_TCP1620=1 ;;
			--youtube-only|--youtube) TEST_YOUTUBE_ONLY=1 ;;
			--others-only|--others|--no-youtube) TEST_OTHERS_ONLY=1 ;;
			--lan-confirm)
				# deprecated no-op (раньше спрашивали ПК; теперь только note)
				;;
			--yes) TEST_YES=1 ;;
			--print-hosts)
				TEST_PRINT_HOSTS=1
				TEST_MODE_CURRENT=1
				;;
			--source)
				shift
				TEST_SOURCE="${1:-auto}"
				;;
			-h|--help)
				usage
				exit 0
				;;
			*)
				printf 'Неизвестный параметр: %s\n' "$1" >&2
				usage >&2
				exit 1
				;;
		esac
		shift
	done

	modes=$((TEST_MODE_CURRENT + TEST_MODE_STRATEGY + TEST_MODE_TCP1620))
	if [ "$modes" -gt 1 ]; then
		printf 'Укажите только один режим: --current | --strategy | --tcp-16-20\n' >&2
		exit 1
	fi
	if [ "${TEST_YOUTUBE_ONLY:-0}" -eq 1 ] && [ "${TEST_OTHERS_ONLY:-0}" -eq 1 ]; then
		printf 'Нельзя вместе: --youtube-only и --others-only\n' >&2
		exit 1
	fi

	if [ "$TEST_MODE_TCP1620" -eq 1 ]; then
		if zapret_is_profile_generator_host_lists; then
			test_die_host
		fi
		if ! command -v curl >/dev/null 2>&1; then
			printf '%s\n' "Нужен curl на роутере." >&2
			exit 1
		fi
		run_mode_tcp1620
		return "$?"
	fi

	if [ "$TEST_MODE_STRATEGY" -eq 1 ]; then
		if zapret_is_profile_generator_host_lists; then
			test_die_host
		fi
		if ! command -v curl >/dev/null 2>&1; then
			printf '%s\n' "Нужен curl на роутере." >&2
			exit 1
		fi
		if [ "$TEST_YES" -eq 0 ]; then
			ui_init
			ui_trap_cleanup_on_exit
		fi
		run_mode_strategy_switch
		return "$?"
	fi

	if [ "${TEST_MODE_CURRENT:-0}" -eq 1 ]; then
		if [ "$TEST_PRINT_HOSTS" -eq 0 ]; then
			if zapret_is_profile_generator_host_lists; then
				test_die_host
			fi
			if ! command -v curl >/dev/null 2>&1; then
				printf '%s\n' "Нужен curl на роутере." >&2
				exit 1
			fi
		fi
		run_mode_current_config
		return "$?"
	fi

	ui_init
	ui_trap_cleanup_on_exit

	if zapret_is_profile_generator_host_lists; then
		test_die_host
	fi

	if ! command -v curl >/dev/null 2>&1; then
		ui_msgbox "Zapret: тест" "Нужен curl на роутере."
		exit 1
	fi

	while true; do
		mode="$(ui_menu "Zapret: тест секций" "YouTube и остальные — отдельно" 18 84 12 \
			"1" "YouTube: текущие ENABLED" \
			"2" "Остальные: текущие ENABLED" \
			"3" "YouTube: перебор стратегий" \
			"4" "Остальные: перебор стратегий" \
			"5" "DPI TCP 16-20" \
			"0" "Назад" || true)"
		case "$mode" in
			1)
				TEST_YOUTUBE_ONLY=1
				TEST_OTHERS_ONLY=0
				_cur_rep="$(mktemp)"
				run_mode_current_config >"$_cur_rep" 2>&1 || true
				ui_show_textbox "Zapret: YouTube (текущие)" "$_cur_rep" 28 100
				rm -f "$_cur_rep"
				;;
			2)
				TEST_YOUTUBE_ONLY=0
				TEST_OTHERS_ONLY=1
				_cur_rep="$(mktemp)"
				run_mode_current_config >"$_cur_rep" 2>&1 || true
				ui_show_textbox "Zapret: остальные (текущие)" "$_cur_rep" 28 100
				rm -f "$_cur_rep"
				;;
			3)
				TEST_YOUTUBE_ONLY=1
				TEST_OTHERS_ONLY=0
				run_mode_strategy_switch
				;;
			4)
				TEST_YOUTUBE_ONLY=0
				TEST_OTHERS_ONLY=1
				run_mode_strategy_switch
				;;
			5)
				_dpi_rep="$(mktemp)"
				run_mode_tcp1620 >"$_dpi_rep" 2>&1 || true
				ui_show_textbox "Zapret: DPI TCP 16-20" "$_dpi_rep" 28 100
				rm -f "$_dpi_rep"
				;;
			*) exit 0 ;;
		esac
	done
}

main "$@"
