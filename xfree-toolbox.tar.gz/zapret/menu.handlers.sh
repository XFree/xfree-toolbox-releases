#!/bin/sh
# Hand-written handlers for cli.run component=custom in zapret/menu.yaml.
# shellcheck shell=sh

zapret_menu_window_title() {
	if [ "${ZAPRET_ENGINE:-zapret}" = "zapret2" ]; then
		printf '%s' "Обход блокировок (Zapret2)"
	else
		printf '%s' "Обход блокировок (Zapret)"
	fi
}

# Как iface_lists_apply_title: только проверка файла очереди, без lib.sh / sha256.
zapret_apply_lists_title() {
	label="Применить списки"
	changed_file="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"
	if [ -s "$changed_file" ]; then
		label="Применить списки *"
	fi
	printf '%s' "$label"
}

# Обновить upstream-источники и применить drift в profiles/ (списки zapret в активном профиле).
zapret_run_upstream_preflight() {
	upstreams_handlers="$ROOT_DIR/upstreams/menu.handlers.sh"
	[ -f "$upstreams_handlers" ] || {
		ui_msgbox "Ошибка" "Не найден:\n$upstreams_handlers"
		return 1
	}

	[ -f "$ROOT_DIR/lib/upstreams.sh" ] && . "$ROOT_DIR/lib/upstreams.sh"
	UPSTREAMS_MODULE_DIR="$ROOT_DIR/upstreams"
	# shellcheck disable=SC1090
	. "$upstreams_handlers"

	update_selected_modules
	check_active_list_updates_one_mode profiles 1
}

zapret_run_all_menu() {
	if ui_bg_task_redirect_if_running "Zapret"; then
		return 0
	fi

	if ! ui_confirm "Выполнить всё" \
"Сначала: обновление upstream и списков в profiles/.
Затем: проверка/установка zapret и полное применение (apply.sh --yes).

Продолжить?"; then
		return 0
	fi

	ui_run_with_output_batch_begin
	zapret_run_upstream_preflight || {
		ui_run_with_output_batch_end "Выполнить всё (zapret)"
		return 0
	}
	run_zapret_script_with_output "Выполнить всё (zapret)" "$ZAPRET_MENU_apply" --yes
	ui_run_with_output_batch_end "Выполнить всё (zapret)"
}

zapret_menu_choice_2() {
	if [ -f "${ZAPRET_MENU_ensure:-}" ]; then
		run_zapret_script_with_output "Zapret: ensure" "$ZAPRET_MENU_ensure" --install-if-missing --upgrade-if-newer
	else
		run_zapret_script_with_output "Zapret: install" "$ZAPRET_MENU_install" --yes
	fi
}

zapret_copy_fake_menu() {
	src="${ZAPRET_SRC_FAKE_DIR:-$ROOT_DIR/zapret/files/fake}"
	dst="${ZAPRET_FAKE_DIR:-/opt/zapret/files/fake}"
	if ! ui_confirm "Скопировать fake-файлы" \
"Источник: $src/*.bin
Назначение: $dst
Одноимённые файлы будут перезаписаны.
Пакетные fake, которых нет в каталоге, не удаляются.
После копирования zapret будет перезапущен.

Продолжить?"; then
		return 0
	fi
	if [ -n "${ZAPRET_MENU_copy_config:-}" ] && [ -f "$ZAPRET_MENU_copy_config" ]; then
		run_zapret_script_with_output "Zapret: copy fake" "$ZAPRET_MENU_copy_config" --fake-only --yes
	else
		ui_msgbox "Ошибка" "Не найден copy-config.sh"
	fi
}
