#!/bin/sh
# shellcheck shell=sh
# Установка/обновление core zapret и apply профиля (--copy-only) для доступа к Cloudflare до iface/WARP.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
load_base_config "$ROOT_DIR"

# Пайплайн шаблонов / Cloudflare-bootstrap всегда nfqws1.
# Zapret2 — только экспертное меню (menu-zapret2.sh экспортирует ZAPRET_ENGINE=zapret2).
export ZAPRET_ENGINE=zapret

ZAPRET_ENSURE_SCRIPT="${ZAPRET_ENSURE_SCRIPT:-$ROOT_DIR/zapret/ensure-zapret.sh}"
ZAPRET_APPLY_SCRIPT="${ZAPRET_APPLY_SCRIPT:-$ROOT_DIR/zapret/apply.sh}"
PROFILE_DIR_ARG="${PROFILE_DIR:-}"
PROFILE_DIR=""

SKIP_IF_PIPELINE=0

usage() {
    cat <<EOF
Usage: $(basename "$0") [--profile-dir DIR] [--skip-if-pipeline-applied]

Ensure zapret core is installed/up-to-date and apply profile zapret config (--copy-only).
Skips when active profile has no zapret/ directory.

  --skip-if-pipeline-applied
      Skip when XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE=1 (уже применён в этом apply-template)
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --profile-dir)
            shift
            [ "$#" -gt 0 ] || die "Не указано значение для --profile-dir"
            PROFILE_DIR_ARG="$1"
            ;;
        --skip-if-pipeline-applied)
            SKIP_IF_PIPELINE=1
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            die "Неизвестный аргумент: $1"
            ;;
    esac
    shift
done

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "$PROFILE_DIR_ARG")"

if [ ! -d "$PROFILE_DIR/zapret" ]; then
    info "zapret bootstrap: пропущен (нет zapret/ в профиле $PROFILE_DIR)"
    exit 0
fi

[ -f "$ZAPRET_ENSURE_SCRIPT" ] || die "Не найден zapret ensure script: $ZAPRET_ENSURE_SCRIPT"
[ -f "$ZAPRET_APPLY_SCRIPT" ] || die "Не найден zapret apply script: $ZAPRET_APPLY_SCRIPT"

if [ "$SKIP_IF_PIPELINE" = "1" ] && [ "${XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE:-0}" = "1" ]; then
    info "zapret bootstrap: пропущен (уже применён в этом пайплайне)"
    exit 0
fi

info "zapret bootstrap: PROFILE_DIR=$PROFILE_DIR"
info "zapret bootstrap: ensure (install/upgrade core)"
sh "$ZAPRET_ENSURE_SCRIPT" --install-if-missing --upgrade-if-newer \
    || die "Не удалось установить/обновить zapret (ensure)"

info "zapret bootstrap: apply (copy-config + restart)"
export PROFILE_DIR
sh "$ZAPRET_APPLY_SCRIPT" --yes --copy-only \
    || die "Не удалось применить zapret (copy-config)"

export XFREE_ZAPRET_PIPELINE_BOOTSTRAP_DONE=1
success "zapret bootstrap: готово"
