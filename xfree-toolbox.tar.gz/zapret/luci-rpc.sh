#!/bin/sh
# shellcheck shell=sh
# Non-interactive Zapret menu actions for LuCI (ubus xfree-toolbox zapretMenu).
# Lists selection lives under Маршруты → Zapret (wizard); this RPC is ops only.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

ACTION="${1:-}"
ARG="${2:-}"

run() {
	_title="$1"
	shift
	printf '=== %s ===\n' "$_title"
	sh "$@"
}

case "$ACTION" in
applyLists)
	run "Zapret: apply lists" "$SCRIPT_DIR/apply-changed-sections.sh"
	;;
ensure)
	run "Zapret: ensure" "$SCRIPT_DIR/ensure-zapret.sh" --install-if-missing --upgrade-if-newer
	;;
apply)
	run "Zapret: apply" "$SCRIPT_DIR/apply.sh" --yes
	;;
portConflicts)
	run "Zapret: port conflicts" "$SCRIPT_DIR/check-port-conflicts.sh"
	;;
testYoutubeCurrent)
	run "Zapret: YouTube (текущие)" "$SCRIPT_DIR/test-sections-access.sh" --current --youtube-only --yes
	;;
testOthersCurrent)
	run "Zapret: остальные (текущие)" "$SCRIPT_DIR/test-sections-access.sh" --current --others-only --yes
	;;
testDpiTcp)
	run "Zapret: DPI TCP 16-20" "$SCRIPT_DIR/test-sections-access.sh" --tcp-16-20 --yes
	;;
copyFake)
	run "Zapret: copy fake" "$SCRIPT_DIR/copy-config.sh" --fake-only --yes
	;;
*)
	printf 'unknown zapretMenu action: %s\n' "${ACTION:-?}" >&2
	exit 1
	;;
esac
