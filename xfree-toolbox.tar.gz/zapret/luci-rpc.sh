#!/bin/sh
# shellcheck shell=sh
# Non-interactive Zapret menu actions for LuCI (ubus xfree-toolbox zapretMenu).
# Lists selection lives under Маршруты → Zapret (wizard); this RPC is ops only.
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

ACTION="${1:-}"
ARG="${2:-}"
PAYLOAD="${3:-}"

# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/background-tasks.sh" ] && . "$ROOT_DIR/lib/background-tasks.sh"

run() {
	_title="$1"
	shift
	printf '=== %s ===\n' "$_title"
	sh "$@"
}

zapret_emit_task_status() {
	_running=0
	_task=""
	_pid=""
	_log=""
	_last_status=""
	_last_exit=""

	if command -v bg_tasks_is_running >/dev/null 2>&1 && bg_tasks_is_running; then
		_running=1
		_task="${BG_TASK_NAME:-}"
		_pid="${BG_TASK_PID:-}"
		_log="${BG_TASK_LOG_FILE:-}"
	elif command -v bg_tasks_read_last_meta >/dev/null 2>&1 && bg_tasks_read_last_meta; then
		_task="${BG_TASK_LAST_NAME:-}"
		_log="${BG_TASK_LAST_LOG_FILE:-}"
		_last_status="${BG_TASK_LAST_STATUS:-}"
		_last_exit="${BG_TASK_LAST_EXIT_CODE:-}"
	fi

	if [ "$_running" -eq 1 ]; then
		printf 'STATUS=running\n'
	elif [ -n "$_last_status" ] || [ -n "$_task" ]; then
		printf 'STATUS=idle\n'
	else
		printf 'STATUS=none\n'
	fi
	[ -n "$_task" ] && printf 'TASK=%s\n' "$_task"
	[ -n "$_pid" ] && printf 'PID=%s\n' "$_pid"
	[ -n "$_log" ] && printf 'LOG=%s\n' "$_log"
	[ -n "$_last_status" ] && printf 'LAST_STATUS=%s\n' "$_last_status"
	[ -n "$_last_exit" ] && printf 'LAST_EXIT=%s\n' "$_last_exit"
	if [ -n "$_log" ] && [ -f "$_log" ]; then
		printf '%s\n' '---'
		tail -n 250 "$_log" 2>/dev/null || true
	fi
}

zapret_start_bg() {
	_task="$1"
	shift
	_runner="$ROOT_DIR/lib/bg-task-run.sh"
	_bg_root="${XFREE_BG_ROOT:-/tmp/xfree-background-tasks}"
	_log="${_bg_root}/${_task}.log"

	mkdir -p "$_bg_root" 2>/dev/null || true
	[ -f "$_runner" ] || {
		printf 'STATUS=failed\nERROR=missing %s\n' "$_runner"
		return 1
	}
	if command -v bg_tasks_is_running >/dev/null 2>&1 && bg_tasks_is_running; then
		printf '=== Задача уже выполняется ===\n'
		printf 'STATUS=already_running\n'
		zapret_emit_task_status
		return 0
	fi

	printf '=== Запуск в фоне: %s ===\n' "$_task"
	printf 'Лог: %s\n\n' "$_log"
	(
		export XFREE_TOOLBOX_ROOT="$ROOT_DIR"
		sh "$_runner" "$_task" --log "$_log" -- env ZAPRET_LUCI_FOREGROUND=1 "$@"
	) >/dev/null 2>&1 &
	sleep 1
	zapret_emit_task_status
}

zapret_want_bg() {
	[ "${ZAPRET_LUCI_FOREGROUND:-}" = "1" ] && return 1
	case "${ACTION:-}" in
	testDpiTcp|testYoutubeCurrent|testOthersCurrent|applyLists|apply|ensure|runAll)
		return 0
		;;
	*)
		return 1
		;;
	esac
}

action_status() {
	_initd="/etc/init.d/zapret"
	[ -x "$_initd" ] || _initd="/etc/init.d/zapret2"
	_running=0
	_installed=0
	if [ -x "$_initd" ]; then
		_installed=1
		if "$_initd" running >/dev/null 2>&1; then
			_running=1
		fi
	fi
	if [ -x /opt/zapret/nfq/nfqws ]; then
		_installed=1
	fi

	_ver=""
	if [ -f /opt/zapret/common/version.txt ]; then
		_ver="$(head -n 1 /opt/zapret/common/version.txt 2>/dev/null | awk '{print $3}' || true)"
	fi
	if [ -z "$_ver" ] && command -v apk >/dev/null 2>&1; then
		_ver="$(apk info zapret 2>/dev/null | head -n 1 | awk '{print $1}' || true)"
	fi
	if [ -z "$_ver" ] && command -v opkg >/dev/null 2>&1; then
		_ver="$(opkg list-installed zapret 2>/dev/null | awk '{print $3}' || true)"
	fi
	[ -n "$_ver" ] || _ver="72"

	_engine="${ZAPRET_ENGINE:-zapret}"
	_changed_file="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"
	_pending=0
	if [ -s "$_changed_file" ]; then
		_pending=1
	fi

	printf 'STATUS|running=%d|installed=%d|version=%s|engine=%s|pending=%d\n' \
		"$_running" "$_installed" "$_ver" "$_engine" "$_pending"

	_sec_root=""
	if [ -d "/etc/xfree-toolbox/zapret/state/sections" ]; then
		_sec_root="/etc/xfree-toolbox/zapret/state/sections"
	elif [ -n "${ROOT_DIR:-}" ] && [ -d "$ROOT_DIR/profiles/default/zapret/sections" ]; then
		_sec_root="$ROOT_DIR/profiles/default/zapret/sections"
	fi

	_order_file=""
	if [ -f "/etc/xfree-toolbox/zapret/state/sections.order" ]; then
		_order_file="/etc/xfree-toolbox/zapret/state/sections.order"
	elif [ -n "$_sec_root" ] && [ -f "$(dirname "$_sec_root")/sections.order" ]; then
		_order_file="$(dirname "$_sec_root")/sections.order"
	fi

	if [ -n "$_sec_root" ] && [ -d "$_sec_root" ]; then
		if [ -f "$_order_file" ]; then
			while IFS= read -r _sname || [ -n "$_sname" ]; do
				_sname="$(printf '%s' "$_sname" | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
				[ -n "$_sname" ] || continue
				[ -d "$_sec_root/$_sname" ] || continue
				_cnt=0
				_hf="$(find "$_sec_root/$_sname" -type f \( -name "*.txt" -o -name "*.lst" \) 2>/dev/null | head -n 1 || true)"
				if [ -n "$_hf" ] && [ -f "$_hf" ]; then
					_cnt="$(grep -c . "$_hf" 2>/dev/null || true)"
				fi
				_en=1
				_cf="$_sec_root/$_sname/config/section.conf"
				if [ -f "$_cf" ]; then
					if grep -q "^ZAPRET_SECTION_ENABLED='0'" "$_cf" 2>/dev/null; then
						_en=0
					fi
				fi
				printf 'SECTION|name=%s|hosts=%d|enabled=%d\n' "$_sname" "$_cnt" "$_en"
			done < "$_order_file"
		else
			for _sdir in "$_sec_root"/*; do
				[ -d "$_sdir" ] || continue
				_sname="$(basename "$_sdir")"
				_cnt=0
				_hf="$(find "$_sdir" -type f \( -name "*.txt" -o -name "*.lst" \) 2>/dev/null | head -n 1 || true)"
				if [ -n "$_hf" ] && [ -f "$_hf" ]; then
					_cnt="$(grep -c . "$_hf" 2>/dev/null || true)"
				fi
				_en=1
				_cf="$_sdir/config/section.conf"
				if [ -f "$_cf" ]; then
					if grep -q "^ZAPRET_SECTION_ENABLED='0'" "$_cf" 2>/dev/null; then
						_en=0
					fi
				fi
				printf 'SECTION|name=%s|hosts=%d|enabled=%d\n' "$_sname" "$_cnt" "$_en"
			done
		fi
	fi
}

if zapret_want_bg; then
	zapret_start_bg "$ACTION" sh "$SCRIPT_DIR/luci-rpc.sh" "$ACTION" "$ARG"
	exit 0
fi

case "$ACTION" in
taskStatus)
	zapret_emit_task_status
	exit 0
	;;
status|summary)
	action_status
	;;
toggleSection)
	_sname="${ARG:-}"
	[ -n "$_sname" ] || { printf 'section name required\n' >&2; exit 1; }
	_target_en=""
	if [ "${_sname#*:}" != "$_sname" ]; then
		_target_en="${_sname#*:}"
		_sname="${_sname%%:*}"
	fi

	_found_cf=""
	if [ -f "/etc/xfree-toolbox/zapret/state/sections/$_sname/config/section.conf" ]; then
		_found_cf="/etc/xfree-toolbox/zapret/state/sections/$_sname/config/section.conf"
	fi

	if [ -z "$_target_en" ]; then
		if [ -n "$_found_cf" ] && grep -q "^ZAPRET_SECTION_ENABLED='0'" "$_found_cf" 2>/dev/null; then
			_target_en=1
		else
			_target_en=0
		fi
	fi

	# Update state
	if [ -f "/etc/xfree-toolbox/zapret/state/sections/$_sname/config/section.conf" ]; then
		_cf="/etc/xfree-toolbox/zapret/state/sections/$_sname/config/section.conf"
		_tmp="${_cf}.tmp.$$"
		awk -v val="$_target_en" '
			BEGIN { set=0 }
			/^ZAPRET_SECTION_ENABLED=/ { print "ZAPRET_SECTION_ENABLED='\''" val "'\''"; set=1; next }
			{ print }
			END { if (set==0) print "ZAPRET_SECTION_ENABLED='\''" val "'\''" }
		' "$_cf" > "$_tmp"
		mv "$_tmp" "$_cf"
	fi

	# Also update profile if exists
	for _pcf in /etc/xfree-toolbox/profiles/*/zapret/sections/"$_sname/config/section.conf" \
	            "$ROOT_DIR/profiles"/*/zapret/sections/"$_sname/config/section.conf"; do
		[ -f "$_pcf" ] || continue
		_tmp="${_pcf}.tmp.$$"
		awk -v val="$_target_en" '
			BEGIN { set=0 }
			/^ZAPRET_SECTION_ENABLED=/ { print "ZAPRET_SECTION_ENABLED='\''" val "'\''"; set=1; next }
			{ print }
			END { if (set==0) print "ZAPRET_SECTION_ENABLED='\''" val "'\''" }
		' "$_pcf" > "$_tmp"
		mv "$_tmp" "$_pcf"
	done

	# Mark changed in zapret-changed-sections.lst
	_chfile="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"
	mkdir -p "$(dirname "$_chfile")"
	touch "$_chfile"
	if ! grep -qx "$_sname" "$_chfile" 2>/dev/null; then
		printf '%s\n' "$_sname" >> "$_chfile"
	fi

	printf 'OK|section=%s|enabled=%s\n' "$_sname" "$_target_en"
	;;
getStrategy)
	_sname="${ARG:-}"
	[ -n "$_sname" ] || { printf 'section name required\n' >&2; exit 1; }
	_tf=""
	if [ -f "/etc/xfree-toolbox/zapret/state/sections/$_sname/config/section.text" ]; then
		_tf="/etc/xfree-toolbox/zapret/state/sections/$_sname/config/section.text"
	elif [ -n "${ROOT_DIR:-}" ] && [ -f "$ROOT_DIR/profiles/default/zapret/sections/$_sname/config/section.text" ]; then
		_tf="$ROOT_DIR/profiles/default/zapret/sections/$_sname/config/section.text"
	fi
	if [ -n "$_tf" ] && [ -f "$_tf" ]; then
		cat "$_tf"
	else
		printf '# section.text not found for %s\n' "$_sname"
	fi
	;;
saveStrategy)
	_sname="${ARG:-}"
	[ -n "$_sname" ] || { printf 'section name required\n' >&2; exit 1; }
	_content="${PAYLOAD:-}"
	if [ -z "$_content" ] && [ ! -t 0 ]; then
		_content="$(cat 2>/dev/null || true)"
	fi
	[ -n "$_content" ] || { printf 'strategy content required\n' >&2; exit 1; }

	# Update state
	if [ -d "/etc/xfree-toolbox/zapret/state/sections/$_sname" ]; then
		mkdir -p "/etc/xfree-toolbox/zapret/state/sections/$_sname/config"
		printf '%s\n' "$_content" > "/etc/xfree-toolbox/zapret/state/sections/$_sname/config/section.text"
	fi

	# Update profile if exists
	for _pdir in /etc/xfree-toolbox/profiles/*/zapret/sections/"$_sname" \
	             "${ROOT_DIR:-/root/xfree-toolbox}/profiles"/*/zapret/sections/"$_sname"; do
		[ -d "$_pdir" ] || continue
		mkdir -p "$_pdir/config"
		printf '%s\n' "$_content" > "$_pdir/config/section.text"
	done

	# Mark changed in zapret-changed-sections.lst
	_chfile="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"
	mkdir -p "$(dirname "$_chfile")"
	touch "$_chfile"
	if ! grep -qx "$_sname" "$_chfile" 2>/dev/null; then
		printf '%s\n' "$_sname" >> "$_chfile"
	fi

	printf 'OK|section=%s|saved=1\n' "$_sname"
	;;
restart)
	run "Zapret: restart" "$SCRIPT_DIR/restart.sh"
	;;
applyLists)
	run "Zapret: apply lists" "$SCRIPT_DIR/apply-changed-sections.sh" --yes
	;;
ensure)
	run "Zapret: ensure" "$SCRIPT_DIR/ensure-zapret.sh" --install-if-missing --upgrade-if-newer
	;;
apply)
	run "Zapret: apply" "$SCRIPT_DIR/apply.sh" --yes
	;;
portConflicts)
	run "Zapret: port conflicts" "$SCRIPT_DIR/check-port-conflicts.sh"
	;;
testYoutubeCurrent)
	run "Zapret: YouTube (текущие)" "$SCRIPT_DIR/test-sections-access.sh" --current --youtube-only --yes
	;;
testOthersCurrent)
	run "Zapret: остальные (текущие)" "$SCRIPT_DIR/test-sections-access.sh" --current --others-only --yes
	;;
testDpiTcp)
	run "Zapret: DPI TCP 16-20" "$SCRIPT_DIR/test-sections-access.sh" --tcp-16-20 --yes
	;;
copyFake)
	run "Zapret: copy fake" "$SCRIPT_DIR/copy-config.sh" --fake-only --yes
	;;
runAll)
	printf '=== Zapret: Выполнить всё ===\n'
	if [ -f "$ROOT_DIR/upstreams/check-upstream-updates.sh" ]; then
		sh "$ROOT_DIR/upstreams/check-upstream-updates.sh" --yes || true
	fi
	sh "$SCRIPT_DIR/ensure-zapret.sh" --install-if-missing --upgrade-if-newer
	sh "$SCRIPT_DIR/apply.sh" --yes
	;;
*)
	printf 'unknown zapretMenu action: %s\n' "${ACTION:-?}" >&2
	exit 1
	;;
esac
