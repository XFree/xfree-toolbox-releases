#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib.sh"
. "$ROOT_DIR/lib/ui.sh"

zapret_ensure_sections_order_file
ORDER_FILE="$(zapret_sections_order_file)"
SECTIONS_ROOT="$(zapret_sections_root)"
CR="$(printf '\r')"
MODE="${1:---whiptail}"

read_key() {
  # shellcheck disable=SC2039
  key="$(dd bs=1 count=1 2>/dev/null < /dev/tty || true)"
  [ -n "$key" ] || return 1
  case "$key" in
    "$(printf '\033')")
      # Read possible escape sequence (arrows / function keys)
      next="$(dd bs=1 count=1 2>/dev/null < /dev/tty || true)"
      [ -n "$next" ] || { printf 'ESC\n'; return 0; }
      if [ "$next" = "[" ]; then
        c3="$(dd bs=1 count=1 2>/dev/null < /dev/tty || true)"
        case "$c3" in
          A) printf 'UP\n' ;;
          B) printf 'DOWN\n' ;;
          1|5|6)
            c4="$(dd bs=1 count=1 2>/dev/null < /dev/tty || true)"
            c5="$(dd bs=1 count=1 2>/dev/null < /dev/tty || true)"
            seq="${c3}${c4}${c5}"
            case "$seq" in
              15~) printf 'F5\n' ;;
              17~) printf 'F6\n' ;;
              5~) printf 'PGUP\n' ;;
              6~) printf 'PGDN\n' ;;
              *) printf 'ESC\n' ;;
            esac
            ;;
          *) printf 'ESC\n' ;;
        esac
      else
        printf 'ESC\n'
      fi
      ;;
    "") return 1 ;;
    "$(printf '\n')"|"$CR") printf 'ENTER\n' ;;
    "+") printf 'PLUS\n' ;;
    "-") printf 'MINUS\n' ;;
    q|Q) printf 'QUIT\n' ;;
    s|S) printf 'SAVE\n' ;;
    j|J) printf 'DOWN\n' ;;
    k|K) printf 'UP\n' ;;
    *) printf 'OTHER\n' ;;
  esac
}

editor_fallback() {
  editor="${EDITOR:-}"
  if [ -z "$editor" ]; then
    if command -v nano >/dev/null 2>&1; then
      editor="nano"
    elif command -v vi >/dev/null 2>&1; then
      editor="vi"
    else
      editor=""
    fi
  fi

  if [ -z "$editor" ]; then
    echo "[-] Не найден редактор (nano/vi). Отредактируйте вручную: $ORDER_FILE" >&2
    exit 1
  fi
  "$editor" "$ORDER_FILE"
  echo "[*] Порядок секций сохранен: $ORDER_FILE"
}

move_up() {
  current="$1"
  pos="$2"
  printf '%s\n' "$current" | awk -v c="$pos" '
    NR==c-1 { a=$0; next }
    NR==c   { print; print a; next }
    { print }
  '
}

move_down() {
  current="$1"
  pos="$2"
  printf '%s\n' "$current" | awk -v c="$pos" '
    NR==c   { a=$0; next }
    NR==c+1 { print; print a; next }
    { print }
  '
}

whiptail_reorder() {
  ui_have_whiptail || editor_fallback
  sel=1
  while true; do
    total="$(printf '%s\n' "$order" | sed '/^$/d' | wc -l | tr -d ' ')"
    [ "$sel" -gt "$total" ] && sel="$total"
    [ "$sel" -lt 1 ] && sel=1

    set --
    i=1
    while IFS= read -r sec; do
      [ -n "$sec" ] || continue
      tag="S$i"
      label="$sec"
      [ "$i" -eq "$sel" ] && label="> $sec"
      set -- "$@" "$tag" "$label"
      i=$((i + 1))
    done <<EOF
$order
EOF

    set -- "$@" \
      "U" "Переместить выше" \
      "D" "Переместить ниже" \
      "W" "Сохранить и выйти" \
      "Q" "Выйти без сохранения"

    UI_MENU_DEFAULT_ITEM="S$sel"
    choice="$(ui_menu "Zapret: sections.order (test)" "Выберите секцию или действие" 22 90 14 "$@" || true)"
    unset UI_MENU_DEFAULT_ITEM

    [ -n "${choice:-}" ] || return 0
    case "$choice" in
      S*)
        sel="${choice#S}"
        ;;
      U)
        if [ "$sel" -gt 1 ]; then
          order="$(move_up "$order" "$sel")"
          sel=$((sel - 1))
        fi
        ;;
      D)
        if [ "$sel" -lt "$total" ]; then
          order="$(move_down "$order" "$sel")"
          sel=$((sel + 1))
        fi
        ;;
      W)
        printf '%s\n' "$order" > "$ORDER_FILE"
        ui_msgbox "Zapret" "Порядок секций сохранен."
        return 0
        ;;
      Q)
        return 0
        ;;
    esac
  done
}

# No TTY: fallback to editor mode.
[ -t 0 ] || editor_fallback
[ -r /dev/tty ] || editor_fallback
[ -w /dev/tty ] || editor_fallback
command -v stty >/dev/null 2>&1 || editor_fallback

found_sections="$(for dir in "$SECTIONS_ROOT"/*; do
  [ -d "$dir" ] || continue
  printf '%s\n' "$(basename "$dir")"
done | sort)"

order_raw="$(tr -d '\r' < "$ORDER_FILE" | sed '/^[[:space:]]*#/d; /^[[:space:]]*$/d')"
order=""

# Keep only existing sections from file.
for sec in $order_raw; do
  printf '%s\n' "$found_sections" | awk -v s="$sec" '$0 == s { found=1 } END { exit(found ? 0 : 1) }' || continue
  order="${order}${order:+
}${sec}"
done

# Append menu-created leftovers only (ORIGIN=manual). Toolbox dirs outside order are scrubbed on apply.
missing="$(printf '%s\n' "$found_sections" | awk -v cur="$order" '
  BEGIN {
    n=split(cur, a, /\n/)
    for (i=1; i<=n; i++) if (a[i] != "") seen[a[i]]=1
  }
  { if ($0 != "" && !seen[$0]) print $0 }
')"
if [ -n "$missing" ]; then
  missing_keep=""
  while IFS= read -r miss; do
    [ -n "${miss:-}" ] || continue
    zapret_section_dir_is_manual "$SECTIONS_ROOT/$miss" || continue
    missing_keep="${missing_keep}${missing_keep:+
}${miss}"
  done <<EOF
$missing
EOF
  [ -n "$missing_keep" ] && order="${order}${order:+
}${missing_keep}"
fi

[ -n "$order" ] || {
  echo "[-] Нет секций для упорядочивания: $SECTIONS_ROOT" >&2
  exit 1
}

if [ "$MODE" = "--whiptail" ]; then
  whiptail_reorder
  exit 0
fi

cursor=1
total="$(printf '%s\n' "$order" | sed '/^$/d' | wc -l | tr -d ' ')"
old_tty="$(stty -g </dev/tty)"
stty -echo -icanon min 1 time 0 </dev/tty
trap 'stty "$old_tty" </dev/tty; printf "\033[0m\033[?25h\n"' EXIT INT TERM

while true; do
  printf '\033[2J\033[H\033[?25l'
  printf 'Zapret: порядок секций (BIOS-style)\n'
  printf 'Клавиши: ↑/↓ выбрать, +/- (или F5/F6, PgUp/PgDn) двигать, Enter/S сохранить, Q выйти\n\n'

  i=1
  printf '%s\n' "$order" | while IFS= read -r sec; do
    [ -n "$sec" ] || continue
    if [ "$i" -eq "$cursor" ]; then
      printf ' > %2s. %s\n' "$i" "$sec"
    else
      printf '   %2s. %s\n' "$i" "$sec"
    fi
    i=$((i + 1))
  done

  key="$(read_key || true)"
  case "${key:-}" in
    UP)
      [ "$cursor" -gt 1 ] && cursor=$((cursor - 1))
      ;;
    DOWN)
      [ "$cursor" -lt "$total" ] && cursor=$((cursor + 1))
      ;;
    PLUS|F5|PGUP)
      if [ "$cursor" -gt 1 ]; then
        order="$(printf '%s\n' "$order" | awk -v c="$cursor" '
          NR==c-1 { a=$0; next }
          NR==c { print; print a; next }
          { print }
        ')"
        cursor=$((cursor - 1))
      fi
      ;;
    MINUS|F6|PGDN)
      if [ "$cursor" -lt "$total" ]; then
        order="$(printf '%s\n' "$order" | awk -v c="$cursor" '
          NR==c { a=$0; next }
          NR==c+1 { print; print a; next }
          { print }
        ')"
        cursor=$((cursor + 1))
      fi
      ;;
    ENTER|SAVE)
      printf '%s\n' "$order" > "$ORDER_FILE"
      printf '\033[2J\033[H'
      echo "[*] Порядок секций сохранен: $ORDER_FILE"
      break
      ;;
    QUIT)
      printf '\033[2J\033[H'
      echo "[*] Отменено. Порядок не изменен."
      break
      ;;
  esac
done
