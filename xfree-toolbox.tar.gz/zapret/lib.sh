#!/bin/sh
# shellcheck shell=sh
set -eu

# Sourced from zapret/*.sh and templates/apply-template.sh. $0 is the caller,
# so never derive zapret paths from dirname $0 (that becomes templates/lib/engine.sh).
if [ -z "${ROOT_DIR:-}" ] || [ ! -f "$ROOT_DIR/lib/common.sh" ]; then
    _zapret_caller_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
    ROOT_DIR="$(CDPATH= cd -- "$_zapret_caller_dir/.." && pwd -P)"
    unset _zapret_caller_dir
fi
ZAPRET_DIR="${ZAPRET_DIR:-$ROOT_DIR/zapret}"
# Keep caller SCRIPT_DIR (templates/ vs zapret/). Only fill if unset.
if [ -z "${SCRIPT_DIR:-}" ]; then
    SCRIPT_DIR="$ZAPRET_DIR"
fi

. "$ROOT_DIR/lib/common.sh"
[ -f "$ROOT_DIR/lib/upstreams.sh" ] && . "$ROOT_DIR/lib/upstreams.sh"

ZAPRET_STATE_ROOT="${XFREE_ZAPRET_ROOT:-/etc/xfree-toolbox/zapret}"
ZAPRET_STATE_DIR="$ZAPRET_STATE_ROOT/state"
ZAPRET_GENERATED_DIR="$ZAPRET_STATE_ROOT/generated"

zapret_profile_dir() {
    common_profile_dir "$ROOT_DIR"
}

zapret_profile_root() {
    printf '%s/zapret\n' "$(zapret_profile_dir)"
}

# shellcheck disable=SC1091
. "$ZAPRET_DIR/lib/engine.sh"
zapret_engine_apply_vars

# Путь к UCI-шаблону zapret в профиле (как в zapret/apply.sh, по умолчанию zapret.template).
zapret_profile_cfg_template_path() {
    name="${PROFILE_CFG_TEMPLATE_NAME:-zapret.template}"
    printf '%s/%s\n' "$(zapret_profile_root)" "$name"
}

# Читает option ... 'value' из файла шаблона; при отсутствии — default_val.
zapret_read_profile_template_option() {
    option_name="$1"
    default_val="${2:-0}"
    tmpl="$(zapret_profile_cfg_template_path)"
    [ -f "$tmpl" ] || {
        printf '%s\n' "$default_val"
        return 0
    }
    val="$(awk -v name="$option_name" '
        $1 == "option" && $2 == name {
            value=$0
            sub(/^[[:space:]]*option[[:space:]]+[^[:space:]]+[[:space:]]+'\''/, "", value)
            sub(/'\''[[:space:]]*$/, "", value)
            print value
            exit
        }
    ' "$tmpl")"
    val="$(printf '%s' "${val:-}" | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
    [ -n "$val" ] || val="$default_val"
    printf '%s\n' "$val"
}

zapret_sections_root() {
    printf '%s/sections\n' "$(zapret_profile_root)"
}

zapret_sections_order_file() {
    printf '%s/sections.order\n' "$(zapret_profile_root)"
}

zapret_state_sections_root() {
    printf '%s/sections\n' "$ZAPRET_STATE_DIR"
}

zapret_state_sections_order_file() {
    printf '%s/sections.order\n' "$ZAPRET_STATE_DIR"
}

# Итерация секций из применённого state (/etc/xfree-toolbox/zapret/state).
zapret_iter_state_sections() {
    sections_root="$(zapret_state_sections_root)"
    [ -d "$sections_root" ] || return 0

    order_file="$(zapret_state_sections_order_file)"
    tmp_found="$(mktemp)"
    tmp_order="$(mktemp)"

    for dir in "$sections_root"/*; do
        [ -d "$dir" ] || continue
        basename "$dir"
    done | sort -u > "$tmp_found"

    if [ -f "$order_file" ]; then
        tr -d '\r' < "$order_file" | sed '/^[[:space:]]*#/d; /^[[:space:]]*$/d' > "$tmp_order"
    else
        : > "$tmp_order"
    fi

    awk '
        FNR == NR {
            if ($0 != "") order[++n] = $0
            next
        }
        {
            if ($0 != "") found[$0] = 1
        }
        END {
            for (i = 1; i <= n; i++) {
                s = order[i]
                if (s in found) {
                    print s
                    printed[s] = 1
                }
            }
        }
    ' "$tmp_order" "$tmp_found"
    awk '
        FNR == NR {
            if ($0 != "") order[$0] = 1
            next
        }
        ($0 != "" && !($0 in order)) { print }
    ' "$tmp_order" "$tmp_found" | sort

    rm -f "$tmp_found" "$tmp_order"
}

# HOST_FILE из section.conf без mkdir; пусто → дефолтный паттерн xfree-<slug>-hosts.txt.
zapret_section_host_file_quick() {
    conf_path="$1"
    section_slug="$2"
    host_file=""
    if [ -f "$conf_path" ]; then
        host_file="$(awk -F"'" '/^ZAPRET_SECTION_HOST_FILE=/ { print $2; exit }' "$conf_path")"
    fi
    if [ -z "${host_file:-}" ]; then
        host_file="xfree-${section_slug}-hosts.txt"
    fi
    printf '%s\n' "$host_file"
}

zapret_default_sections_order() {
    cat <<'EOF'
google
googlevideo
user
cust1
fb-wa
telegram
discord
roblox
dot-tls
cloud-front-flare
EOF
}

zapret_ensure_sections_order_file() {
    order_file="$(zapret_sections_order_file)"
    [ -f "$order_file" ] && return 0
    mkdir -p "$(dirname -- "$order_file")"
    zapret_default_sections_order > "$order_file"
}

zapret_ensure_section_dirs() {
    section="$1"
    section_slug="$(common_normalize_token "$section")"
    [ -n "$section_slug" ] || die "Некорректное имя секции zapret: $section"

    section_dir="$(zapret_sections_root)/$section_slug"
    mkdir -p "$section_dir/config" "$section_dir/fqdn.d" "$section_dir/prefixes.d" "$section_dir/fqdn.exclude.d"
    # Backward compatibility: migrate legacy exclude.d -> fqdn.exclude.d once.
    if [ -d "$section_dir/exclude.d" ]; then
        for f in "$section_dir/exclude.d"/*.lst; do
            [ -f "$f" ] || continue
            cp -f "$f" "$section_dir/fqdn.exclude.d/"
        done
        rm -rf "$section_dir/exclude.d" 2>/dev/null || true
    fi
    printf '%s\n' "$section_dir"
}

zapret_section_conf_path() {
    section="$1"
    section_dir="$(zapret_ensure_section_dirs "$section")"
    printf '%s/config/section.conf\n' "$section_dir"
}

zapret_init_section_conf_if_missing() {
    section="$1"
    section_slug="$(common_normalize_token "$section")"
    conf_path="$(zapret_section_conf_path "$section")"
    [ -f "$conf_path" ] && return 0

    cat > "$conf_path" <<EOF
ZAPRET_SECTION_NAME='$section_slug'
ZAPRET_SECTION_ENABLED='1'
ZAPRET_SECTION_EXCLUDE_TAG=''
EOF
}

zapret_section_text_path() {
    section="$1"
    section_dir="$(zapret_ensure_section_dirs "$section")"
    printf '%s/config/section.text\n' "$section_dir"
}

zapret_init_section_text_if_missing() {
    section="$1"
    text_path="$(zapret_section_text_path "$section")"
    [ -f "$text_path" ] && return 0

    cat > "$text_path" <<'EOF'
--dpi-desync=fake,multisplit
--dpi-desync-fake-tls=0x00000000
--dpi-desync-fake-tls=!
--dpi-desync-split-pos=1,midsld
--dpi-desync-repeats=2
--dpi-desync-fooling=badseq
--dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com
EOF
}

zapret_iter_sections() {
    sections_root="$(zapret_sections_root)"
    [ -d "$sections_root" ] || return 0

    zapret_ensure_sections_order_file
    order_file="$(zapret_sections_order_file)"

    tmp_found="$(mktemp)"
    tmp_order="$(mktemp)"

    for dir in "$sections_root"/*; do
        [ -d "$dir" ] || continue
        basename "$dir"
    done | sort -u > "$tmp_found"

    tr -d '\r' < "$order_file" | sed '/^[[:space:]]*#/d; /^[[:space:]]*$/d' > "$tmp_order"

    # Без O(n²) grep -Fxq: order ∩ found, затем хвост вне order (lex).
    awk '
        FNR == NR {
            if ($0 != "") order[++n] = $0
            next
        }
        {
            if ($0 != "") found[$0] = 1
        }
        END {
            for (i = 1; i <= n; i++) {
                s = order[i]
                if (s in found) {
                    print s
                    printed[s] = 1
                }
            }
        }
    ' "$tmp_order" "$tmp_found"
    awk '
        FNR == NR {
            if ($0 != "") order[$0] = 1
            next
        }
        ($0 != "" && !($0 in order)) { print }
    ' "$tmp_order" "$tmp_found" | sort

    rm -f "$tmp_found" "$tmp_order"
}

# Пути к section.conf/section.text без mkdir/migrate (для быстрых проверок pending).
zapret_section_profile_paths() {
    section="$1"
    slug="$(common_normalize_token "$section")"
    [ -n "$slug" ] || return 1
    base="$(zapret_sections_root)/$slug"
    printf '%s\n' "$base/config/section.conf" "$base/config/section.text"
}

_zapret_path_mtime() {
    f="$1"
    [ -f "$f" ] || {
        printf '0'
        return 0
    }
    stat -c %Y "$f" 2>/dev/null || stat -f %m "$f" 2>/dev/null || printf '0'
}

_zapret_section_enabled_quick() {
    conf_path="$1"
    [ -f "$conf_path" ] || return 0
    if grep -q "^ZAPRET_SECTION_ENABLED='0'" "$conf_path" 2>/dev/null; then
        return 1
    fi
    return 0
}

# OpenWrt BusyBox has no cksum(1). sha256sum/md5sum are default applets on 24/25.
_zapret_stdin_digest() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum | awk '{print $1}'
    elif command -v md5sum >/dev/null 2>&1; then
        md5sum | awk '{print $1}'
    else
        awk 'BEGIN { h = 5381 }
        {
            for (i = 1; i <= length($0); i++) {
                n = index("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-", substr($0, i, 1))
                h = (h * 33 + n) % 2147483647
            }
            h = (h * 33 + 10) % 2147483647
        }
        END { print h }'
    fi
}

_zapret_hash_section_profile_files() {
    conf_path="$1"
    text_path="$2"
    [ -f "$conf_path" ] && [ -f "$text_path" ] || return 1
    {
        tr -d '\r' < "$conf_path"
        printf '\n---XFREE-ZAPRET-SEP---\n'
        tr -d '\r' < "$text_path"
    } | _zapret_stdin_digest
}

zapret_load_section_conf() {
    section="$1"
    conf_path="$(zapret_section_conf_path "$section")"
    zapret_init_section_conf_if_missing "$section"
    zapret_init_section_text_if_missing "$section"

    unset \
        ZAPRET_SECTION_NAME \
        ZAPRET_SECTION_ENABLED \
        ZAPRET_SECTION_EXCLUDE_TAG \
        ZAPRET_SECTION_HOST_FILE \
        ZAPRET_SECTION_IPSET_FILE \
        ZAPRET_SECTION_EXCLUDE_FILE \
        ZAPRET_SECTION_TEXT_FILE \
        2>/dev/null || true

    # Windows CRLF in section.conf makes ENABLED=$'1\r' → apply skips section
    # while UI still shows ON (only checks for ENABLED='0').
    _zapret_conf_clean="$(mktemp)"
    tr -d '\r' < "$conf_path" > "$_zapret_conf_clean"
    # shellcheck disable=SC1090
    . "$_zapret_conf_clean"
    rm -f "$_zapret_conf_clean"
    unset _zapret_conf_clean

    ZAPRET_SECTION_NAME="${ZAPRET_SECTION_NAME:-$section}"
    ZAPRET_SECTION_ENABLED="${ZAPRET_SECTION_ENABLED:-1}"
    section_slug="$(common_normalize_token "$ZAPRET_SECTION_NAME")"
    [ -n "$section_slug" ] || section_slug="$(common_normalize_token "$section")"
    [ -n "$section_slug" ] || die "Некорректное имя секции zapret: $section"
    ZAPRET_SECTION_HOST_FILE="${ZAPRET_SECTION_HOST_FILE:-xfree-${section_slug}-hosts.txt}"
    ZAPRET_SECTION_IPSET_FILE="${ZAPRET_SECTION_IPSET_FILE:-xfree-${section_slug}-ipset.txt}"
    ZAPRET_SECTION_EXCLUDE_TAG="${ZAPRET_SECTION_EXCLUDE_TAG:-}"
    ZAPRET_SECTION_EXCLUDE_FILE="${ZAPRET_SECTION_EXCLUDE_FILE:-xfree-${section_slug}-exclude.txt}"
    ZAPRET_SECTION_TEXT_FILE="${ZAPRET_SECTION_TEXT_FILE:-$(zapret_section_text_path "$section")}"
}

# Сигнатура «профиль секции» (section.conf + section.text) для сравнения с last-deployed в state.
zapret_profile_section_config_sig() {
    section="$1"
    conf_path="$(zapret_section_conf_path "$section")"
    text_path="$(zapret_section_text_path "$section")"
    zapret_init_section_conf_if_missing "$section"
    zapret_init_section_text_if_missing "$section"
    {
        tr -d '\r' < "$conf_path"
        printf '\n---XFREE-ZAPRET-SEP---\n'
        tr -d '\r' < "$text_path"
    } | _zapret_stdin_digest
}

zapret_section_deployed_sig_path() {
    section="$1"
    [ -n "${section:-}" ] || return 1
    printf '%s/sections/%s/.xfree-deployed-profile.sig\n' "$ZAPRET_STATE_DIR" "$section"
}

# 0 = профиль секции отличается от последнего применённого снимка (нужен apply).
zapret_section_config_differs_from_deployed() {
    section="$1"
    sig_path="$(zapret_section_deployed_sig_path "$section")" || return 1
    paths="$(zapret_section_profile_paths "$section")" || return 1
    conf_path="$(printf '%s\n' "$paths" | sed -n '1p')"
    text_path="$(printf '%s\n' "$paths" | sed -n '2p')"

    [ -f "$conf_path" ] && [ -f "$text_path" ] || return 0
    [ -f "$sig_path" ] || return 0

    sig_mtime="$(_zapret_path_mtime "$sig_path")"
    conf_mtime="$(_zapret_path_mtime "$conf_path")"
    text_mtime="$(_zapret_path_mtime "$text_path")"
    if [ "$conf_mtime" -le "$sig_mtime" ] && [ "$text_mtime" -le "$sig_mtime" ]; then
        return 1
    fi

    cur="$(_zapret_hash_section_profile_files "$conf_path" "$text_path")" || return 1
    old="$(tr -d '\r\n' < "$sig_path")"
    [ "$cur" != "$old" ]
}

zapret_write_section_deployed_sig() {
    section="$1"
    sig_path="$(zapret_section_deployed_sig_path "$section")" || return 1
    mkdir -p "$(dirname -- "$sig_path")"
    zapret_profile_section_config_sig "$section" > "$sig_path"
}

zapret_refresh_all_enabled_section_deployed_sigs() {
    for section in $(zapret_iter_sections); do
        zapret_load_section_conf "$section"
        [ "${ZAPRET_SECTION_ENABLED:-1}" = "1" ] || continue
        zapret_write_section_deployed_sig "$section"
    done
}

# profile-generator «Работа со списками» на host: только шаблон, без /etc/xfree-toolbox.
zapret_is_profile_generator_host_lists() {
    [ "${XFREE_PROFILE_GENERATOR_HOST_LISTS:-0}" = "1" ]
}

# Канон: профиль → runtime (generate + copy-config + restart). Без ensure/install.
zapret_apply_profile_to_runtime() {
    if zapret_is_profile_generator_host_lists; then
        die "zapret apply на host (profile-generator) недоступен: списки уже в profile-templates/. Применяйте на роутере (xft → zapret) или после deploy профиля."
    fi
    apply_sh="${ZAPRET_APPLY_SCRIPT:-$ZAPRET_DIR/apply.sh}"
    [ -f "$apply_sh" ] || die "Не найден zapret apply: $apply_sh"
    sh "$apply_sh" --copy-only
}

zapret_clear_pending_sections_queue() {
    changed_file="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"
    rm -f "$changed_file"
}

# Секции из явной очереди (select-lists) — O(1), для отрисовки меню.
zapret_build_pending_queue_file_sections() {
    changed_file="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"
    [ -f "$changed_file" ] || return 0
    tr -d '\r' < "$changed_file" | sed '/^[[:space:]]*$/d'
}

# Полный список: очередь + drift section.conf/section.text (для apply-changed-sections).
zapret_build_pending_sections_list() {
    changed_file="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"
    tmpf="$(mktemp)"
    zapret_build_pending_queue_file_sections >> "$tmpf" 2>/dev/null || true
    for section in $(zapret_iter_sections); do
        paths="$(zapret_section_profile_paths "$section")" || continue
        conf_path="$(printf '%s\n' "$paths" | sed -n '1p')"
        _zapret_section_enabled_quick "$conf_path" || continue
        if zapret_section_config_differs_from_deployed "$section"; then
            printf '%s\n' "$section" >> "$tmpf"
        fi
    done
    sort -u "$tmpf" | sed '/^$/d'
    rm -f "$tmpf"
}

ZAPRET_SERVICE_LIB_SH="$ZAPRET_DIR/lib/service.sh"
if [ -f "$ZAPRET_SERVICE_LIB_SH" ]; then
    # shellcheck disable=SC1090
    . "$ZAPRET_SERVICE_LIB_SH"
fi

