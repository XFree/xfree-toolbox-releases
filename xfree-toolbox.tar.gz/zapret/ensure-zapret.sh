#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/engine.sh"
zapret_engine_apply_vars
ZAPRET_RESOLVE_RELEASE_SCRIPT="${ZAPRET_RESOLVE_RELEASE_SCRIPT:-$SCRIPT_DIR/resolve-release.sh}"
export ZAPRET_RESOLVE_RELEASE_SCRIPT
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/install-state.sh"

ZAPRET_INSTALL_SCRIPT="${ZAPRET_INSTALL_SCRIPT:-$SCRIPT_DIR/install.sh}"
INSTALL_IF_MISSING=0
UPGRADE_IF_NEWER=0

usage() {
  cat <<EOF
Usage: $0 [--install-if-missing] [--upgrade-if-newer]

Check $ZAPRET_LABEL installation (core binary / package + $ZAPRET_LUCI_PKG_NAME).

Options:
  --install-if-missing   Install zapret if core or luci-app-zapret is missing
  --upgrade-if-newer     Upgrade when a newer GitHub release is available
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --install-if-missing)
      INSTALL_IF_MISSING=1
      ;;
    --upgrade-if-newer)
      UPGRADE_IF_NEWER=1
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Неизвестный аргумент: $1"
      ;;
  esac
  shift
done

run_zapret_install() {
  reason="$1"
  [ -f "$ZAPRET_INSTALL_SCRIPT" ] || die "Не найден install script: $ZAPRET_INSTALL_SCRIPT"
  info "$reason"
  sh "$ZAPRET_INSTALL_SCRIPT" --yes
  zapret_core_installed || die "zapret core не появился после установки (ожидался $ZAPRET_NFQWS_BIN)"
  zapret_luci_installed || die "пакет $ZAPRET_LUCI_PKG_NAME не появился после установки"
}

zapret_install_state_summary || true

if ! zapret_core_installed; then
  warn "zapret не установлен"
  if [ "$INSTALL_IF_MISSING" != "1" ]; then
    exit 1
  fi
  run_zapret_install "zapret отсутствует, запускаю установку"
  new_ver="$(zapret_get_installed_version 2>/dev/null || true)"
  [ -n "$new_ver" ] && success "zapret установлен (${new_ver})" || success "zapret установлен"
  exit 0
fi

if ! zapret_luci_installed; then
  warn "zapret core есть, но $ZAPRET_LUCI_PKG_NAME не установлен"
  if [ "$INSTALL_IF_MISSING" != "1" ]; then
    exit 1
  fi
  run_zapret_install "Доустанавливаю $ZAPRET_LUCI_PKG_NAME (и пакеты релиза)"
  new_ver="$(zapret_get_installed_version 2>/dev/null || true)"
  [ -n "$new_ver" ] && success "zapret установлен (${new_ver}, luci ok)" || success "zapret установлен (luci ok)"
  exit 0
fi

current_ver="$(zapret_get_installed_version 2>/dev/null || true)"

if [ "$UPGRADE_IF_NEWER" = "1" ]; then
  latest_ver="$(zapret_resolve_latest_version 2>/dev/null || true)"
  if [ -z "$latest_ver" ]; then
    warn "Не удалось определить последний релиз (${ZAPRET_RESOLVE_RELEASE_SCRIPT:-resolve-release.sh}) — проверка обновления пропущена"
    [ -n "$current_ver" ] && success "zapret установлен (${current_ver})" || success "zapret установлен"
    exit 0
  fi

  info "Последний релиз на GitHub: $latest_ver"
  if [ -n "$current_ver" ] && [ "$current_ver" != "unknown" ] && zapret_version_is_older "$current_ver" "$latest_ver"; then
    run_zapret_install "Установлена $current_ver, доступна $latest_ver — обновляю zapret"
    new_ver="$(zapret_get_installed_version 2>/dev/null || true)"
    [ -n "$new_ver" ] && success "zapret обновлён: $new_ver" || success "zapret обновлён"
    exit 0
  fi

  if [ "$current_ver" = "unknown" ]; then
    warn "Версия установленного пакета неизвестна — сравнение с $latest_ver пропущено"
    success "zapret установлен (версия пакета не определена)"
    exit 0
  fi

  success "zapret актуален (${current_ver})"
  exit 0
fi

[ -n "$current_ver" ] && success "zapret установлен (${current_ver})" || success "zapret установлен"
