#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/pkgmgr.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/engine.sh"
zapret_engine_apply_vars

RESOLVER_SH="$SCRIPT_DIR/resolve-release.sh"
YES=0
KEEP=0

usage() {
    cat <<'EOF'
Использование:
  install.sh [--yes] [--keep]
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --yes) YES=1 ;;
        --keep) KEEP=1 ;;
        -h|--help) usage; exit 0 ;;
        *) die "Неизвестный аргумент: $1" ;;
    esac
    shift
done

pick_first_by_globs() {
    dir="$1"; shift
    for pat in "$@"; do
        for candidate in "$dir"/$pat; do
            [ -e "$candidate" ] || continue
            printf '%s\n' "$candidate"
            return 0
        done
    done
    return 1
}

install_one_file() {
    file="$1"; label="$2"
    [ -n "$file" ] || die "Пустой путь для $label"
    info "Установка $label: $(basename "$file")"
    pm_install_file "$file"
}

ensure_unzip() {
    command -v unzip >/dev/null 2>&1 && return 0
    info "unzip не найден — устанавливаю из репозитория ($PM)…"
    pm_update_index_optional
    pm_install unzip || die "Не удалось установить unzip (нужен для распаковки ZIP zapret)"
    require_cmd unzip
}

main() {
    pm_print
    http_need_tools
    http_print
    confirm_or_exit "Скачать и установить $ZAPRET_LABEL из последнего релиза?"

    TMP_ENV="$(mktemp)"
    WORKDIR=""
    trap 'rm -f "$TMP_ENV" >/dev/null 2>&1 || true; [ "$KEEP" -eq 1 ] || [ -z "$WORKDIR" ] || rm -rf "$WORKDIR" >/dev/null 2>&1 || true' EXIT INT TERM

    sh "$RESOLVER_SH" --emit-shell --engine "$ZAPRET_ENGINE" >"$TMP_ENV"
    . "$TMP_ENV"

    : "${ZAPRET_OPENWRT_ARCH:?}"
    : "${ZAPRET_TAG:?}"
    : "${ZAPRET_ARCHIVE:?}"
    : "${ZAPRET_URL:?}"

    WORKDIR="$(mktemp -d /tmp/zapret-inst.XXXXXX)"
    ZIPFILE="$WORKDIR/$ZAPRET_ARCHIVE"

    info "Архитектура: $ZAPRET_OPENWRT_ARCH"
    info "Тег релиза:  $ZAPRET_TAG"
    info "Архив:       $ZAPRET_ARCHIVE"
    info "URL:         $ZAPRET_URL"
    info "Working dir: $WORKDIR"

    ensure_unzip
    info "Скачиваю архив zapret с GitHub (curl без прогресс-бара; в логе heartbeat каждые 15с)…"
    http_download_file "$ZAPRET_URL" "$ZIPFILE"

    info "Распаковка ZIP..."
    ( cd "$WORKDIR" && unzip -o "$ZIPFILE" >/dev/null )

    if [ "$ZAPRET_ENGINE" = "zapret2" ]; then
        core_glob_apk='zapret2-*.apk'
        core_glob_apk_alt='zapret2_*.apk'
        luci_glob_apk='luci-app-zapret2-*.apk'
        luci_glob_apk_alt='luci-app-zapret2_*.apk'
        core_glob_ipk='zapret2_*.ipk'
        core_glob_ipk_alt='zapret2-*.ipk'
        luci_glob_ipk='luci-app-zapret2_*.ipk'
        luci_glob_ipk_alt='luci-app-zapret2-*.ipk'
        luci_exclude='/luci-app-zapret2'
    else
        core_glob_apk='zapret-*.apk'
        core_glob_apk_alt='zapret_*.apk'
        luci_glob_apk='luci-app-zapret-*.apk'
        luci_glob_apk_alt='luci-app-zapret_*.apk'
        core_glob_ipk='zapret_*.ipk'
        core_glob_ipk_alt='zapret-*.ipk'
        luci_glob_ipk='luci-app-zapret_*.ipk'
        luci_glob_ipk_alt='luci-app-zapret-*.ipk'
        luci_exclude='/luci-app-zapret'
    fi

    if [ "$PM" = "apk" ]; then
        PKGDIR="$WORKDIR/apk"
        [ -d "$PKGDIR" ] || die "В архиве не найден каталог apk/"
        core_pkg="$(pick_first_by_globs "$PKGDIR" "$core_glob_apk" "$core_glob_apk_alt" | grep -v "$luci_exclude" | head -n1 || true)"
        luci_pkg="$(pick_first_by_globs "$PKGDIR" "$luci_glob_apk" "$luci_glob_apk_alt" | head -n1 || true)"
    else
        PKGDIR="$WORKDIR"
        core_pkg="$(pick_first_by_globs "$PKGDIR" "$core_glob_ipk" "$core_glob_ipk_alt" | grep -v "$luci_exclude" | head -n1 || true)"
        luci_pkg="$(pick_first_by_globs "$PKGDIR" "$luci_glob_ipk" "$luci_glob_ipk_alt" | head -n1 || true)"
    fi

    [ -n "${core_pkg:-}" ] || die "Не найден пакет $ZAPRET_PKG_NAME core в архиве"
    [ -n "${luci_pkg:-}" ] || die "Не найден пакет $ZAPRET_LUCI_PKG_NAME в архиве"

    pm_update_index_optional
    zapret_engine_stop_other
    info "Установка пакетов $ZAPRET_LABEL..."
    install_one_file "$core_pkg" "$ZAPRET_PKG_NAME core"
    install_one_file "$luci_pkg" "$ZAPRET_LUCI_PKG_NAME"

    # Меню LuCI с depends.acl видит новый ACL только после нового логина;
    # кэш меню тоже сбрасываем, иначе пункт «Службы → Zapret» может не появиться.
    rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache 2>/dev/null || true
    restart_service_if_exists rpcd
    restart_service_if_exists uhttpd
    success "Установка $ZAPRET_LABEL завершена."
    warn "Если в LuCI нет пункта $ZAPRET_LABEL: выйдите из веб-интерфейса и войдите снова (нужен новый ACL-сеанс)."
}

main "$@"
