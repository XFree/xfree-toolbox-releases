#!/bin/sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

PKGMGR_SH="$ROOT_DIR/lib/pkgmgr.sh"
[ -f "$PKGMGR_SH" ] || {
    echo "[!] Не найден pkgmgr.sh: $PKGMGR_SH" >&2
    exit 1
}
. "$PKGMGR_SH"

REPO_OWNER="remittor"
REPO_NAME="zapret-openwrt"
RELEASES_URL="https://github.com/${REPO_OWNER}/${REPO_NAME}/releases"
MODE="url"
ENGINE="zapret"

while [ "$#" -gt 0 ]; do
    case "$1" in
        --url) MODE="url" ;;
        --summary) MODE="summary" ;;
        --emit-shell) MODE="emit-shell" ;;
        --engine)
            shift
            [ "$#" -gt 0 ] || { echo "[!] --engine требует zapret|zapret2" >&2; exit 1; }
            ENGINE="$1"
            ;;
        -h|--help)
            cat <<'EOF'
Использование:
  resolve-release.sh [--url|--summary|--emit-shell] [--engine zapret|zapret2]
EOF
            exit 0 ;;
        *) echo "[!] Неизвестный аргумент: $1" >&2; exit 1 ;;
    esac
    shift
done

case "$ENGINE" in
    zapret|zapret2) ;;
    zapret1) ENGINE="zapret" ;;
    *) echo "[!] Неизвестный движок: $ENGINE (ожидался zapret|zapret2)" >&2; exit 1 ;;
esac

detect_openwrt_arch() {
    [ -f /etc/openwrt_release ] || die "Не найден /etc/openwrt_release"
    . /etc/openwrt_release

    raw_arch="${OPENWRT_ARCH:-${DISTRIB_ARCH:-}}"
    if [ -z "${raw_arch:-}" ] && command -v apk >/dev/null 2>&1; then
        raw_arch="$(apk --print-arch 2>/dev/null || true)"
    fi
    if [ -z "${raw_arch:-}" ] && command -v opkg >/dev/null 2>&1; then
        raw_arch="$(opkg print-architecture 2>/dev/null | awk '$1=="arch" && $2!="all" && $2!="noarch" {print $2, $3}' | sort -k2,2n | tail -n1 | awk '{print $1}')"
    fi
    [ -n "${raw_arch:-}" ] || die "Не удалось определить архитектуру OpenWrt"
    printf '%s\n' "$raw_arch"
}

fetch_releases_html() {
    http_fetch_text "$RELEASES_URL"
}

resolve_release() {
    OWRT_ARCH="$(detect_openwrt_arch)"
    HTML="$(fetch_releases_html)"
    [ -n "${HTML:-}" ] || die "Не удалось получить HTML страницы релизов"

    if [ "$ENGINE" = "zapret2" ]; then
        REL_PATH="$(printf '%s' "$HTML" \
            | tr '"' '\n' \
            | grep "/${REPO_OWNER}/${REPO_NAME}/releases/download/v[0-9][0-9.]*/zapret2_v[0-9][0-9.]*_${OWRT_ARCH}\.zip" \
            | head -n1 || true)"
        [ -n "${REL_PATH:-}" ] || die "Не найден архив zapret2 для архитектуры: $OWRT_ARCH"
    else
        REL_PATH="$(printf '%s' "$HTML" \
            | tr '"' '\n' \
            | grep "/${REPO_OWNER}/${REPO_NAME}/releases/download/v[0-9][0-9]*\.[0-9][0-9]*/zapret_v[0-9][0-9]*\.[0-9][0-9]*_${OWRT_ARCH}\.zip" \
            | grep -v '/zapret2_' \
            | head -n1 || true)"
        [ -n "${REL_PATH:-}" ] || die "Не найден архив zapret для архитектуры: $OWRT_ARCH"
    fi

    ZAPRET_URL="https://github.com${REL_PATH}"
    ZAPRET_ARCHIVE="$(basename "$REL_PATH")"
    ZAPRET_TAG="$(printf '%s' "$REL_PATH" | sed -n 's#.*/download/\(v[^/]*\)/.*#\1#p')"
    ZAPRET_VERSION="${ZAPRET_TAG#v}"

    case "$MODE" in
        url) printf '%s\n' "$ZAPRET_URL" ;;
        summary)
            printf '[*] OpenWrt arch : %s\n' "$OWRT_ARCH"
            printf '[*] Tag          : %s\n' "$ZAPRET_TAG"
            printf '[*] Archive      : %s\n' "$ZAPRET_ARCHIVE"
            printf '[*] URL          : %s\n' "$ZAPRET_URL"
            ;;
        emit-shell)
            cat <<EOF
ZAPRET_OPENWRT_ARCH='${OWRT_ARCH}'
ZAPRET_TAG='${ZAPRET_TAG}'
ZAPRET_VERSION='${ZAPRET_VERSION}'
ZAPRET_ARCHIVE='${ZAPRET_ARCHIVE}'
ZAPRET_URL='${ZAPRET_URL}'
EOF
            ;;
    esac
}

resolve_release
