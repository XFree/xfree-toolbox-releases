#!/bin/sh
# shellcheck shell=sh
# Переключение YouTube с Zapret на VPN-интерфейс (по умолчанию: proton).
# 1. Отключает все youtube_* секции в zapret (ENABLED=0).
# 2. Добавляет списки доменов YouTube в fqdn.d целевого интерфейса (proton).
# 3. Применяет изменения в runtime (zapret apply + iface apply).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1091
[ -f "$ROOT_DIR/lib/common.sh" ] && . "$ROOT_DIR/lib/common.sh"
# shellcheck disable=SC1091
[ -f "$ROOT_DIR/zapret/lib/zapret-config.sh" ] && . "$ROOT_DIR/zapret/lib/zapret-config.sh"

TARGET_IFACE="${1:-proton}"
PROFILES_DIR="${XFREE_PROFILES_ROOT:-$ROOT_DIR/profiles}"

# Определение активного профиля
ACTIVE_PROFILE="default"
if [ -f "/etc/xfree-toolbox/applied-profile.env" ]; then
	_p="$(awk -F= '/^[[:space:]]*XFREE_APPLIED_PROFILE=/ { v=$2; gsub(/["'"'"']/, "", v); gsub(/^[[:space:]]+|[[:space:]]+$/, "", v); print v; exit }' "/etc/xfree-toolbox/applied-profile.env" 2>/dev/null || true)"
	[ -n "$_p" ] && ACTIVE_PROFILE="$_p"
fi

PROFILE_ROOT="$PROFILES_DIR/$ACTIVE_PROFILE"
[ -d "$PROFILE_ROOT" ] || {
	printf 'Ошибка: профиль не найден: %s\n' "$PROFILE_ROOT" >&2
	exit 1
}

info "Отключение всех секций YouTube в Zapret (профиль: $ACTIVE_PROFILE)..."
for sec_dir in "$PROFILE_ROOT/zapret/sections"/youtube_*; do
	[ -d "$sec_dir" ] || continue
	conf="$sec_dir/section.conf"
	[ -f "$conf" ] || continue
	tmp="${conf}.tmp.$$"
	awk '
		BEGIN { set=0 }
		/^ZAPRET_SECTION_ENABLED=/ { print "ZAPRET_SECTION_ENABLED='\''0'\''"; set=1; next }
		{ print }
		END { if (set==0) print "ZAPRET_SECTION_ENABLED='\''0'\''" }
	' "$conf" > "$tmp"
	mv "$tmp" "$conf"
done

# Копирование списка fqdn google/youtube в целевой интерфейс
IFACE_DIR="$PROFILE_ROOT/iface-routing/interfaces/$TARGET_IFACE"
mkdir -p "$IFACE_DIR/fqdn.d"

# Ищем канонический файл доменов youtube
SRC_LST=""
for cand in "$ROOT_DIR/upstreams/user/upstream/zapret/google/fqdn-google.lst" \
            "$PROFILE_ROOT/zapret/sections/youtube_1/fqdn.d/user__service__zapret__google__fqdn.lst"; do
	if [ -f "$cand" ]; then
		SRC_LST="$cand"
		break
	fi
done

if [ -n "$SRC_LST" ]; then
	cp -f "$SRC_LST" "$IFACE_DIR/fqdn.d/user__service__zapret__google__fqdn.lst"
	info "Добавлен список YouTube в интерфейс $TARGET_IFACE: $IFACE_DIR/fqdn.d/user__service__zapret__google__fqdn.lst"
fi

# Применение конфигурации
info "Применение правил Zapret..."
sh "$ROOT_DIR/zapret/apply.sh" --yes || true

info "Применение правил маршрутизации интерфейсов..."
if [ -f "$ROOT_DIR/iface-routing/apply-routing.sh" ]; then
	sh "$ROOT_DIR/iface-routing/apply-routing.sh" --yes || true
fi

printf 'SUCCESS: YouTube переключён на %s, все секции Zapret отключены.\n' "$TARGET_IFACE"
