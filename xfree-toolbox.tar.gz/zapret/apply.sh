#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib.sh"
# shellcheck disable=SC1091
. "$SCRIPT_DIR/lib/engine.sh"
zapret_engine_apply_vars

INSTALL_SCRIPT="${INSTALL_SCRIPT:-$SCRIPT_DIR/install.sh}"
ENSURE_SCRIPT="${ENSURE_SCRIPT:-$SCRIPT_DIR/ensure-zapret.sh}"
COPY_SCRIPT="${COPY_SCRIPT:-$SCRIPT_DIR/copy-config.sh}"
PROFILE_CFG_TEMPLATE_NAME="${PROFILE_CFG_TEMPLATE_NAME:-zapret.template}"

YES=0
DO_INSTALL=1
DO_COPY=1
BEST_EFFORT_INSTALL=0
NO_RESTART=0
GENERATE_ONLY=0
COMPUTED_NFQWS_PORTS_TCP=""
COMPUTED_NFQWS_PORTS_UDP=""

build_merged_file() {
  src_dir="$1"
  dst_file="$2"
  kind="$3"
  disable_ipv6="${4:-0}"

  mkdir -p "$(dirname -- "$dst_file")"

  if [ ! -d "$src_dir" ]; then
    : > "$dst_file"
    return 0
  fi

  tmp_file="$(mktemp)"
  trap 'rm -f "$tmp_file"' EXIT INT TERM

  if [ "$kind" = "prefix" ]; then
    # Prefix merge order must be stable: ipv4 first, then ipv6.
    for f in "$src_dir"/*__ipv4.lst "$src_dir"/*__prefix.lst; do
      [ -f "$f" ] || continue
      tr -d '\r' < "$f" | sed '/^[[:space:]]*$/d; /^[[:space:]]*[#;]/d; s/[[:space:]]\+#.*$//' >> "$tmp_file"
    done
    if [ "$disable_ipv6" != "1" ]; then
      for f in "$src_dir"/*__ipv6.lst; do
        [ -f "$f" ] || continue
        tr -d '\r' < "$f" | sed '/^[[:space:]]*$/d; /^[[:space:]]*[#;]/d; s/[[:space:]]\+#.*$//' >> "$tmp_file"
      done
    fi
    # Backward compatibility for old materialized names.
    if [ ! -s "$tmp_file" ]; then
      for f in "$src_dir"/*.lst; do
        [ -f "$f" ] || continue
        tr -d '\r' < "$f" | sed '/^[[:space:]]*$/d; /^[[:space:]]*[#;]/d; s/[[:space:]]\+#.*$//' >> "$tmp_file"
      done
    fi
  else
    for f in "$src_dir"/*.lst; do
      [ -f "$f" ] || continue
      cat "$f" | common_norm_domains_stream >> "$tmp_file"
    done
  fi

  if [ -s "$tmp_file" ]; then
    awk '!seen[$0]++' "$tmp_file" > "$dst_file"
  else
    : > "$dst_file"
  fi

  rm -f "$tmp_file"
  trap - EXIT INT TERM
}

read_uci_option_value() {
  cfg_file="$1"
  option_name="$2"
  awk -v name="$option_name" '
    $1 == "option" && $2 == name {
      value=$0
      sub(/^[[:space:]]*option[[:space:]]+[^[:space:]]+[[:space:]]+'\''/, "", value)
      sub(/'\''[[:space:]]*$/, "", value)
      print value
      exit
    }
  ' "$cfg_file"
}

append_managed_nfqws_block() {
  config_file="$1"
  block_file="$2"
  optkey="${ZAPRET_OPT_KEY:-NFQWS_OPT}"

  tmp_out="$(mktemp)"
  awk -v blk="$block_file" -v optkey="$optkey" '
    BEGIN {
      in_opt=0
      in_managed=0
      inserted=0
    }
    {
      if (!in_opt) {
        print $0
        re = "^[[:space:]]*option[[:space:]]+" optkey "[[:space:]]+'\''"
        if ($0 ~ re) in_opt=1
        next
      }

      if ($0 ~ /^[[:space:]]*# XFREE-ZAPRET-BEGIN$/) { in_managed=1; next }
      if (in_managed) {
        if ($0 ~ /^[[:space:]]*# XFREE-ZAPRET-END$/) in_managed=0
        next
      }

      if ($0 ~ /^[[:space:]]*'\''$/) {
        while ((getline line < blk) > 0) print line
        close(blk)
        print $0
        in_opt=0
        inserted=1
        next
      }

      print $0
    }
    END {
      if (!inserted) exit 42
    }
  ' "$config_file" > "$tmp_out" || {
    rm -f "$tmp_out"
    die "Не удалось встроить managed блок в $optkey ($config_file)"
  }

  mv "$tmp_out" "$config_file"
}

materialize_profile_config_from_template() {
  template_file="$1"
  dst_file="$2"
  block_file="$3"

  [ -f "$template_file" ] || return 1

  tmp_out="$(mktemp)"
  awk -v blk="$block_file" '
    BEGIN { inserted=0 }
    {
      if ($0 ~ /\{\{SECTIONS_BLOCK\}\}/) {
        while ((getline line < blk) > 0) print line
        close(blk)
        inserted=1
        next
      }
      print $0
    }
    END {
      if (!inserted) exit 42
    }
  ' "$template_file" > "$tmp_out" || {
    rm -f "$tmp_out"
    return 1
  }

  mv "$tmp_out" "$dst_file"
  return 0
}

append_section_text() {
  text_file="$1"
  out_file="$2"
  [ -f "$text_file" ] || return 0

  tr -d '\r' < "$text_file" \
    | sed '/^[[:space:]]*$/d; /^[[:space:]]*[#;]/d' >> "$out_file"
}

collect_filter_ports() {
  block_file="$1"
  proto="$2" # tcp|udp
  awk -v p="--filter-"$proto"=" '
    index($0, p) == 1 {
      s=$0
      sub("^--filter-[a-z]+=", "", s)
      n=split(s, a, ",")
      for (i=1; i<=n; i++) {
        t=a[i]
        gsub(/[[:space:]]/, "", t)
        if (t != "") print t
      }
    }
  ' "$block_file" | sort -u | awk '
    BEGIN { first=1 }
    {
      if (!first) printf ","
      printf "%s", $0
      first=0
    }
    END { printf "\n" }
  '
}

update_uci_option_value() {
  cfg_file="$1"
  opt_name="$2"
  opt_value="$3"
  tmp_file="$(mktemp)"
  awk -v name="$opt_name" -v val="$opt_value" '
    BEGIN { done=0 }
    {
      if ($0 ~ "^[[:space:]]*option[[:space:]]+" name "[[:space:]]+'\''.*'\''[[:space:]]*$") {
        print "\toption " name " '\''" val "'\''"
        done=1
        next
      }
      print $0
    }
    END {
      if (!done) print "\toption " name " '\''" val "'\''"
    }
  ' "$cfg_file" > "$tmp_file"
  mv "$tmp_file" "$cfg_file"
}

normalize_nfqws_opt_leading_new() {
  cfg_file="$1"
  optkey="${ZAPRET_OPT_KEY:-NFQWS_OPT}"
  tmp_file="$(mktemp)"
  awk -v optkey="$optkey" '
    BEGIN {
      in_opt=0
      removed=0
    }
    {
      if (!in_opt) {
        print $0
        re = "^[[:space:]]*option[[:space:]]+" optkey "[[:space:]]+'\''"
        if ($0 ~ re) in_opt=1
        next
      }

      if (!removed && $0 ~ /^[[:space:]]*--new[[:space:]]*$/) {
        removed=1
        next
      }

      if ($0 ~ /^[[:space:]]*'\''[[:space:]]*$/) {
        in_opt=0
      }
      print $0
    }
  ' "$cfg_file" > "$tmp_file"
  mv "$tmp_file" "$cfg_file"
}

compute_and_apply_nfqws_ports() {
  block_file="$1"
  profile_cfg="$2"

  COMPUTED_NFQWS_PORTS_TCP="$(collect_filter_ports "$block_file" tcp)"
  COMPUTED_NFQWS_PORTS_UDP="$(collect_filter_ports "$block_file" udp)"

  [ -n "${COMPUTED_NFQWS_PORTS_TCP:-}" ] || COMPUTED_NFQWS_PORTS_TCP="443"
  [ -n "${COMPUTED_NFQWS_PORTS_UDP:-}" ] || COMPUTED_NFQWS_PORTS_UDP="443"

  update_uci_option_value "$profile_cfg" "${ZAPRET_PORTS_TCP_KEY:-NFQWS_PORTS_TCP}" "$COMPUTED_NFQWS_PORTS_TCP"
  update_uci_option_value "$profile_cfg" "${ZAPRET_PORTS_UDP_KEY:-NFQWS_PORTS_UDP}" "$COMPUTED_NFQWS_PORTS_UDP"
}

port_token_overlap() {
  left="$1"
  right="$2"

  l_start="$left"
  l_end="$left"
  case "$left" in
    *-*)
      l_start="${left%-*}"
      l_end="${left#*-}"
      ;;
  esac

  r_start="$right"
  r_end="$right"
  case "$right" in
    *-*)
      r_start="${right%-*}"
      r_end="${right#*-}"
      ;;
  esac

  case "$l_start$l_end$r_start$r_end" in
    *[!0-9]*) return 1 ;;
  esac

  [ "$l_start" -le "$r_end" ] && [ "$r_start" -le "$l_end" ]
}

firewall_redirect_conflicts_for_ports() {
  ports_csv="$1"
  [ -n "${ports_csv:-}" ] || return 0
  command -v uci >/dev/null 2>&1 || return 0

  tmp_ports="$(mktemp)"
  tmp_redirects="$(mktemp)"
  printf '%s\n' "$ports_csv" | tr ',' '\n' | sed 's/[[:space:]]//g; /^$/d' > "$tmp_ports"

  for sec in $(uci show firewall 2>/dev/null | sed -n "s/^\(firewall\.[^.]*\)=redirect$/\1/p"); do
    [ -n "${sec:-}" ] || continue
    src_dport="$(uci -q get "$sec.src_dport" 2>/dev/null || true)"
    dest_port="$(uci -q get "$sec.dest_port" 2>/dev/null || true)"
    name="$(uci -q get "$sec.name" 2>/dev/null || true)"
    [ -n "$name" ] || name="$sec"

    for field in "$src_dport" "$dest_port"; do
      [ -n "${field:-}" ] || continue
      printf '%s\n' "$field" | tr ' ,' '\n\n' | sed 's/[[:space:]]//g; /^$/d' | while IFS= read -r token; do
        printf '%s|%s|%s\n' "$sec" "$name" "$token"
      done
    done
  done | sort -u > "$tmp_redirects"

  while IFS='|' read -r sec name fw_port; do
    [ -n "${fw_port:-}" ] || continue
    while IFS= read -r nfq_port; do
      [ -n "${nfq_port:-}" ] || continue
      if port_token_overlap "$nfq_port" "$fw_port"; then
        printf '%s|%s|%s|%s\n' "$sec" "$name" "$fw_port" "$nfq_port"
        break
      fi
    done < "$tmp_ports"
  done < "$tmp_redirects" | sort -u

  rm -f "$tmp_ports" "$tmp_redirects"
}

check_firewall_redirect_conflicts_or_confirm() {
  tcp_csv="$1"
  udp_csv="$2"
  command -v uci >/dev/null 2>&1 || return 0

  tcp_conflicts="$(firewall_redirect_conflicts_for_ports "$tcp_csv" || true)"
  udp_conflicts="$(firewall_redirect_conflicts_for_ports "$udp_csv" || true)"
  all_conflicts="$(printf '%s\n%s\n' "$tcp_conflicts" "$udp_conflicts" | sed '/^$/d' | sort -u)"
  [ -n "${all_conflicts:-}" ] || return 0

  warn "Обнаружены пересечения NFQWS_PORTS с firewall redirect:"
  printf '%s\n' "$all_conflicts" | while IFS='|' read -r sec name fw_port nfq_port; do
    warn "  - $name ($sec): redirect_port=$fw_port пересекается с nfqws_port=$nfq_port"
  done
  confirm_or_exit "Найдены конфликты портов с firewall redirect. Продолжить применение zapret?"
}

render_section_template() {
  template_file="$1"
  out_file="$2"
  kind="$3"
  host_target_path="$4"
  prefix_ipset_target_path="$5"
  exclude_path="${6:-}"

  [ -f "$template_file" ] || return 0
  select_line="--hostlist=$host_target_path"
  [ "$kind" = "ipset" ] && select_line="--ipset=$prefix_ipset_target_path"
  fqdn_line="--hostlist=$host_target_path"
  prefix_line="--ipset=$prefix_ipset_target_path"
  exclude_line=""
  [ -n "${exclude_path:-}" ] && exclude_line="--hostlist-exclude=$exclude_path"
  sed \
    -e "s|{{SELECT_LIST}}|$select_line|g" \
    -e "s|{{SELECT_FQDN_LIST}}|$fqdn_line|g" \
    -e "s|{{SELECT_PREFIX_LIST}}|$prefix_line|g" \
    -e "s|{{SELECT_EXCLUDE_LIST}}|$exclude_line|g" \
    -e "s|{{HOSTLIST}}|--hostlist=$host_target_path|g" \
    -e "s|{{IPSET}}|--ipset=$prefix_ipset_target_path|g" \
    "$template_file" \
    | tr -d '\r' \
    | sed '/^[[:space:]]*$/d; /^[[:space:]]*[#;]/d' >> "$out_file"
}

render_section_template_mode() {
  template_file="$1"
  out_file="$2"
  mode="$3"       # shared|list
  kind="$4"       # hostlist|ipset
  host_target_path="$5"
  prefix_ipset_target_path="$6"
  exclude_path="${7:-}"

  [ -f "$template_file" ] || return 0

  tmp_dir="$(mktemp -d)"
  trap 'rm -rf "$tmp_dir"' EXIT INT TERM

  awk -v out_prefix="$tmp_dir/block." '
    function flush_block() {
      if (block_len == 0) return
      file = sprintf("%s%06d", out_prefix, idx)
      print block > file
      close(file)
      idx++
      block = ""
      block_len = 0
    }
    {
      line = $0
      sub(/\r$/, "", line)
      if (line ~ /^--new$/) {
        if (block_len > 0) flush_block()
        next
      }
      block = block line "\n"
      block_len++
    }
    END { flush_block() }
  ' "$template_file"

  wrote_mode_chunk=0
  for block in "$tmp_dir"/block.*; do
    [ -f "$block" ] || continue
    has_any_select=0
    has_fqdn_select=0
    has_prefix_select=0

    if awk '/\{\{SELECT_LIST\}\}|\{\{SELECT_FQDN_LIST\}\}|\{\{SELECT_PREFIX_LIST\}\}|\{\{HOSTLIST\}\}|\{\{IPSET\}\}/ { found=1 } END { exit(found ? 0 : 1) }' "$block"; then
      has_any_select=1
    fi
    if awk '/\{\{SELECT_FQDN_LIST\}\}|\{\{HOSTLIST\}\}/ { found=1 } END { exit(found ? 0 : 1) }' "$block"; then
      has_fqdn_select=1
    fi
    if awk '/\{\{SELECT_PREFIX_LIST\}\}|\{\{IPSET\}\}/ { found=1 } END { exit(found ? 0 : 1) }' "$block"; then
      has_prefix_select=1
    fi

    case "$mode" in
      shared)
        [ "$has_any_select" -eq 0 ] || continue
        ;;
      list)
        [ "$has_any_select" -eq 1 ] || continue
        if [ "$kind" = "hostlist" ]; then
          if [ "$has_fqdn_select" -eq 0 ] && ! awk '/\{\{SELECT_LIST\}\}/ { found=1 } END { exit(found ? 0 : 1) }' "$block"; then
            continue
          fi
        else
          if [ "$has_prefix_select" -eq 0 ] && ! awk '/\{\{SELECT_LIST\}\}/ { found=1 } END { exit(found ? 0 : 1) }' "$block"; then
            continue
          fi
        fi
        ;;
      *)
        continue
        ;;
    esac

    if [ "$wrote_mode_chunk" -gt 0 ]; then
      echo "--new" >> "$out_file"
    fi
    size_before="$(wc -c < "$out_file" 2>/dev/null | tr -d '[:space:]' || true)"
    [ -n "${size_before:-}" ] || size_before=0
    render_section_template "$block" "$out_file" "$kind" "$host_target_path" "$prefix_ipset_target_path" "$exclude_path"
    size_after="$(wc -c < "$out_file" 2>/dev/null | tr -d '[:space:]' || true)"
    [ -n "${size_after:-}" ] || size_after=0
    if [ "$size_after" -gt "$size_before" ]; then
      wrote_mode_chunk=$((wrote_mode_chunk + 1))
    fi
  done

  rm -rf "$tmp_dir"
  trap - EXIT INT TERM
}

append_rendered_chunk() {
  block_file="$1"
  rendered_file="$2"
  [ -s "$rendered_file" ] || return 0

  cleaned_tmp="$(mktemp)"
  awk '
    BEGIN { dropped=0 }
    {
      line=$0
      sub(/\r$/, "", line)
      if (dropped==0 && line ~ /^[[:space:]]*--new[[:space:]]*$/) {
        dropped=1
        next
      }
      print line
      dropped=1
    }
  ' "$rendered_file" > "$cleaned_tmp"

  if [ ! -s "$cleaned_tmp" ]; then
    rm -f "$cleaned_tmp"
    return 0
  fi

  if [ -s "$block_file" ]; then
    echo "--new" >> "$block_file"
  fi
  cat "$cleaned_tmp" >> "$block_file"
  rm -f "$cleaned_tmp"
}

generate_zapret_targets() {
  profile_root="$(zapret_profile_root)"
  sections_root="$(zapret_sections_root)"
  sections_order_file="$(zapret_sections_order_file)"
  profile_ipset_dir="$profile_root/ipset"
  profile_cfg="$profile_root/zapret"
  profile_cfg_template="$profile_root/$PROFILE_CFG_TEMPLATE_NAME"
  state_cfg_template="$ZAPRET_STATE_DIR/$PROFILE_CFG_TEMPLATE_NAME"
  state_sections_order_file="$ZAPRET_STATE_DIR/sections.order"

  mkdir -p "$ZAPRET_STATE_DIR/sections" "$ZAPRET_GENERATED_DIR/sections" "$profile_ipset_dir"
  zapret_ensure_sections_order_file
  cp -f "$sections_order_file" "$state_sections_order_file"
  if [ ! -f "$profile_cfg_template" ]; then
    fallback="$ROOT_DIR/profile-templates/default/zapret/$PROFILE_CFG_TEMPLATE_NAME"
    if [ -f "$fallback" ]; then
      info "В профиле нет $PROFILE_CFG_TEMPLATE_NAME — копирую из шаблона default"
      cp -f "$fallback" "$profile_cfg_template"
    fi
  fi
  [ -f "$profile_cfg_template" ] || die "Не найден обязательный шаблон zapret: $profile_cfg_template"
  disable_ipv6="$(read_uci_option_value "$profile_cfg_template" "DISABLE_IPV6" || true)"
  [ -n "${disable_ipv6:-}" ] || disable_ipv6="0"

  block_file="$(mktemp)"
  : > "$block_file"

  has_sections=0
  for section in $(zapret_iter_sections); do
    has_sections=1
    zapret_load_section_conf "$section"
    [ "${ZAPRET_SECTION_ENABLED:-1}" = "1" ] || {
      info "Секция '$section' отключена (ZAPRET_SECTION_ENABLED=0), пропуск."
      continue
    }
    section_dir="$sections_root/$section"

    state_section_dir="$ZAPRET_STATE_DIR/sections/$section"
    gen_section_dir="$ZAPRET_GENERATED_DIR/sections/$section"
    mkdir -p "$state_section_dir/config" "$state_section_dir/fqdn.d" "$state_section_dir/prefixes.d" "$gen_section_dir"
    mkdir -p "$state_section_dir/fqdn.exclude.d"

    common_sync_dir_mirror "$section_dir/config" "$state_section_dir/config"
    common_sync_dir_mirror "$section_dir/fqdn.d" "$state_section_dir/fqdn.d"
    common_sync_dir_mirror "$section_dir/prefixes.d" "$state_section_dir/prefixes.d"
    common_sync_dir_mirror "$section_dir/fqdn.exclude.d" "$state_section_dir/fqdn.exclude.d"

    gen_host_file="$gen_section_dir/$ZAPRET_SECTION_HOST_FILE"
    gen_ipset_file="$gen_section_dir/$ZAPRET_SECTION_IPSET_FILE"
    gen_exclude_file="$gen_section_dir/$ZAPRET_SECTION_EXCLUDE_FILE"
    build_merged_file "$state_section_dir/fqdn.d" "$gen_host_file" fqdn
    build_merged_file "$state_section_dir/prefixes.d" "$gen_ipset_file" prefix "$disable_ipv6"
    build_merged_file "$state_section_dir/fqdn.exclude.d" "$gen_exclude_file" fqdn

    host_runtime="$profile_ipset_dir/$ZAPRET_SECTION_HOST_FILE"
    ipset_runtime="$profile_ipset_dir/$ZAPRET_SECTION_IPSET_FILE"
    exclude_runtime="$profile_ipset_dir/$ZAPRET_SECTION_EXCLUDE_FILE"
    cp -f "$gen_host_file" "$host_runtime"
    cp -f "$gen_ipset_file" "$ipset_runtime"
    cp -f "$gen_exclude_file" "$exclude_runtime"

    host_count="$(wc -l < "$gen_host_file" 2>/dev/null || echo 0)"
    ipset_count="$(wc -l < "$gen_ipset_file" 2>/dev/null || echo 0)"
    exclude_count="$(wc -l < "$gen_exclude_file" 2>/dev/null || echo 0)"

    info "Секция '$section': hostlist=$host_count ipset=$ipset_count exclude=$exclude_count"

    host_path="${ZAPRET_IPSET_DIR:-/opt/zapret/ipset}/$ZAPRET_SECTION_HOST_FILE"
    ipset_path="${ZAPRET_IPSET_DIR:-/opt/zapret/ipset}/$ZAPRET_SECTION_IPSET_FILE"
    exclude_path=""
    [ "$exclude_count" -gt 0 ] && exclude_path="${ZAPRET_IPSET_DIR:-/opt/zapret/ipset}/$ZAPRET_SECTION_EXCLUDE_FILE"

    section_text_src="$ZAPRET_SECTION_TEXT_FILE"
    section_text_converted=""
    if [ "${ZAPRET_ENGINE:-zapret}" = "zapret2" ]; then
      CONV="$SCRIPT_DIR/lib/nfqws1-to-nfqws2.sh"
      [ -f "$CONV" ] || die "Не найден конвертер стратегий: $CONV"
      section_text_converted="$(mktemp)"
      sh "$CONV" "$ZAPRET_SECTION_TEXT_FILE" >"$section_text_converted" \
        || die "Не удалось конвертировать секцию '$section' в zapret2"
      section_text_src="$section_text_converted"
    fi

    if [ "$host_count" -gt 0 ]; then
      rendered_tmp="$(mktemp)"
      render_section_template_mode "$section_text_src" "$rendered_tmp" list hostlist "$host_path" "$ipset_path" "$exclude_path"
      append_rendered_chunk "$block_file" "$rendered_tmp"
      rm -f "$rendered_tmp"
    fi

    if [ "$ipset_count" -gt 0 ]; then
      rendered_tmp="$(mktemp)"
      render_section_template_mode "$section_text_src" "$rendered_tmp" list ipset "$host_path" "$ipset_path" "$exclude_path"
      append_rendered_chunk "$block_file" "$rendered_tmp"
      rm -f "$rendered_tmp"
    fi

    rendered_shared_tmp="$(mktemp)"
    render_section_template_mode "$section_text_src" "$rendered_shared_tmp" shared hostlist "$host_path" "$ipset_path" "$exclude_path"
    append_rendered_chunk "$block_file" "$rendered_shared_tmp"
    rm -f "$rendered_shared_tmp" "$section_text_converted"
  done

  if [ "$has_sections" -eq 0 ]; then
    warn "Не найдено ни одной секции zapret в профиле ($sections_root). Пропускаю генерацию."
    rm -f "$block_file"
    return 0
  fi

  if ! materialize_profile_config_from_template "$profile_cfg_template" "$profile_cfg" "$block_file"; then
    rm -f "$block_file"
    die "Шаблон $profile_cfg_template не содержит {{SECTIONS_BLOCK}} или не может быть обработан"
  fi
  compute_and_apply_nfqws_ports "$block_file" "$profile_cfg"
  cp -f "$profile_cfg_template" "$state_cfg_template"
  rm -f "$block_file"
}

usage() {
  cat <<EOF
Usage: $(basename "$0") [options]

Options:
  --yes                 Non-interactive mode
  --install-only        Only install zapret packages
  --copy-only           Regenerate profile artifacts, then copy full config/ipset to runtime
  --best-effort-install Do not fail whole run if install fails
  --no-restart          Pass --no-restart to copy-config.sh
  --generate-only       Only generate section artifacts/config block
  -h, --help            Show help
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes) YES=1 ;;
    --install-only) DO_COPY=0 ;;
    --copy-only) DO_INSTALL=0 ;;
    --best-effort-install) BEST_EFFORT_INSTALL=1 ;;
    --no-restart) NO_RESTART=1 ;;
    --generate-only) GENERATE_ONLY=1; DO_INSTALL=0; DO_COPY=0 ;;
    -h|--help) usage; exit 0 ;;
    *) die "Неизвестный аргумент: $1" ;;
  esac
  shift
done

[ "$GENERATE_ONLY" = "1" ] || [ "$DO_INSTALL" = "1" ] || [ "$DO_COPY" = "1" ] || die "Нечего выполнять: выбраны --install-only и --copy-only одновременно"

# zapret/apply.sh is the orchestration entrypoint: run install/copy non-interactively.
YES=1

[ -f "$INSTALL_SCRIPT" ] || die "Не найден install script: $INSTALL_SCRIPT"
[ -f "$ENSURE_SCRIPT" ] || die "Не найден ensure script: $ENSURE_SCRIPT"
[ -f "$COPY_SCRIPT" ] || die "Не найден copy-config script: $COPY_SCRIPT"

if [ "$GENERATE_ONLY" != "1" ] && [ "$DO_INSTALL" = "1" ]; then
  set -- "$ENSURE_SCRIPT" --install-if-missing --upgrade-if-newer
  if ! sh "$@"; then
    if [ "$BEST_EFFORT_INSTALL" = "1" ]; then
      warn "Установка zapret завершилась с ошибкой, продолжаю по best-effort."
    else
      die "Не удалось установить zapret"
    fi
  fi
fi

info "Подготовка конфигурации $ZAPRET_LABEL из профиля (списки и $ZAPRET_OPT_KEY)…"
generate_zapret_targets
zapret_engine_persist

if [ "$GENERATE_ONLY" != "1" ]; then
  check_firewall_redirect_conflicts_or_confirm "$COMPUTED_NFQWS_PORTS_TCP" "$COMPUTED_NFQWS_PORTS_UDP"
fi

if [ "$GENERATE_ONLY" = "1" ]; then
  success "zapret apply: генерация списков/managed-конфига выполнена"
  exit 0
fi

if [ "$DO_COPY" = "1" ]; then
  zapret_engine_stop_other
  set -- "$COPY_SCRIPT" --yes
  [ "$NO_RESTART" = "1" ] && set -- "$@" --no-restart
  sh "$@" || die "Не удалось скопировать конфиг zapret"
fi

success "zapret apply: выполнено"
