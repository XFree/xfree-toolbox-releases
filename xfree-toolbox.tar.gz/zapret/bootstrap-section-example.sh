#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib.sh"

SECTION_NAME="${1:-example}"
SECTION_NAME="$(common_normalize_token "$SECTION_NAME")"
[ -n "$SECTION_NAME" ] || die "Некорректное имя секции"

profile_cfg="$(zapret_profile_root)/zapret"
[ -f "$profile_cfg" ] || die "Не найден файл: $profile_cfg"

zapret_init_section_conf_if_missing "$SECTION_NAME"
zapret_init_section_text_if_missing "$SECTION_NAME"
zapret_load_section_conf "$SECTION_NAME"

tmp_dpi="$(mktemp)"
trap 'rm -f "$tmp_dpi"' EXIT INT TERM

awk '
  BEGIN { in_opt=0 }
  /^[[:space:]]*option[[:space:]]+NFQWS_OPT[[:space:]]+'\''/ { in_opt=1; next }
  in_opt {
    if ($0 ~ /^[[:space:]]*'\''$/) { exit }
    if ($0 ~ /^[[:space:]]*--dpi-/) print $0
  }
' "$profile_cfg" | awk '!seen[$0]++' > "$tmp_dpi"

if [ -s "$tmp_dpi" ]; then
  cp -f "$tmp_dpi" "$ZAPRET_SECTION_TEXT_FILE"
  success "Секция '$SECTION_NAME' обновлена из NFQWS_OPT: $ZAPRET_SECTION_TEXT_FILE"
else
  warn "В NFQWS_OPT не найдено --dpi-* строк; оставлен default section.text"
fi

info "Пример секции: $(zapret_ensure_section_dirs "$SECTION_NAME")"
