#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib.sh"

info "== Zapret: синхронизация UCI → runtime =="
zapret_sync_config_or_die
success "Конфиг zapret синхронизирован ($(zapret_sync_config_script))."
