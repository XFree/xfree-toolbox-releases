#!/bin/sh
# shellcheck shell=sh
# Zapret2 menu: same zapret UI, engine=zapret2 (nfqws2 / remittor zapret2).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

# shellcheck disable=SC1090
. "$ROOT_DIR/lib/ui.sh"

ui_have_whiptail || {
	echo "[!] whiptail не установлен" >&2
	exit 1
}

export ZAPRET_ENGINE=zapret2
# `sh` so WSL /mnt/d does not depend on +x or a shebang.
exec sh "$SCRIPT_DIR/menu.gen.sh" "${1:-ui}"
