#!/bin/sh
# shellcheck shell=sh
# Применить pending-секции: пересобрать артефакты в профиле и полностью скопировать в runtime.
# Канон: zapret/apply.sh --copy-only (generate + copy-config + restart).
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/ui.sh"
. "$SCRIPT_DIR/lib.sh"

# UI-обёртка: pending-секции → confirm → zapret_apply_profile_to_runtime (lib.sh).

main() {
    ui_init
    ui_trap_cleanup_on_exit

    if zapret_is_profile_generator_host_lists; then
        ui_msgbox "Zapret: host" "На host (profile-generator) apply недоступен.

Списки уже в profile-templates/.
Runtime apply — на роутере (xft → zapret) или после deploy профиля."
        exit 0
    fi

    changed_sections="$(zapret_build_pending_sections_list)"
    [ -n "${changed_sections:-}" ] || {
        ui_msgbox "Zapret: применение" "Нет изменившихся секций для применения."
        exit 0
    }

    pending_n="$(printf '%s\n' "$changed_sections" | grep -c .)"
    [ "${pending_n:-0}" -gt 0 ] || pending_n=0

    confirm_msg="Ожидают применения секции ($pending_n шт.):

$changed_sections

Пересобрать артефакты в профиле, скопировать конфиг и списки в runtime ($ZAPRET_RUNTIME_UCI_FILE, $ZAPRET_IPSET_DIR/) и перезапустить $ZAPRET_LABEL?"

    if ! ui_confirm "Zapret: применение" "$confirm_msg"; then
        exit 0
    fi

    if ! zapret_apply_profile_to_runtime; then
        ui_msgbox "Zapret: применение" "Не удалось применить zapret (apply.sh --copy-only).

См. вывод выше или лог в /tmp."
        exit 1
    fi

    zapret_clear_pending_sections_queue
    ui_msgbox "Zapret: применение" "Применение завершено.

Секций в очереди: $pending_n
Профиль → runtime: полное копирование (generate + copy-config + restart)."
}

main "$@"
