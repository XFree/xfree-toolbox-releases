#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$ROOT_DIR/lib/ui.sh"
. "$ROOT_DIR/lib/upstreams.sh"
. "$SCRIPT_DIR/lib.sh"

# Same pin as dns-routing/select-lists.sh / iface-routing/selection-ui.sh.
UPSTREAMS_DIR="$(common_resolve_path "$ROOT_DIR" "${UPSTREAMS_DIR:-upstreams}")"
export UPSTREAMS_DIR

DEBUG_LOG="${XFREE_ZAPRET_SELECT_LOG:-/tmp/xfree-toolbox/zapret-select.log}"
CHANGED_SECTIONS_FILE="${XFREE_ZAPRET_CHANGED_SECTIONS_FILE:-/tmp/xfree-toolbox/zapret-changed-sections.lst}"

debug_log() {
    common_append_log_file "$DEBUG_LOG" "[zapret/select-lists] $*"
}

normalize_list_stream() {
    kind="$1"
    file="$2"
    case "$kind" in
        fqdn)
            common_norm_domains_stream < "$file"
            ;;
        prefix)
            tr -d '\r' < "$file" | sed '/^[[:space:]]*$/d; /^[[:space:]]*[#;]/d; s/[[:space:]]\+#.*$//'
            ;;
        *)
            tr -d '\r' < "$file"
            ;;
    esac
}

# BusyBox на OpenWrt 24/25 без cksum(1); md5sum/sha256sum — штатные апплеты.
list_dir_stream_sig() {
    if command -v md5sum >/dev/null 2>&1; then
        md5sum | awk '{print $1}'
    elif command -v sha256sum >/dev/null 2>&1; then
        sha256sum | awk '{print $1}'
    else
        awk 'BEGIN { h = 5381 }
        {
            for (i = 1; i <= length($0); i++) {
                n = index("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-", substr($0, i, 1))
                h = (h * 33 + n) % 2147483647
            }
            h = (h * 33 + 10) % 2147483647
        }
        END { print h }'
    fi
}

build_dir_signature() {
    kind="$1"
    dir="$2"
    out="$3"
    apply_af_filter="${4:-0}"
    disable_ipv4="${5:-0}"
    disable_ipv6="${6:-0}"
    : > "$out"
    [ -d "$dir" ] || return 0

    for f in "$dir"/*.lst; do
        [ -f "$f" ] || continue
        base="$(basename "$f")"
        if [ "$kind" = "prefix" ] && [ "$apply_af_filter" = "1" ]; then
            case "$base" in
                *__ipv6.lst) [ "$disable_ipv6" = "1" ] && continue ;;
                *__ipv4.lst) [ "$disable_ipv4" = "1" ] && continue ;;
            esac
        fi
        sig="$(normalize_list_stream "$kind" "$f" | sort -u | list_dir_stream_sig)"
        printf '%s|%s\n' "$base" "$sig" >> "$out"
    done
    sort -u "$out" -o "$out"
}

list_dirs_differ() {
    kind="$1"
    left_dir="$2"
    right_dir="$3"

    left_sig="$(mktemp)"
    right_sig="$(mktemp)"
    if [ "$kind" = "prefix" ]; then
        dv4="$(zapret_read_profile_template_option DISABLE_IPV4 0)"
        dv6="$(zapret_read_profile_template_option DISABLE_IPV6 0)"
        # Слева (профиль) — полная сигнатура; справа (staged) — без файлов, отключённых DISABLE_IPV* (как при merge в apply).
        build_dir_signature "$kind" "$left_dir" "$left_sig" 0 0 0
        build_dir_signature "$kind" "$right_dir" "$right_sig" 1 "$dv4" "$dv6"
    else
        build_dir_signature "$kind" "$left_dir" "$left_sig"
        build_dir_signature "$kind" "$right_dir" "$right_sig"
    fi
    if cmp -s "$left_sig" "$right_sig"; then
        rm -f "$left_sig" "$right_sig"
        return 1
    fi
    rm -f "$left_sig" "$right_sig"
    return 0
}

mark_section_changed() {
    section="$1"
    mkdir -p "$(dirname -- "$CHANGED_SECTIONS_FILE")"
    touch "$CHANGED_SECTIONS_FILE"
    if ! awk -v s="$section" '$0==s{found=1} END{exit(found?0:1)}' "$CHANGED_SECTIONS_FILE"; then
        printf '%s\n' "$section" >> "$CHANGED_SECTIONS_FILE"
    fi
}

count_nonempty_lines() {
    upstreams_count_nonempty_lines "$1"
}

count_staged_lists() {
    upstreams_count_staged_lists "$1"
}

# Abort before replace_dir if user selected tags but nothing was copied from upstream.
zapret_guard_staging_before_apply() {
    choices_file="$1"
    staged_fqdn="$2"
    staged_prefix="$3"

    if ! upstreams_staging_selection_mismatch "$choices_file" "$staged_fqdn" "$staged_prefix"; then
        return 0
    fi

    selected_n="$(upstreams_count_nonempty_lines "$choices_file")"
    ui_msgbox "Zapret: ошибка материализации" "$(upstreams_staging_mismatch_message "$choices_file")"
    debug_log "zapret_guard_staging_before_apply: selected=$selected_n staged=0"
    return 1
}

# $6 = direct: без доп. подтверждений (выбор в чеклисте уже явное действие), без msgbox «нет изменений».
apply_staged_lists_to_profile() {
    section="$1"
    kind="$2"
    label="$3"
    target_dir="$4"
    staged_dir="$5"
    apply_mode="${6:-}"

    if ! list_dirs_differ "$kind" "$target_dir" "$staged_dir"; then
        if [ "$apply_mode" != "direct" ]; then
            ui_msgbox "Zapret: $label" "Изменений не обнаружено для секции '$section'."
        fi
        return 1
    fi

    if [ "$apply_mode" != "direct" ]; then
        if ! ui_confirm "Zapret: $label" "Скопировать измененные списки в профиль для секции '$section'?"; then
            ui_msgbox "Zapret: $label" "Копирование в профиль отменено."
            return 1
        fi
    fi

    upstreams_replace_dir_from_staged "$target_dir" "$staged_dir"
    mark_section_changed "$section"
    return 0
}

section_edit_text() {
    section="$1"
    zapret_load_section_conf "$section"
    text_file="$ZAPRET_SECTION_TEXT_FILE"
    [ -f "$text_file" ] || zapret_init_section_text_if_missing "$section"

    editor="${EDITOR:-}"
    if [ -z "${editor:-}" ]; then
        if command -v nano >/dev/null 2>&1; then
            editor="nano"
        elif command -v vi >/dev/null 2>&1; then
            editor="vi"
        elif command -v vim >/dev/null 2>&1; then
            editor="vim"
        fi
    fi

    if [ -z "${editor:-}" ]; then
        ui_msgbox "Zapret: редактор" "Не найден текстовый редактор.

Установите nano или vi, либо задайте переменную EDITOR."
        debug_log "section_edit_text: no editor found"
        return 0
    fi

    debug_log "section_edit_text: editor=$editor file=$text_file"
    old_sig="$(zapret_profile_section_config_sig "$section")"
    ui_prepare_tty
    "$editor" "$text_file" || true
    ui_prepare_tty
    new_sig="$(zapret_profile_section_config_sig "$section")"
    if [ "$old_sig" != "$new_sig" ]; then
        mark_section_changed "$section"
    fi
}

section_show_text() {
    section="$1"
    zapret_load_section_conf "$section"
    text_file="$ZAPRET_SECTION_TEXT_FILE"
    [ -f "$text_file" ] || zapret_init_section_text_if_missing "$section"
    ui_show_textbox "Zapret: текст секции '$section'" "$text_file" 28 110
}

section_enabled_status() {
    section="$1"
    # Быстрый путь: без mkdir/migrate/. conf (см. zapret_load_section_conf) —
    # иначе меню секций тормозит на десятках youtube_*.
    slug="$(common_normalize_token "$section")"
    conf_path="$(zapret_sections_root)/$slug/config/section.conf"
    if [ -n "$slug" ] && [ -f "$conf_path" ] \
        && ! _zapret_section_enabled_quick "$conf_path"; then
        printf 'OFF\n'
    else
        printf 'ON\n'
    fi
}

section_set_enabled() {
    section="$1"
    enabled="$2"
    conf_path="$(zapret_section_conf_path "$section")"
    [ -f "$conf_path" ] || zapret_init_section_conf_if_missing "$section"

    tmp="${conf_path}.tmp.$$"
    awk -v val="$enabled" '
        BEGIN { set=0 }
        /^ZAPRET_SECTION_ENABLED=/ { print "ZAPRET_SECTION_ENABLED='\''" val "'\''"; set=1; next }
        { print }
        END { if (set==0) print "ZAPRET_SECTION_ENABLED='\''" val "'\''" }
    ' "$conf_path" > "$tmp"
    mv "$tmp" "$conf_path"
}

section_set_conf_value() {
    section="$1"
    key="$2"
    value="$3"
    conf_path="$(zapret_section_conf_path "$section")"
    [ -f "$conf_path" ] || zapret_init_section_conf_if_missing "$section"

    tmp="${conf_path}.tmp.$$"
    awk -v k="$key" -v v="$value" '
        BEGIN { set=0 }
        $0 ~ ("^" k "=") { print k "='\''" v "'\''"; set=1; next }
        { print }
        END { if (set==0) print k "='\''" v "'\''" }
    ' "$conf_path" > "$tmp"
    mv "$tmp" "$conf_path"
}

section_get_conf_value() {
    section="$1"
    key="$2"
    conf_path="$(zapret_section_conf_path "$section")"
    [ -f "$conf_path" ] || zapret_init_section_conf_if_missing "$section"
    awk -F"'" -v k="$key" '$1 == k "=" { print $2; exit }' "$conf_path"
}

section_toggle_enabled() {
    section="$1"
    current="$(section_enabled_status "$section")"
    if [ "$current" = "ON" ]; then
        section_set_enabled "$section" 0
        ui_msgbox "Zapret: секция" "Секция '$section' деактивирована."
        debug_log "section_toggle_enabled: section=$section -> OFF"
    else
        section_set_enabled "$section" 1
        ui_msgbox "Zapret: секция" "Секция '$section' активирована."
        debug_log "section_toggle_enabled: section=$section -> ON"
    fi
}

ensure_exclude_placeholder() {
    section="$1"
    zapret_load_section_conf "$section"
    text_file="$ZAPRET_SECTION_TEXT_FILE"
    [ -f "$text_file" ] || zapret_init_section_text_if_missing "$section"

    if awk '/\{\{SELECT_EXCLUDE_LIST\}\}/ { found=1 } END { exit(found ? 0 : 1) }' "$text_file"; then
        return 0
    fi

    tmp="${text_file}.tmp.$$"
    awk '
        {
            print $0
            if (added==0 && $0 ~ /\{\{SELECT_FQDN_LIST\}\}|\{\{SELECT_LIST\}\}|\{\{HOSTLIST\}\}/) {
                print "{{SELECT_EXCLUDE_LIST}}"
                added=1
            }
        }
        END {
            if (added==0) print "{{SELECT_EXCLUDE_LIST}}"
        }
    ' "$text_file" > "$tmp"
    mv "$tmp" "$text_file"
}

select_exclude_list_for_section() {
    section="$1"
    section_dir="$(zapret_ensure_section_dirs "$section")"
    exclude_dir="$section_dir/fqdn.exclude.d"
    ZAPRET_UI_EXCLUDE_DIR="$exclude_dir"
    mkdir -p "$exclude_dir"

    tmp_dir="$(mktemp -d)"
    trap 'rm -rf "$tmp_dir"' EXIT INT TERM
    upstreams_build_model_tsv "$ROOT_DIR" "$tmp_dir/entities.tsv" "$tmp_dir/files.tsv"

    map_tmp="$tmp_dir/exclude-map.tsv"
    ui_upstreams_build_label_map "$tmp_dir/entities.tsv" "$map_tmp" "fqdn_only"
    [ -s "$map_tmp" ] || {
        debug_log "select_exclude_list_for_section: no fqdn entities in exclude-map"
        ui_msgbox "Zapret: exclude" "Для exclude не найдено ни одной fqdn-сущности в upstream."
        return 0
    }

    enabled_tags_tsv="$tmp_dir/enabled-tags.tsv"
    upstreams_build_enabled_tags_tsv \
        "zapret" \
        "$tmp_dir/files.tsv" \
        "$exclude_dir" \
        "" \
        "fqdn_only" > "$enabled_tags_tsv"

    # Keep EXIT/INT/TERM trap across checklist (slang SIGINT on Ok; ui-ux-contract).
    if ! selected_tags="$(ui_upstreams_select_tags_from_model \
        "Zapret: exclude для секции '$section'" \
        "Выберите exclude upstream-списки (fqdn)" \
        "$tmp_dir/entities.tsv" \
        "$tmp_dir/files.tsv" \
        "fqdn_only" \
        "" \
        "$enabled_tags_tsv")"; then
        return 2
    fi

    tmp_choices="$tmp_dir/choices.lst"
    printf '%s\n' "${selected_tags:-}" > "$tmp_choices"

    if [ ! -s "$tmp_choices" ]; then
        rm -f "$exclude_dir"/*.lst 2>/dev/null || true
        section_set_conf_value "$section" "ZAPRET_SECTION_EXCLUDE_TAG" ""
        ensure_exclude_placeholder "$section"
        mark_section_changed "$section"
        ui_msgbox "Zapret: exclude" "Exclude-списки для секции '$section' очищены."
        return 0
    fi

    staged_dir="$tmp_dir/staged-exclude"
    mkdir -p "$staged_dir"
    chosen_tags="$tmp_dir/chosen-tags.lst"
    : > "$chosen_tags"
    while IFS= read -r tag; do
        [ -n "${tag:-}" ] || continue
        printf '%s\n' "$tag" >> "$chosen_tags"
        upstreams_stage_tag_files_from_model \
            "zapret" \
            "$tag" \
            "$tmp_dir/files.tsv" \
            "$staged_dir" \
            "" \
            "fqdn_only"
    done < "$tmp_choices"

    zapret_guard_staging_before_apply "$tmp_choices" "$staged_dir" "" || return 1

    tags_csv="$(sort -u "$chosen_tags" 2>/dev/null | awk 'BEGIN{f=1} { if(!f) printf ","; printf "%s",$0; f=0 } END{ printf "\n" }')"
    section_set_conf_value "$section" "ZAPRET_SECTION_EXCLUDE_TAG" "$(printf '%s' "$tags_csv" | tr -d '\r')"
    ensure_exclude_placeholder "$section"
    apply_staged_lists_to_profile "$section" "fqdn" "exclude" "$exclude_dir" "$staged_dir" "direct" || return 0
}

select_or_create_section() {
    debug_log "select_or_create_section: start"
    tmp_all="$(mktemp)"
    tmp_on="$(mktemp)"
    tmp_off="$(mktemp)"
    trap 'rm -f "$tmp_all" "$tmp_on" "$tmp_off"' EXIT INT TERM
    : > "$tmp_on"
    : > "$tmp_off"

    zapret_iter_sections > "$tmp_all"

    # ON сверху, внутри групп — порядок sections.order (zapret_iter_sections).
    while IFS= read -r section; do
        [ -n "${section:-}" ] || continue
        status="$(section_enabled_status "$section" || echo OFF)"
        if [ "$status" = "ON" ]; then
            printf '%s\n' "$section" >> "$tmp_on"
        else
            printf '%s\n' "$section" >> "$tmp_off"
        fi
    done < "$tmp_all"

    set --
    idx=1
    while IFS= read -r section; do
        [ -n "${section:-}" ] || continue
        set -- "$@" "$idx" "[ON] $section"
        eval "ZAPRET_SECTION_$idx='$section'"
        idx=$((idx + 1))
    done < "$tmp_on"
    while IFS= read -r section; do
        [ -n "${section:-}" ] || continue
        set -- "$@" "$idx" "[OFF] $section"
        eval "ZAPRET_SECTION_$idx='$section'"
        idx=$((idx + 1))
    done < "$tmp_off"

    set -- "$@" "N" "+ создать новую секцию"
    debug_log "select_or_create_section: options_count=$#"
    choice="$(ui_menu "Zapret: выбор секции" "Выберите секцию для настройки списков" 20 100 12 "$@" || true)"
    [ -n "${choice:-}" ] || return 1

    debug_log "select_or_create_section: choice=$choice"
    if [ "$choice" = "N" ]; then
        raw="$(ui_inputbox "Новая секция zapret" "Введите имя секции (slug):" "" || true)"
        raw="$(printf '%s' "${raw:-}" | tr -d '\r')"
        section="$(common_normalize_token "$raw")"
        [ -n "${section:-}" ] || return 1
        zapret_init_section_conf_if_missing "$section"
        debug_log "select_or_create_section: created=$section"
        printf '%s\n' "$section"
        return 0
    fi

    eval "selected=\${ZAPRET_SECTION_$choice:-}"
    [ -n "${selected:-}" ] || return 1
    debug_log "select_or_create_section: selected=$selected"
    printf '%s\n' "$selected"
}

select_lists_for_section() {
    section="$1"
    debug_log "select_lists_for_section: section=$section"
    section_dir="$(zapret_ensure_section_dirs "$section")"
    fqdn_dir="$section_dir/fqdn.d"
    prefix_dir="$section_dir/prefixes.d"
    ZAPRET_UI_FQDN_DIR="$fqdn_dir"
    ZAPRET_UI_PREFIX_DIR="$prefix_dir"

    tmp_dir="$(mktemp -d)"
    trap 'rm -rf "$tmp_dir"' EXIT INT TERM

    upstreams_build_model_tsv "$ROOT_DIR" "$tmp_dir/entities.tsv" "$tmp_dir/files.tsv"
    debug_log "select_lists_for_section: entities_tsv_size=$(wc -c < "$tmp_dir/entities.tsv" 2>/dev/null || echo 0)"
    [ -s "$tmp_dir/entities.tsv" ] || {
        debug_log "select_lists_for_section: no_entities"
        ui_msgbox "Zapret: выбор списков" "Не найдены доступные upstream-списки."
        return 1
    }

    sel_disable_ipv4="$(zapret_read_profile_template_option DISABLE_IPV4 0)"
    sel_disable_ipv6="$(zapret_read_profile_template_option DISABLE_IPV6 0)"

    enabled_tags_tsv="$tmp_dir/enabled-tags.tsv"
    upstreams_build_enabled_tags_tsv \
        "zapret" \
        "$tmp_dir/files.tsv" \
        "$fqdn_dir" \
        "$prefix_dir" \
        "all" \
        "$sel_disable_ipv4" \
        "$sel_disable_ipv6" > "$enabled_tags_tsv"

    # Keep EXIT/INT/TERM trap across checklist (slang SIGINT on Ok; ui-ux-contract).
    if ! selected_tags="$(ui_upstreams_select_tags_from_model \
        "Zapret: списки для секции '$section'" \
        "Выберите upstream-списки для секции '$section'" \
        "$tmp_dir/entities.tsv" \
        "$tmp_dir/files.tsv" \
        "all" \
        "" \
        "$enabled_tags_tsv")"; then
        debug_log "select_lists_for_section: checklist_cancelled"
        return 2
    fi
    debug_log "select_lists_for_section: selected_raw=$(printf '%s' "$selected_tags" | tr '\n' ';')"

    tmp_choices="$tmp_dir/choices.lst"
    printf '%s\n' "$selected_tags" > "$tmp_choices"

    staged_fqdn="$tmp_dir/staged-fqdn"
    staged_prefix="$tmp_dir/staged-prefix"
    mkdir -p "$staged_fqdn" "$staged_prefix"

    while IFS= read -r tag; do
        [ -n "${tag:-}" ] || continue

        upstreams_stage_tag_files_from_model \
            "zapret" \
            "$tag" \
            "$tmp_dir/files.tsv" \
            "$staged_fqdn" \
            "$staged_prefix" \
            "all" \
            "$sel_disable_ipv4" \
            "$sel_disable_ipv6"
    done < "$tmp_choices"

    zapret_guard_staging_before_apply "$tmp_choices" "$staged_fqdn" "$staged_prefix" || return 1

    apply_staged_lists_to_profile "$section" "fqdn" "upstream fqdn" "$fqdn_dir" "$staged_fqdn" "direct" || true
    apply_staged_lists_to_profile "$section" "prefix" "upstream prefix" "$prefix_dir" "$staged_prefix" "direct" || true
    fqdn_count="$(ls -1 "$fqdn_dir"/*.lst 2>/dev/null | wc -l | awk '{print $1}')"
    prefix_count="$(ls -1 "$prefix_dir"/*.lst 2>/dev/null | wc -l | awk '{print $1}')"
    debug_log "select_lists_for_section: saved fqdn=$fqdn_count prefix=$prefix_count"
}

main() {
    ui_init
    ui_trap_cleanup_on_exit

    section="${1:-}"
    if [ -z "${section:-}" ]; then
        section="$(select_or_create_section || true)"
    fi
    [ -n "${section:-}" ] || exit 0

    while true; do
        status="$(section_enabled_status "$section" || echo OFF)"
        if zapret_is_profile_generator_host_lists; then
            action="$(ui_menu "Zapret: секция '$section' [$status] · host" "Шаблон profile-templates (без apply на /etc)" 20 100 12 \
                "1" "Выбрать upstream-списки" \
                "2" "Выбрать exclude-список" \
                "3" "Редактировать текст секции (nano)" \
                "4" "Показать текущий текст секции" \
                "5" "Активировать/Деактивировать секцию" \
                "0" "Назад" || true)"
        else
            action="$(ui_menu "Zapret: секция '$section' [$status]" "Выберите действие" 20 100 12 \
                "1" "Выбрать upstream-списки" \
                "2" "Выбрать exclude-список" \
                "3" "Редактировать текст секции (nano)" \
                "4" "Показать текущий текст секции" \
                "5" "Активировать/Деактивировать секцию" \
                "6" "Применить изменившиеся секции" \
                "0" "Назад" || true)"
        fi

        [ -n "${action:-}" ] || exit 0
        case "$action" in
            1) select_lists_for_section "$section" ;;
            2) select_exclude_list_for_section "$section" ;;
            3) section_edit_text "$section" ;;
            4) section_show_text "$section" ;;
            5) section_toggle_enabled "$section" ;;
            6)
                if zapret_is_profile_generator_host_lists; then
                    ui_msgbox "Zapret: host" "На host (profile-generator) apply недоступен.

Списки уже сохранены в profile-templates/.
Применение runtime — на роутере (xft → zapret) или после deploy профиля."
                else
                    sh "$SCRIPT_DIR/apply-changed-sections.sh" || true
                fi
                ;;
            0) exit 0 ;;
        esac
    done
}

if [ "${0##*/}" = "select-lists.sh" ]; then
    main "$@"
fi
