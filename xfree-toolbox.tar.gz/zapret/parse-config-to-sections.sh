#!/bin/sh
# shellcheck shell=sh
set -eu

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
ROOT_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd -P)"

. "$ROOT_DIR/lib/common.sh"
. "$SCRIPT_DIR/lib.sh"

PROFILE_DIR="$(common_profile_dir "$ROOT_DIR" "${PROFILE_DIR:-}")"
PROFILE_ZAPRET_DIR="$PROFILE_DIR/zapret"
PROFILE_CFG="$PROFILE_ZAPRET_DIR/zapret"
PROFILE_IPSET_DIR="$PROFILE_ZAPRET_DIR/ipset"
SECTIONS_DIR="$PROFILE_ZAPRET_DIR/sections"
EXAMPLE_CFG_OUT="$PROFILE_ZAPRET_DIR/zapret.generated.example"
CLEAN=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --clean) CLEAN=1 ;;
    *) die "Неизвестный аргумент: $1" ;;
  esac
  shift
done

[ -f "$PROFILE_CFG" ] || die "Не найден zapret config: $PROFILE_CFG"
mkdir -p "$SECTIONS_DIR"
if [ "$CLEAN" = "1" ] && [ -d "$SECTIONS_DIR" ]; then
  rm -rf "$SECTIONS_DIR"
  mkdir -p "$SECTIONS_DIR"
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT INT TERM
BLOCKS_META="$TMP_DIR/blocks.meta.tsv"
SECTION_LIST="$TMP_DIR/sections.list"

ui_known_file() {
  case "$1" in
    zapret-hosts-google.txt|zapret-hosts-googlevideo.txt|zapret-hosts-user.txt|zapret-hosts-user-exclude.txt|zapret-ip-exclude.txt|zapret-ip-user.txt|zapret-ip-user-exclude.txt|cust1.txt|cust2.txt|cust3.txt|cust4.txt)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

canonical_section_from_stem() {
  stem="$1"
  s="$stem"
  case "$s" in
    zapret-hosts-*) s="${s#zapret-hosts-}" ;;
    zapret-ip-*) s="${s#zapret-ip-}" ;;
    fqdn-*) s="${s#fqdn-}" ;;
    prefixes-ipv4-*) s="${s#prefixes-ipv4-}" ;;
    prefixes-ipv6-*) s="${s#prefixes-ipv6-}" ;;
    prefixes4-*) s="${s#prefixes4-}" ;;
    prefixes6-*) s="${s#prefixes6-}" ;;
    prefixes-*) s="${s#prefixes-}" ;;
  esac
  common_normalize_token "$s"
}

new_payload_file() {
  idx="$1"
  printf '%s/payload.%s.txt\n' "$TMP_DIR" "$idx"
}

emit_block() {
  idx="$1"
  kind="$2"
  target="$3"
  active="$4"
  payload_file="$5"
  filter_tcp="$6"
  filter_udp="$7"

  [ -n "$kind" ] || return 0
  [ -n "$target" ] || return 0

  [ -n "$filter_tcp" ] || filter_tcp="-"
  [ -n "$filter_udp" ] || filter_udp="-"
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$idx" "$kind" "$target" "$active" "$payload_file" "$filter_tcp" "$filter_udp" >> "$BLOCKS_META"
}

: > "$BLOCKS_META"
in_opt=0
block_idx=0
block_kind=""
block_target=""
block_active=1
block_filter_tcp=""
block_filter_udp=""
payload_file="$(new_payload_file "$block_idx")"
: > "$payload_file"

while IFS= read -r raw_line || [ -n "$raw_line" ]; do
  line="$(printf '%s' "$raw_line" | tr -d '\r')"

  if [ "$in_opt" = "0" ]; then
    case "$line" in
      *"option NFQWS_OPT '"*) in_opt=1 ;;
    esac
    continue
  fi

  case "$line" in
    "'"|"' "*)
      emit_block "$block_idx" "$block_kind" "$block_target" "$block_active" "$payload_file" "$block_filter_tcp" "$block_filter_udp"
      break
      ;;
  esac

  trimmed="$(printf '%s' "$line" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
  [ -n "$trimmed" ] || continue

  cmd=""
  cmd_active=1
  case "$trimmed" in
    \#--*)
      cmd="${trimmed#\#}"
      cmd_active=0
      ;;
    --*)
      cmd="$trimmed"
      cmd_active=1
      ;;
    *)
      continue
      ;;
  esac

  if [ "$cmd" = "--new" ]; then
    emit_block "$block_idx" "$block_kind" "$block_target" "$block_active" "$payload_file" "$block_filter_tcp" "$block_filter_udp"
    block_idx=$((block_idx + 1))
    block_kind=""
    block_target=""
    block_active="$cmd_active"
    block_filter_tcp=""
    block_filter_udp=""
    payload_file="$(new_payload_file "$block_idx")"
    : > "$payload_file"
    continue
  fi

  case "$cmd" in
    --hostlist=*)
      block_kind="hostlist"
      block_target="${cmd#--hostlist=}"
      block_active="$cmd_active"
      continue
      ;;
    --ipset=*)
      block_kind="ipset"
      block_target="${cmd#--ipset=}"
      block_active="$cmd_active"
      continue
      ;;
    --filter-tcp=*)
      block_filter_tcp="${cmd#--filter-tcp=}"
      continue
      ;;
    --filter-udp=*)
      block_filter_udp="${cmd#--filter-udp=}"
      continue
      ;;
  esac

  printf '%s\n' "$cmd" >> "$payload_file"
done < "$PROFILE_CFG"

[ -s "$BLOCKS_META" ] || die "Не удалось распарсить NFQWS_OPT блоки"

section_meta_set() {
  section="$1"
  key="$2"
  val="$3"
  printf '%s\n' "$val" > "$TMP_DIR/section.$section.$key"
}

section_meta_get() {
  section="$1"
  key="$2"
  path="$TMP_DIR/section.$section.$key"
  [ -f "$path" ] || return 1
  cat "$path"
}

remember_section_meta() {
  section="$1"
  kind="$2"
  src_name="$3"
  active="$4"

  host_explicit=""
  ipset_explicit=""
  if ui_known_file "$src_name"; then
    [ "$kind" = "hostlist" ] && host_explicit="$src_name"
    [ "$kind" = "ipset" ] && ipset_explicit="$src_name"
  fi

  if ! awk -v s="$section" '$0==s { found=1 } END { exit(found?0:1) }' "$SECTION_LIST"; then
    printf '%s\n' "$section" >> "$SECTION_LIST"
  fi

  cur_host="$(section_meta_get "$section" host 2>/dev/null || true)"
  cur_ipset="$(section_meta_get "$section" ipset 2>/dev/null || true)"
  cur_enabled="$(section_meta_get "$section" enabled 2>/dev/null || printf '0')"

  [ -n "$host_explicit" ] || host_explicit="$cur_host"
  [ -n "$ipset_explicit" ] || ipset_explicit="$cur_ipset"
  [ "$active" = "1" ] && cur_enabled=1

  if [ -n "$host_explicit" ]; then
    section_meta_set "$section" host "$host_explicit"
  fi
  if [ -n "$ipset_explicit" ]; then
    section_meta_set "$section" ipset "$ipset_explicit"
  fi
  section_meta_set "$section" enabled "${cur_enabled:-0}"
}

: > "$SECTION_LIST"
while IFS="$(printf '\t')" read -r idx kind target active payload_file filter_tcp filter_udp; do
  [ -n "${kind:-}" ] || continue
  [ -n "${target:-}" ] || continue
  [ -f "${payload_file:-}" ] || continue

  src_name="$(basename "$target")"
  stem="${src_name%.*}"
  section="$(canonical_section_from_stem "$stem")"
  [ -n "$section" ] || continue

  remember_section_meta "$section" "$kind" "$src_name" "$active"

  section_dir="$(zapret_ensure_section_dirs "$section")"
  zapret_init_section_conf_if_missing "$section"
  zapret_init_section_text_if_missing "$section"

  init_flag="$TMP_DIR/section.$section.initialized"
  if [ ! -f "$init_flag" ]; then
    : > "$section_dir/config/section.text"
    : > "$init_flag"
  fi

  block_tpl="$TMP_DIR/block.$idx.tpl"
  : > "$block_tpl"
  echo "--new" >> "$block_tpl"
  [ "${filter_tcp:-}" != "-" ] && echo "--filter-tcp=$filter_tcp" >> "$block_tpl"
  [ "${filter_udp:-}" != "-" ] && echo "--filter-udp=$filter_udp" >> "$block_tpl"
  echo "{{SELECT_LIST}}" >> "$block_tpl"
  [ -f "$payload_file" ] && cat "$payload_file" >> "$block_tpl"

  cat "$block_tpl" >> "$section_dir/config/section.text"

  src_path="$PROFILE_IPSET_DIR/$src_name"
  if [ "$kind" = "hostlist" ]; then
    dst_path="$section_dir/fqdn.d/${stem}__from-config.lst"
  else
    dst_path="$section_dir/prefixes.d/${stem}__from-config.lst"
  fi
  [ -f "$src_path" ] && cp -f "$src_path" "$dst_path"
done < "$BLOCKS_META"

while IFS= read -r section; do
  [ -n "${section:-}" ] || continue
  conf_path="$SECTIONS_DIR/$section/config/section.conf"
  [ -f "$conf_path" ] || continue
  host_explicit="$(section_meta_get "$section" host 2>/dev/null || true)"
  ipset_explicit="$(section_meta_get "$section" ipset 2>/dev/null || true)"
  enabled="$(section_meta_get "$section" enabled 2>/dev/null || printf '0')"
  {
    printf "ZAPRET_SECTION_NAME='%s'\n" "$section"
    printf "ZAPRET_SECTION_ENABLED='%s'\n" "${enabled:-1}"
    if [ -n "${host_explicit:-}" ]; then
      printf "ZAPRET_SECTION_HOST_FILE='%s'\n" "$host_explicit"
    fi
    if [ -n "${ipset_explicit:-}" ]; then
      printf "ZAPRET_SECTION_IPSET_FILE='%s'\n" "$ipset_explicit"
    fi
  } > "$conf_path"
done < "$SECTION_LIST"

{
  echo "# autogenerated example from NFQWS_OPT blocks"
  echo "config main 'config'"
  echo "	option NFQWS_OPT '"
} > "$EXAMPLE_CFG_OUT"

while IFS="$(printf '\t')" read -r idx kind target active payload_file filter_tcp filter_udp; do
  [ -n "${kind:-}" ] || continue
  [ -n "${target:-}" ] || continue

  src_name="$(basename "$target")"
  stem="${src_name%.*}"
  section="$(canonical_section_from_stem "$stem")"
  [ -n "$section" ] || continue
  zapret_load_section_conf "$section"

  runtime_target="$target"
  if [ "$kind" = "hostlist" ]; then
    runtime_target="/opt/zapret/ipset/$ZAPRET_SECTION_HOST_FILE"
  elif [ "$kind" = "ipset" ]; then
    runtime_target="/opt/zapret/ipset/$ZAPRET_SECTION_IPSET_FILE"
  fi

  enabled="${ZAPRET_SECTION_ENABLED:-1}"
  [ "${active:-1}" = "1" ] || enabled=0
  prefix=""
  [ "$enabled" = "1" ] || prefix="#"

  printf '%s# ZAPRET_SECTION_NAME='\''%s'\'' target=%s\n' "$prefix" "$section" "$kind" >> "$EXAMPLE_CFG_OUT"
  printf '%s--new\n' "$prefix" >> "$EXAMPLE_CFG_OUT"
  [ "${filter_tcp:-}" != "-" ] && printf '%s--filter-tcp=%s\n' "$prefix" "$filter_tcp" >> "$EXAMPLE_CFG_OUT"
  [ "${filter_udp:-}" != "-" ] && printf '%s--filter-udp=%s\n' "$prefix" "$filter_udp" >> "$EXAMPLE_CFG_OUT"
  if [ "$kind" = "hostlist" ]; then
    printf '%s--hostlist=%s\n' "$prefix" "$runtime_target" >> "$EXAMPLE_CFG_OUT"
  else
    printf '%s--ipset=%s\n' "$prefix" "$runtime_target" >> "$EXAMPLE_CFG_OUT"
  fi
  [ -f "${payload_file:-}" ] && sed '/^[[:space:]]*$/d; /^[[:space:]]*[#;]/d' "$payload_file" | sed "s/^/$prefix/" >> "$EXAMPLE_CFG_OUT"
done < "$BLOCKS_META"

echo "	'" >> "$EXAMPLE_CFG_OUT"

success "Структура секций собрана из $PROFILE_CFG"
info "Секции: $SECTIONS_DIR"
info "Пример конфига: $EXAMPLE_CFG_OUT"
