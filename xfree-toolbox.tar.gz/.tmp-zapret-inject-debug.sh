#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
ROOT=/root/xfree-toolbox
cp -f "$ROOT/zapret/apply.sh" /tmp/apply.sh.bak

# Use awk to inject debug after fqdn sync line
awk '
  { print }
  /common_sync_dir_mirror "\$section_dir\/fqdn\.d" "\$state_section_dir\/fqdn\.d"/ {
    print "    if [ \"$section\" = \"youtube_29\" ] || [ \"$section\" = \"discord\" ] || [ \"$section\" = \"user\" ]; then"
    print "      info \"DEBUG $section section_dir=$section_dir state_dir=$state_section_dir\""
    print "      info \"DEBUG profile_n=$(ls -1 \"$section_dir/fqdn.d\" 2>/dev/null | wc -l) state_n=$(ls -1 \"$state_section_dir/fqdn.d\" 2>/dev/null | wc -l)\""
    print "      ls -la \"$section_dir/fqdn.d\" 2>&1 | head -8"
    print "      ls -la \"$state_section_dir/fqdn.d\" 2>&1 | head -8"
    print "      find \"$section_dir/fqdn.d\" -mindepth 1 -maxdepth 1 -type f 2>&1 | head -8"
    print "    fi"
  }
' /tmp/apply.sh.bak > "$ROOT/zapret/apply.sh"

export XFREE_APPLY_PROFILE_DIR=/root/xfree-toolbox/profiles/default
/root/xfree-toolbox/zapret/apply.sh --yes --generate-only 2>&1 | tee /tmp/zapret-debug-gen.log | grep -E 'DEBUG|Секция .(youtube_29|discord|user|cdn-host)' | head -80

echo '=== profile youtube_29 still has list? ==='
ls -la /root/xfree-toolbox/profiles/default/zapret/sections/youtube_29/fqdn.d/

cp -f /tmp/apply.sh.bak "$ROOT/zapret/apply.sh"
REMOTE
