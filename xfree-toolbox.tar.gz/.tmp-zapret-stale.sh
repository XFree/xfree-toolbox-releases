#!/bin/sh
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
. ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo "=== profile sections.order ==="
cat /root/xfree-toolbox/profiles/default/zapret/sections.order
echo "=== state sections dirs ==="
ls /root/xfree-toolbox/state/zapret/state/sections 2>/dev/null || ls /root/xfree-toolbox/state/zapret/sections 2>/dev/null || true
echo "=== orphans (in state dir, not in order) ==="
ORDER=/root/xfree-toolbox/profiles/default/zapret/sections.order
SEC=
if [ -d /root/xfree-toolbox/state/zapret/state/sections ]; then
  SEC=/root/xfree-toolbox/state/zapret/state/sections
elif [ -d /root/xfree-toolbox/state/zapret/sections ]; then
  SEC=/root/xfree-toolbox/state/zapret/sections
fi
echo "SEC=$SEC"
for d in "$SEC"/*; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  if ! grep -qx "$id" "$ORDER" 2>/dev/null; then
    echo "ORPHAN $id"
  fi
done
echo "=== profile section dirs missing from order ==="
for d in /root/xfree-toolbox/profiles/default/zapret/sections/*; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  if ! grep -qx "$id" "$ORDER" 2>/dev/null; then
    echo "PROFILE_ORPHAN $id"
  fi
done
REMOTE
