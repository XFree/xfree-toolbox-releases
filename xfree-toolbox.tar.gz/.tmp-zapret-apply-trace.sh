#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo '=== profile zapret NFQWS_OPT (materialized) hostlist count ==='
grep -c hostlist /root/xfree-toolbox/profiles/default/zapret/zapret || true
grep -E 'hostlist|SECTIONS' /root/xfree-toolbox/profiles/default/zapret/zapret | head -20
echo '=== template has SECTIONS_BLOCK? ==='
grep -n SECTIONS /root/xfree-toolbox/profiles/default/zapret/zapret.template || true
cat /root/xfree-toolbox/profiles/default/zapret/zapret.template
echo '=== discord section.text (shared?) ==='
cat /root/xfree-toolbox/profiles/default/zapret/sections/discord/config/section.text 2>&1 | head -40
echo '=== youtube_29 section.text ==='
cat /root/xfree-toolbox/profiles/default/zapret/sections/youtube_29/config/section.text 2>&1 | head -40
echo '=== enabled youtube count in profile ==='
c=0
for d in /root/xfree-toolbox/profiles/default/zapret/sections/youtube_*; do
  en=$(awk -F"'" '/^ZAPRET_SECTION_ENABLED=/ {print $2; exit}' "$d/config/section.conf")
  [ "$en" = 1 ] && c=$((c+1))
  echo "$(basename "$d") ENABLED=$en hf=$(awk -F"'" '/^ZAPRET_SECTION_HOST_FILE=/ {print $2; exit}' "$d/config/section.conf")"
done | head -40
echo "enabled_youtube=$c"
echo '=== profile ipset sizes ==='
ls -la /root/xfree-toolbox/profiles/default/zapret/ipset 2>&1 | head -40
wc -l /root/xfree-toolbox/profiles/default/zapret/ipset/zapret-hosts-google.txt 2>&1 || true
echo '=== generate dry: sync one section manually ==='
# show common_sync if available
. /root/xfree-toolbox/lib/common.sh 2>/dev/null || true
type common_sync_dir_mirror 2>&1 | head -5 || true
echo '=== last apply log today ==='
grep -E '2026-10-04|zapret apply|Секция|hostlist=|generate|copy-config|NFQWS' /etc/xfree-toolbox/system/auto-update.log 2>/dev/null | tail -80 || true
# find other logs from today apply
find /tmp /etc/xfree-toolbox -name '*.log' -mtime -1 2>/dev/null | head -30
ls -lt /root/xfree-toolbox/profiles/default/zapret/ipset 2>&1 | head -15
REMOTE
