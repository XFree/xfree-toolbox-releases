#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB="${ROUTER_TARGET_DIR:-/root/xfree-toolbox}"
BASE=build/openwrt/luci-app-xfree-toolbox/htdocs/luci-static/resources
scp "${SCP_OPTS[@]}" \
  iface-routing/luci-rpc.sh \
  "$SSH_TARGET:$TB/iface-routing/luci-rpc.sh"
scp "${SCP_OPTS[@]}" \
  build/openwrt/xfree-toolbox/files/usr/libexec/rpcd/xfree-toolbox \
  "$SSH_TARGET:/usr/libexec/rpcd/xfree-toolbox"
scp "${SCP_OPTS[@]}" \
  "$BASE/xfree-toolbox/luci-ui.js" \
  "$SSH_TARGET:/www/luci-static/resources/xfree-toolbox/luci-ui.js"
scp "${SCP_OPTS[@]}" \
  "$BASE/view/xfree-toolbox/shell.js" \
  "$SSH_TARGET:/www/luci-static/resources/view/xfree-toolbox/shell.js"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
VER=/usr/share/ucode/luci/version.uc
BUST=$(date +%s)
if grep -q "xfreebust" "$VER" 2>/dev/null; then
  sed -i "s/xfreebust[0-9]*/xfreebust${BUST}/" "$VER"
else
  sed -i "s/export const revision = '\\([^']*\\)'/export const revision = '\\1-xfreebust${BUST}'/" "$VER"
fi
rm -f /tmp/luci-indexcache* 2>/dev/null || true
rm -rf /tmp/luci-modulecache 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true
/etc/init.d/uhttpd reload 2>/dev/null || true
echo "=== whitelist ==="
grep -o 'applyRouting' /usr/libexec/rpcd/xfree-toolbox | head -1
grep -n 'action_apply_routing\|applyRouting)' /root/xfree-toolbox/iface-routing/luci-rpc.sh | head -5
grep -n 'onWizardApply\|Применить' /www/luci-static/resources/xfree-toolbox/luci-ui.js | head -10
grep -n 'v=20261006b' /www/luci-static/resources/view/xfree-toolbox/shell.js
echo "=== dry invoke help path ==="
test -f /root/xfree-toolbox/lib/apply-dns-and-iface-routing.sh && echo apply_wrapper=ok
REMOTE
