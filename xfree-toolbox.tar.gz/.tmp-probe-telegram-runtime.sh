#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
P=/root/xfree-toolbox/profiles/default/iface-routing/interfaces
G=/etc/xfree-toolbox/iface-routing/generated/interfaces
S=/etc/xfree-toolbox/iface-routing/interfaces

echo "=== profile tele ==="
for iface in proton warp warp3; do
  echo "--- $iface ---"
  ls "$P/$iface/fqdn.d" 2>/dev/null | grep -i tele || echo "(no tele in profile fqdn.d)"
done

echo
echo "=== generated maps tele ==="
for iface in proton warp warp3; do
  echo "--- $iface ---"
  if [ -f "$G/$iface/fqdn.sources.map" ]; then
    grep -i tele "$G/$iface/fqdn.sources.map" | head -10 || echo "(no tele in generated map)"
  else
    echo "(no generated map)"
  fi
done

echo
echo "=== state tele ==="
for iface in proton warp warp3; do
  echo "--- $iface ---"
  ls "$S/$iface/fqdn.d" 2>/dev/null | grep -i tele || echo "(no tele in state fqdn.d)"
done

echo
echo "=== ip rules / nft sets warp3 ==="
ip rule show | grep -E '0x120|xfree' || true
nft list sets 2>/dev/null | grep -E 'warp3|proton_fqdn|warp_fqdn' | head -30 || true

echo
echo "=== sample telegram domains in nft (proton/warp) ==="
for setname in proton_fqdn4 warp_fqdn4 warp3_fqdn4; do
  echo "-- $setname --"
  nft list set inet xfree-routing "$setname" 2>/dev/null | grep -iE 'telegram|t\.me|cdn-telegram' | head -8 || echo "(set missing or no tele)"
done
REMOTE
