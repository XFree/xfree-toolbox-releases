#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
SCP_OPTS=()
router_ssh_session_scp_opts SCP_OPTS
TB=/root/xfree-toolbox
scp "${SCP_OPTS[@]}" zapret/lib.sh zapret/apply.sh "$SSH_TARGET:$TB/zapret/"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
export XFREE_APPLY_PROFILE_DIR=/root/xfree-toolbox/profiles/default
export PROFILE_DIR=/root/xfree-toolbox/profiles/default
echo '=== generate+copy apply ==='
/root/xfree-toolbox/zapret/apply.sh --yes --copy-only 2>&1 | tee /tmp/zapret-fix-apply.log | grep -E 'Секция .(youtube_29|user|discord|cdn-host)|hostlist=|готово|скопир|ERROR|FAIL' | head -40
echo '=== counts ==='
wc -l /root/xfree-toolbox/profiles/default/zapret/ipset/zapret-hosts-google.txt \
  /root/xfree-toolbox/profiles/default/zapret/ipset/xfree-discord-hosts.txt \
  /opt/zapret/ipset/zapret-hosts-google.txt \
  /etc/xfree-toolbox/zapret/state/sections/youtube_29/fqdn.d/*.lst 2>&1
echo '=== NFQWS hostlist lines ==='
grep -c 'hostlist=' /etc/config/zapret || true
grep -E 'hostlist=' /etc/config/zapret | head -15
echo '=== traffic-path youtube ==='
/root/xfree-toolbox/diagnostics/traffic-path.sh trace cdn.youtube.com | head -c 1200
echo
REMOTE
