#!/bin/sh
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
. ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"

ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
echo "=== version.uc ==="
cat /usr/share/ucode/luci/version.uc
echo "=== search 1790953379 ==="
grep -R "1790953379" /usr /www /etc 2>/dev/null | head || true
echo "=== luci.js url / v= ==="
grep -n "urlArgs\|?v=\|distrevision\|luciversion\|cache\|revision" /www/luci-static/resources/luci.js | head -40
echo "=== runtime env ==="
grep -n "distrevision\|luciversion\|revision\|resource" /usr/share/ucode/luci/runtime.uc | head -40
echo "=== dispatcher env inject ==="
grep -n "distrevision\|luciversion\|L\.env\|script.*v=" /usr/share/ucode/luci/dispatcher.uc | head -40
# find in templates
grep -Rn "distrevision\|luciversion\|?v=" /usr/share/ucode/luci/template 2>/dev/null | head -40
echo "=== apk times ==="
apk info -vv luci-app-xfree-toolbox 2>/dev/null | head || true
stat -c '%Y %n' /www/luci-static/resources/xfree-toolbox/traffic-map.js /usr/share/ucode/luci/version.uc 2>/dev/null || ls -le /www/luci-static/resources/xfree-toolbox/traffic-map.js
# compute: is 1790953379 related to file?
python3 - <<'PY' 2>/dev/null || true
import os, time
print("now", int(time.time()))
print("1790953379 ->", time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(1790953379)))
print("mtime traffic", os.path.getmtime("/www/luci-static/resources/xfree-toolbox/traffic-map.js"))
PY
REMOTE
