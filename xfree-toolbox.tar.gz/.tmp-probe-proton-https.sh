#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE' || true
set +e
echo "=== map lines for proton* ==="
grep -E 'proton' /etc/xfree-toolbox/dns-routing/generated/dns-redirects.map 2>/dev/null | head -20
echo "=== dnsmasq conf proton ==="
grep -nE 'proton' /var/etc/dnsmasq.conf* /etc/dnsmasq.d/xfree-toolbox-routing/* 2>/dev/null | head -20
echo "=== curl account.protonvpn.com ==="
curl -sI --connect-timeout 10 --max-time 15 https://account.protonvpn.com/ 2>&1 | head -15
echo "=== done ==="
REMOTE
