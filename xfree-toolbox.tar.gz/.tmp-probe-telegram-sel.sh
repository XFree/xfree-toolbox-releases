#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
P=/root/xfree-toolbox/profiles/default/iface-routing/interfaces
echo "=== telegram-related lists in profile ==="
for iface in proton warp warp3; do
  echo "--- $iface ---"
  find "$P/$iface" -type f \( -name '*telegram*' -o -name '*tele*' \) 2>/dev/null | sort || true
  ls "$P/$iface/fqdn.d" 2>/dev/null | grep -i tele || echo "(no tele in fqdn.d)"
  ls "$P/$iface/prefixes.d" 2>/dev/null | grep -i tele || echo "(no tele in prefixes.d)"
done
echo
echo "=== generated telegram ==="
G=/etc/xfree-toolbox/iface-routing/generated/interfaces
for iface in proton warp warp3; do
  echo "--- $iface gen ---"
  [ -d "$G/$iface" ] || { echo "(no generated dir)"; continue; }
  find "$G/$iface" -type f -name '*tele*' 2>/dev/null | sort || true
  ls "$G/$iface" 2>/dev/null | head -20
done
echo
echo "=== selection index / meta if any ==="
find /root/xfree-toolbox/profiles/default/iface-routing -name '*selection*' -o -name '*upstream*' 2>/dev/null | head -30
echo
echo "=== warp3 runtime again ==="
. /root/xfree-toolbox/diagnostics/lib/traffic-path.sh
TRAFFIC_PATH_ROOT=/root/xfree-toolbox
traffic_path_init_paths
traffic_path_runtime_iface warp3 2>/dev/null || true
echo
echo "=== ip rule / nft for warp3 ==="
grep -E 'MARK_HEX|NFT_FQDN|ROUTE_TABLE' "$P/warp3/config/iface.conf" 2>/dev/null || true
ip rule show 2>/dev/null | grep -i warp3 || ip rule show 2>/dev/null | grep -E '0x12|lookup' | head -20
nft list sets inet fw4 2>/dev/null | grep -i warp3 || true
REMOTE
