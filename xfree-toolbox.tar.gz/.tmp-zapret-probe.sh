#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE'
set -eu
S=/etc/xfree-toolbox/zapret/state/sections
echo '=== youtube_29 state ==='
ls -la "$S/youtube_29" "$S/youtube_29/config" "$S/youtube_29/fqdn.d" 2>&1 | head -40
echo '--- section.conf ---'
cat "$S/youtube_29/config/section.conf" 2>&1 || true
echo '--- fqdn.d ---'
ls -la "$S/youtube_29/fqdn.d" 2>&1 || true
wc -l "$S/youtube_29/fqdn.d"/*.lst 2>/dev/null || echo 'no lst'
echo '--- generated ---'
ls -la /etc/xfree-toolbox/zapret/generated/sections/youtube_29 2>&1 | head -20
echo '=== HOST_FILE refs for youtube* with cdn.youtube ==='
for d in "$S"/youtube_*; do
  [ -d "$d" ] || continue
  id=$(basename "$d")
  conf="$d/config/section.conf"
  [ -f "$conf" ] || continue
  en=$(awk -F"'" '/^ZAPRET_SECTION_ENABLED=/ {print $2; exit}' "$conf")
  hf=$(awk -F"'" '/^ZAPRET_SECTION_HOST_FILE=/ {print $2; exit}' "$conf")
  [ "${en:-1}" = 0 ] && continue
  n_state=0
  [ -d "$d/fqdn.d" ] && n_state=$(find "$d/fqdn.d" -name '*.lst' -type f 2>/dev/null | wc -l)
  n_hf=0
  [ -n "$hf" ] && [ -f "/opt/zapret/ipset/$hf" ] && n_hf=$(wc -l <"/opt/zapret/ipset/$hf")
  yt=0
  [ -n "$hf" ] && [ -f "/opt/zapret/ipset/$hf" ] && yt=$(grep -c 'youtube\|googlevideo' "/opt/zapret/ipset/$hf" 2>/dev/null || true)
  echo "$id en=${en:-1} hf=$hf state_lst=$n_state hf_lines=$n_hf yt_in_hf=$yt"
done | head -40
echo '=== which hostfile has cdn.youtube.com ==='
grep -rl 'cdn.youtube.com' /opt/zapret/ipset 2>/dev/null | head -20 || echo none
echo '=== uci zapret NFQWS sample ==='
uci show zapret 2>/dev/null | grep -E 'NFQWS|hostlist|nfqws_opt|enabled' | head -40
echo '=== nft zapret / queue ==='
nft list ruleset 2>/dev/null | grep -iE 'zapret|nfq|queue|desync' | head -40 || true
echo '=== iptables mangle queue (legacy) ==='
iptables -t mangle -S 2>/dev/null | grep -iE 'NFQUEUE|zapret|MARK' | head -30 || true
ip6tables -t mangle -S 2>/dev/null | grep -iE 'NFQUEUE|zapret|MARK' | head -15 || true
echo '=== procd zapret ==='
ps w | grep -E 'nfqws|zapret' | grep -v grep | head -20
REMOTE
