#!/usr/bin/env bash
set -eu
cd /mnt/d/tools/routers/openwrt/xfree-utils
# shellcheck disable=SC1091
source ci/lib/router-ssh-session.sh
router_ssh_session_source_dependencies "$(pwd)"
set -- --key bluehome
while [ $# -gt 0 ]; do
  rc=0
  router_ssh_session_parse_common_option "$1" || rc=$?
  if [ "$rc" -eq 2 ]; then
    opt="$1"
    shift
    router_ssh_session_parse_common_option_value "$opt" "${1:-}"
  fi
  shift || true
done
trap router_ssh_session_cleanup EXIT INT TERM
router_ssh_session_bootstrap "$(pwd)"
ssh "${SSH_OPTS[@]}" "$SSH_TARGET" sh -s <<'REMOTE' || true
set +e
echo "=== dhcp server list ==="
uci -q get dhcp.@dnsmasq[0].server
echo
echo "=== state dns instances with xft / proton ==="
find /etc/xfree-toolbox/dns-routing -type f -name '*xft*' 2>/dev/null
find /etc/xfree-toolbox -path '*dns*' -name '*xft*' 2>/dev/null | head
for d in /etc/xfree-toolbox/dns-routing/state/dns/*/fqdn.d /etc/xfree-toolbox/*/dns-routing/*/fqdn.d; do
  [ -d "$d" ] || continue
  if grep -lqiE 'protonvpn|proton\.me' "$d"/*.lst 2>/dev/null; then
    echo "HIT $d"
    grep -nHiE 'proton' "$d"/*.lst 2>/dev/null
  fi
done
echo "=== profile work dns? ==="
find /etc/xfree-toolbox -type d -name 'dns.google' 2>/dev/null | head
find /etc/xfree-toolbox -type d -name 'google-dns-no-doh' 2>/dev/null | head
find /etc/xfree-toolbox -type d -name 'cloudflare-dns-no-doh' 2>/dev/null | head
echo "=== nslookup account via local / google doh port ==="
nslookup account.protonvpn.com 127.0.0.1 2>&1 | head -15
# busybox nslookup may not support port; use dig or curl to https-dns via dns-query protocol hard — use socat?
if command -v dig >/dev/null 2>&1; then
  dig @127.0.0.1 -p 5062 account.protonvpn.com A +short
  dig @127.0.0.1 -p 5058 account.protonvpn.com A +short
fi
# probe DoH google instance via curl to local? https-dns-proxy speaks DNS on 5062
if command -v nc >/dev/null 2>&1 || command -v busybox >/dev/null 2>&1; then
  :
fi
echo "=== curl google doh still ok ==="
curl -sG --connect-timeout 8 --max-time 12 \
  --data-urlencode 'name=account.protonvpn.com' --data-urlencode 'type=A' \
  'https://dns.google/resolve' 2>&1 | head -c 300; echo
echo "=== done4 ==="
REMOTE
