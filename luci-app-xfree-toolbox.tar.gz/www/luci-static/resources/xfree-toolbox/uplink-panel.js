'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.console-output';
'require xfree-toolbox.uplink-cards as uplinkCards';
'require xfree-toolbox.uplink-fields as uplinkFields';
'require xfree-toolbox.uplink-view as uplinkView';

/* Экран мониторинга канала usb-power-watch (uplink).
 * Карточки туннелей, форма настроек и сборка интерфейса живут
 * в соседних модулях и вешаются на один прототип xfree-uplink. */

var TAG = 'xfree-uplink';

var UplinkPanel = class extends wc.LightElement {
};

function mixUplink(part) {
	prototypeMix.mixInto(UplinkPanel.prototype, part);
}

mixUplink(uplinkCards);
mixUplink(uplinkFields);
mixUplink(uplinkView);

wc.define(TAG, UplinkPanel);

return baseclass.extend({
	tag: TAG
});
