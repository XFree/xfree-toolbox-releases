'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-uplink';

var FIELD_GROUPS = [
	{
		id: 'monitor',
		title: _('Мониторинг'),
		fields: [
			{ id: 'ENABLED', title: _('Включён (ENABLED)'), type: 'toggle', hint: _('1 = опрос разрешён; нужен cron') },
			{ id: 'LED_STATUS', title: _('LED статус'), type: 'toggle', hint: _('blue:wan / red:fault') },
			{ id: 'INTERVAL_MIN', title: _('Период cron, мин'), type: 'number', min: 1, max: 60 },
			{ id: 'PROBE_INTERVAL_SEC', title: _('Интервал probe, с'), type: 'number', min: 5, max: 300 }
		]
	},
	{
		id: 'probe',
		title: _('Проверка канала'),
		fields: [
			{ id: 'PROBE_IFACE', title: _('Интерфейс probe'), type: 'text', hint: _('auto / wan / lte…') },
			{ id: 'TEST_URL', title: _('Базовый URL'), type: 'text' },
			{ id: 'TEST_URL_ALT', title: _('Доп. URL (полный интернет)'), type: 'text' },
			{ id: 'FAIL_MAX', title: _('Порог FAIL → USB/recovery'), type: 'number', min: 1, max: 20 }
		]
	},
	{
		id: 'vpn',
		title: _('VPN / туннели'),
		fields: [
			{ id: 'TUNNEL_PROBE_ENABLED', title: _('Probe VPN'), type: 'toggle' },
			{ id: 'TUNNEL_ICMP_FAIL_MAX', title: _('FAIL до restart'), type: 'number', min: 1, max: 20 },
			{ id: 'TUNNEL_BOUNCE_MAX', title: _('Макс. restart'), type: 'number', min: 1, max: 20 },
			{ id: 'TUNNEL_BOUNCE_RETRY_MIN', title: _('Пауза до повтора, мин'), type: 'number', min: 0, max: 120 },
			{ id: 'TUNNEL_PROBE_SETTLE_SEC', title: _('Settle после restart, с'), type: 'number', min: 1, max: 300 },
			{
				id: 'PROTON_GUEST_RENEW',
				title: _('Proton guest renew'),
				type: 'select',
				options: [
					{ v: 'expiry', t: 'expiry' },
					{ v: 'tunnel-fail', t: 'tunnel-fail' },
					{ v: 'both', t: 'both' },
					{ v: 'off', t: 'off' }
				]
			}
		]
	},
	{
		id: 'dns',
		title: _('DNS / резолв'),
		fields: [
			{ id: 'DNS_PROBE_ENABLED', title: _('Проверка DNS'), type: 'toggle', hint: _('1 = резолв хостов в каждом тике cron') },
			{ id: 'DNS_PROBE_HOSTS', title: _('Хосты для проверки'), type: 'textarea', rows: 5, hint: _('Домены для проверки локальным резолвером (127.0.0.1), по одному на строку') }
		]
	},
	{
		id: 'usb',
		title: _('USB power-cycle'),
		expert: true,
		fields: [
			{
				id: 'POWER_CYCLE',
				title: _('Режим'),
				type: 'select',
				options: [
					{ v: 'auto', t: 'auto' },
					{ v: 'on', t: 'on' },
					{ v: 'off', t: 'off' }
				]
			},
			{ id: 'CYCLE_MAX', title: _('Макс. попыток'), type: 'number', min: 0, max: 20 },
			{ id: 'OFF_SEC', title: _('OFF, с'), type: 'number', min: 1, max: 60 },
			{ id: 'ON_SEC', title: _('ON, с'), type: 'number', min: 1, max: 60 },
			{ id: 'SETTLE_SEC', title: _('Settle, с'), type: 'number', min: 10, max: 600 }
		]
	}
];

function evalTone(runtime) {
	var ev = String((runtime && runtime.last_probe_eval) || '');

	if (ev === '0')
		return 'ok';
	if (ev === '1')
		return 'bad';
	if (ev === '2')
		return 'warn';
	return 'muted';
}

function parseTunnelDetail(rawStatus, text) {
	var s = String(text || '').trim();
	var out = {
		rawStatus: rawStatus || '—',
		ok: /^OK$/i.test(rawStatus),
		paused: '',
		ping: '',
		pingOk: null,
		hs: '',
		hsOk: null,
		failCount: '',
		failMax: '',
		bounceCount: '',
		bounceMax: '',
		lastAction: '',
		isProtonGuest: false,
		guestSess: '',
		guestCert: ''
	};

	var m;
	if ((m = s.match(/paused\s*(?:\(([^)]+)\))?/i))) {
		out.paused = m[1] || 'paused';
	}

	if ((m = s.match(/\bping=([A-Za-z0-9—]+)/i))) {
		out.ping = m[1];
		out.pingOk = /^ok$/i.test(m[1]) ? true : (/^fail$/i.test(m[1]) ? false : null);
	}

	if ((m = s.match(/\bhs=([A-Za-z0-9—]+)/i))) {
		out.hs = m[1];
		out.hsOk = /^ok$/i.test(m[1]) ? true : (/^fail$/i.test(m[1]) ? false : null);
	}

	if ((m = s.match(/\bfail=([0-9]+)\/([0-9]+)/))) {
		out.failCount = m[1];
		out.failMax = m[2];
	}

	if ((m = s.match(/\bbounce=([0-9]+)\/([0-9]+)/))) {
		out.bounceCount = m[1];
		out.bounceMax = m[2];
	}

	if ((m = s.match(/\blast=([A-Za-z0-9_-]+)/))) {
		if (m[1] !== 'none') {
			out.lastAction = m[1];
		}
	}

	if (/\bproton=guest\b/i.test(s)) {
		out.isProtonGuest = true;
	}

	if ((m = s.match(/\bsess=([A-Za-z0-9_-]+)/))) {
		out.guestSess = m[1];
	}

	if ((m = s.match(/\bcert=([0-9]{4})-([0-9]{2})-([0-9]{2})/))) {
		out.guestCert = m[3] + '.' + m[2] + '.' + m[1];
	}

	return out;
}

function parseTunnelLines(text) {
	var lines = String(text || '').split(/\n/);
	var out = [];
	var i;
	var m;

	for (i = 0; i < lines.length; i++) {
		m = lines[i].match(/^\s*-\s*([A-Za-z0-9._-]+)\s*:\s*(\S+)(?:\s+(.*))?$/);
		if (!m)
			continue;
		var rawStatus = m[2];
		var detail = String(m[3] || '');
		out.push({
			name: m[1],
			ok: /^OK$/i.test(rawStatus) ? 1 : 0,
			detail: detail,
			info: parseTunnelDetail(rawStatus, detail)
		});
	}

	return out;
}

function renderTunnelCard(tunnel) {
	var info = tunnel.info || {};
	var name = tunnel.name;
	var isOk = !!tunnel.ok;
	var tone = isOk ? 'ok' : (info.paused ? 'warn' : 'bad');

	var icon = '🌐';
	var typeName = '';
	if (/proton/i.test(name)) {
		icon = '🛡️';
		typeName = 'Proton VPN';
	} else if (/warp/i.test(name)) {
		icon = '⚡';
		typeName = 'Cloudflare WARP';
	}

	var statusLabel = isOk ? 'OK' : (info.paused ? _('Пауза (%s)').format(info.paused) : _('Сбой'));

	var pills = [];
	if (info.ping && info.ping !== '—') {
		pills.push(E('div', {
			'class': 'xfree-tunnel-pill' + (info.pingOk === true ? ' is-ok' : (info.pingOk === false ? ' is-bad' : ''))
		}, [
			E('span', { 'class': 'pill-k' }, [ 'Ping' ]),
			E('span', { 'class': 'pill-v' }, [ info.ping.toUpperCase() ])
		]));
	}

	if (info.hs && info.hs !== '—') {
		pills.push(E('div', {
			'class': 'xfree-tunnel-pill' + (info.hsOk === true ? ' is-ok' : (info.hsOk === false ? ' is-bad' : ''))
		}, [
			E('span', { 'class': 'pill-k' }, [ 'Handshake' ]),
			E('span', { 'class': 'pill-v' }, [ info.hs.toUpperCase() ])
		]));
	}

	if (info.failCount && (info.failCount !== '0' || !isOk)) {
		pills.push(E('div', { 'class': 'xfree-tunnel-pill is-bad' }, [
			E('span', { 'class': 'pill-k' }, [ _('Сбои') ]),
			E('span', { 'class': 'pill-v' }, [ info.failCount + ' / ' + info.failMax ])
		]));
	}

	if (info.bounceCount && info.bounceCount !== '0') {
		pills.push(E('div', { 'class': 'xfree-tunnel-pill is-warn' }, [
			E('span', { 'class': 'pill-k' }, [ _('Рестарты') ]),
			E('span', { 'class': 'pill-v' }, [ info.bounceCount + ' / ' + info.bounceMax ])
		]));
	}

	if (info.lastAction) {
		var actText = info.lastAction === 'bounce' ? _('рестарт') :
		              info.lastAction === 'guest-renew' ? _('renew ключа') :
		              info.lastAction;
		pills.push(E('div', { 'class': 'xfree-tunnel-pill is-warn' }, [
			E('span', { 'class': 'pill-k' }, [ _('Действие') ]),
			E('span', { 'class': 'pill-v' }, [ actText ])
		]));
	}

	var footer = null;
	if (info.isProtonGuest) {
		footer = E('div', { 'class': 'xfree-uplink-tunnel-footer muted' }, [
			E('span', {
				'class': 'xfree-tunnel-session-badge',
				'title': info.guestSess ? _('Сессия: %s').format(info.guestSess) : ''
			}, [
				'🔑 ', _('Proton Guest')
			]),
			info.guestCert ? E('span', { 'class': 'xfree-tunnel-cert-date' }, [
				_('сертификат до %s').format(info.guestCert)
			]) : ''
		]);
	}

	return E('div', {
		'class': 'xfree-uplink-tunnel is-' + tone
	}, [
		E('div', { 'class': 'xfree-uplink-tunnel-top' }, [
			E('div', { 'class': 'xfree-uplink-tunnel-name-wrap' }, [
				E('span', { 'class': 'xfree-uplink-tunnel-ico' }, [ icon ]),
				E('strong', { 'class': 'xfree-uplink-tunnel-name' }, [ name ]),
				typeName ? E('span', { 'class': 'xfree-uplink-tunnel-tag muted' }, [ typeName ]) : ''
			]),
			E('span', { 'class': 'xfree-uplink-tunnel-status is-' + tone }, [
				E('span', { 'class': 'dot' }),
				statusLabel
			])
		]),
		pills.length ? E('div', { 'class': 'xfree-uplink-tunnel-metrics' }, pills) : '',
		footer || ''
	]);
}

function renderDnsHostCard(item) {
	var isOk = item.status === 'ok';
	var isBad = item.status === 'fail';
	var tone = isOk ? 'ok' : (isBad ? 'bad' : 'muted');
	var statusLabel = isOk ? 'OK' : (isBad ? _('FAIL') : '—');

	var pills = [];
	if (item.dns) {
		pills.push(E('div', { 'class': 'xfree-tunnel-pill' }, [
			E('span', { 'class': 'pill-k' }, [ 'DNS' ]),
			E('span', { 'class': 'pill-v' }, [ item.dns ])
		]));
	}
	if (item.route) {
		pills.push(E('div', {
			'class': 'xfree-tunnel-pill' + (/vpn/i.test(item.route) ? ' is-ok' : '')
		}, [
			E('span', { 'class': 'pill-k' }, [ _('Маршрут') ]),
			E('span', { 'class': 'pill-v' }, [ item.route ])
		]));
	}

	return E('div', {
		'class': 'xfree-uplink-tunnel is-' + tone
	}, [
		E('div', { 'class': 'xfree-uplink-tunnel-top' }, [
			E('div', { 'class': 'xfree-uplink-tunnel-name-wrap' }, [
				E('span', { 'class': 'xfree-uplink-tunnel-ico' }, [ '🌐' ]),
				E('strong', { 'class': 'xfree-uplink-tunnel-name' }, [ item.host ]),
				E('span', { 'class': 'xfree-uplink-tunnel-tag muted' }, [ _('DNS') ])
			]),
			E('span', { 'class': 'xfree-uplink-tunnel-status is-' + tone }, [
				E('span', { 'class': 'dot' }),
				statusLabel
			])
		]),
		pills.length ? E('div', { 'class': 'xfree-uplink-tunnel-metrics' }, pills) : ''
	]);
}

function renderTunnelSkeleton() {
	return E('div', { 'class': 'xfree-uplink-tunnel is-skeleton' }, [
		E('div', { 'class': 'xfree-uplink-tunnel-top' }, [
			E('div', { 'class': 'xfree-uplink-tunnel-name-wrap' }, [
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 80px; height: 16px;' })
			]),
			E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 45px; height: 18px;' })
		]),
		E('div', { 'class': 'xfree-uplink-tunnel-metrics' }, [
			E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 70px; height: 22px;' }),
			E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 85px; height: 22px;' })
		])
	]);
}

function fieldValue(settings, id) {
	if (!settings || settings[id] == null)
		return '';
	return String(settings[id]);
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._settings = (spec && spec.settings) || {};
		this._runtime = (spec && spec.runtime) || {};
		this._output = (spec && spec.outputText) || '';
		this._busy = !!(spec && spec.busy);
		this._loading = !!(spec && spec.loading);
		this._msg = (spec && spec.message) || '';
		this.requestPaint();
	}

	setLoading(loading) {
		this._loading = !!loading;
		if (this._spec)
			this._spec.loading = this._loading;
		this.requestPaint();
	}

	setConfig(settings, runtime) {
		this._settings = settings || {};
		this._runtime = runtime || {};
		this._loading = false;
		if (this._spec)
			this._spec.loading = false;
		this.requestPaint();
	}

	setOutputText(text) {
		this._output = text || '';
		var el = this.querySelector('xfree-console.xfree-uplink-log');

		if (el)
			el.text = this._output;
		else
			this.requestPaint();
	}

	setBusy(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button, input, select').forEach(function(el) {
			if (el.getAttribute('data-keep-enabled') === '1')
				return;
			el.disabled = !!busy;
		});
	}

	setMessage(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var el = this.querySelector('[data-xfree-uplink-msg]');

		if (el) {
			el.textContent = this._msg;
			el.className = 'xfree-uplink-msg' + (this._msgTone ? ' is-' + this._msgTone : '');
		}
	}

	collectSettings() {
		var out = {};
		var root = this;

		this.querySelectorAll('[data-xfree-uplink-field]').forEach(function(el) {
			var id = el.getAttribute('data-xfree-uplink-field');
			var typ = el.getAttribute('data-field-type') || 'text';

			if (!id)
				return;
			if (typ === 'toggle')
				out[id] = el.checked ? '1' : '0';
			else if (typ === 'textarea')
				out[id] = String(el.value || '').trim().split(/\s+/).filter(Boolean).join(' ');
			else
				out[id] = String(el.value || '').trim();
		});

		return out;
	}

	_renderField(field, settings) {
		var id = field.id;
		var val = fieldValue(settings, id);
		var control;
		var opts;
		var i;

		if (field.type === 'toggle') {
			control = E('label', { 'class': 'xfree-uplink-toggle' }, [
				E('input', {
					'type': 'checkbox',
					'data-xfree-uplink-field': id,
					'data-field-type': 'toggle',
					'checked': val === '1' ? true : null
				}),
				E('span', { 'class': 'muted' }, [ _('вкл / выкл') ])
			]);
		} else if (field.type === 'select') {
			opts = [];
			for (i = 0; i < (field.options || []).length; i++) {
				opts.push(E('option', {
					'value': field.options[i].v,
					'selected': field.options[i].v === val ? true : null
				}, [ field.options[i].t ]));
			}
			control = E('select', {
				'class': 'xfree-uplink-input',
				'data-xfree-uplink-field': id,
				'data-field-type': 'select'
			}, opts);
		} else if (field.type === 'textarea') {
			var textLines = String(val || '').trim().split(/\s+/).filter(Boolean).join('\n');
			control = E('textarea', {
				'class': 'xfree-uplink-input xfree-uplink-textarea font-mono',
				'rows': field.rows ? String(field.rows) : '5',
				'data-xfree-uplink-field': id,
				'data-field-type': 'textarea',
				'placeholder': 'ya.ru\ngoogle.com\nchatgpt.com\ninstagram.com\nkino.watch\nroblox.com'
			}, [ textLines ]);
		} else {
			control = E('input', {
				'class': 'xfree-uplink-input',
				'type': field.type === 'number' ? 'number' : 'text',
				'data-xfree-uplink-field': id,
				'data-field-type': field.type || 'text',
				'value': val,
				'min': field.min != null ? String(field.min) : null,
				'max': field.max != null ? String(field.max) : null
			});
		}

		var fieldClasses = 'xfree-uplink-field' + (field.type === 'textarea' ? ' is-textarea' : '');
		var fieldStyle = field.type === 'textarea' ? 'grid-column: 1 / -1; max-width: 32rem;' : null;

		/* div wrapper — LuCI themes style bare <label> like CBI titles. */
		return E('div', { 'class': fieldClasses, 'style': fieldStyle }, [
			E('div', { 'class': 'xfree-uplink-field-label' }, [ field.title ]),
			control,
			field.hint ? E('div', { 'class': 'muted xfree-uplink-field-hint' }, [ field.hint ]) : ''
		]);
	}

	render() {
		var s = this._spec || {};
		var view = s.view;
		var expert = !!(s.expert);
		var settings = this._settings || {};
		var runtime = this._runtime || {};
		var onSave = s.onSave;
		var onAction = s.onAction;
		var onRefresh = s.onRefresh;
		var tone = evalTone(runtime);
		var tunnels = parseTunnelLines(runtime.tunnels_text);
		var groups = [];
		var actions = [];
		var chips = [];
		var tunnelChips = [];
		var g;
		var i;
		var fields;
		var consoleEl;
		var evalLabel = runtime.last_probe_eval_label || runtime.last_probe_eval || '—';

		this.className = 'xfree-uplink-root';
		this.setAttribute('data-xfree-uplink', '1');

		var isLoading = !!(s.loading);
		if (isLoading && (!runtime || !runtime.last_probe_eval)) {
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('Канал') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 48px; height: 14px;' }) ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('Cron') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 68px; height: 14px;' }) ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('FAIL') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 40px; height: 14px;' }) ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('Последний тик') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 55px; height: 14px;' }) ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('Probe') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 52px; height: 14px;' }) ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('DNS') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 44px; height: 14px;' }) ])
			]));
		} else {
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-' + tone }, [
				E('span', { 'class': 'k' }, [ _('Канал') ]),
				E('span', { 'class': 'v' }, [ String(evalLabel).toUpperCase() ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' + (runtime.cron === 1 || runtime.cron === '1' ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [ _('Cron') ]),
				E('span', { 'class': 'v' }, [
					(runtime.cron === 1 || runtime.cron === '1')
						? _('каждые %s мин').format(settings.INTERVAL_MIN || '—')
						: _('нет')
				])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [ _('FAIL') ]),
				E('span', { 'class': 'v' }, [
					'%s / %s'.format(runtime.fail_count || '0', settings.FAIL_MAX || '—')
				])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [ _('Последний тик') ]),
				E('span', { 'class': 'v' }, [ runtime.last_tick || '—' ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [ _('Probe') ]),
				E('span', { 'class': 'v' }, [ runtime.probe_iface_label || settings.PROBE_IFACE || '—' ])
			]));

			var dnsTone = 'muted';
			var dnsText = '—';
			if (runtime.dns_probe_status === 'ok' || runtime.last_dns_probe === '1') {
				dnsTone = 'ok';
				dnsText = 'OK';
			} else if (runtime.dns_probe_status === 'fail' || runtime.last_dns_probe === '0') {
				dnsTone = 'bad';
				dnsText = 'FAIL';
			} else if (runtime.dns_probe_status === 'off' || settings.DNS_PROBE_ENABLED === '0') {
				dnsTone = 'muted';
				dnsText = _('ВЫКЛ');
			}

			chips.push(E('div', { 'class': 'xfree-uplink-chip is-' + dnsTone }, [
				E('span', { 'class': 'k' }, [ _('DNS') ]),
				E('span', { 'class': 'v' }, [ dnsText ])
			]));
		}

		if (isLoading && !tunnels.length) {
			tunnelChips.push(renderTunnelSkeleton());
			tunnelChips.push(renderTunnelSkeleton());
		} else {
			for (i = 0; i < tunnels.length; i++) {
				tunnelChips.push(renderTunnelCard(tunnels[i]));
			}
		}

		for (g = 0; g < FIELD_GROUPS.length; g++) {
			if (FIELD_GROUPS[g].expert && !expert)
				continue;
			fields = [];
			for (i = 0; i < FIELD_GROUPS[g].fields.length; i++)
				fields.push(this._renderField(FIELD_GROUPS[g].fields[i], settings));
			groups.push(E('section', { 'class': 'xfree-uplink-group' }, [
				E('h4', {}, [ FIELD_GROUPS[g].title ]),
				E('div', { 'class': 'xfree-uplink-fields' }, fields)
			]));
		}

		actions = [
			E('button', {
				'class': 'btn',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onSave)
						onSave();
				})
			}, [ _('Сохранить настройки') ]),
			E('button', {
				'class': 'ghost' + ((this._loading || this._busy) ? ' is-loading' : ''),
				'type': 'button',
				'disabled': (this._loading || this._busy) ? true : null,
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onRefresh)
						onRefresh();
				})
			}, [
				E('span', { 'class': (this._loading || this._busy) ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + ((this._loading || this._busy) ? _('Обновление…') : _('Обновить статус'))
			]),
			E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('probe', null, _('Запустить полный тик проверки канала?'));
				})
			}, [ _('Проверить сейчас') ]),
			E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('cronOn', null, _('Установить cron и ENABLED=1?'));
				})
			}, [ _('Вкл. cron') ]),
			E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('cronOff', null, _('Снять cron usb-power-watch?'));
				})
			}, [ _('Выкл. cron') ])
		];

		if (expert) {
			actions.push(E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('usbCycle', null, _('USB power-cycle — модем пропадёт на время OFF. Продолжить?'));
				})
			}, [ _('USB cycle') ]));
		}

		consoleEl = E('xfree-console', {
			'label': _('Журнал действия'),
			'class': 'xfree-uplink-log',
			style: '--xfree-console-max-height:28vh'
		});
		consoleEl.text = this._output || '';

		var dnsCards = [];
		var dnsHosts = Array.isArray(runtime.dns_hosts) ? runtime.dns_hosts : [];
		for (i = 0; i < dnsHosts.length; i++) {
			dnsCards.push(renderDnsHostCard(dnsHosts[i]));
		}

		this.replaceChildren(
			E('div', { 'class': 'xfree-uplink-head' }, [
				E('div', {}, [
					E('h3', {}, [ _('Мониторинг канала') ]),
					E('p', { 'class': 'muted' }, [
						_('Параметры usb-power-watch и живой статус. Сохранение пишет conf на роутере.')
					])
				]),
				E('p', {
					'class': 'xfree-uplink-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
					'data-xfree-uplink-msg': '1'
				}, [ this._msg || '' ])
			]),
			E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips),
			tunnelChips.length
				? E('div', { 'class': 'xfree-uplink-tunnels' }, tunnelChips)
				: E('p', { 'class': 'muted' }, [ _('Нет данных probe туннелей') ]),
			dnsCards.length
				? E('div', { 'class': 'xfree-uplink-tunnels' }, dnsCards)
				: '',
			E('div', { 'class': 'xfree-uplink-meta muted' }, [
				runtime.power_cycle_label
					? _('USB: %s').format(runtime.power_cycle_label)
					: '',
				runtime.conf_path
					? E('span', {}, [ ' · ', runtime.conf_path ])
					: ''
			]),
			E('div', { 'class': 'xfree-uplink-groups' }, groups),
			E('div', { 'class': 'xfree-uplink-actions' }, actions),
			consoleEl
		);

		if (this._busy) {
			this.querySelectorAll('button, input, select').forEach(function(el) {
				if (el.getAttribute('data-keep-enabled') === '1')
					return;
				el.disabled = true;
			});
		}
	}
});

return baseclass.extend({
	tag: TAG
});
