'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';

return baseclass.extend({
	mount: function(spec) {
		this._spec = spec || {};
		this._status = (spec && spec.status) || {
			running: false,
			installed: false,
			version: '',
			engine: 'zapret',
			pending: false,
			sections: []
		};
		this._displaySections = this._prepareSections(this._status.sections);
		this._busy = !!(spec && spec.busy);
		this._msg = (spec && spec.message) || '';
		this._msgTone = (spec && spec.messageTone) || '';
		this.setAttribute('data-xfree-zapret', '1');
		this.requestPaint();
	},

	setLoading: function(loading) {
		this._loading = !!loading;
		this.requestPaint();
	},

	setStatus: function(status) {
		this._status = status || {};
		this._status.loaded = true;
		this._loading = false;
		this._displaySections = this._prepareSections(this._status.sections);
		this.requestPaint();
	},

	setBusy: function(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button').forEach(function(el) {
			el.disabled = !!busy;
		});
		this.requestPaint();
	},

	setMessage: function(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		this.requestPaint();
	},

	_act: function(ev, action, arg, confirmText) {
		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}
		var s = this._spec || {};
		if (s.onAction)
			s.onAction(action, arg || '', confirmText || '');
	},

	_renderHeader: function(s, view, st, isRefreshing) {
		var self = this;
		var headActions = [
			xcmp.button({
				variant: 'vpn',
				extraClass: isRefreshing ? 'is-loading' : '',
				disabled: isRefreshing,
				title: _('Обновить состояние Zapret'),
				onClick: function(ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				},
				children: [
					E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, [ '🔄' ]),
					' ' + (isRefreshing ? _('Обновление…') : _('Обновить'))
				]
			}),
			xcmp.button({
				variant: 'vpn',
				title: _('Перейти к выбору списков доменов для Zapret в разделе «Маршруты»'),
				text: '📋 ' + _('Списки'),
				onClick: function(ev) {
					ev.preventDefault();
					if (s.onNavigate)
						s.onNavigate('routing', 'zapret');
					else if (view && view.navigate)
						view.navigate('routing', 'zapret');
				}
			}),
			xcmp.button({
				variant: 'vpn',
				primary: true,
				title: _('Применить изменённые списки Zapret в runtime'),
				text: '⚡ ' + _('Применить списки'),
				onClick: function(ev) {
					self._act(ev, 'applyLists', '',
						_('Применить изменённые секции Zapret (apply-changed-sections)?'));
				}
			})
		];

		return E('div', { 'class': 'page-head' }, [
			E('div', { 'class': 'page-head-main' }, [
				E('p', { 'class': 'eyebrow' }, [ 'XFree toolbox' ]),
				E('h1', {}, [
					_('Zapret'),
					xcmp.badge({
						variant: 'vpn-status',
						tone: st.running ? 'ok' : (st.installed ? 'bad' : 'warn'),
						text: st.running ? _('Активен') : (st.installed ? _('Остановлен') : _('Не установлен')),
						style: 'margin-left: 10px; font-size: 13px; font-weight: normal; vertical-align: middle;'
					})
				])
			]),
			E('div', { 'class': 'page-head-actions', 'style': 'display:flex; align-items:center; gap:8px;' }, [
				E('p', { 'class': 'muted page-head-desc' }, [
					_('Обход блокировок и замедлений (nfqws/tpws)')
				]),
				E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, headActions)
			])
		]);
	},

	_renderStatusChips: function(st, sections, activeCount) {
		var chips = [
			xcmp.chip({
				label: _('Служба'),
				value: st.running ? _('работает') : _('остановлена'),
				tone: st.running ? 'ok' : 'bad',
				extraClass: 'xfree-status-chip'
			}),
			xcmp.chip({
				label: _('Движок'),
				value: st.engine || 'nfqws',
				extraClass: 'xfree-status-chip'
			}),
			xcmp.chip({
				label: _('Версия'),
				value: st.version || '—',
				extraClass: 'xfree-status-chip'
			}),
			xcmp.chip({
				label: _('Секции'),
				value: '%d / %d активны'.format(activeCount, sections.length),
				extraClass: 'xfree-status-chip'
			}),
			xcmp.chip({
				label: _('Списки'),
				value: st.pending ? _('есть изменения *') : _('актуальны'),
				tone: st.pending ? 'warn' : 'ok',
				extraClass: 'xfree-status-chip'
			})
		];

		return E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips);
	},

	_renderOpsSection: function(s, view) {
		var self = this;
		return E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '⚙️ ' + _('Управление службой и списками') ]),
					xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: _('Runtime ops') })
				]),
				E('p', { 'class': 'muted' }, [
					_('Применение списков пересобирает правила DPI на лету. Полный apply выполняет генерацию и перезапуск всех секций.')
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'padding: 8px 0;' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					text: '⚡ ' + _('Применить списки'),
					onClick: function(ev) {
						self._act(ev, 'applyLists', '',
							_('Применить изменённые секции Zapret (apply-changed-sections)?'));
					}
				}),
				xcmp.button({
					variant: 'vpn',
					text: '🚀 ' + _('Выполнить всё'),
					onClick: function(ev) {
						self._act(ev, 'runAll', '',
							_('Выполнить полный пайплайн Zapret (обновить upstream + ensure + apply)?'));
					}
				}),
				xcmp.button({
					variant: 'vpn',
					text: '🔄 ' + _('Применить Zapret'),
					onClick: function(ev) {
						self._act(ev, 'apply', '',
							_('Выполнить полный перезапуск и применение zapret (apply.sh --yes)?'));
					}
				}),
				xcmp.button({
					variant: 'vpn',
					text: '🔁 ' + _('Перезапустить службу'),
					onClick: function(ev) {
						self._act(ev, 'restart', '',
							_('Перезапустить службу Zapret?'));
					}
				}),
				xcmp.button({
					variant: 'vpn',
					text: '📋 ' + _('Настроить списки'),
					onClick: function(ev) {
						ev.preventDefault();
						if (s.onNavigate)
							s.onNavigate('routing', 'zapret');
						else if (view && view.navigate)
							view.navigate('routing', 'zapret');
					}
				}),
				xcmp.button({
					variant: 'vpn',
					text: '📦 ' + _('Проверить / обновить'),
					onClick: function(ev) {
						self._act(ev, 'ensure', '',
							_('Проверить и установить/обновить бинарники zapret (ensure)?'));
					}
				}),
				xcmp.button({
					variant: 'vpn',
					text: '📄 ' + _('Скопировать fake-файлы'),
					onClick: function(ev) {
						self._act(ev, 'copyFake', '',
							_('Скопировать fake *.bin в /opt/zapret и перезапустить zapret?'));
					}
				})
			])
		]);
	},

	render: function() {
		var s = this._spec || {};
		var view = s.view;
		var st = this._status || {};
		var sections = this._displaySections || st.sections || [];
		var nodes = [];

		this.className = 'xfree-vpn-wrap xfree-zapret-wrap';

		/* 1. Page Header */
		var isRefreshing = !!(this._loading || this._busy);
		nodes.push(this._renderHeader(s, view, st, isRefreshing));

		/* Alert / Banner */
		if (this._msg) {
			nodes.push(E('div', {
				'class': 'alert-message ' + (this._msgTone === 'ok' ? 'success' : (this._msgTone === 'warn' ? 'warning' : 'danger')),
				'style': 'margin-bottom: 12px;'
			}, [ this._msg ]));
		}

		/* 2. Top Metric Plaques */
		var activeCount = 0;
		for (var i = 0; i < sections.length; i++) {
			if (sections[i].enabled) activeCount++;
		}
		nodes.push(this._renderStatusChips(st, sections, activeCount));

		/* 3. Section: Управление и применение */
		nodes.push(this._renderOpsSection(s, view));

		/* 4. Section: Диагностика и проверка стратегий */
		nodes.push(this._renderTestCards());

		/* 5. Section: Секции DPI */
		if (sections.length > 0) {
			nodes.push(this._renderSectionsBlock(sections, activeCount));
		}

		this.replaceChildren.apply(this, nodes);
	}
});
