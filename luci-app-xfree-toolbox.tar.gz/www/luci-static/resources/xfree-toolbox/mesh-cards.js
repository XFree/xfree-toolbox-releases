'use strict';
'require baseclass';

return baseclass.extend({
	_renderHeader: function(s, st, isRefreshing) {
		var statusText = _('Автономный роутер');
		var statusTone = 'warn';
		if (st.role === 'master') {
			statusText = _('Mesh Master (основной узел)');
			statusTone = 'ok';
		} else if (st.role === 'satellite') {
			statusText = _('Mesh Satellite (ведомый узел)');
			statusTone = 'ok';
		} else if (st.hasMeshIf && !st.meshDisabled) {
			statusText = _('Mesh Backhaul активен');
			statusTone = 'ok';
		}

		var headActions = [
			E('button', {
				'class': 'ghost ghost-compact' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние беспроводной сети'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				}
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить'))
			])
		];

		return E('div', { 'class': 'page-head' }, [
			E('div', { 'class': 'page-head-main' }, [
				E('p', { 'class': 'eyebrow' }, [ 'XFree toolbox' ]),
				E('h1', {}, [
					_('Беспроводная сеть, Mesh и роуминг'),
					E('span', {
						'class': 'xfree-vpn-status is-' + statusTone,
						'style': 'margin-left: 10px; font-size: 13px; font-weight: normal; vertical-align: middle;'
					}, [ statusText ])
				])
			]),
			E('div', { 'class': 'page-head-actions', 'style': 'display:flex; align-items:center; gap:8px;' }, [
				E('p', { 'class': 'muted page-head-desc' }, [
					_('Раздельная настройка 802.11s backhaul, быстрого роуминга 802.11r/k/v и защиты STP')
				]),
				E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, headActions)
			])
		]);
	},

	_renderChips: function(st, meshActive) {
		var chips = [];
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (meshActive ? 'ok' : (st.meshDisabled ? 'warn' : 'bad')) }, [
			E('span', { 'class': 'k' }, [ _('802.11s Mesh') ]),
			E('span', { 'class': 'v' }, [
				meshActive
					? (st.meshId ? st.meshId : _('активен'))
					: (st.meshDisabled ? _('отключен (кабель)') : _('не создан'))
			])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (st.mobilityDomain ? 'ok' : 'warn') }, [
			E('span', { 'class': 'k' }, [ _('Роуминг 802.11r') ]),
			E('span', { 'class': 'v' }, [ st.mobilityDomain ? ('Domain: ' + st.mobilityDomain) : _('не включен') ])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (st.stp ? 'ok' : 'warn') }, [
			E('span', { 'class': 'k' }, [ _('Мост br-lan') ]),
			E('span', { 'class': 'v' }, [ st.stp ? _('STP включен (защита ок)') : _('STP выключен!') ])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (st.hasWpadMesh ? 'ok' : 'bad') }, [
			E('span', { 'class': 'k' }, [ _('Пакет wpad') ]),
			E('span', { 'class': 'v' }, [ st.hasWpadMesh ? 'wpad-mesh (SAE/Mesh)' : _('wpad-basic (нужен mesh)') ])
		]));
		if (st.channel5g) {
			chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [ _('Канал 5 GHz') ]),
				E('span', { 'class': 'v' }, [ st.channel5g ])
			]));
		}

		return E('div', { 'class': 'xfree-status-panel xfree-uplink-status', 'style': 'margin-bottom: 1.25rem;' }, chips);
	},

	_renderBackhaulSection: function(st, meshActive) {
		var self = this;
		var wpadConfirm = _('Внимание: пакет wpad-mesh-mbedtls не установлен на роутере!\n\nСтандартный wpad-basic не поддерживает 802.11s Mesh и WPA3-SAE.\nУстановить wpad-mesh-mbedtls сейчас? (Потребуется перезагрузка роутера)');
		var backhaulCards = [
			{
				icon: '👑',
				title: _('Основной узел (Mesh Master)'),
				desc: _('Фиксация канала 5 GHz на 36, включение STP/IGMP Snooping на br-lan и поднятие 802.11s Mesh с WPA3-SAE.'),
				action: 'configureMeshMaster',
				btn: _('Настроить Master'),
				confirm: _('Настроить этот роутер как основной узел (Mesh Master)? Существующие точки Wi-Fi сохраняются.'),
				needsMeshPkg: true
			},
			{
				icon: '🛰️',
				title: _('Ведомый узел (Mesh Satellite)'),
				desc: _('Отключение DHCP и NAT/firewall, объединение WAN и LAN в мост, настройка статического IP и бэкхола к Master.'),
				action: 'configureMeshSatellite',
				btn: _('Настроить Satellite'),
				needsMeshPkg: true
			}
		];

		if (meshActive) {
			backhaulCards.push({
				icon: '🔌',
				title: _('Отключить беспроводной Mesh'),
				desc: _('Интерфейс 802.11s активен. Если узлы соединены кабелем Ethernet, отключите беспроводной mesh для освобождения эфира 5 GHz.'),
				action: 'disableMeshBackhaul',
				btn: _('Отключить Mesh (кабель)'),
				confirm: _('Отключить интерфейс 802.11s Mesh? Используйте это, если роутеры соединены проводом Ethernet.')
			});
		} else {
			backhaulCards.push({
				icon: '📡',
				title: _('Включить беспроводной Mesh'),
				desc: _('Создание или повторное включение интерфейса 802.11s Mesh на 5 GHz для беспроводного соединения узлов.'),
				action: 'configureMeshBackhaul',
				btn: _('Включить 802.11s Mesh'),
				confirm: _('Включить 802.11s беспроводной Mesh backhaul на 5 GHz?'),
				needsMeshPkg: true
			});
		}

		return E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 1rem;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '🔗 ' + _('Межроутерная связь (Backhaul)') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Связь роутер ↔ роутер') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Объединение роутеров в единую сеть по беспроводному каналу 802.11s на 5 GHz или через кабель Ethernet. Защита от петель моста STP.')
				])
			]),
			E('div', { 'class': 'xfree-mesh-grid' }, backhaulCards.map(function(card) {
				var requiresPkgWarn = card.needsMeshPkg && !st.hasWpadMesh;
				var topChildren = [
					E('span', { 'class': 'xfree-mesh-card-ico' }, [ card.icon ]),
					E('strong', {}, [ card.title ])
				];
				if (requiresPkgWarn) {
					topChildren.push(E('span', {
						'class': 'xfree-vpn-status is-warn',
						'style': 'margin-left: auto; font-size: 11px; padding: 2px 6px;'
					}, [ _('Нужен wpad-mesh') ]));
				}
				return E('div', { 'class': 'xfree-mesh-card' + (requiresPkgWarn ? ' is-warn' : '') }, [
					E('div', { 'class': 'xfree-mesh-card-top' }, topChildren),
					E('p', { 'class': 'xfree-mesh-card-desc' }, [ card.desc ]),
					E('div', { 'class': 'xfree-mesh-card-action' }, [
						E('button', {
							'class': 'cbi-button cbi-button-action' + (requiresPkgWarn ? ' important' : ''),
							'type': 'button',
							'click': function(ev) {
								if (requiresPkgWarn) {
									self._act(ev, 'installWpadMesh', '', wpadConfirm);
								} else {
									self._act(ev, card.action, '', card.confirm || '');
								}
							}
						}, [ requiresPkgWarn ? _('Установить wpad-mesh') : card.btn ])
					])
				]);
			}))
		]);
	},

	_renderDiagSection: function() {
		var self = this;
		var diagCards = [
			{
				icon: '📡',
				title: _('Диагностика связности Mesh / Backhaul'),
				desc: _('Обнаружение 802.11s пиров, качество сигнала (RSSI), битрейт, таблица маршрутов mpath и защита от петель STP на сетевом мосту.'),
				action: 'meshDiag',
				btn: _('Запустить диагностику')
			}
		];

		return E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 1rem;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📊 ' + _('Диагностика и мониторинг') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Связность и пиры') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Проверка качества беспроводного бэкхола между узлами и предотвращение сетевых петель.')
				])
			]),
			E('div', { 'class': 'xfree-mesh-grid' }, diagCards.map(function(card) {
				return E('div', { 'class': 'xfree-mesh-card' }, [
					E('div', { 'class': 'xfree-mesh-card-top' }, [
						E('span', { 'class': 'xfree-mesh-card-ico' }, [ card.icon ]),
						E('strong', {}, [ card.title ])
					]),
					E('p', { 'class': 'xfree-mesh-card-desc' }, [ card.desc ]),
					E('div', { 'class': 'xfree-mesh-card-action' }, [
						E('button', {
							'class': 'cbi-button cbi-button-action',
							'type': 'button',
							'click': function(ev) {
								self._act(ev, card.action, '');
							}
						}, [ card.btn ])
					])
				]);
			}))
		]);
	},

	_renderPkgSection: function(st) {
		var self = this;
		var pkgCards = [
			{
				icon: '📦',
				title: _('Пакет wpad-mesh-mbedtls (802.11s)'),
				desc: _('Замена стандартного wpad-basic на версию с полной поддержкой 802.11s Mesh и WPA3-SAE для работы беспроводного соединения узлов.'),
				action: 'installWpadMesh',
				btn: _('Установить wpad-mesh'),
				confirm: _('Заменить wpad на wpad-mesh-mbedtls? Роутер будет перезагружен после установки.')
			}
		];

		return E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 1rem;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '🧩 ' + _('Системные пакеты и зависимости') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Драйверы Wi-Fi') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Управление демонами аутентификации беспроводной сети.')
				])
			]),
			E('div', { 'class': 'xfree-mesh-grid' }, pkgCards.map(function(card) {
				return E('div', { 'class': 'xfree-mesh-card' }, [
					E('div', { 'class': 'xfree-mesh-card-top' }, [
						E('span', { 'class': 'xfree-mesh-card-ico' }, [ card.icon ]),
						E('strong', {}, [ card.title ])
					]),
					E('p', { 'class': 'xfree-mesh-card-desc' }, [ card.desc ]),
					E('div', { 'class': 'xfree-mesh-card-action' }, [
						E('button', {
							'class': 'cbi-button ' + (st.hasWpadMesh ? 'cbi-button-neutral' : 'cbi-button-action important'),
							'type': 'button',
							'click': function(ev) {
								self._act(ev, card.action, '', card.confirm || '');
							}
						}, [ st.hasWpadMesh ? _('Переустановить') : card.btn ])
					])
				]);
			}))
		]);
	}
});
