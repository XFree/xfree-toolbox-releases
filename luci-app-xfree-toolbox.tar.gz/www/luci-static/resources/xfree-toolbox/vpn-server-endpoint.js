'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';

return baseclass.extend({
	_openChangeEndpointDialog: function (awg) {
		var self = this;
		var s = this._spec || {};
		var currentEp = awg.defaultEndpoint || '';

		var epOpts = [];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [choices[i].label]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'value': currentEp,
			'placeholder': 'domain.tld:51820 или 1.2.3.4:51820',
			'style': 'width: 100%; margin-top: 6px;'
		});

		epSelect.addEventListener('change', function () {
			if (epSelect.value)
				customEpInput.value = epSelect.value;
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 8px;' }, [
					_('Default Endpoint используется как адрес сервера в создаваемых клиентских .conf-файлах.')
				]),
				E('label', { 'style': 'font-weight: 600;' }, [_('Выберите из обнаруженных адресов:')]),
				epSelect,
				E('label', { 'style': 'font-weight: 600; display: block; margin-top: 8px;' }, [_('Или укажите вручную:')]),
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px;' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					text: _('Отмена'),
					onClick: function () { ui.hideModal(); }
				}),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function () {
						var ep = String(customEpInput.value || '').trim();
						if (!ep) {
							customEpInput.focus();
							return;
						}
						ui.hideModal();
						if (s.onAction)
							s.onAction('serverSetEndpoint', ep, _('Установить Default Endpoint сервера: %s?').format(ep));
					}
				}, [_('Сохранить')])
			])
		];

		self._showVpnDialog(_('Смена Default Endpoint сервера'), body);
	},

	_openPeerEndpointDialog: function (peer, awg) {
		var self = this;
		var s = this._spec || {};
		var currentEp = peer.endpoint || awg.defaultEndpoint || '';

		var epOpts = [
			E('option', { 'value': '' }, [_('Использовать Default Endpoint сервера (%s)').format(awg.defaultEndpoint || '')])
		];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [choices[i].label]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'value': currentEp,
			'placeholder': 'host:port',
			'style': 'width: 100%; margin-top: 6px;'
		});

		epSelect.addEventListener('change', function () {
			if (epSelect.value)
				customEpInput.value = epSelect.value;
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 8px;' }, [
					_('Индивидуальный Endpoint подключения для клиента «%s».').format(peer.name)
				]),
				E('label', { 'style': 'font-weight: 600;' }, [_('Выбрать из вариантов:')]),
				epSelect,
				E('label', { 'style': 'font-weight: 600; display: block; margin-top: 8px;' }, [_('Или адрес:порт:')]),
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px;' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					text: _('Отмена'),
					onClick: function () { ui.hideModal(); }
				}),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function () {
						var ep = String(customEpInput.value || '').trim();
						ui.hideModal();
						if (s.onAction)
							s.onAction('peerUpdateEndpoint', peer.slug + '|' + ep,
								_('Обновить Endpoint для клиента «%s» на %s?').format(peer.name, ep || _('default')));
					}
				}, [_('Сохранить')])
			])
		];

		self._showVpnDialog(_('Endpoint для «%s»').format(peer.name), body);
	},

	_openNatHelpDialog: function () {
		ui.showModal(_('Как обойти NAT и подключиться к домашнему серверу'), [
			E('div', { 'class': 'xfree-modal-body', 'style': 'font-size: 13px; line-height: 1.5;' }, [
				E('p', {}, [
					_('Если у роутера серый IP-адрес (провайдерский CGNAT 100.64.0.0/10), внешние входящие подключения из интернета блокируются оборудованием провайдера на корню. Ни AmneziaWG напрямую, ни FreeTurn (поскольку VK TURN должен переслать пакет на роутер) достучаться до роутера не смогут.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, ['1. ' + _('Услуга «Белый IP» у провайдера (Рекомендуется)')]),
				E('p', { 'class': 'muted' }, [
					_('Самый стабильный и простой путь. В личном кабинете вашего интернет-провайдера подключите услугу «Статический IP» или «Публичный IP» (обычно 100–150 ₽/мес). После этого роутер получит прямой белый адрес, и все клиенты смогут подключаться без костылей.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, ['2. ' + _('Использование IPv6')]),
				E('p', { 'class': 'muted' }, [
					_('Многие провайдеры с CGNAT по IPv4 параллельно бесплатно выдают полноценный публичный префикс IPv6. Если мобильный оператор вашего телефона также поддерживает IPv6, вы можете указать IPv6-адрес сервера в настройках пиров и подключаться напрямую.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, ['3. ' + _('Реверсивный туннель через VPS (Rathole / FRP / WireGuard)')]),
				E('p', { 'class': 'muted' }, [
					_('Домашний роутер сам устанавливает постоянное исходящее соединение на внешний VPS (исходящие соединения провайдер не блокирует). VPS принимает подключения клиентов из интернета и пробрасывает трафик внутрь на роутер.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, ['4. ' + _('Tailscale / NetBird (P2P Mesh + DERP-релеи)')]),
				E('p', { 'class': 'muted' }, [
					_('Tailscale устанавливается на роутер и клиентские устройства. Если прямое P2P соединение невозможно из-за строгого CGNAT, трафик автоматически пересылается через зашифрованные промежуточные релеи (DERP) без белого IP.')
				])
			]),
			E('div', { 'class': 'right', 'style': 'margin-top: 16px;' }, [
				E('button', {
					'class': 'btn is-primary',
					'click': ui.hideModal
				}, [_('Понятно')])
			])
		]);
	},

	_openFreeTurnConfigDialog: function (awg) {
		var self = this;
		var s = this._spec || {};
		var currentPort = awg.freeTurnPort || '56000';

		var portInput = E('input', {
			'type': 'number',
			'min': '1',
			'max': '65535',
			'value': currentPort,
			'class': 'cbi-input-text',
			'style': 'width: 100%; font-size: 14px; padding: 6px 10px; margin-top: 6px;'
		});

		var presets = [
			{ port: '56000', label: _('56000 (по умолчанию)') },
			{ port: '443', label: _('443 (HTTPS/QUIC)') },
			{ port: '8443', label: _('8443') },
			{ port: '3478', label: _('3478 (STUN)') },
			{ port: '51820', label: _('51820 (AWG)') },
			{ port: '1194', label: _('1194 (OpenVPN)') }
		];

		var presetBtns = presets.map(function (p) {
			return xcmp.button({
				variant: 'vpn',
				style: 'font-size: 11px; padding: 3px 8px;',
				title: _('Установить порт %s').format(p.port),
				text: p.label,
				onClick: function (ev) {
					ev.preventDefault();
					portInput.value = p.port;
				}
			});
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 14px;' }, [
				E('p', { 'style': 'margin: 0 0 8px 0; font-size: 13px;' }, [
					_('Внешний UDP-порт роутера, на котором служба FreeTurn принимает входящий замаскированный трафик от клиентских приложений.')
				]),
				E('label', { 'style': 'font-weight: 600; display: block;' }, [_('Внешний порт (UDP):')]),
				portInput,
				E('div', { 'style': 'margin-top: 8px;' }, [
					E('span', { 'class': 'muted', 'style': 'font-size: 11px; display: block; margin-bottom: 4px;' }, [
						_('Быстрый выбор популярного порта:')
					]),
					E('div', { 'style': 'display: flex; flex-wrap: wrap; gap: 6px;' }, presetBtns)
				]),
				E('div', { 'class': 'muted', 'style': 'margin-top: 12px; font-size: 12px; line-height: 1.4;' }, [
					E('span', { 'style': 'display: block; margin-bottom: 2px;' }, [_('При сохранении:')]),
					E('span', { 'style': 'display: block;' }, ['• ' + _('Обновляется правило входящего трафика в Firewall (Allow-free-turn)')]),
					E('span', { 'style': 'display: block;' }, ['• ' + _('Перезапускается служба /etc/init.d/free-turn с новым портом')]),
					E('span', { 'style': 'display: block;' }, ['• ' + _('Все новые ссылки freeturn:// и QR-коды клиентов будут генерироваться для этого порта')])
				])
			]),
			E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 18px; border-top: 1px solid var(--border-subtle, #e5e5e5); padding-top: 12px;' }, [
				xcmp.button({
					variant: 'vpn',
					title: _('Полная перенастройка бинарника, Firewall и procd'),
					text: _('Перенастроить всё'),
					onClick: function (ev) {
						ui.hideModal();
						self._act(ev, 'freeTurnSetup', '', {
							title: _('Перенастройка FreeTurn прокси'),
							message: _('Перенастроить службу FreeTurn прокси?'),
							detail: _('Будет проверен бинарник, обновлена конфигурация procd сервиса /etc/init.d/free-turn и правила Firewall.'),
							confirmText: _('Перенастроить'),
							tone: 'primary',
							icon: '⚙️'
						});
					}
				}),
				E('div', { 'style': 'display: flex; gap: 8px;' }, [
					xcmp.button({
						variant: 'vpn',
						primary: true,
						text: _('Отмена'),
						onClick: function () { ui.hideModal(); }
					}),
					E('button', {
						'class': 'btn is-primary',
						'type': 'button',
						'click': function () {
							var raw = String(portInput.value || '').trim();
							var p = parseInt(raw, 10);
							if (isNaN(p) || p < 1 || p > 65535) {
								ui.addNotification(null, E('p', {}, [_('Укажите корректный номер порта от 1 до 65535')]), 'danger');
								portInput.focus();
								return;
							}
							ui.hideModal();
							if (s.onAction) {
								s.onAction('freeTurnSetPort', String(p),
									_('Сменить внешний порт FreeTurn на %s (с обновлением Firewall и перезапуском службы)?').format(p));
							}
						}
					}, [_('Сохранить порт')])
				])
			])
		];

		self._showVpnDialog(_('Настройка FreeTurn Proxy'), body);
	},

});
