'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-invoke';

function nameList(list) {
	var out = [];
	var i;
	var name;

	if (list && !Array.isArray(list) && typeof list === 'object')
		list = Object.keys(list).map(function(k) { return list[k]; });
	if (!Array.isArray(list))
		return out;

	for (i = 0; i < list.length; i++) {
		name = list[i];
		if (name && typeof name === 'object')
			name = name.id || name.name || '';
		name = String(name || '').trim();
		if (name)
			out.push(name);
	}
	return out;
}

function hasName(list, name) {
	return nameList(list).indexOf(String(name || '')) >= 0;
}

function suggestValues(catalog, values) {
	var next = {};
	var key;
	var refs;
	var profile;
	var want;

	values = values || {};
	catalog = catalog || {};
	for (key in values) {
		if (Object.prototype.hasOwnProperty.call(values, key))
			next[key] = values[key];
	}

	if (!next.profile && catalog.active && hasName(catalog.profiles, catalog.active))
		next.profile = catalog.active;
	if (!next.profile && catalog.applied && hasName(catalog.profiles, catalog.applied))
		next.profile = catalog.applied;

	if (!next.template && next.profile) {
		refs = catalog.templateRef || {};
		profile = next.profile;
		want = refs[profile] || (hasName(catalog.templates, profile) ? profile : '');
		if (want && !hasName(catalog.templates, want)) {
			if (want === 'default-with-proton' || want === 'default-with-proton-ai')
				want = 'warp-proton';
			else if (want === 'default')
				want = 'warp';
		}
		if (want && hasName(catalog.templates, want))
			next.template = want;
	}

	return next;
}

function selectOptions(field, catalog) {
	var source = field && field.source;
	var list = [];
	var opts = (field && field.options) || [];
	var i;

	if (source === 'templates')
		list = nameList((catalog && catalog.templates) || []);
	else if (source === 'profiles')
		list = nameList((catalog && catalog.profiles) || []);
	else if (opts.length) {
		for (i = 0; i < opts.length; i++) {
			if (typeof opts[i] === 'string')
				list.push(opts[i]);
			else if (opts[i] && (opts[i].id || opts[i].value))
				list.push(opts[i].id || opts[i].value);
		}
	}

	if (list && !Array.isArray(list) && typeof list === 'object')
		list = Object.keys(list).map(function(k) { return list[k]; });

	return Array.isArray(list) ? list : [];
}

function renderField(field, catalog, values) {
	var id = field.id || '';
	var title = field.title || id;
	var current = (values && values[id]) || '';
	var kids;
	var list;
	var i;
	var name;
	var selected;
	var attrs;

	if (field.type === 'checkbox') {
		attrs = {
			'type': 'checkbox',
			'class': 'cbi-input-checkbox',
			'data-xfree-invoke-field': id
		};
		if (current === '1' || current === true || field.checked)
			attrs.checked = true;

		return E('div', { 'class': 'cbi-value' }, [
			E('label', { 'class': 'cbi-value-title' }, [ title ]),
			E('div', { 'class': 'cbi-value-field' }, [
				E('input', attrs)
			])
		]);
	}

	if (field.type === 'text') {
		return E('div', { 'class': 'cbi-value' }, [
			E('label', { 'class': 'cbi-value-title' }, [ title ]),
			E('div', { 'class': 'cbi-value-field' }, [
				E('input', {
					'type': 'text',
					'class': 'cbi-input-text',
					'data-xfree-invoke-field': id,
					'value': current,
					'placeholder': field.placeholder || ''
				})
			])
		]);
	}

	list = selectOptions(field, catalog);
	kids = [ E('option', { 'value': '' }, [ _('— выберите —') ]) ];
	for (i = 0; i < list.length; i++) {
		name = list[i];
		if (name && typeof name === 'object')
			name = name.id || name.name || '';
		if (!name)
			continue;
		selected = (String(name) === String(current)) ? 'selected' : null;
		kids.push(E('option', {
			'value': name,
			'selected': selected
		}, [ name ]));
	}

	return E('div', { 'class': 'cbi-value' }, [
		E('label', { 'class': 'cbi-value-title' }, [ title ]),
		E('div', { 'class': 'cbi-value-field' }, [
			E('select', {
				'class': 'cbi-input-select',
				'data-xfree-invoke-field': id
			}, kids)
		])
	]);
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this.requestPaint();
	}

	getValues() {
		var fields = (this._spec && this._spec.node && this._spec.node.fields) || [];
		var values = {};
		var i;
		var field;
		var el;
		var id;

		for (i = 0; i < fields.length; i++) {
			field = fields[i];
			if (!field || !field.id)
				continue;
			el = this.querySelector('[data-xfree-invoke-field="' + field.id + '"]');
			if (!el)
				values[field.id] = '';
			else if (field.type === 'checkbox')
				values[field.id] = el.checked ? '1' : '0';
			else
				values[field.id] = String(el.value || '').trim();
		}

		this.querySelectorAll('[data-xfree-invoke-field]').forEach(function(node) {
			id = node.getAttribute('data-xfree-invoke-field');
			if (!id || values[id] != null)
				return;
			if (node.type === 'checkbox')
				values[id] = node.checked ? '1' : '0';
			else
				values[id] = String(node.value || '').trim();
		});

		if (values.name && !values.profile)
			values.profile = values.name;

		return values;
	}

	setOutput(text) {
		var el = this.querySelector('xfree-console');

		if (el)
			el.text = text || '';
	}

	setRunning(running) {
		this.querySelectorAll('button').forEach(function(btn) {
			btn.disabled = !!running;
		});
	}

	_bindCouple(catalog) {
		var tmpl = this.querySelector('[data-xfree-invoke-field="template"]');
		var prof = this.querySelector('[data-xfree-invoke-field="profile"]');
		var refs = (catalog && catalog.templateRef) || {};

		if (!tmpl || !prof)
			return;

		tmpl.addEventListener('change', function() {
			var t = String(tmpl.value || '').trim();
			var p = String(prof.value || '').trim();

			if (t && !p && hasName(catalog.profiles, t))
				prof.value = t;
		});
		prof.addEventListener('change', function() {
			var p = String(prof.value || '').trim();
			var want = refs[p] || (hasName(catalog.templates, p) ? p : '');

			if (p && want && hasName(catalog.templates, want))
				tmpl.value = want;
		});
	}

	render() {
		var s = this._spec || {};
		var node = s.node || {};
		var catalog = s.catalog || {};
		var status = s.status || {};
		var values = s.values || {};
		var fields = node.fields || [];
		var buttons = s.buttons || [];
		var fieldNodes = [];
		var actionNodes = [];
		var i;
		var meta = [];
		var running = !!status.running;
		var descr = node.descr ||
			_('Выберите параметры и запустите действие. Лог — то же окно, что textbox в CLI.');
		var consoleEl;
		var self = this;
		var view = s.view;

		this.className = 'cbi-section';
		this.setAttribute('data-xfree-invoke', node.id || '');

		if (catalog.active)
			meta.push(_('Активный профиль: %s').format(catalog.active));
		if (catalog.applied)
			meta.push(_('Применён: %s').format(catalog.applied));
		if (node.cli)
			meta.push(node.cli);

		for (i = 0; i < fields.length; i++)
			fieldNodes.push(renderField(fields[i], catalog, values));

		for (i = 0; i < buttons.length; i++) {
			(function(btn) {
				var cls = 'cbi-button cbi-button-action';

				if (btn.op === 'deleteProfile' || btn.op === 'restoreApply' || btn.op === 'recreateApply')
					cls += ' important';

				actionNodes.push(E('button', {
					'class': cls,
					'disabled': running ? true : null,
					'click': ui.createHandlerFn(view, function() {
						if (s.onRun)
							s.onRun(btn, self);
					})
				}, [ btn.title || _('Выполнить') ]));
			})(buttons[i]);
		}

		consoleEl = E('xfree-console', {
			'label': _('Вывод'),
			'class': 'xfree-invoke-output'
		});
		consoleEl.text = s.output || '';

		this.replaceChildren(
			E('h3', {}, [ node.title || node.id || '' ]),
			E('div', { 'class': 'cbi-section-descr' }, [ descr ]),
			meta.length ? E('div', { 'class': 'cbi-section-descr' }, [ meta.join(' · ') ]) : '',
			E('div', { 'class': 'cbi-section-node' }, fieldNodes),
			E('div', { 'class': 'cbi-page-actions right' }, actionNodes),
			consoleEl
		);
		this._bindCouple(catalog);
	}
});

return baseclass.extend({
	tag: TAG,
	suggestValues: suggestValues
});
