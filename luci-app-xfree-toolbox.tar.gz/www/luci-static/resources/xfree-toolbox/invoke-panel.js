'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-invoke';
var xcmp = components;

function nameList(list) {
	var out = [];
	var i;
	var name;

	if (list && !Array.isArray(list) && typeof list === 'object')
		list = Object.keys(list).map(function(k) { return list[k]; });
	if (!Array.isArray(list))
		return out;

	for (i = 0; i < list.length; i++) {
		name = list[i];
		if (name && typeof name === 'object')
			name = name.id || name.name || '';
		name = String(name || '').trim();
		if (name)
			out.push(name);
	}
	return out;
}

function hasName(list, name) {
	return nameList(list).indexOf(String(name || '')) >= 0;
}

function suggestValues(catalog, values) {
	var next = {};
	var key;
	var refs;
	var profile;
	var want;
	var profilesList;
	var templatesList;

	values = values || {};
	catalog = catalog || {};
	for (key in values) {
		if (Object.prototype.hasOwnProperty.call(values, key))
			next[key] = values[key];
	}

	profilesList = nameList(catalog.profiles || []);
	templatesList = nameList(catalog.templates || []);

	if (!next.profile && catalog.applied && (hasName(catalog.profiles, catalog.applied) || !profilesList.length))
		next.profile = catalog.applied;
	if (!next.profile && catalog.active && (hasName(catalog.profiles, catalog.active) || !profilesList.length))
		next.profile = catalog.active;
	if (!next.profile && profilesList.length === 1)
		next.profile = profilesList[0];

	if (!next.template && next.profile) {
		refs = catalog.templateRef || {};
		profile = next.profile;
		want = refs[profile] || (hasName(catalog.templates, profile) ? profile : '');
		if (want && !hasName(catalog.templates, want)) {
			if (want === 'default-with-proton' || want === 'default-with-proton-ai')
				want = 'warp-proton';
			else if (want === 'default')
				want = 'warp';
		}
		if (want && hasName(catalog.templates, want))
			next.template = want;
	}

	if (!next.template && templatesList.length === 1)
		next.template = templatesList[0];

	return next;
}

function selectOptions(field, catalog) {
	var source = field && field.source;
	var list = [];
	var opts = (field && field.options) || [];
	var i;

	if (source === 'templates')
		list = nameList((catalog && catalog.templates) || []);
	else if (source === 'profiles')
		list = nameList((catalog && catalog.profiles) || []);
	else if (opts.length) {
		for (i = 0; i < opts.length; i++) {
			if (typeof opts[i] === 'string')
				list.push(opts[i]);
			else if (opts[i] && (opts[i].id || opts[i].value))
				list.push(opts[i].id || opts[i].value);
		}
	}

	if (list && !Array.isArray(list) && typeof list === 'object')
		list = Object.keys(list).map(function(k) { return list[k]; });

	return Array.isArray(list) ? list : [];
}

function renderField(field, catalog, values) {
	var id = field.id || '';
	var title = field.title || id;
	var current = (values && values[id]) || '';
	var list;
	var i;
	var name;
	var selected;

	if (field.type === 'checkbox') {
		var isChecked = (current !== '') ? (current === '1' || current === true) : !!field.checked;
		var cbAttrs = {
			'type': 'checkbox',
			'class': 'cbi-input-checkbox',
			'data-xfree-invoke-field': id
		};
		if (isChecked) cbAttrs.checked = true;

		return E('div', { 'class': 'xfree-invoke-field-row' }, [
			E('label', {}, [ title ]),
			E('div', { 'class': 'xfree-invoke-field-check' }, [ E('input', cbAttrs) ])
		]);
	}

	if (field.type === 'text') {
		return E('div', { 'class': 'xfree-invoke-field-row' }, [
			E('label', {}, [ title ]),
			E('div', { 'class': 'xfree-invoke-field-control' }, [
				E('input', {
					'type': 'text',
					'class': 'cbi-input-text font-mono',
					'data-xfree-invoke-field': id,
					'value': current,
					'placeholder': field.placeholder || ''
				})
			])
		]);
	}

	list = selectOptions(field, catalog);
	var options = [ E('option', { 'value': '' }, [ _('— выберите —') ]) ];
	for (i = 0; i < list.length; i++) {
		name = list[i];
		if (name && typeof name === 'object')
			name = name.id || name.name || '';
		if (!name)
			continue;
		selected = (String(name) === String(current)) ? 'selected' : null;
		options.push(E('option', {
			'value': name,
			'selected': selected
		}, [ name ]));
	}

	var selectEl = E('select', {
		'class': 'cbi-input-select font-mono',
		'data-xfree-invoke-field': id
	}, options);
	if (current) selectEl.value = current;

	return E('div', { 'class': 'xfree-invoke-field-row' }, [
		E('label', {}, [ title ]),
		E('div', { 'class': 'xfree-invoke-field-control' }, [ selectEl ])
	]);
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		if (this._spec.catalog) {
			this._spec.values = suggestValues(this._spec.catalog, this._spec.values || {});
		}
		this.requestPaint();
	}

	getValues() {
		var fields = (this._spec && this._spec.node && this._spec.node.fields) || [];
		var values = {};
		var i;
		var field;
		var el;
		var id;

		for (i = 0; i < fields.length; i++) {
			field = fields[i];
			if (!field || !field.id)
				continue;
			el = this.querySelector('[data-xfree-invoke-field="' + field.id + '"]');
			if (!el)
				values[field.id] = '';
			else if (field.type === 'checkbox')
				values[field.id] = el.checked ? '1' : '0';
			else
				values[field.id] = String(el.value || '').trim();
		}

		this.querySelectorAll('[data-xfree-invoke-field]').forEach(function(node) {
			id = node.getAttribute('data-xfree-invoke-field');
			if (!id || values[id] != null)
				return;
			if (node.type === 'checkbox')
				values[id] = node.checked ? '1' : '0';
			else
				values[id] = String(node.value || '').trim();
		});

		if (values.name && !values.profile)
			values.profile = values.name;

		return values;
	}

	setOutput(text) {
		var el = this.querySelector('xfree-console');

		if (el)
			el.text = text || '';
	}

	setRunning(running) {
		this.querySelectorAll('button').forEach(function(btn) {
			btn.disabled = !!running;
		});
	}

	_bindCouple(catalog) {
		var tmpl = this.querySelector('[data-xfree-invoke-field="template"]');
		var prof = this.querySelector('[data-xfree-invoke-field="profile"]');
		var refs = (catalog && catalog.templateRef) || {};

		if (!tmpl || !prof)
			return;

		tmpl.addEventListener('change', function() {
			var t = String(tmpl.value || '').trim();
			var p = String(prof.value || '').trim();

			if (t && !p && hasName(catalog.profiles, t))
				prof.value = t;
		});
		prof.addEventListener('change', function() {
			var p = String(prof.value || '').trim();
			var want = refs[p] || (hasName(catalog.templates, p) ? p : '');

			if (p && want && hasName(catalog.templates, want))
				tmpl.value = want;

			var slotEl = prof.parentNode && prof.parentNode.parentNode
				? prof.parentNode.parentNode.querySelector('[data-xfree-profile-active-slot]')
				: null;
			if (slotEl) {
				var s = self._spec || {};
				var status = s.status || {};
				self._renderActiveSlot(slotEl, p, catalog, s.buttons || [], !!status.running, s.onRun);
			}
		});
	}

	render() {
		var s = this._spec || {};
		var node = s.node || {};
		var catalog = s.catalog || {};
		var status = s.status || {};
		var values = suggestValues(catalog, s.values || {});
		s.values = values;
		var fields = node.fields || [];
		var buttons = s.buttons || [];
		var fieldNodes = [];
		var actionNodes = [];
		var i;
		var running = !!status.running;
		var descr = node.descr || _('Выберите параметры и запустите действие.');
		var consoleEl;
		var self = this;
		var view = s.view;

		this.className = 'xfree-invoke-wrap';
		this.setAttribute('data-xfree-invoke', node.id || '');

		for (i = 0; i < fields.length; i++) {
			var fRow = renderField(fields[i], catalog, values);
			if (fields[i] && fields[i].id === 'profile' && fields[i].source === 'profiles') {
				var activeSlot = E('span', {
					'class': 'xfree-profile-active-slot',
					'data-xfree-profile-active-slot': '1'
				});
				self._renderActiveSlot(activeSlot, values.profile || '', catalog, buttons, running, s.onRun);
				if (typeof fRow.appendChild === 'function') {
					fRow.appendChild(activeSlot);
				} else if (Array.isArray(fRow.children)) {
					fRow.children.push(activeSlot);
				}
			}
			fieldNodes.push(fRow);
		}

		var mainActionNodes = [];
		var dangerActionNodes = [];

		for (i = 0; i < buttons.length; i++) {
			(function(btn) {
				if (btn.visibility === 'expert' && view && view.isExpertMode && !view.isExpertMode())
					return;
				var op = btn.op || '';
				if (op === 'setActive')
					return;
				var isDestructive = (op === 'deleteProfile' || op === 'restoreApply');
				var isPrimary = (op === 'syncApply');
				var tone = isDestructive ? 'danger' : (isPrimary ? 'primary' : 'ghost');
				var icon = '⚡';
				if (op === 'deleteProfile' || op === 'restoreApply') icon = '🗑️';
				else if (op === 'restoreDiff') icon = '🔍';
				else if (op === 'recreateApply') icon = '🔄';
				else if (op === 'instantiatePrompt' || op === 'instantiate') icon = '➕';
				else if (op === 'createFromStatePrompt' || op === 'createFromState') icon = '📥';

				var btnNode = xcmp.button({
					text: btn.title || _('Выполнить'),
					tone: tone,
					size: 'md',
					icon: icon,
					disabled: running,
					onClick: function() {
						if (s.onRun)
							s.onRun(btn, self);
					}
				});
				if (isDestructive || op === 'restoreDiff')
					dangerActionNodes.push(btnNode);
				else
					mainActionNodes.push(btnNode);
			})(buttons[i]);
		}

		var actionsRow = E('div', { 'class': 'xfree-invoke-actions' }, [
			E('div', { 'class': 'xfree-invoke-actions-main' }, mainActionNodes),
			dangerActionNodes.length
				? E('div', { 'class': 'xfree-invoke-actions-danger' }, dangerActionNodes)
				: ''
		]);

		consoleEl = E('xfree-console', {
			'label': _('Журнал выполнения'),
			'class': 'xfree-invoke-output',
			'style': '--xfree-console-max-height:35vh; margin-top: 14px;'
		});
		consoleEl.text = s.output || '';

		var metaBadges = [];
		if (catalog.active) {
			metaBadges.push(xcmp.badge({
				text: _('Активный: %s').format(catalog.active),
				tone: 'ok',
				icon: '✓'
			}));
		}
		if (catalog.applied && catalog.applied !== catalog.active) {
			metaBadges.push(xcmp.badge({
				text: _('Применён: %s').format(catalog.applied),
				tone: 'warn'
			}));
		}

		var card = xcmp.card({
			title: node.title || node.id || _('Профиль'),
			subtitle: descr,
			badge: metaBadges.length ? E('div', { 'style': 'display: flex; gap: 6px;' }, metaBadges) : null,
			content: [
				E('div', { 'class': 'xfree-invoke-fields', 'style': 'margin-bottom: 14px;' }, fieldNodes),
				actionsRow,
				consoleEl
			]
		});

		this.replaceChildren(card);
		this._bindCouple(catalog);
	}

	_renderActiveSlot(slotEl, profileVal, catalog, buttons, running, onRun) {
		var self = this;
		var active = (catalog && catalog.active) || '';
		var setActiveBtn = null;
		var i;

		if (!slotEl)
			return;

		for (i = 0; i < (buttons || []).length; i++) {
			if (buttons[i] && buttons[i].op === 'setActive') {
				setActiveBtn = buttons[i];
				break;
			}
		}

		if (profileVal && setActiveBtn) {
			var isAlreadyActive = !!(active && profileVal === active);
			slotEl.replaceChildren(xcmp.button({
				text: isAlreadyActive ? _('Активен') : _('Сделать активным'),
				tone: isAlreadyActive ? 'ghost' : 'primary',
				size: 'sm',
				icon: '✓',
				disabled: running || isAlreadyActive,
				title: isAlreadyActive
					? _('Этот профиль сейчас активен. Выберите другой профиль в списке, чтобы переключить.')
					: _('Установить выбранный профиль активным в config.sh'),
				onClick: function () {
					if (onRun && !isAlreadyActive)
						onRun(setActiveBtn, self);
				}
			}));
			return;
		}

		slotEl.replaceChildren();
	}
});

return baseclass.extend({
	tag: TAG,
	suggestValues: suggestValues,
	renderField: renderField
});
