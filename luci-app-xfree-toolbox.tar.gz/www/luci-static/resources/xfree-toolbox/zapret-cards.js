'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.zapret-probe-dialog as probeDlg';
'require xfree-toolbox.zapret-checker-dialog as checkerDlg';

function sectionIcon(name) {
	var n = String(name || '').toLowerCase();
	if (n.indexOf('youtube') >= 0) return '🎬';
	if (n.indexOf('discord') >= 0) return '💬';
	if (n.indexOf('telegram') >= 0) return '✈️';
	if (n.indexOf('fb') >= 0 || n.indexOf('wa') >= 0) return '📱';
	if (n.indexOf('roblox') >= 0) return '🎮';
	if (n.indexOf('dns') >= 0 || n.indexOf('dot') >= 0 || n.indexOf('tls') >= 0) return '🛡️';
	if (n.indexOf('cdn') >= 0) return '⚡';
	if (n.indexOf('user') >= 0 || n.indexOf('cust') >= 0) return '👤';
	return '📑';
}

return baseclass.extend({
	sectionIcon: sectionIcon,

	_prepareSections: function(sections) {
		if (!sections || !sections.length) return [];
		var active = [];
		var inactive = [];
		for (var i = 0; i < sections.length; i++) {
			var s = sections[i];
			if (s.enabled)
				active.push(s);
			else
				inactive.push(s);
		}
		return active.concat(inactive);
	},

	_renderTestCards: function() {
		var self = this;
		var s = this._spec || {};
		var view = s.view;
		var testCards = [
			{
				icon: '🎬',
				title: _('YouTube'),
				desc: _('Проверка доступности видеопотоков, googlevideo CDN и интерфейса YouTube.'),
				onCheck: function(ev) {
					ev.preventDefault();
					checkerDlg.openCheckerDialog(view, {
						target: 'youtube',
						title: _('Проверка доступности: YouTube'),
						probeOpts: { isYt: true, target: 'youtube' }
					});
				},
				onProbe: function(ev) {
					ev.preventDefault();
					probeDlg.openProbeDialog(self, { isYt: true, target: 'youtube' });
				}
			},
			{
				icon: '💬',
				title: _('Discord'),
				desc: _('Проверка доступности Discord (API, Gateway, Media CDN, Voice WebRTC) и автоподбор стратегий.'),
				onCheck: function(ev) {
					ev.preventDefault();
					checkerDlg.openCheckerDialog(view, {
						target: 'discord',
						title: _('Проверка доступности: Discord'),
						probeOpts: { target: 'discord' }
					});
				},
				onProbe: function(ev) {
					ev.preventDefault();
					probeDlg.openProbeDialog(self, { target: 'discord' });
				}
			},
			{
				icon: '🌐',
				title: _('Остальные сервисы'),
				desc: _('Проверка доступности Telegram, соцсетей и прочих заблокированных сайтов.'),
				onCheck: function(ev) {
					ev.preventDefault();
					checkerDlg.openCheckerDialog(view, {
						target: 'others',
						title: _('Проверка доступности: Остальные сервисы'),
						probeOpts: { target: 'others' }
					});
				},
				onProbe: function(ev) {
					ev.preventDefault();
					probeDlg.openProbeDialog(self, { target: 'others' });
				}
			},
			{
				icon: '⚡',
				title: _('DPI: TCP 16-20'),
				desc: _('Быстрый лёгкий тест обхода DPI с размером окна TCP 16-20 (экспресс-проверка).'),
				onCheck: function(ev) {
					ev.preventDefault();
					checkerDlg.openCheckerDialog(view, {
						target: 'dpi',
						title: _('DPI экспресс-тест (TCP 16-20)')
					});
				}
			},
			{
				icon: '🛡️',
				title: _('Конфликты портов'),
				desc: _('Проверка пересечения портов nfqws с правилами port forwarding и локальными сервисами роутера.'),
				onCheck: function(ev) {
					self._act(ev, 'portConflicts', '');
				}
			}
		];

		var testGrid = testCards.map(function(tc) {
			var actions = [];
			if (tc.onCheck && tc.onProbe) {
				actions.push(xcmp.button({
					variant: 'vpn',
					text: _('Проверить'),
					onClick: tc.onCheck
				}));
				actions.push(xcmp.button({
					variant: 'vpn',
					primary: true,
					text: '⚡ ' + _('Автоподбор'),
					onClick: tc.onProbe
				}));
			} else if (tc.onCheck) {
				var btnText = tc.title === _('DPI: TCP 16-20')
					? _('Тест TCP 16-20')
					: (tc.title === _('Конфликты портов') ? _('Проверить порты') : _('Проверить'));
				actions.push(xcmp.button({
					variant: 'vpn',
					primary: true,
					text: btnText,
					onClick: tc.onCheck
				}));
			}

			return E('div', { 'class': 'xfree-zapret-test-card' }, [
				E('div', { 'class': 'xfree-zapret-card-top' }, [
					E('span', { 'class': 'xfree-zapret-card-ico' }, [ tc.icon ]),
					E('strong', {}, [ tc.title ])
				]),
				E('p', { 'class': 'muted xfree-zapret-card-desc' }, [ tc.desc ]),
				E('div', { 'class': 'xfree-zapret-card-action', 'style': 'display: flex; gap: 6px; flex-wrap: wrap;' }, actions)
			]);
		});

		return E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '🎯 ' + _('Диагностика и проверка стратегий') ]),
					xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: _('Тестирование DPI') })
				]),
				E('p', { 'class': 'muted' }, [
					_('Запуск проверок откроет окно с живым отчётом тестирования доступности целевых хостов.')
				])
			]),
			E('div', { 'class': 'xfree-zapret-tests-grid' }, testGrid)
		]);
	},

	_renderSectionCard: function(sec) {
		var self = this;
		var s = this._spec || {};
		var view = s.view;
		var st = this._status || {};
		var ico = sectionIcon(sec.name);
		var isEn = !!sec.enabled;

		var toggleInput = E('input', {
			'type': 'checkbox',
			'checked': isEn ? 'checked' : null,
			'title': isEn ? _('Отключить секцию') : _('Включить секцию')
		});
		toggleInput.checked = isEn;
		toggleInput.addEventListener('change', function(ev) {
			ev.stopPropagation();
			var targetEn = ev.target.checked;
			sec.enabled = targetEn;
			self.requestPaint();
			xui.runZapretMenu('toggleSection', sec.name + ':' + (targetEn ? '1' : '0'))
				.then(function() {
					st.pending = true;
					self.setMessage(
						_('Секция «%s» %s. Для применения правил нажмите «⚡ Применить списки».')
							.format(sec.name, targetEn ? _('включена') : _('отключена')),
						'warn'
					);
					self.requestPaint();
				})
				.catch(function(err) {
					sec.enabled = !targetEn;
					self.setMessage(_('Ошибка: %s').format(err && err.message || err), 'bad');
					self.requestPaint();
				});
		});

		var toggleSwitch = E('label', {
			'class': 'xfree-zapret-toggle',
			'title': isEn ? _('Включена (нажмите для отключения)') : _('Отключена (нажмите для включения)')
		}, [
			toggleInput,
			E('span', { 'class': 'xfree-zapret-toggle-slider' })
		]);

		return E('div', { 'class': 'xfree-zapret-section-card' + (isEn ? '' : ' is-disabled') }, [
			E('div', { 'class': 'xfree-zapret-sec-top' }, [
				E('span', { 'style': 'font-size: 16px; margin-right: 6px;' }, [ ico ]),
				E('strong', { 'class': 'xfree-zapret-sec-name' }, [ sec.name ]),
				toggleSwitch
			]),
			E('div', { 'class': 'xfree-zapret-sec-meta' }, [
				isEn
					? xcmp.badge({ variant: 'vpn-status', tone: 'ok', text: '● ' + _('Активна'), style: 'font-size: 11px;' })
					: xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: '○ ' + _('Отключена'), style: 'font-size: 11px;' }),
				sec.hosts > 0
					? xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: '%d хостов'.format(sec.hosts), style: 'font-size: 11px;' })
					: xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: _('пусто'), style: 'font-size: 11px;' })
			]),
			E('div', { 'class': 'xfree-zapret-sec-actions' }, [
				xcmp.button({
					variant: 'vpn',
					title: _('Быстрый подбор рабочей стратегии для секции «%s»').format(sec.name),
					text: '⚡ ' + _('Подбор'),
					onClick: function(ev) {
						ev.preventDefault();
						var isYt = sec.name.indexOf('youtube') >= 0;
						var isDiscord = sec.name.indexOf('discord') >= 0;
						probeDlg.openProbeDialog(self, {
							isYt: isYt,
							target: isDiscord ? 'discord' : (isYt ? 'youtube' : 'others'),
							sectionName: sec.name
						});
					}
				}),
				xcmp.button({
					variant: 'vpn',
					title: _('Просмотр и редактирование параметров стратегии (section.text)'),
					text: '⚙️ ' + _('Стратегия'),
					onClick: function(ev) {
						ev.preventDefault();
						self._openStrategyDialog(sec.name);
					}
				}),
				xcmp.button({
					variant: 'vpn',
					title: _('Перейти к спискам для секции «%s» в «Маршруты»').format(sec.name),
					text: '📋 ' + _('Списки'),
					onClick: function(ev) {
						ev.preventDefault();
						if (s.onNavigate)
							s.onNavigate('routing', 'zapret', sec.name);
						else if (view && view.navigate)
							view.navigate('routing', 'zapret', sec.name);
					}
				})
			])
		]);
	},

	_renderSectionsBlock: function(sections, activeCount) {
		var self = this;
		var filterMode = this._filter || 'all';
		var filtered = sections.filter(function(sec) {
			if (filterMode === 'active') return !!sec.enabled;
			if (filterMode === 'disabled') return !sec.enabled;
			return true;
		});

		var secGrid = filtered.map(function(sec) {
			return self._renderSectionCard(sec);
		});

		var filterGroup = E('div', { 'class': 'xfree-zapret-filter-group' }, [
			E('button', {
				'class': 'xfree-zapret-filter-btn' + (filterMode === 'all' ? ' is-active' : ''),
				'type': 'button',
				'click': function(ev) {
					ev.preventDefault();
					self._filter = 'all';
					self.requestPaint();
				}
			}, [ _('Все') + ' (' + sections.length + ')' ]),
			E('button', {
				'class': 'xfree-zapret-filter-btn' + (filterMode === 'active' ? ' is-active' : ''),
				'type': 'button',
				'click': function(ev) {
					ev.preventDefault();
					self._filter = 'active';
					self.requestPaint();
				}
			}, [ '● ' + _('Активные') + ' (' + activeCount + ')' ]),
			E('button', {
				'class': 'xfree-zapret-filter-btn' + (filterMode === 'disabled' ? ' is-active' : ''),
				'type': 'button',
				'click': function(ev) {
					ev.preventDefault();
					self._filter = 'disabled';
					self.requestPaint();
				}
			}, [ '○ ' + _('Отключённые') + ' (' + (sections.length - activeCount) + ')' ])
		]);

		return E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📑 ' + _('Секции DPI (%d из %d активны)').format(activeCount, sections.length) ]),
					xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: _('sections.order') })
				]),
				E('p', { 'class': 'muted' }, [
					_('Секции обрабатывают сетевой трафик в порядке расположения. Для включения или отключения используйте переключатель. Для редактирования привязанных доменов нажмите «Списки».')
				]),
				filterGroup
			]),
			E('div', { 'class': 'xfree-zapret-sections-grid' }, secGrid)
		]);
	}
});
