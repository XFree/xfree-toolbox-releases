'use strict';
'require baseclass';
'require xfree-toolbox.core.text-io as textIo';

function formatBytes(bytes) {
	var b = Number(bytes);
	if (!isFinite(b) || b <= 0) return '0 B';
	var units = ['B', 'KB', 'MB', 'GB', 'TB'];
	var i = Math.min(Math.floor(Math.log(b) / Math.log(1024)), units.length - 1);
	var v = b / Math.pow(1024, i);
	return (v >= 100 ? v.toFixed(0) : v.toFixed(1)) + ' ' + units[i];
}

function formatHandshake(ts) {
	var t = Number(ts);
	if (!isFinite(t) || t <= 0) return _('никогда');
	var now = Math.floor(Date.now() / 1000);
	var diff = Math.max(0, now - t);
	if (diff < 60) return diff + ' ' + _('сек назад');
	var m = Math.floor(diff / 60);
	if (m < 60) return m + ' ' + _('мин назад');
	var h = Math.floor(m / 60);
	if (h < 24) return h + ' ' + _('ч назад');
	var d = Math.floor(h / 24);
	return d + ' ' + _('дн назад');
}

function copyToClipboard(text, btn) {
	if (!text) return;
	var done = function () {
		if (btn && btn.textContent) {
			var orig = btn.textContent;
			btn.textContent = _('Скопировано!');
			setTimeout(function () { btn.textContent = orig; }, 1500);
		}
	};
	textIo.writeText(text).then(done, done);
}

function downloadTextFile(filename, text) {
	textIo.downloadText(filename, text);
}

function slugifyPeerName(name) {
	var ru = {
		'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'e', 'ж': 'zh', 'з': 'z', 'и': 'i',
		'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't',
		'у': 'u', 'ф': 'f', 'х': 'h', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch', 'ъ': '', 'ы': 'y', 'ь': '',
		'э': 'e', 'ю': 'yu', 'я': 'ya'
	};
	var res = '';
	var lower = String(name || '').trim().toLowerCase();
	for (var i = 0; i < lower.length; i++) {
		var ch = lower[i];
		if (ru[ch] !== undefined) {
			res += ru[ch];
		} else if (/[a-z0-9_-]/.test(ch)) {
			res += ch;
		} else if (/\s/.test(ch)) {
			res += '-';
		}
	}
	return res.replace(/-+/g, '-').replace(/^[-_]+|[-_]+$/g, '');
}

function extractConfBody(stdout) {
	if (!stdout) return '';
	var m = stdout.match(/CONF_BODY_BEGIN\r?\n([\s\S]*?)\r?\nCONF_BODY_END/);
	if (m && m[1]) return m[1].trim();
	return stdout.trim();
}

function loadUqr() {
	if (window.UqrClass)
		return Promise.resolve(window.UqrClass);
	if (window.L && typeof window.L.require === 'function') {
		return window.L.require('uqr').then(function (Uqr) {
			window.UqrClass = Uqr;
			return Uqr;
		}).catch(function (err) {
			console.warn('uqr load error:', err);
			return null;
		});
	}
	return Promise.resolve(null);
}

function renderQrSvg(uqrEngine, text) {
	if (!uqrEngine || !text)
		return null;
	var rawSvg = null;
	var opts = {
		pixelSize: 4,
		whiteColor: '#ffffff',
		blackColor: '#000000',
		ecc: 'M',
		border: 4
	};
	try {
		if (typeof uqrEngine.renderSVG === 'function') {
			rawSvg = uqrEngine.renderSVG(text, opts);
		} else if (typeof uqrEngine === 'function') {
			var inst = new uqrEngine();
			if (typeof inst.renderSVG === 'function') {
				rawSvg = inst.renderSVG(text, opts);
			}
		}
	} catch (e) {
		console.warn('uqr renderSVG error:', e);
	}

	if (!rawSvg)
		return null;

	var m = rawSvg.match(/<svg\s+([^>]*?)>/i);
	if (!m)
		return rawSvg;

	var tagContent = m[1];
	if (/viewBox=/i.test(tagContent))
		return rawSvg;

	var wMatch = tagContent.match(/width="([^"]+)"/i);
	var hMatch = tagContent.match(/height="([^"]+)"/i);
	var w = wMatch ? parseFloat(wMatch[1]) : 0;
	var h = hMatch ? parseFloat(hMatch[1]) : 0;

	if (w > 0 && h > 0) {
		var newTag = '<svg ' + tagContent + ' viewBox="0 0 ' + w + ' ' + h + '">';
		return rawSvg.replace(m[0], newTag);
	}
	return rawSvg;
}

return baseclass.extend({
	formatBytes: formatBytes,
	formatHandshake: formatHandshake,
	copyToClipboard: copyToClipboard,
	downloadTextFile: downloadTextFile,
	slugifyPeerName: slugifyPeerName,
	extractConfBody: extractConfBody,
	loadUqr: loadUqr,
	renderQrSvg: renderQrSvg
});
