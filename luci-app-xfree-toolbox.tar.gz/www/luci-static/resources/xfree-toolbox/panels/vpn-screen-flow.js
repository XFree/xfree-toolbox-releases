'use strict';
'require baseclass';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.core.rpc-client as rpcClient';
'require xfree-toolbox.panels.vpn-places as places';
'require xfree-toolbox.panels.vpn-catalog as catalog';

var COUNTRY_RU = places.COUNTRY_RU;
var confOptions = catalog.confOptions;
var ifaceNameFromConf = catalog.ifaceNameFromConf;

return baseclass.extend({
	_act: function (ev, action, arg, confirmText) {
		var s = this._spec || {};

		if (ev && typeof ev.preventDefault === 'function')
			ev.preventDefault();
		if (ev && typeof ev.stopPropagation === 'function')
			ev.stopPropagation();
		if (s.onAction)
			return s.onAction(action, arg, confirmText);
	},

	_nav: function (ev, panel) {
		var s = this._spec || {};

		ev.preventDefault();
		ev.stopPropagation();
		if (s.onNavigate)
			s.onNavigate(panel);
	},

	_promptAct: function (ev, action, promptText, confirmText) {
		var s = this._spec || {};
		var arg;

		ev.preventDefault();
		ev.stopPropagation();
		arg = window.prompt(promptText, '');
		if (arg === null)
			return;
		arg = String(arg || '').trim();
		if (!arg) {
			this.setOutputText(_('Нужен аргумент: %s').format(promptText));
			this.setMessage(_('Нужен аргумент: %s').format(promptText), 'warn');
			return;
		}
		if (s.onAction)
			s.onAction(action, arg, confirmText);
	},

	_pickSelect: function (title, hint, options, onPick) {
		var sel;
		var opts = [];
		var i;

		if (!options || !options.length) {
			this.setMessage(_('Нет вариантов для выбора'), 'bad');
			return;
		}

		for (i = 0; i < options.length; i++) {
			opts.push(E('option', { 'value': options[i].v }, [options[i].t]));
		}

		sel = E('select', { 'class': 'xfree-uplink-input xfree-vpn-pick-select' }, opts);

		xui.openDialog({
			title: title,
			hint: hint || '',
			body: E('div', { 'class': 'xfree-vpn-pick' }, [sel]),
			actions: [
				{ label: _('Отмена'), variant: 'secondary', close: true },
				{
					label: _('Выбрать'),
					variant: 'primary',
					close: true,
					click: function () {
						var v = String(sel.value || '').trim();

						if (v && onPick)
							onPick(v);
					}
				}
			]
		});
	},

	_updateIface: function (ev, ifaceName, kind) {
		var s = this._spec || {};
		var confs = (this._summary && this._summary.confs) || [];
		var opts = confOptions(confs, kind);
		var isGenerator = (kind === 'warp' || kind === 'proton');
		var confirmMsg;
		var genLabel;
		var combinedOpts;

		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}

		if (isGenerator) {
			if (!opts || !opts.length) {
				confirmMsg = (kind === 'warp')
					? _('Обновить туннель «%s»? Будет выполнен подбор рабочего эндпоинта и обновление конфигурации.').format(ifaceName)
					: _('Обновить туннель «%s»? Будет обновлена конфигурация Proton VPN и применены настройки.').format(ifaceName);

				if (s.onAction)
					s.onAction('regenerateOne', ifaceName, confirmMsg);
				return;
			}

			genLabel = (kind === 'warp')
				? '⚡ ' + _('Автоматически: подобрать рабочий эндпоинт')
				: '⚡ ' + _('Автоматически: обновить конфигурацию');
			combinedOpts = [{ v: '__REGENERATE__', t: genLabel }].concat(opts);

			this._pickSelect(
				_('Обновить туннель «%s»').format(ifaceName),
				_('Выберите источник обновления конфигурации:'),
				combinedOpts,
				function (choice) {
					if (choice === '__REGENERATE__') {
						if (s.onAction)
							s.onAction('regenerateOne', ifaceName,
								_('Пересобрать и обновить «%s»?').format(ifaceName));
					} else {
						if (s.onAction)
							s.onAction('updateFromConf', ifaceName + '|' + choice,
								_('Обновить туннель «%s» из %s?').format(ifaceName, choice));
					}
				}
			);
			return;
		}

		if (!opts || !opts.length) {
			xui.openDialog({
				title: _('Обновить «%s»').format(ifaceName),
				hint: '',
				body: E('div', { 'class': 'xfree-vpn-pick' }, [
					E('p', {}, [
						_('В каталоге vpn/ текущего профиля не найдено файлов конфигурации (.conf).')
					]),
					E('p', { 'class': 'muted' }, [
						_('Загрузите файл .conf на вкладке «Файлы» или настройте туннель через «Пересобрать».')
					])
				]),
				actions: [
					{ label: _('Понятно'), variant: 'primary', close: true }
				]
			});
			return;
		}

		this._pickSelect(
			_('Обновить «%s» из .conf').format(ifaceName),
			_('Выберите файл конфигурации'),
			opts,
			function (file) {
				if (s.onAction)
					s.onAction('updateFromConf', ifaceName + '|' + file,
						_('Обновить туннель «%s» из %s?').format(ifaceName, file));
			}
		);
	},

	_updateFromConf: function (ev, ifaceName, preferKind) {
		return this._updateIface(ev, ifaceName, preferKind);
	},

	_createFromConf: function (ev) {
		var s = this._spec || {};
		var confs = (this._summary && this._summary.confs) || [];
		var opts = confOptions(confs, '');

		ev.preventDefault();
		ev.stopPropagation();
		this._pickSelect(
			_('Создать туннель из .conf'),
			_('Имя туннеля подберётся автоматически'),
			opts,
			function (file) {
				var ifaces = (this._summary && this._summary.ifaces) || [];
				var name = ifaceNameFromConf(file, ifaces);

				if (!s.onAction)
					return;
				xui.openDialog({
					title: _('Создать туннель «%s»').format(name),
					hint: catalog.formatConfLabel(file),
					body: E('div', { 'class': 'xfree-vpn-pick' }, [
						E('p', {}, [_('Применить туннель сразу после создания?')])
					]),
					actions: [
						{ label: _('Отмена'), variant: 'secondary', close: true },
						{
							label: _('Только создать'),
							variant: 'secondary',
							close: true,
							click: function () {
								s.onAction('createFromConf', name + '|' + file);
							}
						},
						{
							label: _('Создать и применить'),
							variant: 'primary',
							close: true,
							click: function () {
								s.onAction('createFromConf', name + '|' + file + '|1');
							}
						}
					]
				});
			}.bind(this)
		);
	},

	_getProtonCountryOptions: function (freeOnly, requireIpv6) {
		var isFreeOnly = (freeOnly === '1' || freeOnly === 1 || freeOnly === true);
		var isIpv6Only = (requireIpv6 === '1' || requireIpv6 === 1 || requireIpv6 === true);
		var sc = this._protonServerCountries;

		var allowedCodes = null;
		if (sc) {
			if (isFreeOnly && isIpv6Only && sc.free_v6 && sc.free_v6.length) {
				allowedCodes = sc.free_v6;
			} else if (isFreeOnly && sc.free && sc.free.length) {
				allowedCodes = sc.free;
			} else if (isIpv6Only && sc.v6 && sc.v6.length) {
				allowedCodes = sc.v6;
			} else if (!isFreeOnly && sc.all && sc.all.length) {
				allowedCodes = sc.all;
			}
		}

		if (!allowedCodes) {
			if (isFreeOnly) {
				allowedCodes = ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG'];
			} else {
				allowedCodes = null;
			}
		}

		var list = [
			{ v: 'AUTO', t: _('Все страны (AUTO)') }
		];
		var seen = { 'AUTO': true };

		var priority = isFreeOnly
			? ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG']
			: ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG', 'MX', 'DE', 'FR', 'CH', 'SE', 'GB', 'ES', 'IT', 'FI', 'TR', 'KZ', 'AE', 'BR', 'AR', 'AU'];

		var freeSet = {};
		var freeList = (sc && sc.free) ? sc.free : ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG'];
		for (var f = 0; f < freeList.length; f++)
			freeSet[freeList[f]] = true;

		var allowedSet = null;
		if (allowedCodes) {
			allowedSet = {};
			for (var a = 0; a < allowedCodes.length; a++)
				allowedSet[allowedCodes[a]] = true;
		}

		for (var p = 0; p < priority.length; p++) {
			var code = priority[p];
			if (allowedSet && !allowedSet[code])
				continue;
			if (!seen[code]) {
				var name = COUNTRY_RU[code] || code;
				var suffix = (!isFreeOnly && freeSet[code]) ? ' [Free]' : '';
				list.push({ v: code, t: name + ' (' + code + ')' + suffix });
				seen[code] = true;
			}
		}

		var rest = [];
		if (allowedSet) {
			for (var c in allowedSet) {
				if (!seen[c]) {
					var label = (COUNTRY_RU[c] || c) + ' (' + c + ')';
					rest.push({ v: c, t: label });
					seen[c] = true;
				}
			}
		} else {
			for (var c2 in COUNTRY_RU) {
				if (!seen[c2]) {
					rest.push({ v: c2, t: COUNTRY_RU[c2] + ' (' + c2 + ')' });
					seen[c2] = true;
				}
			}
		}

		rest.sort(function (a, b) {
			return a.t.localeCompare(b.t, 'ru');
		});

		return list.concat(rest);
	},

	_updateProtonCountriesDropdown: function (preferredCountry) {
		var sel = this.querySelector('[data-xfree-vpn-field="proton_country"]');
		if (!sel) return;

		var freeSel = this.querySelector('[data-xfree-vpn-field="proton_free_only"]');
		var ipv6Sel = this.querySelector('[data-xfree-vpn-field="proton_require_ipv6"]');

		var freeOnly = freeSel ? freeSel.value : '1';
		var ipv6Only = ipv6Sel ? ipv6Sel.value : '0';
		var curVal = preferredCountry || sel.value || 'AUTO';

		var options = this._getProtonCountryOptions(freeOnly, ipv6Only);

		while (sel.firstChild)
			sel.removeChild(sel.firstChild);

		var valFound = false;
		for (var i = 0; i < options.length; i++) {
			var opt = E('option', { 'value': options[i].v }, [options[i].t]);
			if (options[i].v === curVal) {
				opt.selected = true;
				valFound = true;
			}
			sel.appendChild(opt);
		}

		if (!valFound) {
			sel.value = 'AUTO';
		}
	},

	_fetchProtonCountries: function (forceRefresh) {
		var self = this;
		if (this._protonCountriesFetching) return;
		this._protonCountriesFetching = true;

		var refreshBtn = this.querySelector('.xfree-vpn-proton-country-refresh');
		if (refreshBtn) {
			refreshBtn.textContent = '⏳';
			refreshBtn.disabled = true;
		}

		/* Список стран меняется редко. Кнопка обновления передаёт force и обходит TTL. */
		rpcClient.request(xui.ifaceMenu, ['protonCountries', forceRefresh ? 'refresh=1' : ''], {
			ttl: rpcClient.TTL_STATIC,
			force: !!forceRefresh,
			key: 'xfree-toolbox:ifaceMenu:protonCountries'
		}).then(function (res) {
			return xui.normalizeReportResult(res, 'ifaceMenu');
		}).then(function (res) {
			self._protonCountriesFetching = false;
			if (refreshBtn) {
				refreshBtn.textContent = '🔄';
				refreshBtn.disabled = false;
			}

			var raw = (res && (res.stdout || res.output || res)) || '';
			if (typeof raw !== 'string' && typeof raw.toString === 'function')
				raw = raw.toString();

			var sc = { free: [], all: [], v6: [], free_v6: [] };
			var lines = raw.split('\n');
			for (var i = 0; i < lines.length; i++) {
				var line = lines[i].trim();
				if (line.indexOf('PROTON_FREE_COUNTRIES=') === 0) {
					var s = line.substring(22).trim();
					if (s) sc.free = s.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_ALL_COUNTRIES=') === 0) {
					var s2 = line.substring(21).trim();
					if (s2) sc.all = s2.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_V6_COUNTRIES=') === 0) {
					var s3 = line.substring(20).trim();
					if (s3) sc.v6 = s3.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_FREE_V6_COUNTRIES=') === 0) {
					var s4 = line.substring(25).trim();
					if (s4) sc.free_v6 = s4.split(',').filter(Boolean);
				}
			}

			if (sc.all.length > 0) {
				self._protonServerCountries = sc;
				self._protonCountriesLoaded = true;
				self._updateProtonCountriesDropdown();
				if (forceRefresh) {
					self.setMessage(_('Список стран Proton обновлён (%d стран)').format(sc.all.length), 'ok');
				}
			}
		}).catch(function () {
			self._protonCountriesFetching = false;
			if (refreshBtn) {
				refreshBtn.textContent = '🔄';
				refreshBtn.disabled = false;
			}
		});
	},
});
