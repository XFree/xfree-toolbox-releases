'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.loading as loading';

var xcmp = components;

/**
 * Парсер текстового отчета maintenanceStatus
 * @param {string} text
 * @returns {Object}
 */
function parseMaintenanceReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		backup: {
			dir: '/etc/xfree-toolbox/backups',
			size: '0',
			count: 0,
			keep: 3
		},
		packages: {
			missing: [],
			luciRu: false
		},
		migrations: {
			stateDirOk: true
		},
		rawText: String(text || '')
	};

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i].trim();
		if (!line)
			continue;

		if (line.indexOf('BACKUP_DIR=') === 0) {
			res.backup.dir = line.substring(11).trim();
		} else if (line.indexOf('BACKUP_SIZE=') === 0) {
			res.backup.size = line.substring(12).trim();
		} else if (line.indexOf('BACKUP_COUNT=') === 0) {
			res.backup.count = parseInt(line.substring(13).trim(), 10) || 0;
		} else if (line.indexOf('BACKUP_KEEP=') === 0) {
			res.backup.keep = parseInt(line.substring(12).trim(), 10) || 3;
		} else if (line.indexOf('MISSING_PACKAGES=') === 0) {
			var missStr = line.substring(17).trim();
			res.packages.missing = missStr ? missStr.split(/\s+/) : [];
		} else if (line.indexOf('LUCI_RU_INSTALLED=') === 0) {
			res.packages.luciRu = (line.substring(18).trim() === '1');
		} else if (line.indexOf('STATE_DIR_OK=') === 0) {
			res.migrations.stateDirOk = (line.substring(13).trim() === '1');
		}
	}

	return res;
}

function renderMetricRow(label, valueNode) {
	return E('div', { 'class': 'xfree-metric-row' }, [
		E('span', { 'class': 'xfree-metric-label' }, [ label ]),
		E('div', { 'class': 'xfree-metric-value' }, [ valueNode ])
	]);
}

function renderBackupCard(info, view, onRefresh) {
	var bk = info.backup;
	var badgeTone = bk.count > 0 ? 'ok' : 'neutral';
	var badgeText = bk.count > 0 ? (bk.count + ' ' + _('копий') + ' (' + bk.size + ')') : _('Нет копий');

	var rows = [];

	rows.push(renderMetricRow(_('Каталог архивов'), E('span', { 'class': 'font-mono muted', 'style': 'font-size: 11px;' }, [
		bk.dir || '/etc/xfree-toolbox/backups'
	])));

	rows.push(renderMetricRow(_('Объём на диске'), E('span', { 'class': 'font-mono', 'style': 'font-weight: 700;' }, [
		bk.size || '0'
	])));

	rows.push(renderMetricRow(_('Число снимков'), E('span', {}, [
		String(bk.count)
	])));

	rows.push(renderMetricRow(_('Глубина ротации'), E('span', {}, [
		_('Хранить последние ') + bk.keep
	])));

	var rotateBtn = xcmp.button({
		text: _('🔄 Ротация'),
		tone: 'primary',
		title: _('Оставить только актуальные копии в пределах лимита глубины'),
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('backupRotate').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Ротация резервных копий выполнена') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка ротации: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var cleanupBtn = xcmp.button({
		text: _('🧹 Чистка мусора'),
		tone: 'secondary',
		title: _('Удалить временные файлы и мусор бэкапов'),
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('backupCleanup').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Чистка устаревших бэкапов завершена') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка чистки: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var purgeBtn = xcmp.button({
		text: _('🗑️ Очистить всё'),
		tone: 'ghost',
		disabled: bk.count === 0,
		title: _('Полное удаление всех резервных копий'),
		onClick: function(ev) {
			if (!confirm(_('Внимание! Будут удалены все архивные копии профилей. Продолжить?'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('backupPurge').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Все резервные копии очищены') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка очистки: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [rotateBtn, cleanupBtn, purgeBtn]);

	return xcmp.card({
		title: _('Резервные копии (Backups)'),
		subtitle: _('Снимки профилей конфигураций и ротация на диске'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderPackagesCard(info, view, onRefresh) {
	var pkg = info.packages;
	var isOk = pkg.missing.length === 0;

	var badgeTone = isOk ? 'ok' : 'warning';
	var badgeText = isOk ? _('Все пакеты на месте') : (_('Не хватает: ') + pkg.missing.length);

	var rows = [];

	rows.push(renderMetricRow(_('Базовые утилиты'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		E('span', {}, [ 'curl, jq, ip-full, kmod-*' ]),
		xcmp.badge({
			text: isOk ? 'ОК ✓' : 'не установлены',
			tone: isOk ? 'ok' : 'warning'
		})
	])));

	rows.push(renderMetricRow(_('Русский язык LuCI'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		E('span', {}, [ 'luci-i18n-base-ru' ]),
		xcmp.badge({
			text: pkg.luciRu ? 'установлен ✓' : 'не установлен',
			tone: pkg.luciRu ? 'ok' : 'neutral'
		})
	])));

	rows.push(renderMetricRow(_('Менеджер пакетов'), E('span', {}, [
		'APK (OpenWrt 25+)'
	])));

	var installBaseBtn = xcmp.button({
		text: _('📦 Установить базовые'),
		tone: 'primary',
		title: _('Проверить и доустановить недостающие системные пакеты OpenWrt'),
		onClick: function(ev) {
			if (!confirm(_('Запустить установку/проверку базовых системных пакетов?'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('installBase').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Установка базовых пакетов завершена') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка установки: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var installLuciRuBtn = null;
	if (!pkg.luciRu) {
		installLuciRuBtn = xcmp.button({
			text: _('🇷🇺 Русский LuCI'),
			tone: 'secondary',
			title: _('Установить языковой пакет luci-i18n-base-ru'),
			onClick: function(ev) {
				var btn = ev.target;
				loading.track(btn, view.runSystemAction('installLuciRu').then(function() {
					ui.addNotification(null, E('p', {}, [ _('Русский язык LuCI установлен') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function(err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка установки языка: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		});
	}

	var updateAllBtn = xcmp.button({
		text: _('⚡ Обновить все пакеты'),
		tone: 'secondary',
		title: _('Полное обновление всех установленных пакетов OpenWrt (apk upgrade)'),
		onClick: function(ev) {
			if (!confirm(_('Выполнить полное обновление всех установленных пакетов системы?'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('updateAll').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Обновление пакетов завершено') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsList = [installBaseBtn];
	if (installLuciRuBtn) actionsList.push(installLuciRuBtn);
	actionsList.push(updateAllBtn);

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, actionsList);

	return xcmp.card({
		title: _('Системные пакеты и окружение'),
		subtitle: _('Необходимые сетевые утилиты и локализация'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderIntegrityCard(info, view, onRefresh) {
	var mig = info.migrations;
	var badgeTone = mig.stateDirOk ? 'ok' : 'warning';
	var badgeText = mig.stateDirOk ? _('Структура в норме') : _('Требует внимания');

	var rows = [];

	rows.push(renderMetricRow(_('Каталог состояния'), E('span', { 'class': 'font-mono muted', 'style': 'font-size: 11px;' }, [
		'/etc/xfree-toolbox'
	])));

	rows.push(renderMetricRow(_('Идемпотентные миграции'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		E('span', {}, [ _('Проверка каталогов и линков') ]),
		xcmp.badge({
			text: mig.stateDirOk ? 'ОК ✓' : 'сбой',
			tone: mig.stateDirOk ? 'ok' : 'critical'
		})
	])));

	rows.push(renderMetricRow(_('Стандарт платформы'), E('span', {}, [
		'Google OKF v0.2'
	])));

	var checkMigrationBtn = xcmp.button({
		text: _('🔍 Проверить целостность'),
		tone: 'primary',
		title: _('Запустить скрипт проверки миграций и состояния'),
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('checkMigration').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Проверка целостности завершена') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка проверки: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [checkMigrationBtn]);

	return xcmp.card({
		title: _('Целостность и миграции'),
		subtitle: _('Консистентность системных директорий и профилей'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

return baseclass.extend({
	parseReport: parseMaintenanceReport,

	render: function (opts) {
		opts = opts || {};
		var data = opts.data || {};
		var view = opts.view || {};
		var onRefresh = opts.onRefresh;

		var rawText = '';
		if (data.execResult) {
			rawText = data.execResult.stdout || data.execResult.stderr || '';
		}

		var info = parseMaintenanceReport(rawText);

		var panelView = {
			runSystemAction: function (action, arg, payload) {
				var x = (typeof xui !== 'undefined') ? xui : null;
				if (x && typeof x.runSystemMenuWithOutput === 'function') {
					return x.runSystemMenuWithOutput(action, arg, payload);
				}
				if (view && typeof view.runSystemMenu === 'function') {
					return view.runSystemMenu(action, arg, payload);
				}
				if (x && typeof x.runSystemMenu === 'function') {
					return x.runSystemMenu(action, arg, payload);
				}
				return Promise.reject(new Error('runSystemMenu is not available'));
			}
		};

		var cards = [
			renderBackupCard(info, panelView, onRefresh),
			renderPackagesCard(info, panelView, onRefresh),
			renderIntegrityCard(info, panelView, onRefresh)
		];

		var refreshBtn = xcmp.refreshButton({
			isRefreshing: false,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(refreshBtn, res);
					}
				}
			}
		});

		var actionBar = xcmp.actionBar({
			title: _('Обслуживание системы'),
			description: _('Управление резервными копиями, системными пакетами и целостностью роутера'),
			actions: [ refreshBtn ]
		});

		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод maintenanceStatus)'),
			rawText: rawText
		});

		return E('div', { 'class': 'xfree-web xfree-system-maintenance-panel' }, [
			actionBar,
			E('div', { 'class': 'xfree-resource-grid' }, cards),
			spoiler
		]);
	}
});
