'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.panels.vpn-catalog as catalog';
'require xfree-toolbox.panels.vpn-generator-fields as genFields';

var sanitizeIfaceName = catalog.sanitizeIfaceName;
var defaultNewIfaceName = catalog.defaultNewIfaceName;
var textField = catalog.textField;

return baseclass.extend({
	_openAddTunnelDialog: function (view) {
		var self = this;
		var importCard = this._renderImportCard(view, true);

		xui.openDialog({
			title: _('Добавить новый туннель'),
			hint: _('Загрузите файл конфигурации (.conf, .ovpn), вставьте текст или ссылку vpn://'),
			size: 'wide',
			body: E('div', { 'class': 'xfree-vpn-add-dialog', 'style': 'padding: 4px 0;' }, [
				importCard
			]),
			actions: [
				{
					label: _('Выбрать из имеющихся .conf…'),
					variant: 'secondary',
					close: true,
					click: function () {
						self._createFromConf({ preventDefault: function () { }, stopPropagation: function () { } });
					}
				},
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				}
			]
		});
	},

	_collectFieldsIn: function (root, prefix) {
		var out = {};

		if (!root)
			return out;
		root.querySelectorAll('[data-xfree-vpn-field]').forEach(function (el) {
			var id = el.getAttribute('data-xfree-vpn-field') || '';

			if (prefix && id.indexOf(prefix) !== 0)
				return;
			out[id] = String(el.value || '').trim();
		});

		return out;
	},

	_modalPipeArgs: function (map, keys, stripPrefix) {
		var parts = [];
		var i;
		var k;
		var short;

		for (i = 0; i < keys.length; i++) {
			k = keys[i];
			short = k;
			if (stripPrefix && k.indexOf(stripPrefix) === 0)
				short = k.slice(stripPrefix.length);
			parts.push(short + '=' + (map[k] != null ? map[k] : ''));
		}

		return parts.join('|');
	},

	_showVpnDialog: function (title, children) {
		try {
			this.setBusy(false);
			return ui.showModal(title, children, 'cbi-modal', 'xfree-dialog', 'xfree-vpn-dialog');
		} catch (err) {
			this.setBusy(false);
			this.setMessage((err && err.message) ? err.message : String(err), 'bad');
			return null;
		}
	},

	_openNewTunnelDialog: function (kind, slotHint) {
		var self = this;
		var s = this._spec || {};
		var summary = this._summary || {};
		var warp = summary.warp || {};
		var proton = summary.proton || {};
		var ifaces = summary.ifaces || [];
		var k = String(kind || '').toLowerCase();
		var defaultIface = defaultNewIfaceName(slotHint || k, ifaces, summary);
		var fields = [];
		var body;
		var title;

		this.setBusy(false);

		if (k === 'warp') {
			title = _('Новый туннель WARP');
			var activeWarp = null;
			for (var wi = 0; wi < ifaces.length; wi++) {
				var wName = ifaces[wi].name || ifaces[wi].iface || '';
				var wKind = (ifaces[wi].kind || '').toLowerCase();
				if ((wKind === 'warp' || wName.indexOf('warp') === 0) && ifaces[wi].ifaceUp) {
					activeWarp = wName;
					break;
				}
			}
			if (activeWarp) {
				fields.push(
					E('div', { 'class': 'alert-message warning', 'style': 'margin-bottom:12px' }, [
						_('Внимание: туннель «%s» уже активен (172.16.0.2). Два туннеля WARP имеют одинаковый локальный IP и не должны работать одновременно в ядре Linux. Новый туннель будет создан в режиме ожидания (Standby).').format(activeWarp)
					])
				);
			}
			fields.push(textField('new_iface', _('Имя интерфейса'), defaultIface, 'warp'));
			Array.prototype.push.apply(fields, genFields.buildWarpFields({
				prefix: 'new_warp_',
				values: Object.assign({}, warp, { server: (warp.server && warp.server !== 'xfree') ? warp.server : 'def' }),
				includeName: true,
				nameLabel: _('Имя .conf')
			}));
		} else if (k === 'proton') {
			title = _('Новый туннель Proton');
			var activeProton = null;
			for (var pi = 0; pi < ifaces.length; pi++) {
				var pName = ifaces[pi].name || ifaces[pi].iface || '';
				var pKind = (ifaces[pi].kind || '').toLowerCase();
				if ((pKind === 'proton' || pName.indexOf('proton') === 0) && ifaces[pi].ifaceUp) {
					activeProton = pName;
					break;
				}
			}
			var tune = null;
			if (proton.tune_result) {
				try {
					tune = (typeof proton.tune_result === 'string') ? JSON.parse(proton.tune_result) : proton.tune_result;
				} catch {
					tune = null;
				}
			}
			var defProfile = (tune && (tune.profile || (tune.variant ? '2.0:' + tune.variant : null))) || proton.profile || '2.0:1';
			var defEntropy = (tune && tune.entropy) || proton.i1_entropy || 'r32';
			var defNoise = (tune && tune.noise != null) ? String(tune.noise) : (proton.awg_noise != null ? String(proton.awg_noise) : '0');
			var defPort = (tune && tune.port) || (tune && tune.endpoint && tune.endpoint.indexOf(':') !== -1 ? tune.endpoint.split(':')[1] : (proton.port || 'auto'));
			var defCountry = proton.country || 'NL';
			var defSessionMode = proton.session_mode || 'guest';
			var defSelectionMode = proton.selection_mode || 'best';
			var defMtu = proton.mtu || '1280';
			var defFreeOnly = proton.free_only != null ? String(proton.free_only) : '1';
			var defRequireIpv6 = proton.require_ipv6 != null ? String(proton.require_ipv6) : '0';
			var defVia = proton.via || 'auto';
			var defHandshakeProbe = proton.handshake_probe != null ? String(proton.handshake_probe) : '1';

			if (activeProton) {
				fields.push(
					E('div', { 'class': 'alert-message warning', 'style': 'margin-bottom:12px' }, [
						_('Внимание: туннель «%s» уже активен (10.2.0.2). Два туннеля Proton имеют одинаковый локальный IP и не могут работать одновременно в ядре Linux. Новый туннель будет создан в режиме ожидания (Standby).').format(activeProton)
					])
				);
			}

			if (tune && tune.status === 'OK') {
				fields.push(
					E('div', { 'class': 'alert-message notice', 'style': 'margin-bottom:12px' }, [
						_('Подставлены результаты фонового автоподбора: сервер %s%s, AWG %s, шум=%s, энтропия=%s, порт=%s.').format(
							tune.server_name || _('найден'),
							tune.rtt_ms ? (', ' + tune.rtt_ms + ' ' + _('мс')) : '',
							defProfile,
							defNoise === '1' ? _('Вкл (Jc=4)') : _('Выкл'),
							defEntropy,
							defPort
						)
					])
				);
			}

			if (tune && tune.server_name) {
				fields.push(
					E('input', {
						'type': 'hidden',
						'data-xfree-vpn-field': 'new_proton_server',
						'value': tune.server_name
					})
				);
			}

			fields.push(textField('new_iface', _('Имя интерфейса'), defaultIface, 'proton'));
			Array.prototype.push.apply(fields, genFields.buildProtonFields({
				prefix: 'new_proton_',
				values: {
					country: defCountry,
					session_mode: defSessionMode,
					profile: defProfile,
					i1_entropy: defEntropy,
					awg_noise: defNoise,
					selection_mode: defSelectionMode,
					mtu: defMtu,
					free_only: defFreeOnly,
					require_ipv6: defRequireIpv6,
					port: defPort,
					via: defVia,
					handshake_probe: defHandshakeProbe,
					name: proton.name || ''
				},
				ifaces: ifaces,
				includeName: true,
				nameLabel: _('Имя .conf')
			}));
		} else {
			this.setMessage(_('Неизвестный тип: %s').format(kind), 'bad');
			return;
		}

		body = E('div', { 'class': 'xfree-vpn-fields xfree-vpn-modal-fields' }, fields);

		this._showVpnDialog(title, [
			E('p', { 'class': 'muted' }, [
				_('Сгенерировать .conf, создать интерфейс в профиле и применить на роутере.')
			]),
			body,
			E('div', { 'class': 'right xfree-vpn-dialog-actions' }, [
				E('button', {
					'type': 'button',
					'class': 'btn',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						ui.hideModal();
					}
				}, [_('Отмена')]),
				' ',
				E('button', {
					'type': 'button',
					'class': 'btn cbi-button-positive',
					'click': function (ev) {
						var f = self._collectFieldsIn(body, '');
						var iface = sanitizeIfaceName(f.new_iface);
						var arg;
						var action;

						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						if (!iface) {
							self.setMessage(_('Укажите имя интерфейса'), 'bad');
							return;
						}
						ui.hideModal();
						if (k === 'warp') {
							action = 'warpProvision';
							arg = iface + '|' + self._modalPipeArgs(f, [
								'new_warp_server', 'new_warp_profile', 'new_warp_mode',
								'new_warp_i1_mode', 'new_warp_i1_domain', 'new_warp_name',
								'new_warp_selection', 'new_warp_exclude_ru',
								'new_warp_i1_entropy', 'new_warp_awg_noise'
							], 'new_warp_');
						} else {
							action = 'protonProvision';
							arg = iface + '|' + self._modalPipeArgs(f, [
								'new_proton_country', 'new_proton_session_mode', 'new_proton_profile',
								'new_proton_name', 'new_proton_mtu', 'new_proton_free_only',
								'new_proton_require_ipv6', 'new_proton_selection_mode',
								'new_proton_i1_entropy', 'new_proton_awg_noise',
								'new_proton_port', 'new_proton_via', 'new_proton_handshake_probe',
								'new_proton_server'
							], 'new_proton_');
						}
						if (s.onAction)
							s.onAction(action, arg);
					}
				}, [_('Создать и применить')])
			])
		]);
	},
});
