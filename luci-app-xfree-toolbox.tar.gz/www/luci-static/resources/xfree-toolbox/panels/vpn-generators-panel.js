'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.panels.vpn-screen as vpnScreen';
'require xfree-toolbox.panels.vpn-generator-fields as genFields';

var Screen = vpnScreen.Screen;
var selectField = vpnScreen.selectField;
var warpServerTip = vpnScreen.warpServerTip;
var warpServerNeedsReg = vpnScreen.warpServerNeedsReg;
var warpServerIsLte = vpnScreen.warpServerIsLte;

var TAG = 'xfree-vpn-generators';

wc.define(TAG, class extends Screen {
	render() {
		var self = this;
		var s = this._spec || {};
		var view = s.view;
		var summary = this._summary || {};
		var ifaces = summary.ifaces || [];
		var warp = summary.warp || {};
		var proton = summary.proton || {};
		var chips = [];
		var genCards = [];
		var i;

			if (s.loading) {
				chips.push(xcmp.chip({ label: _('WARP .conf'), loading: true }));
				chips.push(xcmp.chip({ label: _('Proton .conf'), loading: true }));
				chips.push(xcmp.chip({ label: _('Всего файлов'), loading: true }));
			} else {
				var confsList = summary.confs || [];
				var warpConfsCount = 0;
				var protonConfsCount = 0;
				for (i = 0; i < confsList.length; i++) {
					if (confsList[i].kind === 'warp' || /warp/i.test(confsList[i].file))
						warpConfsCount++;
					else if (confsList[i].kind === 'proton' || /proton/i.test(confsList[i].file))
						protonConfsCount++;
				}
				chips.push(xcmp.chip({
					label: _('WARP .conf'),
					value: warpConfsCount ? ('%d .conf'.format(warpConfsCount)) : _('нет'),
					tone: warpConfsCount ? 'ok' : ''
				}));
				chips.push(xcmp.chip({
					label: _('Proton .conf'),
					value: protonConfsCount ? ('%d .conf'.format(protonConfsCount)) : _('нет'),
					tone: protonConfsCount ? 'ok' : ''
				}));
				chips.push(xcmp.chip({
					label: _('Всего файлов'),
					value: confsList.length + ' .conf',
					tone: confsList.length ? 'ok' : ''
				}));
			}

		var allConfs = summary.confs || [];
		var warpLatestConf = null;
		var protonLatestConf = null;
		var warpTunnel = null;
		var protonTunnel = null;
		for (i = 0; i < allConfs.length; i++) {
			if (!warpLatestConf && (allConfs[i].kind === 'warp' || /warp/i.test(allConfs[i].file)))
				warpLatestConf = allConfs[i];
			if (!protonLatestConf && (allConfs[i].kind === 'proton' || /proton/i.test(allConfs[i].file)))
				protonLatestConf = allConfs[i];
		}
		for (i = 0; i < ifaces.length; i++) {
			if (!warpTunnel && String(ifaces[i].kind || ifaces[i].name || '').toLowerCase().indexOf('warp') >= 0)
				warpTunnel = ifaces[i];
			if (!protonTunnel && String(ifaces[i].kind || ifaces[i].name || '').toLowerCase().indexOf('proton') >= 0)
				protonTunnel = ifaces[i];
		}

		var warpCard = E('div', {
			'class': 'xfree-vpn-gen',
			'style': 'align-self: start; height: auto; min-height: 0; justify-content: flex-start;'
		}, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title' }, [
					E('strong', {}, [_('WARP')]),
					E('span', { 'class': 'muted' }, [_('генератор')])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, s.loading ? [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 72px; height: 18px; border-radius: 999px;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 88px; height: 18px; border-radius: 999px;' })
				] : [
					warpLatestConf
						? E('span', {
							'class': 'xfree-vpn-status is-ok',
							'title': warpLatestConf.file + (warpLatestConf.created ? ' · ' + warpLatestConf.created : '')
						}, ['📄 ' + vpnScreen.formatConfLabel(warpLatestConf, { showUsedBy: false })])
						: E('span', { 'class': 'xfree-vpn-status is-warn' }, [_('нет .conf')]),
					warpTunnel
						? E('span', { 'class': 'xfree-vpn-status is-' + (warpTunnel.ifaceUp ? 'ok' : 'bad') }, ['🔗 ' + warpTunnel.name + ' (' + (warpTunnel.ifaceUp ? 'UP' : 'DOWN') + ')'])
						: E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('туннель не добавлен')])
				])
			]),
			E('div', { 'class': 'xfree-vpn-fields-wrap' }, [
				E('div', { 'class': 'xfree-vpn-fields' }, genFields.buildWarpFields({
					prefix: 'warp_',
					values: Object.assign({}, warp, { server: (warp.server && warp.server !== 'xfree') ? warp.server : 'def' }),
					includeName: true
				})),
				warpServerTip(),
				warpServerNeedsReg(warp.server)
					? E('p', { 'class': 'xfree-vpn-tip is-warn' }, [
						_('Сейчас выбран сервер со страной (рег.) — без активации в боте llimonix туннель через tribukvy может не работать.')
					])
					: '',
				warpServerIsLte(warp.server)
					? E('p', { 'class': 'xfree-vpn-tip' }, [
						_('Сейчас выбран [LTE]: без бота; endpoint tel.*.tribukvy.ltd, порты как на сайте (ltePL ≠988, lteFL ≠1010).')
					])
					: ''
			]),
			E('div', {
				'class': 'xfree-vpn-tunnel-actions',
				'style': 'margin-top: 10px; flex: 0 0 auto;'
			}, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('warp_'), [
							'warp_server', 'warp_profile', 'warp_mode',
							'warp_i1_mode', 'warp_i1_domain', 'warp_name',
							'warp_selection', 'warp_exclude_ru',
							'warp_i1_entropy', 'warp_awg_noise'
						]);
						self._act(ev, arg ? 'warpSaveAndGenerate' : 'warpGenerate', arg,
							_('Сгенерировать WARP .conf с текущими параметрами?'));
					})
				}, [_('Сгенерировать')]),
				E('button', {
					'class': 'btn ghost-compact is-primary',
					'type': 'button',
					'title': _('Автоматический подбор оптимального варианта AWG и минимального RTT'),
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('warp_'), [
							'warp_server', 'warp_selection', 'warp_exclude_ru'
						]);
						self._act(ev, 'warpTune', arg,
							_('Запустить автоподбор параметров WARP? Будут протестированы различные комбинации AWG и выбран рабочий вариант с минимальной задержкой.'));
					})
				}, ['⚡ ' + _('Автоподбор')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						self._saveWarp(ev);
					})
				}, [_('Сохранить')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						try {
							self._openConfManager('warp');
						} catch (err) {
							self.setBusy(false);
							self.setMessage((err && err.message) ? err.message : String(err), 'bad');
						}
					}
				}, [_('.conf…')])
			])
		]);

		var protonCountryField = xcmp.selectField({
			variant: 'vpn',
			id: 'proton_country',
			label: _('Страна'),
			options: [],
			labelAside: E('button', {
				'class': 'ghost ghost-compact xfree-vpn-proton-country-refresh',
				'type': 'button',
				'title': _('Обновить список стран с серверов Proton'),
				'style': 'padding: 0 4px; font-size: 11px; height: 18px; line-height: 18px; border: none; background: transparent; cursor: pointer;',
				'click': function (ev) {
					ev.preventDefault();
					ev.stopPropagation();
					self._fetchProtonCountries(true);
				}
			}, [self._protonCountriesFetching ? '⏳' : '🔄'])
		});

		var protonFreeOnlyField = selectField('proton_free_only', _('Только free'),
			(proton.free_only === '0' || proton.free_only === 0) ? '0' : '1', [
				{ v: '1', t: _('да') },
				{ v: '0', t: _('нет') }
			]);
		var protonIpv6Field = selectField('proton_require_ipv6', 'IPv6',
			(proton.require_ipv6 === '1' || proton.require_ipv6 === 1) ? '1' : '0', [
				{ v: '0', t: _('все') },
				{ v: '1', t: _('только IPv6') }
			]);
		var protonFreeOnlySelect = protonFreeOnlyField.querySelector('select');
		var protonIpv6Select = protonIpv6Field.querySelector('select');

		protonFreeOnlySelect.addEventListener('change', function () {
			self._updateProtonCountriesDropdown();
		});
		protonIpv6Select.addEventListener('change', function () {
			self._updateProtonCountriesDropdown();
		});

		var protonCard = E('div', {
			'class': 'xfree-vpn-gen',
			'style': 'align-self: start; height: auto; min-height: 0; justify-content: flex-start;'
		}, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title' }, [
					E('strong', {}, [_('Proton')]),
					E('span', { 'class': 'muted' }, [_('генератор')])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, s.loading ? [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 72px; height: 18px; border-radius: 999px;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 88px; height: 18px; border-radius: 999px;' })
				] : [
					protonLatestConf
						? E('span', {
							'class': 'xfree-vpn-status is-ok',
							'title': protonLatestConf.file + (protonLatestConf.created ? ' · ' + protonLatestConf.created : '')
						}, ['📄 ' + vpnScreen.formatConfLabel(protonLatestConf, { showUsedBy: false })])
						: E('span', { 'class': 'xfree-vpn-status is-warn' }, [_('нет .conf')]),
					protonTunnel
						? E('span', { 'class': 'xfree-vpn-status is-' + (protonTunnel.ifaceUp ? 'ok' : 'bad') }, ['🔗 ' + protonTunnel.name + ' (' + (protonTunnel.ifaceUp ? 'UP' : 'DOWN') + ')'])
						: E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('туннель не добавлен')])
				])
			]),
			E('div', { 'class': 'xfree-vpn-fields-wrap' }, [
				E('div', { 'class': 'xfree-vpn-fields' }, genFields.buildProtonFields({
					prefix: 'proton_',
					values: proton,
					ifaces: ifaces,
					includeName: true,
					countryField: protonCountryField,
					freeOnlyField: protonFreeOnlyField,
					ipv6Field: protonIpv6Field
				}))
			]),
			E('div', {
				'class': 'xfree-vpn-tunnel-actions',
				'style': 'margin-top: 10px; flex: 0 0 auto;'
			}, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('proton_'), [
							'proton_country', 'proton_session_mode', 'proton_profile',
							'proton_name', 'proton_mtu', 'proton_free_only',
							'proton_require_ipv6', 'proton_selection_mode',
							'proton_i1_entropy', 'proton_awg_noise', 'proton_port', 'proton_via',
							'proton_handshake_probe'
						]);
						self._act(ev, arg ? 'protonSaveAndGenerate' : 'protonGenerate', arg,
							_('Сгенерировать Proton .conf через API (raw)?'));
					})
				}, [_('Сгенерировать')]),
				E('button', {
					'class': 'btn ghost-compact is-primary',
					'type': 'button',
					'title': _('Автоматический подбор оптимального варианта AWG, энтропии и шума'),
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('proton_'), [
							'proton_country', 'proton_session_mode', 'proton_free_only',
							'proton_require_ipv6', 'proton_selection_mode', 'proton_port', 'proton_via'
						]);
						self._act(ev, 'protonTune', arg,
							_('Запустить автоподбор параметров Proton? Будут протестированы различные комбинации AWG и выбран рабочий сервер с минимальной задержкой.'));
					})
				}, ['⚡ ' + _('Автоподбор')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						self._saveProton(ev);
					})
				}, [_('Сохранить')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						try {
							self._openConfManager('proton');
						} catch (err) {
							self.setBusy(false);
							self.setMessage((err && err.message) ? err.message : String(err), 'bad');
						}
					}
				}, [_('.conf…')])
			])
		]);

		genCards.push(warpCard);
		genCards.push(protonCard);
		genCards.push(this._renderImportCard(view));

		this.renderChrome({
			viewName: 'generators',
			title: _('Генераторы и импорт'),
			hint: _('Импорт конфигураций (Amnezia, WireGuard, OpenVPN) и генераторы WARP / Proton.'),
			chips: chips,
			body: [
				E('section', { 'class': 'xfree-vpn-section' }, [
					E('div', { 'class': 'xfree-vpn-gens' }, genCards)
				])
			]
		});

		setTimeout(function () {
			self._updateProtonCountriesDropdown(proton.country || 'AUTO');
			if (!self._protonServerCountries && !self._protonCountriesFetching) {
				self._fetchProtonCountries(false);
			}
		}, 0);
	}
});

return baseclass.extend({
	tag: TAG
});
