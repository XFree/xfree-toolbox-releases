'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.panels.vpn-screen as vpnScreen';

var Screen = vpnScreen.Screen;
var TAG = 'xfree-vpn-pbrbypass';

wc.define(TAG, class extends Screen {
	_renderPbrBypassSection(ifaces, summary, view) {
		var self = this;
		var uciNets = summary.uciNetworks || [];

		if (!ifaces || ifaces.length === 0)
			return null;

		// 1. Build list of networks: start with UCI networks (lan, guest, etc.)
		var availableNets = (Array.isArray(uciNets) && uciNets.length)
			? uciNets.slice()
			: ['lan', 'guest'];

		if (availableNets.indexOf('lan') === -1)
			availableNets.unshift('lan');
		if (availableNets.indexOf('guest') === -1)
			availableNets.push('guest');

		// Include any networks currently stored in any tunnel's pbrBypass
		ifaces.forEach(function (row) {
			var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
			cur.forEach(function (net) {
				if (availableNets.indexOf(net) === -1)
					availableNets.push(net);
			});
		});

		// 2. Initialize matrix if needed or if summary refreshed
		if (!self._pbrMatrix || self._pbrSummarySeq !== summary) {
			self._pbrMatrix = {};
			ifaces.forEach(function (row) {
				var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
				self._pbrMatrix[row.name] = cur;
			});
			self._pbrSavedSnapshot = JSON.stringify(self._pbrMatrix);
			self._pbrSummarySeq = summary;
		} else {
			// Ensure all current ifaces exist in self._pbrMatrix
			ifaces.forEach(function (row) {
				if (!Array.isArray(self._pbrMatrix[row.name])) {
					var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
					self._pbrMatrix[row.name] = cur;
				}
			});
		}

		var isDirty = JSON.stringify(self._pbrMatrix) !== self._pbrSavedSnapshot;

		var initialMap = {};
		try {
			initialMap = JSON.parse(self._pbrSavedSnapshot || '{}');
		} catch {
			initialMap = {};
		}

		// 3. Header
		var headerCols = [
			E('th', { 'style': 'min-width: 170px;' }, [_('Локальная сеть (Wi-Fi / LAN)')])
		];

		ifaces.forEach(function (row) {
			headerCols.push(E('th', { 'class': 'xfree-pbr-col-tunnel' }, [
				E('div', { 'class': 'xfree-pbr-tunnel-th' }, [
					E('span', { 'class': 'xfree-vpn-status-dot is-' + (row.ifaceUp ? 'ok' : 'bad') }),
					E('strong', {}, [row.name]),
					row.kind ? E('span', { 'class': 'muted font-mono', 'style': 'font-size: 10px;' }, [' (' + row.kind + ')']) : ''
				])
			]));
		});

		headerCols.push(E('th', { 'style': 'text-align: right; min-width: 190px;' }, [_('Быстрые действия')]));

		// 4. Rows
		var rows = [];

		availableNets.forEach(function (net) {
			var rowCells = [];
			var icon = '🌐';
			var desc = '';

			if (net === 'lan') {
				icon = '🏠';
				desc = _(' (основная сеть)');
			} else if (net === 'guest') {
				icon = '👥';
				desc = _(' (гостевой Wi-Fi)');
			} else if (net === 'iot') {
				icon = '💡';
				desc = _(' (умный дом)');
			}

			// Network name cell
			rowCells.push(E('td', { 'class': 'xfree-pbr-cell-net' }, [
				E('span', { 'style': 'margin-right: 6px;' }, [icon]),
				E('strong', { 'class': 'font-mono' }, [net]),
				desc ? E('span', { 'class': 'muted font-xs' }, [desc]) : ''
			]));

			// Per-tunnel checkbox cells
			ifaces.forEach(function (t) {
				var list = self._pbrMatrix[t.name] || [];
				var inBypass = list.indexOf(net) >= 0;
				var initList = initialMap[t.name] || [];
				var initInBypass = initList.indexOf(net) >= 0;
				var isCellModified = (inBypass !== initInBypass);

				var cb = E('input', {
					'type': 'checkbox',
					'class': 'xfree-pbr-matrix-cb',
					'checked': inBypass ? true : null,
					'title': inBypass
						? _('Сеть «%s» исключена из «%s» (трафик идёт в WAN). Нажмите, чтобы направить в VPN.').format(net, t.name)
						: _('Сеть «%s» использует «%s» по спискам VPN. Нажмите, чтобы исключить (пустить в WAN).').format(net, t.name),
					'change': function () {
						var cur = self._pbrMatrix[t.name] || [];
						var idx = cur.indexOf(net);
						if (this.checked && idx === -1) {
							cur.push(net);
						} else if (!this.checked && idx >= 0) {
							cur.splice(idx, 1);
						}
						self._pbrMatrix[t.name] = cur;
						self.requestPaint();
					}
				});

				var cellClasses = ['xfree-pbr-cell-check'];
				if (inBypass) cellClasses.push('is-bypass');
				if (isCellModified) cellClasses.push('is-modified');

				rowCells.push(E('td', { 'class': cellClasses.join(' ') }, [
					E('label', {
						'class': 'xfree-pbr-cb-wrap' + (isCellModified ? ' is-modified' : ''),
						'title': isCellModified ? _('Это значение изменено, но ещё не сохранено') : null
					}, [
						cb,
						E('span', { 'class': 'xfree-pbr-cb-label' }, [inBypass ? _('WAN') : _('VPN')])
					])
				]));
			});

			// Quick action buttons for this row
			var bypassAllBtn = E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Исключить сеть «%s» из ВСЕХ туннелей (всегда направлять через WAN)').format(net),
				'click': function (ev) {
					ev.preventDefault();
					ifaces.forEach(function (t) {
						var cur = self._pbrMatrix[t.name] || [];
						if (cur.indexOf(net) === -1)
							cur.push(net);
						self._pbrMatrix[t.name] = cur;
					});
					self.requestPaint();
				}
			}, [_('В обход всех')]);

			var vpnAllBtn = E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Направлять сеть «%s» через все туннели по спискам маршрутов').format(net),
				'click': function (ev) {
					ev.preventDefault();
					ifaces.forEach(function (t) {
						var cur = self._pbrMatrix[t.name] || [];
						var idx = cur.indexOf(net);
						if (idx >= 0)
							cur.splice(idx, 1);
						self._pbrMatrix[t.name] = cur;
					});
					self.requestPaint();
				}
			}, [_('Все в VPN')]);

			rowCells.push(E('td', { 'style': 'text-align: right; white-space: nowrap;' }, [
				bypassAllBtn,
				' ',
				vpnAllBtn
			]));

			rows.push(E('tr', { 'class': 'xfree-selfroute-row' }, rowCells));
		});

		var table = E('table', { 'class': 'xfree-selfroute-table xfree-pbr-matrix' }, [
			E('thead', {}, [
				E('tr', {}, headerCols)
			]),
			E('tbody', {}, rows)
		]);

		// Unified smart action button (always working, compact, never stretches)
		var actionBtn = E('button', {
			'class': isDirty ? 'btn ghost-compact xfree-pbr-action-btn is-dirty' : 'ghost ghost-compact xfree-pbr-action-btn',
			'type': 'button',
			'title': isDirty
				? _('Сохранить изменения матрицы и переприменить правила маршрутизации')
				: _('Переприменить текущие правила маршрутизации nftables (apply-routing)'),
			'click': function (ev) {
				ev.preventDefault();
				if (isDirty) {
					var bulkArg = ifaces.map(function (t) {
						var nets = (self._pbrMatrix[t.name] || []).join(' ');
						return t.name + '=' + (nets || '-');
					}).join(';');

					self._pbrSavedSnapshot = JSON.stringify(self._pbrMatrix);
					self._act(ev, 'pbrApplyBulk', bulkArg,
						_('Применить новую матрицу исключений PBR для туннелей?'));
				} else {
					self._act(ev, 'applyRouting', '',
						_('Переприменить правила маршрутизации nftables прямо сейчас?'));
				}
			}
		}, [
			isDirty ? ('⚡ ' + _('Сохранить и применить')) : ('⚡ ' + _('Применить маршрутизацию'))
		]);

		var resetBtn = isDirty ? E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'style': 'color: var(--muted);',
			'title': _('Отменить несохранённые изменения и вернуть текущие настройки'),
			'click': function (ev) {
				ev.preventDefault();
				self._pbrMatrix = JSON.parse(self._pbrSavedSnapshot);
				self.requestPaint();
			}
		}, ['🔄 ' + _('Отменить')]) : null;

		var statusBtn = E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'title': _('Показать текущую конфигурацию PBR bypass и nft sets'),
			'click': ui.createHandlerFn(view, function (ev) {
				self._act(ev, 'pbrStatus', '');
			})
		}, ['📋 ' + _('Подробный статус PBR')]);

		var dirtyNotice = isDirty ? E('span', { 'class': 'xfree-pbr-dirty-hint' }, [
			'● ' + _('Есть несохранённые изменения')
		]) : null;

		var toolbar = E('div', { 'class': 'xfree-pbr-matrix-toolbar' }, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
				statusBtn
			]),
			E('div', { 'class': 'xfree-pbr-main-ops' }, [
				dirtyNotice ? dirtyNotice : '',
				resetBtn ? resetBtn : '',
				actionBtn
			])
		]);

		var stateBadge = isDirty
			? E('span', { 'class': 'xfree-vpn-badge is-warn', 'style': 'font-size: 11px;' }, ['● ' + _('Есть изменения')])
			: E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size: 11px;' }, ['✓ ' + _('Сохранено')]);

		return E('section', { 'class': 'xfree-vpn-section xfree-selfroute-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('h4', {}, ['🛡️ ' + _('Матрица сетей без VPN → WAN (PBR Bypass)')]),
						stateBadge
					]),
					E('div', { 'style': 'display: flex; align-items: center; gap: 6px;' }, [
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'title': _('Перейти к маршрутизации отдельных устройств (IP/MAC)'),
							'click': function (ev) {
								ev.preventDefault();
								if (view && typeof view.navigate === 'function')
									view.navigate('vpn', 'devicepolicy', 'vpn.devicepolicy');
							}
						}, ['📱 ' + _('Маршрутизация устройств (IP/MAC) →')]),
						E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('Policy-Based Routing')])
					])
				]),
				E('p', { 'class': 'muted' }, [
					_('Настройка обхода для целых сетей (lan, guest, vlan). Чтобы настроить исключения или принудительное туннелирование для конкретного смартфона, ПК или ТВ по IP или MAC-адресу, используйте вкладку «Маршрутизация устройств».')
				])
			]),
			table,
			toolbar
		]);
	}

	render() {
		var s = this._spec || {};
		var view = s.view;
		var summary = this._summary || {};
		var ifaces = summary.ifaces || [];
		var chips = [];
		var i;
		var sec;
		var isPbrLoading = !!(this._loading || (!ifaces.length && !this._summaryLoaded));

		if (isPbrLoading) {
			chips.push(xcmp.chip({ label: _('Сетей (LAN/VLAN)'), loading: true }));
			chips.push(xcmp.chip({ label: _('Туннелей'), loading: true }));
			chips.push(xcmp.chip({ label: _('Bypass в WAN'), loading: true }));
			chips.push(xcmp.chip({ label: _('Режим'), loading: true }));
		} else {
				var uciNets = summary.uciNetworks || [];
				var availableNets = (Array.isArray(uciNets) && uciNets.length) ? uciNets.slice() : ['lan', 'guest'];
				if (availableNets.indexOf('lan') === -1)
					availableNets.unshift('lan');
				var activeBypassCount = 0;
				for (i = 0; i < ifaces.length; i++) {
					var pbrList = ifaces[i].pbrBypassNets || [];
					for (var ni = 0; ni < availableNets.length; ni++) {
						if (pbrList.indexOf(availableNets[ni]) !== -1)
							activeBypassCount++;
					}
				}
			chips.push(xcmp.chip({
				label: _('Сетей (LAN/VLAN)'),
				value: String(availableNets.length)
			}));
			chips.push(xcmp.chip({ label: _('Туннелей'), value: String(ifaces.length) }));
			chips.push(xcmp.chip({
				label: _('Bypass в WAN'),
				value: String(activeBypassCount),
				tone: activeBypassCount > 0 ? 'warn' : ''
			}));
			chips.push(xcmp.chip({
				label: _('Режим'),
				value: _('Policy Routing'),
				tone: 'ok'
			}));
			chips.push(xcmp.chip({
				label: _('Устройства (IP/MAC)'),
				value: _('Открыть →'),
				extraClass: 'is-link',
				title: _('Перейти к управлению маршрутизацией конкретных клиентов по IP/MAC'),
				onClick: function (ev) {
					ev.preventDefault();
					if (view && typeof view.navigate === 'function')
						view.navigate('vpn', 'devicepolicy', 'vpn.devicepolicy');
				}
			}));
		}

		sec = this._renderPbrBypassSection(ifaces, summary, view);
		this.renderChrome({
			viewName: 'pbrbypass',
			title: _('PBR Bypass'),
			hint: _('Policy-Based Routing: прямой выход выбранных локальных сетей в интернет через WAN в обход VPN.'),
			chips: chips,
			body: [
				sec || E('p', { 'class': 'muted' }, [
					_('Туннели не найдены. Создайте туннели для настройки матрицы PBR.')
				])
			]
		});
	}
});

return baseclass.extend({
	tag: TAG
});
