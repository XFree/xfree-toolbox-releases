'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.panels.vpn-screen as vpnScreen';

var Screen = vpnScreen.Screen;
var TAG = 'xfree-vpn-selfroute';

wc.define(TAG, class extends Screen {
	_renderSelfRouteSection(ifaces, summary, view) {
		var self = this;
		var rows = [];
		var table;
		var i;
		var quickOps = [];
		var hotplugOk = !!(summary && summary.selfRouteHotplug);

		if (!ifaces || ifaces.length === 0)
			return null;

		for (i = 0; i < ifaces.length; i++) {
			(function (row) {
				var target = row.name;
				var currentVia = row.selfRouteVia || '';
				var selEl;
				var opts = [];
				var j;
				var other;
				var applyBtn;
				var resetBtn = null;

				opts.push(E('option', {
					'value': '',
					'selected': !currentVia ? true : null
				}, [_('WAN (напрямую, без туннеля)')]));

				for (j = 0; j < ifaces.length; j++) {
					other = ifaces[j];
					if (other.name === target)
						continue;
					opts.push(E('option', {
						'value': other.name,
						'selected': currentVia === other.name ? true : null
					}, ['➔ ' + other.name + (other.kind ? ' (' + other.kind + ')' : '')]));
				}

				selEl = E('select', {
					'class': 'xfree-uplink-input xfree-selfroute-select',
					'data-selfroute-target': target
				}, opts);

				applyBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						var selectedVia = String(selEl.value || '').trim();
						if (!selectedVia) {
							if (currentVia) {
								self._act(ev, 'selfRouteRemove', target,
									_('Сбросить маршрут для «%s» (направить напрямую через WAN)?').format(target));
							} else {
								self.setMessage(_('Туннель «%s» уже направлен напрямую через WAN').format(target), 'ok');
							}
							return;
						}
						if (selectedVia === currentVia) {
							self.setMessage(
								_('Маршрут %s ➔ %s уже сохранён. Для обновления нажмите «Обновить маршруты».').format(target, currentVia),
								'ok'
							);
							return;
						}
						self._act(ev, 'selfRouteApply', target + '|' + selectedVia,
							_('Направить туннель «%s» через «%s» (%s ➔ %s)?').format(target, selectedVia, target, selectedVia));
					})
				}, [_('Применить')]);

				if (currentVia) {
					resetBtn = E('button', {
						'class': 'ghost ghost-compact',
						'type': 'button',
						'click': ui.createHandlerFn(view, function (ev) {
							self._act(ev, 'selfRouteRemove', target,
								_('Сбросить каскадный маршрут для «%s» (вернуть выход через WAN)?').format(target));
						})
					}, [_('Сбросить')]);
				}

				rows.push(E('tr', { 'class': 'xfree-selfroute-row' }, [
					E('td', { 'class': 'xfree-selfroute-cell-target' }, [
						E('div', { 'class': 'xfree-selfroute-target-box' }, [
							E('span', { 'class': 'xfree-vpn-status-dot is-' + (row.ifaceUp ? 'ok' : 'bad') }),
							E('strong', {}, [target]),
							row.kind ? E('span', { 'class': 'muted font-mono' }, [' (' + row.kind + ')']) : ''
						])
					]),
					E('td', { 'class': 'xfree-selfroute-cell-route' }, [
						currentVia
							? E('span', { 'class': 'xfree-selfroute-pill is-active' }, [
								target + ' ',
								E('span', { 'class': 'xfree-vpn-arrow' }, ['➔']),
								' ' + currentVia
							])
							: E('span', { 'class': 'xfree-selfroute-pill is-wan' }, [
								target + ' ',
								E('span', { 'class': 'muted' }, ['➔ WAN'])
							])
					]),
					E('td', { 'class': 'xfree-selfroute-cell-via' }, [selEl]),
					E('td', { 'class': 'xfree-selfroute-cell-actions' }, [
						applyBtn,
						resetBtn ? ' ' : '',
						resetBtn ? resetBtn : ''
					])
				]));
			})(ifaces[i]);
		}

		table = E('table', { 'class': 'xfree-selfroute-table' }, [
			E('thead', {}, [
				E('tr', {}, [
					E('th', {}, [_('Туннель')]),
					E('th', {}, [_('Текущий маршрут')]),
					E('th', {}, [_('Маршрут через (Via)')]),
					E('th', {}, [_('Действия')])
				])
			]),
			E('tbody', {}, rows)
		]);

		quickOps = [
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Обновить runtime host-routes в ядре (пункт 5)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'selfRouteRunHotplug', '',
						_('Обновить runtime host-routes для всех туннелей в ядре прямо сейчас?'));
				})
			}, ['🔄 ' + _('Обновить маршруты')]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Пересобрать hotplug hook /etc/hotplug.d/iface/95-xfree-toolbox-self-route (пункт 4)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'selfRouteRebuildHotplug', '',
						_('Пересобрать hotplug hook для автоматического поднятия маршрутов?'));
				})
			}, ['⚙️ ' + _('Пересобрать hotplug')]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Полная пересборка и удаление сиротских маршрутов (пункт 6)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'selfRouteCleanup', '',
						_('Выполнить полную пересборку и очистку сиротских маршрутов (cleanup)?'));
				})
			}, ['🧹 ' + _('Очистить сироты (cleanup)')]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Показать текущую конфигурацию self-route и статус hotplug (пункт 1)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'selfRouteStatus', '');
				})
			}, ['📋 ' + _('Подробный статус')])
		];

		return E('section', { 'class': 'xfree-vpn-section xfree-selfroute-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, ['🔀 ' + _('Исходящие маршруты туннелей (Self-route)')]),
					E('span', {
						'class': 'xfree-vpn-status is-' + (hotplugOk ? 'ok' : 'warn')
					}, [hotplugOk ? 'hotplug: active' : 'hotplug: not set'])
				]),
				E('p', { 'class': 'muted' }, [
					_('Каскадная маршрутизация (туннель через туннель). Направляет endpoint целевого VPN через промежуточный туннель, скрывая реальный IP роутера от провайдера целевого VPN.')
				])
			]),
			ifaces.length < 2
				? E('p', { 'class': 'muted' }, [
					_('Для каскадной маршрутизации требуется хотя бы два созданных туннеля (например, warp и proton).')
				])
				: table,
			E('div', { 'class': 'xfree-selfroute-ops' }, quickOps)
		]);
	}

	render() {
		var s = this._spec || {};
		var view = s.view;
		var summary = this._summary || {};
		var ifaces = summary.ifaces || [];
		var count = summary.count || ifaces.length || 0;
		var chips = [];
		var i;
		var sec;
		var isSelfRouteLoading = !!(this._loading || (!ifaces.length && !this._summaryLoaded));

		if (isSelfRouteLoading) {
			chips.push(xcmp.chip({ label: _('Туннелей'), loading: true }));
			chips.push(xcmp.chip({ label: _('Каскадных (Via)'), loading: true }));
			chips.push(xcmp.chip({ label: _('Прямой WAN'), loading: true }));
			chips.push(xcmp.chip({ label: _('Hotplug'), loading: true }));
		} else {
				var viaCount = 0;
				for (i = 0; i < ifaces.length; i++) {
					if (ifaces[i].selfRouteVia)
						viaCount++;
				}
			chips.push(xcmp.chip({ label: _('Туннелей'), value: String(count) }));
			chips.push(xcmp.chip({
				label: _('Каскадных (Via)'),
				value: String(viaCount),
				tone: viaCount > 0 ? 'ok' : ''
			}));
			chips.push(xcmp.chip({ label: _('Прямой WAN'), value: String(count - viaCount) }));
			chips.push(xcmp.chip({
				label: _('Hotplug'),
				value: summary.selfRouteHotplug ? _('активен') : _('не настроен'),
				tone: summary.selfRouteHotplug ? 'ok' : 'warn'
			}));
		}

		sec = this._renderSelfRouteSection(ifaces, summary, view);
		this.renderChrome({
			viewName: 'selfroute',
			title: _('Self-route'),
			hint: _('Каскадная маршрутизация (туннель через туннель). Направляет endpoint целевого VPN через промежуточный туннель, скрывая реальный IP роутера.'),
			chips: chips,
			body: [
				sec || E('p', { 'class': 'muted' }, [
					_('Туннели не найдены. Создайте туннели для настройки исходящей маршрутизации.')
				])
			]
		});
	}
});

return baseclass.extend({
	tag: TAG
});
