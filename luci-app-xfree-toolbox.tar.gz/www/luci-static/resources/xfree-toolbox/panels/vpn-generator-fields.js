'use strict';
'require baseclass';
'require xfree-toolbox.panels.vpn-catalog as catalog';

var selectField = catalog.selectField;
var textField = catalog.textField;

function buildViaOptions(ifaces, excludeIface) {
	var opts = [
		{ v: 'auto', t: _('Авто (через self-route, если настроен)') },
		{ v: 'none', t: _('Напрямую через WAN') }
	];
	var list = ifaces || [];
	var i;
	var iname;

	for (i = 0; i < list.length; i++) {
		iname = list[i].name || list[i].iface;
		if (iname && (!excludeIface || iname !== excludeIface))
			opts.push({ v: iname, t: _('Через туннель «%s»').format(iname) });
	}
	return opts;
}

/**
 * Единый набор полей настроек генератора WARP для панели генераторов,
 * диалога создания туннеля и диалога пересборки.
 */
function buildWarpFields(opts) {
	var o = opts || {};
	var p = o.prefix || 'warp_';
	var v = o.values || {};
	var fields = [
		selectField(p + 'server', _('Сервер'), v.server || 'def', catalog.WARP_SERVERS),
		selectField(p + 'selection', _('Выбор endpoint'), v.selection || 'best', catalog.WARP_SELECTION),
		selectField(p + 'exclude_ru', _('Фильтр колоний RU'), v.excludeRu != null ? String(v.excludeRu) : '1', [
			{ v: '1', t: _('Вкл — без DME/LED/KJA/SVX') },
			{ v: '0', t: _('Выкл') }
		]),
		selectField(p + 'profile', _('Профиль AWG'), v.profile || '2.0:1', catalog.WARP_PROFILES),
		selectField(p + 'i1_entropy', _('Энтропия I1'), v.i1_entropy || 'off', catalog.WARP_ENTROPY_OPTIONS),
		selectField(p + 'awg_noise', _('Шум AWG'), v.awg_noise != null ? String(v.awg_noise) : '1', catalog.PROTON_NOISE_OPTIONS),
		selectField(p + 'mode', _('Режим'), v.mode || 'local', catalog.WARP_MODES),
		selectField(p + 'i1_mode', _('I1'), v.i1Mode || 'fixed', catalog.WARP_I1),
		textField(p + 'i1_domain', _('I1 domain/seed'), v.i1Domain || '', _('для domain'))
	];

	if (o.includeName !== false)
		fields.push(textField(p + 'name', o.nameLabel || _('Имя файла'), v.name || '', _('авто')));

	return fields;
}

/**
 * Единый набор полей настроек генератора Proton для панели генераторов,
 * диалога создания туннеля и диалога пересборки.
 */
function buildProtonFields(opts) {
	var o = opts || {};
	var p = o.prefix || 'proton_';
	var v = o.values || {};
	var fields = [
		o.countryField || selectField(p + 'country', _('Страна'), v.country || 'NL', catalog.PROTON_COUNTRIES),
		selectField(p + 'session_mode', _('Сессия'), v.session_mode || 'guest', [
			{ v: 'guest', t: _('гостевая') },
			{ v: 'permanent', t: _('постоянная') }
		]),
		selectField(p + 'profile', _('Профиль AWG'), v.profile || '2.0:1', catalog.WARP_PROFILES),
		selectField(p + 'i1_entropy', _('Энтропия I1'), v.i1_entropy || 'r32', catalog.PROTON_ENTROPY_OPTIONS),
		selectField(p + 'awg_noise', _('Шум AWG'), v.awg_noise != null ? String(v.awg_noise) : '0', catalog.PROTON_NOISE_OPTIONS),
		selectField(p + 'selection_mode', _('Выбор сервера'), v.selection_mode || 'best', [
			{ v: 'best', t: 'best' },
			{ v: 'random', t: 'random' }
		]),
		textField(p + 'mtu', 'MTU', v.mtu || '1280', '1280'),
		o.freeOnlyField || selectField(p + 'free_only', _('Только free'), v.free_only != null ? String(v.free_only) : '1', [
			{ v: '1', t: _('да') },
			{ v: '0', t: _('нет') }
		]),
		o.ipv6Field || selectField(p + 'require_ipv6', 'IPv6', v.require_ipv6 != null ? String(v.require_ipv6) : '0', [
			{ v: '0', t: _('все') },
			{ v: '1', t: _('только IPv6') }
		])
	];

	if (o.includeRounds) {
		fields.push(selectField(p + 'rounds', _('Попытки (раунды по 3)'), v.rounds || '5', [
			{ v: '1', t: _('1 (топ-3)') },
			{ v: '3', t: _('3 (топ-9)') },
			{ v: '5', t: _('5 (топ-15, по умолч.)') },
			{ v: '10', t: _('10 (топ-30)') },
			{ v: '0', t: _('все доступные') }
		]));
	}

	fields.push(
		selectField(p + 'port', _('Порт Endpoint'), v.port || 'auto', catalog.PROTON_PORT_OPTIONS),
		selectField(p + 'via', _('Маршрут подбора'), v.via || 'auto', buildViaOptions(o.ifaces, o.excludeIface)),
		selectField(p + 'handshake_probe', _('Проверка рукопожатия'), v.handshake_probe != null ? String(v.handshake_probe) : '1', [
			{ v: '1', t: _('да (по умолчанию)') },
			{ v: '0', t: _('нет') }
		])
	);

	if (o.includeName !== false)
		fields.push(textField(p + 'name', o.nameLabel || _('Имя файла'), v.name || '', _('авто')));

	return fields;
}

return baseclass.extend({
	buildWarpFields: buildWarpFields,
	buildProtonFields: buildProtonFields
});
