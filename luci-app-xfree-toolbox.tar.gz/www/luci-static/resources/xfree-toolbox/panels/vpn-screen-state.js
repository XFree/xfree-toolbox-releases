'use strict';
'require baseclass';
'require ui';

return baseclass.extend({
	mount: function (spec) {
		this._spec = spec || {};
		this._summary = (spec && spec.summary) || { ifaces: [], warp: {}, proton: {}, count: 0 };
		this._awgSummary = (spec && spec.awgSummary) || {};
		this._protocolsStatus = (spec && spec.protocolsStatus) || {};
		this._output = (spec && spec.outputText) || '';
		this._busy = !!(spec && spec.busy);
		this._loading = !!(spec && spec.loading);
		this._protocolsLoaded = !!(spec && spec.protocolsStatus && Object.keys(spec.protocolsStatus).length > 0 && spec.protocolsStatus.awg);
		this._serverLoaded = !!(spec && spec.awgSummary && (spec.awgSummary.iface || spec.awgSummary.running != null));
		this._summaryLoaded = !!(spec && spec.summary && (spec.summary.ifaces != null || spec.summary.count != null));
		this._msg = (spec && spec.message) || '';
		this._msgTone = (spec && spec.messageTone) || '';
		this._vpnView = (spec && spec.vpnView) || 'tunnels';
		this.requestPaint();
	},

	setLoading: function (loading) {
		this._loading = !!loading;
		if (this._spec)
			this._spec.loading = this._loading;
		this.requestPaint();
	},

	setSummary: function (summary) {
		this._summary = summary || { ifaces: [], warp: {}, proton: {}, count: 0 };
		this._summaryLoaded = true;
		this._loading = false;
		if (this._spec)
			this._spec.loading = false;
		this.requestPaint();
	},

	setAwgSummary: function (awg) {
		this._awgSummary = awg || {};
		this._serverLoaded = true;
		if (this._spec)
			this._spec.awgSummary = this._awgSummary;
		this.requestPaint();
	},

	setProtocolsStatus: function (status) {
		this._protocolsStatus = status || {};
		this._protocolsLoaded = true;
		this._loading = false;
		if (this._spec) {
			this._spec.protocolsStatus = this._protocolsStatus;
			this._spec.loading = false;
		}
		this.requestPaint();
	},

	setOutputText: function (text) {
		this._output = text || '';
	},

	setBusy: function (busy) {
		this._busy = !!busy;
		this.querySelectorAll('button').forEach(function (el) {
			el.disabled = !!busy;
		});
	},

	setMessage: function (text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var el = this.querySelector('[data-xfree-vpn-msg]');

		if (el) {
			el.textContent = this._msg;
			el.className = 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : '');
		}
	},

	/* Шапка, чипы и строка сообщения — общие для экранов. data-xfree-vpn на хабе, не здесь. */
	renderChrome: function (opts) {
		var s = this._spec || {};
		var view = s.view;
		var isRefreshing = !!(this._loading || this._busy);
		var topOps = [
			E('button', {
				'class': 'ghost ghost-compact xfree-vpn-head-btn' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние туннелей и интерфейсов'),
				'click': ui.createHandlerFn(view, function (ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				})
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, ['🔄']),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить статус'))
			])
		].concat(opts.extraOps || []);
		var sections = [
			E('div', { 'class': 'xfree-vpn-head' }, [
				E('div', { 'class': 'xfree-vpn-head-left' }, [
					E('h3', {}, [opts.title || '']),
					E('p', { 'class': 'muted' }, [opts.hint || ''])
				]),
				E('div', { 'class': 'xfree-vpn-head-right' }, [
					E('div', { 'class': 'xfree-vpn-head-actions' }, topOps),
					E('div', {
						'class': 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
						'data-xfree-vpn-msg': '1'
					}, [this._msg || ''])
				])
			]),
			E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, opts.chips || [])
		];

		(opts.body || []).forEach(function (node) {
			if (node)
				sections.push(node);
		});
		this.className = 'xfree-vpn-root';
		if (opts.viewName)
			this.setAttribute('data-xfree-view', opts.viewName);
		this.replaceChildren.apply(this, sections);
		if (this._busy) {
			this.querySelectorAll('button').forEach(function (el) {
				el.disabled = true;
			});
		}
	},
});
