'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.panels.vpn-catalog-const as vpnConst';
'require xfree-toolbox.panels.vpn-conf-format as confFmt';

function unpackAmneziaVpnKey(rawStr) {
	var s = String(rawStr || '').trim();
	if (s.indexOf('vpn://') === 0)
		s = s.substring(6);
	s = s.replace(/_/g, '/').replace(/-/g, '+');
	while (s.length % 4) s += '=';
	var bin;
	try {
		bin = atob(s);
	} catch {
		return Promise.reject(new Error(_('Некорректная Base64 строка')));
	}
	var bytes = new Uint8Array(bin.length);
	for (var i = 0; i < bin.length; i++) {
		bytes[i] = bin.charCodeAt(i);
	}
	var offset = 0;
	if (bytes.length >= 4 && bytes[0] === 0 && bytes[1] === 0 && bytes[2] === 0 && bytes[3] === 0xff) {
		offset = 4;
	}
	var payload = bytes.subarray(offset);
	if (typeof DecompressionStream !== 'undefined') {
		try {
			var ds = new DecompressionStream('deflate');
			var writer = ds.writable.getWriter();
			writer.write(payload);
			writer.close();
			var reader = ds.readable.getReader();
			var chunks = [];
			var total = 0;
			function readNext() {
				return reader.read().then(function (step) {
					if (step.done) {
						var res = new Uint8Array(total);
						var cur = 0;
						for (var j = 0; j < chunks.length; j++) {
							res.set(chunks[j], cur);
							cur += chunks[j].length;
						}
						var text = new TextDecoder('utf-8').decode(res);
						return JSON.parse(text);
					}
					chunks.push(step.value);
					total += step.value.length;
					return readNext();
				});
			}
			return readNext();
		} catch (err) {
			return Promise.reject(err);
		}
	}
	return Promise.reject(new Error(_('DecompressionStream не поддерживается в этом браузере')));
}

function extractAmneziaConfig(jsonObj) {
	if (!jsonObj || typeof jsonObj !== 'object')
		return null;
	if (jsonObj.api_config) {
		return {
			isSubscription: true,
			name: jsonObj.name || jsonObj.description || 'Amnezia Premium',
			serviceType: jsonObj.api_config.service_type || 'amnezia-premium',
			country: jsonObj.api_config.user_country_code || '',
			apiKey: (jsonObj.auth_data && jsonObj.auth_data.api_key) || ''
		};
	}
	var extractedConf = null;
	var type = jsonObj.defaultContainer || 'awg';
	if (Array.isArray(jsonObj.containers)) {
		for (var i = 0; i < jsonObj.containers.length; i++) {
			var c = jsonObj.containers[i];
			if (c.awg && c.awg.last_config) {
				extractedConf = c.awg.last_config;
				type = 'awg';
				break;
			}
			if (c.wireguard && c.wireguard.last_config) {
				extractedConf = c.wireguard.last_config;
				type = 'wireguard';
				break;
			}
			if (c.openvpn && c.openvpn.last_config) {
				extractedConf = c.openvpn.last_config;
				type = 'openvpn';
				break;
			}
		}
	}
	if (extractedConf) {
		return {
			isStatic: true,
			confText: extractedConf,
			type: type,
			name: jsonObj.description || jsonObj.hostName || 'amnezia'
		};
	}
	return null;
}

function listCreateKinds(summary) {
	var slots = (summary && summary.createSlots) || [];
	var byKind = {};
	var out = [];
	var k;
	var i;
	var s;

	for (i = 0; i < slots.length; i++) {
		s = slots[i];
		k = String(s.kind || s.slot || '').toLowerCase();
		if (!k || k === 'manual')
			continue;
		if (!byKind[k] || (byKind[k].occupied && !s.occupied))
			byKind[k] = s;
	}
	if (!byKind['warp']) {
		byKind['warp'] = { kind: 'warp', slot: 'warp', occupied: 0 };
	}
	if (!byKind['proton']) {
		byKind['proton'] = { kind: 'proton', slot: 'proton', occupied: 0 };
	}

	var orderedKinds = ['warp', 'proton'];
	for (i = 0; i < orderedKinds.length; i++) {
		k = orderedKinds[i];
		if (byKind[k]) {
			out.push({
				kind: k,
				slot: byKind[k].slot || k,
				occupied: byKind[k].occupied ? 1 : 0
			});
		}
	}
	for (k in byKind) {
		if (!Object.prototype.hasOwnProperty.call(byKind, k) || orderedKinds.indexOf(k) >= 0)
			continue;
		out.push({
			kind: k,
			slot: byKind[k].slot || k,
			occupied: byKind[k].occupied ? 1 : 0
		});
	}
	return out;
}

function defaultNewIfaceName(slotName, ifaces, summary) {
	var kind = String(slotName || '').toLowerCase();
	var free;

	if (kind === 'warp' || kind.indexOf('warp') === 0) {
		free = summary && summary.freeWarpIface;
		if (free)
			return free;
	}
	if (kind === 'proton' || kind.indexOf('proton') === 0) {
		free = summary && summary.freeProtonIface;
		if (free)
			return free;
	}

	var base = confFmt.sanitizeIfaceName(slotName) || 'tunnel';
	var i;
	var names = {};

	for (i = 0; i < (ifaces || []).length; i++)
		names[ifaces[i].name] = 1;
	if (!names[base])
		return base;
	for (var n = 2; n < 50; n++) {
		if (!names[base + String(n)])
			return base + String(n);
	}
	return base + '_new';
}

function createKindLabel(kind) {
	var k = String(kind || '').toLowerCase();

	if (k === 'warp')
		return 'WARP';
	if (k === 'proton')
		return 'Proton';
	return kind;
}

function selectField(id, label, value, options) {
	return xcmp.selectField({
		variant: 'vpn',
		id: id,
		label: label,
		value: value,
		options: options
	});
}

function textField(id, label, value, placeholder) {
	return xcmp.inputField({
		variant: 'vpn',
		id: id,
		label: label,
		value: value,
		placeholder: placeholder
	});
}

function secretField(id, label, placeholder) {
	return xcmp.inputField({
		variant: 'vpn',
		id: id,
		label: label,
		placeholder: placeholder,
		type: 'password'
	});
}

function renderTunnelSkeleton() {
	return xcmp.card({ variant: 'vpn-tunnel', loading: true });
}

return baseclass.extend({
	formatConfLabel: confFmt.formatConfLabel,
	confOptions: confFmt.confOptions,
	ifaceNameFromConf: confFmt.ifaceNameFromConf,
	sanitizeIfaceName: confFmt.sanitizeIfaceName,
	unpackAmneziaVpnKey: unpackAmneziaVpnKey,
	extractAmneziaConfig: extractAmneziaConfig,
	listCreateKinds: listCreateKinds,
	defaultNewIfaceName: defaultNewIfaceName,
	createKindLabel: createKindLabel,
	selectField: selectField,
	textField: textField,
	secretField: secretField,
	WARP_SERVERS: vpnConst.WARP_SERVERS,
	WARP_PROFILES: vpnConst.WARP_PROFILES,
	WARP_MODES: vpnConst.WARP_MODES,
	WARP_I1: vpnConst.WARP_I1,
	WARP_SELECTION: vpnConst.WARP_SELECTION,
	WARP_ENTROPY_OPTIONS: vpnConst.WARP_ENTROPY_OPTIONS,
	PROTON_ENTROPY_OPTIONS: vpnConst.PROTON_ENTROPY_OPTIONS,
	PROTON_NOISE_OPTIONS: vpnConst.PROTON_NOISE_OPTIONS,
	PROTON_PORT_OPTIONS: vpnConst.PROTON_PORT_OPTIONS,
	PROTON_COUNTRIES: vpnConst.PROTON_COUNTRIES,
	warpServerNeedsReg: vpnConst.warpServerNeedsReg,
	warpServerIsLte: vpnConst.warpServerIsLte,
	warpServerTip: vpnConst.warpServerTip,
	renderTunnelSkeleton: renderTunnelSkeleton
});
