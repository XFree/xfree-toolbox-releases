'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.panels.vpn-screen as vpnScreen';
'require xfree-toolbox.panels.vpn-card';

var Screen = vpnScreen.Screen;
var listCreateKinds = vpnScreen.listCreateKinds;
var createKindLabel = vpnScreen.createKindLabel;
var renderTunnelSkeleton = vpnScreen.renderTunnelSkeleton;
var countryName = vpnScreen.countryName;
var coloLabel = vpnScreen.coloLabel;

var TAG = 'xfree-vpn-tunnels';

wc.define(TAG, class extends Screen {
	render() {
		var self = this;
		var s = this._spec || {};
		var view = s.view;
		var summary = this._summary || {};
		var ifaces = summary.ifaces || [];
		var count = summary.count || ifaces.length || 0;
		var stateOk = summary.stateOk || 0;
		var sourceOk = summary.sourceOk || 0;
		var viaMap = {};
		var chips = [];
		var tunnelCards = [];
		var i;
		var iface;
		var sub;
		var viewMode = this._vpnView || 'tunnels';
		var sections = [];
		var createKinds = listCreateKinds(summary);
		var createBtns = [];
		var ci;
		var ck;
		var extraOps = [];
		var toneApplied = count > 0 && stateOk === count ? 'ok' : (stateOk > 0 ? 'warn' : 'muted');

		for (i = 0; i < ifaces.length; i++) {
			if (ifaces[i].selfRouteVia) {
				if (!viaMap[ifaces[i].selfRouteVia])
					viaMap[ifaces[i].selfRouteVia] = [];
				viaMap[ifaces[i].selfRouteVia].push(ifaces[i].name);
			}
		}

		if ((this._loading || s.loading) && !this._summaryLoaded) {
			chips.push(xcmp.chip({ label: _('Туннели'), loading: true }));
			chips.push(xcmp.chip({ label: _('В state'), loading: true }));
			chips.push(xcmp.chip({ label: _('Source'), loading: true }));
		} else {
			chips.push(xcmp.chip({ label: _('Туннели'), value: String(count) }));
			chips.push(xcmp.chip({
				label: _('В state'),
				value: '%s / %s'.format(stateOk, count || '0'),
				tone: toneApplied
			}));
			chips.push(xcmp.chip({
				label: _('Source'),
				value: '%s / %s'.format(sourceOk, count || '0'),
				tone: (sourceOk === count && count) ? 'ok' : ''
			}));
		}

		if (s.loading && !ifaces.length) {
			tunnelCards.push(renderTunnelSkeleton());
			tunnelCards.push(renderTunnelSkeleton());
		}

		for (i = 0; i < ifaces.length; i++) {
			iface = ifaces[i];
			sub = [];
			if (iface.kind)
				sub.push(iface.kind);
			if (iface.server)
				sub.push(iface.server);
			if (iface.country)
				sub.push(countryName(iface.country));
			if (iface.city && String(iface.kind || '').toLowerCase() === 'proton')
				sub.push(iface.city);
			if (iface.colo)
				sub.push(coloLabel(iface.colo));
			var cardEl = E('xfree-vpn-card');
			cardEl.mount({
				row: iface,
				ifaces: ifaces,
				sub: sub,
				viaMap: viaMap,
				view: view,
				spec: s,
				screen: self
			});
			tunnelCards.push(cardEl);
		}

		if (viewMode === 'tunnels') {
			for (ci = 0; ci < createKinds.length; ci++) {
				ck = createKinds[ci];
				(function (row) {
					createBtns.push(E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function (ev) {
							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							try {
								self._openNewTunnelDialog(row.kind, row.slot);
							} catch (err) {
								self.setBusy(false);
								self.setMessage((err && err.message) ? err.message : String(err), 'bad');
							}
						}
					}, ['+ ' + createKindLabel(row.kind)]));
				})(ck);
			}
			createBtns.push(E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': ui.createHandlerFn(view, function (ev) {
					ev.preventDefault();
					self._openAddTunnelDialog(view);
				})
			}, [_('загрузить…')]));
			createBtns.push(E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': ui.createHandlerFn(view, function (ev) {
					self._createFromConf(ev);
				})
			}, [_('из conf')]));
			tunnelCards.push(E('div', { 'class': 'xfree-vpn-tunnel is-new' }, [
				E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
					E('strong', {}, [_('Новый')]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('создать')])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-sub muted' }, [
					_('Генерация .conf → интерфейс → apply')
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-actions xfree-vpn-create-actions' }, createBtns)
			]));
		}

		if (viewMode === 'tunnels') {
			extraOps.push(E('button', {
				'class': 'btn ghost-compact xfree-vpn-head-btn',
				'type': 'button',
				'title': _('Пересобрать правила DNS, nftables и self-route (нужно после удаления туннелей в режиме «Только туннель»)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'applyRouting', '',
						_('Применить маршрутизацию и обновить DNS?'));
				})
			}, [_('Применить маршрутизацию')]));
			if (ifaces.length > 0) {
				extraOps.push(E('button', {
					'class': 'btn ghost-compact xfree-vpn-head-btn is-primary',
					'type': 'button',
					'title': _('Применить конфигурацию всех туннелей профиля'),
					'click': ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'applyAll', '',
							_('Применить все туннели профиля?'));
					})
				}, ['⚡ ' + _('Применить все')]));
			}
		}

		if (viewMode === 'overview') {
			var vpnHeadIco = E('span', { 'class': 'stat-ico', 'aria-hidden': 'true', 'style': 'display:inline-flex; vertical-align:middle; margin-right:6px;' });
			vpnHeadIco.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 4.5 3.2 8 8 9 4.8-1 8-4.5 8-9V7z"/><path d="M9.5 12.5 11 14l3.5-3.5"/></svg>';

			var overviewHead = E('div', { 'class': 'xfree-overview-vpn-head' }, [
				E('div', { 'class': 'xfree-overview-vpn-title-wrap' }, [
					E('h3', {}, [
						vpnHeadIco,
						_('VPN-туннели')
					]),
					E('p', { 'class': 'muted xfree-overview-vpn-subhead' }, [
						_('Туннели профиля WireGuard/AWG и маршрутизация')
					])
				]),
				E('div', { 'class': 'xfree-overview-vpn-head-actions' }, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Открыть полный раздел управления туннелями'),
						'click': function (ev) {
							self._nav(ev, 'vpn.tunnels');
						}
					}, [_('Управление туннелями ➔')])
				])
			]);

			sections.push(overviewHead);
			sections.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-top: 8px;' }, [
				tunnelCards.length
					? E('div', { 'class': 'xfree-vpn-tunnels' }, tunnelCards)
					: E('p', { 'class': 'muted' }, [
						_('Туннели не найдены — создайте из .conf или на вкладке «Генераторы и импорт».')
					])
			]));

			this.className = 'xfree-vpn-root';
			this.setAttribute('data-xfree-view', 'overview');
			this.replaceChildren.apply(this, sections);
			if (this._busy) {
				this.querySelectorAll('button').forEach(function (el) {
					el.disabled = true;
				});
			}
			return;
		}

		this.renderChrome({
			viewName: viewMode,
			title: _('VPN-туннели'),
			hint: _('Статус профиля и быстрые действия. Списки сайтов — Маршруты → VPN.'),
			chips: chips,
			extraOps: extraOps,
			body: [
				E('section', { 'class': 'xfree-vpn-section' }, [
					E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;' }, [
						E('h4', { 'style': 'margin: 0;' }, [_('Туннели профиля')]),
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'click': function (ev) {
								ev.preventDefault();
								self._openAddTunnelDialog(view);
							}
						}, [_('+ Добавить туннель')])
					]),
					tunnelCards.length
						? E('div', { 'class': 'xfree-vpn-tunnels' }, tunnelCards)
						: E('p', { 'class': 'muted' }, [
							_('Туннели не найдены — создайте из .conf или на вкладке «Генераторы и импорт».')
						])
				])
			]
		});
	}
});

return baseclass.extend({
	tag: TAG
});
