'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.core.loading as loading';

var xcmp = components;

/**
 * Парсер текстового отчета apply-client.sh --status
 * @param {string} text
 * @returns {Object}
 */
function parseMgmtReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		iface: 'xft_mgmt',
		stateDir: '',
		savedConf: '',
		status: 'disabled',
		proto: '',
		defaultroute: '0',
		addresses: '',
		endpoint: '',
		allowedIps: '',
		awgMissing: false,
		isInterfaceUp: false,
		latestHandshake: '',
		transfer: '',
		rawText: String(text || '')
	};

	var inIfstatus = false;
	var inAwg = false;
	var ifstatusBuf = [];

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i].trim();
		if (!line)
			continue;

		if (line === '--- ifstatus ---') {
			inIfstatus = true;
			inAwg = false;
			continue;
		}
		if (line === '--- awg ---') {
			inIfstatus = false;
			inAwg = true;
			continue;
		}

		if (inIfstatus) {
			ifstatusBuf.push(line);
			if (line.indexOf('"up": true') !== -1 || line.indexOf('"up":true') !== -1)
				res.isInterfaceUp = true;
			continue;
		}

		if (inAwg) {
			var mHs = line.match(/^latest handshake:\s*(.+)$/i);
			if (mHs) res.latestHandshake = mHs[1].trim();

			var mTr = line.match(/^transfer:\s*(.+)$/i);
			if (mTr) res.transfer = mTr[1].trim();
			continue;
		}

		var mIf = line.match(/^iface:\s*(.+)$/i);
		if (mIf) { res.iface = mIf[1].trim(); continue; }

		var mSd = line.match(/^state_dir:\s*(.+)$/i);
		if (mSd) { res.stateDir = mSd[1].trim(); continue; }

		var mSc = line.match(/^saved_conf:\s*(.+)$/i);
		if (mSc) { res.savedConf = mSc[1].trim(); continue; }

		var mSt = line.match(/^status:\s*(.+)$/i);
		if (mSt) { res.status = mSt[1].trim().toLowerCase(); continue; }

		var mPr = line.match(/^proto:\s*(.+)$/i);
		if (mPr) { res.proto = mPr[1].trim(); continue; }

		var mDr = line.match(/^defaultroute:\s*(.+)$/i);
		if (mDr) { res.defaultroute = mDr[1].trim(); continue; }

		var mAd = line.match(/^addresses:\s*(.+)$/i);
		if (mAd) { res.addresses = mAd[1].trim(); continue; }

		var mEp = line.match(/^endpoint:\s*(.+)$/i);
		if (mEp) { res.endpoint = mEp[1].trim(); continue; }

		var mAl = line.match(/^allowed_ips:\s*(.+)$/i);
		if (mAl) { res.allowedIps = mAl[1].trim(); continue; }

		if (line.indexOf('awg: missing') !== -1) {
			res.awgMissing = true;
		}
	}

	if (res.status === 'enabled' && res.latestHandshake) {
		res.isInterfaceUp = true;
	}

	return res;
}

/**
 * Карточка 1: Состояние оверлея
 */
function renderStatusCard(info) {
	var isEnabled = info.status === 'enabled';
	var isUp = isEnabled && info.isInterfaceUp;
	var tone = isUp ? 'ok' : (isEnabled ? 'warn' : 'muted');
	var badgeText = isUp ? _('Активен') : (isEnabled ? _('Подключение…') : _('Отключен'));

	var rows = [
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Сетевой интерфейс') ]),
			E('strong', {}, [ info.iface + (info.proto ? ' (' + info.proto + ')' : '') ])
		]),
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Состояние туннеля') ]),
			xcmp.badge({ text: isUp ? _('Соединение установлено') : (isEnabled ? _('Ожидание Handshake') : _('Интерфейс остановлен')), tone: tone })
		])
	];

	if (info.latestHandshake) {
		rows.push(E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Последний Handshake') ]),
			E('span', { 'style': 'font-family: monospace; font-size: 12px;' }, [ info.latestHandshake ])
		]));
	}

	if (info.transfer) {
		rows.push(E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Передано / Принято') ]),
			E('span', { 'style': 'font-family: monospace; font-size: 12px;' }, [ info.transfer ])
		]));
	}

	if (info.awgMissing) {
		rows.push(E('div', {
			'class': 'alert-message warning',
			'style': 'margin-top: 10px; font-size: 12px; padding: 8px 12px;'
		}, [
			_('Пакет amneziawg не установлен в системе. Установите модуль AmneziaWG для работы оверлея.')
		]));
	}

	return xcmp.card({
		title: _('Оверлей управления'),
		subtitle: _('Защищенный AmneziaWG-туннель для удаленного мониторинга и координации'),
		badge: xcmp.badge({ text: badgeText, tone: tone, pulse: isEnabled }),
		tone: tone,
		content: rows
	});
}

/**
 * Карточка 2: Параметры сети и маршрутизации
 */
function renderNetworkCard(info) {
	var rows = [
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Адрес в оверлее') ]),
			E('strong', { 'style': 'font-family: monospace;' }, [ info.addresses || '—' ])
		]),
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Мастер-хаб (Endpoint)') ]),
			E('span', { 'style': 'font-family: monospace;' }, [ (info.endpoint && info.endpoint !== ':') ? info.endpoint : '—' ])
		]),
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Разрешенные подсети') ]),
			E('span', { 'style': 'font-family: monospace;' }, [ info.allowedIps || '10.77.0.0/24' ])
		]),
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Конфигурация клиента') ]),
			E('span', { 'class': 'muted', 'style': 'font-size: 12px; font-family: monospace; word-break: break-all;' }, [ info.savedConf || '(none)' ])
		])
	];

	return xcmp.card({
		title: _('Параметры подключения'),
		subtitle: _('Сетевые реквизиты, адресация и маршрутизация оверлея'),
		badge: xcmp.badge({ text: '10.77.0.0/24', tone: 'standby' }),
		content: rows
	});
}

/**
 * Карточка 3: Действия
 */
function renderActionsCard(info, panelView, onRefresh) {
	var isEnabled = info.status === 'enabled';
	var buttons = [];

	if (isEnabled) {
		buttons.push(xcmp.button({
			text: _('Отключить оверлей'),
			tone: 'danger',
			onClick: function (ev) {
				if (!confirm(_('Отключить сетевой интерфейс xft_mgmt оверлея управления?')))
					return;
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtDisable').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Оверлей управления отключен') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка отключения: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
		buttons.push(xcmp.button({
			text: _('Переподключить (ensure-client)'),
			tone: 'ghost',
			onClick: function (ev) {
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtConnect').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Команда подключения выполнена') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка подключения: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
	} else {
		buttons.push(xcmp.button({
			text: '⚡ ' + _('Включить оверлей'),
			tone: 'primary',
			onClick: function (ev) {
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtEnable').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Оверлей управления включен') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка включения: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
		buttons.push(xcmp.button({
			text: '☁ ' + _('Подключить через Cloud (ensure-client)'),
			tone: 'ghost',
			onClick: function (ev) {
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtConnect').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Команда подключения к хабу выполнена') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка подключения: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
	}

	return xcmp.card({
		title: _('Управление подключением'),
		subtitle: _('Включение, выключение и автоматическая инициализация клиента'),
		badge: xcmp.badge({ text: 'Control', tone: 'standby' }),
		content: E('div', { 'style': 'display: flex; gap: 8px; flex-wrap: wrap; align-items: center;' }, buttons)
	});
}

return baseclass.extend({
	parseReport: parseMgmtReport,

	render: function (opts) {
		opts = opts || {};
		var view = opts.view || {};
		var execResult = opts.execResult || (opts.data && opts.data.execResult) || {};
		var rawText = (execResult && execResult.stdout) ? execResult.stdout : (typeof execResult === 'string' ? execResult : '');
		var info = parseMgmtReport(rawText);
		var onRefresh = opts.onRefresh;
		var isRefreshing = !!(opts && opts.isRefreshing);

		var panelView = {
			runSystemAction: function (action, arg, payload) {
				var x = (typeof xui !== 'undefined') ? xui : null;
				if (x && typeof x.runSystemMenuWithOutput === 'function') {
					return x.runSystemMenuWithOutput(action, arg, payload);
				}
				if (typeof view.runSystemAction === 'function') {
					return view.runSystemAction(action, arg, payload);
				}
				if (view && typeof view.runSystemMenu === 'function') {
					return view.runSystemMenu(action, arg, payload);
				}
				return Promise.reject(new Error('runSystemMenu is not available'));
			}
		};

		var cards = [
			renderStatusCard(info),
			renderNetworkCard(info),
			renderActionsCard(info, panelView, onRefresh)
		];

		var refreshBtn = xcmp.refreshButton({
			isRefreshing: isRefreshing,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(refreshBtn, res);
					}
				}
			}
		});

		var actionBar = xcmp.actionBar({
			title: _('Хаб управления (XFree Mgmt Hub)'),
			description: _('Удаленный доступ, телеметрия и координация роутера через защищенный оверлей AmneziaWG'),
			actions: [ refreshBtn ]
		});

		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод status.sh)'),
			rawText: rawText,
			maxHeight: '300px'
		});

		return E('div', { 'class': 'xfree-web xfree-system-mgmt-panel' }, [
			actionBar,
			E('div', {
				'class': 'xfree-card-grid',
				'style': 'display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 16px;'
			}, cards),
			spoiler
		]);
	}
});
