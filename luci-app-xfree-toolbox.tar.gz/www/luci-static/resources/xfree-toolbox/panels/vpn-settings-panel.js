'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.panels.vpn-screen as vpnScreen';

var Screen = vpnScreen.Screen;
var TAG = 'xfree-vpn-settings';

function parseKvLines(res) {
	var text = (res && typeof res === 'object' && typeof xui.formatExecReport === 'function')
		? xui.formatExecReport(res)
		: String(res || '');
	var out = {};

	String(text || '').split(/\r?\n/).forEach(function (line) {
		var idx = line.indexOf('=');
		if (idx <= 0)
			return;
		out[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
	});
	return out;
}

function modeLabel(mode) {
	if (mode === 'off') return _('Выключен (off)');
	if (mode === 'selective') return _('Выборочный (selective)');
	if (mode === 'full') return _('Полный (full)');
	return _('Авто (auto)');
}

wc.define(TAG, class extends Screen {
	mount(spec) {
		Screen.prototype.mount.call(this, spec);
		this._wan6Loading = false;
		this._wan6Saving = false;
		this._wan6Loaded = false;
		this._wan6State = {
			mode: 'auto',
			effective: 'off',
			hasIpv6: false,
			zapretIpv6: ''
		};
		this._wan6DraftMode = null;
		this._wan6DraftZapret = null;
		this._loadWan6Status();
	}

	_loadWan6Status() {
		var self = this;

		if (self._wan6Loading)
			return Promise.resolve();
		self._wan6Loading = true;
		self.requestPaint();

		return xui.runSystemMenu('wan6PolicyStatus').then(function (res) {
			var kv = parseKvLines(res);

			self._wan6State = {
				mode: kv.XFREE_WAN6_MODE || 'auto',
				effective: kv.XFREE_WAN6_EFFECTIVE || 'off',
				hasIpv6: kv.XFREE_WAN6_HAS_IPV6 === '1',
				zapretIpv6: kv.XFREE_ZAPRET_IPV6 || ''
			};
			self._wan6DraftMode = self._wan6State.mode;
			self._wan6DraftZapret = self._wan6State.zapretIpv6;
			self._wan6Loaded = true;
			self._wan6Loading = false;
			self.requestPaint();
		}).catch(function (err) {
			self._wan6Loading = false;
			self.setMessage((err && err.message) || String(err), 'bad');
			self.requestPaint();
		});
	}

	_saveWan6Policy() {
		var self = this;
		var mode = self._wan6DraftMode || 'auto';
		var zapretV6 = self._wan6DraftZapret != null ? String(self._wan6DraftZapret) : '';

		if (self._wan6Saving)
			return;
		self._wan6Saving = true;
		self.setMessage(_('Применяю политику WAN6…'), '');
		self.requestPaint();

		return xui.runSystemMenu('wan6PolicySet', mode, zapretV6).then(function (res) {
			var kv = parseKvLines(res);

			if (kv.XFREE_WAN6_MODE) {
				self._wan6State = {
					mode: kv.XFREE_WAN6_MODE || mode,
					effective: kv.XFREE_WAN6_EFFECTIVE || mode,
					hasIpv6: kv.XFREE_WAN6_HAS_IPV6 === '1',
					zapretIpv6: kv.XFREE_ZAPRET_IPV6 != null ? kv.XFREE_ZAPRET_IPV6 : zapretV6
				};
				self._wan6DraftMode = self._wan6State.mode;
				self._wan6DraftZapret = self._wan6State.zapretIpv6;
			}
			self._wan6Saving = false;
			self.setMessage(_('Политика WAN6 применена: %s').format(modeLabel(self._wan6State.mode)), 'ok');
			self.requestPaint();
		}).catch(function (err) {
			self._wan6Saving = false;
			self.setMessage((err && err.message) || String(err), 'bad');
			self.requestPaint();
		});
	}

	paint() {
		var self = this;
		var st = self._wan6State || {};
		var mode = self._wan6DraftMode != null ? self._wan6DraftMode : (st.mode || 'auto');
		var zapretV6 = self._wan6DraftZapret != null ? self._wan6DraftZapret : (st.zapretIpv6 || '');
		var busy = self._wan6Loading || self._wan6Saving || self._busy;
		var dirty = self._wan6Loaded && (mode !== st.mode || zapretV6 !== (st.zapretIpv6 || ''));

		this.className = 'xfree-vpn-root';
		this.setAttribute('data-xfree-vpn-view', 'settings');

		var chips = [
			xcmp.chip({
				label: _('Режим'),
				loading: self._wan6Loading && !self._wan6Loaded,
				value: modeLabel(st.mode || 'auto')
			}),
			xcmp.chip({
				label: _('Активно сейчас'),
				loading: self._wan6Loading && !self._wan6Loaded,
				value: modeLabel(st.effective || 'off'),
				tone: st.effective === 'off' ? '' : 'ok'
			}),
			xcmp.chip({
				label: _('IPv6 на роутере'),
				loading: self._wan6Loading && !self._wan6Loaded,
				value: st.hasIpv6 ? _('обнаружен') : _('не обнаружен'),
				tone: st.hasIpv6 ? 'ok' : ''
			})
		];

		var modeSelect = E('select', {
			'class': 'cbi-input-select',
			'disabled': busy ? 'disabled' : null,
			'change': function (ev) {
				self._wan6DraftMode = ev.target.value;
				self.requestPaint();
			}
		}, [
			E('option', { 'value': 'auto', 'selected': mode === 'auto' ? 'selected' : null }, [
				_('Авто (auto) — selective при наличии IPv6, иначе off')
			]),
			E('option', { 'value': 'selective', 'selected': mode === 'selective' ? 'selected' : null }, [
				_('Выборочный (selective) — VPN IPv6 + домены из колонки WAN6')
			]),
			E('option', { 'value': 'full', 'selected': mode === 'full' ? 'selected' : null }, [
				_('Полный (full) — весь IPv6 напрямую + защита утечек VPN')
			]),
			E('option', { 'value': 'off', 'selected': mode === 'off' ? 'selected' : null }, [
				_('Выключен (off) — отключить WAN6 на WAN и LAN')
			])
		]);

		var zapretSelect = E('select', {
			'class': 'cbi-input-select',
			'disabled': busy ? 'disabled' : null,
			'change': function (ev) {
				self._wan6DraftZapret = ev.target.value;
				self.requestPaint();
			}
		}, [
			E('option', { 'value': '', 'selected': zapretV6 === '' ? 'selected' : null }, [
				_('По умолчанию (1 для full, 0 для остальных)')
			]),
			E('option', { 'value': '0', 'selected': zapretV6 === '0' ? 'selected' : null }, [
				_('Отключено (0)')
			]),
			E('option', { 'value': '1', 'selected': zapretV6 === '1' ? 'selected' : null }, [
				_('Включено (1)')
			])
		]);

		var card = E('div', { 'class': 'xfree-vpn-card' }, [
			E('div', { 'class': 'xfree-vpn-card-head' }, [
				E('h4', {}, [_('Политика WAN6 (IPv6)')]),
				E('span', { 'class': 'badge ' + (st.effective === 'off' ? '' : 'ok') }, [
					st.effective === 'off' ? 'OFF' : String(st.effective || 'AUTO').toUpperCase()
				])
			]),
			E('p', { 'class': 'muted', 'style': 'margin-bottom: 12px;' }, [
				_('Управляет работой IPv6 на интерфейсах WAN/LAN, защитой от утечек IPv6 через VPN и режимом маршрутизации списков колонки «WAN6» в разделе «Маршруты».')
			]),
			E('div', { 'style': 'display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; margin-bottom: 14px;' }, [
				E('label', { 'style': 'display: flex; flex-direction: column; gap: 6px;' }, [
					E('span', { 'style': 'font-size: 12px; font-weight: 600;' }, [_('Режим политики WAN6')]),
					modeSelect
				]),
				E('label', { 'style': 'display: flex; flex-direction: column; gap: 6px;' }, [
					E('span', { 'style': 'font-size: 12px; font-weight: 600;' }, [_('Обработка IPv6 в Zapret')]),
					zapretSelect
				])
			]),
			E('div', { 'class': 'xfree-vpn-server-actions', 'style': 'display: flex; gap: 8px; flex-wrap: wrap; align-items: center;' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					extraClass: 'is-primary',
					disabled: busy,
					text: self._wan6Saving ? _('Применение…') : ('⚡ ' + _('Сохранить и применить')),
					onClick: function (ev) {
						ev.preventDefault();
						self._saveWan6Policy();
					}
				}),
				xcmp.button({
					variant: 'vpn',
					disabled: busy,
					text: '🔄 ' + _('Обновить статус'),
					onClick: function (ev) {
						ev.preventDefault();
						self._loadWan6Status();
					}
				}),
				dirty ? E('span', { 'class': 'muted', 'style': 'font-size: 12px;' }, [_('Есть несохранённые изменения')]) : ''
			])
		]);

		this.replaceChildren(
			E('div', { 'class': 'xfree-vpn-head' }, [
				E('div', { 'class': 'xfree-vpn-head-left' }, [
					E('h3', {}, [_('Дополнительные настройки VPN')]),
					E('p', { 'class': 'muted' }, [_('Политика IPv6 (WAN6) и дополнительные параметры подсистемы VPN')])
				]),
				E('div', { 'class': 'xfree-vpn-head-right' }, [
					E('div', {
						'class': 'xfree-vpn-msg' + (self._msgTone ? ' is-' + self._msgTone : ''),
						'data-xfree-vpn-msg': '1'
					}, [self._msg || ''])
				])
			]),
			E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips),
			card
		);
	}
});

return baseclass.extend({
	TAG: TAG
});
