'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.panels.vpn-catalog as catalog';

return baseclass.extend({
	_openConfManager: function (filterKind) {
		var self = this;
		var s = this._spec || {};
		var all = (this._summary && this._summary.confs) || [];
		var kindFilter = String(filterKind || '').toLowerCase();
		var confs = [];
		var list;
		var rows = [];
		var i;
		var c;
		var title;
		var hint;

		function reopen() {
			self._openConfManager(kindFilter);
		}

		function downloadText(name, text) {
			var a = document.createElement('a');
			var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });

			a.href = URL.createObjectURL(blob);
			a.download = name;
			document.body.appendChild(a);
			a.click();
			setTimeout(function () {
				URL.revokeObjectURL(a.href);
				a.remove();
			}, 500);
		}

		function showEditor(kind, file, initial) {
			var ta = E('textarea', {
				'class': 'xfree-vpn-conf-editor',
				'rows': 18
			}, [initial || '']);

			xui.openDialog({
				title: _('Редактировать %s').format(file),
				size: 'wide',
				hint: kind + ' / ' + file,
				body: ta,
				actions: [
					{
						label: _('Назад'),
						variant: 'secondary',
						close: true,
						click: function () {
							reopen();
						}
					},
					{
						label: _('Сохранить'),
						variant: 'primary',
						close: false,
						click: function () {
							var body = String(ta.value || '');
							var b64;

							try {
								b64 = btoa(unescape(encodeURIComponent(body)));
							} catch {
								self.setMessage(_('Не удалось закодировать файл'), 'bad');
								return;
							}
							ui.hideModal();
							if (s.onAction)
								s.onAction('confSave', kind + '|' + file + '|b64:' + b64);
						}
					}
				]
			});
		}

		function extractConfBody(text) {
			var raw = String(text || '');
			var a = raw.indexOf('CONF_BODY_BEGIN\n');
			var b = raw.indexOf('\nCONF_BODY_END');

			if (a >= 0 && b > a)
				return raw.slice(a + 'CONF_BODY_BEGIN\n'.length, b);
			return raw;
		}

		function loadAnd(kind, file, mode) {
			if (!s.onAction)
				return;
			self.setBusy(true);
			s.onAction('confShow', kind + '|' + file, null, function (res, text) {
				var body = extractConfBody(text || '');

				self.setBusy(false);
				if (!res || (res.code && res.code !== 0)) {
					self.setMessage(_('Не удалось прочитать %s').format(file), 'bad');
					return;
				}

				if (mode === 'view') {
					xui.openDialog({
						title: _('Просмотр %s').format(file),
						size: 'wide',
						body: E('pre', { 'class': 'xfree-vpn-conf-view' }, [body]),
						actions: [{
							label: _('Назад'),
							variant: 'secondary',
							close: true,
							click: function () {
								reopen();
							}
						}]
					});
				} else if (mode === 'download') {
					downloadText(file, body);
					reopen();
				} else if (mode === 'edit') {
					showEditor(kind, file, body);
				}
			});
		}

		for (i = 0; i < all.length; i++) {
			c = all[i];
			if (kindFilter && String(c.kind || '').toLowerCase() !== kindFilter)
				continue;
			confs.push(c);
		}

		if (!confs.length) {
			var emptyActions = [];
			if (kindFilter && all.length) {
				emptyActions.push({
					label: _('Показать все .conf (%d)').format(all.length),
					variant: 'secondary',
					close: true,
					click: function () {
						self._openConfManager('');
					}
				});
			}
			emptyActions.push({ label: _('Закрыть'), variant: 'primary', close: true });
			xui.openDialog({
				title: kindFilter ? _('Файлы .conf — %s').format(kindFilter) : _('Файлы .conf'),
				hint: '',
				body: E('div', { 'class': 'xfree-vpn-pick' }, [
					E('p', {}, [
						kindFilter
							? _('Нет .conf для «%s» — сначала сгенерируйте или импортируйте конфигурацию.').format(kindFilter)
							: _('Нет сгенерированных .conf — сначала сгенерируйте WARP/Proton или импортируйте файл.')
					])
				]),
				actions: emptyActions
			});
			return;
		}

		var unusedCount = 0;
		for (i = 0; i < confs.length; i++) {
			if (!confs[i].usedBy)
				unusedCount++;
		}

		for (i = 0; i < confs.length; i++) {
			c = confs[i];
			(function (row) {
				var metaBits = [row.file];

				if (!kindFilter && row.kind)
					metaBits.push(row.kind);
				if (row.created)
					metaBits.push(row.created);

				rows.push(E('div', { 'class': 'xfree-vpn-conf-row' }, [
					E('div', { 'class': 'xfree-vpn-conf-name' }, [
						E('div', { 'style': 'display: flex; align-items: center; gap: 8px; flex-wrap: wrap;' }, [
							E('strong', { 'title': row.file }, [catalog.formatConfLabel(row, { showUsedBy: false })]),
							row.usedBy
								? E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size: 11px;' }, ['✓ ' + _('используется: %s').format(row.usedBy)])
								: E('span', { 'class': 'xfree-vpn-badge', 'style': 'font-size: 11px;' }, [_('не используется')])
						]),
						metaBits.length
							? E('div', { 'class': 'muted xfree-vpn-conf-meta' }, [
								metaBits.join(' · ')
							])
							: ''
					]),
					E('div', { 'class': 'xfree-vpn-conf-actions' }, [
						xui.dialogBtn({
							label: _('Просмотр'),
							variant: 'ghost',
							compact: true,
							click: function () {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'view');
							}
						}),
						xui.dialogBtn({
							label: _('Скачать'),
							variant: 'ghost',
							compact: true,
							click: function () {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'download');
							}
						}),
						xui.dialogBtn({
							label: _('Изменить'),
							variant: 'ghost',
							compact: true,
							click: function () {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'edit');
							}
						}),
						xui.dialogBtn({
							label: _('Удалить'),
							variant: 'danger',
							compact: true,
							click: function () {
								ui.hideModal();
								if (s.onAction) {
									var confirmMsg = row.usedBy
										? _('ВНИМАНИЕ: конфигурация используется интерфейсом %s! Удалить %s?').format(row.usedBy, row.file)
										: _('Удалить %s?').format(row.file);
									s.onAction('confDelete', row.kind + '|' + row.file, confirmMsg);
								}
							}
						})
					])
				]));
			})(c);
		}

		if (kindFilter === 'warp') {
			title = _('Конфигурации WARP .conf');
			hint = _('Файлы генератора WARP. Дата — локальное время роутера (mtime). После правки — «Обновить» на туннеле.');
		} else if (kindFilter === 'proton') {
			title = _('Конфигурации Proton .conf');
			hint = _('Файлы генератора Proton. Дата — локальное время роутера (mtime). После правки — «Обновить» на туннеле.');
		} else {
			title = _('Конфигурации .conf');
			hint = _('Файлы в каталогах генераторов. Дата — локальное время роутера (mtime).');
		}

		list = E('div', { 'class': 'xfree-vpn-conf-list' }, rows);
		xui.openDialog({
			title: title,
			size: 'lg',
			hint: hint,
			body: list,
			actions: [
				{
					label: unusedCount > 0
						? _('Удалить неиспользуемые (%d)').format(unusedCount)
						: _('Удалить неиспользуемые'),
					variant: 'danger',
					disabled: unusedCount === 0,
					click: function () {
						ui.hideModal();
						if (s.onAction) {
							var confirmMsg = unusedCount > 0
								? _('Удалить неиспользуемые файлы конфигураций (%d шт.)?').format(unusedCount)
								: _('Удалить неиспользуемые файлы конфигураций?');
							s.onAction('confDeleteUnused', kindFilter || '', confirmMsg);
						}
					}
				},
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				}
			]
		});
	},

	_deleteIface: function (ev, ifaceName) {
		var s = this._spec || {};
		var modeLabels = {
			full: _('полная очистка'),
			basic: _('только туннель')
		};

		ev.preventDefault();
		ev.stopPropagation();
		this._pickSelect(
			_('Удалить «%s»').format(ifaceName),
			_('Режим очистки'),
			[
				{ v: 'full', t: _('Полная очистка — удалить туннель, обновить DNS и маршрутизацию') },
				{ v: 'basic', t: _('Только туннель — без обновления DNS и маршрутизации') }
			],
			function (mode) {
				if (!s.onAction)
					return;
				var confirmMsg = mode === 'basic'
					? _('Удалить туннель «%s» (только туннель)? После удаления всех нужных туннелей нажмите «Применить маршрутизацию» для обновления DNS и правил.').format(ifaceName)
					: _('Удалить туннель «%s» (%s)?').format(ifaceName, modeLabels[mode] || mode);
				s.onAction('delete', ifaceName + '|' + mode, confirmMsg);
			}
		);
	},

	collectFields: function (prefix) {
		var out = {};

		this.querySelectorAll('[data-xfree-vpn-field]').forEach(function (el) {
			var id = el.getAttribute('data-xfree-vpn-field') || '';

			if (prefix && id.indexOf(prefix) !== 0)
				return;
			out[id] = String(el.value || '').trim();
		});

		return out;
	},

	_pipeArgs: function (map, keys) {
		var parts = [];
		var i;
		var k;
		var short;

		for (i = 0; i < keys.length; i++) {
			k = keys[i];
			short = k.replace(/^warp_/, '').replace(/^proton_/, '');
			parts.push(short + '=' + (map[k] != null ? map[k] : ''));
		}

		return parts.join('|');
	},

	_saveWarp: function (ev) {
		var s = this._spec || {};
		var f = this.collectFields('warp_');
		var arg;

		ev.preventDefault();
		arg = this._pipeArgs(f, [
			'warp_server', 'warp_profile', 'warp_mode',
			'warp_i1_mode', 'warp_i1_domain', 'warp_name',
			'warp_selection', 'warp_exclude_ru',
			'warp_i1_entropy', 'warp_awg_noise'
		]);
		if (s.onAction)
			s.onAction('warpSave', arg);
	},

	_saveProton: function (ev) {
		var s = this._spec || {};
		var f = this.collectFields('proton_');
		var arg;

		ev.preventDefault();
		arg = this._pipeArgs(f, [
			'proton_country', 'proton_session_mode', 'proton_profile',
			'proton_name', 'proton_mtu', 'proton_free_only',
			'proton_require_ipv6', 'proton_selection_mode',
			'proton_i1_entropy', 'proton_awg_noise', 'proton_port', 'proton_via',
			'proton_handshake_probe'
		]);
		if (s.onAction)
			s.onAction('protonSave', arg);
	},
});
