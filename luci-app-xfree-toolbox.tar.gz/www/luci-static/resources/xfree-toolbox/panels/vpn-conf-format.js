'use strict';
'require baseclass';
'require xfree-toolbox.panels.vpn-places as places';

function pad2(n) {
	return n < 10 ? '0' + n : String(n);
}

function formatConfStamp(ymd, hms, isUtc) {
	if (!ymd || ymd.length !== 8 || !hms || hms.length < 4)
		return '';
	var y = parseInt(ymd.slice(0, 4), 10);
	var m = parseInt(ymd.slice(4, 6), 10);
	var d = parseInt(ymd.slice(6, 8), 10);
	var hh = parseInt(hms.slice(0, 2), 10);
	var mm = parseInt(hms.slice(2, 4), 10);
	var ss = hms.length >= 6 ? parseInt(hms.slice(4, 6), 10) : 0;

	if (isUtc) {
		var dt = new Date(Date.UTC(y, m - 1, d, hh, mm, ss));
		if (!isNaN(dt.getTime())) {
			return pad2(dt.getDate()) + '.' + pad2(dt.getMonth() + 1) + ' ' +
				pad2(dt.getHours()) + ':' + pad2(dt.getMinutes());
		}
	}
	return ymd.slice(6, 8) + '.' + ymd.slice(4, 6) + ' ' + hms.slice(0, 2) + ':' + hms.slice(2, 4);
}

function formatCreatedStamp(created) {
	var s = String(created || '').trim();
	var m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::\d{2})?(?:\s*[+-]\d{2}(?::?\d{2})?)?$/);
	if (m)
		return m[3] + '.' + m[2] + ' ' + m[4] + ':' + m[5];
	return s;
}

function formatProtonServer(slug) {
	var m = String(slug || '').match(/^([a-z]{2})-(free|plus|core)-(\d+)$/i);
	if (m)
		return m[1].toUpperCase() + '-' + m[2].toUpperCase() + '#' + m[3];
	return String(slug || '').toUpperCase();
}

function formatConfLabel(conf, opts) {
	var c = (typeof conf === 'string') ? { file: conf } : (conf || {});
	var file = String(c.file || '');
	var kind = String(c.kind || '').toLowerCase();
	var countries = (places && places.COUNTRY_RU) || {};
	var isUtc = /Z\.conf$/i.test(file);
	var showUsedBy = !opts || opts.showUsedBy !== false;
	var parts = [];
	var m;
	var cc;
	var country;
	var stamp;
	var base;

	if (!file)
		return '';

	m = file.match(/^proton-(.+?)-(guest-\d{8}-\d{6}|[^-]+)-awg([^-]+)-v([^-]+)-(.+?)-(\d{8})-(\d{6})Z?\.conf$/i);
	if (m) {
		cc = (m[1].match(/^([a-z]{2})(?:-|$)/i) || [])[1];
		country = cc ? countries[cc.toUpperCase()] : '';
		parts.push('Proton');
		if (country)
			parts.push(country);
		parts.push(formatProtonServer(m[1]));
		parts.push(/^guest-/i.test(m[2]) ? _('гость') : m[2]);
		parts.push('AWG ' + m[3]);
		stamp = formatConfStamp(m[6], m[7], isUtc);
		if (stamp)
			parts.push(stamp);
	} else if ((m = file.match(/^warp-(.+?)-awg([^-]+)-v([^-]+)-(.+?)-(\d{8})-(\d{6})Z?\.conf$/i))) {
		parts.push('WARP');
		country = countries[m[1].toUpperCase()];
		parts.push(country ? (m[1] + ' (' + country + ')') : m[1]);
		parts.push('AWG ' + m[2]);
		stamp = formatConfStamp(m[5], m[6], isUtc);
		if (stamp)
			parts.push(stamp);
	} else {
		base = file.replace(/^.*\//, '').replace(/\.(conf|ovpn|json)$/i, '');
		if (kind === 'proton')
			parts.push('Proton');
		else if (kind === 'warp')
			parts.push('WARP');
		else if (kind === 'openvpn')
			parts.push('OpenVPN');
		else if (kind === 'vless')
			parts.push('VLESS');
		else if (kind === 'amnezia')
			parts.push('AmneziaWG');
		else if (kind)
			parts.push(kind);
		parts.push(base || file);
		if (c.created)
			parts.push(formatCreatedStamp(c.created));
	}

	if (showUsedBy && c.usedBy)
		parts.push('[' + c.usedBy + ']');

	return parts.join(' · ');
}

function confOptions(confs, preferKind) {
	var list = Array.isArray(confs) ? confs.slice() : [];
	var opts = [];
	var i;
	var c;
	var preferred = [];
	var rest = [];

	for (i = 0; i < list.length; i++) {
		c = list[i];
		if (!c || !c.file)
			continue;
		if (preferKind && c.kind === preferKind)
			preferred.push(c);
		else
			rest.push(c);
	}
	list = preferred.concat(rest);
	for (i = 0; i < list.length; i++) {
		c = list[i];
		opts.push({
			v: c.file,
			t: formatConfLabel(c)
		});
	}
	return opts;
}

function sanitizeIfaceName(raw) {
	var s = String(raw || '').trim()
		.replace(/[^A-Za-z0-9_]+/g, '_')
		.replace(/^_+|_+$/g, '');

	return s.slice(0, 15).replace(/_+$/g, '') || '';
}

function ifaceNameFromConf(file, existingIfaces) {
	var baseFile = String(file || '').replace(/^.*\//, '').replace(/\.(conf|ovpn|json)$/i, '');
	var base = '';
	var m;
	var used = {};
	var i;
	var row;
	var candidate;
	var seq;
	var suffix;

	if ((m = baseFile.match(/^proton-([a-z]{2})(?:-|$)/i)))
		base = 'proton_' + m[1].toLowerCase();
	else if (/^proton-/i.test(baseFile))
		base = 'proton';
	else if ((m = baseFile.match(/^warp-([a-z0-9_]+?)-awg/i)))
		base = sanitizeIfaceName('warp_' + m[1]);
	else if (/^warp-/i.test(baseFile))
		base = 'warp';
	else
		base = sanitizeIfaceName(baseFile);

	base = sanitizeIfaceName(base) || 'tunnel';

	if (Array.isArray(existingIfaces)) {
		for (i = 0; i < existingIfaces.length; i++) {
			row = existingIfaces[i];
			if (row && (row.name || row.iface))
				used[String(row.name || row.iface)] = true;
		}
	}

	if (!used[base])
		return base;

	for (seq = 2; seq < 100; seq++) {
		suffix = '_' + seq;
		candidate = base.slice(0, 15 - suffix.length).replace(/_+$/g, '') + suffix;
		if (!used[candidate])
			return candidate;
	}
	return base;
}

return baseclass.extend({
	formatConfLabel: formatConfLabel,
	confOptions: confOptions,
	sanitizeIfaceName: sanitizeIfaceName,
	ifaceNameFromConf: ifaceNameFromConf
});
