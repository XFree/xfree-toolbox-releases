'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.panels.vpn-places as places';
'require xfree-toolbox.panels.vpn-catalog as catalog';
'require xfree-toolbox.panels.vpn-screen-state as screenState';
'require xfree-toolbox.panels.vpn-screen-flow as screenFlow';
'require xfree-toolbox.panels.vpn-screen-import as screenImport';
'require xfree-toolbox.panels.vpn-screen-create as screenCreate';
'require xfree-toolbox.panels.vpn-screen-rebuild as screenRebuild';
'require xfree-toolbox.panels.vpn-screen-manage as screenManage';

/* Общие помощники и диалоги экранов VPN.
 * Туннели и генераторы открывают одни и те же окна: методы лежат на одном
 * прототипе Screen, тела — в соседних модулях. В файлы экранов их не копируют.
 * Своего тега у модуля нет. LuCI отдаёт require как экземпляр, поэтому
 * методы снимаются и с самого объекта, и с его прототипа. */

function flagTone(ok) {
	return ok ? 'ok' : 'muted';
}

function badge(label, ok) {
	return E('span', {
		'class': 'xfree-vpn-badge is-' + flagTone(ok)
	}, [label + (ok ? ' ✓' : ' —')]);
}

function healthTone(health) {
	var h = String(health || '').toLowerCase();

	if (h === 'ok') return 'ok';
	if (h === 'warn') return 'warn';
	if (h === 'fail') return 'bad';
	return 'muted';
}

function healthLabel(health) {
	var h = String(health || '').toLowerCase();

	if (h === 'ok') return 'OK';
	if (h === 'warn') return 'WARN';
	if (h === 'fail') return 'FAIL';
	return '—';
}

var VpnScreen = class extends wc.LightElement {
};

function mixScreen(part) {
	prototypeMix.mixInto(VpnScreen.prototype, part);
}

mixScreen(screenState);
mixScreen(screenFlow);
mixScreen(screenImport);
mixScreen(screenCreate);
mixScreen(screenRebuild);
mixScreen(screenManage);

return baseclass.extend({
	Screen: VpnScreen,
	COUNTRY_RU: places.COUNTRY_RU,
	WARP_COLO: places.WARP_COLO,
	countryName: places.countryName,
	coloLabel: places.coloLabel,
	coloCountry: places.coloCountry,
	coloCity: places.coloCity,
	healthTone: healthTone,
	healthLabel: healthLabel,
	badge: badge,
	renderTunnelSkeleton: catalog.renderTunnelSkeleton,
	formatConfLabel: catalog.formatConfLabel,
	listCreateKinds: catalog.listCreateKinds,
	createKindLabel: catalog.createKindLabel,
	selectField: catalog.selectField,
	textField: catalog.textField,
	secretField: catalog.secretField,
	WARP_SERVERS: catalog.WARP_SERVERS,
	WARP_PROFILES: catalog.WARP_PROFILES,
	WARP_MODES: catalog.WARP_MODES,
	WARP_I1: catalog.WARP_I1,
	WARP_SELECTION: catalog.WARP_SELECTION,
	WARP_ENTROPY_OPTIONS: catalog.WARP_ENTROPY_OPTIONS,
	PROTON_ENTROPY_OPTIONS: catalog.PROTON_ENTROPY_OPTIONS,
	PROTON_NOISE_OPTIONS: catalog.PROTON_NOISE_OPTIONS,
	PROTON_PORT_OPTIONS: catalog.PROTON_PORT_OPTIONS,
	warpServerTip: catalog.warpServerTip,
	warpServerNeedsReg: catalog.warpServerNeedsReg,
	warpServerIsLte: catalog.warpServerIsLte
});
