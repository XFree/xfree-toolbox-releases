'use strict';
'require baseclass';
'require xfree-toolbox.panels.vpn-places as places';

var COUNTRY_RU = places.COUNTRY_RU || {};

/* Country = tribukvy + бот llimonix; [LTE] = tel.*.tribukvy без бота (фильтр портов). */
var WARP_SERVERS = [
	{ v: 'def', t: 'def (Cloudflare)' },
	{ v: 'FL', t: 'Финляндия (рег.)' },
	{ v: 'NL', t: 'Нидерланды (рег.)' },
	{ v: 'PL', t: 'Польша (рег.)' },
	{ v: 'DE', t: 'Германия (рег.)' },
	{ v: 'LV', t: 'Латвия (рег.)' },
	{ v: 'RU', t: 'Россия (рег.)' },
	{ v: 'lteFL', t: '[LTE] Финляндия' },
	{ v: 'ltePL', t: '[LTE] Польша' },
	{ v: 'lteDE', t: '[LTE] Германия' }
];

var WARP_GEN_HELP_URL = 'https://warp-generation.github.io/';

function warpServerNeedsReg(v) {
	return /^(FL|NL|PL|DE|LV|RU)$/.test(String(v || ''));
}

function warpServerIsLte(v) {
	return /^(lteFL|ltePL|lteDE)$/.test(String(v || ''));
}

function warpServerTip() {
	return E('p', { 'class': 'muted xfree-vpn-tip' }, [
		_('«(рег.)» — нужна регистрация в Telegram-боте от llimonix. «[LTE]» — без бота, но со своим фильтром портов (Польша без 988, Финляндия без 1010), как на '),
		E('a', {
			'href': WARP_GEN_HELP_URL,
			'target': '_blank',
			'rel': 'noopener noreferrer'
		}, ['warp-generation.github.io']),
		_('. Для обычного доступа достаточно def (Cloudflare).')
	]);
}

var WARP_PROFILES = [
	{ v: '2.0:auto', t: 'AWG 2.0 · автоподбор' },
	{ v: '2.0:1', t: 'AWG 2.0 · вариант 1' },
	{ v: '2.0:2', t: 'AWG 2.0 · вариант 2' },
	{ v: '2.0:3', t: 'AWG 2.0 · вариант 3' }
];

var WARP_ENTROPY_OPTIONS = [
	{ v: 'off', t: _('без энтропии (по умолчанию)') },
	{ v: 'r32', t: '<r 32> · 32 байта' },
	{ v: 'r64', t: '<r 64> · 64 байта (паранойя)' },
	{ v: 't', t: '<t> · timestamp' },
	{ v: 'c', t: '<c> · счётчик' },
	{ v: 'rc10', t: '<rc 10> · 10 букв' },
	{ v: 'rd6', t: '<rd 6> · 6 цифр' }
];

var PROTON_ENTROPY_OPTIONS = [
	{ v: 'auto', t: _('автоподбор') },
	{ v: 'r32', t: '<r 32> · 32 байта (по умолчанию)' },
	{ v: 'r64', t: '<r 64> · 64 байта (паранойя)' },
	{ v: 't', t: '<t> · timestamp' },
	{ v: 'c', t: '<c> · счётчик' },
	{ v: 'rc10', t: '<rc 10> · 10 букв' },
	{ v: 'rd6', t: '<rd 6> · 6 цифр' },
	{ v: 'off', t: _('без энтропии (только <b 0x…>)') }
];

var PROTON_NOISE_OPTIONS = [
	{ v: '0', t: _('без шума (Jc=0)') },
	{ v: '1', t: _('с шумом (Jc=4, Jmin=40, Jmax=70)') }
];

var PROTON_PORT_OPTIONS = [
	{ v: 'auto', t: _('Авто (51820 + перебор: 443, 500, 4500, 1194, 5060)') },
	{ v: '51820', t: '51820 (' + _('по умолчанию') + ')' },
	{ v: '443', t: '443 (HTTPS)' },
	{ v: '500', t: '500 (IPsec/IKEv2)' },
	{ v: '4500', t: '4500 (IPsec NAT-T)' },
	{ v: '1194', t: '1194 (OpenVPN)' },
	{ v: '5060', t: '5060 (SIP)' }
];

var WARP_MODES = [
	{ v: 'local', t: 'local' },
	{ v: 'raw', t: 'raw' }
];

var WARP_I1 = [
	{ v: 'fixed', t: 'fixed' },
	{ v: 'random', t: 'random' },
	{ v: 'domain', t: 'domain-seeded' }
];

var WARP_SELECTION = [
	{ v: 'best', t: _('Топ-5 по колонии + задержка') },
	{ v: 'random', t: _('Случайный endpoint') }
];

var PROTON_COUNTRIES = (function () {
	var list = [
		{ v: 'AUTO', t: _('Все страны (AUTO)') },
		{ v: 'NL', t: _('Нидерланды (NL)') + ' [Free]' },
		{ v: 'US', t: _('США (US)') + ' [Free]' },
		{ v: 'JP', t: _('Япония (JP)') + ' [Free]' },
		{ v: 'CA', t: _('Канада (CA)') + ' [Free]' },
		{ v: 'PL', t: _('Польша (PL)') + ' [Free]' },
		{ v: 'RO', t: _('Румыния (RO)') + ' [Free]' },
		{ v: 'SG', t: _('Сингапур (SG)') + ' [Free]' },
		{ v: 'MX', t: _('Мексика (MX)') },
		{ v: 'DE', t: _('Германия (DE)') },
		{ v: 'FR', t: _('Франция (FR)') },
		{ v: 'CH', t: _('Швейцария (CH)') },
		{ v: 'SE', t: _('Швеция (SE)') },
		{ v: 'GB', t: _('Великобритания (GB)') },
		{ v: 'ES', t: _('Испания (ES)') },
		{ v: 'IT', t: _('Италия (IT)') },
		{ v: 'FI', t: _('Финляндия (FI)') },
		{ v: 'TR', t: _('Турция (TR)') },
		{ v: 'KZ', t: _('Казахстан (KZ)') },
		{ v: 'AE', t: _('ОАЭ (AE)') },
		{ v: 'BR', t: _('Бразилия (BR)') },
		{ v: 'AR', t: _('Аргентина (AR)') },
		{ v: 'AU', t: _('Австралия (AU)') }
	];
	var seen = {};
	for (var i = 0; i < list.length; i++)
		seen[list[i].v] = true;

	var rest = [];
	for (var c in COUNTRY_RU) {
		if (!seen[c]) {
			var label = COUNTRY_RU[c] + ' (' + c + ')';
			rest.push({ v: c, t: label });
		}
	}
	rest.sort(function (a, b) {
		return a.t.localeCompare(b.t, 'ru');
	});
	return list.concat(rest);
})();

return baseclass.extend({
	WARP_SERVERS: WARP_SERVERS,
	WARP_GEN_HELP_URL: WARP_GEN_HELP_URL,
	warpServerNeedsReg: warpServerNeedsReg,
	warpServerIsLte: warpServerIsLte,
	warpServerTip: warpServerTip,
	WARP_PROFILES: WARP_PROFILES,
	WARP_MODES: WARP_MODES,
	WARP_I1: WARP_I1,
	WARP_SELECTION: WARP_SELECTION,
	WARP_ENTROPY_OPTIONS: WARP_ENTROPY_OPTIONS,
	PROTON_ENTROPY_OPTIONS: PROTON_ENTROPY_OPTIONS,
	PROTON_NOISE_OPTIONS: PROTON_NOISE_OPTIONS,
	PROTON_PORT_OPTIONS: PROTON_PORT_OPTIONS,
	PROTON_COUNTRIES: PROTON_COUNTRIES
});
