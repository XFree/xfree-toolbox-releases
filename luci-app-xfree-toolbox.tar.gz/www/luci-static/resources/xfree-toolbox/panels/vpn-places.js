'use strict';
'require baseclass';
'require xfree-toolbox.panels.vpn-places-colo as colo';

/* ISO country code → Russian name */
var COUNTRY_RU = {
	AD: 'Андорра',
	AE: 'ОАЭ',
	AF: 'Афганистан',
	AL: 'Албания',
	AM: 'Армения',
	AO: 'Ангола',
	AR: 'Аргентина',
	AT: 'Австрия',
	AU: 'Австралия',
	AZ: 'Азербайджан',
	BA: 'Босния и Герцеговина',
	BB: 'Барбадос',
	BD: 'Бангладеш',
	BE: 'Бельгия',
	BF: 'Буркина-Фасо',
	BG: 'Болгария',
	BH: 'Бахрейн',
	BN: 'Бруней',
	BO: 'Боливия',
	BR: 'Бразилия',
	BT: 'Бутан',
	BW: 'Ботсвана',
	BY: 'Беларусь',
	CA: 'Канада',
	CH: 'Швейцария',
	CI: 'Кот-д\'Ивуар',
	CL: 'Чили',
	CM: 'Камерун',
	CN: 'Китай',
	CO: 'Колумбия',
	CR: 'Коста-Рика',
	CY: 'Кипр',
	CZ: 'Чехия',
	DE: 'Германия',
	DJ: 'Джибути',
	DK: 'Дания',
	DO: 'Доминиканская Республика',
	DZ: 'Алжир',
	EC: 'Эквадор',
	EE: 'Эстония',
	EG: 'Египет',
	ES: 'Испания',
	ET: 'Эфиопия',
	FI: 'Финляндия',
	FJ: 'Фиджи',
	FR: 'Франция',
	GB: 'Великобритания',
	GD: 'Гренада',
	GE: 'Грузия',
	GH: 'Гана',
	GR: 'Греция',
	GT: 'Гватемала',
	GU: 'Гуам',
	GY: 'Гайана',
	HK: 'Гонконг',
	HN: 'Гондурас',
	HR: 'Хорватия',
	HU: 'Венгрия',
	ID: 'Индонезия',
	IE: 'Ирландия',
	IL: 'Израиль',
	IN: 'Индия',
	IQ: 'Ирак',
	IS: 'Исландия',
	IT: 'Италия',
	JM: 'Ямайка',
	JO: 'Иордания',
	JP: 'Япония',
	KE: 'Кения',
	KG: 'Кыргызстан',
	KH: 'Камбоджа',
	KR: 'Южная Корея',
	KW: 'Кувейт',
	KZ: 'Казахстан',
	LA: 'Лаос',
	LB: 'Ливан',
	LK: 'Шри-Ланка',
	LT: 'Литва',
	LU: 'Люксембург',
	LV: 'Латвия',
	MA: 'Марокко',
	MD: 'Молдова',
	ME: 'Черногория',
	MG: 'Мадагаскар',
	MK: 'Северная Македония',
	MM: 'Мьянма',
	MN: 'Монголия',
	MO: 'Макао',
	MT: 'Мальта',
	MU: 'Маврикий',
	MV: 'Мальдивы',
	MX: 'Мексика',
	MY: 'Малайзия',
	MZ: 'Мозамбик',
	NA: 'Намибия',
	NC: 'Новая Каледония',
	NG: 'Нигерия',
	NL: 'Нидерланды',
	NO: 'Норвегия',
	NP: 'Непал',
	NZ: 'Новая Зеландия',
	OM: 'Оман',
	PA: 'Панама',
	PE: 'Перу',
	PF: 'Французская Полинезия',
	PG: 'Папуа — Новая Гвинея',
	PH: 'Филиппины',
	PK: 'Пакистан',
	PL: 'Польша',
	PR: 'Пуэрто-Рико',
	PS: 'Палестина',
	PT: 'Португалия',
	PY: 'Парагвай',
	QA: 'Катар',
	RO: 'Румыния',
	RS: 'Сербия',
	RU: 'Россия',
	RW: 'Руанда',
	SA: 'Саудовская Аравия',
	SE: 'Швеция',
	SG: 'Сингапур',
	SI: 'Словения',
	SK: 'Словакия',
	SN: 'Сенегал',
	SR: 'Суринам',
	SV: 'Сальвадор',
	TH: 'Таиланд',
	TN: 'Тунис',
	TR: 'Турция',
	TT: 'Тринидад и Тобаго',
	TW: 'Тайвань',
	TZ: 'Танзания',
	UA: 'Украина',
	UG: 'Уганда',
	US: 'США',
	UY: 'Уругвай',
	UZ: 'Узбекистан',
	VE: 'Венесуэла',
	VN: 'Вьетнам',
	ZA: 'ЮАР',
	ZM: 'Замбия',
	ZW: 'Зимбабве',
};

var WARP_COLO = (colo && colo.WARP_COLO) || {};

function countryName(code) {
	if (!code)
		return '';
	var c = String(code).toUpperCase().trim();
	return COUNTRY_RU[c] || code;
}

function coloInfo(coloCode) {
	var c = String(coloCode || '').toUpperCase();
	return (c && WARP_COLO[c]) || null;
}

function coloCity(coloCode) {
	var info = coloInfo(coloCode);
	return info ? info[0] : '';
}

function coloCountry(coloCode) {
	var info = coloInfo(coloCode);
	return info ? info[1] : '';
}

function coloLabel(coloCode) {
	var c = String(coloCode || '').toUpperCase();
	var info;
	var city;
	var cc;
	var country;
	var loc = [];

	if (!c)
		return '';
	info = coloInfo(c);
	if (info) {
		city = info[0];
		cc = info[1];
		country = countryName(cc);
		if (city)
			loc.push(city);
		if (country)
			loc.push(country);
		if (loc.length)
			return c + ' (' + loc.join(' / ') + ')';
	}
	return c;
}

return baseclass.extend({
	COUNTRY_RU: COUNTRY_RU,
	WARP_COLO: WARP_COLO,
	countryName: countryName,
	coloCity: coloCity,
	coloCountry: coloCountry,
	coloLabel: coloLabel
});
