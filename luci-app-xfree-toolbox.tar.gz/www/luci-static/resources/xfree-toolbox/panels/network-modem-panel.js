'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.loading as loading';

var xcmp = components;

function _uiMarkerValue(line, key) {
	var prefix = key + ':';
	if (line.indexOf(prefix) !== 0)
		return null;
	return line.substring(prefix.length).trim();
}

function _uiPkgMarker(line) {
	/* UI_PKG:<name>=yes|no|? */
	if (line.indexOf('UI_PKG:') !== 0)
		return null;
	var body = line.substring(7);
	var eq = body.indexOf('=');
	if (eq < 1)
		return null;
	return {
		name: body.substring(0, eq).trim(),
		value: body.substring(eq + 1).trim()
	};
}

/**
 * Парсер отчёта modemDiag: только маркеры UI_* / UI_PKG:* (канон uplink + pm_is_installed).
 * @param {string} text
 * @returns {Object}
 */
function parseModemReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		detected: false,
		heuristicMode: '',
		confidence: '',
		hasCdcWdm: false,
		hasTtyUsb: false,
		hasLteIface: false,
		hasWwanIface: false,
		lteDetail: '',
		wwanDetail: '',
		probeIface: '',
		pkgs: {},
		cdcEtherInstalled: false,
		usbModeswitchInstalled: false,
		recommendation: '',
		rawText: String(text || '')
	};

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i].trim();
		if (!line)
			continue;

		var pkg = _uiPkgMarker(line);
		if (pkg) {
			res.pkgs[pkg.name] = pkg.value;
			if (pkg.name === 'kmod-usb-net-cdc-ether')
				res.cdcEtherInstalled = (pkg.value === 'yes');
			if (pkg.name === 'usb-modeswitch')
				res.usbModeswitchInstalled = (pkg.value === 'yes');
			continue;
		}

		var v;
		if ((v = _uiMarkerValue(line, 'UI_PROBE_IFACE')) !== null) {
			res.probeIface = v;
			continue;
		}
		if ((v = _uiMarkerValue(line, 'UI_LTE_IFACE')) !== null) {
			res.hasLteIface = (v === 'yes');
			if (res.hasLteIface) res.detected = true;
			continue;
		}
		if ((v = _uiMarkerValue(line, 'UI_LTE_DETAIL')) !== null) {
			res.lteDetail = v;
			continue;
		}
		if ((v = _uiMarkerValue(line, 'UI_WWAN_IFACE')) !== null) {
			res.hasWwanIface = (v === 'yes');
			if (res.hasWwanIface) res.detected = true;
			continue;
		}
		if ((v = _uiMarkerValue(line, 'UI_WWAN_DETAIL')) !== null) {
			res.wwanDetail = v;
			continue;
		}
		if ((v = _uiMarkerValue(line, 'UI_CDC_ETHER')) !== null) {
			res.cdcEtherInstalled = (v === 'yes');
			continue;
		}
		if ((v = _uiMarkerValue(line, 'UI_USB_MODESWITCH')) !== null) {
			res.usbModeswitchInstalled = (v === 'yes');
			continue;
		}

		if (line.indexOf('Режим (эвристика):') !== -1) {
			res.heuristicMode = line.substring(line.indexOf(':') + 1).trim();
		} else if (line.indexOf('Уверенность:') !== -1) {
			res.confidence = line.substring(line.indexOf(':') + 1).trim();
		} else if (line.indexOf('Рекомендуемый набор:') !== -1) {
			res.recommendation = line.substring(line.indexOf(':') + 1).trim();
		}

		if (line.indexOf('/dev/cdc-wdm') !== -1 && line.indexOf('нет') === -1) {
			res.hasCdcWdm = true;
			res.detected = true;
		}
		if (line.indexOf('/dev/ttyUSB') !== -1 && line.indexOf('нет') === -1) {
			res.hasTtyUsb = true;
			res.detected = true;
		}
	}

	if (res.hasCdcWdm || res.hasTtyUsb || res.hasLteIface || res.hasWwanIface) {
		res.detected = true;
	}

	return res;
}

function renderMetricRow(label, valueNode) {
	return E('div', { 'class': 'xfree-metric-row' }, [
		E('span', { 'class': 'xfree-metric-label' }, [ label ]),
		E('div', { 'class': 'xfree-metric-value' }, [ valueNode ])
	]);
}

function renderModemStatusCard(info, view, onRefresh) {
	var isDet = info.detected;
	var badgeTone = isDet ? 'ok' : 'neutral';
	var badgeText = isDet ? _('Модем подключен') : _('Не обнаружен');

	var rows = [];

	rows.push(renderMetricRow(_('Статус устройства'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		xcmp.badge({
			text: isDet ? _('Обнаружен на USB') : _('Модем не найден'),
			tone: isDet ? 'ok' : 'neutral'
		})
	])));

	rows.push(renderMetricRow(_('Режим работы (эвристика)'), E('span', { 'class': 'font-mono' }, [
		info.heuristicMode || (isDet ? _('Определяется...') : _('не определён'))
	])));

	var wanLabel = _('не настроен');
	if (info.hasLteIface) {
		wanLabel = info.lteDetail ? ('lte: ' + info.lteDetail) : 'lte (настроен)';
	} else if (info.hasWwanIface) {
		wanLabel = info.wwanDetail ? ('wwan: ' + info.wwanDetail) : 'wwan (настроен)';
	}
	if (info.probeIface && info.probeIface !== '?') {
		wanLabel = wanLabel + ' · probe=' + info.probeIface;
	}
	rows.push(renderMetricRow(_('Сетевой интерфейс WAN'), E('span', {
		'class': 'xfree-status-pill ' + (info.hasLteIface || info.hasWwanIface ? 'online' : 'offline')
	}, [ wanLabel ])));

	var devNodes = [];
	if (info.hasCdcWdm) devNodes.push('/dev/cdc-wdm*');
	if (info.hasTtyUsb) devNodes.push('/dev/ttyUSB*');
	if (devNodes.length === 0) devNodes.push(_('нет символьных устройств'));

	rows.push(renderMetricRow(_('Системные узлы (/dev)'), E('span', { 'class': 'font-mono muted', 'style': 'font-size: 11px;' }, [
		devNodes.join(', ')
	])));

	var createLteBtn = xcmp.button({
		text: _('⚡ Создать интерфейс LTE'),
		tone: 'primary',
		title: _('Создать WAN-интерфейс lte в конфигурации сети и firewall'),
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('modemLteIface').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Интерфейс LTE успешно создан и привязан к зоне WAN') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка создания интерфейса: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var cycleBtn = xcmp.button({
		text: _('🔄 Перезагрузить USB'),
		tone: 'secondary',
		title: _('Сброс питания USB-порта при зависании модема'),
		onClick: function(ev) {
			if (!confirm(_('Отключить питание USB на 8 секунд и подать снова для перезапуска модема?'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('usbPowerCycle').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Сброс питания USB выполнен') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка перезагрузки USB: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [ createLteBtn, cycleBtn ]);

	return xcmp.card({
		title: _('4G / LTE USB-модем'),
		subtitle: _('Статус подключения, эвристика протокола и привязка к интерфейсам WAN'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderModemPackagesCard(info, view, onRefresh) {
	var rows = [];

	rows.push(renderMetricRow(_('Рекомендация ядра'), E('span', {}, [
		info.recommendation || _('HiLink E3372 или QMI')
	])));

	rows.push(renderMetricRow(_('Драйвер HiLink (cdc-ether)'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		xcmp.badge({
			text: info.cdcEtherInstalled ? _('Установлен') : _('Не установлен'),
			tone: info.cdcEtherInstalled ? 'ok' : 'neutral'
		})
	])));

	rows.push(renderMetricRow(_('Переключатель modeswitch'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		xcmp.badge({
			text: info.usbModeswitchInstalled ? _('Установлен') : _('Не установлен'),
			tone: info.usbModeswitchInstalled ? 'ok' : 'neutral'
		})
	])));

	var hilinkBtn = xcmp.button({
		text: _('📦 Пакеты HiLink (E3372)'),
		tone: 'primary',
		title: _('Установка kmod-usb-net-cdc-ether и usb-modeswitch'),
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('modemHilink').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Пакеты HiLink успешно установлены') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка установки пакетов: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var recBtn = xcmp.button({
		text: _('⚡ Установить полный набор (QMI+HiLink)'),
		tone: 'secondary',
		title: _('Полный набор драйверов модемов: QMI, MBIM, CDC-Ether, modeswitch'),
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('modemRecommended').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Рекомендуемый набор пакетов модема установлен') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка установки: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [ hilinkBtn, recBtn ]);

	return xcmp.card({
		title: _('Драйверы и режимы работы'),
		subtitle: _('Поддержка модемов в режиме роутера (HiLink) и прямого управления (QMI/MBIM)'),
		badge: xcmp.badge({ text: _('Драйверы USB'), tone: 'info' }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

return baseclass.extend({
	parseReport: parseModemReport,

	/**
	 * Главный рендер панели «4G / LTE Модем»
	 * @param {Object} opts — { data, view, onRefresh }
	 * @returns {Node}
	 */
	render: function (opts) {
		opts = opts || {};
		var data = opts.data || {};
		var view = opts.view || {};
		var onRefresh = opts.onRefresh;

		var rawText = '';
		if (data.execResult) {
			rawText = data.execResult.stdout || data.execResult.stderr || '';
		}

		var info = parseModemReport(rawText);

		var panelView = {
			runSystemAction: function (action, arg, payload) {
				var x = (typeof xui !== 'undefined') ? xui : null;
				if (x && typeof x.runSystemMenuWithOutput === 'function') {
					return x.runSystemMenuWithOutput(action, arg, payload);
				}
				if (view && typeof view.runSystemMenu === 'function') {
					return view.runSystemMenu(action, arg, payload);
				}
				if (x && typeof x.runSystemMenu === 'function') {
					return x.runSystemMenu(action, arg, payload);
				}
				return Promise.reject(new Error('runSystemMenu is not available'));
			}
		};

		var cards = [
			renderModemStatusCard(info, panelView, onRefresh),
			renderModemPackagesCard(info, panelView, onRefresh)
		];

		var refreshBtn = xcmp.refreshButton({
			isRefreshing: false,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(refreshBtn, res);
					}
				}
			}
		});

		var actionBar = xcmp.actionBar({
			title: _('4G / LTE Модем'),
			description: _('Диагностика USB-модемов, установка драйверов HiLink/QMI и настройка резервного WAN'),
			actions: [ refreshBtn ]
		});

		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод modemDiag)'),
			rawText: rawText,
			maxHeight: '250px'
		});

		return E('div', { 'class': 'xfree-dashboard-wrap' }, [
			actionBar,
			E('div', {
				'class': 'xfree-card-grid',
				'style': 'display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 16px;'
			}, cards),
			spoiler
		]);
	}
});
