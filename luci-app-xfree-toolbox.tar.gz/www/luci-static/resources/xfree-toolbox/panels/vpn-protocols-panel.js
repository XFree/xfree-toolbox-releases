'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.components as xcmp';

var TAG = 'xfree-vpn-protocols';

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._protocolsStatus = (spec && spec.protocolsStatus) || {};
		this._loading = !!(spec && spec.loading);
		this._busy = !!(spec && spec.busy);
		this._protocolsLoaded = !!(spec && spec.protocolsStatus && Object.keys(spec.protocolsStatus).length > 0 && spec.protocolsStatus.awg);
		this.setAttribute('data-xfree-vpn-protocols', '1');
		this.requestPaint();
	}

	setLoading(loading) {
		this._loading = !!loading;
		this.requestPaint();
	}

	setBusy(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button').forEach(function (el) {
			el.disabled = !!busy;
		});
	}

	setProtocolsStatus(status) {
		this._protocolsStatus = status || {};
		this._protocolsLoaded = true;
		this._loading = false;
		this.requestPaint();
	}

	_act(action, arg, confirmText) {
		if (this._spec && typeof this._spec.onAction === 'function') {
			return this._spec.onAction(action, arg, confirmText);
		}
	}

	render() {
		var self = this;
		var ps = this._protocolsStatus || {};
		var isLoading = !!(this._loading || !this._protocolsLoaded);
		var isBusy = !!this._busy;

		this.className = 'xfree-vpn-protocols-root';

		// 1. Верхние чипы статуса (Summary Chips)
		var isInstalled = function (lbl) { return lbl && lbl !== 'Не установлен'; };
		var chips = [
			xcmp.chip({
				label: 'AmneziaWG',
				value: ps.awg || _('Не установлен'),
				tone: isInstalled(ps.awg) ? 'ok' : 'muted',
				loading: isLoading
			}),
			xcmp.chip({
				label: 'OpenVPN',
				value: ps.openvpn || _('Не установлен'),
				tone: isInstalled(ps.openvpn) ? 'ok' : 'muted',
				loading: isLoading
			}),
			xcmp.chip({
				label: 'Sing-box',
				value: ps.vless || _('Не установлен'),
				tone: isInstalled(ps.vless) ? 'ok' : 'muted',
				loading: isLoading
			}),
			xcmp.chip({
				label: 'FreeTurn Client',
				value: ps.freeturn || _('Не установлен'),
				tone: isInstalled(ps.freeturn) ? 'ok' : 'muted',
				loading: isLoading
			})
		];

		// 2. Описание протоколов
		var protocols = [
			{
				id: 'awg',
				title: 'AmneziaWG (AWG)',
				subtitle: ps.awg && ps.awg.indexOf('2.0') !== -1 ? 'AmneziaWG 2.0+ (Modern Obfuscation)' : 'AmneziaWG Kernel Module',
				descr: _('Модифицированный WireGuard с обфускацией заголовков и защитой от DPI (Jc/Jmin/Jmax/S1/S2/H1..H4).'),
				status: ps.awg || _('Не установлен'),
				updateAvailable: !!ps.awgUpdateAvailable,
				rawVersion: ps.awgRawVersion || '',
				canRemove: true,
				installTitle: _('Установить AWG'),
				confirmInstall: _('Установить модули ядра и пакеты AmneziaWG (kmod-amneziawg, amneziawg-tools)?'),
				confirmRemove: _('Удалить AmneziaWG из системы?')
			},
			{
				id: 'openvpn',
				title: 'OpenVPN',
				subtitle: 'OpenVPN SSL/TLS Tunnel',
				descr: _('Классический клиент OpenVPN с поддержкой шифрования SSL/TLS и туннелей TUN/TAP.'),
				status: ps.openvpn || _('Не установлен'),
				canRemove: true,
				installTitle: _('Установить OpenVPN'),
				confirmInstall: _('Установить OpenVPN (openvpn-openssl и kmod-tun)?'),
				confirmRemove: _('Удалить OpenVPN из системы?')
			},
			{
				id: 'vless',
				title: 'Sing-box (VLESS)',
				subtitle: 'Next-Gen Universal Proxy Platform',
				descr: _('Универсальный прокси-клиент Sing-box для современных протоколов VLESS Reality, Trojan, ShadowSocks.'),
				status: ps.vless || _('Не установлен'),
				canRemove: true,
				installTitle: _('Установить Sing-box'),
				confirmInstall: _('Установить Sing-box и пакет корневых сертификатов ca-bundle?'),
				confirmRemove: _('Удалить Sing-box из системы?')
			},
			{
				id: 'freeturn',
				title: 'FreeTurn Client',
				subtitle: 'STUN/TURN Obfuscated Proxy Client',
				descr: _('Клиентский бинарник FreeTurn Proxy для обфусцированных туннелей через STUN/TURN серверы.'),
				status: ps.freeturn || _('Не установлен'),
				canRemove: true,
				installTitle: _('Установить FreeTurn'),
				confirmInstall: _('Скачать и установить FreeTurn Client с GitHub?'),
				confirmRemove: _('Удалить FreeTurn Client из системы?')
			}
		];

		// 3. Построение карточек компонентов через xcmp.card()
		var cards = protocols.map(function (item) {
			var installed = isInstalled(item.status);
			var badgeTone = installed ? 'ok' : 'muted';
			var actions = [];

			if (isLoading) {
				return xcmp.card({
					title: item.title,
					subtitle: item.subtitle,
					badge: xcmp.badge({ text: xcmp.skeleton({ width: '70px', height: '14px' }), tone: 'muted' }),
					content: [
						E('p', { 'class': 'muted', 'style': 'margin: 0 0 14px 0; font-size: 13px; line-height: 1.4;' }, [item.descr]),
						xcmp.button({ text: _('Загрузка...'), tone: 'ghost-compact', disabled: true, loading: true })
					]
				});
			}

			// Кнопка установки / переустановки
			var installLabel = !installed
				? item.installTitle
				: (item.id === 'awg' && item.updateAvailable ? ('⚡ ' + _('Обновить до 2.0+')) : _('Переустановить'));

			var installTone = !installed || (item.id === 'awg' && item.updateAvailable) ? 'primary' : 'ghost-compact';

			actions.push(xcmp.button({
				text: installLabel,
				tone: installTone,
				disabled: isBusy,
				onClick: function () {
					self._act('protocolsInstall', item.id, item.confirmInstall);
				}
			}));

			// Кнопка удаления (если установлен)
			if (item.canRemove && installed) {
				actions.push(xcmp.button({
					text: _('Удалить'),
					tone: 'danger',
					size: 'sm',
					disabled: isBusy,
					onClick: function () {
						self._act('protocolsRemove', item.id, item.confirmRemove);
					}
				}));
			}

			// Блок специальных уведомлений (например, AWG 2.0)
			var noticeEl = null;
			if (item.id === 'awg' && installed) {
				if (item.updateAvailable) {
					noticeEl = E('div', {
						'style': 'margin: 0 0 12px 0; padding: 8px 12px; background: rgba(245, 158, 11, 0.12); border: 1px solid rgba(245, 158, 11, 0.35); border-radius: 6px; font-size: 12px; line-height: 1.4; color: #b45309;'
					}, [
						E('strong', {}, ['⚡ ' + _('Доступно обновление: ')]),
						E('span', {}, [_('В системе AWG 1.0. Доступна версия AWG 2.0+ с поддержкой новых параметров обфускации.')])
					]);
				} else if (item.status && (item.status.indexOf('2.0') !== -1 || item.status.indexOf('3.1') !== -1)) {
					var rawVerText = item.rawVersion ? (' (' + item.rawVersion + ')') : '';
					noticeEl = E('div', {
						'style': 'margin: 0 0 12px 0; padding: 8px 12px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 6px; font-size: 12px; line-height: 1.4; color: #047857;'
					}, [
						E('strong', {}, ['✓ ' + _('Актуальная версия: ')]),
						E('span', {}, [_('Установлена сборка AmneziaWG 2.0+ с расширенными параметрами.') + rawVerText])
					]);
				}
			}

			var bodyItems = [
				E('p', { 'class': 'muted', 'style': 'margin: 0 0 14px 0; font-size: 13px; line-height: 1.4;' }, [item.descr])
			];
			if (noticeEl) bodyItems.push(noticeEl);
			bodyItems.push(E('div', { 'style': 'display: flex; gap: 8px; align-items: center;' }, actions));

			return xcmp.card({
				title: item.title,
				subtitle: item.subtitle,
				badge: xcmp.badge({ text: item.status, tone: badgeTone }),
				tone: installed ? 'ok' : 'muted',
				content: bodyItems
			});
		});

		// 4. Компоновка всего экрана
		this.replaceChildren(
			E('div', { 'class': 'xfree-uplink-chips', 'style': 'display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap;' }, chips),
			E('section', { 'class': 'xfree-vpn-section' }, [
				E('h4', { 'style': 'margin-bottom: 12px;' }, [_('Системные пакеты и протоколы')]),
				E('div', {
					'class': 'xfree-vpn-gens',
					'style': 'display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 14px;'
				}, cards)
			])
		);
	}
});

return baseclass.extend({
	tag: TAG
});

