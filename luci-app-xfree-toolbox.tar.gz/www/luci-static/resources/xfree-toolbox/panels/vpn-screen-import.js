'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.panels.vpn-catalog as catalog';

var sanitizeIfaceName = catalog.sanitizeIfaceName;
var unpackAmneziaVpnKey = catalog.unpackAmneziaVpnKey;
var extractAmneziaConfig = catalog.extractAmneziaConfig;

return baseclass.extend({
	_renderImportCard: function (view, inModal) {
		var self = this;
		var s = this._spec || {};
		var allConfs = (this._summary && this._summary.confs) || [];
		var customConfs = allConfs.filter(function (c) {
			return c.kind === 'custom' || c.kind === 'amnezia' || c.kind === 'openvpn' || c.kind === 'vless';
		});
		var latestCustom = customConfs[0] || null;

		var fileInput = E('input', {
			'type': 'file',
			'accept': '.conf,.ovpn,.json,.txt',
			'style': 'display: none;'
		});

		var statusNote = E('div', {
			'class': 'xfree-vpn-import-note',
			'style': 'display: none; margin-top: 8px; font-size: 13px; padding: 8px 12px; border-radius: 6px; line-height: 1.4;'
		});

		var ta = E('textarea', {
			'class': 'xfree-uplink-input',
			'rows': 5,
			'placeholder': _('Вставьте текст .conf, .ovpn или ссылку vpn://...'),
			'style': 'width: 100%; font-family: monospace; font-size: 12px; resize: vertical;'
		});

		var nameInput = E('input', {
			'class': 'xfree-uplink-input',
			'type': 'text',
			'placeholder': _('например, amnezia_nl'),
			'style': 'width: 100%;'
		});

		var protoSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%;'
		}, [
			E('option', { 'value': 'auto' }, [_('Автоопределение')]),
			E('option', { 'value': 'awg' }, [_('AmneziaWG / WireGuard (.conf)')]),
			E('option', { 'value': 'openvpn' }, [_('OpenVPN (.ovpn)')]),
			E('option', { 'value': 'vless' }, [_('VLESS Reality / sing-box (.json / vless://)')])
		]);

		function updateStatus(text, tone) {
			if (!text) {
				statusNote.style.display = 'none';
				statusNote.textContent = '';
				return;
			}
			statusNote.style.display = 'block';
			statusNote.textContent = text;
			if (tone === 'ok') {
				statusNote.style.background = 'rgba(34, 197, 94, 0.1)';
				statusNote.style.border = '1px solid rgba(34, 197, 94, 0.3)';
				statusNote.style.color = '#22c55e';
			} else if (tone === 'warn') {
				statusNote.style.background = 'rgba(234, 179, 8, 0.1)';
				statusNote.style.border = '1px solid rgba(234, 179, 8, 0.3)';
				statusNote.style.color = '#eab308';
			} else {
				statusNote.style.background = 'rgba(59, 130, 246, 0.1)';
				statusNote.style.border = '1px solid rgba(59, 130, 246, 0.25)';
				statusNote.style.color = 'inherit';
			}
		}

		function processText(text) {
			var val = String(text || '').trim();
			if (!val) {
				updateStatus('', '');
				return;
			}
			if (val.indexOf('vpn://') === 0) {
				updateStatus(_('Распаковка ссылки Amnezia vpn://...'), 'info');
				unpackAmneziaVpnKey(val).then(function (jsonObj) {
					var ext = extractAmneziaConfig(jsonObj);
					if (ext && ext.isStatic && ext.confText) {
						ta.value = ext.confText;
						protoSelect.value = (ext.type === 'openvpn') ? 'openvpn' : 'awg';
						if (!nameInput.value.trim() && ext.name) {
							nameInput.value = sanitizeIfaceName(ext.name);
						}
						updateStatus(_('✓ Распакована конфигурация Amnezia: ') + (ext.name || ext.type), 'ok');
					} else if (ext && ext.isSubscription) {
						updateStatus(_('ℹ Обнаружен ключ подписки Amnezia Premium (%s, %s). Скачайте .conf в личном кабинете или приложении Amnezia и вставьте сюда.').format(ext.name, ext.country.toUpperCase()), 'warn');
					} else {
						updateStatus(_('✓ JSON Amnezia распакован, но не содержит last_config'), 'warn');
					}
				}).catch(function (err) {
					updateStatus(_('Ошибка распаковки vpn://: ') + (err && err.message ? err.message : String(err)), 'warn');
				});
			} else if (val.indexOf('[Interface]') >= 0) {
				if (protoSelect.value === 'auto')
					protoSelect.value = 'awg';
				if (val.indexOf('vpn://') >= 0 || val.indexOf('Keenetic:') >= 0 || val.indexOf('HeaderProtectionKey') >= 0 || /\b\w+\s*=\s*\d+\s*-\s*\d+/.test(val)) {
					updateStatus(_('✓ Распознан AmneziaWG / Keenetic (диапазоны значений будут автоматически нормализованы)'), 'ok');
				} else {
					updateStatus(_('✓ Распознан формат WireGuard / AmneziaWG (.conf)'), 'ok');
				}
			} else if (val.indexOf('dev tun') >= 0 || val.indexOf('client') >= 0) {
				if (protoSelect.value === 'auto')
					protoSelect.value = 'openvpn';
				updateStatus(_('✓ Распознан формат OpenVPN (.ovpn)'), 'ok');
			} else if (val.indexOf('vless://') === 0 || (val.indexOf('{') === 0 && val.indexOf('outbounds') >= 0)) {
				if (protoSelect.value === 'auto')
					protoSelect.value = 'vless';
				updateStatus(_('✓ Распознан формат VLESS Reality / sing-box (требуется sing-box, проверка места >35 МБ)'), 'ok');
			}
		}

		ta.addEventListener('input', function () {
			processText(ta.value);
		});

		fileInput.addEventListener('change', function (ev) {
			var file = ev.target.files && ev.target.files[0];
			if (!file) return;
			var fname = file.name || '';
			if (!nameInput.value.trim()) {
				var base = fname.replace(/\.(conf|ovpn|txt)$/i, '');
				nameInput.value = sanitizeIfaceName(base);
			}
			var reader = new FileReader();
			reader.onload = function (e) {
				ta.value = e.target.result || '';
				processText(ta.value);
			};
			reader.readAsText(file);
		});

		function doSave(shouldCreate) {
			var body = String(ta.value || '').trim();
			if (!body) {
				self.setMessage(_('Введите текст конфигурации или выберите файл'), 'warn');
				return;
			}
			var proto = protoSelect.value;
			if (proto === 'auto') {
				if (body.indexOf('dev tun') >= 0 || body.indexOf('client') >= 0)
					proto = 'openvpn';
				else if (body.indexOf('vless://') === 0 || (body.indexOf('{') === 0 && body.indexOf('outbounds') >= 0))
					proto = 'vless';
				else
					proto = 'awg';
			}
			var isOvpn = (proto === 'openvpn');
			var isVless = (proto === 'vless');
			var ext = isOvpn ? '.ovpn' : (isVless ? '.json' : '.conf');
			var rawName = String(nameInput.value || '').trim();
			if (!rawName)
				rawName = isOvpn ? 'ovpn_1' : (isVless ? 'vless_1' : 'vpn_1');
			var sanitized = sanitizeIfaceName(rawName);
			var filename = sanitized.indexOf(ext) >= 0 ? sanitized : (sanitized + ext);
			var ifaceName = sanitized.replace(/\.(conf|ovpn|json|txt)$/i, '');

			var b64;
			try {
				b64 = btoa(unescape(encodeURIComponent(body)));
			} catch {
				self.setMessage(_('Ошибка кодирования текста в base64'), 'bad');
				return;
			}

			var kind = isOvpn ? 'openvpn' : (isVless ? 'vless' : 'custom');
			var arg = kind + '|' + filename + '|b64:' + b64;
			if (shouldCreate) {
				arg += '|create:' + ifaceName;
			}

			if (inModal && typeof ui.hideModal === 'function') {
				ui.hideModal();
			}

			if (s.onAction) {
				var confirmMsg = shouldCreate
					? _('Сохранить %s, создать и применить туннель «%s»?').format(filename, ifaceName)
					: _('Сохранить файл %s в профиль?').format(filename);
				s.onAction('confSave', arg, confirmMsg);
			}
		}

		var cardChildren = [];

		if (!inModal) {
			cardChildren.push(
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap;' }, [
						E('strong', {}, [_('Импорт конфигурации')]),
						E('span', { 'class': 'muted' }, [_('Amnezia / WireGuard / OpenVPN / VLESS')])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						latestCustom
							? E('span', { 'class': 'xfree-vpn-status is-ok', 'title': latestCustom.created || '' }, ['📄 ' + latestCustom.file])
							: E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('готов к загрузке')])
					])
				])
			);
		}

		cardChildren.push(
			E('div', { 'class': 'xfree-vpn-fields-wrap', 'style': inModal ? 'padding: 4px 0;' : 'padding: 14px;' }, [
				E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;' }, [
					E('span', { 'style': 'font-weight: 500; font-size: 13px;' }, [_('Текст конфига или ссылка vpn://')]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function (ev) {
							ev.preventDefault();
							fileInput.click();
						}
					}, [_('📂 Выбрать файл с диска')]),
					fileInput
				]),
				ta,
				statusNote,
				E('div', { 'class': 'xfree-vpn-fields', 'style': 'margin-top: 12px;' }, [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('label', {}, [_('Имя туннеля / конфига')]),
						nameInput
					]),
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('label', {}, [_('Протокол')]),
						protoSelect
					])
				])
			])
		);

		cardChildren.push(
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': inModal ? 'margin-top: 14px;' : '' }, [
				E('button', {
					'class': 'btn cbi-button-positive',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						doSave(true);
					})
				}, [_('Сохранить и применить туннель')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						doSave(false);
					})
				}, [_('Сохранить файл')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						self._openConfManager('');
					}
				}, [_('Менеджер .conf…')])
			])
		);

		return E('div', {
			'class': inModal ? 'xfree-vpn-import-card is-modal-body' : 'xfree-vpn-gen xfree-vpn-import-card',
			'style': inModal ? 'border: none; background: transparent; padding: 0;' : 'border-left: 3px solid #3b82f6;'
		}, cardChildren);
	},
});
