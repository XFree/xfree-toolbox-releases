'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.panels.vpn-screen as vpnScreen';

var badge = vpnScreen.badge;
var healthTone = vpnScreen.healthTone;
var healthLabel = vpnScreen.healthLabel;
var countryName = vpnScreen.countryName;
var coloCountry = vpnScreen.coloCountry;
var coloLabel = vpnScreen.coloLabel;

var TAG = 'xfree-vpn-card';

function buildTunnelCard(ctx) {
	var row = ctx.row || {};
	var ifaces = ctx.ifaces || [];
	var sub = ctx.sub || [];
	var viaMap = ctx.viaMap || {};
	var view = ctx.view;
	var s = ctx.spec || {};
	var self = ctx.screen;
	var tone = healthTone(row.health);
	var status = [];
	var meta = [];
	var actions = [];
	var kindLc = String(row.kind || '').toLowerCase();
	var cityOk = row.city && (kindLc === 'proton' || !/^(cf-|[0-9])/i.test(row.city));
	var countryShow = countryName(row.country || coloCountry(row.colo));
	var coloShow = coloLabel(row.colo);
	var peers = viaMap[row.name];

	status.push({ text: healthLabel(row.health), tone: tone });
	status.push({ text: row.ifaceUp ? 'UP' : 'DOWN', tone: row.ifaceUp ? 'ok' : 'bad' });
	if (!row.ifaceUp) {
		var hasActiveSameKind = false;
		var oi;

		for (oi = 0; oi < ifaces.length; oi++) {
			if (ifaces[oi].name !== row.name && ifaces[oi].ifaceUp) {
				var okind = String(ifaces[oi].kind || '').toLowerCase();
				if ((kindLc === 'proton' && (okind === 'proton' || ifaces[oi].name.indexOf('proton') === 0)) ||
					(kindLc === 'warp' && (okind === 'warp' || ifaces[oi].name.indexOf('warp') === 0))) {
					hasActiveSameKind = true;
					break;
				}
			}
		}
		if (hasActiveSameKind) {
			status.push({
				text: _('standby'),
				tone: 'muted',
				title: _('Режим ожидания: активен другой туннель этого сервиса')
			});
		}
	}
	if (row.rtOk)
		status.push({ text: 'rt', tone: 'ok' });
	else if (row.lists === 0)
		status.push({ text: _('empty') });
	else if (row.state)
		status.push({ text: _('apply?'), tone: 'warn' });

	if (countryShow)
		meta.push({ label: _('страна'), value: countryShow });
	if (cityOk)
		meta.push({ label: _('город'), value: row.city });
	if (coloShow)
		meta.push({ label: _('колония'), value: coloShow });
	else if (kindLc === 'warp')
		meta.push({ label: _('колония'), value: _('нет в meta'), muted: true });
	if (row.probe)
		meta.push({ label: 'probe', value: row.probe });
	if (row.proton)
		meta.push({ label: 'proton', value: row.proton + (row.sess ? ' · ' + row.sess : '') });
	if (row.cert)
		meta.push({ label: 'cert', value: row.cert });
	if (row.dev && row.dev !== row.name)
		meta.push({ label: 'dev', value: row.dev });
	if (row.selfRouteVia) {
		meta.push({
			label: _('через'),
			value: row.selfRouteVia,
			rowClass: 'xfree-vpn-kv xfree-vpn-kv-route is-target',
			chip: 'route'
		});
	}
	if (peers && peers.length) {
		meta.push({
			label: _('шлюз для'),
			value: peers.join(', '),
			rowClass: 'xfree-vpn-kv xfree-vpn-kv-route is-gateway',
			chip: 'gateway'
		});
	}

	var isSynced = Boolean(row.work && row.state && row.gen && row.source);

	if (!isSynced) {
		actions.push({
			text: '⚡ ' + _('Применить'),
			className: 'btn is-primary ghost-compact',
			title: _('Конфигурация туннеля не синхронизирована с runtime'),
			onClick: ui.createHandlerFn(view, function (ev) {
				self._act(ev, 'applyOne', row.name, _('Применить туннель «%s»?').format(row.name));
			})
		});
	}
	actions.push({
		text: _('Списки'),
		className: 'ghost ghost-compact',
		title: row.lists
			? _('Списки маршрутов для «%s» (%d активных). Нажмите для перехода в «Маршруты»').format(row.name, row.lists)
			: _('Списки маршрутов для «%s». Нажмите для перехода в «Маршруты»').format(row.name),
		onClick: function (ev) {
			if (ev) {
				ev.preventDefault();
				ev.stopPropagation();
			}
			if (s.onNavigate)
				s.onNavigate('routing', 'vpn', row.name);
			else if (view && view.navigate)
				view.navigate('routing', 'vpn', row.name);
		}
	});
	actions.push({
		text: _('Обновить'),
		className: 'ghost ghost-compact',
		onClick: ui.createHandlerFn(view, function (ev) {
			self._updateIface(ev, row.name, row.kind || '');
		})
	});
	actions.push({
		text: _('Пересобрать'),
		className: 'ghost ghost-compact',
		onClick: function (ev) {
			if (ev) {
				ev.preventDefault();
				ev.stopPropagation();
			}
			try {
				self._openRebuildDialog(row.name, row.kind || '');
			} catch (err) {
				self.setBusy(false);
				self.setMessage((err && err.message) ? err.message : String(err), 'bad');
			}
		}
	});
	actions.push({
		text: _('Файлы'),
		className: 'ghost ghost-compact',
		onClick: ui.createHandlerFn(view, function (ev) {
			self._act(ev, 'show', row.name);
		})
	});
	if (kindLc === 'openvpn') {
		actions.push({
			text: _('Пароль'),
			className: 'ghost ghost-compact',
			title: _('Сменить логин и пароль OpenVPN'),
			onClick: function (ev) {
				if (ev) {
					ev.preventDefault();
					ev.stopPropagation();
				}
				try {
					self._openOpenvpnAuthDialog(row.name);
				} catch (err) {
					self.setBusy(false);
					self.setMessage((err && err.message) ? err.message : String(err), 'bad');
				}
			}
		});
	}
	actions.push({
		text: _('Удалить'),
		className: 'ghost ghost-compact',
		onClick: ui.createHandlerFn(view, function (ev) {
			self._deleteIface(ev, row.name);
		})
	});

	return xcmp.card({
		variant: 'vpn-tunnel',
		title: row.name,
		tone: tone,
		subtitle: sub.length ? sub.join(' · ') : '',
		status: status,
		meta: meta,
		emptyMeta: _('Нет данных probe — проверьте монитор'),
		badges: [
			badge('work', row.work),
			badge('state', row.state),
			badge('gen', row.gen),
			badge('src', row.source)
		],
		actions: actions
	});
}

wc.define(TAG, class extends wc.LightElement {
	mount(ctx) {
		this._ctx = ctx || {};
		/* Сетка .xfree-vpn-tunnels считает дочерним сам .xfree-vpn-tunnel. */
		this.style.display = 'contents';
		this.requestPaint();
	}

	render() {
		var node = buildTunnelCard(this._ctx || {});

		if (node)
			this.replaceChildren(node);
	}
});

return baseclass.extend({
	tag: TAG,
	buildTunnelCard: buildTunnelCard
});
