'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.panels.vpn-catalog as catalog';
'require xfree-toolbox.panels.vpn-generator-fields as genFields';

var textField = catalog.textField;
var secretField = catalog.secretField;

return baseclass.extend({
	_parseMetaText: function (text) {
		var out = {};
		var lines = String(text || '').split(/\n/);
		var i;
		var line;
		var m;

		for (i = 0; i < lines.length; i++) {
			line = lines[i].replace(/\r$/, '').trim();
			m = line.match(/^META_([A-Z0-9_]+)=(.*)$/);
			if (m)
				out[m[1]] = m[2];
			else if (line.indexOf('IFACE=') === 0)
				out.IFACE = line.slice(6);
		}
		return out;
	},

	_showOpenvpnAuthForm: function (ifaceName, meta) {
		var self = this;
		var s = this._spec || {};
		var user = (meta && meta.AUTH_USER) || '';
		var hint = _('Новый пароль записывается в профиль туннеля, затем туннель применяется и OpenVPN перезапускается. Текущий пароль не показывается.');

		if (meta && meta.HAS_TOTP === '1')
			hint += ' ' + _('Секрет одноразового кода не меняется.');

		var body = E('div', { 'class': 'xfree-vpn-fields xfree-vpn-modal-fields' }, [
			E('div', { 'class': 'xfree-vpn-field' }, [
				E('div', { 'class': 'xfree-vpn-field-label' }, [_('Интерфейс')]),
				E('div', {}, [ifaceName])
			]),
			textField('ovpn_user', _('Логин'), user, _('логин OpenVPN')),
			secretField('ovpn_pass', _('Новый пароль'), _('новый пароль'))
		]);

		this._showVpnDialog(_('Пароль «%s»').format(ifaceName), [
			E('p', { 'class': 'muted' }, [hint]),
			body,
			E('div', { 'class': 'right xfree-vpn-dialog-actions' }, [
				E('button', {
					'type': 'button',
					'class': 'btn',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						ui.hideModal();
					}
				}, [_('Отмена')]),
				' ',
				E('button', {
					'type': 'button',
					'class': 'btn cbi-button-positive',
					'click': function (ev) {
						var userEl = body.querySelector('[data-xfree-vpn-field="ovpn_user"]');
						var passEl = body.querySelector('[data-xfree-vpn-field="ovpn_pass"]');
						var login = userEl ? String(userEl.value || '').trim() : '';
						var pass = passEl ? String(passEl.value || '') : '';
						var arg;

						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						if (!login) {
							self.setMessage(_('Укажите логин'), 'bad');
							return;
						}
						if (!pass) {
							self.setMessage(_('Укажите новый пароль'), 'bad');
							return;
						}
						try {
							arg = ifaceName
								+ '|b64:' + btoa(unescape(encodeURIComponent(login)))
								+ '|b64:' + btoa(unescape(encodeURIComponent(pass)));
						} catch {
							self.setMessage(_('Не удалось закодировать пароль'), 'bad');
							return;
						}
						ui.hideModal();
						if (s.onAction)
							s.onAction('setOpenvpnAuth', arg);
					}
				}, [_('Сохранить и применить')])
			])
		]);
	},

	_openOpenvpnAuthDialog: function (ifaceName) {
		var self = this;
		var s = this._spec || {};

		if (!s.onAction) {
			this.setMessage(_('Нет обработчика действия'), 'bad');
			return;
		}

		this.setBusy(true);
		s.onAction('ifaceMeta', ifaceName, null, function (res, text) {
			var meta = {};

			self.setBusy(false);
			if (res && !(res.code && res.code !== 0))
				meta = self._parseMetaText(text || '');
			self._showOpenvpnAuthForm(ifaceName, meta);
		});
	},

	_openRebuildDialog: function (ifaceName, preferKind) {
		var self = this;
		var s = this._spec || {};

		if (!s.onAction) {
			this.setMessage(_('Нет обработчика действия'), 'bad');
			return;
		}

		this.setBusy(true);
		s.onAction('ifaceMeta', ifaceName, null, function (res, text) {
			var meta;
			var kind;
			var fields = [];
			var body;
			var profile;
			var sessionMode;

			self.setBusy(false);
			if (!res || (res.code && res.code !== 0)) {
				self.setMessage(_('Не удалось прочитать meta «%s»').format(ifaceName), 'bad');
				return;
			}
			meta = self._parseMetaText(text || '');
			kind = String(meta.GENERATOR_KIND || preferKind || '').toLowerCase();
			if (kind !== 'warp' && kind !== 'proton') {
				self.setMessage(_('Не удалось прочитать meta «%s»').format(ifaceName), 'bad');
				return;
			}

			if (kind === 'warp') {
				var varId = meta.VARIANT_ID || '1';
				profile = (varId === 'auto') ? '2.0:auto' : ('2.0:' + varId);
				fields = [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [_('Интерфейс')]),
						E('div', {}, [ifaceName])
					])
				].concat(genFields.buildWarpFields({
					prefix: 'rb_',
					values: {
						server: (meta.SERVER_ID && meta.SERVER_ID !== 'xfree') ? meta.SERVER_ID : 'def',
						selection: meta.SELECTION_MODE || 'best',
						excludeRu: meta.EXCLUDE_RU != null ? String(meta.EXCLUDE_RU) : '1',
						profile: profile,
						mode: meta.PROFILE_MODE || 'local',
						i1Mode: meta.I1_MODE || 'fixed',
						i1Domain: meta.I1_DOMAIN || '',
						i1_entropy: meta.AWG_I1_ENTROPY || 'off',
						awg_noise: meta.AWG_NOISE_ENABLED != null ? String(meta.AWG_NOISE_ENABLED) : '1'
					},
					includeName: false
				}));
			} else {
				var varId = meta.VARIANT_ID || '1';
				profile = (varId === 'auto') ? '2.0:auto' : ((meta.AWG_VERSION || '2.0') + ':' + varId);
				sessionMode = (meta.SESSION_AUTH_MODE === 'guest') ? 'guest' : 'permanent';
				var portVal = meta.ENDPOINT_PORT || (meta.ENDPOINT && meta.ENDPOINT.indexOf(':') !== -1 ? meta.ENDPOINT.split(':')[1] : 'auto');
				var srvInfo = meta.SERVER_NAME ? (meta.SERVER_NAME + (meta.ENDPOINT ? ' · ' + meta.ENDPOINT : '')) : (meta.ENDPOINT || '');
				fields = [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [_('Интерфейс')]),
						E('div', {}, [ifaceName])
					])
				].concat(genFields.buildProtonFields({
					prefix: 'rb_',
					values: {
						country: meta.COUNTRY_FILTER || meta.SERVER_COUNTRY || 'NL',
						session_mode: sessionMode,
						profile: profile,
						i1_entropy: meta.AWG_I1_ENTROPY || 'r32',
						awg_noise: meta.AWG_NOISE_ENABLED != null ? String(meta.AWG_NOISE_ENABLED) : '0',
						selection_mode: meta.SELECTION_MODE || 'best',
						mtu: meta.MTU || '1280',
						free_only: meta.FREE_ONLY != null ? String(meta.FREE_ONLY) : '1',
						require_ipv6: meta.REQUIRE_IPV6 != null ? String(meta.REQUIRE_IPV6) : '0',
						rounds: meta.PROBE_ROUNDS || '5',
						port: portVal,
						via: meta.PROBE_VIA || 'auto',
						handshake_probe: meta.HANDSHAKE_PROBE != null ? String(meta.HANDSHAKE_PROBE) : '1'
					},
					ifaces: self._summary && self._summary.ifaces,
					excludeIface: ifaceName,
					includeRounds: true,
					includeName: false
				}));
			}

			body = E('div', { 'class': 'xfree-vpn-fields xfree-vpn-modal-fields' }, fields);
			self._showVpnDialog(_('Пересобрать «%s»').format(ifaceName), [
				E('p', { 'class': 'muted' }, [
					srvInfo ?
						_('Параметры подтянуты из последнего подбора (%s). Страна, сессия и режим сохраняются, сервер выбирается заново.').format(srvInfo) :
						_('Параметры из source.conf.meta. После сохранения — новый подбор сервера и apply.')
				]),
				body,
				E('div', { 'class': 'right xfree-vpn-dialog-actions' }, [
					E('button', {
						'type': 'button',
						'class': 'btn',
						'click': function (ev) {
							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							ui.hideModal();
						}
					}, [_('Отмена')]),
					' ',
					E('button', {
						'type': 'button',
						'class': 'btn cbi-button-positive',
						'click': function (ev) {
							var f = self._collectFieldsIn(body, '');
							var arg;

							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							ui.hideModal();
							if (kind === 'warp') {
								arg = ifaceName + '|' + self._modalPipeArgs({
									server: f.rb_server,
									selection: f.rb_selection,
									exclude_ru: f.rb_exclude_ru,
									profile: f.rb_profile,
									mode: f.rb_mode,
									i1_mode: f.rb_i1_mode,
									i1_domain: f.rb_i1_domain,
									rounds: f.rb_rounds,
									i1_entropy: f.rb_i1_entropy,
									awg_noise: f.rb_awg_noise
								}, [
									'server', 'selection', 'exclude_ru', 'profile',
									'mode', 'i1_mode', 'i1_domain', 'rounds',
									'i1_entropy', 'awg_noise'
								], '');
							} else {
								arg = ifaceName + '|' + self._modalPipeArgs({
									country: f.rb_country,
									session_mode: f.rb_session_mode,
									profile: f.rb_profile,
									selection_mode: f.rb_selection_mode,
									mtu: f.rb_mtu,
									free_only: f.rb_free_only,
									require_ipv6: f.rb_require_ipv6,
									rounds: f.rb_rounds,
									port: f.rb_port,
									via: f.rb_via,
									handshake_probe: f.rb_handshake_probe,
									i1_entropy: f.rb_i1_entropy,
									awg_noise: f.rb_awg_noise
								}, [
									'country', 'session_mode', 'profile', 'selection_mode',
									'mtu', 'free_only', 'require_ipv6', 'rounds', 'port', 'via',
									'handshake_probe', 'i1_entropy', 'awg_noise'
								], '');
							}
							if (s.onAction)
								s.onAction('regenerateOpts', arg);
						}
					}, [_('Пересобрать и применить')])
				])
			]);
		});
	},
});
