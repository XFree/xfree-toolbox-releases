'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.loading as loading';

var xcmp = components;

/**
 * Парсер текстового отчета show-host-resources.sh
 * @param {string} text
 * @returns {Object}
 */
function parseResourcesReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		host: '',
		time: '',
		uptime: '',
		load: [],
		ram: null,
		thermals: [],
		disks: []
	};

	var i;
	var line;
	var m;

	for (i = 0; i < lines.length; i++) {
		line = lines[i].trim();
		if (!line || /^[=─\-_]{3,}$/.test(line))
			continue;

		m = line.match(/^Хост\s*:\s*(.+)$/i);
		if (m && !res.host) {
			res.host = m[1].trim();
			continue;
		}

		m = line.match(/^Время\s*:\s*(.+)$/i);
		if (m && !res.time) {
			res.time = m[1].trim();
			continue;
		}

		m = line.match(/\bup\s+(.+?),\s*(?:(\d+)\s+users?,\s*)?load average:\s*([\d.]+),\s*([\d.]+),\s*([\d.]+)/i);
		if (m) {
			res.uptime = m[1].trim();
			res.load = [parseFloat(m[3]), parseFloat(m[4]), parseFloat(m[5])];
			continue;
		}

		m = line.match(/\bload average:\s*([\d.]+),\s*([\d.]+),\s*([\d.]+)/i);
		if (m && !res.load.length) {
			res.load = [parseFloat(m[1]), parseFloat(m[2]), parseFloat(m[3])];
			continue;
		}

		/* RAM parsing: "RAM 42% [███...] занято 105.20 MiB · доступно 144.80 MiB · всего 250.00 MiB" */
		if (/^RAM\s+(\d+)%/i.test(line)) {
			var ramPct = parseInt(line.match(/^RAM\s+(\d+)%/i)[1], 10);
			var nextLine = (i + 1 < lines.length) ? lines[i + 1].trim() : '';
			var ramMatch = nextLine.match(/занято\s+([^·]+)\s*·\s*доступно\s+([^·]+)\s*·\s*всего\s+(.+)/i);
			if (ramMatch) {
				res.ram = {
					pct: ramPct,
					used: ramMatch[1].trim(),
					avail: ramMatch[2].trim(),
					total: ramMatch[3].trim()
				};
				i++;
				continue;
			}
		}

		/* Thermal sensors: "● 45.0 °C cpu-thermal норма" or "▲ 78.5 °C wifi-thermal тепло" */
		m = line.match(/^([●▲!?*]+|\?)\s*([\d.]+\s*°\s*C)\s+([^\s]+)\s+(норма|тепло|критич\S*|нет данных)/i);
		if (m) {
			var marker = m[1].trim();
			var deg = m[2].trim();
			var sensorName = m[3].trim();
			var levelText = m[4].trim();
			var tone = 'ok';
			if (/тепло/i.test(levelText) || marker === '▲') tone = 'warn';
			else if (/критич/i.test(levelText) || /!/.test(marker)) tone = 'err';
			else if (/нет данных/i.test(levelText) || marker === '?') tone = 'muted';

			res.thermals.push({
				name: sensorName,
				temp: deg,
				level: levelText,
				tone: tone
			});
			continue;
		}

		/* Disk rows: "/overlay 12% [██░...] занято 12.30 MiB · свободно 87.70 MiB · всего 100.00 MiB" */
		m = line.match(/^(\/[^\s]*)\s+(\d+)%\s+\[([^\]]+)\]/);
		if (m) {
			var mount = m[1];
			var diskPct = parseInt(m[2], 10);
			var diskNext = (i + 1 < lines.length) ? lines[i + 1].trim() : '';
			var diskSubNext = (i + 2 < lines.length) ? lines[i + 2].trim() : '';
			var diskStats = diskNext.match(/занято\s+([^·]+)\s*·\s*свободно\s+([^·]+)\s*·\s*всего\s+(.+)/i);
			var devFs = (diskSubNext && !/^[=─\-_]{3,}$/.test(diskSubNext) && !/^\//.test(diskSubNext) && diskSubNext.indexOf('%') === -1)
				? diskSubNext : '';

			res.disks.push({
				mount: mount,
				pct: diskPct,
				used: diskStats ? diskStats[1].trim() : '',
				avail: diskStats ? diskStats[2].trim() : '',
				total: diskStats ? diskStats[3].trim() : '',
				fs: devFs
			});

			if (diskStats) i++;
			if (devFs) i++;
		}
	}

	return res;
}

/**
 * Объединение с данными ubus call system info / board
 */
function mergeSystemInfo(parsed, sysInfo, boardInfo) {
	if (sysInfo && sysInfo.memory && !parsed.ram) {
		var mem = sysInfo.memory;
		var totalK = Math.round((mem.total || 0) / 1024);
		var availK = Math.round((mem.available || mem.free || 0) / 1024);
		var usedK = Math.max(0, totalK - availK);
		var pct = totalK > 0 ? Math.round((usedK * 100) / totalK) : 0;
		var fmtMb = function(k) { return (k / 1024).toFixed(1) + ' MiB'; };

		parsed.ram = {
			pct: pct,
			used: fmtMb(usedK),
			avail: fmtMb(availK),
			total: fmtMb(totalK)
		};
	}

	if (sysInfo && sysInfo.load && (!parsed.load || !parsed.load.length)) {
		parsed.load = [
			(sysInfo.load[0] / 65536.0).toFixed(2),
			(sysInfo.load[1] / 65536.0).toFixed(2),
			(sysInfo.load[2] / 65536.0).toFixed(2)
		];
	}

	if (boardInfo) {
		parsed.board = {
			model: boardInfo.model || '',
			system: boardInfo.system || '',
			target: (boardInfo.release && boardInfo.release.target) || '',
			distro: (boardInfo.release && boardInfo.release.description) || ''
		};
	}

	return parsed;
}

return baseclass.extend({
	parseReport: parseResourcesReport,
	mergeInfo: mergeSystemInfo,

	/**
	 * Рендер панели ресурсов
	 * @param {Object} opts
	 * @param {Object} opts.data Данные отчета и системной инфы
	 * @param {Function} opts.onRefresh Обработчик обновления
	 * @param {Object} [opts.view] LuCI view экземпляр
	 * @returns {Node}
	 */
	render: function(opts) {
		opts = opts || {};
		var data = opts.data || {};
		var onRefresh = opts.onRefresh;
		var execResult = data.execResult || {};
		var rawText = (execResult.stdout || execResult.stderr || (typeof execResult === 'string' ? execResult : '')).trim();

		var parsed = parseResourcesReport(rawText);
		parsed = mergeSystemInfo(parsed, data.sysInfo, data.boardInfo);

		var cards = [];

		/* 1. Карточка процессора (CPU & Load) */
		var loadEls = [];
		if (parsed.load && parsed.load.length >= 3) {
			var l1 = parseFloat(parsed.load[0]);
			var loadTone = 'ok';
			var loadLabel = _('В норме');
			if (l1 >= 3.0) {
				loadTone = 'err';
				loadLabel = _('Высокая');
			} else if (l1 >= 1.0) {
				loadTone = 'warn';
				loadLabel = _('Повышенная');
			}

			loadEls.push(E('div', { 'class': 'xfree-metric-row' }, [
				E('span', { 'class': 'xfree-metric-label' }, [ _('Load Average (1 / 5 / 15 мин)') ]),
				E('span', { 'class': 'xfree-metric-value' }, [
					E('span', { 'style': 'font-family: monospace; font-size: 14px; margin-right: 8px;' }, [
						parsed.load[0] + ', ' + parsed.load[1] + ', ' + parsed.load[2]
					]),
					xcmp.badge({ text: loadLabel, tone: loadTone })
				])
			]));
		}

		if (parsed.uptime) {
			loadEls.push(E('div', { 'class': 'xfree-metric-row' }, [
				E('span', { 'class': 'xfree-metric-label' }, [ _('Время непрерывной работы (Uptime)') ]),
				E('span', { 'class': 'xfree-metric-value' }, [ parsed.uptime ])
			]));
		}

		if (parsed.board && (parsed.board.model || parsed.board.system)) {
			loadEls.push(E('div', { 'class': 'xfree-metric-row' }, [
				E('span', { 'class': 'xfree-metric-label' }, [ _('Модель / Процессор') ]),
				E('span', { 'class': 'xfree-metric-value' }, [ parsed.board.model || parsed.board.system ])
			]));
		}

		if (parsed.board && parsed.board.target) {
			loadEls.push(E('div', { 'class': 'xfree-metric-row' }, [
				E('span', { 'class': 'xfree-metric-label' }, [ _('Архитектура платформы') ]),
				E('span', { 'class': 'xfree-metric-value' }, [ parsed.board.target ])
			]));
		}

		if (parsed.time) {
			loadEls.push(E('div', { 'class': 'xfree-metric-row' }, [
				E('span', { 'class': 'xfree-metric-label' }, [ _('Системное время') ]),
				E('span', { 'class': 'xfree-metric-value' }, [ parsed.time ])
			]));
		}

		cards.push(xcmp.card({
			title: _('Процессор и система'),
			subtitle: parsed.host ? ('Хост: ' + parsed.host) : _('Общая информация'),
			badge: xcmp.badge({ text: 'CPU', tone: 'standby' }),
			content: E('div', {}, loadEls)
		}));

		/* 2. Карточка оперативной памяти (RAM) */
		var ramContent = [];
		if (parsed.ram) {
			var ramPct = parsed.ram.pct;
			var ramTone = ramPct >= 90 ? 'err' : (ramPct >= 75 ? 'warn' : 'ok');
			var ramLabel = ramPct >= 90 ? _('Дефицит памяти') : (ramPct >= 75 ? 'Внимание' : _('В норме'));

			ramContent.push(E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;' }, [
					E('span', { 'style': 'font-size: 13px; font-weight: 600;' }, [ _('Использование RAM: ') + ramPct + '%' ]),
					xcmp.badge({ text: ramLabel, tone: ramTone })
				]),
				xcmp.progressBar({ value: ramPct, tone: ramTone, height: '10px' })
			]));

			ramContent.push(E('div', { 'class': 'xfree-metric-row' }, [
				E('span', { 'class': 'xfree-metric-label' }, [ _('Занято') ]),
				E('span', { 'class': 'xfree-metric-value' }, [ parsed.ram.used ])
			]));
			ramContent.push(E('div', { 'class': 'xfree-metric-row' }, [
				E('span', { 'class': 'xfree-metric-label' }, [ _('Доступно') ]),
				E('span', { 'class': 'xfree-metric-value' }, [ parsed.ram.avail ])
			]));
			ramContent.push(E('div', { 'class': 'xfree-metric-row' }, [
				E('span', { 'class': 'xfree-metric-label' }, [ _('Всего') ]),
				E('span', { 'class': 'xfree-metric-value' }, [ parsed.ram.total ])
			]));
		} else {
			ramContent.push(E('div', { 'class': 'muted', 'style': 'padding: 12px 0;' }, [
				_('Информация об оперативной памяти временно недоступна.')
			]));
		}

		cards.push(xcmp.card({
			title: _('Оперативная память (RAM)'),
			subtitle: parsed.ram ? (_('Занято ') + parsed.ram.used + _(' из ') + parsed.ram.total) : '',
			badge: xcmp.badge({ text: 'RAM', tone: 'standby' }),
			content: E('div', {}, ramContent)
		}));

		/* 3. Карточка накопителя (Flash & Mounts) */
		var diskContent = [];
		if (parsed.disks && parsed.disks.length) {
			parsed.disks.forEach(function(d) {
				var dTone = d.pct >= 90 ? 'err' : (d.pct >= 75 ? 'warn' : 'ok');
				var subInfo = [];
				if (d.used && d.avail) {
					subInfo.push(_('занято: ') + d.used + ' · ' + _('свободно: ') + d.avail);
				}
				if (d.fs) {
					subInfo.push(d.fs);
				}

				diskContent.push(E('div', { 'style': 'margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06));' }, [
					E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;' }, [
						E('span', { 'style': 'font-weight: 600; font-family: monospace; font-size: 13px;' }, [ d.mount ]),
						E('span', { 'style': 'font-size: 12px; font-weight: 600;' }, [ d.pct + '%' ])
					]),
					xcmp.progressBar({ value: d.pct, tone: dTone, height: '6px' }),
					subInfo.length ? E('div', { 'class': 'muted', 'style': 'font-size: 11px; margin-top: 4px;' }, [ subInfo.join('  ·  ') ]) : null
				]));
			});
		} else {
			diskContent.push(E('div', { 'class': 'muted', 'style': 'padding: 12px 0;' }, [
				_('Разделы диска не обнаружены.')
			]));
		}

		cards.push(xcmp.card({
			title: _('Накопитель и разделы'),
			subtitle: _('Flash-память, /overlay и системные тома'),
			badge: xcmp.badge({ text: 'Flash', tone: 'standby' }),
			content: E('div', {}, diskContent)
		}));

		/* 4. Карточка температуры */
		var tempContent = [];
		if (parsed.thermals && parsed.thermals.length) {
			parsed.thermals.forEach(function(t) {
				tempContent.push(E('div', { 'class': 'xfree-metric-row' }, [
					E('span', { 'class': 'xfree-metric-label', 'style': 'font-weight: 500;' }, [ t.name ]),
					E('span', { 'class': 'xfree-metric-value' }, [
						E('span', { 'style': 'margin-right: 8px;' }, [ t.temp ]),
						xcmp.badge({ text: t.level, tone: t.tone })
					])
				]));
			});
		} else {
			tempContent.push(E('div', { 'style': 'padding: 16px 0; text-align: center;' }, [
				E('div', { 'style': 'font-size: 24px; margin-bottom: 6px;' }, [ '🌡️' ]),
				E('div', { 'style': 'font-weight: 500; font-size: 13px; margin-bottom: 4px;' }, [ _('Датчики температуры не обнаружены') ]),
				E('div', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
					_('На части аппаратных платформ или виртуальных машин системные термодатчики отсутствуют в sysfs.')
				])
			]));
		}

		cards.push(xcmp.card({
			title: _('Температура устройства'),
			subtitle: _('Аппаратные датчики thermal_zone и hwmon'),
			badge: xcmp.badge({ text: 'Thermal', tone: 'standby' }),
			content: E('div', {}, tempContent)
		}));

		/* Верхний экшн-бар */
		var isRefreshing = !!(opts && opts.isRefreshing);
		var refreshBtn = xcmp.refreshButton({
			isRefreshing: isRefreshing,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(res, { text: _('Обновление ресурсов…') });
					}
				}
			}
		});

		var actionBar = xcmp.actionBar({
			title: _('Состояние аппаратных ресурсов'),
			description: _('Автоматическое чтение параметров CPU, памяти, дисков и температуры'),
			actions: [ refreshBtn ]
		});

		/* Сворачиваемый терминальный вывод для опытных пользователей */
		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод show-host-resources.sh)'),
			rawText: rawText
		});

		return E('div', { 'class': 'xfree-web xfree-resources-container' }, [
			actionBar,
			E('div', { 'class': 'xfree-resource-grid' }, cards),
			spoiler
		]);
	}
});

