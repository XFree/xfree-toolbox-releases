'use strict';
'require baseclass';
'require ui';

/* Точка входа render, переключение между общим отчётом и дашбордом DNS.
 * Методы вешаются на прототип xfree-report. */

return baseclass.extend({
	mount: function (spec) {
		this._spec = spec || {};
		this._filterMode = 'all';
		this._searchQuery = '';
		this._showConsole = false;
		this.requestPaint();
	},

	_renderGenericReport: function (s, desc, pollSec, view, reloadFn) {
		var consoleEl = E('xfree-console', {
			'label': _('Вывод'),
			'class': 'xfree-report-output',
			'style': '--xfree-console-max-height:70vh'
		});
		consoleEl.text = s.text || '';

		this.className = 'panel-block';
		this.replaceChildren(
			E('h3', {}, [ s.title || '' ]),
			E('p', { 'class': 'muted' }, [ desc ]),
			E('div', { 'class': 'actions', 'style': 'grid-template-columns:1fr;max-width:16rem' }, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': ui.createHandlerFn(view, reloadFn)
				}, [ _('Обновить') ])
			]),
			consoleEl
		);
	},

	_renderDnsDashboard: function (s, view, reloadFn) {
		var self = this;
		var parsed = this._parseDnsReport(s.text || '');
		var isRunning = parsed.status === 'running';
		var failSecCount = 0;
		var totalSecCount = parsed.sections.length;
		var i;

		for (i = 0; i < parsed.sections.length; i++) {
			if (parsed.sections[i].failCount > 0)
				failSecCount++;
		}

		var stats = this._renderDnsStats(parsed, isRunning);
		var toolbar = this._renderDnsToolbar(parsed, view, reloadFn, totalSecCount, failSecCount, isRunning);
		var cardsGrid = this._renderDnsSectionCards(parsed, view, reloadFn, totalSecCount, isRunning);

		var consoleEl = E('xfree-console', {
			'label': _('Сырой вывод терминала (dns-check.log)'),
			'class': 'xfree-report-output',
			'style': '--xfree-console-max-height:70vh; margin-top: 12px;' + (self._showConsole ? '' : 'display: none;')
		});
		consoleEl.text = s.text || '';

		this.className = 'panel-block';
		this.replaceChildren(
			E('div', { 'class': 'xfree-dns-root' }, [
				E('div', { 'style': 'display: flex; align-items: baseline; justify-content: space-between; gap: 10px; flex-wrap: wrap;' }, [
					E('div', {}, [
						E('h3', { 'style': 'margin: 0 0 4px;' }, [ s.title || _('Диагностика DNS') ]),
						E('p', { 'class': 'muted', 'style': 'margin: 0;' }, [
							s.descr || _('Запросы A по секциям DNS активного профиля и эталонам Google.')
						])
					]),
					stats.statusBadge
				]),
				stats.statsBlock,
				toolbar,
				cardsGrid,
				consoleEl
			])
		);
	},

	render: function () {
		var s = this._spec || {};
		var desc = s.descr || _('Отчёт с роутера (тот же скрипт, что в CLI).');
		var pollSec = s.pollSec || 0;
		var view = s.view;
		var reloadFn = s.onReload;

		this._isDns = (s.title && s.title.indexOf('DNS') >= 0) ||
			(s.descr && s.descr.indexOf('DNS') >= 0) ||
			/Диагностика DNS|STATUS:.*pid=|=== Диагностика DNS/.test(s.text || '');

		if (this._isDns) {
			this._renderDnsDashboard(s, view, reloadFn);
		} else {
			this._renderGenericReport(s, desc, pollSec, view, reloadFn);
		}
	}
});
