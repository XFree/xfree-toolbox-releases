'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.loading as loading';
'require xfree-toolbox.luci-ui as xui';


var xcmp = components;

/** Parse 0.2.2+2 / 0.2.0-r0 / xfree-toolbox-0.2.0-r0 → parts or null */
function parseXfreeVersion(s) {
	var m = String(s || '').match(/(\d+)\.(\d+)\.(\d+)(?:\+(\d+)|-r(\d+))?/);
	if (!m)
		return null;
	return {
		maj: parseInt(m[1], 10),
		min: parseInt(m[2], 10),
		pat: parseInt(m[3], 10),
		bld: parseInt(m[4] || m[5] || '0', 10)
	};
}

/** @returns {-1|0|1|null} a<b / equal / a>b; null if unparsable */
function cmpXfreeVersion(a, b) {
	var A = parseXfreeVersion(a);
	var B = parseXfreeVersion(b);
	if (!A || !B)
		return null;
	if (A.maj !== B.maj) return A.maj > B.maj ? 1 : -1;
	if (A.min !== B.min) return A.min > B.min ? 1 : -1;
	if (A.pat !== B.pat) return A.pat > B.pat ? 1 : -1;
	if (A.bld !== B.bld) return A.bld > B.bld ? 1 : -1;
	return 0;
}

/**
 * Единая нормализация статуса обновления (rail + вкладка «Обновления»).
 * Канон ключей: available | none | error | unknown
 * (up-to-date принимается как синоним none).
 */
function normalizeUpdateComponent(comp) {
	if (!comp)
		return comp;
	if (comp.update === 'up-to-date')
		comp.update = 'none';
	if (comp.update === 'none') {
		if (!comp.updateLabel || String(comp.updateLabel).indexOf('не проверен') !== -1)
			comp.updateLabel = 'актуально';
	}
	/* Semver: available ≤ current → none (тот же алгоритм для сайдбара и карточек). */
	if (comp.availablePkg && comp.version) {
		var c = cmpXfreeVersion(comp.version, comp.availablePkg);
		if (c !== null && c >= 0) {
			comp.update = 'none';
			comp.updateLabel = 'актуально';
			comp.availablePkg = '';
		}
	}
	return comp;
}

function isUpdateAvailable(comp) {
	return !!(comp && (comp.update === 'available' ||
		(comp.updateLabel && String(comp.updateLabel).indexOf('есть обновление') !== -1)));
}

function isUpdateCurrent(comp) {
	return !!(comp && (comp.update === 'none' || comp.update === 'up-to-date' ||
		(comp.updateLabel && String(comp.updateLabel).indexOf('актуальн') !== -1)));
}

function formatNewVersionValue(comp) {
	if (isUpdateAvailable(comp) && comp.availablePkg) {
		return String(comp.availablePkg).split(/\s+/)[0] || String(comp.availablePkg);
	}
	if (isUpdateCurrent(comp))
		return _('нет');
	return '—';
}

/**
 * Парсер текстового отчета autoUpdateStatus (system/luci-rpc.sh autoUpdateStatus)
 * @param {string} text
 * @returns {Object}
 */
function parseUpdatesReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		toolbox: {
			version: '',
			update: 'unknown',
			updateLabel: 'не проверено',
			channel: '',
			availablePkg: '',
			checkedAt: '',
			summary: ''
		},
		luci: {
			version: '',
			update: 'unknown',
			updateLabel: 'не проверено',
			availablePkg: '',
			checkedAt: ''
		},
		autoUpdate: {
			enabled: false,
			mode: '',
			schedule: '',
			cron: '',
			running: false,
			lastLogLine: '',
			lastLogDate: ''
		},
		apkFeed: {
			enabled: false,
			source: '',
			mirror: '',
			url: '',
			githubOk: false,
			nextcloudOk: false
		},
		rawText: String(text || '')
	};

	var currentSection = '';

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i].trim();
		if (!line)
			continue;

		if (line.indexOf('=== xfree-toolbox ===') !== -1) {
			currentSection = 'toolbox';
			continue;
		} else if (line.indexOf('=== LUCI_APP ===') !== -1) {
			currentSection = 'luci_app';
			continue;
		} else if (line.indexOf('=== AUTO_UPDATE ===') !== -1) {
			currentSection = 'auto_update';
			continue;
		} else if (line.indexOf('=== APK_FEED ===') !== -1) {
			currentSection = 'apk_feed';
			continue;
		}

		var m;

		// Key-values for toolbox
		if (line.indexOf('TOOLBOX_VERSION=') === 0) {
			res.toolbox.version = line.substring(16).trim();
		} else if (line.indexOf('TOOLBOX_UPDATE=') === 0) {
			res.toolbox.update = line.substring(15).trim();
		} else if (line.indexOf('TOOLBOX_UPDATE_LABEL=') === 0) {
			res.toolbox.updateLabel = line.substring(21).trim();
		} else if (line.indexOf('TOOLBOX_CHANNEL=') === 0) {
			res.toolbox.channel = line.substring(16).trim();
		} else if (line.indexOf('TOOLBOX_AVAILABLE=') === 0) {
			res.toolbox.availablePkg = line.substring(18).trim();
		} else if (line.indexOf('TOOLBOX_CHECKED_AT=') === 0) {
			res.toolbox.checkedAt = line.substring(19).trim();
		} else if (line.indexOf('TOOLBOX_SUMMARY=') === 0) {
			res.toolbox.summary = line.substring(16).trim();
		}

		// Key-values for luci
		if (line.indexOf('LUCI_VERSION=') === 0) {
			res.luci.version = line.substring(13).trim();
		} else if (line.indexOf('LUCI_UPDATE=') === 0) {
			res.luci.update = line.substring(12).trim();
		} else if (line.indexOf('LUCI_UPDATE_LABEL=') === 0) {
			res.luci.updateLabel = line.substring(18).trim();
		} else if (line.indexOf('LUCI_AVAILABLE=') === 0) {
			res.luci.availablePkg = line.substring(15).trim();
		}

		/* Тот же отчёт: человекочитаемые строки, если KEY= ещё пуст. */
		if (currentSection === 'toolbox') {
			m = line.match(/^Версия\s*:\s*(.+)$/i);
			if (m && !res.toolbox.version) res.toolbox.version = m[1].trim();

			m = line.match(/^Обновления\s*:\s*(.+)$/i);
			if (m && !res.toolbox.updateLabel) res.toolbox.updateLabel = m[1].trim();

			m = line.match(/^Канал\s*:\s*(.+)$/i);
			if (m && !res.toolbox.channel) res.toolbox.channel = m[1].trim();

			m = line.match(/^Available\s*:\s*(.+)$/i);
			if (m && !res.toolbox.availablePkg) res.toolbox.availablePkg = m[1].trim();

			m = line.match(/^Проверено\s*:\s*(.+)$/i);
			if (m && !res.toolbox.checkedAt) res.toolbox.checkedAt = m[1].trim();
		}

		if (line.indexOf('[*] Package         : luci-app-xfree-toolbox') !== -1) {
			currentSection = 'luci_check';
		}
		if (currentSection === 'luci_check') {
			m = line.match(/^\[\*\]\s*Available\s*:\s*(.+)$/i);
			if (m && !res.luci.availablePkg) res.luci.availablePkg = m[1].trim();

			m = line.match(/^\[\*\]\s*Upgradable\s*:\s*(yes|no)$/i);
			if (m) {
				if (m[1].toLowerCase() === 'yes') {
					res.luci.update = 'available';
					res.luci.updateLabel = 'есть обновление';
				} else {
					res.luci.update = 'none';
					res.luci.updateLabel = 'актуально';
				}
			}
		}

		// Auto Update
		if (line.indexOf('ENABLED=') === 0) {
			res.autoUpdate.enabled = (line.substring(8).trim() === '1');
		} else if (line.indexOf('MODE=') === 0) {
			res.autoUpdate.mode = line.substring(5).trim();
		} else if (line.indexOf('SCHEDULE=') === 0) {
			res.autoUpdate.schedule = line.substring(9).trim();
		} else if (line.indexOf('cron=') === 0) {
			res.autoUpdate.cron = line.substring(5).trim();
		} else if (line.indexOf('RUNNING=') === 0) {
			res.autoUpdate.running = (line.substring(8).trim() === '1');
		} else if (line.indexOf('LAST_LOG_LINE=') === 0) {
			res.autoUpdate.lastLogLine = line.substring(14).trim();
		} else if (line.indexOf('LAST_LOG_DATE=') === 0) {
			res.autoUpdate.lastLogDate = line.substring(14).trim();
		}

		// APK Feed
		if (currentSection === 'apk_feed') {
			m = line.match(/^\[\*\]\s*Фид\s*xfree\s*:\s*(.+)$/i);
			if (m) {
				var statusStr = m[1].trim().toLowerCase();
				res.apkFeed.enabled = (statusStr === 'вкл' || statusStr === 'on' || statusStr === 'enabled' || statusStr === '1');
			}
			m = line.match(/^\[\*\]\s*Источник\s*:\s*(.+)$/i);
			if (m) res.apkFeed.source = m[1].trim();

			m = line.match(/^\[\*\]\s*Зеркало\s*:\s*(.+)$/i);
			if (m) res.apkFeed.mirror = m[1].trim();

			m = line.match(/^\[\*\]\s*URL\s*:\s*(.+)$/i);
			if (m) res.apkFeed.url = m[1].trim();

			m = line.match(/^\[\*\]\s*Доступность\s*GitHub\s*:\s*(.+)$/i);
			if (m) res.apkFeed.githubOk = (m[1].indexOf('доступен') !== -1 && m[1].indexOf('недоступен') === -1);

			m = line.match(/^\[\*\]\s*Доступность\s*Nextcloud\s*:\s*(.+)$/i);
			if (m) res.apkFeed.nextcloudOk = (m[1].indexOf('доступен') !== -1 && m[1].indexOf('недоступен') === -1);
		}
	}

	normalizeUpdateComponent(res.toolbox);
	normalizeUpdateComponent(res.luci);
	return res;
}

function renderMetricRow(label, valueNode) {
	return E('div', { 'class': 'xfree-metric-row' }, [
		E('span', { 'class': 'xfree-metric-label' }, [ label ]),
		E('div', { 'class': 'xfree-metric-value' }, [ valueNode ])
	]);
}

function renderToolboxCard(info, view, onRefresh) {
	var tb = info.toolbox;
	var isAvail = isUpdateAvailable(tb);
	var isOk = isUpdateCurrent(tb);
	var newVer = formatNewVersionValue(tb);

	var badgeTone = isAvail ? 'warning' : (isOk ? 'ok' : 'neutral');
	var badgeText = isAvail ? _('Доступно обновление') : (isOk ? _('Актуально') : (tb.updateLabel || _('Не проверено')));

	var rows = [];

	rows.push(renderMetricRow(_('Текущая версия'), E('span', { 'class': 'font-mono', 'style': 'font-weight: 700;' }, [
		tb.version ? ('v' + tb.version) : _('Не определена')
	])));

	rows.push(renderMetricRow(_('Канал обновлений'), E('span', {}, [
		tb.channel ? tb.channel.toUpperCase() : _('APK (OpenWrt 25+)')
	])));

	rows.push(renderMetricRow(_('Последняя проверка'), E('span', { 'class': 'muted font-mono', 'style': 'font-size: 12px;' }, [
		tb.checkedAt || _('Ещё не выполнялась')
	])));

	rows.push(renderMetricRow(_('Новая версия'), E('span', {
		'class': isAvail ? '' : 'muted',
		'style': isAvail ? 'color: var(--accent); font-weight: 600;' : ''
	}, [ newVer ])));

	var upgradeBtn = xcmp.button({
		text: _('⚡ Обновить xfree-toolbox'),
		tone: 'action',
		disabled: !isAvail,
		title: isAvail ? _('Обновить пакет xfree-toolbox сейчас') : _('Обновлений не обнаружено'),
		onClick: function(ev) {
			if (!confirm(_('Обновить xfree-toolbox сейчас? Пользовательские профили сохраняются.'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('upgrade').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Обновление xfree-toolbox завершено!') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [upgradeBtn]);

	return xcmp.card({
		title: _('Ядро и CLI (xfree-toolbox)'),
		subtitle: _('Системные скрипты и службы xfree-toolbox'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderLuciCard(info, view, onRefresh) {
	var luci = info.luci;
	var isAvail = isUpdateAvailable(luci);
	var isOk = isUpdateCurrent(luci);
	var newVer = formatNewVersionValue(luci);

	var badgeTone = isAvail ? 'warning' : (isOk ? 'ok' : 'neutral');
	var badgeText = isAvail ? _('Доступно обновление') : (isOk ? _('Актуально') : (luci.updateLabel || _('Не проверено')));

	var rows = [];

	rows.push(renderMetricRow(_('Текущая версия'), E('span', { 'class': 'font-mono', 'style': 'font-weight: 700;' }, [
		luci.version ? ('v' + luci.version) : _('Установлен')
	])));

	rows.push(renderMetricRow(_('Компонент интерфейса'), E('span', {}, [
		'luci-app-xfree-toolbox'
	])));

	rows.push(renderMetricRow(_('Среда интерфейса'), E('span', {}, [
		_('OpenWrt LuCI (client-side JS)')
	])));

	rows.push(renderMetricRow(_('Новая версия'), E('span', {
		'class': isAvail ? '' : 'muted',
		'style': isAvail ? 'color: var(--accent); font-weight: 600;' : ''
	}, [ newVer ])));

	var upgradeLuciBtn = xcmp.button({
		text: _('⚡ Обновить веб-панель (LuCI)'),
		tone: 'action',
		disabled: !isAvail,
		title: isAvail ? _('Обновить пакет веб-интерфейса luci-app-xfree-toolbox') : _('Обновлений интерфейса не обнаружено'),
		onClick: function(ev) {
			if (!confirm(_('Обновить веб-интерфейс LuCI сейчас? После обновления страница будет перезагружена.'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('upgradeLuci').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Веб-интерфейс LuCI успешно обновлён!') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка обновления LuCI: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [upgradeLuciBtn]);

	return xcmp.card({
		title: _('Веб-панель (LuCI)'),
		subtitle: _('Интерфейс управления роутером luci-app-xfree-toolbox'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderAutoUpdateCard(info, view, onRefresh) {
	var au = info.autoUpdate;
	var isEnabled = au.enabled;
	var isRunning = au.running;

	var badgeTone = isRunning ? 'warning' : (isEnabled ? 'ok' : 'neutral');
	var badgeText = isRunning ? _('Выполняется…') : (isEnabled ? _('Включено') : _('Отключено'));

	var rows = [];

	rows.push(renderMetricRow(_('Расписание (cron)'), E('span', { 'class': 'font-mono' }, [
		isEnabled ? (au.schedule || '02:00') : _('Не назначено')
	])));

	rows.push(renderMetricRow(_('Режим'), E('span', { 'style': 'font-size: 12px;' }, [
		au.mode || _('Списки upstream + пакет toolbox')
	])));

	rows.push(renderMetricRow(_('Служба планировщика'), E('span', {}, [
		au.cron === 'installed' ? 'crond (активен)' : (au.cron || 'crond')
	])));

	if (au.lastLogDate) {
		var logText = au.lastLogLine ? (au.lastLogDate + ' (' + au.lastLogLine + ')') : au.lastLogDate;
		rows.push(renderMetricRow(_('Последний запуск'), E('span', { 'class': 'muted font-mono', 'style': 'font-size: 11px;' }, [
			logText
		])));
	}

	// Actions
	var toggleBtn = xcmp.button({
		text: isEnabled ? _('Выключить автообновление') : _('Включить автообновление'),
		tone: isEnabled ? 'ghost' : 'primary',
		onClick: function(ev) {
			var action = isEnabled ? 'autoUpdateDisable' : 'autoUpdateEnable';
			var btn = ev.target;
			loading.track(btn, view.runSystemAction(action).then(function() {
				ui.addNotification(null, E('p', {}, [ isEnabled ? _('Автообновление выключено') : _('Автообновление включено') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var runNowBtn = xcmp.button({
		text: _('▶ Запустить сейчас'),
		tone: 'secondary',
		disabled: isRunning,
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('autoUpdateRunNow').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Фоновое автообновление запущено') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка запуска: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, isEnabled ? [toggleBtn, runNowBtn] : [toggleBtn]);

	return xcmp.card({
		title: _('Фоновое автообновление'),
		subtitle: _('Ночная синхронизация списков и пакетов по cron'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderApkFeedCard(info, view, onRefresh) {
	var feed = info.apkFeed;
	var isEnabled = feed.enabled;
	var isGithub = !feed.source || feed.source.toLowerCase().indexOf('github') !== -1;

	var badgeTone = isEnabled ? 'ok' : 'neutral';
	var badgeText = isEnabled ? _('Фид активен') : _('Фид отключён');

	var rows = [];

	rows.push(renderMetricRow(_('Основной источник'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		E('span', { 'style': isGithub ? 'font-weight: 700;' : '' }, [
			isGithub ? '★ GitHub (активен)' : 'GitHub'
		]),
		xcmp.badge({
			text: feed.githubOk ? 'доступен ✓' : 'недоступен ✗',
			tone: feed.githubOk ? 'ok' : 'critical'
		})
	])));

	rows.push(renderMetricRow(_('Резервное зеркало'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		E('span', { 'style': !isGithub ? 'font-weight: 700;' : '' }, [
			!isGithub ? '★ Nextcloud (активен)' : 'Nextcloud'
		]),
		xcmp.badge({
			text: feed.nextcloudOk ? 'доступен ✓' : 'недоступен ✗',
			tone: feed.nextcloudOk ? 'ok' : 'critical'
		})
	])));

	if (feed.url) {
		rows.push(renderMetricRow(_('URL пакетов'), E('span', {
			'class': 'font-mono muted',
			'style': 'font-size: 11px; word-break: break-all; max-width: 260px; text-align: right;'
		}, [feed.url])));
	}

	var switchSourceBtn = xcmp.button({
		text: isGithub ? _('⇄ На Nextcloud') : _('⇄ На GitHub'),
		tone: 'secondary',
		disabled: !isEnabled,
		title: isGithub ? _('Переключить активный источник на Nextcloud') : _('Переключить активный источник на GitHub'),
		onClick: function(ev) {
			var targetSource = isGithub ? 'cloud' : 'github';
			var targetName = isGithub ? 'Nextcloud' : 'GitHub';
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('apkFeedSetSource', targetSource).then(function() {
				ui.addNotification(null, E('p', {}, [ _('Источник APK-фида переключён на: ') + targetName ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка переключения: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var failoverBtn = xcmp.button({
		text: _('⚡ Failover'),
		tone: 'secondary',
		disabled: !isEnabled,
		title: _('Проверить доступность и автоматически переключить на рабочее зеркало при сбое'),
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('apkFeedFailover').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Проверка доступности и failover завершены') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка failover: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var toggleFeedBtn = xcmp.button({
		text: isEnabled ? _('Отключить фид') : _('Включить фид'),
		tone: isEnabled ? 'ghost' : 'primary',
		onClick: function(ev) {
			var action = isEnabled ? 'apkFeedDisable' : 'apkFeedEnable';
			var btn = ev.target;
			loading.track(btn, view.runSystemAction(action).then(function() {
				ui.addNotification(null, E('p', {}, [ isEnabled ? _('APK-фид отключён') : _('APK-фид подключён') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [switchSourceBtn, failoverBtn, toggleFeedBtn]);

	return xcmp.card({
		title: _('Каналы APK и репозиторий'),
		subtitle: _('Официальный репозиторий пакетов OpenWrt'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

return baseclass.extend({
	parseReport: parseUpdatesReport,
	normalizeUpdateComponent: normalizeUpdateComponent,
	isUpdateAvailable: isUpdateAvailable,
	isUpdateCurrent: isUpdateCurrent,

	render: function (opts) {
		opts = opts || {};
		var data = opts.data || {};
		var view = opts.view || {};
		var onRefresh = opts.onRefresh;

		var rawText = '';
		if (data.execResult) {
			rawText = data.execResult.stdout || data.execResult.stderr || '';
		}

		var info = parseUpdatesReport(rawText);

		var xuiInst = (opts && opts.xui) || (typeof xui !== 'undefined' ? xui : null);

		var panelView = {
			runSystemAction: function (action, arg, payload) {
				var x = xuiInst || (typeof xui !== 'undefined' ? xui : null);
				if (x && typeof x.runSystemMenuWithOutput === 'function') {
					return x.runSystemMenuWithOutput(action, arg, payload);
				}
				var fn = (view && typeof view.runSystemMenu === 'function') ? view.runSystemMenu.bind(view) :
				         ((x && typeof x.runSystemMenu === 'function') ? x.runSystemMenu.bind(x) : null);
				if (!fn) {
					return Promise.reject(new Error(_('runSystemMenu is not available')));
				}
				return fn(action, arg, payload).then(function(res) {
					if (res && res.code != null && res.code !== 0) {
						var msg = res.stderr || res.stdout || ('exit ' + res.code);
						return Promise.reject(new Error(msg));
					}
					return res;
				});
			}
		};

		var cards = [
			renderToolboxCard(info, panelView, onRefresh),
			renderLuciCard(info, panelView, onRefresh),
			renderAutoUpdateCard(info, panelView, onRefresh),
			renderApkFeedCard(info, panelView, onRefresh)
		];

		// Toolbar buttons: Check all updates & Refresh status
		var checkAllBtn = xcmp.button({
			text: '🔍 ' + _('Проверить обновления'),
			tone: 'primary',
			onClick: function (ev) {
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('checkUpdate').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Проверка обновлений xfree-toolbox и LuCI завершена') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка проверки: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		});

		var refreshBtn = xcmp.refreshButton({
			isRefreshing: false,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(refreshBtn, res);
					}
				}
			}
		});

		var isTbAvail = isUpdateAvailable(info.toolbox);
		var isLuciAvail = isUpdateAvailable(info.luci);
		var headerActions = [ checkAllBtn ];

		/* Сайдбар и вкладка — один нормализованный статус. */
		if (view && typeof view.updateRailBrand === 'function') {
			view.updateRailBrand({
				version: info.toolbox.version || '',
				update: info.toolbox.update || 'unknown',
				label: info.toolbox.updateLabel || ''
			});
		}

		if (isTbAvail && isLuciAvail) {
			var updateAllBtn = xcmp.button({
				text: '⚡ ' + _('Обновить всё (Core + LuCI)'),
				tone: 'action',
				onClick: function (ev) {
					if (!confirm(_('Обновить все компоненты (пакет xfree-toolbox и веб-панель LuCI) сейчас?'))) {
						return;
					}
					var btn = ev.target;
					loading.track(btn, panelView.runSystemAction('upgrade').then(function () {
						return panelView.runSystemAction('upgradeLuci');
					}).then(function () {
						ui.addNotification(null, E('p', {}, [ _('Все компоненты успешно обновлены!') ]), 'info');
						if (typeof onRefresh === 'function') return onRefresh();
					}).catch(function (err) {
						ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
					}));
				}
			});
			headerActions.push(updateAllBtn);
		}

		headerActions.push(refreshBtn);

		var actionBar = xcmp.actionBar({
			title: _('Центр обновлений'),
			description: _('Управление релизами xfree-toolbox и LuCI, автообновлением по cron и APK-фидом'),
			actions: headerActions
		});

		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод autoUpdateStatus)'),
			rawText: rawText
		});

		return E('div', { 'class': 'xfree-web xfree-system-updates-panel' }, [
			actionBar,
			E('div', { 'class': 'xfree-resource-grid' }, cards),
			spoiler
		]);
	}
});
