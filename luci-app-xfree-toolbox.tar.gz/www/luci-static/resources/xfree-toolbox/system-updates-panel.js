'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.core.loading as loading';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.system-updates-report as updatesReport';
'require xfree-toolbox.system-updates-cards as updatesCards';
'require xfree-toolbox.system-updates-autoupdate as updatesAuto';

var xcmp = components;

return baseclass.extend({
	parseReport: updatesReport.parseUpdatesReport,
	normalizeUpdateComponent: updatesReport.normalizeUpdateComponent,
	isUpdateAvailable: updatesReport.isUpdateAvailable,
	isUpdateCurrent: updatesReport.isUpdateCurrent,
	openAutoUpdateSettingsModal: updatesAuto.openAutoUpdateSettingsModal,

	render: function (opts) {
		opts = opts || {};
		var data = opts.data || {};
		var view = opts.view || {};
		var onRefresh = opts.onRefresh;

		var rawText = '';
		if (data.execResult) {
			rawText = data.execResult.stdout || data.execResult.stderr || '';
		}

		var info = updatesReport.parseUpdatesReport(rawText);

		var xuiInst = (opts && opts.xui) || (typeof xui !== 'undefined' ? xui : null);

		var panelView = {
			runSystemMenu: function (action, arg, payload) {
				var x = xuiInst || (typeof xui !== 'undefined' ? xui : null);
				var fn = (x && typeof x.runSystemMenu === 'function') ? x.runSystemMenu.bind(x) :
				         ((view && typeof view.runSystemMenu === 'function') ? view.runSystemMenu.bind(view) : null);
				if (!fn) {
					return Promise.reject(new Error(_('runSystemMenu is not available')));
				}
				return fn(action, arg, payload).then(function(res) {
					if (res && res.code != null && res.code !== 0) {
						var msg = res.stderr || res.stdout || ('exit ' + res.code);
						return Promise.reject(new Error(msg));
					}
					return res;
				});
			},
			runSystemAction: function (action, arg, payload) {
				var x = xuiInst || (typeof xui !== 'undefined' ? xui : null);
				if (x && typeof x.runSystemMenuWithOutput === 'function') {
					return x.runSystemMenuWithOutput(action, arg, payload);
				}
				return this.runSystemMenu(action, arg, payload);
			}
		};

		var cards = [
			updatesCards.renderPlatformCard(info, panelView, onRefresh),
			updatesAuto.renderAutoUpdateCard(info, panelView, onRefresh),
			updatesCards.renderApkFeedCard(info, panelView, onRefresh)
		];

		var checkAllBtn = xcmp.button({
			text: '🔍 ' + _('Проверить обновления'),
			tone: 'primary',
			onClick: function (ev) {
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('checkUpdate').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Проверка обновлений xfree-toolbox и LuCI завершена') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка проверки: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		});

		var refreshBtn = xcmp.refreshButton({
			isRefreshing: false,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(refreshBtn, res);
					}
				}
			}
		});

		var isTbAvail = updatesReport.isUpdateAvailable(info.toolbox);
		var isLuciAvail = updatesReport.isUpdateAvailable(info.luci);
		var headerActions = [ checkAllBtn ];

		if (view && typeof view.updateRailBrand === 'function') {
			view.updateRailBrand({
				version: info.toolbox.version || '',
				update: info.toolbox.update || 'unknown',
				label: info.toolbox.updateLabel || ''
			});
		}

		if (isTbAvail && isLuciAvail) {
			var updateAllBtn = xcmp.button({
				text: '⚡ ' + _('Обновить всё (Core + LuCI)'),
				tone: 'action',
				onClick: function (ev) {
					if (!confirm(_('Обновить все компоненты (пакет xfree-toolbox и веб-панель LuCI) сейчас?'))) {
						return;
					}
					var btn = ev.target;
					loading.track(btn, panelView.runSystemAction('upgrade').then(function () {
						return panelView.runSystemAction('upgradeLuci');
					}).then(function () {
						ui.addNotification(null, E('p', {}, [ _('Все компоненты успешно обновлены!') ]), 'info');
						if (typeof onRefresh === 'function') return onRefresh();
					}).catch(function (err) {
						ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
					}));
				}
			});
			headerActions.push(updateAllBtn);
		}

		headerActions.push(refreshBtn);

		var actionBar = xcmp.actionBar({
			title: _('Центр обновлений'),
			description: _('Управление релизами xfree-toolbox и LuCI, автообновлением по cron и APK-фидом'),
			actions: headerActions
		});

		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод autoUpdateStatus)'),
			rawText: rawText
		});

		return E('div', { 'class': 'xfree-web xfree-system-updates-panel' }, [
			actionBar,
			E('div', { 'class': 'xfree-resource-grid' }, cards),
			spoiler
		]);
	}
});
