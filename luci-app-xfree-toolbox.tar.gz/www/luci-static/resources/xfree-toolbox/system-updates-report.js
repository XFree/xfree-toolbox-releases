'use strict';
'require baseclass';

function parseXfreeVersion(s) {
	var m = String(s || '').match(/(\d+)\.(\d+)\.(\d+)(?:\+(\d+)|-r(\d+))?/);
	if (!m)
		return null;
	return {
		maj: parseInt(m[1], 10),
		min: parseInt(m[2], 10),
		pat: parseInt(m[3], 10),
		bld: parseInt(m[4] || m[5] || '0', 10)
	};
}

/** @returns {-1|0|1|null} a<b / equal / a>b; null if unparsable */
function cmpXfreeVersion(a, b) {
	var A = parseXfreeVersion(a);
	var B = parseXfreeVersion(b);
	if (!A || !B)
		return null;
	if (A.maj !== B.maj) return A.maj > B.maj ? 1 : -1;
	if (A.min !== B.min) return A.min > B.min ? 1 : -1;
	if (A.pat !== B.pat) return A.pat > B.pat ? 1 : -1;
	if (A.bld !== B.bld) return A.bld > B.bld ? 1 : -1;
	return 0;
}

/**
 * Единая нормализация статуса обновления (rail + вкладка «Обновления»).
 * Канон ключей: available | none | error | unknown
 * (up-to-date принимается как синоним none).
 */
function normalizeUpdateComponent(comp) {
	if (!comp)
		return comp;
	if (comp.update === 'up-to-date')
		comp.update = 'none';
	if (comp.update === 'none') {
		if (!comp.updateLabel || String(comp.updateLabel).indexOf('не проверен') !== -1)
			comp.updateLabel = 'актуально';
	}
	/* Semver: available ≤ current → none (тот же алгоритм для сайдбара и карточек). */
	if (comp.availablePkg && comp.version) {
		var c = cmpXfreeVersion(comp.version, comp.availablePkg);
		if (c !== null && c >= 0) {
			comp.update = 'none';
			comp.updateLabel = 'актуально';
			comp.availablePkg = '';
		}
	}
	return comp;
}

function isUpdateAvailable(comp) {
	return !!(comp && (comp.update === 'available' ||
		(comp.updateLabel && String(comp.updateLabel).indexOf('есть обновление') !== -1)));
}

function isUpdateCurrent(comp) {
	return !!(comp && (comp.update === 'none' || comp.update === 'up-to-date' ||
		(comp.updateLabel && String(comp.updateLabel).indexOf('актуальн') !== -1)));
}

function formatNewVersionValue(comp) {
	if (isUpdateAvailable(comp) && comp.availablePkg) {
		return String(comp.availablePkg).split(/\s+/)[0] || String(comp.availablePkg);
	}
	if (isUpdateCurrent(comp))
		return _('нет');
	return '—';
}

/**
 * Парсер текстового отчета autoUpdateStatus (system/luci-rpc.sh autoUpdateStatus)
 * @param {string} text
 * @returns {Object}
 */
function parseUpdatesReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		toolbox: {
			version: '',
			update: 'unknown',
			updateLabel: 'не проверено',
			channel: '',
			availablePkg: '',
			checkedAt: '',
			summary: ''
		},
		luci: {
			version: '',
			update: 'unknown',
			updateLabel: 'не проверено',
			availablePkg: '',
			checkedAt: ''
		},
		autoUpdate: {
			enabled: false,
			mode: '',
			modeKey: 'upstreams-lists-package',
			schedule: '',
			hour: 2,
			minute: 0,
			cron: '',
			running: false,
			lastLogLine: '',
			lastLogDate: ''
		},
		apkFeed: {
			enabled: false,
			source: '',
			mirror: '',
			url: '',
			githubOk: false,
			nextcloudOk: false
		},
		rawText: String(text || '')
	};

	var currentSection = '';

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i].trim();
		if (!line)
			continue;

		if (line.indexOf('=== xfree-toolbox ===') !== -1) {
			currentSection = 'toolbox';
			continue;
		} else if (line.indexOf('=== LUCI_APP ===') !== -1) {
			currentSection = 'luci_app';
			continue;
		} else if (line.indexOf('=== AUTO_UPDATE ===') !== -1) {
			currentSection = 'auto_update';
			continue;
		} else if (line.indexOf('=== APK_FEED ===') !== -1) {
			currentSection = 'apk_feed';
			continue;
		}

		var m;

		// Key-values for toolbox
		if (line.indexOf('TOOLBOX_VERSION=') === 0) {
			res.toolbox.version = line.substring(16).trim();
		} else if (line.indexOf('TOOLBOX_UPDATE=') === 0) {
			res.toolbox.update = line.substring(15).trim();
		} else if (line.indexOf('TOOLBOX_UPDATE_LABEL=') === 0) {
			res.toolbox.updateLabel = line.substring(21).trim();
		} else if (line.indexOf('TOOLBOX_CHANNEL=') === 0) {
			res.toolbox.channel = line.substring(16).trim();
		} else if (line.indexOf('TOOLBOX_AVAILABLE=') === 0) {
			res.toolbox.availablePkg = line.substring(18).trim();
		} else if (line.indexOf('TOOLBOX_CHECKED_AT=') === 0) {
			res.toolbox.checkedAt = line.substring(19).trim();
		} else if (line.indexOf('TOOLBOX_SUMMARY=') === 0) {
			res.toolbox.summary = line.substring(16).trim();
		}

		// Key-values for luci
		if (line.indexOf('LUCI_VERSION=') === 0) {
			res.luci.version = line.substring(13).trim();
		} else if (line.indexOf('LUCI_UPDATE=') === 0) {
			res.luci.update = line.substring(12).trim();
		} else if (line.indexOf('LUCI_UPDATE_LABEL=') === 0) {
			res.luci.updateLabel = line.substring(18).trim();
		} else if (line.indexOf('LUCI_AVAILABLE=') === 0) {
			res.luci.availablePkg = line.substring(15).trim();
		}

		/* Тот же отчёт: человекочитаемые строки, если KEY= ещё пуст. */
		if (currentSection === 'toolbox') {
			m = line.match(/^Версия\s*:\s*(.+)$/i);
			if (m && !res.toolbox.version) res.toolbox.version = m[1].trim();

			m = line.match(/^Обновления\s*:\s*(.+)$/i);
			if (m && !res.toolbox.updateLabel) res.toolbox.updateLabel = m[1].trim();

			m = line.match(/^Канал\s*:\s*(.+)$/i);
			if (m && !res.toolbox.channel) res.toolbox.channel = m[1].trim();

			m = line.match(/^Available\s*:\s*(.+)$/i);
			if (m && !res.toolbox.availablePkg) res.toolbox.availablePkg = m[1].trim();

			m = line.match(/^Проверено\s*:\s*(.+)$/i);
			if (m && !res.toolbox.checkedAt) res.toolbox.checkedAt = m[1].trim();
		}

		if (line.indexOf('[*] Package         : luci-app-xfree-toolbox') !== -1) {
			currentSection = 'luci_check';
		}
		if (currentSection === 'luci_check') {
			m = line.match(/^\[\*\]\s*Available\s*:\s*(.+)$/i);
			if (m && !res.luci.availablePkg) res.luci.availablePkg = m[1].trim();

			m = line.match(/^\[\*\]\s*Upgradable\s*:\s*(yes|no)$/i);
			if (m) {
				if (m[1].toLowerCase() === 'yes') {
					res.luci.update = 'available';
					res.luci.updateLabel = 'есть обновление';
				} else {
					res.luci.update = 'none';
					res.luci.updateLabel = 'актуально';
				}
			}
		}

		// Auto Update
		if (line.indexOf('ENABLED=') === 0) {
			res.autoUpdate.enabled = (line.substring(8).trim() === '1');
		} else if (line.indexOf('MODE=') === 0) {
			var fullMode = line.substring(5).trim();
			res.autoUpdate.mode = fullMode;
			var spaceIdx = fullMode.indexOf(' ');
			res.autoUpdate.modeKey = (spaceIdx !== -1) ? fullMode.substring(0, spaceIdx) : fullMode;
		} else if (line.indexOf('SCHEDULE=') === 0) {
			var sched = line.substring(9).trim();
			res.autoUpdate.schedule = sched;
			var sm = sched.match(/^(\d{1,2}):(\d{2})/);
			if (sm) {
				res.autoUpdate.hour = parseInt(sm[1], 10);
				res.autoUpdate.minute = parseInt(sm[2], 10);
			}
		} else if (line.indexOf('cron=') === 0) {
			res.autoUpdate.cron = line.substring(5).trim();
		} else if (line.indexOf('RUNNING=') === 0) {
			res.autoUpdate.running = (line.substring(8).trim() === '1');
		} else if (line.indexOf('LAST_LOG_LINE=') === 0) {
			res.autoUpdate.lastLogLine = line.substring(14).trim();
		} else if (line.indexOf('LAST_LOG_DATE=') === 0) {
			res.autoUpdate.lastLogDate = line.substring(14).trim();
		}

		var cm = line.match(/^(\d{1,2})\s+(\d{1,2})\s+\*\s+\*\s+\*.*auto-update/);
		if (cm) {
			if (res.autoUpdate.minute == null || isNaN(res.autoUpdate.minute)) {
				res.autoUpdate.minute = parseInt(cm[1], 10);
			}
			if (res.autoUpdate.hour == null || isNaN(res.autoUpdate.hour)) {
				res.autoUpdate.hour = parseInt(cm[2], 10);
			}
		}

		// APK Feed
		if (currentSection === 'apk_feed') {
			m = line.match(/^\[\*\]\s*Фид\s*xfree\s*:\s*(.+)$/i);
			if (m) {
				var statusStr = m[1].trim().toLowerCase();
				res.apkFeed.enabled = (statusStr === 'вкл' || statusStr === 'on' || statusStr === 'enabled' || statusStr === '1');
			}
			m = line.match(/^\[\*\]\s*Источник\s*:\s*(.+)$/i);
			if (m) res.apkFeed.source = m[1].trim();

			m = line.match(/^\[\*\]\s*Зеркало\s*:\s*(.+)$/i);
			if (m) res.apkFeed.mirror = m[1].trim();

			m = line.match(/^\[\*\]\s*URL\s*:\s*(.+)$/i);
			if (m) res.apkFeed.url = m[1].trim();

			m = line.match(/^\[\*\]\s*Доступность\s*GitHub\s*:\s*(.+)$/i);
			if (m) res.apkFeed.githubOk = (m[1].indexOf('доступен') !== -1 && m[1].indexOf('недоступен') === -1);

			m = line.match(/^\[\*\]\s*Доступность\s*Nextcloud\s*:\s*(.+)$/i);
			if (m) res.apkFeed.nextcloudOk = (m[1].indexOf('доступен') !== -1 && m[1].indexOf('недоступен') === -1);
		}
	}

	normalizeUpdateComponent(res.toolbox);
	normalizeUpdateComponent(res.luci);

	if (!res.autoUpdate.modeKey) {
		res.autoUpdate.modeKey = 'upstreams-lists-package';
	}
	if (isNaN(res.autoUpdate.hour) || res.autoUpdate.hour == null) {
		res.autoUpdate.hour = 2;
	}
	if (isNaN(res.autoUpdate.minute) || res.autoUpdate.minute == null) {
		res.autoUpdate.minute = 0;
	}

	return res;
}

return baseclass.extend({
	parseXfreeVersion: parseXfreeVersion,
	cmpXfreeVersion: cmpXfreeVersion,
	normalizeUpdateComponent: normalizeUpdateComponent,
	isUpdateAvailable: isUpdateAvailable,
	isUpdateCurrent: isUpdateCurrent,
	formatNewVersionValue: formatNewVersionValue,
	parseUpdatesReport: parseUpdatesReport
});
