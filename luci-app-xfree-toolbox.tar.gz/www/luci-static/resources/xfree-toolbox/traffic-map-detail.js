'use strict';
'require baseclass';

function nodeKind(id) {
	if (!id) return '';
	var i = String(id).indexOf(':');
	return i > 0 ? id.slice(0, i) : id;
}

function nodeLabel(id, fallback) {
	if (!id) return fallback || '';
	var i = String(id).indexOf(':');
	return i > 0 ? id.slice(i + 1) : id;
}

function runtimeOk(node) {
	return !node || !node.runtime || node.runtime.ok !== false;
}

/* Monitor palette: ok | warn | fail | unknown (from usb-power-watch). */
function nodeHealth(node) {
	var h;

	if (node && node.runtime && node.runtime.health)
		h = String(node.runtime.health);
	else if (node && node.health)
		h = String(node.health);
	else if (node && node.runtime && node.runtime.ok === false)
		h = 'fail';
	else
		h = 'unknown';

	if (h === 'ok' || h === 'warn' || h === 'fail' || h === 'unknown')
		return h;
	return 'unknown';
}

function healthLabel(h) {
	/* Do not gettext "OK" — LuCI maps it to «Принять». */
	if (h === 'ok')
		return 'OK';
	if (h === 'warn')
		return _('частично');
	if (h === 'fail')
		return 'FAIL';
	return _('нет данных');
}

function channelLabel(wan) {
	var c = wan && wan.channel;
	var ev;

	if (c === 'FULL' || c === 'PARTIAL' || c === 'FAIL')
		return c;
	ev = wan && wan.probeEval != null ? String(wan.probeEval) : '';
	if (ev === '0') return 'FULL';
	if (ev === '1') return 'FAIL';
	if (ev === '2') return 'PARTIAL';
	return '';
}

function probeBitOk(v) {
	return v === 1 || v === '1' || v === true || v === 'ok';
}

/* Click-popover rows for VPN tunnel chips (proton / warp / …). */
function tunnelDetailRows(node) {
	var rt = (node && node.runtime) || {};
	var rows;
	var up;
	var ifaceLabel = '—';
	var hs = rt.monitorHs || '';
	var act = rt.monitorAction || '';
	var line = rt.monitorLine || '';

	up = rt.ifaceUp;
	if (up === true || up === 'true')
		ifaceLabel = 'UP';
	else if (up === false || up === 'false')
		ifaceLabel = 'DOWN';

	rows = [
		{ k: _('статус'), v: healthLabel(nodeHealth(node)) }
	];
	if (line) {
		rows.push({ k: _('probe'), v: line });
	} else {
		rows.push({ k: 'probe', v: rt.monitorPing || '—' });
		rows.push({ k: 'hs', v: hs || '—' });
		rows.push({ k: 'last', v: act || rt.monitorLast || '—' });
	}
	if (rt.protonAuth)
		rows.push({ k: 'proton', v: String(rt.protonAuth) });
	if (rt.protonSess)
		rows.push({ k: 'sess', v: String(rt.protonSess) });
	if (rt.certLocal)
		rows.push({ k: 'cert', v: String(rt.certLocal) });
	rows.push({ k: _('iface'), v: ifaceLabel });
	if (rt.vpnDev)
		rows.push({ k: _('dev'), v: String(rt.vpnDev) });
	rows.push({
		k: _('Runtime'),
		v: runtimeOk(node) ? 'ok' : _('нужен apply / iface down')
	});
	if (rt.detail && !line)
		rows.push({ k: _('деталь'), v: String(rt.detail) });
	return rows;
}

/* DNS tip: last dns-check summary (preferred) + optional trace match. */
function dnsCheckHealth(node) {
	var rt = (node && node.runtime) || {};
	var fail;
	var ok;

	if (rt.checkSummary == null && rt.checkOk == null && rt.checkFail == null)
		return null;
	fail = Number(rt.checkFail);
	ok = Number(rt.checkOk);
	if (fail > 0)
		return 'fail';
	if (ok > 0)
		return 'ok';
	return 'unknown';
}

function dnsDetailRows(node, hit, fqdn) {
	var rt = (node && node.runtime) || {};
	var rows;
	var id = nodeLabel(node && node.id, '') || rt.dnsId || '';
	var hosts;
	var hi;
	var h;
	var ok;

	rows = [
		{ k: _('DNS'), v: id || '—' }
	];
	if (rt.checkSummary) {
		rows.push({ k: _('тест'), v: String(rt.checkSummary) });
		if (rt.checkWhen)
			rows.push({ k: _('когда'), v: String(rt.checkWhen) });
	} else {
		rows.push({ k: _('тест'), v: _('нет данных') });
		rows.push({
			k: _('UCI'),
			v: runtimeOk(node) ? 'ok' : (rt.detail || _('https-dns-proxy пуст'))
		});
	}
	/* Per-host dns-check probes — ✓ / ✗ instead of bare "fail". */
	hosts = Array.isArray(rt.checkHosts) ? rt.checkHosts : [];
	for (hi = 0; hi < hosts.length; hi++) {
		h = hosts[hi] || {};
		if (!h.h)
			continue;
		ok = h.ok === true || h.ok === 1 || h.ok === '1';
		rows.push({
			k: String(h.h),
			v: ok ? '✓' : '✗',
			mark: ok ? 'ok' : 'fail',
			hint: h.rcode ? String(h.rcode) + (h.ms != null ? ' · ' + h.ms + 'ms' : '') : ''
		});
	}
	if (fqdn)
		rows.push({ k: _('Домен'), v: fqdn });
	if (hit && hit.listFile)
		rows.push({ k: _('Список'), v: String(hit.listFile) });
	else if (hit && hit.base)
		rows.push({ k: _('map'), v: String(hit.base) });
	return rows;
}

function zapretDetailRows(node, hit, fqdn) {
	var rows = [
		{ k: _('Секция'), v: nodeLabel(node && node.id, '') || '—' },
		{ k: _('Домен'), v: (hit && hit.base) || fqdn || '—' },
		{ k: _('Стратегия'), v: (hit && hit.strategy) || '—' },
		{ k: _('Runtime'), v: runtimeOk(node) ? 'ok' : _('нужен apply') }
	];
	var rt = (node && node.runtime) || {};

	if (rt.detail)
		rows.push({ k: _('деталь'), v: String(rt.detail) });
	return rows;
}

/* Real wizard scopes only — skip synthetic tip ids (dns:default, …). */
function tipNavScope(id) {
	var kind = nodeKind(id);
	var scope = nodeLabel(id, '');

	if (!scope)
		return '';
	if (kind === 'dns' || kind === 'iface' || kind === 'zapret') {
		if (scope === 'default' || scope === 'skipped')
			return '';
		return scope;
	}
	return '';
}

return baseclass.extend({
	nodeKind: nodeKind,
	nodeLabel: nodeLabel,
	runtimeOk: runtimeOk,
	nodeHealth: nodeHealth,
	healthLabel: healthLabel,
	channelLabel: channelLabel,
	probeBitOk: probeBitOk,
	tunnelDetailRows: tunnelDetailRows,
	dnsCheckHealth: dnsCheckHealth,
	dnsDetailRows: dnsDetailRows,
	zapretDetailRows: zapretDetailRows,
	tipNavScope: tipNavScope
});
