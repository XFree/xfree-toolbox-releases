'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.vpn-server-format as serverFormat';

var copyToClipboard = serverFormat.copyToClipboard;

/* Карточка идентичности сервера. Метод вешается на прототип xfree-vpn-server. */

return baseclass.extend({
	_renderServerIdentity: function (awg, view) {
		var self = this;
		var peers = awg.peers || [];
		// Card 1: Server Identity & Settings
		var pubkeyShow = awg.pubkey || '—';
		var epShow = awg.defaultEndpoint || '—';
		var obfsShow = awg.obfuscation || '—';

		var serverParamsRows = [
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Публичный ключ')]),
				E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px; font-family:monospace;' }, [
					E('span', { 'title': pubkeyShow }, [pubkeyShow.length > 28 ? pubkeyShow.slice(0, 14) + '…' + pubkeyShow.slice(-10) : pubkeyShow]),
					pubkeyShow !== '—' ? xcmp.button({
						variant: 'vpn',
						primary: true,
						style: 'padding: 2px 6px; font-size: 11px;',
						title: _('Скопировать публичный ключ'),
						text: _('Копировать'),
						onClick: function (ev) { copyToClipboard(pubkeyShow, ev.target); }
					}) : ''
				])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Default endpoint')]),
				E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
					E('strong', {}, [epShow]),
					xcmp.button({
						variant: 'vpn',
						primary: true,
						style: 'padding: 2px 6px; font-size: 11px;',
						title: _('Изменить endpoint сервера'),
						text: _('Изменить'),
						onClick: function () { self._openChangeEndpointDialog(awg); }
					})
				])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Обфускация')]),
				E('span', { 'style': 'font-family:monospace; font-size: 11px; color: var(--accent);' }, [obfsShow])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Firewall')]),
				E('span', {}, [_('Входящий UDP %s разрешён (WAN → Router)').format(awg.port || '51820')])
			])
		];

		var serverActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					extraClass: 'is-primary',
					text: '⚡ ' + _('Применить сервер'),
					title: _('Применить параметры сервера и обновить список пиров'),
					onClick: ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'serverApply', '', {
							title: _('Применение настроек сервера'),
							message: _('Перезапустить VPN-сервер и применить конфигурацию интерфейса?'),
							detail: _('Сетевой интерфейс awg_ingress будет перезапущен с актуальными ключами, портами и списком клиентов. Существующие соединения кратковременно переподключатся.'),
							confirmText: _('Применить'),
							tone: 'primary',
							icon: '⚡'
						});
					})
				}),
				xui.helpBtn({
					title: _('Применить сервер'),
					desc: _('Применяет текущую конфигурацию интерфейса awg_ingress и синхронизирует пиров.'),
					whatDoes: _('Вызывает скрипт apply-peers.sh, обновляет список доверенных публичных ключей клиентов в ядре и перезапускает интерфейс.'),
					tips: _('Используйте после добавления новых клиентов, изменения обфускации или смены Default Endpoint.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					text: '🛡️ ' + _('Настроить Firewall'),
					title: _('Проверить и настроить правила Firewall для входящего VPN'),
					onClick: ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'serverConfigureFirewall', '', {
							title: _('Настройка Firewall'),
							message: _('Настроить правила межсетевого экрана для VPN-сервера?'),
							detail: _('Будет открыт входящий UDP-порт %s на интерфейсе WAN и разрешён форвардинг трафика между зоной awg_ingress и вашей локальной сетью LAN.').format(awg.port || '51820'),
							confirmText: _('Настроить Firewall'),
							tone: 'primary',
							icon: '🛡️'
						});
					})
				}),
				xui.helpBtn({
					title: _('Настройка Firewall'),
					desc: _('Настраивает правила межсетевого экрана (nftables / firewall4) для безопасного приёма подключений клиентов.'),
					whatDoes: _('Создаёт правило разрешения входящего UDP-порта сервера в зоне WAN и настраивает forwarding между зонами awg_ingress и LAN.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					text: '⚙️ ' + _('Setup сервера'),
					title: _('Выполнить первоначальную настройку сервера'),
					onClick: ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'serverSetup', '', {
							title: _('Первоначальная настройка'),
							message: _('Выполнить первичный Setup входящего VPN-сервера?'),
							detail: _('Скрипт создаст недостающие рабочие каталоги, сгенерирует ключи (если отсутствуют) и подготовит базовые конфигурационные файлы.'),
							confirmText: _('Запустить Setup'),
							tone: 'primary',
							icon: '⚙️'
						});
					})
				}),
				xui.helpBtn({
					title: _('Setup сервера'),
					desc: _('Сценарий первичной инициализации сервера AmneziaWG на роутере.'),
					whatDoes: _('Генерирует файлы /etc/xfree-toolbox/awg-ingress/state/server.key, public.key и настраивает начальное окружение.'),
					tips: _('Полезно при первичной установке или после полного сброса настроек роутера.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group is-danger', 'style': 'margin-left: auto;' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					extraClass: 'is-bad',
					style: 'color: var(--bad); border-color: color-mix(in srgb, var(--bad) 40%, var(--line));',
					text: '⚠️ ' + _('Пересоздать ключи'),
					title: _('Пересоздать приватный и публичный ключи сервера (все клиенты перестанут работать)'),
					onClick: ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'serverRecreateKeys', '', {
							title: _('Пересоздание ключей сервера'),
							message: _('ВНИМАНИЕ! Пересоздать ключи сервера? Все клиенты потеряют доступ!'),
							detail: _('КРИТИЧЕСКАЯ ОПЕРАЦИЯ: Будет сгенерирована абсолютно новая пара ключей сервера. Все подключённые клиенты (%d шт.) перестанут подключаться. Вам потребуется пересоздать и заново импортировать .conf и QR-коды на каждом клиентском устройстве.').format(peers.length),
							confirmText: _('Да, пересоздать ключи'),
							tone: 'danger',
							icon: '⚠️'
						});
					})
				}),
				xui.helpBtn({
					title: _('Пересоздание ключей сервера'),
					desc: _('Генерация новой ключевой пары сервера AmneziaWG.'),
					whatDoes: _('Перезаписывает приватный и публичный ключ сервера в /etc/xfree-toolbox/awg-ingress/state/.'),
					tips: _('Используйте эту операцию ТОЛЬКО при компрометации старых ключей сервера. Все выданные ранее клиентам настройки станут недействительными!')
				})
			])
		]);

		var serverCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('strong', {}, [_('AmneziaWG Server (Ingress)')]),
					xui.helpBtn({
						title: _('Входящий VPN-сервер AmneziaWG'),
						desc: _('Входящий VPN-сервер на базе протокола AmneziaWG (WireGuard с обфускацией пакетов Junk/Init/Response). Позволяет вашим смартфонам, ноутбукам и другим устройствам безопасно подключаться к домашней сети роутера из любой точки мира.'),
						whatDoes: _('Принимает зашифрованный входящий туннельный трафик на порту %s/UDP и направляет его в домашнюю сеть LAN или в интернет через настроенные аплинки.').format(awg.port || '51820'),
						tips: _('Для подключения мобильных устройств используйте приложение AmneziaWG. QR-коды для мгновенной настройки доступны в карточках клиентов ниже.')
					}),
					E('span', { 'class': 'muted' }, [(awg.iface || 'awg_ingress') + ' · ' + (awg.addr || '10.200.200.1/24')])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, [
					xcmp.badge({
						variant: 'vpn-status',
						tone: awg.running ? 'ok' : 'bad',
						text: awg.running ? _('СЕРВЕР АКТИВЕН') : _('ОСТАНОВЛЕН')
					}),
					awg.version ? xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: awg.version }) : ''
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, serverParamsRows),
			serverActions
		]);
		return serverCard;
	}
});
