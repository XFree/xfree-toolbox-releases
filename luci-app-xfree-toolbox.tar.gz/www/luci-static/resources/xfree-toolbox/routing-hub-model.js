'use strict';
'require baseclass';

/* Модель матрицы маршрутизации, выборка колонок и строк списков.
 * Методы вешаются на прототип xfree-routing. */

function cloneChecked(checked) {
	var out = {};
	if (!checked || typeof checked !== 'object')
		return out;
	Object.keys(checked).forEach(function(k) {
		out[k] = Array.isArray(checked[k]) ? checked[k].slice() : [];
	});
	return out;
}

function tagsEqual(a, b) {
	var arrA = Array.isArray(a) ? a : [];
	var arrB = Array.isArray(b) ? b : [];
	if (arrA.length !== arrB.length)
		return false;
	var sa = arrA.slice().sort();
	var sb = arrB.slice().sort();
	for (var i = 0; i < sa.length; i++) {
		if (sa[i] !== sb[i])
			return false;
	}
	return true;
}

return baseclass.extend({
	_cloneChecked: function (checked) {
		return cloneChecked(checked);
	},

	_tagsEqual: function (a, b) {
		return tagsEqual(a, b);
	},

	mount: function (spec) {
		this._spec = spec || {};
		if (spec && spec.hub) {
			this._isExclude = !!spec.hub.isExclude;
		}
		if (spec && spec.activeTarget) {
			this._activeTarget = (spec.activeTarget === 'general' ? 'all' : spec.activeTarget);
		}
		if (spec && spec.hub && spec.hub !== this._lastMountedHub) {
			this._initialChecked = cloneChecked(spec.hub.checked);
			this._lastMountedHub = spec.hub;
		}
		this.requestPaint();
	},

	_xui: function () {
		return (this._spec && this._spec.xui) || null;
	},

	_view: function () {
		return (this._spec && this._spec.view) || null;
	},

	_hub: function () {
		return (this._spec && this._spec.hub) || {};
	},

	_sel: function () {
		return (this._hub() && this._hub().sel) || { view: 'general' };
	},

	_selScope: function () {
		if (this._activeScope !== undefined)
			return this._activeScope;
		var sel = this._sel();
		return (sel && sel.scope) ? sel.scope : '';
	},

	_orderedCols: function (hub) {
		var raw = (hub && hub.columns) ? hub.columns.slice() : [];
		var checkedMap = (hub && hub.checked) || {};
		var targetOrder = { 'iface': 1, 'vpn': 1, 'wan6': 2, 'dns': 3, 'zapret': 4 };
		var selScope = this._selScope();

		raw.sort(function(a, b) {
			/* 1) Group order (VPN -> DNS -> Zapret) to avoid mixing targets */
			var ta = targetOrder[a.target] || 99;
			var tb = targetOrder[b.target] || 99;
			if (ta !== tb)
				return ta - tb;

			/* 1b) Put selected scope (e.g. from tunnel card) first within its group */
			if (selScope) {
				var aScopeMatch = (a.scope === selScope || a.key === selScope || a.key === 'iface:' + selScope || a.key === 'vpn:' + selScope);
				var bScopeMatch = (b.scope === selScope || b.key === selScope || b.key === 'iface:' + selScope || b.key === 'vpn:' + selScope);
				if (aScopeMatch !== bScopeMatch)
					return aScopeMatch ? -1 : 1;
			}

			var aCount = (checkedMap[a.key] || []).length;
			var bCount = (checkedMap[b.key] || []).length;
			var aHas = aCount > 0 ? 1 : 0;
			var bHas = bCount > 0 ? 1 : 0;

			/* 2) Within group: columns with active selections come first */
			if (aHas !== bHas)
				return bHas - aHas;

			/* 3) Within active columns: higher count first */
			if (aHas && aCount !== bCount)
				return bCount - aCount;

			/* 4) Tie-breaker: alphabetical order */
			return String(a.label || a.scope).localeCompare(
				String(b.label || b.scope), undefined, { sensitivity: 'base' });
		});

		return raw;
	},

	_selTarget: function () {
		var spec = this._spec || {};
		var active = this._activeTarget || spec.activeTarget;
		if (active) {
			if (active === 'all' || active === 'general') return 'all';
			if (active === 'vpn' || active === 'iface') return 'vpn';
			if (active === 'dns') return 'dns';
			if (active === 'zapret') return 'zapret';
			if (active === 'exclude') return 'exclude';
		}
		var sel = this._sel();
		if (sel && sel.tab) {
			if (sel.tab === 'vpn' || sel.tab === 'iface') return 'vpn';
			if (sel.tab === 'dns') return 'dns';
			if (sel.tab === 'zapret') return 'zapret';
			if (sel.tab === 'exclude') return 'exclude';
		}
		if (sel && sel.target) {
			if (sel.target === 'iface' || sel.target === 'vpn') return 'vpn';
			if (sel.target === 'dns') return 'dns';
			if (sel.target === 'zapret') return 'zapret';
		}
		if (this._isExclude) return 'exclude';
		return 'all';
	},

	_filteredCols: function (hub) {
		var cols = this._orderedCols(hub);
		var target = this._activeTarget || this._selTarget();

		if (!target || target === 'all' || target === 'general' || target === 'exclude')
			return cols;

		return cols.filter(function(c) {
			if (target === 'vpn' || target === 'iface')
				return c.target === 'iface' || c.target === 'vpn' || c.target === 'wan6';
			if (target === 'dns')
				return c.target === 'dns';
			if (target === 'zapret')
				return c.target === 'zapret';
			return c.target === target;
		});
	},

	_matrixRows: function (hub) {
		var xui = this._xui();
		var cols = this._filteredCols(hub);
		var items = hub.items || [];
		var checkedMap = hub.checked || {};
		var checkedSet = {};
		var rows = [];
		var i;
		var j;
		var col;
		var item;
		var tag;
		var row;
		var any;
		var list;
		var key;

		/* key -> {tag: true} for O(1) lookup */
		for (i = 0; i < cols.length; i++) {
			key = cols[i].key;
			list = checkedMap[key] || [];
			checkedSet[key] = {};
			for (j = 0; j < list.length; j++)
				checkedSet[key][list[j]] = true;
		}

		for (i = 0; i < items.length; i++) {
			item = items[i];
			tag = item.tag || '';
			if (!tag)
				continue;
			row = {
				tag: tag,
				item: item,
				available: {},
				checked: {},
				anyChecked: false
			};
			any = false;
			for (j = 0; j < cols.length; j++) {
				col = cols[j];
				/* DNS and WAN6 columns: only fqdn-capable lists */
				if (col.target === 'dns' || col.target === 'wan6' || col.mode === 'fqdn_only') {
					row.available[col.key] = !!(item.has_fqdn ||
						item.kind === 'fqdn' || item.kind === 'fqdn+prefix');
				} else {
					row.available[col.key] = true;
				}
				row.checked[col.key] = !!(checkedSet[col.key] && checkedSet[col.key][tag]);
				if (row.checked[col.key])
					any = true;
			}
			row.anyChecked = any;
			rows.push(row);
		}

		var sourceOrder = { 'user': 1, 'allow-domains': 2, 'rekryt-iplist': 3, 'vpn': 4 };

		rows.sort(function(a, b) {
			/* 1) Checked items first, unchecked last */
			if (a.anyChecked !== b.anyChecked)
				return a.anyChecked ? -1 : 1;

			/* 2) Group by upstream (source) within checked/unchecked */
			var sa = sourceOrder[a.item.source] || 99;
			var sb = sourceOrder[b.item.source] || 99;
			if (sa !== sb)
				return sa - sb;
			var sc = String(a.item.source || '').localeCompare(
				String(b.item.source || ''), undefined, { sensitivity: 'base' });
			if (sc !== 0)
				return sc;

			/* 3) Alphabetical by item title within the same upstream */
			var tc = String(xui.listItemTitle(a.item)).localeCompare(
				String(xui.listItemTitle(b.item)), undefined, { sensitivity: 'base' });
			if (tc !== 0)
				return tc;

			/* 4) Tie-breaker: tag */
			return String(a.tag).localeCompare(String(b.tag));
		});

		return rows;
	}
});
