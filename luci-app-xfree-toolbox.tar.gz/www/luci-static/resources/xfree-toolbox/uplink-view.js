'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';

/* Жизненный цикл состояния, чипы статуса, действия и render экрана uplink.
 * Методы вешаются на прототип xfree-uplink. */

return baseclass.extend({
	mount: function (spec) {
		this._spec = spec || {};
		this._settings = (spec && spec.settings) || {};
		this._runtime = (spec && spec.runtime) || {};
		this._output = (spec && spec.outputText) || '';
		this._busy = !!(spec && spec.busy);
		this._loading = !!(spec && spec.loading);
		this._msg = (spec && spec.message) || '';
		this.requestPaint();
	},

	setLoading: function (loading) {
		this._loading = !!loading;
		if (this._spec)
			this._spec.loading = this._loading;
		this.requestPaint();
	},

	setConfig: function (settings, runtime) {
		this._settings = settings || {};
		this._runtime = runtime || {};
		this._loading = false;
		if (this._spec)
			this._spec.loading = false;
		this.requestPaint();
	},

	setOutputText: function (text) {
		this._output = text || '';
		var el = this.querySelector('xfree-console.xfree-uplink-log');

		if (el)
			el.text = this._output;
		else
			this.requestPaint();
	},

	setBusy: function (busy) {
		this._busy = !!busy;
		this.querySelectorAll('button, input, select').forEach(function(el) {
			if (el.getAttribute('data-keep-enabled') === '1')
				return;
			el.disabled = !!busy;
		});
	},

	setMessage: function (text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var el = this.querySelector('[data-xfree-uplink-msg]');

		if (el) {
			el.textContent = this._msg;
			el.className = 'xfree-uplink-msg' + (this._msgTone ? ' is-' + this._msgTone : '');
		}
	},

	render: function () {
		var s = this._spec || {};
		var view = s.view;
		var expert = !!(s.expert);
		var settings = this._settings || {};
		var runtime = this._runtime || {};
		var onSave = s.onSave;
		var onAction = s.onAction;
		var onRefresh = s.onRefresh;
		var tone = this._evalTone(runtime);
		var tunnels = this._parseTunnelLines(runtime.tunnels_text);
		var groups = [];
		var actions = [];
		var chips = [];
		var tunnelChips = [];
		var i;
		var consoleEl;
		var evalLabel = runtime.last_probe_eval_label || runtime.last_probe_eval || '—';

		this.className = 'xfree-uplink-root';
		this.setAttribute('data-xfree-uplink', '1');

		var isLoading = !!(s.loading);
		var cronOn = runtime.cron === 1 || runtime.cron === '1';
		if (isLoading && (!runtime || !runtime.last_probe_eval)) {
			chips.push(xcmp.chip({ label: _('Канал'), loading: true }));
			chips.push(xcmp.chip({ label: _('Cron'), loading: true }));
			chips.push(xcmp.chip({ label: _('FAIL'), loading: true }));
			chips.push(xcmp.chip({ label: _('Последний тик'), loading: true }));
			chips.push(xcmp.chip({ label: _('Probe'), loading: true }));
			chips.push(xcmp.chip({ label: _('DNS'), loading: true }));
		} else {
			chips.push(xcmp.chip({
				label: _('Канал'),
				value: String(evalLabel).toUpperCase(),
				tone: tone
			}));
			chips.push(xcmp.chip({
				label: _('Cron'),
				value: cronOn
					? _('каждые %s мин').format(settings.INTERVAL_MIN || '—')
					: _('нет'),
				tone: cronOn ? 'ok' : ''
			}));
			chips.push(xcmp.chip({
				label: _('FAIL'),
				value: '%s / %s'.format(runtime.fail_count || '0', settings.FAIL_MAX || '—')
			}));
			chips.push(xcmp.chip({
				label: _('Последний тик'),
				value: runtime.last_tick || '—'
			}));
			chips.push(xcmp.chip({
				label: _('Probe'),
				value: runtime.probe_iface_label || settings.PROBE_IFACE || '—'
			}));

			var dnsTone = 'muted';
			var dnsText = '—';
			var dnsSummary = runtime.dns_probe_summary ? String(runtime.dns_probe_summary) : '';
			if (runtime.dns_probe_status === 'ok' || runtime.last_dns_probe === '1') {
				dnsTone = 'ok';
				dnsText = dnsSummary || 'OK';
			} else if (runtime.dns_probe_status === 'fail' || runtime.last_dns_probe === '0') {
				dnsTone = 'bad';
				dnsText = dnsSummary || 'FAIL';
			} else if (runtime.dns_probe_status === 'off' || settings.DNS_PROBE_ENABLED === '0') {
				dnsTone = 'muted';
				dnsText = _('ВЫКЛ');
			}

			chips.push(xcmp.chip({
				label: _('DNS'),
				value: dnsText,
				tone: dnsTone,
				title: dnsSummary || dnsText
			}));
		}

		if (isLoading && !tunnels.length) {
			tunnelChips.push(this._renderTunnelSkeleton());
			tunnelChips.push(this._renderTunnelSkeleton());
		} else {
			for (i = 0; i < tunnels.length; i++) {
				tunnelChips.push(this._renderTunnelCard(tunnels[i]));
			}
		}

		groups = this._renderFieldGroups(expert, settings);

		actions = [
			E('button', {
				'class': 'btn',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onSave)
						onSave();
				})
			}, [ _('Сохранить настройки') ]),
			E('button', {
				'class': 'ghost' + ((this._loading || this._busy) ? ' is-loading' : ''),
				'type': 'button',
				'disabled': (this._loading || this._busy) ? true : null,
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onRefresh)
						onRefresh();
				})
			}, [
				E('span', { 'class': (this._loading || this._busy) ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + ((this._loading || this._busy) ? _('Обновление…') : _('Обновить статус'))
			]),
			E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('probe', null, _('Запустить полный тик проверки канала?'));
				})
			}, [ _('Проверить сейчас') ]),
			E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('tunnelsCheck', null, _('Запустить полную проверку iface-routing (Handshake, probe, curl, nftables)?'));
				})
			}, [ '🩺 ' + _('Глубокая проверка туннелей') ]),
			E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('cronOn', null, _('Установить cron и ENABLED=1?'));
				})
			}, [ _('Вкл. cron') ]),
			E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('cronOff', null, _('Снять cron usb-power-watch?'));
				})
			}, [ _('Выкл. cron') ])
		];

		if (expert) {
			actions.push(E('button', {
				'class': 'ghost',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onAction)
						onAction('usbCycle', null, _('USB power-cycle — модем пропадёт на время OFF. Продолжить?'));
				})
			}, [ _('USB cycle') ]));
		}

		consoleEl = E('xfree-console', {
			'label': _('Журнал действия'),
			'class': 'xfree-uplink-log',
			style: '--xfree-console-max-height:28vh'
		});
		consoleEl.text = this._output || '';

		var dnsCards = [];
		var dnsHosts = Array.isArray(runtime.dns_hosts) ? runtime.dns_hosts : [];
		for (i = 0; i < dnsHosts.length; i++) {
			dnsCards.push(this._renderDnsHostCard(dnsHosts[i]));
		}

		this.replaceChildren(
			E('div', { 'class': 'xfree-uplink-head' }, [
				E('div', {}, [
					E('h3', {}, [ _('Мониторинг канала') ]),
					E('p', { 'class': 'muted' }, [
						_('Параметры usb-power-watch и живой статус. Сохранение пишет conf на роутере.')
					])
				]),
				E('p', {
					'class': 'xfree-uplink-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
					'data-xfree-uplink-msg': '1'
				}, [ this._msg || '' ])
			]),
			E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips),
			tunnelChips.length
				? E('div', { 'class': 'xfree-uplink-tunnels' }, tunnelChips)
				: E('p', { 'class': 'muted' }, [ _('Нет данных probe туннелей') ]),
			dnsCards.length
				? E('div', { 'class': 'xfree-uplink-tunnels' }, dnsCards)
				: '',
			E('div', { 'class': 'xfree-uplink-meta muted' }, [
				runtime.power_cycle_label
					? _('USB: %s').format(runtime.power_cycle_label)
					: '',
				runtime.conf_path
					? E('span', {}, [ ' · ', runtime.conf_path ])
					: ''
			]),
			E('div', { 'class': 'xfree-uplink-groups' }, groups),
			E('div', { 'class': 'xfree-uplink-actions' }, actions),
			consoleEl
		);

		if (this._busy) {
			this.querySelectorAll('button, input, select').forEach(function(el) {
				if (el.getAttribute('data-keep-enabled') === '1')
					return;
				el.disabled = true;
			});
		}
	}
});
