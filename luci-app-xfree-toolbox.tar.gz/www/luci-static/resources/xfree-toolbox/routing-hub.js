'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.routing-hub-model as routingModel';
'require xfree-toolbox.routing-hub-actions as routingActions';
'require xfree-toolbox.routing-hub-matrix as routingMatrix';
'require xfree-toolbox.routing-hub-view as routingView';

/* Экран общей матрицы маршрутизации (VPN / DNS / Zapret / Исключения).
 * Модель, действия сохранения, матрица и отрисовка живут в соседних модулях
 * и вешаются на один прототип тега xfree-routing. */

var TAG = 'xfree-routing';

var RoutingHub = class extends wc.LightElement {
};

function mixRouting(part) {
	prototypeMix.mixInto(RoutingHub.prototype, part);
}

mixRouting(routingModel);
mixRouting(routingActions);
mixRouting(routingMatrix);
mixRouting(routingView);

wc.define(TAG, RoutingHub);

return baseclass.extend({
	tag: TAG
});
