'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-routing';

function kindLabel(target) {
	switch (target) {
	case 'dns':
		return _('DNS');
	case 'zapret':
		return _('Zapret');
	default:
		return _('VPN');
	}
}

function _tabForTarget(target) {
	return target === 'iface' ? 'vpn' : target;
}

function _modeForTarget(target) {
	return target === 'dns' ? 'fqdn_only' : 'all';
}

function cloneChecked(checked) {
	var out = {};
	if (!checked || typeof checked !== 'object')
		return out;
	Object.keys(checked).forEach(function(k) {
		out[k] = Array.isArray(checked[k]) ? checked[k].slice() : [];
	});
	return out;
}

function tagsEqual(a, b) {
	var arrA = Array.isArray(a) ? a : [];
	var arrB = Array.isArray(b) ? b : [];
	if (arrA.length !== arrB.length)
		return false;
	var sa = arrA.slice().sort();
	var sb = arrB.slice().sort();
	for (var i = 0; i < sa.length; i++) {
		if (sa[i] !== sb[i])
			return false;
	}
	return true;
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		if (spec && spec.hub) {
			this._isExclude = !!spec.hub.isExclude;
		}
		if (spec && spec.activeTarget) {
			this._activeTarget = (spec.activeTarget === 'general' ? 'all' : spec.activeTarget);
		}
		if (spec && spec.hub && spec.hub !== this._lastMountedHub) {
			this._initialChecked = cloneChecked(spec.hub.checked);
			this._lastMountedHub = spec.hub;
		}
		this.requestPaint();
	}

	_xui() {
		return (this._spec && this._spec.xui) || null;
	}

	_view() {
		return (this._spec && this._spec.view) || null;
	}

	_hub() {
		return (this._spec && this._spec.hub) || {};
	}

	_sel() {
		return (this._hub() && this._hub().sel) || { view: 'general' };
	}

	_selScope() {
		if (this._activeScope !== undefined)
			return this._activeScope;
		var sel = this._sel();
		return (sel && sel.scope) ? sel.scope : '';
	}

	_orderedCols(hub) {
		var raw = (hub && hub.columns) ? hub.columns.slice() : [];
		var checkedMap = (hub && hub.checked) || {};
		var targetOrder = { 'iface': 1, 'vpn': 1, 'dns': 2, 'zapret': 3 };
		var selScope = this._selScope();

		raw.sort(function(a, b) {
			/* 1) Group order (VPN -> DNS -> Zapret) to avoid mixing targets */
			var ta = targetOrder[a.target] || 99;
			var tb = targetOrder[b.target] || 99;
			if (ta !== tb)
				return ta - tb;

			/* 1b) Put selected scope (e.g. from tunnel card) first within its group */
			if (selScope) {
				var aScopeMatch = (a.scope === selScope || a.key === selScope || a.key === 'iface:' + selScope || a.key === 'vpn:' + selScope);
				var bScopeMatch = (b.scope === selScope || b.key === selScope || b.key === 'iface:' + selScope || b.key === 'vpn:' + selScope);
				if (aScopeMatch !== bScopeMatch)
					return aScopeMatch ? -1 : 1;
			}

			var aCount = (checkedMap[a.key] || []).length;
			var bCount = (checkedMap[b.key] || []).length;
			var aHas = aCount > 0 ? 1 : 0;
			var bHas = bCount > 0 ? 1 : 0;

			/* 2) Within group: columns with active selections come first */
			if (aHas !== bHas)
				return bHas - aHas;

			/* 3) Within active columns: higher count first */
			if (aHas && aCount !== bCount)
				return bCount - aCount;

			/* 4) Tie-breaker: alphabetical order */
			return String(a.label || a.scope).localeCompare(
				String(b.label || b.scope), undefined, { sensitivity: 'base' });
		});

		return raw;
	}

	_selTarget() {
		var spec = this._spec || {};
		var active = this._activeTarget || spec.activeTarget;
		if (active) {
			if (active === 'all' || active === 'general') return 'all';
			if (active === 'vpn' || active === 'iface') return 'vpn';
			if (active === 'dns') return 'dns';
			if (active === 'zapret') return 'zapret';
			if (active === 'exclude') return 'exclude';
		}
		var sel = this._sel();
		if (sel && sel.tab) {
			if (sel.tab === 'vpn' || sel.tab === 'iface') return 'vpn';
			if (sel.tab === 'dns') return 'dns';
			if (sel.tab === 'zapret') return 'zapret';
			if (sel.tab === 'exclude') return 'exclude';
		}
		if (sel && sel.target) {
			if (sel.target === 'iface' || sel.target === 'vpn') return 'vpn';
			if (sel.target === 'dns') return 'dns';
			if (sel.target === 'zapret') return 'zapret';
		}
		if (this._isExclude) return 'exclude';
		return 'all';
	}

	_filteredCols(hub) {
		var cols = this._orderedCols(hub);
		var target = this._activeTarget || this._selTarget();

		if (!target || target === 'all' || target === 'general' || target === 'exclude')
			return cols;

		return cols.filter(function(c) {
			if (target === 'vpn' || target === 'iface')
				return c.target === 'iface' || c.target === 'vpn';
			if (target === 'dns')
				return c.target === 'dns';
			if (target === 'zapret')
				return c.target === 'zapret';
			return c.target === target;
		});
	}

	_chipNav() {
		var self = this;
		var xui = this._xui();
		var view = this._view();
		var activeTarget = this._activeTarget || this._selTarget();
		var buttons = [];

		var tabs = [
			{ id: 'all', title: _('Общее') },
			{ id: 'vpn', title: _('VPN') },
			{ id: 'dns', title: _('DNS') },
			{ id: 'zapret', title: _('Zapret') },
			{ id: 'exclude', title: _('Исключения') }
		];

		tabs.forEach(function(t) {
			var isActive = activeTarget === t.id ||
				(t.id === 'all' && (!activeTarget || activeTarget === 'general' || activeTarget === 'all'));

			buttons.push(E('button', {
				'type': 'button',
				'class': 'subnav-btn' + (isActive ? ' is-active' : ''),
				'click': function(ev) {
					if (ev) ev.preventDefault();
					if (t.id === 'exclude') {
						self._activeTarget = 'exclude';
						self._activeScope = '';
						self._isExclude = true;
						self._setStatus(_('Загрузка матрицы исключений…'));
						xui.loadRoutingHub(view, { view: 'exclude', tab: 'exclude' }, true).then(function(nextHub) {
							self._spec.hub = nextHub;
							self._initialChecked = cloneChecked(nextHub.checked);
							self.requestPaint();
							view.navigate('routing', 'exclude', '');
						});
					} else {
						self._activeTarget = t.id;
						self._activeScope = '';
						if (self._isExclude) {
							self._isExclude = false;
							self._setStatus(_('Загрузка общих списков…'));
							xui.loadRoutingHub(view, { view: 'general', tab: t.id }, false).then(function(nextHub) {
								self._spec.hub = nextHub;
								self._initialChecked = cloneChecked(nextHub.checked);
								self.requestPaint();
								view.navigate('routing', t.id === 'all' ? 'general' : t.id, '');
							});
						} else {
							self.requestPaint();
							view.navigate('routing', t.id === 'all' ? 'general' : t.id, '');
						}
					}
				}
			}, [ t.title ]));
		});

		return E('nav', {
			'class': 'subnav xfree-routing-chips',
			'aria-label': _('Цели маршрутизации')
		}, buttons);
	}

	_matrixRows(hub) {
		var xui = this._xui();
		var cols = this._filteredCols(hub);
		var items = hub.items || [];
		var checkedMap = hub.checked || {};
		var checkedSet = {};
		var rows = [];
		var i;
		var j;
		var col;
		var item;
		var tag;
		var row;
		var any;
		var list;
		var key;

		/* key -> {tag: true} for O(1) lookup */
		for (i = 0; i < cols.length; i++) {
			key = cols[i].key;
			list = checkedMap[key] || [];
			checkedSet[key] = {};
			for (j = 0; j < list.length; j++)
				checkedSet[key][list[j]] = true;
		}

		for (i = 0; i < items.length; i++) {
			item = items[i];
			tag = item.tag || '';
			if (!tag)
				continue;
			row = {
				tag: tag,
				item: item,
				available: {},
				checked: {},
				anyChecked: false
			};
			any = false;
			for (j = 0; j < cols.length; j++) {
				col = cols[j];
				/* DNS columns: only fqdn-capable lists */
				if (col.target === 'dns' || col.mode === 'fqdn_only') {
					row.available[col.key] = !!(item.has_fqdn ||
						item.kind === 'fqdn' || item.kind === 'fqdn+prefix');
				} else {
					row.available[col.key] = true;
				}
				row.checked[col.key] = !!(checkedSet[col.key] && checkedSet[col.key][tag]);
				if (row.checked[col.key])
					any = true;
			}
			row.anyChecked = any;
			rows.push(row);
		}

		var sourceOrder = { 'user': 1, 'allow-domains': 2, 'rekryt-iplist': 3, 'vpn': 4 };

		rows.sort(function(a, b) {
			/* 1) Checked items first, unchecked last */
			if (a.anyChecked !== b.anyChecked)
				return a.anyChecked ? -1 : 1;

			/* 2) Group by upstream (source) within checked/unchecked */
			var sa = sourceOrder[a.item.source] || 99;
			var sb = sourceOrder[b.item.source] || 99;
			if (sa !== sb)
				return sa - sb;
			var sc = String(a.item.source || '').localeCompare(
				String(b.item.source || ''), undefined, { sensitivity: 'base' });
			if (sc !== 0)
				return sc;

			/* 3) Alphabetical by item title within the same upstream */
			var tc = String(xui.listItemTitle(a.item)).localeCompare(
				String(xui.listItemTitle(b.item)), undefined, { sensitivity: 'base' });
			if (tc !== 0)
				return tc;

			/* 4) Tie-breaker: tag */
			return String(a.tag).localeCompare(String(b.tag));
		});

		return rows;
	}

	_matrixDescr(target) {
		if (target === 'exclude')
			return _('Исключения: списки, исключаемые из туннелей VPN (fqdn.exclude.d) и секций Zapret.');
		if (target === 'vpn' || target === 'iface')
			return _('VPN: одна строка — список; колонки — туннели. Выбранные сверху.');
		if (target === 'zapret')
			return _('Zapret: одна строка — список; колонки — активные секции Zapret. Выбранные сверху.');
		if (target === 'dns')
			return _('DNS: одна строка — список; колонки — DNS-серверы. Выбранные сверху.');
		return _('Общее: одна строка — список; колонки — куда он может попасть (VPN / DNS / секция Zapret). Выбранные сверху.');
	}

	_renderMatrix() {
		var self = this;
		var xui = this._xui();
		var view = this._view();
		var hub = this._hub();
		var cols = this._filteredCols(hub);
		var checkedMap = hub.checked || {};
		var rows = this._matrixRows(hub);
		var head = [ E('th', { 'class': 'th xfree-routing-matrix-name' }, [ _('Имя') ]) ];
		var body = [];
		var pane;
		var i;
		var r;
		var title;
		var meta;

		if (hub.loading) {
			var skeletonRows = [];
			var si;
			for (si = 0; si < 6; si++) {
				skeletonRows.push(E('div', { 'class': 'xfree-skeleton-matrix-row' }, [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: ' + (100 + (si % 3) * 40) + 'px; height: 14px;' }),
					E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 48px; height: 16px; margin-left: auto;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 20px; height: 16px; border-radius: 4px;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 20px; height: 16px; border-radius: 4px;' })
				]));
			}

			return E('div', {
				'class': 'cbi-section-node xfree-wizard-pane xfree-routing-matrix-pane',
				'data-xfree-routing-matrix': '1'
			}, [
				E('div', { 'class': 'cbi-section-descr xfree-wizard-pane-head' }, [
					E('div', {}, [ self._matrixDescr(self._activeTarget || self._selTarget()) ]),
					E('div', { 'class': 'cbi-value xfree-list-filter-bar' }, [
						E('div', { 'class': 'xfree-list-filter-wrap' }, [
							E('input', {
								'type': 'search',
								'class': 'cbi-input-text xfree-list-filter',
								'placeholder': _('Найти сервис, группу или источник…'),
								'disabled': true
							})
						])
					]),
					E('div', {
						'class': 'cbi-value-description',
						'data-xfree-list-count': '1'
					}, [
						E('span', { 'class': 'spinning' }, [ _('Загрузка списков…') ])
					])
				]),
				E('div', { 'class': 'xfree-wizard-pane-scroll xfree-routing-matrix-scroll' }, [
					E('div', { 'class': 'xfree-matrix-skeleton' }, skeletonRows)
				])
			]);
		}

		if (!cols.length) {
			return E('div', { 'class': 'cbi-section-descr' }, [
				_('Нет VPN / DNS / секций Zapret для выбора списков.')
			]);
		}

		var selScope = this._selScope();

		for (i = 0; i < cols.length; i++) {
			var colCount = (checkedMap[cols[i].key] || []).length;
			var emptyColClass = colCount === 0 ? ' is-empty-col' : '';
			var isSelectedCol = selScope && (cols[i].scope === selScope || cols[i].key === selScope || cols[i].key === 'iface:' + selScope || cols[i].key === 'vpn:' + selScope);
			var selColClass = isSelectedCol ? ' is-selected-col' : '';

			head.push(E('th', {
				'class': 'th xfree-routing-matrix-col is-' + cols[i].target + emptyColClass + selColClass,
				'title': kindLabel(cols[i].target) + ' · ' + (cols[i].label || cols[i].scope) +
					(colCount > 0 ? ' (' + colCount + ')' : '')
			}, [
				E('span', { 'class': 'xfree-routing-matrix-kind' }, [ kindLabel(cols[i].target) ]),
				E('span', { 'class': 'xfree-routing-matrix-scope' }, [ cols[i].label || cols[i].scope ])
			]));
		}

		for (i = 0; i < rows.length; i++) {
			r = rows[i];
			title = xui.listItemTitle(r.item);
			meta = xui.listItemMeta(r.item);
			(function(rowTag, rowTitle, rowItem, rowChecked, rowAvailable, rowAnyChecked) {
				var rowCells = [
					E('td', { 'class': 'td xfree-routing-matrix-name' }, [
						E('div', { 'class': 'xfree-list-tile-title' }, [
							E('a', {
								'href': '#',
								'class': 'xfree-list-tile-name is-clickable',
								'title': _('Просмотреть содержимое списка'),
								'style': 'cursor: pointer; text-decoration: underline dotted; font-weight: 500;',
								'click': function(ev) {
									ev.preventDefault();
									xui.showListDialog(rowTag, rowTitle);
								}
							}, [ rowTitle ]),
							E('button', {
								'type': 'button',
								'class': 'cbi-button cbi-button-neutral xfree-list-view-btn',
								'title': _('Просмотреть список'),
								'style': 'margin-left: 6px; padding: 1px 5px; font-size: 11px; vertical-align: middle; line-height: 1.2;',
								'click': function(ev) {
									ev.preventDefault();
									xui.showListDialog(rowTag, rowTitle);
								}
							}, [ '👁️' ]),
							rowItem.source ? E('span', {
								'class': 'xfree-matrix-source-badge',
								'title': _('Источник (upstream): ') + rowItem.source
							}, [ rowItem.source ]) : ''
						]),
						meta ? E('div', { 'class': 'cbi-value-description' }, [ meta ]) : ''
					])
				];
				cols.forEach(function(col) {
					var avail = !!rowAvailable[col.key];
					var checked = !!rowChecked[col.key];
					var isSelectedCol = selScope && (col.scope === selScope || col.key === selScope || col.key === 'iface:' + selScope || col.key === 'vpn:' + selScope);
					var selTdClass = isSelectedCol ? ' is-selected-col' : '';
					var inputId = 'xfree-mx-' + col.key + '-' +
						String(rowTag).replace(/[^a-zA-Z0-9_-]/g, '_');

					rowCells.push(E('td', {
						'class': 'td xfree-routing-matrix-cb is-' + col.target +
							(avail ? '' : ' is-na') + selTdClass
					}, [
						avail
							? E('input', {
								'type': 'checkbox',
								'id': inputId,
								'data-matrix-tag': rowTag,
								'data-matrix-col': col.key,
								'data-matrix-target': col.target,
								'data-matrix-scope': col.scope,
								'checked': checked ? true : null,
								'click': function(ev) {
									var isChk = ev.target.checked;
									var t = ev.target.getAttribute('data-matrix-tag') || rowTag;
									var h = self._hub();
									if (!h.checked) h.checked = {};
									if (!h.checked[col.key]) h.checked[col.key] = [];
									var arr = h.checked[col.key];
									var idx = arr.indexOf(t);
									if (isChk && idx === -1) arr.push(t);
									else if (!isChk && idx !== -1) arr.splice(idx, 1);

									// Если включаем туннель VPN (target === 'iface' или 'vpn'),
									// автоматически снимаем отметку с других туннелей VPN в этой строке
									if (isChk && (col.target === 'iface' || col.target === 'vpn')) {
										var tr = ev.target.closest('tr');
										if (tr) {
											tr.querySelectorAll('input[data-matrix-tag]').forEach(function(otherInput) {
												if (otherInput === ev.target) return;
												var oTgt = otherInput.getAttribute('data-matrix-target');
												if (oTgt === 'iface' || oTgt === 'vpn') {
													if (otherInput.checked) {
														otherInput.checked = false;
														var oKey = otherInput.getAttribute('data-matrix-col');
														if (oKey && h.checked[oKey]) {
															var oIdx = h.checked[oKey].indexOf(t);
															if (oIdx !== -1) h.checked[oKey].splice(oIdx, 1);
														}
													}
												}
											});
										}
									}
								}
							})
							: E('span', {
								'class': 'xfree-routing-matrix-na',
								'title': _('Список недоступен для этой цели')
							}, [ '—' ])
					]));
				});
				body.push(E('tr', {
					'class': 'tr' + (rowAnyChecked ? ' is-selected-row' : ''),
					'data-xfree-list-row': '1',
					'data-xfree-haystack': xui.listItemHaystack(rowItem)
				}, rowCells));
			})(r.tag, title, r.item, r.checked, r.available, r.anyChecked);
		}

		pane = E('div', {
			'class': 'cbi-section-node xfree-wizard-pane xfree-routing-matrix-pane',
			'data-xfree-routing-matrix': '1'
		}, [
			E('div', { 'class': 'cbi-section-descr xfree-wizard-pane-head' }, [
				E('div', {}, [
					self._matrixDescr(self._activeTarget || self._selTarget())
				]),
				E('div', { 'class': 'cbi-value xfree-list-filter-bar' }, [
					E('div', { 'class': 'xfree-list-filter-wrap' }, [
						E('input', {
							'type': 'search',
							'class': 'cbi-input-text xfree-list-filter',
							'placeholder': _('Найти сервис, группу или источник…'),
							'data-xfree-list-filter': '1'
						})
					])
				]),
				E('div', {
					'class': 'cbi-value-description',
					'data-xfree-list-count': '1'
				}, [ '' ])
			]),
			E('div', { 'class': 'xfree-wizard-pane-scroll xfree-routing-matrix-scroll' }, [
				E('table', { 'class': 'table cbi-section-table xfree-routing-matrix' }, [
					E('thead', {}, [ E('tr', { 'class': 'tr' }, head) ]),
					E('tbody', {}, body)
				])
			]),
			E('div', { 'class': 'xfree-wizard-pane-footer' }, [
				E('div', { 'class': 'cbi-page-actions right' }, [
					E('button', {
						'class': 'cbi-button cbi-button-save',
						'click': ui.createHandlerFn(view, function() {
							self._saveMatrix();
						})
					}, [ _('Сохранить выбор') ]),
					E('button', {
						'class': 'cbi-button cbi-button-apply important',
						'click': ui.createHandlerFn(view, function() {
							self._applyMatrix();
						})
					}, [ _('Применить') ])
				]),
				E('div', {
					'class': 'cbi-section-descr xfree-wizard-status',
					'data-routing-status': '1'
				}, [ hub.statusText || '' ])
			])
		]);

		requestAnimationFrame(function() {
			xui.bindListPickerFilter(pane);
			self._bindMatrixResort(pane);
		});

		return pane;
	}

	_bindMatrixResort(pane) {
		var tbody;

		if (!pane || pane.getAttribute('data-xfree-matrix-bound') === 'true')
			return;

		tbody = pane.querySelector('tbody');
		if (!tbody)
			return;

		pane.querySelectorAll('input[data-matrix-tag]').forEach(function(cb) {
			cb.addEventListener('change', function() {
				var row = cb.closest('tr');
				var any = false;

				if (!row)
					return;
				row.querySelectorAll('input[data-matrix-tag]').forEach(function(el) {
					if (el.checked)
						any = true;
				});
				if (any)
					row.classList.add('is-selected-row');
				else
					row.classList.remove('is-selected-row');
			});
		});

		pane.setAttribute('data-xfree-matrix-bound', 'true');
	}

	_syncDomChecked() {
		var hub = this._hub();
		if (!hub.checked)
			hub.checked = {};

		var visibleCols = this._filteredCols(hub);
		var domChecked = {};
		for (var i = 0; i < visibleCols.length; i++)
			domChecked[visibleCols[i].key] = [];

		this.querySelectorAll('input[data-matrix-tag]').forEach(function(el) {
			var key = el.getAttribute('data-matrix-col') || '';
			var tag = el.getAttribute('data-matrix-tag') || '';
			if (!key || !tag || !el.checked)
				return;
			if (domChecked[key])
				domChecked[key].push(tag);
		});

		for (var j = 0; j < visibleCols.length; j++) {
			var k = visibleCols[j].key;
			if (domChecked[k])
				hub.checked[k] = domChecked[k];
		}
	}

	_collectMatrixByColumn() {
		this._syncDomChecked();
		var hub = this._hub();
		var cols = this._filteredCols(hub);
		var map = {};
		var i;

		for (i = 0; i < cols.length; i++) {
			var k = cols[i].key;
			map[k] = { col: cols[i], tags: (hub.checked && hub.checked[k]) || [] };
		}

		return map;
	}

	_detectColumnChanges() {
		this._syncDomChecked();
		var self = this;
		var hub = this._hub();
		var allCols = (hub && hub.columns) || [];
		var curChecked = (hub && hub.checked) || {};
		var initial = self._initialChecked || {};
		var changedKeys = [];
		var changedTargets = {
			iface: false,
			dns: false,
			zapret: false
		};
		var colMap = {};

		allCols.forEach(function(col) {
			colMap[col.key] = col;
			var curTags = curChecked[col.key] || [];
			var initTags = initial[col.key] || [];
			if (!tagsEqual(initTags, curTags)) {
				changedKeys.push(col.key);
				var tgt = col.target;
				if (tgt === 'vpn') tgt = 'iface';
				if (changedTargets[tgt] !== undefined)
					changedTargets[tgt] = true;
			}
		});

		return {
			changedKeys: changedKeys,
			changedTargets: changedTargets,
			hasRouting: changedTargets.iface || changedTargets.dns,
			hasZapret: changedTargets.zapret,
			colMap: colMap
		};
	}

	_setStatus(text) {
		var hub = this._hub();
		var el = this.querySelector('[data-routing-status]');

		hub.statusText = text || '';
		if (el)
			el.textContent = hub.statusText;
	}

	_persistMatrix(keysToSave) {
		var self = this;
		var xui = this._xui();
		var hub = this._hub();
		var allCols = (hub && hub.columns) || [];
		var curChecked = (hub && hub.checked) || {};
		var colMap = {};
		allCols.forEach(function(c) { colMap[c.key] = c; });

		this._syncDomChecked();

		var keys = Array.isArray(keysToSave) && keysToSave.length > 0 ? keysToSave : Object.keys(colMap);
		var chain = Promise.resolve();
		var n = 0;

		this._setStatus(_('Сохранение…'));

		keys.forEach(function(key) {
			var col = colMap[key];
			if (!col) return;
			var tags = curChecked[key] || [];

			chain = chain.then(function() {
				n++;
				self._setStatus(_('Сохранение %s/%s: %s…').format(
					n, keys.length, col.label || col.scope));
				return xui.saveUpstreamTags(col.target, col.scope, col.mode, tags);
			});
		});

		return chain;
	}

	_reloadGeneral() {
		var self = this;
		var xui = this._xui();
		var view = this._view();
		var curTarget = this._activeTarget || this._selTarget();
		var isExclude = !!this._isExclude;

		return xui.loadRoutingHub(view, { view: isExclude ? 'exclude' : 'general', tab: isExclude ? 'exclude' : curTarget }, isExclude).then(function(next) {
			self._initialChecked = cloneChecked(next.checked);
			self._lastMountedHub = next;
			self.mount({ xui: xui, view: view, hub: next });
			self._activeTarget = curTarget;
			self.requestPaint();
		});
	}

	_saveMatrix() {
		var self = this;
		var changes = this._detectColumnChanges();
		var keysToSave = changes.changedKeys.length > 0 ? changes.changedKeys : null;

		return this._persistMatrix(keysToSave).then(function() {
			self._setStatus(_('Сохранено.'));
			return self._reloadGeneral();
		}).catch(function(err) {
			self._setStatus((err && err.message) || String(err));
		});
	}

	_applyMatrix() {
		var self = this;
		var xui = this._xui();
		var dlg;
		var logParts = [];
		var changes = this._detectColumnChanges();
		var activeTarget = this._activeTarget || this._selTarget();
		var hasZapretCol = (this._hub().columns || []).some(function(c) {
			return c.target === 'zapret';
		});

		var shouldApplyRouting = false;
		var shouldApplyZapret = false;

		if (changes.hasRouting && changes.hasZapret) {
			shouldApplyRouting = true;
			shouldApplyZapret = true;
		} else if (changes.hasZapret) {
			shouldApplyZapret = true;
			shouldApplyRouting = false;
		} else if (changes.hasRouting) {
			shouldApplyRouting = true;
			shouldApplyZapret = false;
		} else {
			// No changes detected: apply based on active tab or all
			if (activeTarget === 'zapret') {
				shouldApplyZapret = true;
				shouldApplyRouting = false;
			} else if (activeTarget === 'vpn' || activeTarget === 'dns') {
				shouldApplyRouting = true;
				shouldApplyZapret = false;
			} else {
				shouldApplyRouting = true;
				shouldApplyZapret = hasZapretCol;
			}
		}

		var confirmMsg;
		if (shouldApplyZapret && !shouldApplyRouting) {
			confirmMsg = _('Сохранить и применить списки для Zapret?');
		} else if (shouldApplyRouting && !shouldApplyZapret) {
			confirmMsg = _('Сохранить и применить маршрутизацию (VPN/DNS)?');
		} else {
			confirmMsg = _('Сохранить матрицу и применить маршрутизацию (VPN/DNS) и Zapret?');
		}

		if (!window.confirm(confirmMsg))
			return;

		dlg = xui.openExecOutputDialog(_('Применить'));
		dlg.setStatus(_('Сохранение…'));
		dlg.setText(_('Сохранение матрицы…'));
		this._setStatus(_('Сохранение…'));

		var keysToSave = changes.changedKeys.length > 0 ? changes.changedKeys : null;

		this._persistMatrix(keysToSave).then(function() {
			logParts.push(_('=== Сохранение ==='));
			logParts.push(_('Готово.'));
			dlg.setText(logParts.join('\n'));

			if (!shouldApplyRouting)
				return null;

			dlg.setStatus(_('Применение маршрутизации…'));
			return xui.runIfaceMenu('applyRouting', '');
		}).then(function(res) {
			if (res) {
				logParts.push('');
				logParts.push(_('=== VPN / DNS ==='));
				logParts.push(xui.formatExecReport(res));
				dlg.setText(logParts.join('\n'));
				if (res && res.code && res.code !== 0)
					return Promise.reject(new Error((res && res.stderr) || _('Ошибка apply routing')));
				if (xui.ifaceTaskRunning(res)) {
					dlg.setStatus(_('Применение в фоне…'));
					return xui.pollWizardApplyTask(self, self._view(), 'matrix', dlg, 0);
				}
			}
			return null;
		}).then(function() {
			if (!shouldApplyZapret)
				return null;
			dlg.setStatus(_('Применение Zapret…'));
			return xui.runZapretMenu('applyLists', '');
		}).then(function(res) {
			if (res) {
				logParts.push('');
				logParts.push(_('=== Zapret ==='));
				logParts.push(xui.formatExecReport(res));
				dlg.setText(logParts.join('\n'));
				if (res.code && res.code !== 0)
					return Promise.reject(new Error((res && res.stderr) || _('Ошибка apply zapret')));
			}
			dlg.setStatus(_('Применено.'));
			dlg.setDone(true);
			self._setStatus(_('Применено.'));
			return self._reloadGeneral();
		}).catch(function(err) {
			var msg = (err && err.message) || String(err);

			logParts.push('');
			logParts.push(msg);
			dlg.setText(logParts.join('\n'));
			dlg.setStatus(msg);
			dlg.setDone(false);
			self._setStatus(msg);
		});
	}

	_renderScope() {
		var xui = this._xui();
		var view = this._view();
		var hub = this._hub();
		var sel = this._sel();
		var node = xui.routingWizardNode(sel.target);
		var model = hub.model;
		var scope = sel.scope;

		view._xfreeWizardActiveIface = scope;
		if (!view._xfreeWizardModels)
			view._xfreeWizardModels = {};
		view._xfreeWizardModels[scope] = model;

		return E('div', {
			'class': 'xfree-routing-scope',
			'data-xfree-wizard': node.id
		}, [
			E('h3', {}, [
				kindLabel(sel.target) + ' · ' + (sel.label || scope)
			]),
			E('div', { 'class': 'cbi-section-descr' }, [
				_('Отдельный выбор списков для этой цели. «Общее» — матрица по всем целям.')
			]),
			xui.renderWizardListsPane(node, view, scope, model)
		]);
	}

	render() {
		var hub = this._hub();
		var body;

		this.className = 'xfree-routing-hub';
		this.setAttribute('data-xfree-routing', '1');

		if (hub.loading) {
			this.replaceChildren(
				E('div', { 'class': 'panel-block xfree-routing-body' }, [ this._renderMatrix() ])
			);
			return;
		}

		if (hub.error) {
			this.replaceChildren(
				E('div', { 'class': 'cbi-section-descr' }, [ hub.error ])
			);
			return;
		}

		body = this._renderMatrix();

		this.replaceChildren(
			E('div', { 'class': 'panel-block xfree-routing-body' }, [ body ])
		);
	}
});

return baseclass.extend({
	tag: TAG
});
