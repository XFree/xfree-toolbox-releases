'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';
'require xfree-toolbox.vpn-server-panel';

var TAG = 'xfree-vpn';

function flagTone(ok) {
	return ok ? 'ok' : 'muted';
}

function badge(label, ok) {
	return E('span', {
		'class': 'xfree-vpn-badge is-' + flagTone(ok)
	}, [label + (ok ? ' ✓' : ' —')]);
}

function healthTone(health) {
	var h = String(health || '').toLowerCase();

	if (h === 'ok') return 'ok';
	if (h === 'warn') return 'warn';
	if (h === 'fail') return 'bad';
	return 'muted';
}

function healthLabel(health) {
	var h = String(health || '').toLowerCase();

	if (h === 'ok') return 'OK';
	if (h === 'warn') return 'WARN';
	if (h === 'fail') return 'FAIL';
	return '—';
}

/* ISO country code → Russian name */
var COUNTRY_RU = {
	AD: 'Андорра',
	AE: 'ОАЭ',
	AF: 'Афганистан',
	AL: 'Албания',
	AM: 'Армения',
	AO: 'Ангола',
	AR: 'Аргентина',
	AT: 'Австрия',
	AU: 'Австралия',
	AZ: 'Азербайджан',
	BA: 'Босния и Герцеговина',
	BB: 'Барбадос',
	BD: 'Бангладеш',
	BE: 'Бельгия',
	BF: 'Буркина-Фасо',
	BG: 'Болгария',
	BH: 'Бахрейн',
	BN: 'Бруней',
	BO: 'Боливия',
	BR: 'Бразилия',
	BT: 'Бутан',
	BW: 'Ботсвана',
	BY: 'Беларусь',
	CA: 'Канада',
	CH: 'Швейцария',
	CI: 'Кот-д\'Ивуар',
	CL: 'Чили',
	CM: 'Камерун',
	CN: 'Китай',
	CO: 'Колумбия',
	CR: 'Коста-Рика',
	CY: 'Кипр',
	CZ: 'Чехия',
	DE: 'Германия',
	DJ: 'Джибути',
	DK: 'Дания',
	DO: 'Доминиканская Республика',
	DZ: 'Алжир',
	EC: 'Эквадор',
	EE: 'Эстония',
	EG: 'Египет',
	ES: 'Испания',
	ET: 'Эфиопия',
	FI: 'Финляндия',
	FJ: 'Фиджи',
	FR: 'Франция',
	GB: 'Великобритания',
	GD: 'Гренада',
	GE: 'Грузия',
	GH: 'Гана',
	GR: 'Греция',
	GT: 'Гватемала',
	GU: 'Гуам',
	GY: 'Гайана',
	HK: 'Гонконг',
	HN: 'Гондурас',
	HR: 'Хорватия',
	HU: 'Венгрия',
	ID: 'Индонезия',
	IE: 'Ирландия',
	IL: 'Израиль',
	IN: 'Индия',
	IQ: 'Ирак',
	IS: 'Исландия',
	IT: 'Италия',
	JM: 'Ямайка',
	JO: 'Иордания',
	JP: 'Япония',
	KE: 'Кения',
	KG: 'Кыргызстан',
	KH: 'Камбоджа',
	KR: 'Южная Корея',
	KW: 'Кувейт',
	KZ: 'Казахстан',
	LA: 'Лаос',
	LB: 'Ливан',
	LK: 'Шри-Ланка',
	LT: 'Литва',
	LU: 'Люксембург',
	LV: 'Латвия',
	MA: 'Марокко',
	MD: 'Молдова',
	ME: 'Черногория',
	MG: 'Мадагаскар',
	MK: 'Северная Македония',
	MM: 'Мьянма',
	MN: 'Монголия',
	MO: 'Макао',
	MT: 'Мальта',
	MU: 'Маврикий',
	MV: 'Мальдивы',
	MX: 'Мексика',
	MY: 'Малайзия',
	MZ: 'Мозамбик',
	NA: 'Намибия',
	NC: 'Новая Каледония',
	NG: 'Нигерия',
	NL: 'Нидерланды',
	NO: 'Норвегия',
	NP: 'Непал',
	NZ: 'Новая Зеландия',
	OM: 'Оман',
	PA: 'Панама',
	PE: 'Перу',
	PF: 'Французская Полинезия',
	PG: 'Папуа — Новая Гвинея',
	PH: 'Филиппины',
	PK: 'Пакистан',
	PL: 'Польша',
	PR: 'Пуэрто-Рико',
	PS: 'Палестина',
	PT: 'Португалия',
	PY: 'Парагвай',
	QA: 'Катар',
	RO: 'Румыния',
	RS: 'Сербия',
	RU: 'Россия',
	RW: 'Руанда',
	SA: 'Саудовская Аравия',
	SE: 'Швеция',
	SG: 'Сингапур',
	SI: 'Словения',
	SK: 'Словакия',
	SN: 'Сенегал',
	SR: 'Суринам',
	SV: 'Сальвадор',
	TH: 'Таиланд',
	TN: 'Тунис',
	TR: 'Турция',
	TT: 'Тринидад и Тобаго',
	TW: 'Тайвань',
	TZ: 'Танзания',
	UA: 'Украина',
	UG: 'Уганда',
	US: 'США',
	UY: 'Уругвай',
	UZ: 'Узбекистан',
	VE: 'Венесуэла',
	VN: 'Вьетнам',
	ZA: 'ЮАР',
	ZM: 'Замбия',
	ZW: 'Зимбабве',
};

/* Cloudflare colo (IATA) → [ city, ISO country ]; display: ARN (Stockholm, Arlanda / Швеция) */
var WARP_COLO = {
	AAE: ['Annabah', 'DZ'],
	ABJ: ['Abidjan', 'CI'],
	ABQ: ['Albuquerque', 'US'],
	ACC: ['Accra', 'GH'],
	ADB: ['Izmir', 'TR'],
	ADD: ['Addis Ababa', 'ET'],
	ADL: ['Adelaide', 'AU'],
	AKL: ['Auckland', 'NZ'],
	AKX: ['Aktyubinsk', 'KZ'],
	ALA: ['Almaty', 'KZ'],
	ALG: ['Algiers', 'DZ'],
	AMD: ['Ahmedabad', 'IN'],
	AMM: ['Amman', 'JO'],
	AMS: ['Amsterdam', 'NL'],
	ANC: ['Anchorage', 'US'],
	ARI: ['Arica', 'CL'],
	ARN: ['Stockholm, Arlanda', 'SE'],
	ARU: ['Aracatuba', 'BR'],
	ASK: ['Yamoussoukro', 'CI'],
	ASU: ['Asuncion', 'PY'],
	ATH: ['Athens', 'GR'],
	ATL: ['Atlanta', 'US'],
	AUS: ['Austin', 'US'],
	BAH: ['Manama', 'BH'],
	BAQ: ['Barranquilla', 'CO'],
	BCN: ['Barcelona', 'ES'],
	BEG: ['Belgrad', 'RS'],
	BEL: ['Belem', 'BR'],
	BEY: ['Beirut', 'LB'],
	BGI: ['Bridgetown', 'BB'],
	BGR: ['Bangor', 'US'],
	BGW: ['Baghdad', 'IQ'],
	BKK: ['Bangkok', 'TH'],
	BLR: ['Bangalore', 'IN'],
	BNA: ['Nashville', 'US'],
	BNE: ['Brisbane', 'AU'],
	BNU: ['Blumenau', 'BR'],
	BOD: ['Bordeaux/Merignac', 'FR'],
	BOG: ['Bogota', 'CO'],
	BOM: ['Mumbai', 'IN'],
	BOS: ['Boston', 'US'],
	BRU: ['Brussels', 'BE'],
	BSB: ['Brasilia', 'BR'],
	BSR: ['Basrah', 'IQ'],
	BTS: ['Bratislava', 'SK'],
	BUD: ['Budapest', 'HU'],
	BUF: ['Buffalo', 'US'],
	BWN: ['Bandar Seri Begawan', 'BN'],
	CAI: ['Cairo', 'EG'],
	CAW: ['Campos Dos Goytacazes', 'BR'],
	CBR: ['Canberra', 'AU'],
	CCU: ['Kolkata', 'IN'],
	CDG: ['Paris', 'FR'],
	CEB: ['Lapu-Lapu City', 'PH'],
	CFC: ['Caçador', 'BR'],
	CGB: ['Cuiaba', 'BR'],
	CGK: ['Jakarta', 'ID'],
	CGP: ['Chittagong', 'BD'],
	CGY: ['Laguindingan', 'PH'],
	CLT: ['Charlotte', 'US'],
	CMB: ['Colombo', 'LK'],
	CMH: ['Columbus', 'US'],
	CMN: ['Casablanca', 'MA'],
	CNF: ['Belo Horizonte', 'BR'],
	CNN: ['Mattanur', 'IN'],
	CNX: ['Chiang Mai', 'TH'],
	COK: ['Cochin', 'IN'],
	COR: ['Cordoba', 'AR'],
	CPH: ['Copenhagen', 'DK'],
	CPT: ['Cape Town', 'ZA'],
	CRK: ['Angeles City', 'PH'],
	CVG: ['Hebron', 'US'],
	CWB: ['Curitiba', 'BR'],
	CZL: ['Constantine', 'DZ'],
	DAC: ['Dhaka', 'BD'],
	DAD: ['Da Nang', 'VN'],
	DAR: ['Dar es Salaam', 'TZ'],
	DEL: ['New Delhi', 'IN'],
	DEN: ['Denver', 'US'],
	DFW: ['Dallas-Fort Worth', 'US'],
	DKR: ['Dakar', 'SN'],
	DLA: ['Douala', 'CM'],
	DME: ['Moscow', 'RU'],
	DMM: ['Ad Dammam', 'SA'],
	DOH: ['Doha', 'QA'],
	DPS: ['Denpasar-Bali Island', 'ID'],
	DTW: ['Detroit', 'US'],
	DUB: ['Dublin', 'IE'],
	DUR: ['Durban', 'ZA'],
	DUS: ['Dusseldorf', 'DE'],
	DXB: ['Dubai', 'AE'],
	EBB: ['Kampala', 'UG'],
	EBL: ['Arbil', 'IQ'],
	EDI: ['Edinburgh', 'GB'],
	EVN: ['Yerevan', 'AM'],
	EWR: ['Newark', 'US'],
	EZE: ['Ezeiza', 'AR'],
	FCO: ['Rome', 'IT'],
	FLN: ['Florianopolis', 'BR'],
	FOR: ['Fortaleza', 'BR'],
	FRA: ['Frankfurt', 'DE'],
	FRU: ['Bishkek', 'KG'],
	FSD: ['Sioux Falls', 'US'],
	FUK: ['Fukuoka', 'JP'],
	GBE: ['Gaborone', 'BW'],
	GDL: ['Guadalajara', 'MX'],
	GEO: ['Georgetown', 'GY'],
	GIG: ['Rio De Janeiro', 'BR'],
	GND: ['Saint George\'s', 'GD'],
	GOT: ['Gothenburg', 'SE'],
	GRU: ['Sao Paulo', 'BR'],
	GUA: ['Guatemala City', 'GT'],
	GUM: ['Hagatna', 'GU'],
	GVA: ['Geneva', 'CH'],
	GYD: ['Baku', 'AZ'],
	GYE: ['Guayaquil', 'EC'],
	GYN: ['Goiania', 'BR'],
	HAM: ['Hamburg', 'DE'],
	HAN: ['Hanoi', 'VN'],
	HBA: ['Hobart', 'AU'],
	HEL: ['Helsinki', 'FI'],
	HFA: ['Haifa', 'IL'],
	HKG: ['Hong Kong', 'CN'],
	HNL: ['Honolulu', 'US'],
	HRE: ['Harare', 'ZW'],
	HYD: ['Hyderabad', 'IN'],
	IAD: ['Dulles', 'US'],
	IAH: ['Houston', 'US'],
	ICN: ['Seoul', 'KR'],
	IND: ['Indianapolis', 'US'],
	ISB: ['Islamabad', 'PK'],
	IST: ['Arnavutkoy', 'TR'],
	ISU: ['Sulaymaniyah', 'IQ'],
	ITJ: ['Itajai', 'BR'],
	IXC: ['Chandigarh', 'IN'],
	JAX: ['Jacksonville', 'US'],
	JDO: ['Juazeiro Do Norte', 'BR'],
	JED: ['Jeddah', 'SA'],
	JHB: ['Senai', 'MY'],
	JIB: ['Djibouti City', 'DJ'],
	JNB: ['Johannesburg', 'ZA'],
	JOG: ['Yogyakarta-Java Island', 'ID'],
	JOI: ['Joinville', 'BR'],
	JSR: ['Jashahor', 'BD'],
	KBP: ['Kiev', 'UA'],
	KCH: ['Kuching', 'MY'],
	KEF: ['Reykjavik', 'IS'],
	KGL: ['Kigali', 'RW'],
	KHH: ['Kaohsiung City', 'CN'],
	KHI: ['Karachi', 'PK'],
	KIN: ['Kingston', 'JM'],
	KIV: ['Chisinau', 'MD'],
	KIX: ['Osaka', 'JP'],
	KJA: ['Krasnoyarsk', 'RU'],
	KNU: ['Kanpur', 'IN'],
	KTM: ['Kathmandu', 'NP'],
	KUL: ['Kuala Lumpur', 'MY'],
	KWI: ['Kuwait City', 'KW'],
	LAD: ['Luanda', 'AO'],
	LAS: ['Las Vegas', 'US'],
	LAX: ['Los Angeles', 'US'],
	LCA: ['Larnarca', 'CY'],
	LED: ['St. Petersburg', 'RU'],
	LHE: ['Lahore', 'PK'],
	LHR: ['London', 'GB'],
	LIM: ['Lima', 'PE'],
	LIS: ['Lisbon', 'PT'],
	LJU: ['Ljubljana', 'SI'],
	LLK: ['Lankaran', 'AZ'],
	LOS: ['Lagos', 'NG'],
	LPB: ['La Paz / El Alto', 'BO'],
	LUN: ['Lusaka', 'ZM'],
	LUX: ['Luxembourg', 'LU'],
	LYS: ['Lyon', 'FR'],
	MAA: ['Chennai', 'IN'],
	MAD: ['Madrid', 'ES'],
	MAN: ['Manchester', 'GB'],
	MAO: ['Manaus', 'BR'],
	MBA: ['Mombasa', 'KE'],
	MCI: ['Kansas City', 'US'],
	MCT: ['Muscat', 'OM'],
	MDE: ['Rionegro', 'CO'],
	MEL: ['Melbourne', 'AU'],
	MEM: ['Memphis', 'US'],
	MEX: ['Mexico City', 'MX'],
	MFE: ['Mc Allen', 'US'],
	MFM: ['Taipa', 'CN'],
	MGM: ['Montgomery', 'US'],
	MIA: ['Miami', 'US'],
	MLA: ['Luqa', 'MT'],
	MLE: ['Male', 'MV'],
	MLG: ['Malang-Java Island', 'ID'],
	MNL: ['Manila', 'PH'],
	MPM: ['Maputo', 'MZ'],
	MRS: ['Marseille', 'FR'],
	MRU: ['Port Louis', 'MU'],
	MSP: ['Minneapolis', 'US'],
	MSQ: ['Minsk', 'BY'],
	MUC: ['Munich', 'DE'],
	MXP: ['Milan', 'IT'],
	NAG: ['Naqpur', 'IN'],
	NBO: ['Nairobi', 'KE'],
	NJF: ['Najaf', 'IQ'],
	NOU: ['Noumea', 'NC'],
	NQN: ['Neuquen', 'AR'],
	NQZ: ['Astana', 'KZ'],
	NRT: ['Tokyo', 'JP'],
	NVT: ['Navegantes', 'BR'],
	OKA: ['Naha', 'JP'],
	OKC: ['Oklahoma City', 'US'],
	OMA: ['Omaha', 'US'],
	ORD: ['Chicago', 'US'],
	ORK: ['Cork', 'IE'],
	ORN: ['Oran', 'DZ'],
	OSL: ['Oslo', 'NO'],
	OTP: ['Bucharest', 'RO'],
	OUA: ['Ouagadougou', 'BF'],
	PAT: ['Patna', 'IN'],
	PBH: ['Paro', 'BT'],
	PBM: ['Zandery', 'SR'],
	PDX: ['Portland', 'US'],
	PER: ['Perth', 'AU'],
	PHL: ['Philadelphia', 'US'],
	PHX: ['Phoenix', 'US'],
	PIT: ['Pittsburgh', 'US'],
	PMO: ['Palermo', 'IT'],
	PMW: ['Palmas', 'BR'],
	PNH: ['Phnom Penh', 'KH'],
	POA: ['Porto Alegre', 'BR'],
	POS: ['Port of Spain', 'TT'],
	PPT: ['Papeete', 'PF'],
	PRG: ['Prague', 'CZ'],
	PTY: ['Tocumen', 'PA'],
	QRO: ['Queretaro', 'MX'],
	QWJ: ['Americana', 'BR'],
	RAO: ['Ribeirao Preto', 'BR'],
	RDU: ['Raleigh/Durham', 'US'],
	REC: ['Recife', 'BR'],
	RGN: ['Yangon', 'MM'],
	RIC: ['Richmond', 'US'],
	RIX: ['Riga', 'LV'],
	RUH: ['Riyadh', 'SA'],
	RUN: ['St Denis', 'FR'],
	SAN: ['San Diego', 'US'],
	SAP: ['La Mesa', 'HN'],
	SAT: ['San Antonio', 'US'],
	SCL: ['Santiago', 'CL'],
	SDQ: ['Santo Domingo', 'DO'],
	SEA: ['Seattle', 'US'],
	SFO: ['San Francisco', 'US'],
	SGN: ['Ho Chi Minh City', 'VN'],
	SIN: ['Singapore', 'SG'],
	SJC: ['San Jose', 'US'],
	SJK: ['Sao Jose Dos Campos', 'BR'],
	SJO: ['San Jose', 'CR'],
	SJP: ['Sao Jose Do Rio Preto', 'BR'],
	SJU: ['San Juan', 'PR'],
	SKG: ['Thessaloniki', 'GR'],
	SKP: ['Skopje', 'MK'],
	SLC: ['Salt Lake City', 'US'],
	SMF: ['Sacramento', 'US'],
	SOD: ['Sorocaba', 'BR'],
	SOF: ['Sofia', 'BG'],
	SSA: ['Salvador', 'BR'],
	STI: ['Santiago', 'DO'],
	STL: ['St Louis', 'US'],
	STR: ['Stuttgart', 'DE'],
	SUV: ['Nausori', 'FJ'],
	SVX: ['Yekaterinburg', 'RU'],
	SYD: ['Sydney', 'AU'],
	TAS: ['Tashkent', 'UZ'],
	TBS: ['Tbilisi', 'GE'],
	TGU: ['Tegucigalpa', 'HN'],
	TIA: ['Tirana', 'AL'],
	TLH: ['Tallahassee', 'US'],
	TLL: ['Tallinn', 'EE'],
	TLV: ['Tel Aviv', 'IL'],
	TNR: ['Antananarivo', 'MG'],
	TPA: ['Tampa', 'US'],
	TPE: ['Taipei', 'CN'],
	TUN: ['Tunis', 'TN'],
	TXL: ['Berlin', 'DE'],
	UDI: ['Uberlandia', 'BR'],
	UIO: ['Quito', 'EC'],
	ULN: ['Ulan Bator', 'MN'],
	URT: ['Surat Thani', 'TH'],
	VCP: ['Campinas', 'BR'],
	VIE: ['Vienna', 'AT'],
	VIX: ['Vitoria', 'BR'],
	VNO: ['Vilnius', 'LT'],
	VTE: ['Vientiane', 'LA'],
	WAW: ['Warsaw', 'PL'],
	WDH: ['Windhoek', 'NA'],
	WLG: ['Wellington', 'NZ'],
	WRO: ['Wroclaw', 'PL'],
	XAP: ['Chapeco', 'BR'],
	XNH: ['Nasiriyah', 'IQ'],
	YHZ: ['Halifax', 'CA'],
	YOW: ['Ottawa', 'CA'],
	YUL: ['Montreal', 'CA'],
	YVR: ['Vancouver', 'CA'],
	YWG: ['Winnipeg', 'CA'],
	YXE: ['Saskatoon', 'CA'],
	YYC: ['Calgary', 'CA'],
	YYZ: ['Toronto', 'CA'],
	ZAG: ['Zagreb', 'HR'],
	ZDM: ['Ramallah', 'PS'],
	ZRH: ['Zurich', 'CH'],
};

/* Backwards-compatibility alias */
var WARP_COLO_CC = {};
for (var _k in WARP_COLO) {
	if (WARP_COLO.hasOwnProperty(_k))
		WARP_COLO_CC[_k] = WARP_COLO[_k][1];
}

function countryName(code) {
	if (!code)
		return '';
	var c = String(code).toUpperCase().trim();
	return COUNTRY_RU[c] || code;
}

function coloInfo(colo) {
	var c = String(colo || '').toUpperCase();
	return (c && WARP_COLO[c]) || null;
}

function coloCity(colo) {
	var info = coloInfo(colo);
	return info ? info[0] : '';
}

function coloCountry(colo) {
	var info = coloInfo(colo);
	return info ? info[1] : '';
}

function coloLabel(colo) {
	var c = String(colo || '').toUpperCase();
	var info;
	var city;
	var cc;
	var country;
	var loc = [];

	if (!c)
		return '';
	info = coloInfo(c);
	if (info) {
		city = info[0];
		cc = info[1];
		country = countryName(cc);
		if (city)
			loc.push(city);
		if (country)
			loc.push(country);
		if (loc.length)
			return c + ' (' + loc.join(' / ') + ')';
	}
	return c;
}

function confOptions(confs, preferKind) {
	var list = Array.isArray(confs) ? confs.slice() : [];
	var opts = [];
	var i;
	var c;
	var preferred = [];
	var rest = [];

	for (i = 0; i < list.length; i++) {
		c = list[i];
		if (!c || !c.file)
			continue;
		if (preferKind && c.kind === preferKind)
			preferred.push(c);
		else
			rest.push(c);
	}
	list = preferred.concat(rest);
	for (i = 0; i < list.length; i++) {
		c = list[i];
		opts.push({
			v: c.file,
			t: (c.kind ? c.kind + ' · ' : '') + c.file
		});
	}
	return opts;
}

function ifaceNameFromConf(file) {
	var base = String(file || '').replace(/^.*\//, '').replace(/\.conf$/i, '');

	return base.replace(/[^A-Za-z0-9_.-]/g, '_').replace(/^[.-]+|[.-]+$/g, '') || 'tunnel';
}

function sanitizeIfaceName(raw) {
	var s = String(raw || '').trim().replace(/[^A-Za-z0-9_.-]/g, '');

	return s.replace(/^[.-]+|[.-]+$/g, '') || '';
}

function unpackAmneziaVpnKey(rawStr) {
	var s = String(rawStr || '').trim();
	if (s.indexOf('vpn://') === 0)
		s = s.substring(6);
	s = s.replace(/_/g, '/').replace(/-/g, '+');
	while (s.length % 4) s += '=';
	var bin;
	try {
		bin = atob(s);
	} catch {
		return Promise.reject(new Error(_('Некорректная Base64 строка')));
	}
	var bytes = new Uint8Array(bin.length);
	for (var i = 0; i < bin.length; i++) {
		bytes[i] = bin.charCodeAt(i);
	}
	var offset = 0;
	if (bytes.length >= 4 && bytes[0] === 0 && bytes[1] === 0 && bytes[2] === 0 && bytes[3] === 0xff) {
		offset = 4;
	}
	var payload = bytes.subarray(offset);
	if (typeof DecompressionStream !== 'undefined') {
		try {
			var ds = new DecompressionStream('deflate');
			var writer = ds.writable.getWriter();
			writer.write(payload);
			writer.close();
			var reader = ds.readable.getReader();
			var chunks = [];
			var total = 0;
			function readNext() {
				return reader.read().then(function (step) {
					if (step.done) {
						var res = new Uint8Array(total);
						var cur = 0;
						for (var j = 0; j < chunks.length; j++) {
							res.set(chunks[j], cur);
							cur += chunks[j].length;
						}
						var text = new TextDecoder('utf-8').decode(res);
						return JSON.parse(text);
					}
					chunks.push(step.value);
					total += step.value.length;
					return readNext();
				});
			}
			return readNext();
		} catch (err) {
			return Promise.reject(err);
		}
	}
	return Promise.reject(new Error(_('DecompressionStream не поддерживается в этом браузере')));
}

function extractAmneziaConfig(jsonObj) {
	if (!jsonObj || typeof jsonObj !== 'object')
		return null;
	if (jsonObj.api_config) {
		return {
			isSubscription: true,
			name: jsonObj.name || jsonObj.description || 'Amnezia Premium',
			serviceType: jsonObj.api_config.service_type || 'amnezia-premium',
			country: jsonObj.api_config.user_country_code || '',
			apiKey: (jsonObj.auth_data && jsonObj.auth_data.api_key) || ''
		};
	}
	var extractedConf = null;
	var type = jsonObj.defaultContainer || 'awg';
	if (Array.isArray(jsonObj.containers)) {
		for (var i = 0; i < jsonObj.containers.length; i++) {
			var c = jsonObj.containers[i];
			if (c.awg && c.awg.last_config) {
				extractedConf = c.awg.last_config;
				type = 'awg';
				break;
			}
			if (c.wireguard && c.wireguard.last_config) {
				extractedConf = c.wireguard.last_config;
				type = 'wireguard';
				break;
			}
			if (c.openvpn && c.openvpn.last_config) {
				extractedConf = c.openvpn.last_config;
				type = 'openvpn';
				break;
			}
		}
	}
	if (extractedConf) {
		return {
			isStatic: true,
			confText: extractedConf,
			type: type,
			name: jsonObj.description || jsonObj.hostName || 'amnezia'
		};
	}
	return null;
}

function listCreateKinds(summary) {
	var slots = (summary && summary.createSlots) || [];
	var byKind = {};
	var out = [];
	var k;
	var i;
	var s;

	for (i = 0; i < slots.length; i++) {
		s = slots[i];
		k = String(s.kind || s.slot || '').toLowerCase();
		if (!k || k === 'manual')
			continue;
		if (!byKind[k] || (byKind[k].occupied && !s.occupied))
			byKind[k] = s;
	}
	if (!byKind['warp']) {
		byKind['warp'] = { kind: 'warp', slot: 'warp', occupied: 0 };
	}
	if (!byKind['proton']) {
		byKind['proton'] = { kind: 'proton', slot: 'proton', occupied: 0 };
	}

	var orderedKinds = ['warp', 'proton'];
	for (i = 0; i < orderedKinds.length; i++) {
		k = orderedKinds[i];
		if (byKind[k]) {
			out.push({
				kind: k,
				slot: byKind[k].slot || k,
				occupied: byKind[k].occupied ? 1 : 0
			});
		}
	}
	for (k in byKind) {
		if (!Object.prototype.hasOwnProperty.call(byKind, k) || orderedKinds.indexOf(k) >= 0)
			continue;
		out.push({
			kind: k,
			slot: byKind[k].slot || k,
			occupied: byKind[k].occupied ? 1 : 0
		});
	}
	return out;
}

function defaultNewIfaceName(slotName, ifaces, summary) {
	var kind = String(slotName || '').toLowerCase();
	var free;

	if (kind === 'warp' || kind.indexOf('warp') === 0) {
		free = summary && summary.freeWarpIface;
		if (free)
			return free;
	}
	if (kind === 'proton' || kind.indexOf('proton') === 0) {
		free = summary && summary.freeProtonIface;
		if (free)
			return free;
	}

	var base = sanitizeIfaceName(slotName) || 'tunnel';
	var i;
	var n;
	var names = {};

	for (i = 0; i < (ifaces || []).length; i++)
		names[ifaces[i].name] = 1;
	if (!names[base])
		return base;
	for (n = 2; n < 50; n++) {
		if (!names[base + String(n)])
			return base + String(n);
	}
	return base + '_new';
}

function createKindLabel(kind) {
	var k = String(kind || '').toLowerCase();

	if (k === 'warp')
		return 'WARP';
	if (k === 'proton')
		return 'Proton';
	return kind;
}

function _paramLine(k, v) {
	if (!v)
		return null;
	return E('span', { 'class': 'xfree-vpn-param' }, [
		E('em', {}, [k]),
		' ',
		v
	]);
}

function selectField(id, label, value, options) {
	var opts = [];
	var i;
	var v = String(value || '');

	for (i = 0; i < options.length; i++) {
		opts.push(E('option', {
			'value': options[i].v,
			'selected': options[i].v === v ? true : null
		}, [options[i].t]));
	}

	return E('div', { 'class': 'xfree-vpn-field' }, [
		E('div', { 'class': 'xfree-vpn-field-label' }, [label]),
		E('select', {
			'class': 'xfree-uplink-input',
			'data-xfree-vpn-field': id
		}, opts)
	]);
}

function textField(id, label, value, placeholder) {
	return E('div', { 'class': 'xfree-vpn-field' }, [
		E('div', { 'class': 'xfree-vpn-field-label' }, [label]),
		E('input', {
			'class': 'xfree-uplink-input',
			'type': 'text',
			'data-xfree-vpn-field': id,
			'value': value || '',
			'placeholder': placeholder || ''
		})
	]);
}

/* Country = tribukvy + бот llimonix; [LTE] = tel.*.tribukvy без бота (фильтр портов). */
var WARP_SERVERS = [
	{ v: 'xfree', t: 'xfree' },
	{ v: 'def', t: 'def (Cloudflare)' },
	{ v: 'FL', t: 'Финляндия (рег.)' },
	{ v: 'NL', t: 'Нидерланды (рег.)' },
	{ v: 'PL', t: 'Польша (рег.)' },
	{ v: 'DE', t: 'Германия (рег.)' },
	{ v: 'LV', t: 'Латвия (рег.)' },
	{ v: 'RU', t: 'Россия (рег.)' },
	{ v: 'lteFL', t: '[LTE] Финляндия' },
	{ v: 'ltePL', t: '[LTE] Польша' },
	{ v: 'lteDE', t: '[LTE] Германия' }
];

var WARP_GEN_HELP_URL = 'https://warp-generation.github.io/';

function warpServerNeedsReg(v) {
	return /^(FL|NL|PL|DE|LV|RU)$/.test(String(v || ''));
}

function warpServerIsLte(v) {
	return /^(lteFL|ltePL|lteDE)$/.test(String(v || ''));
}

function _warpServerLabel(v) {
	var i;
	var s = String(v || 'xfree');

	for (i = 0; i < WARP_SERVERS.length; i++) {
		if (WARP_SERVERS[i].v === s)
			return WARP_SERVERS[i].t;
	}
	return s;
}

function warpServerTip() {
	return E('p', { 'class': 'muted xfree-vpn-tip' }, [
		_('«(рег.)» — нужна регистрация в Telegram-боте от llimonix. «[LTE]» — без бота, но со своим фильтром портов (Польша без 988, Финляндия без 1010), как на '),
		E('a', {
			'href': WARP_GEN_HELP_URL,
			'target': '_blank',
			'rel': 'noopener noreferrer'
		}, ['warp-generation.github.io']),
		_('. Для обычного доступа достаточно xfree / def (Cloudflare).')
	]);
}

var WARP_PROFILES = [
	{ v: '2.0:auto', t: 'AWG 2.0 · автоподбор' },
	{ v: '2.0:1', t: 'AWG 2.0 · вариант 1' },
	{ v: '2.0:2', t: 'AWG 2.0 · вариант 2' },
	{ v: '2.0:3', t: 'AWG 2.0 · вариант 3' }
];

var PROTON_ENTROPY_OPTIONS = [
	{ v: 'r32', t: '<r 32> · 32 байта (по умолчанию)' },
	{ v: 'r64', t: '<r 64> · 64 байта (паранойя)' },
	{ v: 't', t: '<t> · timestamp' },
	{ v: 'c', t: '<c> · счётчик' },
	{ v: 'rc10', t: '<rc 10> · 10 букв' },
	{ v: 'rd6', t: '<rd 6> · 6 цифр' },
	{ v: 'off', t: _('без энтропии (только <b 0x…>)') }
];

var PROTON_NOISE_OPTIONS = [
	{ v: '0', t: _('без шума (Jc=0)') },
	{ v: '1', t: _('с шумом (Jc=4, Jmin=40, Jmax=70)') }
];

var WARP_MODES = [
	{ v: 'local', t: 'local' },
	{ v: 'raw', t: 'raw' }
];

var WARP_I1 = [
	{ v: 'fixed', t: 'fixed' },
	{ v: 'random', t: 'random' },
	{ v: 'domain', t: 'domain-seeded' }
];

var WARP_SELECTION = [
	{ v: 'best', t: _('Топ-5 по колонии + задержка') },
	{ v: 'random', t: _('Случайный endpoint') }
];

function _warpSelectionLabel(v) {
	var i;
	for (i = 0; i < WARP_SELECTION.length; i++) {
		if (WARP_SELECTION[i].v === v)
			return WARP_SELECTION[i].t;
	}
	return v || 'best';
}

function _warpExcludeRuLabel(v) {
	return (v === '1' || v === 1) ? _('без колоний RU') : _('все колонии');
}

var PROTON_COUNTRIES = (function () {
	var list = [
		{ v: 'AUTO', t: _('AUTO (автовыбор)') },
		{ v: 'NL', t: _('Нидерланды (NL)') + ' [Free]' },
		{ v: 'US', t: _('США (US)') + ' [Free]' },
		{ v: 'JP', t: _('Япония (JP)') + ' [Free]' },
		{ v: 'CA', t: _('Канада (CA)') + ' [Free]' },
		{ v: 'PL', t: _('Польша (PL)') + ' [Free]' },
		{ v: 'RO', t: _('Румыния (RO)') + ' [Free]' },
		{ v: 'SG', t: _('Сингапур (SG)') + ' [Free]' },
		{ v: 'MX', t: _('Мексика (MX)') },
		{ v: 'DE', t: _('Германия (DE)') },
		{ v: 'FR', t: _('Франция (FR)') },
		{ v: 'CH', t: _('Швейцария (CH)') },
		{ v: 'SE', t: _('Швеция (SE)') },
		{ v: 'GB', t: _('Великобритания (GB)') },
		{ v: 'ES', t: _('Испания (ES)') },
		{ v: 'IT', t: _('Италия (IT)') },
		{ v: 'FI', t: _('Финляндия (FI)') },
		{ v: 'TR', t: _('Турция (TR)') },
		{ v: 'KZ', t: _('Казахстан (KZ)') },
		{ v: 'AE', t: _('ОАЭ (AE)') },
		{ v: 'BR', t: _('Бразилия (BR)') },
		{ v: 'AR', t: _('Аргентина (AR)') },
		{ v: 'AU', t: _('Австралия (AU)') }
	];
	var seen = {};
	for (var i = 0; i < list.length; i++)
		seen[list[i].v] = true;

	var rest = [];
	for (var c in COUNTRY_RU) {
		if (!seen[c]) {
			var label = COUNTRY_RU[c] + ' (' + c + ')';
			rest.push({ v: c, t: label });
		}
	}
	rest.sort(function (a, b) {
		return a.t.localeCompare(b.t, 'ru');
	});
	return list.concat(rest);
})();

function renderTunnelSkeleton() {
	return E('div', { 'class': 'xfree-vpn-tunnel is-skeleton' }, [
		E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
			E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 76px; height: 15px;' }),
			E('div', { 'class': 'xfree-vpn-status-row' }, [
				E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 36px; height: 16px;' }),
				E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 26px; height: 16px;' })
			])
		]),
		E('div', { 'class': 'xfree-vpn-tunnel-sub' }, [
			E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 130px; height: 11px;' })
		]),
		E('div', { 'class': 'xfree-vpn-tunnel-meta' }, [
			E('div', { 'class': 'xfree-vpn-kv' }, [
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 34px; height: 11px;' }),
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 11px;' })
			]),
			E('div', { 'class': 'xfree-vpn-kv' }, [
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 34px; height: 11px;' }),
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 90px; height: 11px;' })
			])
		]),
		E('div', { 'class': 'xfree-vpn-tunnel-actions' }, [
			E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 50px; height: 22px; border-radius: 6px;' }),
			E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 50px; height: 22px; border-radius: 6px;' })
		])
	]);
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._summary = (spec && spec.summary) || { ifaces: [], warp: {}, proton: {}, count: 0 };
		this._awgSummary = (spec && spec.awgSummary) || {};
		this._protocolsStatus = (spec && spec.protocolsStatus) || {};
		this._output = (spec && spec.outputText) || '';
		this._busy = !!(spec && spec.busy);
		this._loading = !!(spec && spec.loading);
		this._protocolsLoaded = !!(spec && spec.protocolsStatus && Object.keys(spec.protocolsStatus).length > 0 && spec.protocolsStatus.awg);
		this._serverLoaded = !!(spec && spec.awgSummary && (spec.awgSummary.iface || spec.awgSummary.running != null));
		this._summaryLoaded = !!(spec && spec.summary && (spec.summary.ifaces != null || spec.summary.count != null));
		this._msg = (spec && spec.message) || '';
		this._msgTone = (spec && spec.messageTone) || '';
		this._vpnView = (spec && spec.vpnView) || 'tunnels';
		this.setAttribute('data-xfree-vpn', '1');
		this.requestPaint();
	}

	setLoading(loading) {
		this._loading = !!loading;
		if (this._spec)
			this._spec.loading = this._loading;
		this.requestPaint();
	}

	setSummary(summary) {
		this._summary = summary || { ifaces: [], warp: {}, proton: {}, count: 0 };
		this._summaryLoaded = true;
		this._loading = false;
		if (this._spec)
			this._spec.loading = false;
		this.requestPaint();
	}

	setAwgSummary(awg) {
		this._awgSummary = awg || {};
		this._serverLoaded = true;
		if (this._spec)
			this._spec.awgSummary = this._awgSummary;
		this.requestPaint();
	}

	setProtocolsStatus(status) {
		this._protocolsStatus = status || {};
		this._protocolsLoaded = true;
		this._loading = false;
		if (this._spec) {
			this._spec.protocolsStatus = this._protocolsStatus;
			this._spec.loading = false;
		}
		this.requestPaint();
	}

	setOutputText(text) {
		this._output = text || '';
	}

	setBusy(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button').forEach(function (el) {
			el.disabled = !!busy;
		});
	}

	setMessage(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var el = this.querySelector('[data-xfree-vpn-msg]');

		if (el) {
			el.textContent = this._msg;
			el.className = 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : '');
		}
	}

	_act(ev, action, arg, confirmText) {
		var s = this._spec || {};

		if (ev && typeof ev.preventDefault === 'function')
			ev.preventDefault();
		if (ev && typeof ev.stopPropagation === 'function')
			ev.stopPropagation();
		if (s.onAction)
			return s.onAction(action, arg, confirmText);
	}

	_nav(ev, panel) {
		var s = this._spec || {};

		ev.preventDefault();
		ev.stopPropagation();
		if (s.onNavigate)
			s.onNavigate(panel);
	}

	_promptAct(ev, action, promptText, confirmText) {
		var s = this._spec || {};
		var arg;

		ev.preventDefault();
		ev.stopPropagation();
		arg = window.prompt(promptText, '');
		if (arg === null)
			return;
		arg = String(arg || '').trim();
		if (!arg) {
			this.setOutputText(_('Нужен аргумент: %s').format(promptText));
			this.setMessage(_('Нужен аргумент: %s').format(promptText), 'warn');
			return;
		}
		if (s.onAction)
			s.onAction(action, arg, confirmText);
	}

	_pickSelect(title, hint, options, onPick) {
		var sel;
		var opts = [];
		var i;

		if (!options || !options.length) {
			this.setMessage(_('Нет вариантов для выбора'), 'bad');
			return;
		}

		for (i = 0; i < options.length; i++) {
			opts.push(E('option', { 'value': options[i].v }, [options[i].t]));
		}

		sel = E('select', { 'class': 'xfree-uplink-input xfree-vpn-pick-select' }, opts);

		xui.openDialog({
			title: title,
			hint: hint || '',
			body: E('div', { 'class': 'xfree-vpn-pick' }, [sel]),
			actions: [
				{ label: _('Отмена'), variant: 'secondary', close: true },
				{
					label: _('Выбрать'),
					variant: 'primary',
					close: true,
					click: function () {
						var v = String(sel.value || '').trim();

						if (v && onPick)
							onPick(v);
					}
				}
			]
		});
	}

	_updateIface(ev, ifaceName, kind) {
		var s = this._spec || {};
		var confs = (this._summary && this._summary.confs) || [];
		var opts = confOptions(confs, kind);
		var isGenerator = (kind === 'warp' || kind === 'proton');
		var confirmMsg;
		var genLabel;
		var combinedOpts;

		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}

		if (isGenerator) {
			if (!opts || !opts.length) {
				confirmMsg = (kind === 'warp')
					? _('Обновить туннель «%s»? Будет выполнен подбор рабочего эндпоинта и обновление конфигурации.').format(ifaceName)
					: _('Обновить туннель «%s»? Будет обновлена конфигурация Proton VPN и применены настройки.').format(ifaceName);

				if (s.onAction)
					s.onAction('regenerateOne', ifaceName, confirmMsg);
				return;
			}

			genLabel = (kind === 'warp')
				? '⚡ ' + _('Автоматически: подобрать рабочий эндпоинт')
				: '⚡ ' + _('Автоматически: обновить конфигурацию');
			combinedOpts = [{ v: '__REGENERATE__', t: genLabel }].concat(opts);

			this._pickSelect(
				_('Обновить туннель «%s»').format(ifaceName),
				_('Выберите источник обновления конфигурации:'),
				combinedOpts,
				function (choice) {
					if (choice === '__REGENERATE__') {
						if (s.onAction)
							s.onAction('regenerateOne', ifaceName,
								_('Пересобрать и обновить «%s»?').format(ifaceName));
					} else {
						if (s.onAction)
							s.onAction('updateFromConf', ifaceName + '|' + choice,
								_('Обновить туннель «%s» из %s?').format(ifaceName, choice));
					}
				}
			);
			return;
		}

		if (!opts || !opts.length) {
			xui.openDialog({
				title: _('Обновить «%s»').format(ifaceName),
				hint: '',
				body: E('div', { 'class': 'xfree-vpn-pick' }, [
					E('p', {}, [
						_('В каталоге vpn/ текущего профиля не найдено файлов конфигурации (.conf).')
					]),
					E('p', { 'class': 'muted' }, [
						_('Загрузите файл .conf на вкладке «Файлы» или настройте туннель через «Пересобрать».')
					])
				]),
				actions: [
					{ label: _('Понятно'), variant: 'primary', close: true }
				]
			});
			return;
		}

		this._pickSelect(
			_('Обновить «%s» из .conf').format(ifaceName),
			_('Выберите файл конфигурации'),
			opts,
			function (file) {
				if (s.onAction)
					s.onAction('updateFromConf', ifaceName + '|' + file,
						_('Обновить туннель «%s» из %s?').format(ifaceName, file));
			}
		);
	}

	_updateFromConf(ev, ifaceName, preferKind) {
		return this._updateIface(ev, ifaceName, preferKind);
	}

	_createFromConf(ev) {
		var s = this._spec || {};
		var confs = (this._summary && this._summary.confs) || [];
		var opts = confOptions(confs, '');

		ev.preventDefault();
		ev.stopPropagation();
		this._pickSelect(
			_('Создать туннель из .conf'),
			_('Имя туннеля возьмётся из имени файла'),
			opts,
			function (file) {
				var name = ifaceNameFromConf(file);

				if (s.onAction)
					s.onAction('createFromConf', name + '|' + file,
						_('Создать туннель «%s» из %s?').format(name, file));
			}
		);
	}

	_getProtonCountryOptions(freeOnly, requireIpv6) {
		var isFreeOnly = (freeOnly === '1' || freeOnly === 1 || freeOnly === true);
		var isIpv6Only = (requireIpv6 === '1' || requireIpv6 === 1 || requireIpv6 === true);
		var sc = this._protonServerCountries;

		var allowedCodes = null;
		if (sc) {
			if (isFreeOnly && isIpv6Only && sc.free_v6 && sc.free_v6.length) {
				allowedCodes = sc.free_v6;
			} else if (isFreeOnly && sc.free && sc.free.length) {
				allowedCodes = sc.free;
			} else if (isIpv6Only && sc.v6 && sc.v6.length) {
				allowedCodes = sc.v6;
			} else if (!isFreeOnly && sc.all && sc.all.length) {
				allowedCodes = sc.all;
			}
		}

		if (!allowedCodes) {
			if (isFreeOnly) {
				allowedCodes = ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG'];
			} else {
				allowedCodes = null;
			}
		}

		var list = [
			{ v: 'AUTO', t: _('AUTO (автовыбор)') }
		];
		var seen = { 'AUTO': true };

		var priority = isFreeOnly
			? ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG']
			: ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG', 'MX', 'DE', 'FR', 'CH', 'SE', 'GB', 'ES', 'IT', 'FI', 'TR', 'KZ', 'AE', 'BR', 'AR', 'AU'];

		var freeSet = {};
		var freeList = (sc && sc.free) ? sc.free : ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG'];
		for (var f = 0; f < freeList.length; f++)
			freeSet[freeList[f]] = true;

		var allowedSet = null;
		if (allowedCodes) {
			allowedSet = {};
			for (var a = 0; a < allowedCodes.length; a++)
				allowedSet[allowedCodes[a]] = true;
		}

		for (var p = 0; p < priority.length; p++) {
			var code = priority[p];
			if (allowedSet && !allowedSet[code])
				continue;
			if (!seen[code]) {
				var name = COUNTRY_RU[code] || code;
				var suffix = (!isFreeOnly && freeSet[code]) ? ' [Free]' : '';
				list.push({ v: code, t: name + ' (' + code + ')' + suffix });
				seen[code] = true;
			}
		}

		var rest = [];
		if (allowedSet) {
			for (var c in allowedSet) {
				if (!seen[c]) {
					var label = (COUNTRY_RU[c] || c) + ' (' + c + ')';
					rest.push({ v: c, t: label });
					seen[c] = true;
				}
			}
		} else {
			for (var c2 in COUNTRY_RU) {
				if (!seen[c2]) {
					rest.push({ v: c2, t: COUNTRY_RU[c2] + ' (' + c2 + ')' });
					seen[c2] = true;
				}
			}
		}

		rest.sort(function (a, b) {
			return a.t.localeCompare(b.t, 'ru');
		});

		return list.concat(rest);
	}

	_updateProtonCountriesDropdown(preferredCountry) {
		var sel = this.querySelector('[data-xfree-vpn-field="proton_country"]');
		if (!sel) return;

		var freeSel = this.querySelector('[data-xfree-vpn-field="proton_free_only"]');
		var ipv6Sel = this.querySelector('[data-xfree-vpn-field="proton_require_ipv6"]');

		var freeOnly = freeSel ? freeSel.value : '1';
		var ipv6Only = ipv6Sel ? ipv6Sel.value : '0';
		var curVal = preferredCountry || sel.value || 'AUTO';

		var options = this._getProtonCountryOptions(freeOnly, ipv6Only);

		while (sel.firstChild)
			sel.removeChild(sel.firstChild);

		var valFound = false;
		for (var i = 0; i < options.length; i++) {
			var opt = E('option', { 'value': options[i].v }, [options[i].t]);
			if (options[i].v === curVal) {
				opt.selected = true;
				valFound = true;
			}
			sel.appendChild(opt);
		}

		if (!valFound) {
			sel.value = 'AUTO';
		}
	}

	_fetchProtonCountries(forceRefresh) {
		var self = this;
		if (this._protonCountriesFetching) return;
		this._protonCountriesFetching = true;

		var refreshBtn = this.querySelector('.xfree-vpn-proton-country-refresh');
		if (refreshBtn) {
			refreshBtn.textContent = '⏳';
			refreshBtn.disabled = true;
		}

		xui.runIfaceMenu('protonCountries', forceRefresh ? 'refresh=1' : '').then(function (res) {
			self._protonCountriesFetching = false;
			if (refreshBtn) {
				refreshBtn.textContent = '🔄';
				refreshBtn.disabled = false;
			}

			var raw = (res && (res.stdout || res.output || res)) || '';
			if (typeof raw !== 'string' && typeof raw.toString === 'function')
				raw = raw.toString();

			var sc = { free: [], all: [], v6: [], free_v6: [] };
			var lines = raw.split('\n');
			for (var i = 0; i < lines.length; i++) {
				var line = lines[i].trim();
				if (line.indexOf('PROTON_FREE_COUNTRIES=') === 0) {
					var s = line.substring(22).trim();
					if (s) sc.free = s.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_ALL_COUNTRIES=') === 0) {
					var s2 = line.substring(21).trim();
					if (s2) sc.all = s2.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_V6_COUNTRIES=') === 0) {
					var s3 = line.substring(20).trim();
					if (s3) sc.v6 = s3.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_FREE_V6_COUNTRIES=') === 0) {
					var s4 = line.substring(25).trim();
					if (s4) sc.free_v6 = s4.split(',').filter(Boolean);
				}
			}

			if (sc.all.length > 0) {
				self._protonServerCountries = sc;
				self._protonCountriesLoaded = true;
				self._updateProtonCountriesDropdown();
				if (forceRefresh) {
					self.setMessage(_('Список стран Proton обновлён (%d стран)').format(sc.all.length), 'ok');
				}
			}
		}).catch(function () {
			self._protonCountriesFetching = false;
			if (refreshBtn) {
				refreshBtn.textContent = '🔄';
				refreshBtn.disabled = false;
			}
		});
	}

	_renderImportCard(view, inModal) {
		var self = this;
		var s = this._spec || {};
		var allConfs = (this._summary && this._summary.confs) || [];
		var customConfs = allConfs.filter(function (c) {
			return c.kind === 'custom' || c.kind === 'amnezia' || c.kind === 'openvpn';
		});
		var latestCustom = customConfs[0] || null;

		var fileInput = E('input', {
			'type': 'file',
			'accept': '.conf,.ovpn,.txt',
			'style': 'display: none;'
		});

		var statusNote = E('div', {
			'class': 'xfree-vpn-import-note',
			'style': 'display: none; margin-top: 8px; font-size: 13px; padding: 8px 12px; border-radius: 6px; line-height: 1.4;'
		});

		var ta = E('textarea', {
			'class': 'xfree-uplink-input',
			'rows': 5,
			'placeholder': _('Вставьте текст .conf, .ovpn или ссылку vpn://...'),
			'style': 'width: 100%; font-family: monospace; font-size: 12px; resize: vertical;'
		});

		var nameInput = E('input', {
			'class': 'xfree-uplink-input',
			'type': 'text',
			'placeholder': _('например, amnezia_nl'),
			'style': 'width: 100%;'
		});

		var protoSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%;'
		}, [
			E('option', { 'value': 'auto' }, [_('Автоопределение')]),
			E('option', { 'value': 'awg' }, [_('AmneziaWG / WireGuard (.conf)')]),
			E('option', { 'value': 'openvpn' }, [_('OpenVPN (.ovpn)')])
		]);

		function updateStatus(text, tone) {
			if (!text) {
				statusNote.style.display = 'none';
				statusNote.textContent = '';
				return;
			}
			statusNote.style.display = 'block';
			statusNote.textContent = text;
			if (tone === 'ok') {
				statusNote.style.background = 'rgba(34, 197, 94, 0.1)';
				statusNote.style.border = '1px solid rgba(34, 197, 94, 0.3)';
				statusNote.style.color = '#22c55e';
			} else if (tone === 'warn') {
				statusNote.style.background = 'rgba(234, 179, 8, 0.1)';
				statusNote.style.border = '1px solid rgba(234, 179, 8, 0.3)';
				statusNote.style.color = '#eab308';
			} else {
				statusNote.style.background = 'rgba(59, 130, 246, 0.1)';
				statusNote.style.border = '1px solid rgba(59, 130, 246, 0.25)';
				statusNote.style.color = 'inherit';
			}
		}

		function processText(text) {
			var val = String(text || '').trim();
			if (!val) {
				updateStatus('', '');
				return;
			}
			if (val.indexOf('vpn://') === 0) {
				updateStatus(_('Распаковка ссылки Amnezia vpn://...'), 'info');
				unpackAmneziaVpnKey(val).then(function (jsonObj) {
					var ext = extractAmneziaConfig(jsonObj);
					if (ext && ext.isStatic && ext.confText) {
						ta.value = ext.confText;
						protoSelect.value = (ext.type === 'openvpn') ? 'openvpn' : 'awg';
						if (!nameInput.value.trim() && ext.name) {
							nameInput.value = sanitizeIfaceName(ext.name);
						}
						updateStatus(_('✓ Распакована конфигурация Amnezia: ') + (ext.name || ext.type), 'ok');
					} else if (ext && ext.isSubscription) {
						updateStatus(_('ℹ Обнаружен ключ подписки Amnezia Premium (%s, %s). Скачайте .conf в личном кабинете или приложении Amnezia и вставьте сюда.').format(ext.name, ext.country.toUpperCase()), 'warn');
					} else {
						updateStatus(_('✓ JSON Amnezia распакован, но не содержит last_config'), 'warn');
					}
				}).catch(function (err) {
					updateStatus(_('Ошибка распаковки vpn://: ') + (err && err.message ? err.message : String(err)), 'warn');
				});
			} else if (val.indexOf('[Interface]') >= 0) {
				if (protoSelect.value === 'auto')
					protoSelect.value = 'awg';
				if (val.indexOf('vpn://') >= 0 || val.indexOf('Keenetic:') >= 0 || val.indexOf('HeaderProtectionKey') >= 0 || /\b\w+\s*=\s*\d+\s*-\s*\d+/.test(val)) {
					updateStatus(_('✓ Распознан AmneziaWG / Keenetic (диапазоны значений будут автоматически нормализованы)'), 'ok');
				} else {
					updateStatus(_('✓ Распознан формат WireGuard / AmneziaWG (.conf)'), 'ok');
				}
			} else if (val.indexOf('dev tun') >= 0 || val.indexOf('client') >= 0) {
				if (protoSelect.value === 'auto')
					protoSelect.value = 'openvpn';
				updateStatus(_('✓ Распознан формат OpenVPN (.ovpn)'), 'ok');
			}
		}

		ta.addEventListener('input', function () {
			processText(ta.value);
		});

		fileInput.addEventListener('change', function (ev) {
			var file = ev.target.files && ev.target.files[0];
			if (!file) return;
			var fname = file.name || '';
			if (!nameInput.value.trim()) {
				var base = fname.replace(/\.(conf|ovpn|txt)$/i, '');
				nameInput.value = sanitizeIfaceName(base);
			}
			var reader = new FileReader();
			reader.onload = function (e) {
				ta.value = e.target.result || '';
				processText(ta.value);
			};
			reader.readAsText(file);
		});

		function doSave(shouldCreate) {
			var body = String(ta.value || '').trim();
			if (!body) {
				self.setMessage(_('Введите текст конфигурации или выберите файл'), 'warn');
				return;
			}
			var proto = protoSelect.value;
			if (proto === 'auto') {
				if (body.indexOf('dev tun') >= 0 || body.indexOf('client') >= 0)
					proto = 'openvpn';
				else
					proto = 'awg';
			}
			var isOvpn = (proto === 'openvpn');
			var ext = isOvpn ? '.ovpn' : '.conf';
			var rawName = String(nameInput.value || '').trim();
			if (!rawName)
				rawName = isOvpn ? 'ovpn_1' : 'vpn_1';
			var sanitized = sanitizeIfaceName(rawName);
			var filename = sanitized.indexOf(ext) >= 0 ? sanitized : (sanitized + ext);
			var ifaceName = sanitized.replace(/\.(conf|ovpn)$/i, '');

			var b64;
			try {
				b64 = btoa(unescape(encodeURIComponent(body)));
			} catch {
				self.setMessage(_('Ошибка кодирования текста в base64'), 'bad');
				return;
			}

			var kind = isOvpn ? 'openvpn' : 'custom';
			var arg = kind + '|' + filename + '|b64:' + b64;
			if (shouldCreate) {
				arg += '|create:' + ifaceName;
			}

			if (inModal && typeof ui.hideModal === 'function') {
				ui.hideModal();
			}

			if (s.onAction) {
				var confirmMsg = shouldCreate
					? _('Сохранить %s и создать туннель «%s»?').format(filename, ifaceName)
					: _('Сохранить файл %s в профиль?').format(filename);
				s.onAction('confSave', arg, confirmMsg);
			}
		}

		var cardChildren = [];

		if (!inModal) {
			cardChildren.push(
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap;' }, [
						E('strong', {}, [_('Импорт конфигурации')]),
						E('span', { 'class': 'muted' }, [_('Amnezia / WireGuard / OpenVPN')])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						latestCustom
							? E('span', { 'class': 'xfree-vpn-status is-ok', 'title': latestCustom.created || '' }, ['📄 ' + latestCustom.file])
							: E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('готов к загрузке')])
					])
				])
			);
		}

		cardChildren.push(
			E('div', { 'class': 'xfree-vpn-fields-wrap', 'style': inModal ? 'padding: 4px 0;' : 'padding: 14px;' }, [
				E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;' }, [
					E('span', { 'style': 'font-weight: 500; font-size: 13px;' }, [_('Текст конфига или ссылка vpn://')]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function (ev) {
							ev.preventDefault();
							fileInput.click();
						}
					}, [_('📂 Выбрать файл с диска')]),
					fileInput
				]),
				ta,
				statusNote,
				E('div', { 'class': 'xfree-vpn-fields', 'style': 'margin-top: 12px;' }, [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('label', {}, [_('Имя туннеля / конфига')]),
						nameInput
					]),
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('label', {}, [_('Протокол')]),
						protoSelect
					])
				])
			])
		);

		cardChildren.push(
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': inModal ? 'margin-top: 14px;' : '' }, [
				E('button', {
					'class': 'btn cbi-button-positive',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						doSave(true);
					})
				}, [_('Сохранить и создать туннель')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						doSave(false);
					})
				}, [_('Сохранить файл')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						self._openConfManager('');
					}
				}, [_('Менеджер .conf…')])
			])
		);

		return E('div', {
			'class': inModal ? 'xfree-vpn-import-card is-modal-body' : 'xfree-vpn-gen xfree-vpn-import-card',
			'style': inModal ? 'border: none; background: transparent; padding: 0;' : 'border-left: 3px solid #3b82f6;'
		}, cardChildren);
	}

	_openAddTunnelDialog(view) {
		var self = this;
		var importCard = this._renderImportCard(view, true);

		xui.openDialog({
			title: _('Добавить новый туннель'),
			hint: _('Загрузите файл конфигурации (.conf, .ovpn), вставьте текст или ссылку vpn://'),
			size: 'wide',
			body: E('div', { 'class': 'xfree-vpn-add-dialog', 'style': 'padding: 4px 0;' }, [
				importCard
			]),
			actions: [
				{
					label: _('Выбрать из имеющихся .conf…'),
					variant: 'secondary',
					close: true,
					click: function () {
						self._createFromConf({ preventDefault: function () { }, stopPropagation: function () { } });
					}
				},
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				}
			]
		});
	}

	_collectFieldsIn(root, prefix) {
		var out = {};

		if (!root)
			return out;
		root.querySelectorAll('[data-xfree-vpn-field]').forEach(function (el) {
			var id = el.getAttribute('data-xfree-vpn-field') || '';

			if (prefix && id.indexOf(prefix) !== 0)
				return;
			out[id] = String(el.value || '').trim();
		});

		return out;
	}

	_modalPipeArgs(map, keys, stripPrefix) {
		var parts = [];
		var i;
		var k;
		var short;

		for (i = 0; i < keys.length; i++) {
			k = keys[i];
			short = k;
			if (stripPrefix && k.indexOf(stripPrefix) === 0)
				short = k.slice(stripPrefix.length);
			parts.push(short + '=' + (map[k] != null ? map[k] : ''));
		}

		return parts.join('|');
	}

	_showVpnDialog(title, children) {
		try {
			this.setBusy(false);
			return ui.showModal(title, children, 'cbi-modal', 'xfree-dialog', 'xfree-vpn-dialog');
		} catch (err) {
			this.setBusy(false);
			this.setMessage((err && err.message) ? err.message : String(err), 'bad');
			return null;
		}
	}

	_openNewTunnelDialog(kind, slotHint) {
		var self = this;
		var s = this._spec || {};
		var summary = this._summary || {};
		var warp = summary.warp || {};
		var proton = summary.proton || {};
		var ifaces = summary.ifaces || [];
		var k = String(kind || '').toLowerCase();
		var defaultIface = defaultNewIfaceName(slotHint || k, ifaces, summary);
		var fields = [];
		var body;
		var title;

		this.setBusy(false);

		if (k === 'warp') {
			title = _('Новый туннель WARP');
			var activeWarp = null;
			for (var wi = 0; wi < ifaces.length; wi++) {
				var wName = ifaces[wi].name || ifaces[wi].iface || '';
				var wKind = (ifaces[wi].kind || '').toLowerCase();
				if ((wKind === 'warp' || wName.indexOf('warp') === 0) && ifaces[wi].ifaceUp) {
					activeWarp = wName;
					break;
				}
			}
			if (activeWarp) {
				fields.push(
					E('div', { 'class': 'alert-message warning', 'style': 'margin-bottom:12px' }, [
						_('Внимание: туннель «%s» уже активен (172.16.0.2). Два туннеля WARP имеют одинаковый локальный IP и не должны работать одновременно в ядре Linux. Новый туннель будет создан в режиме ожидания (Standby).').format(activeWarp)
					])
				);
			}
			fields.push(
				textField('new_iface', _('Имя интерфейса'), defaultIface, 'warp'),
				selectField('new_warp_server', _('Сервер'), warp.server || 'def', WARP_SERVERS),
				selectField('new_warp_selection', _('Выбор endpoint'), warp.selection || 'best', WARP_SELECTION),
				selectField('new_warp_exclude_ru', _('Фильтр колоний RU'), warp.excludeRu != null ? String(warp.excludeRu) : '1', [
					{ v: '1', t: _('Вкл — без DME/LED/KJA/SVX') },
					{ v: '0', t: _('Выкл') }
				]),
				selectField('new_warp_profile', _('Профиль AWG'), warp.profile || '2.0:1', WARP_PROFILES),
				selectField('new_warp_mode', _('Режим'), warp.mode || 'local', WARP_MODES),
				selectField('new_warp_i1_mode', _('I1'), warp.i1Mode || 'fixed', WARP_I1),
				textField('new_warp_i1_domain', _('I1 domain/seed'), warp.i1Domain || '', _('для domain')),
				textField('new_warp_name', _('Имя .conf'), warp.name || '', _('авто'))
			);
		} else if (k === 'proton') {
			title = _('Новый туннель Proton');
			var activeProton = null;
			for (var pi = 0; pi < ifaces.length; pi++) {
				var pName = ifaces[pi].name || ifaces[pi].iface || '';
				var pKind = (ifaces[pi].kind || '').toLowerCase();
				if ((pKind === 'proton' || pName.indexOf('proton') === 0) && ifaces[pi].ifaceUp) {
					activeProton = pName;
					break;
				}
			}
			var tune = null;
			if (proton.tune_result) {
				try {
					tune = (typeof proton.tune_result === 'string') ? JSON.parse(proton.tune_result) : proton.tune_result;
				} catch {
					tune = null;
				}
			}
			var defProfile = (tune && (tune.profile || (tune.variant ? '2.0:' + tune.variant : null))) || proton.profile || '2.0:1';
			var defEntropy = (tune && tune.entropy) || proton.i1_entropy || 'r32';
			var defNoise = (tune && tune.noise != null) ? String(tune.noise) : (proton.awg_noise != null ? String(proton.awg_noise) : '0');
			var defPort = (tune && tune.port) || (tune && tune.endpoint && tune.endpoint.indexOf(':') !== -1 ? tune.endpoint.split(':')[1] : (proton.port || 'auto'));
			var defCountry = proton.country || 'NL';
			var defSessionMode = proton.session_mode || 'guest';
			var defSelectionMode = proton.selection_mode || 'best';
			var defMtu = proton.mtu || '1280';
			var defFreeOnly = proton.free_only != null ? String(proton.free_only) : '1';
			var defRequireIpv6 = proton.require_ipv6 != null ? String(proton.require_ipv6) : '0';
			var defVia = proton.via || 'auto';

			if (activeProton) {
				fields.push(
					E('div', { 'class': 'alert-message warning', 'style': 'margin-bottom:12px' }, [
						_('Внимание: туннель «%s» уже активен (10.2.0.2). Два туннеля Proton имеют одинаковый локальный IP и не могут работать одновременно в ядре Linux. Новый туннель будет создан в режиме ожидания (Standby).').format(activeProton)
					])
				);
			}

			if (tune && tune.status === 'OK') {
				fields.push(
					E('div', { 'class': 'alert-message notice', 'style': 'margin-bottom:12px' }, [
						_('Подставлены результаты фонового автоподбора: сервер %s%s, AWG %s, шум=%s, энтропия=%s, порт=%s.').format(
							tune.server_name || _('найден'),
							tune.rtt_ms ? (', ' + tune.rtt_ms + ' ' + _('мс')) : '',
							defProfile,
							defNoise === '1' ? _('Вкл (Jc=4)') : _('Выкл'),
							defEntropy,
							defPort
						)
					])
				);
			}

			if (tune && tune.server_name) {
				fields.push(
					E('input', {
						'type': 'hidden',
						'data-xfree-vpn-field': 'new_proton_server',
						'value': tune.server_name
					})
				);
			}

			fields.push(
				textField('new_iface', _('Имя интерфейса'), defaultIface, 'proton'),
				selectField('new_proton_country', _('Страна'), defCountry, PROTON_COUNTRIES),
				selectField('new_proton_session_mode', _('Сессия'), defSessionMode, [
					{ v: 'guest', t: _('гостевая') },
					{ v: 'permanent', t: _('постоянная') }
				]),
				selectField('new_proton_profile', _('Профиль AWG'), defProfile, WARP_PROFILES),
				selectField('new_proton_i1_entropy', _('Энтропия I1'), defEntropy, PROTON_ENTROPY_OPTIONS),
				selectField('new_proton_awg_noise', _('Шум AWG'), defNoise, PROTON_NOISE_OPTIONS),
				selectField('new_proton_selection_mode', _('Выбор сервера'), defSelectionMode, [
					{ v: 'best', t: 'best' },
					{ v: 'random', t: 'random' }
				]),
				textField('new_proton_mtu', 'MTU', defMtu, '1280'),
				selectField('new_proton_free_only', _('Только free'), defFreeOnly, [
					{ v: '1', t: _('да') },
					{ v: '0', t: _('нет') }
				]),
				selectField('new_proton_require_ipv6', 'IPv6', defRequireIpv6, [
					{ v: '0', t: _('все') },
					{ v: '1', t: _('только IPv6') }
				]),
				selectField('new_proton_port', _('Порт Endpoint'), defPort, [
					{ v: 'auto', t: _('Авто (51820 + перебор: 443, 500, 4500, 1194, 5060)') },
					{ v: '51820', t: '51820 (' + _('по умолчанию') + ')' },
					{ v: '443', t: '443 (HTTPS)' },
					{ v: '500', t: '500 (IPsec/IKEv2)' },
					{ v: '4500', t: '4500 (IPsec NAT-T)' },
					{ v: '1194', t: '1194 (OpenVPN)' },
					{ v: '5060', t: '5060 (SIP)' }
				]),
				selectField('new_proton_via', _('Маршрут подбора'), defVia, (function () {
					var opts = [
						{ v: 'auto', t: _('Авто (через self-route, если настроен)') },
						{ v: 'none', t: _('Напрямую через WAN') }
					];
					var list = (self._summary && self._summary.ifaces) || [];
					for (var vi = 0; vi < list.length; vi++) {
						var iname = list[vi].name || list[vi].iface;
						if (iname)
							opts.push({ v: iname, t: _('Через туннель «%s»').format(iname) });
					}
					return opts;
				})()),
				textField('new_proton_name', _('Имя .conf'), proton.name || '', _('авто'))
			);
		} else {
			this.setMessage(_('Неизвестный тип: %s').format(kind), 'bad');
			return;
		}

		body = E('div', { 'class': 'xfree-vpn-fields xfree-vpn-modal-fields' }, fields);

		this._showVpnDialog(title, [
			E('p', { 'class': 'muted' }, [
				_('Сгенерировать .conf, создать интерфейс в профиле и применить на роутере.')
			]),
			body,
			E('div', { 'class': 'right xfree-vpn-dialog-actions' }, [
				E('button', {
					'type': 'button',
					'class': 'btn',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						ui.hideModal();
					}
				}, [_('Отмена')]),
				' ',
				E('button', {
					'type': 'button',
					'class': 'btn cbi-button-positive',
					'click': function (ev) {
						var f = self._collectFieldsIn(body, '');
						var iface = sanitizeIfaceName(f.new_iface);
						var arg;
						var action;

						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						if (!iface) {
							self.setMessage(_('Укажите имя интерфейса'), 'bad');
							return;
						}
						ui.hideModal();
						if (k === 'warp') {
							action = 'warpProvision';
							arg = iface + '|' + self._modalPipeArgs(f, [
								'new_warp_server', 'new_warp_profile', 'new_warp_mode',
								'new_warp_i1_mode', 'new_warp_i1_domain', 'new_warp_name',
								'new_warp_selection', 'new_warp_exclude_ru'
							], 'new_warp_');
						} else {
							action = 'protonProvision';
							arg = iface + '|' + self._modalPipeArgs(f, [
								'new_proton_country', 'new_proton_session_mode', 'new_proton_profile',
								'new_proton_name', 'new_proton_mtu', 'new_proton_free_only',
								'new_proton_require_ipv6', 'new_proton_selection_mode',
								'new_proton_i1_entropy', 'new_proton_awg_noise',
								'new_proton_port', 'new_proton_via', 'new_proton_server'
							], 'new_proton_');
						}
						if (s.onAction)
							s.onAction(action, arg);
					}
				}, [_('Создать и применить')])
			])
		]);
	}

	_parseMetaText(text) {
		var out = {};
		var lines = String(text || '').split(/\n/);
		var i;
		var line;
		var m;

		for (i = 0; i < lines.length; i++) {
			line = lines[i].replace(/\r$/, '').trim();
			m = line.match(/^META_([A-Z0-9_]+)=(.*)$/);
			if (m)
				out[m[1]] = m[2];
			else if (line.indexOf('IFACE=') === 0)
				out.IFACE = line.slice(6);
		}
		return out;
	}

	_openRebuildDialog(ifaceName, preferKind) {
		var self = this;
		var s = this._spec || {};

		if (!s.onAction) {
			this.setMessage(_('Нет обработчика действия'), 'bad');
			return;
		}

		this.setBusy(true);
		s.onAction('ifaceMeta', ifaceName, null, function (res, text) {
			var meta;
			var kind;
			var fields = [];
			var body;
			var profile;
			var sessionMode;

			self.setBusy(false);
			if (!res || (res.code && res.code !== 0)) {
				self.setMessage(_('Не удалось прочитать meta «%s»').format(ifaceName), 'bad');
				return;
			}
			meta = self._parseMetaText(text || '');
			kind = String(meta.GENERATOR_KIND || preferKind || '').toLowerCase();
			if (kind !== 'warp' && kind !== 'proton') {
				self.setMessage(_('Не удалось прочитать meta «%s»').format(ifaceName), 'bad');
				return;
			}

			if (kind === 'warp') {
				var varId = meta.VARIANT_ID || '1';
				profile = (varId === 'auto') ? '2.0:auto' : ('2.0:' + varId);
				fields = [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [_('Интерфейс')]),
						E('div', {}, [ifaceName])
					]),
					selectField('rb_server', _('Сервер'), meta.SERVER_ID || 'def', WARP_SERVERS),
					selectField('rb_selection', _('Выбор endpoint'), meta.SELECTION_MODE || 'best', WARP_SELECTION),
					selectField('rb_exclude_ru', _('Фильтр колоний RU'), meta.EXCLUDE_RU != null ? String(meta.EXCLUDE_RU) : '1', [
						{ v: '1', t: _('Вкл — без DME/LED/KJA/SVX') },
						{ v: '0', t: _('Выкл') }
					]),
					selectField('rb_profile', _('Профиль AWG'), profile, WARP_PROFILES),
					selectField('rb_mode', _('Режим'), meta.PROFILE_MODE || 'local', WARP_MODES),
					selectField('rb_i1_mode', _('I1'), meta.I1_MODE || 'fixed', WARP_I1),
					textField('rb_i1_domain', _('I1 domain/seed'), meta.I1_DOMAIN || '', _('для domain'))
				];
			} else {
				var varId = meta.VARIANT_ID || '1';
				profile = (varId === 'auto') ? '2.0:auto' : ((meta.AWG_VERSION || '2.0') + ':' + varId);
				sessionMode = (meta.SESSION_AUTH_MODE === 'guest') ? 'guest' : 'permanent';
				var portVal = meta.ENDPOINT_PORT || (meta.ENDPOINT && meta.ENDPOINT.indexOf(':') !== -1 ? meta.ENDPOINT.split(':')[1] : 'auto');
				var srvInfo = meta.SERVER_NAME ? (meta.SERVER_NAME + (meta.ENDPOINT ? ' · ' + meta.ENDPOINT : '')) : (meta.ENDPOINT || '');
				fields = [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [_('Интерфейс')]),
						E('div', {}, [ifaceName])
					]),
					selectField('rb_country', _('Страна'), meta.COUNTRY_FILTER || meta.SERVER_COUNTRY || 'NL', PROTON_COUNTRIES),
					selectField('rb_session_mode', _('Сессия'), sessionMode, [
						{ v: 'guest', t: _('гостевая') },
						{ v: 'permanent', t: _('постоянная') }
					]),
					selectField('rb_profile', _('Профиль AWG'), profile, WARP_PROFILES),
					selectField('rb_i1_entropy', _('Энтропия I1'), meta.AWG_I1_ENTROPY || 'r32', PROTON_ENTROPY_OPTIONS),
					selectField('rb_awg_noise', _('Шум AWG'), meta.AWG_NOISE_ENABLED != null ? String(meta.AWG_NOISE_ENABLED) : '0', PROTON_NOISE_OPTIONS),
					selectField('rb_selection_mode', _('Выбор сервера'), meta.SELECTION_MODE || 'best', [
						{ v: 'best', t: 'best' },
						{ v: 'random', t: 'random' }
					]),
					textField('rb_mtu', 'MTU', meta.MTU || '1280', '1280'),
					selectField('rb_free_only', _('Только free'), meta.FREE_ONLY != null ? String(meta.FREE_ONLY) : '1', [
						{ v: '1', t: _('да') },
						{ v: '0', t: _('нет') }
					]),
					selectField('rb_require_ipv6', 'IPv6', meta.REQUIRE_IPV6 != null ? String(meta.REQUIRE_IPV6) : '0', [
						{ v: '0', t: _('все') },
						{ v: '1', t: _('только IPv6') }
					]),
					selectField('rb_rounds', _('Попытки (раунды по 3)'), meta.PROBE_ROUNDS || '5', [
						{ v: '1', t: _('1 (топ-3)') },
						{ v: '3', t: _('3 (топ-9)') },
						{ v: '5', t: _('5 (топ-15, по умолч.)') },
						{ v: '10', t: _('10 (топ-30)') },
						{ v: '0', t: _('все доступные') }
					]),
					selectField('rb_port', _('Порт Endpoint'), portVal, [
						{ v: 'auto', t: _('Авто (51820 + перебор: 443, 500, 4500, 1194, 5060)') },
						{ v: '51820', t: '51820 (' + _('по умолчанию') + ')' },
						{ v: '443', t: '443 (HTTPS)' },
						{ v: '500', t: '500 (IPsec/IKEv2)' },
						{ v: '4500', t: '4500 (IPsec NAT-T)' },
						{ v: '1194', t: '1194 (OpenVPN)' },
						{ v: '5060', t: '5060 (SIP)' }
					]),
					selectField('rb_via', _('Маршрут подбора'), meta.PROBE_VIA || 'auto', (function () {
						var opts = [
							{ v: 'auto', t: _('Авто (через self-route, если настроен)') },
							{ v: 'none', t: _('Напрямую через WAN') }
						];
						var list = (self._summary && self._summary.ifaces) || [];
						for (var vi = 0; vi < list.length; vi++) {
							var iname = list[vi].name || list[vi].iface;
							if (iname && iname !== ifaceName)
								opts.push({ v: iname, t: _('Через туннель «%s»').format(iname) });
						}
						return opts;
					})())
				];
			}

			body = E('div', { 'class': 'xfree-vpn-fields xfree-vpn-modal-fields' }, fields);
			self._showVpnDialog(_('Пересобрать «%s»').format(ifaceName), [
				E('p', { 'class': 'muted' }, [
					srvInfo ?
						_('Параметры подтянуты из последнего подбора этого интерфейса (%s). Пересборка восстановит конфигурацию для этого же сервера без перебора других нод.').format(srvInfo) :
						_('Параметры из source.conf.meta. После сохранения — новая генерация и apply.')
				]),
				body,
				E('div', { 'class': 'right xfree-vpn-dialog-actions' }, [
					E('button', {
						'type': 'button',
						'class': 'btn',
						'click': function (ev) {
							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							ui.hideModal();
						}
					}, [_('Отмена')]),
					' ',
					E('button', {
						'type': 'button',
						'class': 'btn cbi-button-positive',
						'click': function (ev) {
							var f = self._collectFieldsIn(body, '');
							var arg;

							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							ui.hideModal();
							if (kind === 'warp') {
								arg = ifaceName + '|' + self._modalPipeArgs({
									server: f.rb_server,
									selection: f.rb_selection,
									exclude_ru: f.rb_exclude_ru,
									profile: f.rb_profile,
									mode: f.rb_mode,
									i1_mode: f.rb_i1_mode,
									i1_domain: f.rb_i1_domain,
									rounds: f.rb_rounds
								}, [
									'server', 'selection', 'exclude_ru', 'profile',
									'mode', 'i1_mode', 'i1_domain', 'rounds'
								], '');
							} else {
								arg = ifaceName + '|' + self._modalPipeArgs({
									country: f.rb_country,
									session_mode: f.rb_session_mode,
									profile: f.rb_profile,
									selection_mode: f.rb_selection_mode,
									mtu: f.rb_mtu,
									free_only: f.rb_free_only,
									require_ipv6: f.rb_require_ipv6,
									rounds: f.rb_rounds,
									port: f.rb_port,
									via: f.rb_via,
									i1_entropy: f.rb_i1_entropy,
									awg_noise: f.rb_awg_noise,
									server: meta.SERVER_NAME || '',
									server_id: meta.SERVER_ID || ''
								}, [
									'country', 'session_mode', 'profile', 'selection_mode',
									'mtu', 'free_only', 'require_ipv6', 'rounds', 'port', 'via',
									'i1_entropy', 'awg_noise', 'server', 'server_id'
								], '');
							}
							if (s.onAction)
								s.onAction('regenerateOpts', arg);
						}
					}, [_('Пересобрать и применить')])
				])
			]);
		});
	}

	_openConfManager(filterKind) {
		var self = this;
		var s = this._spec || {};
		var all = (this._summary && this._summary.confs) || [];
		var kindFilter = String(filterKind || '').toLowerCase();
		var confs = [];
		var list;
		var rows = [];
		var i;
		var c;
		var title;
		var hint;

		function reopen() {
			self._openConfManager(kindFilter);
		}

		function downloadText(name, text) {
			var a = document.createElement('a');
			var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });

			a.href = URL.createObjectURL(blob);
			a.download = name;
			document.body.appendChild(a);
			a.click();
			setTimeout(function () {
				URL.revokeObjectURL(a.href);
				a.remove();
			}, 500);
		}

		function showEditor(kind, file, initial) {
			var ta = E('textarea', {
				'class': 'xfree-vpn-conf-editor',
				'rows': 18
			}, [initial || '']);

			xui.openDialog({
				title: _('Редактировать %s').format(file),
				size: 'wide',
				hint: kind + ' / ' + file,
				body: ta,
				actions: [
					{
						label: _('Назад'),
						variant: 'secondary',
						close: true,
						click: function () {
							reopen();
						}
					},
					{
						label: _('Сохранить'),
						variant: 'primary',
						close: false,
						click: function () {
							var body = String(ta.value || '');
							var b64;

							try {
								b64 = btoa(unescape(encodeURIComponent(body)));
							} catch {
								self.setMessage(_('Не удалось закодировать файл'), 'bad');
								return;
							}
							ui.hideModal();
							if (s.onAction)
								s.onAction('confSave', kind + '|' + file + '|b64:' + b64);
						}
					}
				]
			});
		}

		function extractConfBody(text) {
			var raw = String(text || '');
			var a = raw.indexOf('CONF_BODY_BEGIN\n');
			var b = raw.indexOf('\nCONF_BODY_END');

			if (a >= 0 && b > a)
				return raw.slice(a + 'CONF_BODY_BEGIN\n'.length, b);
			return raw;
		}

		function loadAnd(kind, file, mode) {
			if (!s.onAction)
				return;
			self.setBusy(true);
			s.onAction('confShow', kind + '|' + file, null, function (res, text) {
				var body = extractConfBody(text || '');

				self.setBusy(false);
				if (!res || (res.code && res.code !== 0)) {
					self.setMessage(_('Не удалось прочитать %s').format(file), 'bad');
					return;
				}

				if (mode === 'view') {
					xui.openDialog({
						title: _('Просмотр %s').format(file),
						size: 'wide',
						body: E('pre', { 'class': 'xfree-vpn-conf-view' }, [body]),
						actions: [{
							label: _('Назад'),
							variant: 'secondary',
							close: true,
							click: function () {
								reopen();
							}
						}]
					});
				} else if (mode === 'download') {
					downloadText(file, body);
					reopen();
				} else if (mode === 'edit') {
					showEditor(kind, file, body);
				}
			});
		}

		for (i = 0; i < all.length; i++) {
			c = all[i];
			if (kindFilter && String(c.kind || '').toLowerCase() !== kindFilter)
				continue;
			confs.push(c);
		}

		if (!confs.length) {
			this.setMessage(kindFilter
				? _('Нет .conf для «%s» — сначала сгенерируйте').format(kindFilter)
				: _('Нет сгенерированных .conf — сначала сгенерируйте WARP/Proton'), 'warn');
			return;
		}

		var unusedCount = 0;
		for (i = 0; i < confs.length; i++) {
			if (!confs[i].usedBy)
				unusedCount++;
		}

		for (i = 0; i < confs.length; i++) {
			c = confs[i];
			(function (row) {
				var metaBits = [];

				if (!kindFilter && row.kind)
					metaBits.push(row.kind);
				if (row.created)
					metaBits.push(row.created);

				rows.push(E('div', { 'class': 'xfree-vpn-conf-row' }, [
					E('div', { 'class': 'xfree-vpn-conf-name' }, [
						E('div', { 'style': 'display: flex; align-items: center; gap: 8px; flex-wrap: wrap;' }, [
							E('strong', {}, [row.file]),
							row.usedBy
								? E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size: 11px;' }, ['✓ ' + _('используется: %s').format(row.usedBy)])
								: E('span', { 'class': 'xfree-vpn-badge', 'style': 'font-size: 11px;' }, [_('не используется')])
						]),
						metaBits.length
							? E('div', { 'class': 'muted xfree-vpn-conf-meta' }, [
								metaBits.join(' · ')
							])
							: ''
					]),
					E('div', { 'class': 'xfree-vpn-conf-actions' }, [
						xui.dialogBtn({
							label: _('Просмотр'),
							variant: 'ghost',
							compact: true,
							click: function () {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'view');
							}
						}),
						xui.dialogBtn({
							label: _('Скачать'),
							variant: 'ghost',
							compact: true,
							click: function () {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'download');
							}
						}),
						xui.dialogBtn({
							label: _('Изменить'),
							variant: 'ghost',
							compact: true,
							click: function () {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'edit');
							}
						}),
						xui.dialogBtn({
							label: _('Удалить'),
							variant: 'danger',
							compact: true,
							click: function () {
								ui.hideModal();
								if (s.onAction) {
									var confirmMsg = row.usedBy
										? _('ВНИМАНИЕ: конфигурация используется интерфейсом %s! Удалить %s?').format(row.usedBy, row.file)
										: _('Удалить %s?').format(row.file);
									s.onAction('confDelete', row.kind + '|' + row.file, confirmMsg);
								}
							}
						})
					])
				]));
			})(c);
		}

		if (kindFilter === 'warp') {
			title = _('Конфигурации WARP .conf');
			hint = _('Файлы генератора WARP. Дата — локальное время роутера (mtime). После правки — «Обновить» на туннеле.');
		} else if (kindFilter === 'proton') {
			title = _('Конфигурации Proton .conf');
			hint = _('Файлы генератора Proton. Дата — локальное время роутера (mtime). После правки — «Обновить» на туннеле.');
		} else {
			title = _('Конфигурации .conf');
			hint = _('Файлы в каталогах генераторов. Дата — локальное время роутера (mtime).');
		}

		list = E('div', { 'class': 'xfree-vpn-conf-list' }, rows);
		xui.openDialog({
			title: title,
			size: 'lg',
			hint: hint,
			body: list,
			actions: [
				{
					label: unusedCount > 0
						? _('Удалить неиспользуемые (%d)').format(unusedCount)
						: _('Удалить неиспользуемые'),
					variant: 'danger',
					disabled: unusedCount === 0,
					click: function () {
						ui.hideModal();
						if (s.onAction) {
							var confirmMsg = unusedCount > 0
								? _('Удалить неиспользуемые файлы конфигураций (%d шт.)?').format(unusedCount)
								: _('Удалить неиспользуемые файлы конфигураций?');
							s.onAction('confDeleteUnused', kindFilter || '', confirmMsg);
						}
					}
				},
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				}
			]
		});
	}

	_deleteIface(ev, ifaceName) {
		var s = this._spec || {};

		ev.preventDefault();
		ev.stopPropagation();
		this._pickSelect(
			_('Удалить «%s»').format(ifaceName),
			_('Режим очистки'),
			[
				{ v: 'basic', t: _('basic — только туннель') },
				{ v: 'reconcile', t: _('reconcile — + full-reconcile') },
				{ v: 'orphans', t: _('orphans — + cleanup-orphans') },
				{ v: 'full', t: _('full — reconcile + orphans') }
			],
			function (mode) {
				if (s.onAction)
					s.onAction('delete', ifaceName + '|' + mode,
						_('Удалить туннель «%s» (%s)?').format(ifaceName, mode));
			}
		);
	}

	collectFields(prefix) {
		var out = {};

		this.querySelectorAll('[data-xfree-vpn-field]').forEach(function (el) {
			var id = el.getAttribute('data-xfree-vpn-field') || '';

			if (prefix && id.indexOf(prefix) !== 0)
				return;
			out[id] = String(el.value || '').trim();
		});

		return out;
	}

	_pipeArgs(map, keys) {
		var parts = [];
		var i;
		var k;
		var short;

		for (i = 0; i < keys.length; i++) {
			k = keys[i];
			short = k.replace(/^warp_/, '').replace(/^proton_/, '');
			parts.push(short + '=' + (map[k] != null ? map[k] : ''));
		}

		return parts.join('|');
	}

	_saveWarp(ev) {
		var s = this._spec || {};
		var f = this.collectFields('warp_');
		var arg;

		ev.preventDefault();
		arg = this._pipeArgs(f, [
			'warp_server', 'warp_profile', 'warp_mode',
			'warp_i1_mode', 'warp_i1_domain', 'warp_name',
			'warp_selection', 'warp_exclude_ru'
		]);
		if (s.onAction)
			s.onAction('warpSave', arg);
	}

	_saveProton(ev) {
		var s = this._spec || {};
		var f = this.collectFields('proton_');
		var arg;

		ev.preventDefault();
		arg = this._pipeArgs(f, [
			'proton_country', 'proton_session_mode', 'proton_profile',
			'proton_name', 'proton_mtu', 'proton_free_only',
			'proton_require_ipv6', 'proton_selection_mode',
			'proton_i1_entropy', 'proton_awg_noise'
		]);
		if (s.onAction)
			s.onAction('protonSave', arg);
	}

	_renderSelfRouteSection(ifaces, summary, view) {
		var self = this;
		var rows = [];
		var table;
		var i;
		var quickOps = [];
		var hotplugOk = !!(summary && summary.selfRouteHotplug);

		if (!ifaces || ifaces.length === 0)
			return null;

		for (i = 0; i < ifaces.length; i++) {
			(function (row) {
				var target = row.name;
				var currentVia = row.selfRouteVia || '';
				var selEl;
				var opts = [];
				var j;
				var other;
				var applyBtn;
				var resetBtn = null;

				opts.push(E('option', {
					'value': '',
					'selected': !currentVia ? true : null
				}, [_('WAN (напрямую, без туннеля)')]));

				for (j = 0; j < ifaces.length; j++) {
					other = ifaces[j];
					if (other.name === target)
						continue;
					opts.push(E('option', {
						'value': other.name,
						'selected': currentVia === other.name ? true : null
					}, ['➔ ' + other.name + (other.kind ? ' (' + other.kind + ')' : '')]));
				}

				selEl = E('select', {
					'class': 'xfree-uplink-input xfree-selfroute-select',
					'data-selfroute-target': target
				}, opts);

				applyBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						var selectedVia = String(selEl.value || '').trim();
						if (!selectedVia) {
							if (currentVia) {
								self._act(ev, 'selfRouteRemove', target,
									_('Сбросить маршрут для «%s» (направить напрямую через WAN)?').format(target));
							} else {
								self.setMessage(_('Туннель «%s» уже направлен напрямую через WAN').format(target), 'ok');
							}
							return;
						}
						if (selectedVia === currentVia) {
							self.setMessage(
								_('Маршрут %s ➔ %s уже сохранён. Для обновления нажмите «Обновить маршруты».').format(target, currentVia),
								'ok'
							);
							return;
						}
						self._act(ev, 'selfRouteApply', target + '|' + selectedVia,
							_('Направить туннель «%s» через «%s» (%s ➔ %s)?').format(target, selectedVia, target, selectedVia));
					})
				}, [_('Применить')]);

				if (currentVia) {
					resetBtn = E('button', {
						'class': 'ghost ghost-compact',
						'type': 'button',
						'click': ui.createHandlerFn(view, function (ev) {
							self._act(ev, 'selfRouteRemove', target,
								_('Сбросить каскадный маршрут для «%s» (вернуть выход через WAN)?').format(target));
						})
					}, [_('Сбросить')]);
				}

				rows.push(E('tr', { 'class': 'xfree-selfroute-row' }, [
					E('td', { 'class': 'xfree-selfroute-cell-target' }, [
						E('div', { 'class': 'xfree-selfroute-target-box' }, [
							E('span', { 'class': 'xfree-vpn-status-dot is-' + (row.ifaceUp ? 'ok' : 'bad') }),
							E('strong', {}, [target]),
							row.kind ? E('span', { 'class': 'muted font-mono' }, [' (' + row.kind + ')']) : ''
						])
					]),
					E('td', { 'class': 'xfree-selfroute-cell-route' }, [
						currentVia
							? E('span', { 'class': 'xfree-selfroute-pill is-active' }, [
								target + ' ',
								E('span', { 'class': 'xfree-vpn-arrow' }, ['➔']),
								' ' + currentVia
							])
							: E('span', { 'class': 'xfree-selfroute-pill is-wan' }, [
								target + ' ',
								E('span', { 'class': 'muted' }, ['➔ WAN'])
							])
					]),
					E('td', { 'class': 'xfree-selfroute-cell-via' }, [selEl]),
					E('td', { 'class': 'xfree-selfroute-cell-actions' }, [
						applyBtn,
						resetBtn ? ' ' : '',
						resetBtn ? resetBtn : ''
					])
				]));
			})(ifaces[i]);
		}

		table = E('table', { 'class': 'xfree-selfroute-table' }, [
			E('thead', {}, [
				E('tr', {}, [
					E('th', {}, [_('Туннель')]),
					E('th', {}, [_('Текущий маршрут')]),
					E('th', {}, [_('Маршрут через (Via)')]),
					E('th', {}, [_('Действия')])
				])
			]),
			E('tbody', {}, rows)
		]);

		quickOps = [
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Обновить runtime host-routes в ядре (пункт 5)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'selfRouteRunHotplug', '',
						_('Обновить runtime host-routes для всех туннелей в ядре прямо сейчас?'));
				})
			}, ['🔄 ' + _('Обновить маршруты')]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Пересобрать hotplug hook /etc/hotplug.d/iface/95-xfree-toolbox-self-route (пункт 4)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'selfRouteRebuildHotplug', '',
						_('Пересобрать hotplug hook для автоматического поднятия маршрутов?'));
				})
			}, ['⚙️ ' + _('Пересобрать hotplug')]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Полная пересборка и удаление сиротских маршрутов (пункт 6)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'selfRouteCleanup', '',
						_('Выполнить полную пересборку и очистку сиротских маршрутов (cleanup)?'));
				})
			}, ['🧹 ' + _('Очистить сироты (cleanup)')]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Показать текущую конфигурацию self-route и статус hotplug (пункт 1)'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'selfRouteStatus', '');
				})
			}, ['📋 ' + _('Подробный статус')])
		];

		return E('section', { 'class': 'xfree-vpn-section xfree-selfroute-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, ['🔀 ' + _('Исходящие маршруты туннелей (Self-route)')]),
					E('span', {
						'class': 'xfree-vpn-status is-' + (hotplugOk ? 'ok' : 'warn')
					}, [hotplugOk ? 'hotplug: active' : 'hotplug: not set'])
				]),
				E('p', { 'class': 'muted' }, [
					_('Каскадная маршрутизация (туннель через туннель). Направляет endpoint целевого VPN через промежуточный туннель, скрывая реальный IP роутера от провайдера целевого VPN.')
				])
			]),
			ifaces.length < 2
				? E('p', { 'class': 'muted' }, [
					_('Для каскадной маршрутизации требуется хотя бы два созданных туннеля (например, warp и proton).')
				])
				: table,
			E('div', { 'class': 'xfree-selfroute-ops' }, quickOps)
		]);
	}

	_renderPbrBypassSection(ifaces, summary, view) {
		var self = this;
		var uciNets = summary.uciNetworks || [];

		if (!ifaces || ifaces.length === 0)
			return null;

		// 1. Build list of networks: start with UCI networks (lan, guest, etc.)
		var availableNets = (Array.isArray(uciNets) && uciNets.length)
			? uciNets.slice()
			: ['lan', 'guest'];

		if (availableNets.indexOf('lan') === -1)
			availableNets.unshift('lan');
		if (availableNets.indexOf('guest') === -1)
			availableNets.push('guest');

		// Include any networks currently stored in any tunnel's pbrBypass
		ifaces.forEach(function (row) {
			var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
			cur.forEach(function (net) {
				if (availableNets.indexOf(net) === -1)
					availableNets.push(net);
			});
		});

		// 2. Initialize matrix if needed or if summary refreshed
		if (!self._pbrMatrix || self._pbrSummarySeq !== summary) {
			self._pbrMatrix = {};
			ifaces.forEach(function (row) {
				var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
				self._pbrMatrix[row.name] = cur;
			});
			self._pbrSavedSnapshot = JSON.stringify(self._pbrMatrix);
			self._pbrSummarySeq = summary;
		} else {
			// Ensure all current ifaces exist in self._pbrMatrix
			ifaces.forEach(function (row) {
				if (!Array.isArray(self._pbrMatrix[row.name])) {
					var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
					self._pbrMatrix[row.name] = cur;
				}
			});
		}

		var isDirty = JSON.stringify(self._pbrMatrix) !== self._pbrSavedSnapshot;

		var initialMap = {};
		try {
			initialMap = JSON.parse(self._pbrSavedSnapshot || '{}');
		} catch {
			initialMap = {};
		}

		// 3. Header
		var headerCols = [
			E('th', { 'style': 'min-width: 170px;' }, [_('Локальная сеть (Wi-Fi / LAN)')])
		];

		ifaces.forEach(function (row) {
			headerCols.push(E('th', { 'class': 'xfree-pbr-col-tunnel' }, [
				E('div', { 'class': 'xfree-pbr-tunnel-th' }, [
					E('span', { 'class': 'xfree-vpn-status-dot is-' + (row.ifaceUp ? 'ok' : 'bad') }),
					E('strong', {}, [row.name]),
					row.kind ? E('span', { 'class': 'muted font-mono', 'style': 'font-size: 10px;' }, [' (' + row.kind + ')']) : ''
				])
			]));
		});

		headerCols.push(E('th', { 'style': 'text-align: right; min-width: 190px;' }, [_('Быстрые действия')]));

		// 4. Rows
		var rows = [];

		availableNets.forEach(function (net) {
			var rowCells = [];
			var icon = '🌐';
			var desc = '';

			if (net === 'lan') {
				icon = '🏠';
				desc = _(' (основная сеть)');
			} else if (net === 'guest') {
				icon = '👥';
				desc = _(' (гостевой Wi-Fi)');
			} else if (net === 'iot') {
				icon = '💡';
				desc = _(' (умный дом)');
			}

			// Network name cell
			rowCells.push(E('td', { 'class': 'xfree-pbr-cell-net' }, [
				E('span', { 'style': 'margin-right: 6px;' }, [icon]),
				E('strong', { 'class': 'font-mono' }, [net]),
				desc ? E('span', { 'class': 'muted font-xs' }, [desc]) : ''
			]));

			// Per-tunnel checkbox cells
			ifaces.forEach(function (t) {
				var list = self._pbrMatrix[t.name] || [];
				var inBypass = list.indexOf(net) >= 0;
				var initList = initialMap[t.name] || [];
				var initInBypass = initList.indexOf(net) >= 0;
				var isCellModified = (inBypass !== initInBypass);

				var cb = E('input', {
					'type': 'checkbox',
					'class': 'xfree-pbr-matrix-cb',
					'checked': inBypass ? true : null,
					'title': inBypass
						? _('Сеть «%s» исключена из «%s» (трафик идёт в WAN). Нажмите, чтобы направить в VPN.').format(net, t.name)
						: _('Сеть «%s» использует «%s» по спискам VPN. Нажмите, чтобы исключить (пустить в WAN).').format(net, t.name),
					'change': function () {
						var cur = self._pbrMatrix[t.name] || [];
						var idx = cur.indexOf(net);
						if (this.checked && idx === -1) {
							cur.push(net);
						} else if (!this.checked && idx >= 0) {
							cur.splice(idx, 1);
						}
						self._pbrMatrix[t.name] = cur;
						self.requestPaint();
					}
				});

				var cellClasses = ['xfree-pbr-cell-check'];
				if (inBypass) cellClasses.push('is-bypass');
				if (isCellModified) cellClasses.push('is-modified');

				rowCells.push(E('td', { 'class': cellClasses.join(' ') }, [
					E('label', {
						'class': 'xfree-pbr-cb-wrap' + (isCellModified ? ' is-modified' : ''),
						'title': isCellModified ? _('Это значение изменено, но ещё не сохранено') : null
					}, [
						cb,
						E('span', { 'class': 'xfree-pbr-cb-label' }, [inBypass ? _('WAN') : _('VPN')])
					])
				]));
			});

			// Quick action buttons for this row
			var bypassAllBtn = E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Исключить сеть «%s» из ВСЕХ туннелей (всегда направлять через WAN)').format(net),
				'click': function (ev) {
					ev.preventDefault();
					ifaces.forEach(function (t) {
						var cur = self._pbrMatrix[t.name] || [];
						if (cur.indexOf(net) === -1)
							cur.push(net);
						self._pbrMatrix[t.name] = cur;
					});
					self.requestPaint();
				}
			}, [_('В обход всех')]);

			var vpnAllBtn = E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Направлять сеть «%s» через все туннели по спискам маршрутов').format(net),
				'click': function (ev) {
					ev.preventDefault();
					ifaces.forEach(function (t) {
						var cur = self._pbrMatrix[t.name] || [];
						var idx = cur.indexOf(net);
						if (idx >= 0)
							cur.splice(idx, 1);
						self._pbrMatrix[t.name] = cur;
					});
					self.requestPaint();
				}
			}, [_('Все в VPN')]);

			rowCells.push(E('td', { 'style': 'text-align: right; white-space: nowrap;' }, [
				bypassAllBtn,
				' ',
				vpnAllBtn
			]));

			rows.push(E('tr', { 'class': 'xfree-selfroute-row' }, rowCells));
		});

		var table = E('table', { 'class': 'xfree-selfroute-table xfree-pbr-matrix' }, [
			E('thead', {}, [
				E('tr', {}, headerCols)
			]),
			E('tbody', {}, rows)
		]);

		// Unified smart action button (always working, compact, never stretches)
		var actionBtn = E('button', {
			'class': isDirty ? 'btn ghost-compact xfree-pbr-action-btn is-dirty' : 'ghost ghost-compact xfree-pbr-action-btn',
			'type': 'button',
			'title': isDirty
				? _('Сохранить изменения матрицы и переприменить правила маршрутизации')
				: _('Переприменить текущие правила маршрутизации nftables (apply-routing)'),
			'click': function (ev) {
				ev.preventDefault();
				if (isDirty) {
					var bulkArg = ifaces.map(function (t) {
						var nets = (self._pbrMatrix[t.name] || []).join(' ');
						return t.name + '=' + (nets || '-');
					}).join(';');

					self._pbrSavedSnapshot = JSON.stringify(self._pbrMatrix);
					self._act(ev, 'pbrApplyBulk', bulkArg,
						_('Применить новую матрицу исключений PBR для туннелей?'));
				} else {
					self._act(ev, 'applyRouting', '',
						_('Переприменить правила маршрутизации nftables прямо сейчас?'));
				}
			}
		}, [
			isDirty ? ('⚡ ' + _('Сохранить и применить')) : ('⚡ ' + _('Применить маршрутизацию'))
		]);

		var resetBtn = isDirty ? E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'style': 'color: var(--muted);',
			'title': _('Отменить несохранённые изменения и вернуть текущие настройки'),
			'click': function (ev) {
				ev.preventDefault();
				self._pbrMatrix = JSON.parse(self._pbrSavedSnapshot);
				self.requestPaint();
			}
		}, ['🔄 ' + _('Отменить')]) : null;

		var statusBtn = E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'title': _('Показать текущую конфигурацию PBR bypass и nft sets'),
			'click': ui.createHandlerFn(view, function (ev) {
				self._act(ev, 'pbrStatus', '');
			})
		}, ['📋 ' + _('Подробный статус PBR')]);

		var dirtyNotice = isDirty ? E('span', { 'class': 'xfree-pbr-dirty-hint' }, [
			'● ' + _('Есть несохранённые изменения')
		]) : null;

		var toolbar = E('div', { 'class': 'xfree-pbr-matrix-toolbar' }, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
				statusBtn
			]),
			E('div', { 'class': 'xfree-pbr-main-ops' }, [
				dirtyNotice ? dirtyNotice : '',
				resetBtn ? resetBtn : '',
				actionBtn
			])
		]);

		var stateBadge = isDirty
			? E('span', { 'class': 'xfree-vpn-badge is-warn', 'style': 'font-size: 11px;' }, ['● ' + _('Есть изменения')])
			: E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size: 11px;' }, ['✓ ' + _('Сохранено')]);

		return E('section', { 'class': 'xfree-vpn-section xfree-selfroute-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('h4', {}, ['🛡️ ' + _('Матрица сетей без VPN → WAN (PBR Bypass)')]),
						stateBadge
					]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('Policy-Based Routing')])
				]),
				E('p', { 'class': 'muted' }, [
					_('Отметьте ячейки «WAN», чтобы трафик выбранной локальной сети всегда шёл напрямую в интернет через провайдера, минуя соответствующий туннель. Ячейки «VPN» используют туннель по спискам доменов.')
				])
			]),
			table,
			toolbar
		]);
	}

	render() {
		var self = this;
		var s = this._spec || {};
		var view = s.view;
		var summary = this._summary || {};
		var ifaces = summary.ifaces || [];
		var warp = summary.warp || {};
		var proton = summary.proton || {};
		var count = summary.count || ifaces.length || 0;
		var stateOk = summary.stateOk || 0;
		var sourceOk = summary.sourceOk || 0;
		var viaMap = {};
		for (i = 0; i < ifaces.length; i++) {
			if (ifaces[i].selfRouteVia) {
				if (!viaMap[ifaces[i].selfRouteVia])
					viaMap[ifaces[i].selfRouteVia] = [];
				viaMap[ifaces[i].selfRouteVia].push(ifaces[i].name);
			}
		}
		var chips = [];
		var tunnelCards = [];
		var genCards = [];
		var i;
		var iface;
		var sub;
		var viewMode = this._vpnView || 'tunnels';
		var sections = [];
		var createKinds = listCreateKinds(summary);
		var createBtns = [];
		var ci;
		var ck;
		var toneApplied = count > 0 && stateOk === count ? 'ok' : (stateOk > 0 ? 'warn' : 'muted');
		var headHint = viewMode === 'server'
			? _('Управление входящим VPN-сервером AmneziaWG, клиентами, QR-кодами и конфигурациями.')
			: (viewMode === 'protocols'
				? _('Управление установкой компонентов и протоколов VPN на роутере.')
				: (viewMode === 'generators'
					? _('Импорт конфигураций (Amnezia, WireGuard, OpenVPN) и генераторы WARP / Proton.')
					: (viewMode === 'selfroute'
						? _('Каскадная маршрутизация (туннель через туннель). Направляет endpoint целевого VPN через промежуточный туннель, скрывая реальный IP роутера.')
						: (viewMode === 'pbrbypass'
							? _('Policy-Based Routing: прямой выход выбранных локальных сетей в интернет через WAN в обход VPN.')
							: _('Статус профиля и быстрые действия. Списки сайтов — Маршруты → VPN.')))));
		var headTitle = viewMode === 'server'
			? _('VPN-сервер')
			: (viewMode === 'protocols'
				? _('Компоненты')
				: (viewMode === 'generators'
					? _('Генераторы и импорт')
					: (viewMode === 'selfroute'
						? _('Self-route')
						: (viewMode === 'pbrbypass'
							? _('PBR Bypass')
							: _('VPN-туннели')))));

		this.className = 'xfree-vpn-root';
		this.setAttribute('data-xfree-vpn', '1');

		if (viewMode === 'server') {
			var isServerLoading = !!(this._loading || !this._serverLoaded);
			if (isServerLoading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Сервер')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Интерфейс : Порт')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 90px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Подсеть')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 75px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Клиентов')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 25px; height: 14px;' })])
				]));
			} else {
				var awg = this._awgSummary || {};
				var peerCount = (awg.peers && awg.peers.length) || 0;
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.running ? ' is-ok' : ' is-bad') }, [
					E('span', { 'class': 'k' }, [_('Сервер')]),
					E('span', { 'class': 'v' }, [awg.running ? _('активен (UP)') : _('остановлен')])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [_('Интерфейс : Порт')]),
					E('span', { 'class': 'v' }, [(awg.iface || 'awg_ingress') + ' : ' + (awg.port || '51820') + ' UDP'])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [_('Подсеть')]),
					E('span', { 'class': 'v' }, [awg.addr || '10.200.200.1/24'])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (peerCount > 0 ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [_('Клиентов')]),
					E('span', { 'class': 'v' }, [String(peerCount)])
				]));
				if (awg.freeTurnInstalled) {
					chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.freeTurnRunning ? ' is-ok' : '') }, [
						E('span', { 'class': 'k' }, [_('FreeTurn')]),
						E('span', { 'class': 'v' }, [awg.freeTurnRunning ? _('порт %s').format(awg.freeTurnPort || '56000') : _('остановлен')])
					]));
				}
				if (awg.vkInstalled || awg.vkRunning) {
					chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.vkRunning ? ' is-ok' : '') }, [
						E('span', { 'class': 'k' }, [_('VK-Turn')]),
						E('span', { 'class': 'v' }, [awg.vkRunning ? _('порт %s').format(awg.vkPort || '49151') : _('остановлен')])
					]));
				}
			}
		} else if (viewMode === 'generators') {
			if (s.loading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('WARP .conf')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 48px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Proton .conf')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 48px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Всего файлов')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 48px; height: 14px;' })])
				]));
			} else {
				var confsList = summary.confs || [];
				var warpConfsCount = 0;
				var protonConfsCount = 0;
				for (i = 0; i < confsList.length; i++) {
					if (confsList[i].kind === 'warp' || /warp/i.test(confsList[i].file))
						warpConfsCount++;
					else if (confsList[i].kind === 'proton' || /proton/i.test(confsList[i].file))
						protonConfsCount++;
				}
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (warpConfsCount ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [_('WARP .conf')]),
					E('span', { 'class': 'v' }, [warpConfsCount ? ('%d .conf'.format(warpConfsCount)) : _('нет')])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (protonConfsCount ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [_('Proton .conf')]),
					E('span', { 'class': 'v' }, [protonConfsCount ? ('%d .conf'.format(protonConfsCount)) : _('нет')])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (confsList.length ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [_('Всего файлов')]),
					E('span', { 'class': 'v' }, [confsList.length + ' .conf'])
				]));
			}
		} else if (viewMode === 'selfroute') {
			var isSelfRouteLoading = !!(this._loading || (!ifaces.length && !this._summaryLoaded));
			if (isSelfRouteLoading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Туннелей')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Каскадных (Via)')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Прямой WAN')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Hotplug')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 50px; height: 14px;' })])
				]));
			} else {
				var viaCount = 0;
				for (i = 0; i < ifaces.length; i++) {
					if (ifaces[i].selfRouteVia)
						viaCount++;
				}
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [_('Туннелей')]),
					E('span', { 'class': 'v' }, [String(count)])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (viaCount > 0 ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [_('Каскадных (Via)')]),
					E('span', { 'class': 'v' }, [String(viaCount)])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [_('Прямой WAN')]),
					E('span', { 'class': 'v' }, [String(count - viaCount)])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (summary.selfRouteHotplug ? ' is-ok' : ' is-warn') }, [
					E('span', { 'class': 'k' }, [_('Hotplug')]),
					E('span', { 'class': 'v' }, [summary.selfRouteHotplug ? _('активен') : _('не настроен')])
				]));
			}
		} else if (viewMode === 'pbrbypass') {
			var isPbrLoading = !!(this._loading || (!ifaces.length && !this._summaryLoaded));
			if (isPbrLoading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Сетей (LAN/VLAN)')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Туннелей')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Bypass в WAN')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' })])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [_('Режим')]),
					E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 60px; height: 14px;' })])
				]));
			} else {
				var uciNets = summary.uciNetworks || [];
				var availableNets = (Array.isArray(uciNets) && uciNets.length) ? uciNets.slice() : ['lan', 'guest'];
				if (availableNets.indexOf('lan') === -1)
					availableNets.unshift('lan');
				var activeBypassCount = 0;
				for (i = 0; i < ifaces.length; i++) {
					var pbrList = ifaces[i].pbrBypassNets || [];
					for (var ni = 0; ni < availableNets.length; ni++) {
						if (pbrList.indexOf(availableNets[ni]) !== -1)
							activeBypassCount++;
					}
				}
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [_('Сетей (LAN/VLAN)')]),
					E('span', { 'class': 'v' }, [String(availableNets.length)])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [_('Туннелей')]),
					E('span', { 'class': 'v' }, [String(ifaces.length)])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (activeBypassCount > 0 ? ' is-warn' : '') }, [
					E('span', { 'class': 'k' }, [_('Bypass в WAN')]),
					E('span', { 'class': 'v' }, [String(activeBypassCount)])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-ok' }, [
					E('span', { 'class': 'k' }, [_('Режим')]),
					E('span', { 'class': 'v' }, [_('Policy Routing')])
				]));
			}
		} else if ((this._loading || s.loading) && !this._summaryLoaded) {
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [_('Туннели')]),
				E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 28px; height: 14px;' })])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [_('В state')]),
				E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 44px; height: 14px;' })])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [_('Source')]),
				E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 44px; height: 14px;' })])
			]));
		} else {
			chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [_('Туннели')]),
				E('span', { 'class': 'v' }, [String(count)])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-' + toneApplied }, [
				E('span', { 'class': 'k' }, [_('В state')]),
				E('span', { 'class': 'v' }, ['%s / %s'.format(stateOk, count || '0')])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' + (sourceOk === count && count ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [_('Source')]),
				E('span', { 'class': 'v' }, ['%s / %s'.format(sourceOk, count || '0')])
			]));
		}

		if (s.loading && !ifaces.length) {
			tunnelCards.push(renderTunnelSkeleton());
			tunnelCards.push(renderTunnelSkeleton());
		}

		for (i = 0; i < ifaces.length; i++) {
			iface = ifaces[i];
			sub = [];
			if (iface.kind)
				sub.push(iface.kind);
			if (iface.server)
				sub.push(iface.server);
			if (iface.country)
				sub.push(countryName(iface.country));
			if (iface.city && String(iface.kind || '').toLowerCase() === 'proton')
				sub.push(iface.city);
			if (iface.colo)
				sub.push(coloLabel(iface.colo));
			(function (row) {
				var tone = healthTone(row.health);
				var statusBits = [];
				var metaRows = [];
				var cardClass = 'xfree-vpn-tunnel is-' + tone;
				var kindLc = String(row.kind || '').toLowerCase();
				var cityOk = row.city && (kindLc === 'proton' ||
					!/^(cf-|[0-9])/i.test(row.city));
				var countryShow = countryName(row.country || coloCountry(row.colo));
				var coloShow = coloLabel(row.colo);

				statusBits.push(E('span', {
					'class': 'xfree-vpn-status is-' + tone
				}, [healthLabel(row.health)]));
				statusBits.push(E('span', {
					'class': 'xfree-vpn-status is-' + (row.ifaceUp ? 'ok' : 'bad')
				}, [row.ifaceUp ? 'UP' : 'DOWN']));
				if (!row.ifaceUp) {
					var hasActiveSameKind = false;
					for (var oi = 0; oi < ifaces.length; oi++) {
						if (ifaces[oi].name !== row.name && ifaces[oi].ifaceUp) {
							var okind = String(ifaces[oi].kind || '').toLowerCase();
							if ((kindLc === 'proton' && (okind === 'proton' || ifaces[oi].name.indexOf('proton') === 0)) ||
								(kindLc === 'warp' && (okind === 'warp' || ifaces[oi].name.indexOf('warp') === 0))) {
								hasActiveSameKind = true;
								break;
							}
						}
					}
					if (hasActiveSameKind) {
						statusBits.push(E('span', { 'class': 'xfree-vpn-status is-muted', 'title': _('Режим ожидания: активен другой туннель этого сервиса') }, [_('standby')]));
					}
				}
				if (row.rtOk)
					statusBits.push(E('span', { 'class': 'xfree-vpn-status is-ok' }, ['rt']));
				else if (row.lists === 0)
					statusBits.push(E('span', { 'class': 'xfree-vpn-status' }, [_('empty')]));
				else if (row.state)
					statusBits.push(E('span', { 'class': 'xfree-vpn-status is-warn' }, [_('apply?')]));

				if (countryShow)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [_('страна')]),
						E('span', {}, [countryShow])
					]));
				if (cityOk)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [_('город')]),
						E('span', {}, [row.city])
					]));
				if (coloShow)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [_('колония')]),
						E('span', {}, [coloShow])
					]));
				else if (kindLc === 'warp')
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [_('колония')]),
						E('span', { 'class': 'muted' }, [_('нет в meta')])
					]));
				if (row.probe)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, ['probe']),
						E('span', {}, [row.probe])
					]));
				if (row.proton)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, ['proton']),
						E('span', {}, [row.proton + (row.sess ? ' · ' + row.sess : '')])
					]));
				if (row.cert)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, ['cert']),
						E('span', {}, [row.cert])
					]));
				if (row.dev && row.dev !== row.name)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, ['dev']),
						E('span', {}, [row.dev])
					]));
				if (row.selfRouteVia) {
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv xfree-vpn-kv-route is-target' }, [
						E('em', {}, [_('через')]),
						E('span', { 'class': 'xfree-vpn-route-chip' }, [
							'➔ ',
							E('strong', {}, [row.selfRouteVia])
						])
					]));
				}
				if (viaMap[row.name] && viaMap[row.name].length) {
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv xfree-vpn-kv-route is-gateway' }, [
						E('em', {}, [_('шлюз для')]),
						E('span', { 'class': 'xfree-vpn-gw-chip' }, [
							'⮡ ' + viaMap[row.name].join(', ')
						])
					]));
				}

				tunnelCards.push(E('div', { 'class': cardClass }, [
					E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
						E('strong', {}, [row.name]),
						E('div', { 'class': 'xfree-vpn-status-row' }, statusBits)
					]),
					sub.length ? E('div', { 'class': 'xfree-vpn-tunnel-sub muted' }, [sub.join(' · ')]) : '',
					metaRows.length
						? E('div', { 'class': 'xfree-vpn-tunnel-meta' }, metaRows)
						: E('div', { 'class': 'xfree-vpn-tunnel-meta muted' }, [
							_('Нет данных probe — проверьте монитор')
						]),
					E('div', { 'class': 'xfree-vpn-badges' }, [
						badge('work', row.work),
						badge('state', row.state),
						badge('gen', row.gen),
						badge('src', row.source)
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-actions' }, [
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'click': ui.createHandlerFn(view, function (ev) {
								self._act(ev, 'applyOne', row.name,
									_('Применить туннель «%s»?').format(row.name));
							})
						}, [_('Применить')]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'title': row.lists
								? _('Списки маршрутов для «%s» (%d активных). Нажмите для перехода в «Маршруты»').format(row.name, row.lists)
								: _('Списки маршрутов для «%s». Нажмите для перехода в «Маршруты»').format(row.name),
							'click': function (ev) {
								if (ev) {
									ev.preventDefault();
									ev.stopPropagation();
								}
								if (s.onNavigate)
									s.onNavigate('routing', 'vpn', row.name);
								else if (view && view.navigate)
									view.navigate('routing', 'vpn', row.name);
							}
						}, [_('Списки')]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'click': ui.createHandlerFn(view, function (ev) {
								self._updateIface(ev, row.name, row.kind || '');
							})
						}, [_('Обновить')]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'click': function (ev) {
								if (ev) {
									ev.preventDefault();
									ev.stopPropagation();
								}
								try {
									self._openRebuildDialog(row.name, row.kind || '');
								} catch (err) {
									self.setBusy(false);
									self.setMessage((err && err.message) ? err.message : String(err), 'bad');
								}
							}
						}, [_('Пересобрать')]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'click': ui.createHandlerFn(view, function (ev) {
								self._act(ev, 'show', row.name);
							})
						}, [_('Файлы')]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'click': ui.createHandlerFn(view, function (ev) {
								self._deleteIface(ev, row.name);
							})
						}, [_('Удалить')])
					])
				]));
			})(iface);
		}

		if (viewMode === 'tunnels') {
			for (ci = 0; ci < createKinds.length; ci++) {
				ck = createKinds[ci];
				(function (row) {
					createBtns.push(E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function (ev) {
							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							try {
								self._openNewTunnelDialog(row.kind, row.slot);
							} catch (err) {
								self.setBusy(false);
								self.setMessage((err && err.message) ? err.message : String(err), 'bad');
							}
						}
					}, ['+ ' + createKindLabel(row.kind)]));
				})(ck);
			}
			createBtns.push(E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': ui.createHandlerFn(view, function (ev) {
					ev.preventDefault();
					self._openAddTunnelDialog(view);
				})
			}, [_('загрузить…')]));
			createBtns.push(E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': ui.createHandlerFn(view, function (ev) {
					self._createFromConf(ev);
				})
			}, [_('из conf')]));
			tunnelCards.push(E('div', { 'class': 'xfree-vpn-tunnel is-new' }, [
				E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
					E('strong', {}, [_('Новый')]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('создать')])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-sub muted' }, [
					_('Генерация .conf → интерфейс → apply')
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-actions xfree-vpn-create-actions' }, createBtns)
			]));
		}

		var allConfs = summary.confs || [];
		var warpLatestConf = null;
		var protonLatestConf = null;
		var warpTunnel = null;
		var protonTunnel = null;
		for (i = 0; i < allConfs.length; i++) {
			if (!warpLatestConf && (allConfs[i].kind === 'warp' || /warp/i.test(allConfs[i].file)))
				warpLatestConf = allConfs[i];
			if (!protonLatestConf && (allConfs[i].kind === 'proton' || /proton/i.test(allConfs[i].file)))
				protonLatestConf = allConfs[i];
		}
		for (i = 0; i < ifaces.length; i++) {
			if (!warpTunnel && String(ifaces[i].kind || ifaces[i].name || '').toLowerCase().indexOf('warp') >= 0)
				warpTunnel = ifaces[i];
			if (!protonTunnel && String(ifaces[i].kind || ifaces[i].name || '').toLowerCase().indexOf('proton') >= 0)
				protonTunnel = ifaces[i];
		}

		var warpCard = E('div', {
			'class': 'xfree-vpn-gen',
			'style': 'align-self: start; height: auto; min-height: 0; justify-content: flex-start;'
		}, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title' }, [
					E('strong', {}, [_('WARP')]),
					E('span', { 'class': 'muted' }, [_('генератор')])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, s.loading ? [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 72px; height: 18px; border-radius: 999px;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 88px; height: 18px; border-radius: 999px;' })
				] : [
					warpLatestConf
						? E('span', { 'class': 'xfree-vpn-status is-ok', 'title': warpLatestConf.created || '' }, ['📄 ' + warpLatestConf.file])
						: E('span', { 'class': 'xfree-vpn-status is-warn' }, [_('нет .conf')]),
					warpTunnel
						? E('span', { 'class': 'xfree-vpn-status is-' + (warpTunnel.ifaceUp ? 'ok' : 'bad') }, ['🔗 ' + warpTunnel.name + ' (' + (warpTunnel.ifaceUp ? 'UP' : 'DOWN') + ')'])
						: E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('туннель не добавлен')])
				])
			]),
			E('div', { 'class': 'xfree-vpn-fields-wrap' }, [
				E('div', { 'class': 'xfree-vpn-fields' }, [
					selectField('warp_server', _('Сервер'), warp.server || 'xfree', WARP_SERVERS),
					selectField('warp_selection', _('Выбор endpoint'), warp.selection || 'best', WARP_SELECTION),
					selectField('warp_exclude_ru', _('Фильтр колоний RU'), warp.excludeRu != null ? String(warp.excludeRu) : '1', [
						{ v: '1', t: _('Вкл — без DME/LED/KJA/SVX') },
						{ v: '0', t: _('Выкл') }
					]),
					selectField('warp_profile', _('Профиль AWG'), warp.profile || '2.0:1', WARP_PROFILES),
					selectField('warp_mode', _('Режим'), warp.mode || 'local', WARP_MODES),
					selectField('warp_i1_mode', _('I1'), warp.i1Mode || 'fixed', WARP_I1),
					textField('warp_i1_domain', _('I1 domain/seed'), warp.i1Domain || '', _('для domain')),
					textField('warp_name', _('Имя файла'), warp.name || '', _('авто'))
				]),
				warpServerTip(),
				warpServerNeedsReg(warp.server)
					? E('p', { 'class': 'xfree-vpn-tip is-warn' }, [
						_('Сейчас выбран сервер со страной (рег.) — без активации в боте llimonix туннель через tribukvy может не работать.')
					])
					: '',
				warpServerIsLte(warp.server)
					? E('p', { 'class': 'xfree-vpn-tip' }, [
						_('Сейчас выбран [LTE]: без бота; endpoint tel.*.tribukvy.ltd, порты как на сайте (ltePL ≠988, lteFL ≠1010).')
					])
					: ''
			]),
			E('div', {
				'class': 'xfree-vpn-tunnel-actions',
				'style': 'margin-top: 10px; flex: 0 0 auto;'
			}, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('warp_'), [
							'warp_server', 'warp_profile', 'warp_mode',
							'warp_i1_mode', 'warp_i1_domain', 'warp_name',
							'warp_selection', 'warp_exclude_ru'
						]);
						self._act(ev, arg ? 'warpSaveAndGenerate' : 'warpGenerate', arg,
							_('Сгенерировать WARP .conf с текущими параметрами?'));
					})
				}, [_('Сгенерировать')]),
				E('button', {
					'class': 'btn ghost-compact is-primary',
					'type': 'button',
					'title': _('Автоматический подбор оптимального варианта AWG и минимального RTT'),
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('warp_'), [
							'warp_server', 'warp_selection', 'warp_exclude_ru'
						]);
						self._act(ev, 'warpTune', arg,
							_('Запустить автоподбор параметров WARP? Будут протестированы различные комбинации AWG и выбран рабочий вариант с минимальной задержкой.'));
					})
				}, ['⚡ ' + _('Автоподбор')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						self._saveWarp(ev);
					})
				}, [_('Сохранить')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						try {
							self._openConfManager('warp');
						} catch (err) {
							self.setBusy(false);
							self.setMessage((err && err.message) ? err.message : String(err), 'bad');
						}
					}
				}, [_('.conf…')])
			])
		]);

		var protonCountryField = E('div', { 'class': 'xfree-vpn-field' }, [
			E('div', { 'class': 'xfree-vpn-field-label', 'style': 'display: flex; justify-content: space-between; align-items: center;' }, [
				E('span', {}, [_('Страна')]),
				E('button', {
					'class': 'ghost ghost-compact xfree-vpn-proton-country-refresh',
					'type': 'button',
					'title': _('Обновить список стран с серверов Proton'),
					'style': 'padding: 0 4px; font-size: 11px; height: 18px; line-height: 18px; border: none; background: transparent; cursor: pointer;',
					'click': function (ev) {
						ev.preventDefault();
						ev.stopPropagation();
						self._fetchProtonCountries(true);
					}
				}, [self._protonCountriesFetching ? '⏳' : '🔄'])
			]),
			E('select', {
				'class': 'xfree-uplink-input',
				'data-xfree-vpn-field': 'proton_country'
			})
		]);

		var protonFreeOnlySelect = E('select', {
			'class': 'xfree-uplink-input',
			'data-xfree-vpn-field': 'proton_free_only'
		}, [
			E('option', { 'value': '1', 'selected': (proton.free_only !== '0' && proton.free_only !== 0) ? true : null }, [_('да')]),
			E('option', { 'value': '0', 'selected': (proton.free_only === '0' || proton.free_only === 0) ? true : null }, [_('нет')])
		]);

		var protonIpv6Select = E('select', {
			'class': 'xfree-uplink-input',
			'data-xfree-vpn-field': 'proton_require_ipv6'
		}, [
			E('option', { 'value': '0', 'selected': (proton.require_ipv6 !== '1' && proton.require_ipv6 !== 1) ? true : null }, [_('все')]),
			E('option', { 'value': '1', 'selected': (proton.require_ipv6 === '1' || proton.require_ipv6 === 1) ? true : null }, [_('только IPv6')])
		]);

		protonFreeOnlySelect.addEventListener('change', function () {
			self._updateProtonCountriesDropdown();
		});
		protonIpv6Select.addEventListener('change', function () {
			self._updateProtonCountriesDropdown();
		});

		var protonCard = E('div', {
			'class': 'xfree-vpn-gen',
			'style': 'align-self: start; height: auto; min-height: 0; justify-content: flex-start;'
		}, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title' }, [
					E('strong', {}, [_('Proton')]),
					E('span', { 'class': 'muted' }, [_('генератор')])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, s.loading ? [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 72px; height: 18px; border-radius: 999px;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 88px; height: 18px; border-radius: 999px;' })
				] : [
					protonLatestConf
						? E('span', { 'class': 'xfree-vpn-status is-ok', 'title': protonLatestConf.created || '' }, ['📄 ' + protonLatestConf.file])
						: E('span', { 'class': 'xfree-vpn-status is-warn' }, [_('нет .conf')]),
					protonTunnel
						? E('span', { 'class': 'xfree-vpn-status is-' + (protonTunnel.ifaceUp ? 'ok' : 'bad') }, ['🔗 ' + protonTunnel.name + ' (' + (protonTunnel.ifaceUp ? 'UP' : 'DOWN') + ')'])
						: E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('туннель не добавлен')])
				])
			]),
			E('div', { 'class': 'xfree-vpn-fields-wrap' }, [
				E('div', { 'class': 'xfree-vpn-fields' }, [
					protonCountryField,
					selectField('proton_session_mode', _('Сессия'), proton.session_mode || 'guest', [
						{ v: 'guest', t: _('гостевая') },
						{ v: 'permanent', t: _('постоянная') }
					]),
					selectField('proton_profile', _('Профиль AWG'), proton.profile || '2.0:1', WARP_PROFILES),
					selectField('proton_i1_entropy', _('Энтропия I1'), proton.i1_entropy || 'r32', PROTON_ENTROPY_OPTIONS),
					selectField('proton_awg_noise', _('Шум AWG'), proton.awg_noise || '0', PROTON_NOISE_OPTIONS),
					selectField('proton_selection_mode', _('Выбор сервера'), proton.selection_mode || 'best', [
						{ v: 'best', t: 'best' },
						{ v: 'random', t: 'random' }
					]),
					textField('proton_mtu', 'MTU', proton.mtu || '1280', '1280'),
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [_('Только free')]),
						protonFreeOnlySelect
					]),
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, ['IPv6']),
						protonIpv6Select
					]),
					textField('proton_name', _('Имя файла'), proton.name || '', _('авто'))
				])
			]),
			E('div', {
				'class': 'xfree-vpn-tunnel-actions',
				'style': 'margin-top: 10px; flex: 0 0 auto;'
			}, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('proton_'), [
							'proton_country', 'proton_session_mode', 'proton_profile',
							'proton_name', 'proton_mtu', 'proton_free_only',
							'proton_require_ipv6', 'proton_selection_mode',
							'proton_i1_entropy', 'proton_awg_noise'
						]);
						self._act(ev, arg ? 'protonSaveAndGenerate' : 'protonGenerate', arg,
							_('Сгенерировать Proton .conf через API (raw)?'));
					})
				}, [_('Сгенерировать')]),
				E('button', {
					'class': 'btn ghost-compact is-primary',
					'type': 'button',
					'title': _('Автоматический подбор оптимального варианта AWG, энтропии и шума'),
					'click': ui.createHandlerFn(view, function (ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('proton_'), [
							'proton_country', 'proton_session_mode', 'proton_free_only',
							'proton_require_ipv6', 'proton_selection_mode'
						]);
						self._act(ev, 'protonTune', arg,
							_('Запустить автоподбор параметров Proton? Будут протестированы различные комбинации AWG и выбран рабочий сервер с минимальной задержкой.'));
					})
				}, ['⚡ ' + _('Автоподбор')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function (ev) {
						self._saveProton(ev);
					})
				}, [_('Сохранить')]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function (ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						try {
							self._openConfManager('proton');
						} catch (err) {
							self.setBusy(false);
							self.setMessage((err && err.message) ? err.message : String(err), 'bad');
						}
					}
				}, [_('.conf…')])
			])
		]);

		genCards.push(warpCard);
		genCards.push(protonCard);
		genCards.push(this._renderImportCard(view));

		setTimeout(function () {
			self._updateProtonCountriesDropdown(proton.country || 'AUTO');
			if (!self._protonServerCountries && !self._protonCountriesFetching) {
				self._fetchProtonCountries(false);
			}
		}, 0);

		var isRefreshing = !!(this._loading || this._busy);
		var topOps = [
			E('button', {
				'class': 'ghost ghost-compact xfree-vpn-head-btn' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние туннелей и интерфейсов'),
				'click': ui.createHandlerFn(view, function (ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				})
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, ['🔄']),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить статус'))
			])
		];


		if (viewMode === 'tunnels' && ifaces.length > 0) {
			topOps.push(E('button', {
				'class': 'btn ghost-compact xfree-vpn-head-btn is-primary',
				'type': 'button',
				'title': _('Применить конфигурацию всех туннелей профиля'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'applyAll', '',
						_('Применить все туннели профиля?'));
				})
			}, ['⚡ ' + _('Применить все')]));
		}



		if (viewMode === 'overview') {
			var vpnHeadIco = E('span', { 'class': 'stat-ico', 'aria-hidden': 'true', 'style': 'display:inline-flex; vertical-align:middle; margin-right:6px;' });
			vpnHeadIco.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 4.5 3.2 8 8 9 4.8-1 8-4.5 8-9V7z"/><path d="M9.5 12.5 11 14l3.5-3.5"/></svg>';

			var overviewHead = E('div', { 'class': 'xfree-overview-vpn-head' }, [
				E('div', { 'class': 'xfree-overview-vpn-title-wrap' }, [
					E('h3', {}, [
						vpnHeadIco,
						_('VPN-туннели')
					]),
					E('p', { 'class': 'muted xfree-overview-vpn-subhead' }, [
						_('Туннели профиля WireGuard/AWG и маршрутизация')
					])
				]),
				E('div', { 'class': 'xfree-overview-vpn-head-actions' }, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Открыть полный раздел управления туннелями'),
						'click': function (ev) {
							self._nav(ev, 'vpn.tunnels');
						}
					}, [_('Управление туннелями ➔')])
				])
			]);

			sections.push(overviewHead);
			sections.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-top: 8px;' }, [
				tunnelCards.length
					? E('div', { 'class': 'xfree-vpn-tunnels' }, tunnelCards)
					: E('p', { 'class': 'muted' }, [
						_('Туннели не найдены — создайте из .conf или на вкладке «Генераторы и импорт».')
					])
			]));

			this.replaceChildren.apply(this, sections);
			if (this._busy) {
				this.querySelectorAll('button').forEach(function (el) {
					el.disabled = true;
				});
			}
			return;
		}

		sections.push(
			E('div', { 'class': 'xfree-vpn-head' }, [
				E('div', { 'class': 'xfree-vpn-head-left' }, [
					E('h3', {}, [headTitle]),
					E('p', { 'class': 'muted' }, [headHint])
				]),
				E('div', { 'class': 'xfree-vpn-head-right' }, [
					E('div', { 'class': 'xfree-vpn-head-actions' }, topOps),
					E('div', {
						'class': 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
						'data-xfree-vpn-msg': '1'
					}, [this._msg || ''])
				])
			]),
			E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips)
		);

		if (viewMode === 'tunnels') {
			sections.push(
				E('section', { 'class': 'xfree-vpn-section' }, [
					E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;' }, [
						E('h4', { 'style': 'margin: 0;' }, [_('Туннели профиля')]),
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'click': function (ev) {
								ev.preventDefault();
								self._openAddTunnelDialog(view);
							}
						}, [_('+ Добавить туннель')])
					]),
					tunnelCards.length
						? E('div', { 'class': 'xfree-vpn-tunnels' }, tunnelCards)
						: E('p', { 'class': 'muted' }, [
							_('Туннели не найдены — создайте из .conf или на вкладке «Генераторы и импорт».')
						])
				])
			);
		} else if (viewMode === 'server') {
			var srvEl = E('xfree-vpn-server');
			srvEl.mount({
				view: view,
				loading: this._loading,
				expert: this._spec && this._spec.expert,
				awgSummary: this._awgSummary || {},
				onRefresh: s.onRefresh,
				onNavigate: s.onNavigate,
				onAction: s.onAction
			});
			sections.push(srvEl);
		} else if (viewMode === 'selfroute') {
			var selfRouteSec = this._renderSelfRouteSection(ifaces, summary, view);
			if (selfRouteSec)
				sections.push(selfRouteSec);
			else
				sections.push(E('p', { 'class': 'muted' }, [
					_('Туннели не найдены. Создайте туннели для настройки исходящей маршрутизации.')
				]));
		} else if (viewMode === 'pbrbypass') {
			var pbrSec = this._renderPbrBypassSection(ifaces, summary, view);
			if (pbrSec)
				sections.push(pbrSec);
			else
				sections.push(E('p', { 'class': 'muted' }, [
					_('Туннели не найдены. Создайте туннели для настройки матрицы PBR.')
				]));
		} else if (viewMode === 'generators') {
			sections.push(
				E('section', { 'class': 'xfree-vpn-section' }, [
					E('div', { 'class': 'xfree-vpn-gens' }, genCards)
				])
			);
		} else if (viewMode === 'devicepolicy') {
			var dpEl = E('xfree-vpn-devicepolicy');
			dpEl.mount({
				view: view,
				loading: this._loading,
				devices: this._spec && this._spec.devices,
				leases: this._spec && this._spec.leases,
				onRefresh: s.onRefresh
			});
			sections.push(dpEl);
		} else {
			sections.push(
				E('section', { 'class': 'xfree-vpn-section' }, [
					E('h4', {}, [_('Туннели профиля')]),
					tunnelCards.length
						? E('div', { 'class': 'xfree-vpn-tunnels' }, tunnelCards)
						: E('p', { 'class': 'muted' }, [
							_('Туннели не найдены — создайте из .conf или на вкладке «Генераторы и импорт».')
						])
				])
			);
		}

		this.replaceChildren.apply(this, sections);

		if (this._busy) {
			this.querySelectorAll('button').forEach(function (el) {
				el.disabled = true;
			});
		}
	}
});

return baseclass.extend({
	tag: TAG,
	COUNTRY_RU: COUNTRY_RU,
	WARP_COLO: WARP_COLO,
	countryName: countryName,
	coloLabel: coloLabel,
	coloCountry: coloCountry,
	coloCity: coloCity,
	healthTone: healthTone,
	healthLabel: healthLabel,
	badge: badge,
	renderTunnelSkeleton: renderTunnelSkeleton
});
