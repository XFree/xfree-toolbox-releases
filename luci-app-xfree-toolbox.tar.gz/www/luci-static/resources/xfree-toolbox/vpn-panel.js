'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-vpn';

function flagTone(ok) {
	return ok ? 'ok' : 'muted';
}

function badge(label, ok) {
	return E('span', {
		'class': 'xfree-vpn-badge is-' + flagTone(ok)
	}, [ label + (ok ? ' ✓' : ' —') ]);
}

function healthTone(health) {
	var h = String(health || '').toLowerCase();

	if (h === 'ok') return 'ok';
	if (h === 'warn') return 'warn';
	if (h === 'fail') return 'bad';
	return 'muted';
}

function healthLabel(health) {
	var h = String(health || '').toLowerCase();

	if (h === 'ok') return 'OK';
	if (h === 'warn') return 'WARN';
	if (h === 'fail') return 'FAIL';
	return '—';
}

/* ISO country code → Russian name */
var COUNTRY_RU = {
	AD: 'Андорра',
	AE: 'ОАЭ',
	AF: 'Афганистан',
	AL: 'Албания',
	AM: 'Армения',
	AO: 'Ангола',
	AR: 'Аргентина',
	AT: 'Австрия',
	AU: 'Австралия',
	AZ: 'Азербайджан',
	BA: 'Босния и Герцеговина',
	BB: 'Барбадос',
	BD: 'Бангладеш',
	BE: 'Бельгия',
	BF: 'Буркина-Фасо',
	BG: 'Болгария',
	BH: 'Бахрейн',
	BN: 'Бруней',
	BO: 'Боливия',
	BR: 'Бразилия',
	BT: 'Бутан',
	BW: 'Ботсвана',
	BY: 'Беларусь',
	CA: 'Канада',
	CH: 'Швейцария',
	CI: 'Кот-д\'Ивуар',
	CL: 'Чили',
	CM: 'Камерун',
	CN: 'Китай',
	CO: 'Колумбия',
	CR: 'Коста-Рика',
	CY: 'Кипр',
	CZ: 'Чехия',
	DE: 'Германия',
	DJ: 'Джибути',
	DK: 'Дания',
	DO: 'Доминиканская Республика',
	DZ: 'Алжир',
	EC: 'Эквадор',
	EE: 'Эстония',
	EG: 'Египет',
	ES: 'Испания',
	ET: 'Эфиопия',
	FI: 'Финляндия',
	FJ: 'Фиджи',
	FR: 'Франция',
	GB: 'Великобритания',
	GD: 'Гренада',
	GE: 'Грузия',
	GH: 'Гана',
	GR: 'Греция',
	GT: 'Гватемала',
	GU: 'Гуам',
	GY: 'Гайана',
	HK: 'Гонконг',
	HN: 'Гондурас',
	HR: 'Хорватия',
	HU: 'Венгрия',
	ID: 'Индонезия',
	IE: 'Ирландия',
	IL: 'Израиль',
	IN: 'Индия',
	IQ: 'Ирак',
	IS: 'Исландия',
	IT: 'Италия',
	JM: 'Ямайка',
	JO: 'Иордания',
	JP: 'Япония',
	KE: 'Кения',
	KG: 'Кыргызстан',
	KH: 'Камбоджа',
	KR: 'Южная Корея',
	KW: 'Кувейт',
	KZ: 'Казахстан',
	LA: 'Лаос',
	LB: 'Ливан',
	LK: 'Шри-Ланка',
	LT: 'Литва',
	LU: 'Люксембург',
	LV: 'Латвия',
	MA: 'Марокко',
	MD: 'Молдова',
	ME: 'Черногория',
	MG: 'Мадагаскар',
	MK: 'Северная Македония',
	MM: 'Мьянма',
	MN: 'Монголия',
	MO: 'Макао',
	MT: 'Мальта',
	MU: 'Маврикий',
	MV: 'Мальдивы',
	MX: 'Мексика',
	MY: 'Малайзия',
	MZ: 'Мозамбик',
	NA: 'Намибия',
	NC: 'Новая Каледония',
	NG: 'Нигерия',
	NL: 'Нидерланды',
	NO: 'Норвегия',
	NP: 'Непал',
	NZ: 'Новая Зеландия',
	OM: 'Оман',
	PA: 'Панама',
	PE: 'Перу',
	PF: 'Французская Полинезия',
	PG: 'Папуа — Новая Гвинея',
	PH: 'Филиппины',
	PK: 'Пакистан',
	PL: 'Польша',
	PR: 'Пуэрто-Рико',
	PS: 'Палестина',
	PT: 'Португалия',
	PY: 'Парагвай',
	QA: 'Катар',
	RO: 'Румыния',
	RS: 'Сербия',
	RU: 'Россия',
	RW: 'Руанда',
	SA: 'Саудовская Аравия',
	SE: 'Швеция',
	SG: 'Сингапур',
	SI: 'Словения',
	SK: 'Словакия',
	SN: 'Сенегал',
	SR: 'Суринам',
	SV: 'Сальвадор',
	TH: 'Таиланд',
	TN: 'Тунис',
	TR: 'Турция',
	TT: 'Тринидад и Тобаго',
	TW: 'Тайвань',
	TZ: 'Танзания',
	UA: 'Украина',
	UG: 'Уганда',
	US: 'США',
	UY: 'Уругвай',
	UZ: 'Узбекистан',
	VE: 'Венесуэла',
	VN: 'Вьетнам',
	ZA: 'ЮАР',
	ZM: 'Замбия',
	ZW: 'Зимбабве',
};

/* Cloudflare colo (IATA) → [ city, ISO country ]; display: ARN (Stockholm, Arlanda / Швеция) */
var WARP_COLO = {
	AAE: [ 'Annabah', 'DZ' ],
	ABJ: [ 'Abidjan', 'CI' ],
	ABQ: [ 'Albuquerque', 'US' ],
	ACC: [ 'Accra', 'GH' ],
	ADB: [ 'Izmir', 'TR' ],
	ADD: [ 'Addis Ababa', 'ET' ],
	ADL: [ 'Adelaide', 'AU' ],
	AKL: [ 'Auckland', 'NZ' ],
	AKX: [ 'Aktyubinsk', 'KZ' ],
	ALA: [ 'Almaty', 'KZ' ],
	ALG: [ 'Algiers', 'DZ' ],
	AMD: [ 'Ahmedabad', 'IN' ],
	AMM: [ 'Amman', 'JO' ],
	AMS: [ 'Amsterdam', 'NL' ],
	ANC: [ 'Anchorage', 'US' ],
	ARI: [ 'Arica', 'CL' ],
	ARN: [ 'Stockholm, Arlanda', 'SE' ],
	ARU: [ 'Aracatuba', 'BR' ],
	ASK: [ 'Yamoussoukro', 'CI' ],
	ASU: [ 'Asuncion', 'PY' ],
	ATH: [ 'Athens', 'GR' ],
	ATL: [ 'Atlanta', 'US' ],
	AUS: [ 'Austin', 'US' ],
	BAH: [ 'Manama', 'BH' ],
	BAQ: [ 'Barranquilla', 'CO' ],
	BCN: [ 'Barcelona', 'ES' ],
	BEG: [ 'Belgrad', 'RS' ],
	BEL: [ 'Belem', 'BR' ],
	BEY: [ 'Beirut', 'LB' ],
	BGI: [ 'Bridgetown', 'BB' ],
	BGR: [ 'Bangor', 'US' ],
	BGW: [ 'Baghdad', 'IQ' ],
	BKK: [ 'Bangkok', 'TH' ],
	BLR: [ 'Bangalore', 'IN' ],
	BNA: [ 'Nashville', 'US' ],
	BNE: [ 'Brisbane', 'AU' ],
	BNU: [ 'Blumenau', 'BR' ],
	BOD: [ 'Bordeaux/Merignac', 'FR' ],
	BOG: [ 'Bogota', 'CO' ],
	BOM: [ 'Mumbai', 'IN' ],
	BOS: [ 'Boston', 'US' ],
	BRU: [ 'Brussels', 'BE' ],
	BSB: [ 'Brasilia', 'BR' ],
	BSR: [ 'Basrah', 'IQ' ],
	BTS: [ 'Bratislava', 'SK' ],
	BUD: [ 'Budapest', 'HU' ],
	BUF: [ 'Buffalo', 'US' ],
	BWN: [ 'Bandar Seri Begawan', 'BN' ],
	CAI: [ 'Cairo', 'EG' ],
	CAW: [ 'Campos Dos Goytacazes', 'BR' ],
	CBR: [ 'Canberra', 'AU' ],
	CCU: [ 'Kolkata', 'IN' ],
	CDG: [ 'Paris', 'FR' ],
	CEB: [ 'Lapu-Lapu City', 'PH' ],
	CFC: [ 'Caçador', 'BR' ],
	CGB: [ 'Cuiaba', 'BR' ],
	CGK: [ 'Jakarta', 'ID' ],
	CGP: [ 'Chittagong', 'BD' ],
	CGY: [ 'Laguindingan', 'PH' ],
	CLT: [ 'Charlotte', 'US' ],
	CMB: [ 'Colombo', 'LK' ],
	CMH: [ 'Columbus', 'US' ],
	CMN: [ 'Casablanca', 'MA' ],
	CNF: [ 'Belo Horizonte', 'BR' ],
	CNN: [ 'Mattanur', 'IN' ],
	CNX: [ 'Chiang Mai', 'TH' ],
	COK: [ 'Cochin', 'IN' ],
	COR: [ 'Cordoba', 'AR' ],
	CPH: [ 'Copenhagen', 'DK' ],
	CPT: [ 'Cape Town', 'ZA' ],
	CRK: [ 'Angeles City', 'PH' ],
	CVG: [ 'Hebron', 'US' ],
	CWB: [ 'Curitiba', 'BR' ],
	CZL: [ 'Constantine', 'DZ' ],
	DAC: [ 'Dhaka', 'BD' ],
	DAD: [ 'Da Nang', 'VN' ],
	DAR: [ 'Dar es Salaam', 'TZ' ],
	DEL: [ 'New Delhi', 'IN' ],
	DEN: [ 'Denver', 'US' ],
	DFW: [ 'Dallas-Fort Worth', 'US' ],
	DKR: [ 'Dakar', 'SN' ],
	DLA: [ 'Douala', 'CM' ],
	DME: [ 'Moscow', 'RU' ],
	DMM: [ 'Ad Dammam', 'SA' ],
	DOH: [ 'Doha', 'QA' ],
	DPS: [ 'Denpasar-Bali Island', 'ID' ],
	DTW: [ 'Detroit', 'US' ],
	DUB: [ 'Dublin', 'IE' ],
	DUR: [ 'Durban', 'ZA' ],
	DUS: [ 'Dusseldorf', 'DE' ],
	DXB: [ 'Dubai', 'AE' ],
	EBB: [ 'Kampala', 'UG' ],
	EBL: [ 'Arbil', 'IQ' ],
	EDI: [ 'Edinburgh', 'GB' ],
	EVN: [ 'Yerevan', 'AM' ],
	EWR: [ 'Newark', 'US' ],
	EZE: [ 'Ezeiza', 'AR' ],
	FCO: [ 'Rome', 'IT' ],
	FLN: [ 'Florianopolis', 'BR' ],
	FOR: [ 'Fortaleza', 'BR' ],
	FRA: [ 'Frankfurt', 'DE' ],
	FRU: [ 'Bishkek', 'KG' ],
	FSD: [ 'Sioux Falls', 'US' ],
	FUK: [ 'Fukuoka', 'JP' ],
	GBE: [ 'Gaborone', 'BW' ],
	GDL: [ 'Guadalajara', 'MX' ],
	GEO: [ 'Georgetown', 'GY' ],
	GIG: [ 'Rio De Janeiro', 'BR' ],
	GND: [ 'Saint George\'s', 'GD' ],
	GOT: [ 'Gothenburg', 'SE' ],
	GRU: [ 'Sao Paulo', 'BR' ],
	GUA: [ 'Guatemala City', 'GT' ],
	GUM: [ 'Hagatna', 'GU' ],
	GVA: [ 'Geneva', 'CH' ],
	GYD: [ 'Baku', 'AZ' ],
	GYE: [ 'Guayaquil', 'EC' ],
	GYN: [ 'Goiania', 'BR' ],
	HAM: [ 'Hamburg', 'DE' ],
	HAN: [ 'Hanoi', 'VN' ],
	HBA: [ 'Hobart', 'AU' ],
	HEL: [ 'Helsinki', 'FI' ],
	HFA: [ 'Haifa', 'IL' ],
	HKG: [ 'Hong Kong', 'CN' ],
	HNL: [ 'Honolulu', 'US' ],
	HRE: [ 'Harare', 'ZW' ],
	HYD: [ 'Hyderabad', 'IN' ],
	IAD: [ 'Dulles', 'US' ],
	IAH: [ 'Houston', 'US' ],
	ICN: [ 'Seoul', 'KR' ],
	IND: [ 'Indianapolis', 'US' ],
	ISB: [ 'Islamabad', 'PK' ],
	IST: [ 'Arnavutkoy', 'TR' ],
	ISU: [ 'Sulaymaniyah', 'IQ' ],
	ITJ: [ 'Itajai', 'BR' ],
	IXC: [ 'Chandigarh', 'IN' ],
	JAX: [ 'Jacksonville', 'US' ],
	JDO: [ 'Juazeiro Do Norte', 'BR' ],
	JED: [ 'Jeddah', 'SA' ],
	JHB: [ 'Senai', 'MY' ],
	JIB: [ 'Djibouti City', 'DJ' ],
	JNB: [ 'Johannesburg', 'ZA' ],
	JOG: [ 'Yogyakarta-Java Island', 'ID' ],
	JOI: [ 'Joinville', 'BR' ],
	JSR: [ 'Jashahor', 'BD' ],
	KBP: [ 'Kiev', 'UA' ],
	KCH: [ 'Kuching', 'MY' ],
	KEF: [ 'Reykjavik', 'IS' ],
	KGL: [ 'Kigali', 'RW' ],
	KHH: [ 'Kaohsiung City', 'CN' ],
	KHI: [ 'Karachi', 'PK' ],
	KIN: [ 'Kingston', 'JM' ],
	KIV: [ 'Chisinau', 'MD' ],
	KIX: [ 'Osaka', 'JP' ],
	KJA: [ 'Krasnoyarsk', 'RU' ],
	KNU: [ 'Kanpur', 'IN' ],
	KTM: [ 'Kathmandu', 'NP' ],
	KUL: [ 'Kuala Lumpur', 'MY' ],
	KWI: [ 'Kuwait City', 'KW' ],
	LAD: [ 'Luanda', 'AO' ],
	LAS: [ 'Las Vegas', 'US' ],
	LAX: [ 'Los Angeles', 'US' ],
	LCA: [ 'Larnarca', 'CY' ],
	LED: [ 'St. Petersburg', 'RU' ],
	LHE: [ 'Lahore', 'PK' ],
	LHR: [ 'London', 'GB' ],
	LIM: [ 'Lima', 'PE' ],
	LIS: [ 'Lisbon', 'PT' ],
	LJU: [ 'Ljubljana', 'SI' ],
	LLK: [ 'Lankaran', 'AZ' ],
	LOS: [ 'Lagos', 'NG' ],
	LPB: [ 'La Paz / El Alto', 'BO' ],
	LUN: [ 'Lusaka', 'ZM' ],
	LUX: [ 'Luxembourg', 'LU' ],
	LYS: [ 'Lyon', 'FR' ],
	MAA: [ 'Chennai', 'IN' ],
	MAD: [ 'Madrid', 'ES' ],
	MAN: [ 'Manchester', 'GB' ],
	MAO: [ 'Manaus', 'BR' ],
	MBA: [ 'Mombasa', 'KE' ],
	MCI: [ 'Kansas City', 'US' ],
	MCT: [ 'Muscat', 'OM' ],
	MDE: [ 'Rionegro', 'CO' ],
	MEL: [ 'Melbourne', 'AU' ],
	MEM: [ 'Memphis', 'US' ],
	MEX: [ 'Mexico City', 'MX' ],
	MFE: [ 'Mc Allen', 'US' ],
	MFM: [ 'Taipa', 'CN' ],
	MGM: [ 'Montgomery', 'US' ],
	MIA: [ 'Miami', 'US' ],
	MLA: [ 'Luqa', 'MT' ],
	MLE: [ 'Male', 'MV' ],
	MLG: [ 'Malang-Java Island', 'ID' ],
	MNL: [ 'Manila', 'PH' ],
	MPM: [ 'Maputo', 'MZ' ],
	MRS: [ 'Marseille', 'FR' ],
	MRU: [ 'Port Louis', 'MU' ],
	MSP: [ 'Minneapolis', 'US' ],
	MSQ: [ 'Minsk', 'BY' ],
	MUC: [ 'Munich', 'DE' ],
	MXP: [ 'Milan', 'IT' ],
	NAG: [ 'Naqpur', 'IN' ],
	NBO: [ 'Nairobi', 'KE' ],
	NJF: [ 'Najaf', 'IQ' ],
	NOU: [ 'Noumea', 'NC' ],
	NQN: [ 'Neuquen', 'AR' ],
	NQZ: [ 'Astana', 'KZ' ],
	NRT: [ 'Tokyo', 'JP' ],
	NVT: [ 'Navegantes', 'BR' ],
	OKA: [ 'Naha', 'JP' ],
	OKC: [ 'Oklahoma City', 'US' ],
	OMA: [ 'Omaha', 'US' ],
	ORD: [ 'Chicago', 'US' ],
	ORK: [ 'Cork', 'IE' ],
	ORN: [ 'Oran', 'DZ' ],
	OSL: [ 'Oslo', 'NO' ],
	OTP: [ 'Bucharest', 'RO' ],
	OUA: [ 'Ouagadougou', 'BF' ],
	PAT: [ 'Patna', 'IN' ],
	PBH: [ 'Paro', 'BT' ],
	PBM: [ 'Zandery', 'SR' ],
	PDX: [ 'Portland', 'US' ],
	PER: [ 'Perth', 'AU' ],
	PHL: [ 'Philadelphia', 'US' ],
	PHX: [ 'Phoenix', 'US' ],
	PIT: [ 'Pittsburgh', 'US' ],
	PMO: [ 'Palermo', 'IT' ],
	PMW: [ 'Palmas', 'BR' ],
	PNH: [ 'Phnom Penh', 'KH' ],
	POA: [ 'Porto Alegre', 'BR' ],
	POS: [ 'Port of Spain', 'TT' ],
	PPT: [ 'Papeete', 'PF' ],
	PRG: [ 'Prague', 'CZ' ],
	PTY: [ 'Tocumen', 'PA' ],
	QRO: [ 'Queretaro', 'MX' ],
	QWJ: [ 'Americana', 'BR' ],
	RAO: [ 'Ribeirao Preto', 'BR' ],
	RDU: [ 'Raleigh/Durham', 'US' ],
	REC: [ 'Recife', 'BR' ],
	RGN: [ 'Yangon', 'MM' ],
	RIC: [ 'Richmond', 'US' ],
	RIX: [ 'Riga', 'LV' ],
	RUH: [ 'Riyadh', 'SA' ],
	RUN: [ 'St Denis', 'FR' ],
	SAN: [ 'San Diego', 'US' ],
	SAP: [ 'La Mesa', 'HN' ],
	SAT: [ 'San Antonio', 'US' ],
	SCL: [ 'Santiago', 'CL' ],
	SDQ: [ 'Santo Domingo', 'DO' ],
	SEA: [ 'Seattle', 'US' ],
	SFO: [ 'San Francisco', 'US' ],
	SGN: [ 'Ho Chi Minh City', 'VN' ],
	SIN: [ 'Singapore', 'SG' ],
	SJC: [ 'San Jose', 'US' ],
	SJK: [ 'Sao Jose Dos Campos', 'BR' ],
	SJO: [ 'San Jose', 'CR' ],
	SJP: [ 'Sao Jose Do Rio Preto', 'BR' ],
	SJU: [ 'San Juan', 'PR' ],
	SKG: [ 'Thessaloniki', 'GR' ],
	SKP: [ 'Skopje', 'MK' ],
	SLC: [ 'Salt Lake City', 'US' ],
	SMF: [ 'Sacramento', 'US' ],
	SOD: [ 'Sorocaba', 'BR' ],
	SOF: [ 'Sofia', 'BG' ],
	SSA: [ 'Salvador', 'BR' ],
	STI: [ 'Santiago', 'DO' ],
	STL: [ 'St Louis', 'US' ],
	STR: [ 'Stuttgart', 'DE' ],
	SUV: [ 'Nausori', 'FJ' ],
	SVX: [ 'Yekaterinburg', 'RU' ],
	SYD: [ 'Sydney', 'AU' ],
	TAS: [ 'Tashkent', 'UZ' ],
	TBS: [ 'Tbilisi', 'GE' ],
	TGU: [ 'Tegucigalpa', 'HN' ],
	TIA: [ 'Tirana', 'AL' ],
	TLH: [ 'Tallahassee', 'US' ],
	TLL: [ 'Tallinn', 'EE' ],
	TLV: [ 'Tel Aviv', 'IL' ],
	TNR: [ 'Antananarivo', 'MG' ],
	TPA: [ 'Tampa', 'US' ],
	TPE: [ 'Taipei', 'CN' ],
	TUN: [ 'Tunis', 'TN' ],
	TXL: [ 'Berlin', 'DE' ],
	UDI: [ 'Uberlandia', 'BR' ],
	UIO: [ 'Quito', 'EC' ],
	ULN: [ 'Ulan Bator', 'MN' ],
	URT: [ 'Surat Thani', 'TH' ],
	VCP: [ 'Campinas', 'BR' ],
	VIE: [ 'Vienna', 'AT' ],
	VIX: [ 'Vitoria', 'BR' ],
	VNO: [ 'Vilnius', 'LT' ],
	VTE: [ 'Vientiane', 'LA' ],
	WAW: [ 'Warsaw', 'PL' ],
	WDH: [ 'Windhoek', 'NA' ],
	WLG: [ 'Wellington', 'NZ' ],
	WRO: [ 'Wroclaw', 'PL' ],
	XAP: [ 'Chapeco', 'BR' ],
	XNH: [ 'Nasiriyah', 'IQ' ],
	YHZ: [ 'Halifax', 'CA' ],
	YOW: [ 'Ottawa', 'CA' ],
	YUL: [ 'Montreal', 'CA' ],
	YVR: [ 'Vancouver', 'CA' ],
	YWG: [ 'Winnipeg', 'CA' ],
	YXE: [ 'Saskatoon', 'CA' ],
	YYC: [ 'Calgary', 'CA' ],
	YYZ: [ 'Toronto', 'CA' ],
	ZAG: [ 'Zagreb', 'HR' ],
	ZDM: [ 'Ramallah', 'PS' ],
	ZRH: [ 'Zurich', 'CH' ],
};

/* Backwards-compatibility alias */
var WARP_COLO_CC = {};
for (var _k in WARP_COLO) {
	if (WARP_COLO.hasOwnProperty(_k))
		WARP_COLO_CC[_k] = WARP_COLO[_k][1];
}

function countryName(code) {
	if (!code)
		return '';
	var c = String(code).toUpperCase().trim();
	return COUNTRY_RU[c] || code;
}

function coloInfo(colo) {
	var c = String(colo || '').toUpperCase();
	return (c && WARP_COLO[c]) || null;
}

function coloCity(colo) {
	var info = coloInfo(colo);
	return info ? info[0] : '';
}

function coloCountry(colo) {
	var info = coloInfo(colo);
	return info ? info[1] : '';
}

function coloLabel(colo) {
	var c = String(colo || '').toUpperCase();
	var info;
	var city;
	var cc;
	var country;
	var loc = [];

	if (!c)
		return '';
	info = coloInfo(c);
	if (info) {
		city = info[0];
		cc = info[1];
		country = countryName(cc);
		if (city)
			loc.push(city);
		if (country)
			loc.push(country);
		if (loc.length)
			return c + ' (' + loc.join(' / ') + ')';
	}
	return c;
}

function confOptions(confs, preferKind) {
	var list = Array.isArray(confs) ? confs.slice() : [];
	var opts = [];
	var i;
	var c;
	var preferred = [];
	var rest = [];

	for (i = 0; i < list.length; i++) {
		c = list[i];
		if (!c || !c.file)
			continue;
		if (preferKind && c.kind === preferKind)
			preferred.push(c);
		else
			rest.push(c);
	}
	list = preferred.concat(rest);
	for (i = 0; i < list.length; i++) {
		c = list[i];
		opts.push({
			v: c.file,
			t: (c.kind ? c.kind + ' · ' : '') + c.file
		});
	}
	return opts;
}

function ifaceNameFromConf(file) {
	var base = String(file || '').replace(/^.*\//, '').replace(/\.conf$/i, '');

	return base.replace(/[^A-Za-z0-9_.-]/g, '_').replace(/^[.-]+|[.-]+$/g, '') || 'tunnel';
}

function sanitizeIfaceName(raw) {
	var s = String(raw || '').trim().replace(/[^A-Za-z0-9_.-]/g, '');

	return s.replace(/^[.-]+|[.-]+$/g, '') || '';
}

function unpackAmneziaVpnKey(rawStr) {
	var s = String(rawStr || '').trim();
	if (s.indexOf('vpn://') === 0)
		s = s.substring(6);
	s = s.replace(/_/g, '/').replace(/-/g, '+');
	while (s.length % 4) s += '=';
	var bin;
	try {
		bin = atob(s);
	} catch (e) {
		return Promise.reject(new Error(_('Некорректная Base64 строка')));
	}
	var bytes = new Uint8Array(bin.length);
	for (var i = 0; i < bin.length; i++) {
		bytes[i] = bin.charCodeAt(i);
	}
	var offset = 0;
	if (bytes.length >= 4 && bytes[0] === 0 && bytes[1] === 0 && bytes[2] === 0 && bytes[3] === 0xff) {
		offset = 4;
	}
	var payload = bytes.subarray(offset);
	if (typeof DecompressionStream !== 'undefined') {
		try {
			var ds = new DecompressionStream('deflate');
			var writer = ds.writable.getWriter();
			writer.write(payload);
			writer.close();
			var reader = ds.readable.getReader();
			var chunks = [];
			var total = 0;
			function readNext() {
				return reader.read().then(function(step) {
					if (step.done) {
						var res = new Uint8Array(total);
						var cur = 0;
						for (var j = 0; j < chunks.length; j++) {
							res.set(chunks[j], cur);
							cur += chunks[j].length;
						}
						var text = new TextDecoder('utf-8').decode(res);
						return JSON.parse(text);
					}
					chunks.push(step.value);
					total += step.value.length;
					return readNext();
				});
			}
			return readNext();
		} catch (err) {
			return Promise.reject(err);
		}
	}
	return Promise.reject(new Error(_('DecompressionStream не поддерживается в этом браузере')));
}

function extractAmneziaConfig(jsonObj) {
	if (!jsonObj || typeof jsonObj !== 'object')
		return null;
	if (jsonObj.api_config) {
		return {
			isSubscription: true,
			name: jsonObj.name || jsonObj.description || 'Amnezia Premium',
			serviceType: jsonObj.api_config.service_type || 'amnezia-premium',
			country: jsonObj.api_config.user_country_code || '',
			apiKey: (jsonObj.auth_data && jsonObj.auth_data.api_key) || ''
		};
	}
	var extractedConf = null;
	var type = jsonObj.defaultContainer || 'awg';
	if (Array.isArray(jsonObj.containers)) {
		for (var i = 0; i < jsonObj.containers.length; i++) {
			var c = jsonObj.containers[i];
			if (c.awg && c.awg.last_config) {
				extractedConf = c.awg.last_config;
				type = 'awg';
				break;
			}
			if (c.wireguard && c.wireguard.last_config) {
				extractedConf = c.wireguard.last_config;
				type = 'wireguard';
				break;
			}
			if (c.openvpn && c.openvpn.last_config) {
				extractedConf = c.openvpn.last_config;
				type = 'openvpn';
				break;
			}
		}
	}
	if (extractedConf) {
		return {
			isStatic: true,
			confText: extractedConf,
			type: type,
			name: jsonObj.description || jsonObj.hostName || 'amnezia'
		};
	}
	return null;
}

function listCreateKinds(summary) {
	var slots = (summary && summary.createSlots) || [];
	var byKind = {};
	var out = [];
	var k;
	var i;
	var s;

	for (i = 0; i < slots.length; i++) {
		s = slots[i];
		k = String(s.kind || s.slot || '').toLowerCase();
		if (!k || k === 'manual')
			continue;
		if (!byKind[k] || (byKind[k].occupied && !s.occupied))
			byKind[k] = s;
	}
	if (!byKind['warp']) {
		byKind['warp'] = { kind: 'warp', slot: 'warp', occupied: 0 };
	}
	if (!byKind['proton']) {
		byKind['proton'] = { kind: 'proton', slot: 'proton', occupied: 0 };
	}

	var orderedKinds = ['warp', 'proton'];
	for (i = 0; i < orderedKinds.length; i++) {
		k = orderedKinds[i];
		if (byKind[k]) {
			out.push({
				kind: k,
				slot: byKind[k].slot || k,
				occupied: byKind[k].occupied ? 1 : 0
			});
		}
	}
	for (k in byKind) {
		if (!Object.prototype.hasOwnProperty.call(byKind, k) || orderedKinds.indexOf(k) >= 0)
			continue;
		out.push({
			kind: k,
			slot: byKind[k].slot || k,
			occupied: byKind[k].occupied ? 1 : 0
		});
	}
	return out;
}

function defaultNewIfaceName(slotName, ifaces, summary) {
	var kind = String(slotName || '').toLowerCase();
	var free;

	if (kind === 'warp' || kind.indexOf('warp') === 0) {
		free = summary && summary.freeWarpIface;
		if (free)
			return free;
	}
	if (kind === 'proton' || kind.indexOf('proton') === 0) {
		free = summary && summary.freeProtonIface;
		if (free)
			return free;
	}

	var base = sanitizeIfaceName(slotName) || 'tunnel';
	var i;
	var n;
	var names = {};

	for (i = 0; i < (ifaces || []).length; i++)
		names[ifaces[i].name] = 1;
	if (!names[base])
		return base;
	for (n = 2; n < 50; n++) {
		if (!names[base + String(n)])
			return base + String(n);
	}
	return base + '_new';
}

function createKindLabel(kind) {
	var k = String(kind || '').toLowerCase();

	if (k === 'warp')
		return 'WARP';
	if (k === 'proton')
		return 'Proton';
	return kind;
}

function paramLine(k, v) {
	if (!v)
		return null;
	return E('span', { 'class': 'xfree-vpn-param' }, [
		E('em', {}, [ k ]),
		' ',
		v
	]);
}

function selectField(id, label, value, options) {
	var opts = [];
	var i;
	var v = String(value || '');

	for (i = 0; i < options.length; i++) {
		opts.push(E('option', {
			'value': options[i].v,
			'selected': options[i].v === v ? true : null
		}, [ options[i].t ]));
	}

	return E('div', { 'class': 'xfree-vpn-field' }, [
		E('div', { 'class': 'xfree-vpn-field-label' }, [ label ]),
		E('select', {
			'class': 'xfree-uplink-input',
			'data-xfree-vpn-field': id
		}, opts)
	]);
}

function textField(id, label, value, placeholder) {
	return E('div', { 'class': 'xfree-vpn-field' }, [
		E('div', { 'class': 'xfree-vpn-field-label' }, [ label ]),
		E('input', {
			'class': 'xfree-uplink-input',
			'type': 'text',
			'data-xfree-vpn-field': id,
			'value': value || '',
			'placeholder': placeholder || ''
		})
	]);
}

/* Country = tribukvy + бот llimonix; [LTE] = tel.*.tribukvy без бота (фильтр портов). */
var WARP_SERVERS = [
	{ v: 'xfree', t: 'xfree' },
	{ v: 'def', t: 'def (Cloudflare)' },
	{ v: 'FL', t: 'Финляндия (рег.)' },
	{ v: 'NL', t: 'Нидерланды (рег.)' },
	{ v: 'PL', t: 'Польша (рег.)' },
	{ v: 'DE', t: 'Германия (рег.)' },
	{ v: 'LV', t: 'Латвия (рег.)' },
	{ v: 'RU', t: 'Россия (рег.)' },
	{ v: 'lteFL', t: '[LTE] Финляндия' },
	{ v: 'ltePL', t: '[LTE] Польша' },
	{ v: 'lteDE', t: '[LTE] Германия' }
];

var WARP_GEN_HELP_URL = 'https://warp-generation.github.io/';

function warpServerNeedsReg(v) {
	return /^(FL|NL|PL|DE|LV|RU)$/.test(String(v || ''));
}

function warpServerIsLte(v) {
	return /^(lteFL|ltePL|lteDE)$/.test(String(v || ''));
}

function warpServerLabel(v) {
	var i;
	var s = String(v || 'xfree');

	for (i = 0; i < WARP_SERVERS.length; i++) {
		if (WARP_SERVERS[i].v === s)
			return WARP_SERVERS[i].t;
	}
	return s;
}

function warpServerTip() {
	return E('p', { 'class': 'muted xfree-vpn-tip' }, [
		_('«(рег.)» — нужна регистрация в Telegram-боте от llimonix. «[LTE]» — без бота, но со своим фильтром портов (Польша без 988, Финляндия без 1010), как на '),
		E('a', {
			'href': WARP_GEN_HELP_URL,
			'target': '_blank',
			'rel': 'noopener noreferrer'
		}, [ 'warp-generation.github.io' ]),
		_('. Для обычного доступа достаточно xfree / def (Cloudflare).')
	]);
}

var WARP_PROFILES = [
	{ v: '2.0:1', t: 'AWG 2.0 · вариант 1' },
	{ v: '2.0:2', t: 'AWG 2.0 · вариант 2' },
	{ v: '2.0:3', t: 'AWG 2.0 · вариант 3' }
];

var PROTON_ENTROPY_OPTIONS = [
	{ v: 'r32', t: '<r 32> · 32 байта (по умолчанию)' },
	{ v: 'r64', t: '<r 64> · 64 байта (паранойя)' },
	{ v: 't', t: '<t> · timestamp' },
	{ v: 'c', t: '<c> · счётчик' },
	{ v: 'rc10', t: '<rc 10> · 10 букв' },
	{ v: 'rd6', t: '<rd 6> · 6 цифр' },
	{ v: 'off', t: _('без энтропии (только <b 0x…>)') }
];

var PROTON_NOISE_OPTIONS = [
	{ v: '0', t: _('без шума (Jc=0)') },
	{ v: '1', t: _('с шумом (Jc=4, Jmin=40, Jmax=70)') }
];

var WARP_MODES = [
	{ v: 'local', t: 'local' },
	{ v: 'raw', t: 'raw' }
];

var WARP_I1 = [
	{ v: 'fixed', t: 'fixed' },
	{ v: 'random', t: 'random' },
	{ v: 'domain', t: 'domain-seeded' }
];

var WARP_SELECTION = [
	{ v: 'best', t: _('Топ-5 по колонии + задержка') },
	{ v: 'random', t: _('Случайный endpoint') }
];

function warpSelectionLabel(v) {
	var i;
	for (i = 0; i < WARP_SELECTION.length; i++) {
		if (WARP_SELECTION[i].v === v)
			return WARP_SELECTION[i].t;
	}
	return v || 'best';
}

function warpExcludeRuLabel(v) {
	return (v === '1' || v === 1) ? _('без колоний RU') : _('все колонии');
}

var PROTON_COUNTRIES = (function() {
	var list = [
		{ v: 'AUTO', t: _('AUTO (автовыбор)') },
		{ v: 'NL', t: _('Нидерланды (NL)') + ' [Free]' },
		{ v: 'US', t: _('США (US)') + ' [Free]' },
		{ v: 'JP', t: _('Япония (JP)') + ' [Free]' },
		{ v: 'CA', t: _('Канада (CA)') + ' [Free]' },
		{ v: 'PL', t: _('Польша (PL)') + ' [Free]' },
		{ v: 'RO', t: _('Румыния (RO)') + ' [Free]' },
		{ v: 'SG', t: _('Сингапур (SG)') + ' [Free]' },
		{ v: 'MX', t: _('Мексика (MX)') },
		{ v: 'DE', t: _('Германия (DE)') },
		{ v: 'FR', t: _('Франция (FR)') },
		{ v: 'CH', t: _('Швейцария (CH)') },
		{ v: 'SE', t: _('Швеция (SE)') },
		{ v: 'GB', t: _('Великобритания (GB)') },
		{ v: 'ES', t: _('Испания (ES)') },
		{ v: 'IT', t: _('Италия (IT)') },
		{ v: 'FI', t: _('Финляндия (FI)') },
		{ v: 'TR', t: _('Турция (TR)') },
		{ v: 'KZ', t: _('Казахстан (KZ)') },
		{ v: 'AE', t: _('ОАЭ (AE)') },
		{ v: 'BR', t: _('Бразилия (BR)') },
		{ v: 'AR', t: _('Аргентина (AR)') },
		{ v: 'AU', t: _('Австралия (AU)') }
	];
	var seen = {};
	for (var i = 0; i < list.length; i++)
		seen[list[i].v] = true;

	var rest = [];
	for (var c in COUNTRY_RU) {
		if (!seen[c]) {
			var label = COUNTRY_RU[c] + ' (' + c + ')';
			rest.push({ v: c, t: label });
		}
	}
	rest.sort(function(a, b) {
		return a.t.localeCompare(b.t, 'ru');
	});
	return list.concat(rest);
})();

function renderTunnelSkeleton() {
	return E('div', { 'class': 'xfree-vpn-tunnel is-skeleton' }, [
		E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
			E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 76px; height: 15px;' }),
			E('div', { 'class': 'xfree-vpn-status-row' }, [
				E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 36px; height: 16px;' }),
				E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 26px; height: 16px;' })
			])
		]),
		E('div', { 'class': 'xfree-vpn-tunnel-sub' }, [
			E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 130px; height: 11px;' })
		]),
		E('div', { 'class': 'xfree-vpn-tunnel-meta' }, [
			E('div', { 'class': 'xfree-vpn-kv' }, [
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 34px; height: 11px;' }),
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 11px;' })
			]),
			E('div', { 'class': 'xfree-vpn-kv' }, [
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 34px; height: 11px;' }),
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 90px; height: 11px;' })
			])
		]),
		E('div', { 'class': 'xfree-vpn-tunnel-actions' }, [
			E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 50px; height: 22px; border-radius: 6px;' }),
			E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 50px; height: 22px; border-radius: 6px;' })
		])
	]);
}

function formatBytes(bytes) {
	if (!bytes || bytes <= 0) return '0 B';
	var k = 1024;
	var sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
	var i = Math.floor(Math.log(bytes) / Math.log(k));
	if (i >= sizes.length) i = sizes.length - 1;
	return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function formatHandshake(sec) {
	if (!sec || sec <= 0) return _('никогда');
	var now = Math.floor(Date.now() / 1000);
	var diff = now - sec;
	if (diff < 0) diff = 0;
	if (diff < 60) return _('%d сек назад').format(diff);
	if (diff < 3600) return _('%d мин назад').format(Math.floor(diff / 60));
	if (diff < 86400) return _('%d ч назад').format(Math.floor(diff / 3600));
	return _('%d дн назад').format(Math.floor(diff / 86400));
}

function copyToClipboard(text, btnEl) {
	if (window.navigator && window.navigator.clipboard && window.navigator.clipboard.writeText) {
		window.navigator.clipboard.writeText(text).then(function() {
			if (btnEl) {
				var oldText = btnEl.textContent;
				btnEl.textContent = '✓ ' + _('Скопировано');
				setTimeout(function() { btnEl.textContent = oldText; }, 2000);
			}
		});
	} else {
		var ta = document.createElement('textarea');
		ta.value = text;
		ta.style.position = 'fixed';
		ta.style.left = '-9999px';
		document.body.appendChild(ta);
		ta.select();
		try {
			document.execCommand('copy');
			if (btnEl) {
				var oldText = btnEl.textContent;
				btnEl.textContent = '✓ ' + _('Скопировано');
				setTimeout(function() { btnEl.textContent = oldText; }, 2000);
			}
		} catch (e) {}
		document.body.removeChild(ta);
	}
}

function downloadTextFile(filename, text) {
	var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
	var url = window.URL.createObjectURL(blob);
	var a = document.createElement('a');
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	setTimeout(function() {
		document.body.removeChild(a);
		window.URL.revokeObjectURL(url);
	}, 100);
}

function slugifyPeerName(name) {
	var ru = {
		'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ё':'e','ж':'zh','з':'z','и':'i',
		'й':'y','к':'k','л':'l','м':'m','н':'n','о':'o','п':'p','р':'r','с':'s','т':'t',
		'у':'u','ф':'f','х':'h','ц':'ts','ч':'ch','ш':'sh','щ':'sch','ъ':'','ы':'y','ь':'',
		'э':'e','ю':'yu','я':'ya'
	};
	var res = '';
	var lower = String(name || '').trim().toLowerCase();
	for (var i = 0; i < lower.length; i++) {
		var ch = lower[i];
		if (ru[ch] !== undefined) {
			res += ru[ch];
		} else if (/[a-z0-9_-]/.test(ch)) {
			res += ch;
		} else if (/\s/.test(ch)) {
			res += '-';
		}
	}
	return res.replace(/-+/g, '-').replace(/^-|-$/g, '');
}

function extractConfBody(stdout) {
	if (!stdout) return '';
	var m = stdout.match(/CONF_BODY_BEGIN\r?\n([\s\S]*?)\r?\nCONF_BODY_END/);
	if (m && m[1]) return m[1].trim();
	return stdout.trim();
}

function loadUqr() {
	if (window.UqrClass)
		return Promise.resolve(window.UqrClass);
	if (window.L && typeof window.L.require === 'function') {
		return window.L.require('uqr').then(function(Uqr) {
			window.UqrClass = Uqr;
			return Uqr;
		}).catch(function(err) {
			console.warn('uqr load error:', err);
			return null;
		});
	}
	return Promise.resolve(null);
}

function renderQrSvg(uqrEngine, text) {
	if (!uqrEngine || !text)
		return null;
	var rawSvg = null;
	var opts = {
		pixelSize: 4,
		whiteColor: '#ffffff',
		blackColor: '#000000',
		ecc: 'M',
		border: 4
	};
	try {
		if (typeof uqrEngine.renderSVG === 'function') {
			rawSvg = uqrEngine.renderSVG(text, opts);
		} else if (typeof uqrEngine === 'function') {
			var inst = new uqrEngine();
			if (typeof inst.renderSVG === 'function') {
				rawSvg = inst.renderSVG(text, opts);
			}
		}
	} catch (e) {
		console.warn('uqr renderSVG error:', e);
	}

	if (!rawSvg)
		return null;

	// OpenWrt uqr.js generates <svg width="W" height="H"> without a viewBox.
	// When rendered in CSS with max-width/responsive scaling, the browser clips
	// coordinates instead of scaling, cutting off the right & bottom edges of the QR.
	// Adding viewBox and width="100%" height="auto" ensures complete, uncut scaling.
	return rawSvg.replace(/<svg\s+xmlns="([^"]+)"\s+width="(\d+)"\s+height="(\d+)">/, function(match, ns, w, h) {
		return '<svg xmlns="' + ns + '" viewBox="0 0 ' + w + ' ' + h + '" width="100%" height="auto" style="display:block; max-width:100%;">';
	});
}


wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._summary = (spec && spec.summary) || { ifaces: [], warp: {}, proton: {}, count: 0 };
		this._awgSummary = (spec && spec.awgSummary) || {};
		this._protocolsStatus = (spec && spec.protocolsStatus) || {};
		this._output = (spec && spec.outputText) || '';
		this._busy = !!(spec && spec.busy);
		this._loading = !!(spec && spec.loading);
		this._protocolsLoaded = !!(spec && spec.protocolsStatus && Object.keys(spec.protocolsStatus).length > 0 && spec.protocolsStatus.awg);
		this._serverLoaded = !!(spec && spec.awgSummary && (spec.awgSummary.iface || spec.awgSummary.running != null));
		this._summaryLoaded = !!(spec && spec.summary && (spec.summary.ifaces != null || spec.summary.count != null));
		this._msg = (spec && spec.message) || '';
		this._msgTone = (spec && spec.messageTone) || '';
		this._vpnView = (spec && spec.vpnView) || 'tunnels';
		this.setAttribute('data-xfree-vpn', '1');
		this.requestPaint();
	}

	setLoading(loading) {
		this._loading = !!loading;
		if (this._spec)
			this._spec.loading = this._loading;
		this.requestPaint();
	}

	setSummary(summary) {
		this._summary = summary || { ifaces: [], warp: {}, proton: {}, count: 0 };
		this._summaryLoaded = true;
		this._loading = false;
		if (this._spec)
			this._spec.loading = false;
		this.requestPaint();
	}

	setAwgSummary(awg) {
		this._awgSummary = awg || {};
		this._serverLoaded = true;
		if (this._spec)
			this._spec.awgSummary = this._awgSummary;
		this.requestPaint();
	}

	setProtocolsStatus(status) {
		this._protocolsStatus = status || {};
		this._protocolsLoaded = true;
		this._loading = false;
		if (this._spec) {
			this._spec.protocolsStatus = this._protocolsStatus;
			this._spec.loading = false;
		}
		this.requestPaint();
	}

	setOutputText(text) {
		this._output = text || '';
	}

	setBusy(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button').forEach(function(el) {
			el.disabled = !!busy;
		});
	}

	setMessage(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var el = this.querySelector('[data-xfree-vpn-msg]');

		if (el) {
			el.textContent = this._msg;
			el.className = 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : '');
		}
	}

	_act(ev, action, arg, confirmText) {
		var s = this._spec || {};

		if (ev && typeof ev.preventDefault === 'function')
			ev.preventDefault();
		if (ev && typeof ev.stopPropagation === 'function')
			ev.stopPropagation();
		if (s.onAction)
			return s.onAction(action, arg, confirmText);
	}

	_nav(ev, panel) {
		var s = this._spec || {};

		ev.preventDefault();
		ev.stopPropagation();
		if (s.onNavigate)
			s.onNavigate(panel);
	}

	_promptAct(ev, action, promptText, confirmText) {
		var s = this._spec || {};
		var arg;

		ev.preventDefault();
		ev.stopPropagation();
		arg = window.prompt(promptText, '');
		if (arg === null)
			return;
		arg = String(arg || '').trim();
		if (!arg) {
			this.setOutputText(_('Нужен аргумент: %s').format(promptText));
			this.setMessage(_('Нужен аргумент: %s').format(promptText), 'warn');
			return;
		}
		if (s.onAction)
			s.onAction(action, arg, confirmText);
	}

	_pickSelect(title, hint, options, onPick) {
		var sel;
		var opts = [];
		var i;

		if (!options || !options.length) {
			this.setMessage(_('Нет вариантов для выбора'), 'bad');
			return;
		}

		for (i = 0; i < options.length; i++) {
			opts.push(E('option', { 'value': options[i].v }, [ options[i].t ]));
		}

		sel = E('select', { 'class': 'xfree-uplink-input xfree-vpn-pick-select' }, opts);

		xui.openDialog({
			title: title,
			hint: hint || '',
			body: E('div', { 'class': 'xfree-vpn-pick' }, [ sel ]),
			actions: [
				{ label: _('Отмена'), variant: 'secondary', close: true },
				{
					label: _('Выбрать'),
					variant: 'primary',
					close: true,
					click: function() {
						var v = String(sel.value || '').trim();

						if (v && onPick)
							onPick(v);
					}
				}
			]
		});
	}

	_updateIface(ev, ifaceName, kind) {
		var self = this;
		var s = this._spec || {};
		var confs = (this._summary && this._summary.confs) || [];
		var opts = confOptions(confs, kind);
		var isGenerator = (kind === 'warp' || kind === 'proton');
		var confirmMsg;
		var genLabel;
		var combinedOpts;

		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}

		if (isGenerator) {
			if (!opts || !opts.length) {
				confirmMsg = (kind === 'warp')
					? _('Обновить туннель «%s»? Будет выполнен подбор рабочего эндпоинта и обновление конфигурации.').format(ifaceName)
					: _('Обновить туннель «%s»? Будет обновлена конфигурация Proton VPN и применены настройки.').format(ifaceName);

				if (s.onAction)
					s.onAction('regenerateOne', ifaceName, confirmMsg);
				return;
			}

			genLabel = (kind === 'warp')
				? '⚡ ' + _('Автоматически: подобрать рабочий эндпоинт')
				: '⚡ ' + _('Автоматически: обновить конфигурацию');
			combinedOpts = [{ v: '__REGENERATE__', t: genLabel }].concat(opts);

			this._pickSelect(
				_('Обновить туннель «%s»').format(ifaceName),
				_('Выберите источник обновления конфигурации:'),
				combinedOpts,
				function(choice) {
					if (choice === '__REGENERATE__') {
						if (s.onAction)
							s.onAction('regenerateOne', ifaceName,
								_('Пересобрать и обновить «%s»?').format(ifaceName));
					} else {
						if (s.onAction)
							s.onAction('updateFromConf', ifaceName + '|' + choice,
								_('Обновить туннель «%s» из %s?').format(ifaceName, choice));
					}
				}
			);
			return;
		}

		if (!opts || !opts.length) {
			xui.openDialog({
				title: _('Обновить «%s»').format(ifaceName),
				hint: '',
				body: E('div', { 'class': 'xfree-vpn-pick' }, [
					E('p', {}, [
						_('В каталоге vpn/ текущего профиля не найдено файлов конфигурации (.conf).')
					]),
					E('p', { 'class': 'muted' }, [
						_('Загрузите файл .conf на вкладке «Файлы» или настройте туннель через «Пересобрать».')
					])
				]),
				actions: [
					{ label: _('Понятно'), variant: 'primary', close: true }
				]
			});
			return;
		}

		this._pickSelect(
			_('Обновить «%s» из .conf').format(ifaceName),
			_('Выберите файл конфигурации'),
			opts,
			function(file) {
				if (s.onAction)
					s.onAction('updateFromConf', ifaceName + '|' + file,
						_('Обновить туннель «%s» из %s?').format(ifaceName, file));
			}
		);
	}

	_updateFromConf(ev, ifaceName, preferKind) {
		return this._updateIface(ev, ifaceName, preferKind);
	}

	_createFromConf(ev) {
		var self = this;
		var s = this._spec || {};
		var confs = (this._summary && this._summary.confs) || [];
		var opts = confOptions(confs, '');

		ev.preventDefault();
		ev.stopPropagation();
		this._pickSelect(
			_('Создать туннель из .conf'),
			_('Имя туннеля возьмётся из имени файла'),
			opts,
			function(file) {
				var name = ifaceNameFromConf(file);

				if (s.onAction)
					s.onAction('createFromConf', name + '|' + file,
						_('Создать туннель «%s» из %s?').format(name, file));
			}
		);
	}

	_getProtonCountryOptions(freeOnly, requireIpv6) {
		var isFreeOnly = (freeOnly === '1' || freeOnly === 1 || freeOnly === true);
		var isIpv6Only = (requireIpv6 === '1' || requireIpv6 === 1 || requireIpv6 === true);
		var sc = this._protonServerCountries;

		var allowedCodes = null;
		if (sc) {
			if (isFreeOnly && isIpv6Only && sc.free_v6 && sc.free_v6.length) {
				allowedCodes = sc.free_v6;
			} else if (isFreeOnly && sc.free && sc.free.length) {
				allowedCodes = sc.free;
			} else if (isIpv6Only && sc.v6 && sc.v6.length) {
				allowedCodes = sc.v6;
			} else if (!isFreeOnly && sc.all && sc.all.length) {
				allowedCodes = sc.all;
			}
		}

		if (!allowedCodes) {
			if (isFreeOnly) {
				allowedCodes = ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG'];
			} else {
				allowedCodes = null;
			}
		}

		var list = [
			{ v: 'AUTO', t: _('AUTO (автовыбор)') }
		];
		var seen = { 'AUTO': true };

		var priority = isFreeOnly
			? ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG']
			: ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG', 'MX', 'DE', 'FR', 'CH', 'SE', 'GB', 'ES', 'IT', 'FI', 'TR', 'KZ', 'AE', 'BR', 'AR', 'AU'];

		var freeSet = {};
		var freeList = (sc && sc.free) ? sc.free : ['NL', 'US', 'JP', 'CA', 'PL', 'RO', 'SG'];
		for (var f = 0; f < freeList.length; f++)
			freeSet[freeList[f]] = true;

		var allowedSet = null;
		if (allowedCodes) {
			allowedSet = {};
			for (var a = 0; a < allowedCodes.length; a++)
				allowedSet[allowedCodes[a]] = true;
		}

		for (var p = 0; p < priority.length; p++) {
			var code = priority[p];
			if (allowedSet && !allowedSet[code])
				continue;
			if (!seen[code]) {
				var name = COUNTRY_RU[code] || code;
				var suffix = (!isFreeOnly && freeSet[code]) ? ' [Free]' : '';
				list.push({ v: code, t: name + ' (' + code + ')' + suffix });
				seen[code] = true;
			}
		}

		var rest = [];
		if (allowedSet) {
			for (var c in allowedSet) {
				if (!seen[c]) {
					var label = (COUNTRY_RU[c] || c) + ' (' + c + ')';
					rest.push({ v: c, t: label });
					seen[c] = true;
				}
			}
		} else {
			for (var c2 in COUNTRY_RU) {
				if (!seen[c2]) {
					rest.push({ v: c2, t: COUNTRY_RU[c2] + ' (' + c2 + ')' });
					seen[c2] = true;
				}
			}
		}

		rest.sort(function(a, b) {
			return a.t.localeCompare(b.t, 'ru');
		});

		return list.concat(rest);
	}

	_updateProtonCountriesDropdown(preferredCountry) {
		var sel = this.querySelector('[data-xfree-vpn-field="proton_country"]');
		if (!sel) return;

		var freeSel = this.querySelector('[data-xfree-vpn-field="proton_free_only"]');
		var ipv6Sel = this.querySelector('[data-xfree-vpn-field="proton_require_ipv6"]');

		var freeOnly = freeSel ? freeSel.value : '1';
		var ipv6Only = ipv6Sel ? ipv6Sel.value : '0';
		var curVal = preferredCountry || sel.value || 'AUTO';

		var options = this._getProtonCountryOptions(freeOnly, ipv6Only);

		while (sel.firstChild)
			sel.removeChild(sel.firstChild);

		var valFound = false;
		for (var i = 0; i < options.length; i++) {
			var opt = E('option', { 'value': options[i].v }, [ options[i].t ]);
			if (options[i].v === curVal) {
				opt.selected = true;
				valFound = true;
			}
			sel.appendChild(opt);
		}

		if (!valFound) {
			sel.value = 'AUTO';
		}
	}

	_fetchProtonCountries(forceRefresh) {
		var self = this;
		if (this._protonCountriesFetching) return;
		this._protonCountriesFetching = true;

		var refreshBtn = this.querySelector('.xfree-vpn-proton-country-refresh');
		if (refreshBtn) {
			refreshBtn.textContent = '⏳';
			refreshBtn.disabled = true;
		}

		xui.runIfaceMenu('protonCountries', forceRefresh ? 'refresh=1' : '').then(function(res) {
			self._protonCountriesFetching = false;
			if (refreshBtn) {
				refreshBtn.textContent = '🔄';
				refreshBtn.disabled = false;
			}

			var raw = (res && (res.stdout || res.output || res)) || '';
			if (typeof raw !== 'string' && typeof raw.toString === 'function')
				raw = raw.toString();

			var sc = { free: [], all: [], v6: [], free_v6: [] };
			var lines = raw.split('\n');
			for (var i = 0; i < lines.length; i++) {
				var line = lines[i].trim();
				if (line.indexOf('PROTON_FREE_COUNTRIES=') === 0) {
					var s = line.substring(22).trim();
					if (s) sc.free = s.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_ALL_COUNTRIES=') === 0) {
					var s2 = line.substring(21).trim();
					if (s2) sc.all = s2.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_V6_COUNTRIES=') === 0) {
					var s3 = line.substring(20).trim();
					if (s3) sc.v6 = s3.split(',').filter(Boolean);
				} else if (line.indexOf('PROTON_FREE_V6_COUNTRIES=') === 0) {
					var s4 = line.substring(25).trim();
					if (s4) sc.free_v6 = s4.split(',').filter(Boolean);
				}
			}

			if (sc.all.length > 0) {
				self._protonServerCountries = sc;
				self._protonCountriesLoaded = true;
				self._updateProtonCountriesDropdown();
				if (forceRefresh) {
					self.setMessage(_('Список стран Proton обновлён (%d стран)').format(sc.all.length), 'ok');
				}
			}
		}).catch(function() {
			self._protonCountriesFetching = false;
			if (refreshBtn) {
				refreshBtn.textContent = '🔄';
				refreshBtn.disabled = false;
			}
		});
	}

	_renderImportCard(view, inModal) {
		var self = this;
		var s = this._spec || {};
		var allConfs = (this._summary && this._summary.confs) || [];
		var customConfs = allConfs.filter(function(c) {
			return c.kind === 'custom' || c.kind === 'amnezia' || c.kind === 'openvpn';
		});
		var latestCustom = customConfs[0] || null;

		var fileInput = E('input', {
			'type': 'file',
			'accept': '.conf,.ovpn,.txt',
			'style': 'display: none;'
		});

		var statusNote = E('div', {
			'class': 'xfree-vpn-import-note',
			'style': 'display: none; margin-top: 8px; font-size: 13px; padding: 8px 12px; border-radius: 6px; line-height: 1.4;'
		});

		var ta = E('textarea', {
			'class': 'xfree-uplink-input',
			'rows': 5,
			'placeholder': _('Вставьте текст .conf, .ovpn или ссылку vpn://...'),
			'style': 'width: 100%; font-family: monospace; font-size: 12px; resize: vertical;'
		});

		var nameInput = E('input', {
			'class': 'xfree-uplink-input',
			'type': 'text',
			'placeholder': _('например, amnezia_nl'),
			'style': 'width: 100%;'
		});

		var protoSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%;'
		}, [
			E('option', { 'value': 'auto' }, [ _('Автоопределение') ]),
			E('option', { 'value': 'awg' }, [ _('AmneziaWG / WireGuard (.conf)') ]),
			E('option', { 'value': 'openvpn' }, [ _('OpenVPN (.ovpn)') ])
		]);

		function updateStatus(text, tone) {
			if (!text) {
				statusNote.style.display = 'none';
				statusNote.textContent = '';
				return;
			}
			statusNote.style.display = 'block';
			statusNote.textContent = text;
			if (tone === 'ok') {
				statusNote.style.background = 'rgba(34, 197, 94, 0.1)';
				statusNote.style.border = '1px solid rgba(34, 197, 94, 0.3)';
				statusNote.style.color = '#22c55e';
			} else if (tone === 'warn') {
				statusNote.style.background = 'rgba(234, 179, 8, 0.1)';
				statusNote.style.border = '1px solid rgba(234, 179, 8, 0.3)';
				statusNote.style.color = '#eab308';
			} else {
				statusNote.style.background = 'rgba(59, 130, 246, 0.1)';
				statusNote.style.border = '1px solid rgba(59, 130, 246, 0.25)';
				statusNote.style.color = 'inherit';
			}
		}

		function processText(text) {
			var val = String(text || '').trim();
			if (!val) {
				updateStatus('', '');
				return;
			}
			if (val.indexOf('vpn://') === 0) {
				updateStatus(_('Распаковка ссылки Amnezia vpn://...'), 'info');
				unpackAmneziaVpnKey(val).then(function(jsonObj) {
					var ext = extractAmneziaConfig(jsonObj);
					if (ext && ext.isStatic && ext.confText) {
						ta.value = ext.confText;
						protoSelect.value = (ext.type === 'openvpn') ? 'openvpn' : 'awg';
						if (!nameInput.value.trim() && ext.name) {
							nameInput.value = sanitizeIfaceName(ext.name);
						}
						updateStatus(_('✓ Распакована конфигурация Amnezia: ') + (ext.name || ext.type), 'ok');
					} else if (ext && ext.isSubscription) {
						updateStatus(_('ℹ Обнаружен ключ подписки Amnezia Premium (%s, %s). Скачайте .conf в личном кабинете или приложении Amnezia и вставьте сюда.').format(ext.name, ext.country.toUpperCase()), 'warn');
					} else {
						updateStatus(_('✓ JSON Amnezia распакован, но не содержит last_config'), 'warn');
					}
				}).catch(function(err) {
					updateStatus(_('Ошибка распаковки vpn://: ') + (err && err.message ? err.message : String(err)), 'warn');
				});
			} else if (val.indexOf('[Interface]') >= 0) {
				if (protoSelect.value === 'auto')
					protoSelect.value = 'awg';
				if (val.indexOf('vpn://') >= 0 || val.indexOf('Keenetic:') >= 0 || val.indexOf('HeaderProtectionKey') >= 0 || /\b\w+\s*=\s*\d+\s*-\s*\d+/.test(val)) {
					updateStatus(_('✓ Распознан AmneziaWG / Keenetic (диапазоны значений будут автоматически нормализованы)'), 'ok');
				} else {
					updateStatus(_('✓ Распознан формат WireGuard / AmneziaWG (.conf)'), 'ok');
				}
			} else if (val.indexOf('dev tun') >= 0 || val.indexOf('client') >= 0) {
				if (protoSelect.value === 'auto')
					protoSelect.value = 'openvpn';
				updateStatus(_('✓ Распознан формат OpenVPN (.ovpn)'), 'ok');
			}
		}

		ta.addEventListener('input', function() {
			processText(ta.value);
		});

		fileInput.addEventListener('change', function(ev) {
			var file = ev.target.files && ev.target.files[0];
			if (!file) return;
			var fname = file.name || '';
			if (!nameInput.value.trim()) {
				var base = fname.replace(/\.(conf|ovpn|txt)$/i, '');
				nameInput.value = sanitizeIfaceName(base);
			}
			var reader = new FileReader();
			reader.onload = function(e) {
				ta.value = e.target.result || '';
				processText(ta.value);
			};
			reader.readAsText(file);
		});

		function doSave(shouldCreate) {
			var body = String(ta.value || '').trim();
			if (!body) {
				self.setMessage(_('Введите текст конфигурации или выберите файл'), 'warn');
				return;
			}
			var proto = protoSelect.value;
			if (proto === 'auto') {
				if (body.indexOf('dev tun') >= 0 || body.indexOf('client') >= 0)
					proto = 'openvpn';
				else
					proto = 'awg';
			}
			var isOvpn = (proto === 'openvpn');
			var ext = isOvpn ? '.ovpn' : '.conf';
			var rawName = String(nameInput.value || '').trim();
			if (!rawName)
				rawName = isOvpn ? 'ovpn_1' : 'vpn_1';
			var sanitized = sanitizeIfaceName(rawName);
			var filename = sanitized.indexOf(ext) >= 0 ? sanitized : (sanitized + ext);
			var ifaceName = sanitized.replace(/\.(conf|ovpn)$/i, '');

			var b64;
			try {
				b64 = btoa(unescape(encodeURIComponent(body)));
			} catch (e) {
				self.setMessage(_('Ошибка кодирования текста в base64'), 'bad');
				return;
			}

			var kind = isOvpn ? 'openvpn' : 'custom';
			var arg = kind + '|' + filename + '|b64:' + b64;
			if (shouldCreate) {
				arg += '|create:' + ifaceName;
			}

			if (inModal && typeof ui.hideModal === 'function') {
				ui.hideModal();
			}

			if (s.onAction) {
				var confirmMsg = shouldCreate
					? _('Сохранить %s и создать туннель «%s»?').format(filename, ifaceName)
					: _('Сохранить файл %s в профиль?').format(filename);
				s.onAction('confSave', arg, confirmMsg);
			}
		}

		var cardChildren = [];

		if (!inModal) {
			cardChildren.push(
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap;' }, [
						E('strong', {}, [ _('Импорт конфигурации') ]),
						E('span', { 'class': 'muted' }, [ _('Amnezia / WireGuard / OpenVPN') ])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						latestCustom
							? E('span', { 'class': 'xfree-vpn-status is-ok', 'title': latestCustom.created || '' }, [ '📄 ' + latestCustom.file ])
							: E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('готов к загрузке') ])
					])
				])
			);
		}

		cardChildren.push(
			E('div', { 'class': 'xfree-vpn-fields-wrap', 'style': inModal ? 'padding: 4px 0;' : 'padding: 14px;' }, [
				E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;' }, [
					E('span', { 'style': 'font-weight: 500; font-size: 13px;' }, [ _('Текст конфига или ссылка vpn://') ]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function(ev) {
							ev.preventDefault();
							fileInput.click();
						}
					}, [ _('📂 Выбрать файл с диска') ]),
					fileInput
				]),
				ta,
				statusNote,
				E('div', { 'class': 'xfree-vpn-fields', 'style': 'margin-top: 12px;' }, [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('label', {}, [ _('Имя туннеля / конфига') ]),
						nameInput
					]),
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('label', {}, [ _('Протокол') ]),
						protoSelect
					])
				])
			])
		);

		cardChildren.push(
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': inModal ? 'margin-top: 14px;' : '' }, [
				E('button', {
					'class': 'btn cbi-button-positive',
					'type': 'button',
					'click': ui.createHandlerFn(view, function(ev) {
						ev.preventDefault();
						doSave(true);
					})
				}, [ _('Сохранить и создать туннель') ]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function(ev) {
						ev.preventDefault();
						doSave(false);
					})
				}, [ _('Сохранить файл') ]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function(ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						self._openConfManager('');
					}
				}, [ _('Менеджер .conf…') ])
			])
		);

		return E('div', {
			'class': inModal ? 'xfree-vpn-import-card is-modal-body' : 'xfree-vpn-gen xfree-vpn-import-card',
			'style': inModal ? 'border: none; background: transparent; padding: 0;' : 'border-left: 3px solid #3b82f6;'
		}, cardChildren);
	}

	_openAddTunnelDialog(view) {
		var self = this;
		var importCard = this._renderImportCard(view, true);

		xui.openDialog({
			title: _('Добавить новый туннель'),
			hint: _('Загрузите файл конфигурации (.conf, .ovpn), вставьте текст или ссылку vpn://'),
			size: 'wide',
			body: E('div', { 'class': 'xfree-vpn-add-dialog', 'style': 'padding: 4px 0;' }, [
				importCard
			]),
			actions: [
				{
					label: _('Выбрать из имеющихся .conf…'),
					variant: 'secondary',
					close: true,
					click: function() {
						self._createFromConf({ preventDefault: function(){}, stopPropagation: function(){} });
					}
				},
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				}
			]
		});
	}

	_collectFieldsIn(root, prefix) {
		var out = {};

		if (!root)
			return out;
		root.querySelectorAll('[data-xfree-vpn-field]').forEach(function(el) {
			var id = el.getAttribute('data-xfree-vpn-field') || '';

			if (prefix && id.indexOf(prefix) !== 0)
				return;
			out[id] = String(el.value || '').trim();
		});

		return out;
	}

	_modalPipeArgs(map, keys, stripPrefix) {
		var parts = [];
		var i;
		var k;
		var short;

		for (i = 0; i < keys.length; i++) {
			k = keys[i];
			short = k;
			if (stripPrefix && k.indexOf(stripPrefix) === 0)
				short = k.slice(stripPrefix.length);
			parts.push(short + '=' + (map[k] != null ? map[k] : ''));
		}

		return parts.join('|');
	}

	_showVpnDialog(title, children) {
		try {
			this.setBusy(false);
			return ui.showModal(title, children, 'cbi-modal', 'xfree-dialog', 'xfree-vpn-dialog');
		} catch (err) {
			this.setBusy(false);
			this.setMessage((err && err.message) ? err.message : String(err), 'bad');
			return null;
		}
	}

	_openNewTunnelDialog(kind, slotHint) {
		var self = this;
		var s = this._spec || {};
		var summary = this._summary || {};
		var warp = summary.warp || {};
		var proton = summary.proton || {};
		var ifaces = summary.ifaces || [];
		var k = String(kind || '').toLowerCase();
		var defaultIface = defaultNewIfaceName(slotHint || k, ifaces, summary);
		var fields = [];
		var body;
		var title;

		this.setBusy(false);

		if (k === 'warp') {
			title = _('Новый туннель WARP');
			fields = [
				textField('new_iface', _('Имя интерфейса'), defaultIface, 'warp'),
				selectField('new_warp_server', _('Сервер'), warp.server || 'def', WARP_SERVERS),
				selectField('new_warp_selection', _('Выбор endpoint'), warp.selection || 'best', WARP_SELECTION),
				selectField('new_warp_exclude_ru', _('Фильтр колоний RU'), warp.excludeRu != null ? String(warp.excludeRu) : '1', [
					{ v: '1', t: _('Вкл — без DME/LED/KJA/SVX') },
					{ v: '0', t: _('Выкл') }
				]),
				selectField('new_warp_profile', _('Профиль AWG'), warp.profile || '2.0:1', WARP_PROFILES),
				selectField('new_warp_mode', _('Режим'), warp.mode || 'local', WARP_MODES),
				selectField('new_warp_i1_mode', _('I1'), warp.i1Mode || 'fixed', WARP_I1),
				textField('new_warp_i1_domain', _('I1 domain/seed'), warp.i1Domain || '', _('для domain')),
				textField('new_warp_name', _('Имя .conf'), warp.name || '', _('авто'))
			];
		} else if (k === 'proton') {
			title = _('Новый туннель Proton');
			fields = [
				textField('new_iface', _('Имя интерфейса'), defaultIface, 'proton'),
				selectField('new_proton_country', _('Страна'), proton.country || 'NL', PROTON_COUNTRIES),
				selectField('new_proton_session_mode', _('Сессия'), proton.session_mode || 'guest', [
					{ v: 'guest', t: _('гостевая') },
					{ v: 'permanent', t: _('постоянная') }
				]),
				selectField('new_proton_profile', _('Профиль AWG'), proton.profile || '2.0:1', WARP_PROFILES),
				selectField('new_proton_i1_entropy', _('Энтропия I1'), proton.i1_entropy || 'r32', PROTON_ENTROPY_OPTIONS),
				selectField('new_proton_awg_noise', _('Шум AWG'), proton.awg_noise || '0', PROTON_NOISE_OPTIONS),
				selectField('new_proton_selection_mode', _('Выбор сервера'), proton.selection_mode || 'best', [
					{ v: 'best', t: 'best' },
					{ v: 'random', t: 'random' }
				]),
				textField('new_proton_mtu', 'MTU', proton.mtu || '1280', '1280'),
				selectField('new_proton_free_only', _('Только free'), proton.free_only || '1', [
					{ v: '1', t: _('да') },
					{ v: '0', t: _('нет') }
				]),
				selectField('new_proton_require_ipv6', 'IPv6', proton.require_ipv6 || '0', [
					{ v: '0', t: _('все') },
					{ v: '1', t: _('только IPv6') }
				]),
				textField('new_proton_name', _('Имя .conf'), proton.name || '', _('авто'))
			];
		} else {
			this.setMessage(_('Неизвестный тип: %s').format(kind), 'bad');
			return;
		}

		body = E('div', { 'class': 'xfree-vpn-fields xfree-vpn-modal-fields' }, fields);

		this._showVpnDialog(title, [
			E('p', { 'class': 'muted' }, [
				_('Сгенерировать .conf, создать интерфейс в профиле и применить на роутере.')
			]),
			body,
			E('div', { 'class': 'right xfree-vpn-dialog-actions' }, [
				E('button', {
					'type': 'button',
					'class': 'btn',
					'click': function(ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						ui.hideModal();
					}
				}, [ _('Отмена') ]),
				' ',
				E('button', {
					'type': 'button',
					'class': 'btn cbi-button-positive',
					'click': function(ev) {
						var f = self._collectFieldsIn(body, '');
						var iface = sanitizeIfaceName(f.new_iface);
						var arg;
						var action;

						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						if (!iface) {
							self.setMessage(_('Укажите имя интерфейса'), 'bad');
							return;
						}
						ui.hideModal();
						if (k === 'warp') {
							action = 'warpProvision';
							arg = iface + '|' + self._modalPipeArgs(f, [
								'new_warp_server', 'new_warp_profile', 'new_warp_mode',
								'new_warp_i1_mode', 'new_warp_i1_domain', 'new_warp_name',
								'new_warp_selection', 'new_warp_exclude_ru'
							], 'new_warp_');
						} else {
							action = 'protonProvision';
							arg = iface + '|' + self._modalPipeArgs(f, [
								'new_proton_country', 'new_proton_session_mode', 'new_proton_profile',
								'new_proton_name', 'new_proton_mtu', 'new_proton_free_only',
								'new_proton_require_ipv6', 'new_proton_selection_mode',
								'new_proton_i1_entropy', 'new_proton_awg_noise'
							], 'new_proton_');
						}
						if (s.onAction)
							s.onAction(action, arg);
					}
				}, [ _('Создать и применить') ])
			])
		]);
	}

	_parseMetaText(text) {
		var out = {};
		var lines = String(text || '').split(/\n/);
		var i;
		var line;
		var m;

		for (i = 0; i < lines.length; i++) {
			line = lines[i].replace(/\r$/, '').trim();
			m = line.match(/^META_([A-Z0-9_]+)=(.*)$/);
			if (m)
				out[m[1]] = m[2];
			else if (line.indexOf('IFACE=') === 0)
				out.IFACE = line.slice(6);
		}
		return out;
	}

	_openRebuildDialog(ifaceName, preferKind) {
		var self = this;
		var s = this._spec || {};

		if (!s.onAction) {
			this.setMessage(_('Нет обработчика действия'), 'bad');
			return;
		}

		this.setBusy(true);
		s.onAction('ifaceMeta', ifaceName, null, function(res, text) {
			var meta;
			var kind;
			var fields = [];
			var body;
			var profile;
			var sessionMode;

			self.setBusy(false);
			if (!res || (res.code && res.code !== 0)) {
				self.setMessage(_('Не удалось прочитать meta «%s»').format(ifaceName), 'bad');
				return;
			}
			meta = self._parseMetaText(text || '');
			kind = String(meta.GENERATOR_KIND || preferKind || '').toLowerCase();
			if (kind !== 'warp' && kind !== 'proton') {
				self.setMessage(_('Не удалось прочитать meta «%s»').format(ifaceName), 'bad');
				return;
			}

			if (kind === 'warp') {
				profile = '2.0:' + (meta.VARIANT_ID || '1');
				fields = [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [ _('Интерфейс') ]),
						E('div', {}, [ ifaceName ])
					]),
					selectField('rb_server', _('Сервер'), meta.SERVER_ID || 'def', WARP_SERVERS),
					selectField('rb_selection', _('Выбор endpoint'), meta.SELECTION_MODE || 'best', WARP_SELECTION),
					selectField('rb_exclude_ru', _('Фильтр колоний RU'), meta.EXCLUDE_RU != null ? String(meta.EXCLUDE_RU) : '1', [
						{ v: '1', t: _('Вкл — без DME/LED/KJA/SVX') },
						{ v: '0', t: _('Выкл') }
					]),
					selectField('rb_profile', _('Профиль AWG'), profile, WARP_PROFILES),
					selectField('rb_mode', _('Режим'), meta.PROFILE_MODE || 'local', WARP_MODES),
					selectField('rb_i1_mode', _('I1'), meta.I1_MODE || 'fixed', WARP_I1),
					textField('rb_i1_domain', _('I1 domain/seed'), meta.I1_DOMAIN || '', _('для domain'))
				];
			} else {
				profile = (meta.AWG_VERSION || '2.0') + ':' + (meta.VARIANT_ID || '1');
				sessionMode = (meta.SESSION_AUTH_MODE === 'guest') ? 'guest' : 'permanent';
				fields = [
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [ _('Интерфейс') ]),
						E('div', {}, [ ifaceName ])
					]),
					selectField('rb_country', _('Страна'), meta.COUNTRY_FILTER || meta.SERVER_COUNTRY || 'NL', PROTON_COUNTRIES),
					selectField('rb_session_mode', _('Сессия'), sessionMode, [
						{ v: 'guest', t: _('гостевая') },
						{ v: 'permanent', t: _('постоянная') }
					]),
					selectField('rb_profile', _('Профиль AWG'), profile, WARP_PROFILES),
					selectField('rb_i1_entropy', _('Энтропия I1'), meta.AWG_I1_ENTROPY || 'r32', PROTON_ENTROPY_OPTIONS),
					selectField('rb_awg_noise', _('Шум AWG'), meta.AWG_NOISE_ENABLED != null ? String(meta.AWG_NOISE_ENABLED) : '0', PROTON_NOISE_OPTIONS),
					selectField('rb_selection_mode', _('Выбор сервера'), meta.SELECTION_MODE || 'best', [
						{ v: 'best', t: 'best' },
						{ v: 'random', t: 'random' }
					]),
					textField('rb_mtu', 'MTU', meta.MTU || '1280', '1280'),
					selectField('rb_free_only', _('Только free'), meta.FREE_ONLY != null ? String(meta.FREE_ONLY) : '1', [
						{ v: '1', t: _('да') },
						{ v: '0', t: _('нет') }
					]),
					selectField('rb_require_ipv6', 'IPv6', meta.REQUIRE_IPV6 != null ? String(meta.REQUIRE_IPV6) : '0', [
						{ v: '0', t: _('все') },
						{ v: '1', t: _('только IPv6') }
					])
				];
			}

			body = E('div', { 'class': 'xfree-vpn-fields xfree-vpn-modal-fields' }, fields);
			self._showVpnDialog(_('Пересобрать «%s»').format(ifaceName), [
				E('p', { 'class': 'muted' }, [
					_('Параметры из source.conf.meta. После сохранения — новая генерация и apply.')
				]),
				body,
				E('div', { 'class': 'right xfree-vpn-dialog-actions' }, [
					E('button', {
						'type': 'button',
						'class': 'btn',
						'click': function(ev) {
							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							ui.hideModal();
						}
					}, [ _('Отмена') ]),
					' ',
					E('button', {
						'type': 'button',
						'class': 'btn cbi-button-positive',
						'click': function(ev) {
							var f = self._collectFieldsIn(body, '');
							var arg;

							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							ui.hideModal();
							if (kind === 'warp') {
								arg = ifaceName + '|' + self._modalPipeArgs({
									server: f.rb_server,
									selection: f.rb_selection,
									exclude_ru: f.rb_exclude_ru,
									profile: f.rb_profile,
									mode: f.rb_mode,
									i1_mode: f.rb_i1_mode,
									i1_domain: f.rb_i1_domain
								}, [
									'server', 'selection', 'exclude_ru', 'profile',
									'mode', 'i1_mode', 'i1_domain'
								], '');
							} else {
								arg = ifaceName + '|' + self._modalPipeArgs({
									country: f.rb_country,
									session_mode: f.rb_session_mode,
									profile: f.rb_profile,
									selection_mode: f.rb_selection_mode,
									mtu: f.rb_mtu,
									free_only: f.rb_free_only,
									require_ipv6: f.rb_require_ipv6,
									i1_entropy: f.rb_i1_entropy,
									awg_noise: f.rb_awg_noise
								}, [
									'country', 'session_mode', 'profile', 'selection_mode',
									'mtu', 'free_only', 'require_ipv6', 'i1_entropy', 'awg_noise'
								], '');
							}
							if (s.onAction)
								s.onAction('regenerateOpts', arg);
						}
					}, [ _('Пересобрать и применить') ])
				])
			]);
		});
	}

	_openConfManager(filterKind) {
		var self = this;
		var s = this._spec || {};
		var all = (this._summary && this._summary.confs) || [];
		var kindFilter = String(filterKind || '').toLowerCase();
		var confs = [];
		var list;
		var rows = [];
		var i;
		var c;
		var title;
		var hint;

		function reopen() {
			self._openConfManager(kindFilter);
		}

		function downloadText(name, text) {
			var a = document.createElement('a');
			var blob = new Blob([ text ], { type: 'text/plain;charset=utf-8' });

			a.href = URL.createObjectURL(blob);
			a.download = name;
			document.body.appendChild(a);
			a.click();
			setTimeout(function() {
				URL.revokeObjectURL(a.href);
				a.remove();
			}, 500);
		}

		function showEditor(kind, file, initial) {
			var ta = E('textarea', {
				'class': 'xfree-vpn-conf-editor',
				'rows': 18
			}, [ initial || '' ]);

			xui.openDialog({
				title: _('Редактировать %s').format(file),
				size: 'wide',
				hint: kind + ' / ' + file,
				body: ta,
				actions: [
					{
						label: _('Назад'),
						variant: 'secondary',
						close: true,
						click: function() {
							reopen();
						}
					},
					{
						label: _('Сохранить'),
						variant: 'primary',
						close: false,
						click: function() {
							var body = String(ta.value || '');
							var b64;

							try {
								b64 = btoa(unescape(encodeURIComponent(body)));
							} catch (e) {
								self.setMessage(_('Не удалось закодировать файл'), 'bad');
								return;
							}
							ui.hideModal();
							if (s.onAction)
								s.onAction('confSave', kind + '|' + file + '|b64:' + b64);
						}
					}
				]
			});
		}

		function extractConfBody(text) {
			var raw = String(text || '');
			var a = raw.indexOf('CONF_BODY_BEGIN\n');
			var b = raw.indexOf('\nCONF_BODY_END');

			if (a >= 0 && b > a)
				return raw.slice(a + 'CONF_BODY_BEGIN\n'.length, b);
			return raw;
		}

		function loadAnd(kind, file, mode) {
			if (!s.onAction)
				return;
			self.setBusy(true);
			s.onAction('confShow', kind + '|' + file, null, function(res, text) {
				var body = extractConfBody(text || '');

				self.setBusy(false);
				if (!res || (res.code && res.code !== 0)) {
					self.setMessage(_('Не удалось прочитать %s').format(file), 'bad');
					return;
				}

				if (mode === 'view') {
					xui.openDialog({
						title: _('Просмотр %s').format(file),
						size: 'wide',
						body: E('pre', { 'class': 'xfree-vpn-conf-view' }, [ body ]),
						actions: [{
							label: _('Назад'),
							variant: 'secondary',
							close: true,
							click: function() {
								reopen();
							}
						}]
					});
				} else if (mode === 'download') {
					downloadText(file, body);
					reopen();
				} else if (mode === 'edit') {
					showEditor(kind, file, body);
				}
			});
		}

		for (i = 0; i < all.length; i++) {
			c = all[i];
			if (kindFilter && String(c.kind || '').toLowerCase() !== kindFilter)
				continue;
			confs.push(c);
		}

		if (!confs.length) {
			this.setMessage(kindFilter
				? _('Нет .conf для «%s» — сначала сгенерируйте').format(kindFilter)
				: _('Нет сгенерированных .conf — сначала сгенерируйте WARP/Proton'), 'warn');
			return;
		}

		var unusedCount = 0;
		for (i = 0; i < confs.length; i++) {
			if (!confs[i].usedBy)
				unusedCount++;
		}

		for (i = 0; i < confs.length; i++) {
			c = confs[i];
			(function(row) {
				var metaBits = [];

				if (!kindFilter && row.kind)
					metaBits.push(row.kind);
				if (row.created)
					metaBits.push(row.created);

				rows.push(E('div', { 'class': 'xfree-vpn-conf-row' }, [
					E('div', { 'class': 'xfree-vpn-conf-name' }, [
						E('div', { 'style': 'display: flex; align-items: center; gap: 8px; flex-wrap: wrap;' }, [
							E('strong', {}, [ row.file ]),
							row.usedBy
								? E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size: 11px;' }, [ '✓ ' + _('используется: %s').format(row.usedBy) ])
								: E('span', { 'class': 'xfree-vpn-badge', 'style': 'font-size: 11px;' }, [ _('не используется') ])
						]),
						metaBits.length
							? E('div', { 'class': 'muted xfree-vpn-conf-meta' }, [
								metaBits.join(' · ')
							])
							: ''
					]),
					E('div', { 'class': 'xfree-vpn-conf-actions' }, [
						xui.dialogBtn({
							label: _('Просмотр'),
							variant: 'ghost',
							compact: true,
							click: function() {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'view');
							}
						}),
						xui.dialogBtn({
							label: _('Скачать'),
							variant: 'ghost',
							compact: true,
							click: function() {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'download');
							}
						}),
						xui.dialogBtn({
							label: _('Изменить'),
							variant: 'ghost',
							compact: true,
							click: function() {
								ui.hideModal();
								loadAnd(row.kind, row.file, 'edit');
							}
						}),
						xui.dialogBtn({
							label: _('Удалить'),
							variant: 'danger',
							compact: true,
							click: function() {
								ui.hideModal();
								if (s.onAction) {
									var confirmMsg = row.usedBy
										? _('ВНИМАНИЕ: конфигурация используется интерфейсом %s! Удалить %s?').format(row.usedBy, row.file)
										: _('Удалить %s?').format(row.file);
									s.onAction('confDelete', row.kind + '|' + row.file, confirmMsg);
								}
							}
						})
					])
				]));
			})(c);
		}

		if (kindFilter === 'warp') {
			title = _('Конфигурации WARP .conf');
			hint = _('Файлы генератора WARP. Дата — локальное время роутера (mtime). После правки — «Обновить» на туннеле.');
		} else if (kindFilter === 'proton') {
			title = _('Конфигурации Proton .conf');
			hint = _('Файлы генератора Proton. Дата — локальное время роутера (mtime). После правки — «Обновить» на туннеле.');
		} else {
			title = _('Конфигурации .conf');
			hint = _('Файлы в каталогах генераторов. Дата — локальное время роутера (mtime).');
		}

		list = E('div', { 'class': 'xfree-vpn-conf-list' }, rows);
		xui.openDialog({
			title: title,
			size: 'lg',
			hint: hint,
			body: list,
			actions: [
				{
					label: unusedCount > 0
						? _('Удалить неиспользуемые (%d)').format(unusedCount)
						: _('Удалить неиспользуемые'),
					variant: 'danger',
					disabled: unusedCount === 0,
					click: function() {
						ui.hideModal();
						if (s.onAction) {
							var confirmMsg = unusedCount > 0
								? _('Удалить неиспользуемые файлы конфигураций (%d шт.)?').format(unusedCount)
								: _('Удалить неиспользуемые файлы конфигураций?');
							s.onAction('confDeleteUnused', kindFilter || '', confirmMsg);
						}
					}
				},
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				}
			]
		});
	}

	_deleteIface(ev, ifaceName) {
		var self = this;
		var s = this._spec || {};

		ev.preventDefault();
		ev.stopPropagation();
		this._pickSelect(
			_('Удалить «%s»').format(ifaceName),
			_('Режим очистки'),
			[
				{ v: 'basic', t: _('basic — только туннель') },
				{ v: 'reconcile', t: _('reconcile — + full-reconcile') },
				{ v: 'orphans', t: _('orphans — + cleanup-orphans') },
				{ v: 'full', t: _('full — reconcile + orphans') }
			],
			function(mode) {
				if (s.onAction)
					s.onAction('delete', ifaceName + '|' + mode,
						_('Удалить туннель «%s» (%s)?').format(ifaceName, mode));
			}
		);
	}

	collectFields(prefix) {
		var out = {};
		var root = this;

		this.querySelectorAll('[data-xfree-vpn-field]').forEach(function(el) {
			var id = el.getAttribute('data-xfree-vpn-field') || '';

			if (prefix && id.indexOf(prefix) !== 0)
				return;
			out[id] = String(el.value || '').trim();
		});

		return out;
	}

	_pipeArgs(map, keys) {
		var parts = [];
		var i;
		var k;
		var short;

		for (i = 0; i < keys.length; i++) {
			k = keys[i];
			short = k.replace(/^warp_/, '').replace(/^proton_/, '');
			parts.push(short + '=' + (map[k] != null ? map[k] : ''));
		}

		return parts.join('|');
	}

	_saveWarp(ev) {
		var s = this._spec || {};
		var f = this.collectFields('warp_');
		var arg;

		ev.preventDefault();
		arg = this._pipeArgs(f, [
			'warp_server', 'warp_profile', 'warp_mode',
			'warp_i1_mode', 'warp_i1_domain', 'warp_name',
			'warp_selection', 'warp_exclude_ru'
		]);
		if (s.onAction)
			s.onAction('warpSave', arg);
	}

	_saveProton(ev) {
		var s = this._spec || {};
		var f = this.collectFields('proton_');
		var arg;

		ev.preventDefault();
		arg = this._pipeArgs(f, [
			'proton_country', 'proton_session_mode', 'proton_profile',
			'proton_name', 'proton_mtu', 'proton_free_only',
			'proton_require_ipv6', 'proton_selection_mode',
			'proton_i1_entropy', 'proton_awg_noise'
		]);
		if (s.onAction)
			s.onAction('protonSave', arg);
	}

	_openPeerConfigDialog(peer, initialTab) {
		var self = this;
		var s = this._spec || {};
		self.setBusy(true);

		if (!s.onAction) {
			self.setBusy(false);
			return;
		}

		s.onAction('peerShowConfig', peer.slug, '', function(res, report) {
			self.setBusy(false);
			if (!res || res.code !== 0) {
				self.setMessage(_('Не удалось получить конфигурацию клиента: %s').format(report || ''), 'bad');
				return;
			}

			var confText = extractConfBody(res.stdout);
			if (!confText) {
				self.setMessage(_('Конфигурация клиента пуста'), 'warn');
				return;
			}

			loadUqr().then(function(Uqr) {
				var filename = (peer.slug || peer.name || 'client') + '.conf';
				var localSvg = renderQrSvg(Uqr, confText);
				var activeTab = (initialTab === 'conf') ? 'conf' : 'qr';

				var metaRow = E('div', {
					'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; font-size: 13px;'
				}, [
					E('div', {}, [
						E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'margin-right: 8px;' }, [ peer.ip || '' ]),
						E('span', { 'class': 'muted' }, [ _('Endpoint: ') + (peer.endpoint || 'default') ])
					]),
					peer.keepalive ? E('span', { 'class': 'muted font-mono', 'style': 'font-size: 11px;' }, [ _('keepalive: %ds').format(peer.keepalive) ]) : ''
				]);

				var qrPaneChildren = [];
				if (localSvg) {
					var qrWrap = E('div', { 'class': 'xfree-vpn-qr-wrap' });
					qrWrap.innerHTML = localSvg;
					qrPaneChildren.push(qrWrap);
					qrPaneChildren.push(E('p', {
						'class': 'muted',
						'style': 'text-align: center; margin: 6px 0 10px 0; font-size: 12px;'
					}, [ _('Отсканируйте камерой в мобильном приложении AmneziaWG или WireGuard') ]));
				} else {
					qrPaneChildren.push(E('div', {
						'class': 'alert-message warning',
						'style': 'margin: 16px 0;'
					}, [
						_('Не удалось сгенерировать QR-код (модуль uqr недоступен). Используйте вкладку «Конфиг» для скачивания файла .conf или копирования настроек.')
					]));
				}

				var qrPane = E('div', { 'class': 'xfree-dialog-tab-pane' }, qrPaneChildren);

				var confTextArea = E('textarea', {
					'class': 'xfree-vpn-conf-textarea',
					'readonly': 'readonly',
					'rows': 9,
					'style': 'margin-bottom: 6px;'
				}, [ confText ]);

				var confPane = E('div', { 'class': 'xfree-dialog-tab-pane' }, [
					confTextArea,
					E('p', { 'class': 'muted', 'style': 'margin: 4px 0 8px 0; font-size: 12px;' }, [
						_('Импортируйте этот файл конфигурации в приложение AmneziaWG на компьютере или смартфоне.')
					])
				]);

				var tabQrBtn = E('button', {
					'class': 'xfree-dialog-tab-btn' + (activeTab === 'qr' ? ' is-active' : ''),
					'type': 'button',
					'click': function() { switchTab('qr'); }
				}, [ '📱 ' + _('QR-код') ]);

				var tabConfBtn = E('button', {
					'class': 'xfree-dialog-tab-btn' + (activeTab === 'conf' ? ' is-active' : ''),
					'type': 'button',
					'click': function() { switchTab('conf'); }
				}, [ '📄 ' + _('Конфиг (.conf)') ]);

				var tabsBar = E('div', { 'class': 'xfree-dialog-tabs' }, [ tabQrBtn, tabConfBtn ]);

				function switchTab(tab) {
					activeTab = tab;
					if (tab === 'qr') {
						tabQrBtn.classList.add('is-active');
						tabConfBtn.classList.remove('is-active');
						qrPane.style.display = 'block';
						confPane.style.display = 'none';
					} else {
						tabQrBtn.classList.remove('is-active');
						tabConfBtn.classList.add('is-active');
						qrPane.style.display = 'none';
						confPane.style.display = 'block';
					}
				}

				switchTab(activeTab);

				var copyBtn = E('button', {
					'class': 'btn ghost-compact is-primary',
					'type': 'button',
					'style': 'margin-right: 8px;',
					'click': function(ev) {
						copyToClipboard(confText, ev.target);
					}
				}, [ '📋 ' + _('Скопировать') ]);

				var downloadBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'style': 'margin-right: 8px;',
					'click': function() {
						downloadTextFile(filename, confText);
					}
				}, [ '💾 ' + _('Скачать .conf') ]);

				var closeBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function() { ui.hideModal(); }
				}, [ _('Закрыть') ]);

				var buttonsBar = E('div', { 'style': 'display: flex; justify-content: flex-end; margin-top: 14px;' }, [
					copyBtn,
					downloadBtn,
					closeBtn
				]);

				var modalBody = [
					metaRow,
					tabsBar,
					qrPane,
					confPane,
					buttonsBar
				];

				self._showVpnDialog(_('Клиент «%s»').format(peer.name), modalBody);
			});
		});
	}

	_openPeerFreeTurnDialog(peer, awg) {
		var self = this;
		var s = this._spec || {};
		self.setBusy(true);

		if (!s.onAction) {
			self.setBusy(false);
			return;
		}

		s.onAction('peerFreeTurnConfig', peer.slug, '', function(res, report) {
			self.setBusy(false);
			if (!res || res.code !== 0) {
				var errMsg = _('Не удалось сформировать ссылку FreeTurn: %s').format(report || (res && res.stderr) || '');
				self.setMessage(errMsg, 'bad');
				ui.addNotification(null, E('p', errMsg), 'danger');
				return;
			}

			var stdout = res.stdout || '';
			var m = stdout.match(/(freeturn:\/\/[^\s\r\n"']+)/);
			var freeturnUri = m ? m[1] : '';

			if (!freeturnUri) {
				var noUriMsg = _('В выводе скрипта не найдена ссылка freeturn://');
				self.setMessage(noUriMsg, 'bad');
				ui.addNotification(null, E('p', noUriMsg), 'danger');
				return;
			}

			Promise.resolve(loadUqr()).catch(function() { return null; }).then(function(Uqr) {
				try {
					var localSvg = renderQrSvg(Uqr, freeturnUri);

					var metaRow = E('div', {
						'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; font-size: 13px;'
					}, [
						E('div', {}, [
							E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'margin-right: 8px;' }, [ peer.ip || '' ]),
							E('span', { 'class': 'muted' }, [ _('Порт FreeTurn: ') + ((awg && awg.freeTurnPort) || '56000') + ' (UDP)' ])
						]),
						E('span', { 'class': 'xfree-vpn-status is-ok', 'style': 'font-size: 11px;' }, [ _('FreeTurn v5 ready') ])
					]);

					var qrPaneChildren = [];
					if (localSvg) {
						var qrWrap = E('div', { 'class': 'xfree-vpn-qr-wrap' });
						qrWrap.innerHTML = localSvg;
						qrPaneChildren.push(qrWrap);
						qrPaneChildren.push(E('p', {
							'class': 'muted',
							'style': 'text-align: center; margin: 6px 0 10px 0; font-size: 12px;'
						}, [ _('Отсканируйте камерой в Android-приложении turn-proxy-android (кнопка «+» ➔ «Сканировать QR-код» на вкладке «Соединение»)') ]));
					} else {
						qrPaneChildren.push(E('div', {
							'class': 'alert-message warning',
							'style': 'margin: 16px 0;'
						}, [
							_('Не удалось сгенерировать QR-код (модуль uqr недоступен). Скопируйте ссылку ниже.')
						]));
					}

					var uriTextArea = E('textarea', {
						'class': 'xfree-vpn-conf-textarea',
						'readonly': 'readonly',
						'rows': 3,
						'style': 'margin-bottom: 6px; word-break: break-all; font-family: monospace; font-size: 11px;'
					}, [ freeturnUri ]);

					var linkPane = E('div', { 'style': 'margin-top: 10px;' }, [
						E('label', { 'style': 'font-size: 12px; font-weight: bold; margin-bottom: 4px; display: block;' }, [
							_('Ссылка для импорта в приложение (freeturn://):')
						]),
						uriTextArea,
						E('p', { 'class': 'muted', 'style': 'margin: 4px 0 8px 0; font-size: 12px;' }, [
							_('В приложении turn-proxy-android нажмите «+» ➔ «Вставить ссылку». Адрес роутера, порт 56000, ключ обфускации и ключи клиента подставятся автоматически.')
						])
					]);

					var copyBtn = E('button', {
						'class': 'btn ghost-compact is-primary',
						'type': 'button',
						'style': 'margin-right: 8px;',
						'click': function(ev) {
							copyToClipboard(freeturnUri, ev.target);
						}
					}, [ '📋 ' + _('Скопировать ссылку') ]);

					var closeBtn = E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function() { ui.hideModal(); }
					}, [ _('Закрыть') ]);

					var buttonsBar = E('div', { 'style': 'display: flex; justify-content: flex-end; margin-top: 14px;' }, [
						copyBtn,
						closeBtn
					]);

					var modalBody = [
						metaRow,
						E('div', { 'class': 'xfree-dialog-tab-pane' }, qrPaneChildren),
						linkPane,
						buttonsBar
					];

					self._showVpnDialog(_('FreeTurn подключение «%s»').format(peer.name), modalBody);
				} catch (diagErr) {
					var renderErr = _('Ошибка отображения диалога FreeTurn: %s').format(diagErr.message || String(diagErr));
					self.setMessage(renderErr, 'bad');
					ui.addNotification(null, E('p', renderErr), 'danger');
				}
			});
		});
	}

	_openAddPeerDialog(awg) {
		var self = this;
		var s = this._spec || {};
		var nameInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'placeholder': 'client3, sveta, iphone...',
			'style': 'width: 100%; margin-top: 4px;'
		});

		var epOpts = [
			E('option', { 'value': '' }, [ _('Default Endpoint сервера (%s)').format(awg.defaultEndpoint || 'WAN') ])
		];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [ choices[i].label ]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'placeholder': _('Или укажите хост:порт вручную (необязательно)'),
			'style': 'width: 100%; margin-top: 6px;'
		});

		var nameHint = E('p', { 'class': 'muted', 'style': 'font-size: 11px; margin-top: 4px;' }, [
			_('Только латиница, цифры, дефис и подчёркивание')
		]);
		nameInput.addEventListener('input', function() {
			var val = nameInput.value || '';
			var slug = slugifyPeerName(val);
			if (slug && slug !== val) {
				nameHint.textContent = _('Имя для системы: %s').format(slug);
			} else {
				nameHint.textContent = _('Только латиница, цифры, дефис и подчёркивание');
			}
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('label', { 'style': 'font-weight: 600;' }, [ _('Имя клиента:') ]),
				nameInput,
				nameHint
			]),
			E('div', { 'style': 'margin-bottom: 16px;' }, [
				E('label', { 'style': 'font-weight: 600;' }, [ _('Endpoint подключения:') ]),
				epSelect,
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px;' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function() { ui.hideModal(); }
				}, [ _('Отмена') ]),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function() {
						var rawName = String(nameInput.value || '').trim();
						if (!rawName) {
							nameInput.focus();
							return;
						}
						var cleanName = slugifyPeerName(rawName);
						if (!cleanName) {
							self.setMessage(_('Имя клиента содержит недопустимые символы'), 'bad');
							nameInput.focus();
							return;
						}
						var chosenEp = String(customEpInput.value || '').trim() || epSelect.value;
						var arg = cleanName + (chosenEp ? '|' + chosenEp : '');
						ui.hideModal();
						if (s.onAction)
							s.onAction('peerAdd', arg, _('Создать клиента «%s»?').format(cleanName));
					}
				}, [ _('Создать') ])
			])
		];

		self._showVpnDialog(_('Новый VPN-клиент'), body);
		setTimeout(function() { nameInput.focus(); }, 100);
	}

	_openChangeEndpointDialog(awg) {
		var self = this;
		var s = this._spec || {};
		var currentEp = awg.defaultEndpoint || '';

		var epOpts = [];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [ choices[i].label ]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'value': currentEp,
			'placeholder': 'domain.tld:51820 или 1.2.3.4:51820',
			'style': 'width: 100%; margin-top: 6px;'
		});

		epSelect.addEventListener('change', function() {
			if (epSelect.value)
				customEpInput.value = epSelect.value;
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 8px;' }, [
					_('Default Endpoint используется как адрес сервера в создаваемых клиентских .conf-файлах.')
				]),
				E('label', { 'style': 'font-weight: 600;' }, [ _('Выберите из обнаруженных адресов:') ]),
				epSelect,
				E('label', { 'style': 'font-weight: 600; display: block; margin-top: 8px;' }, [ _('Или укажите вручную:') ]),
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px;' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function() { ui.hideModal(); }
				}, [ _('Отмена') ]),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function() {
						var ep = String(customEpInput.value || '').trim();
						if (!ep) {
							customEpInput.focus();
							return;
						}
						ui.hideModal();
						if (s.onAction)
							s.onAction('serverSetEndpoint', ep, _('Установить Default Endpoint сервера: %s?').format(ep));
					}
				}, [ _('Сохранить') ])
			])
		];

		self._showVpnDialog(_('Смена Default Endpoint сервера'), body);
	}

	_openPeerEndpointDialog(peer, awg) {
		var self = this;
		var s = this._spec || {};
		var currentEp = peer.endpoint || awg.defaultEndpoint || '';

		var epOpts = [
			E('option', { 'value': '' }, [ _('Использовать Default Endpoint сервера (%s)').format(awg.defaultEndpoint || '') ])
		];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [ choices[i].label ]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'value': currentEp,
			'placeholder': 'host:port',
			'style': 'width: 100%; margin-top: 6px;'
		});

		epSelect.addEventListener('change', function() {
			if (epSelect.value)
				customEpInput.value = epSelect.value;
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 8px;' }, [
					_('Индивидуальный Endpoint подключения для клиента «%s».').format(peer.name)
				]),
				E('label', { 'style': 'font-weight: 600;' }, [ _('Выбрать из вариантов:') ]),
				epSelect,
				E('label', { 'style': 'font-weight: 600; display: block; margin-top: 8px;' }, [ _('Или адрес:порт:') ]),
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px;' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function() { ui.hideModal(); }
				}, [ _('Отмена') ]),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function() {
						var ep = String(customEpInput.value || '').trim();
						ui.hideModal();
						if (s.onAction)
							s.onAction('peerUpdateEndpoint', peer.slug + '|' + ep,
								_('Обновить Endpoint для клиента «%s» на %s?').format(peer.name, ep || _('default')));
					}
				}, [ _('Сохранить') ])
			])
		];

		self._showVpnDialog(_('Endpoint для «%s»').format(peer.name), body);
	}

	_openNatHelpDialog() {
		ui.showModal(_('Как обойти NAT и подключиться к домашнему серверу'), [
			E('div', { 'class': 'xfree-modal-body', 'style': 'font-size: 13px; line-height: 1.5;' }, [
				E('p', {}, [
					_('Если у роутера серый IP-адрес (провайдерский CGNAT 100.64.0.0/10), внешние входящие подключения из интернета блокируются оборудованием провайдера на корню. Ни AmneziaWG напрямую, ни FreeTurn (поскольку VK TURN должен переслать пакет на роутер) достучаться до роутера не смогут.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, [ '1. ' + _('Услуга «Белый IP» у провайдера (Рекомендуется)') ]),
				E('p', { 'class': 'muted' }, [
					_('Самый стабильный и простой путь. В личном кабинете вашего интернет-провайдера подключите услугу «Статический IP» или «Публичный IP» (обычно 100–150 ₽/мес). После этого роутер получит прямой белый адрес, и все клиенты смогут подключаться без костылей.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, [ '2. ' + _('Использование IPv6') ]),
				E('p', { 'class': 'muted' }, [
					_('Многие провайдеры с CGNAT по IPv4 параллельно бесплатно выдают полноценный публичный префикс IPv6. Если мобильный оператор вашего телефона также поддерживает IPv6, вы можете указать IPv6-адрес сервера в настройках пиров и подключаться напрямую.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, [ '3. ' + _('Реверсивный туннель через VPS (Rathole / FRP / WireGuard)') ]),
				E('p', { 'class': 'muted' }, [
					_('Домашний роутер сам устанавливает постоянное исходящее соединение на внешний VPS (исходящие соединения провайдер не блокирует). VPS принимает подключения клиентов из интернета и пробрасывает трафик внутрь на роутер.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, [ '4. ' + _('Tailscale / NetBird (P2P Mesh + DERP-релеи)') ]),
				E('p', { 'class': 'muted' }, [
					_('Tailscale устанавливается на роутер и клиентские устройства. Если прямое P2P соединение невозможно из-за строгого CGNAT, трафик автоматически пересылается через зашифрованные промежуточные релеи (DERP) без белого IP.')
				])
			]),
			E('div', { 'class': 'right', 'style': 'margin-top: 16px;' }, [
				E('button', {
					'class': 'btn is-primary',
					'click': ui.hideModal
				}, [ _('Понятно') ])
			])
		]);
	}

	_openFreeTurnConfigDialog(awg) {
		var self = this;
		var s = this._spec || {};
		var currentPort = awg.freeTurnPort || '56000';

		var portInput = E('input', {
			'type': 'number',
			'min': '1',
			'max': '65535',
			'value': currentPort,
			'class': 'cbi-input-text',
			'style': 'width: 100%; font-size: 14px; padding: 6px 10px; margin-top: 6px;'
		});

		var presets = [
			{ port: '56000', label: _('56000 (по умолчанию)') },
			{ port: '443', label: _('443 (HTTPS/QUIC)') },
			{ port: '8443', label: _('8443') },
			{ port: '3478', label: _('3478 (STUN)') },
			{ port: '51820', label: _('51820 (AWG)') },
			{ port: '1194', label: _('1194 (OpenVPN)') }
		];

		var presetBtns = presets.map(function(p) {
			return E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'style': 'font-size: 11px; padding: 3px 8px;',
				'title': _('Установить порт %s').format(p.port),
				'click': function(ev) {
					ev.preventDefault();
					portInput.value = p.port;
				}
			}, [ p.label ]);
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 14px;' }, [
				E('p', { 'style': 'margin: 0 0 8px 0; font-size: 13px;' }, [
					_('Внешний UDP-порт роутера, на котором служба FreeTurn принимает входящий замаскированный трафик от клиентских приложений.')
				]),
				E('label', { 'style': 'font-weight: 600; display: block;' }, [ _('Внешний порт (UDP):') ]),
				portInput,
				E('div', { 'style': 'margin-top: 8px;' }, [
					E('span', { 'class': 'muted', 'style': 'font-size: 11px; display: block; margin-bottom: 4px;' }, [
						_('Быстрый выбор популярного порта:')
					]),
					E('div', { 'style': 'display: flex; flex-wrap: wrap; gap: 6px;' }, presetBtns)
				]),
				E('div', { 'class': 'muted', 'style': 'margin-top: 12px; font-size: 12px; line-height: 1.4;' }, [
					E('span', { 'style': 'display: block; margin-bottom: 2px;' }, [ _('При сохранении:') ]),
					E('span', { 'style': 'display: block;' }, [ '• ' + _('Обновляется правило входящего трафика в Firewall (Allow-free-turn)') ]),
					E('span', { 'style': 'display: block;' }, [ '• ' + _('Перезапускается служба /etc/init.d/free-turn с новым портом') ]),
					E('span', { 'style': 'display: block;' }, [ '• ' + _('Все новые ссылки freeturn:// и QR-коды клиентов будут генерироваться для этого порта') ])
				])
			]),
			E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 18px; border-top: 1px solid var(--border-subtle, #e5e5e5); padding-top: 12px;' }, [
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'title': _('Полная перенастройка бинарника, Firewall и procd'),
					'click': function(ev) {
						ui.hideModal();
						self._act(ev, 'freeTurnSetup', '', {
							title: _('Перенастройка FreeTurn прокси'),
							message: _('Перенастроить службу FreeTurn прокси?'),
							detail: _('Будет проверен бинарник, обновлена конфигурация procd сервиса /etc/init.d/free-turn и правила Firewall.'),
							confirmText: _('Перенастроить'),
							tone: 'primary',
							icon: '⚙️'
						});
					}
				}, [ _('Перенастроить всё') ]),
				E('div', { 'style': 'display: flex; gap: 8px;' }, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function() { ui.hideModal(); }
					}, [ _('Отмена') ]),
					E('button', {
						'class': 'btn is-primary',
						'type': 'button',
						'click': function() {
							var raw = String(portInput.value || '').trim();
							var p = parseInt(raw, 10);
							if (isNaN(p) || p < 1 || p > 65535) {
								ui.addNotification(null, E('p', {}, [ _('Укажите корректный номер порта от 1 до 65535') ]), 'danger');
								portInput.focus();
								return;
							}
							ui.hideModal();
							if (s.onAction) {
								s.onAction('freeTurnSetPort', String(p),
									_('Сменить внешний порт FreeTurn на %s (с обновлением Firewall и перезапуском службы)?').format(p));
							}
						}
					}, [ _('Сохранить порт') ])
				])
			])
		];

		self._showVpnDialog(_('Настройка FreeTurn Proxy'), body);
	}

	_renderProtocolsSection(view) {
		var self = this;
		var ps = this._protocolsStatus || {};
		var isBusy = this._busy;
		var isLoading = !!(this._loading || !this._protocolsLoaded);
		var awgUpdateAvailable = (ps.awg_update === '1' || (ps.awg && /1\.0/.test(ps.awg)));

		var protocols = [
			{
				id: 'awg',
				title: 'AmneziaWG / WireGuard',
				descr: _('Ядро и инструменты для работы с туннелями AmneziaWG (продвинутая маскировка пакетов) и WireGuard.'),
				status: ps.awg || _('Не установлен'),
				rawVersion: ps.awg_version || '',
				updateAvailable: awgUpdateAvailable,
				canRemove: false,
				installTitle: _('Установить AmneziaWG'),
				confirmInstall: awgUpdateAvailable
					? _('Обновить AmneziaWG до актуального релиза (v2.0+) из репозитория Slava-Shchipunov/awg-openwrt?')
					: _('Установить модули ядра и утилиты AmneziaWG/WireGuard?')
			},
			{
				id: 'openvpn',
				title: 'OpenVPN',
				descr: _('Клиент OpenVPN с поддержкой шифрования SSL/TLS и туннелей TUN/TAP.'),
				status: ps.openvpn || _('Не установлен'),
				canRemove: true,
				installTitle: _('Установить OpenVPN'),
				confirmInstall: _('Установить OpenVPN (openvpn-openssl и kmod-tun)?'),
				confirmRemove: _('Удалить OpenVPN из системы?')
			},
			{
				id: 'vless',
				title: 'Sing-box (VLESS)',
				descr: _('Универсальный прокси-клиент Sing-box для современных протоколов VLESS Reality, Trojan, ShadowSocks.'),
				status: ps.vless || _('Не установлен'),
				canRemove: true,
				installTitle: _('Установить Sing-box'),
				confirmInstall: _('Установить Sing-box и пакет корневых сертификатов ca-bundle?'),
				confirmRemove: _('Удалить Sing-box из системы?')
			},
			{
				id: 'freeturn',
				title: 'FreeTurn Client',
				descr: _('Клиентский бинарник FreeTurn Proxy для обфусцированных туннелей через STUN/TURN серверы.'),
				status: ps.freeturn || _('Не установлен'),
				canRemove: true,
				installTitle: _('Установить FreeTurn'),
				confirmInstall: _('Скачать и установить FreeTurn Client с GitHub?'),
				confirmRemove: _('Удалить FreeTurn Client из системы?')
			}
		];

		var cards = protocols.map(function(item) {
			var isInstalled = item.status && item.status !== 'Не установлен';
			var statusClass = isInstalled ? 'is-ok' : 'is-muted';
			var actions = [];

			if (isLoading) {
				actions.push(E('button', {
					'class': 'ghost ghost-compact is-loading',
					'type': 'button',
					'disabled': true
				}, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 110px; height: 14px;' }) ]));

				return E('div', { 'class': 'xfree-vpn-gen is-loading', 'style': 'margin-bottom: 0;' }, [
					E('div', { 'class': 'xfree-vpn-gen-head' }, [
						E('div', { 'class': 'xfree-vpn-gen-title' }, [
							E('strong', {}, [ item.title ])
						]),
						E('div', { 'class': 'xfree-vpn-gen-badges' }, [
							E('span', { 'class': 'xfree-vpn-status is-skeleton' }, [
								E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 75px; height: 16px;' })
							])
						])
					]),
					E('div', { 'class': 'xfree-vpn-fields-wrap', 'style': 'padding: 14px;' }, [
						E('p', { 'class': 'muted', 'style': 'margin: 0 0 14px 0; font-size: 13px; line-height: 1.4;' }, [ item.descr ]),
						E('div', { 'style': 'display: flex; gap: 8px; align-items: center;' }, actions)
					])
				]);
			}

			var installBtnClass = 'btn ghost-compact is-primary';
			if (isInstalled && !item.updateAvailable) {
				installBtnClass = 'ghost ghost-compact';
			}

			var installBtnLabel;
			if (!isInstalled) {
				installBtnLabel = item.installTitle;
			} else if (item.id === 'awg' && item.updateAvailable) {
				installBtnLabel = '⚡ ' + _('Обновить до 2.0+');
			} else {
				installBtnLabel = _('Переустановить');
			}

			var installBtn = E('button', {
				'class': installBtnClass,
				'type': 'button',
				'disabled': isBusy ? true : null,
				'click': function(ev) {
					ev.preventDefault();
					if (self._spec && self._spec.onAction) {
						self._spec.onAction('protocolsInstall', item.id, item.confirmInstall);
					}
				}
			}, [ installBtnLabel ]);
			actions.push(installBtn);

			if (item.canRemove && isInstalled) {
				var removeBtn = E('button', {
					'class': 'ghost ghost-compact is-danger',
					'type': 'button',
					'disabled': isBusy ? true : null,
					'style': 'color: var(--color-bad, #e05252);',
					'click': function(ev) {
						ev.preventDefault();
						if (self._spec && self._spec.onAction) {
							self._spec.onAction('protocolsRemove', item.id, item.confirmRemove);
						}
					}
				}, [ _('Удалить') ]);
				actions.push(removeBtn);
			}

			var noticeEl = null;
			if (item.id === 'awg' && isInstalled) {
				if (item.updateAvailable) {
					noticeEl = E('div', {
						'style': 'margin: 0 0 10px 0; padding: 6px 10px; background: rgba(245, 158, 11, 0.12); border: 1px solid rgba(245, 158, 11, 0.35); border-radius: 6px; font-size: 12px; line-height: 1.4; color: #b45309;'
					}, [
						E('strong', {}, [ '⚡ ' + _('Доступно обновление: ') ]),
						E('span', {}, [ _('В системе AWG 1.0. Доступна версия AWG 2.0+ (Slava-Shchipunov/awg-openwrt) с поддержкой новых параметров обфускации.') ])
					]);
				} else if (item.status && (item.status.indexOf('2.0') !== -1 || item.status.indexOf('3.1') !== -1)) {
					var rawVerText = item.rawVersion ? (' (' + item.rawVersion + ')') : '';
					noticeEl = E('div', {
						'style': 'margin: 0 0 10px 0; padding: 6px 10px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 6px; font-size: 12px; line-height: 1.4; color: #047857;'
					}, [
						E('strong', {}, [ '✓ ' + _('Актуальная версия: ') ]),
						E('span', {}, [ _('Установлена сборка AmneziaWG 2.0+ с расширенными параметрами (advanced-security, bogus_endpoints).') + rawVerText ])
					]);
				}
			}

			var fieldsChildren = [
				E('p', { 'class': 'muted', 'style': 'margin: 0 0 14px 0; font-size: 13px; line-height: 1.4;' }, [ item.descr ])
			];
			if (noticeEl) fieldsChildren.push(noticeEl);
			fieldsChildren.push(E('div', { 'style': 'display: flex; gap: 8px; align-items: center;' }, actions));

			return E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 0;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title' }, [
						E('strong', {}, [ item.title ])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status ' + statusClass }, [ item.status ])
					])
				]),
				E('div', { 'class': 'xfree-vpn-fields-wrap', 'style': 'padding: 14px;' }, fieldsChildren)
			]);
		});

		return E('section', { 'class': 'xfree-vpn-section' }, [
			E('h4', {}, [ _('Компоненты и протоколы') ]),
			E('div', { 'class': 'xfree-vpn-gens', 'style': 'grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); display: grid; gap: 14px;' }, cards)
		]);
	}

	_renderServerSection(awg, view) {
		var self = this;
		var s = this._spec || {};
		var peers = awg.peers || [];

		// Card 1: Server Identity & Settings
		var pubkeyShow = awg.pubkey || '—';
		var epShow = awg.defaultEndpoint || '—';
		var obfsShow = awg.obfuscation || '—';

		var serverParamsRows = [
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [ _('Публичный ключ') ]),
				E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px; font-family:monospace;' }, [
					E('span', { 'title': pubkeyShow }, [ pubkeyShow.length > 28 ? pubkeyShow.slice(0, 14) + '…' + pubkeyShow.slice(-10) : pubkeyShow ]),
					pubkeyShow !== '—' ? E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'style': 'padding: 2px 6px; font-size: 11px;',
						'title': _('Скопировать публичный ключ'),
						'click': function(ev) { copyToClipboard(pubkeyShow, ev.target); }
					}, [ _('Копировать') ]) : ''
				])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [ _('Default endpoint') ]),
				E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
					E('strong', {}, [ epShow ]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'style': 'padding: 2px 6px; font-size: 11px;',
						'title': _('Изменить endpoint сервера'),
						'click': function() { self._openChangeEndpointDialog(awg); }
					}, [ _('Изменить') ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [ _('Обфускация') ]),
				E('span', { 'style': 'font-family:monospace; font-size: 11px; color: var(--accent);' }, [ obfsShow ])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [ _('Firewall') ]),
				E('span', {}, [ _('Входящий UDP %s разрешён (WAN → Router)').format(awg.port || '51820') ])
			])
		];

		var serverActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				E('button', {
					'class': 'btn is-primary ghost-compact',
					'type': 'button',
					'title': _('Применить параметры сервера и обновить список пиров'),
					'click': ui.createHandlerFn(view, function(ev) {
						self._act(ev, 'serverApply', '', {
							title: _('Применение настроек сервера'),
							message: _('Перезапустить VPN-сервер и применить конфигурацию интерфейса?'),
							detail: _('Сетевой интерфейс awg_ingress будет перезапущен с актуальными ключами, портами и списком клиентов. Существующие соединения кратковременно переподключатся.'),
							confirmText: _('Применить'),
							tone: 'primary',
							icon: '⚡'
						});
					})
				}, [ '⚡ ' + _('Применить сервер') ]),
				xui.helpBtn({
					title: _('Применить сервер'),
					desc: _('Применяет текущую конфигурацию интерфейса awg_ingress и синхронизирует пиров.'),
					whatDoes: _('Вызывает скрипт apply-peers.sh, обновляет список доверенных публичных ключей клиентов в ядре и перезапускает интерфейс.'),
					tips: _('Используйте после добавления новых клиентов, изменения обфускации или смены Default Endpoint.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'title': _('Проверить и настроить правила Firewall для входящего VPN'),
					'click': ui.createHandlerFn(view, function(ev) {
						self._act(ev, 'serverConfigureFirewall', '', {
							title: _('Настройка Firewall'),
							message: _('Настроить правила межсетевого экрана для VPN-сервера?'),
							detail: _('Будет открыт входящий UDP-порт %s на интерфейсе WAN и разрешён форвардинг трафика между зоной awg_ingress и вашей локальной сетью LAN.').format(awg.port || '51820'),
							confirmText: _('Настроить Firewall'),
							tone: 'primary',
							icon: '🛡️'
						});
					})
				}, [ '🛡️ ' + _('Настроить Firewall') ]),
				xui.helpBtn({
					title: _('Настройка Firewall'),
					desc: _('Настраивает правила межсетевого экрана (nftables / firewall4) для безопасного приёма подключений клиентов.'),
					whatDoes: _('Создаёт правило разрешения входящего UDP-порта сервера в зоне WAN и настраивает forwarding между зонами awg_ingress и LAN.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'title': _('Выполнить первоначальную настройку сервера'),
					'click': ui.createHandlerFn(view, function(ev) {
						self._act(ev, 'serverSetup', '', {
							title: _('Первоначальная настройка'),
							message: _('Выполнить первичный Setup входящего VPN-сервера?'),
							detail: _('Скрипт создаст недостающие рабочие каталоги, сгенерирует ключи (если отсутствуют) и подготовит базовые конфигурационные файлы.'),
							confirmText: _('Запустить Setup'),
							tone: 'primary',
							icon: '⚙️'
						});
					})
				}, [ '⚙️ ' + _('Setup сервера') ]),
				xui.helpBtn({
					title: _('Setup сервера'),
					desc: _('Сценарий первичной инициализации сервера AmneziaWG на роутере.'),
					whatDoes: _('Генерирует файлы /etc/xfree-toolbox/awg-ingress/state/server.key, public.key и настраивает начальное окружение.'),
					tips: _('Полезно при первичной установке или после полного сброса настроек роутера.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group is-danger', 'style': 'margin-left: auto;' }, [
				E('button', {
					'class': 'btn ghost-compact is-bad',
					'type': 'button',
					'style': 'color: var(--bad); border-color: color-mix(in srgb, var(--bad) 40%, var(--line));',
					'title': _('Пересоздать приватный и публичный ключи сервера (все клиенты перестанут работать)'),
					'click': ui.createHandlerFn(view, function(ev) {
						self._act(ev, 'serverRecreateKeys', '', {
							title: _('Пересоздание ключей сервера'),
							message: _('ВНИМАНИЕ! Пересоздать ключи сервера? Все клиенты потеряют доступ!'),
							detail: _('КРИТИЧЕСКАЯ ОПЕРАЦИЯ: Будет сгенерирована абсолютно новая пара ключей сервера. Все подключённые клиенты (%d шт.) перестанут подключаться. Вам потребуется пересоздать и заново импортировать .conf и QR-коды на каждом клиентском устройстве.').format(peers.length),
							confirmText: _('Да, пересоздать ключи'),
							tone: 'danger',
							icon: '⚠️'
						});
					})
				}, [ '⚠️ ' + _('Пересоздать ключи') ]),
				xui.helpBtn({
					title: _('Пересоздание ключей сервера'),
					desc: _('Генерация новой ключевой пары сервера AmneziaWG.'),
					whatDoes: _('Перезаписывает приватный и публичный ключ сервера в /etc/xfree-toolbox/awg-ingress/state/.'),
					tips: _('Используйте эту операцию ТОЛЬКО при компрометации старых ключей сервера. Все выданные ранее клиентам настройки станут недействительными!')
				})
			])
		]);

		var serverCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('strong', {}, [ _('AmneziaWG Server (Ingress)') ]),
					xui.helpBtn({
						title: _('Входящий VPN-сервер AmneziaWG'),
						desc: _('Входящий VPN-сервер на базе протокола AmneziaWG (WireGuard с обфускацией пакетов Junk/Init/Response). Позволяет вашим смартфонам, ноутбукам и другим устройствам безопасно подключаться к домашней сети роутера из любой точки мира.'),
						whatDoes: _('Принимает зашифрованный входящий туннельный трафик на порту %s/UDP и направляет его в домашнюю сеть LAN или в интернет через настроенные аплинки.').format(awg.port || '51820'),
						tips: _('Для подключения мобильных устройств используйте приложение AmneziaWG. QR-коды для мгновенной настройки доступны в карточках клиентов ниже.')
					}),
					E('span', { 'class': 'muted' }, [ (awg.iface || 'awg_ingress') + ' · ' + (awg.addr || '10.200.200.1/24') ])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, [
					E('span', { 'class': 'xfree-vpn-status is-' + (awg.running ? 'ok' : 'bad') }, [
						awg.running ? _('СЕРВЕР АКТИВЕН') : _('ОСТАНОВЛЕН')
					]),
					awg.version ? E('span', { 'class': 'xfree-vpn-status is-muted' }, [ awg.version ]) : ''
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, serverParamsRows),
			serverActions
		]);

		// Card 1.5: NAT / External IP Accessibility Diagnostic
		var natRes = self._natCheckResult;
		var wanIpDisplay = (natRes && natRes.wanIp4) || awg.wanIp || '';
		if (!wanIpDisplay && awg.endpointChoices && Array.isArray(awg.endpointChoices)) {
			for (var eci = 0; eci < awg.endpointChoices.length; eci++) {
				if (awg.endpointChoices[eci].id === 'net:wan') {
					wanIpDisplay = (awg.endpointChoices[eci].endpoint || '').split(':')[0];
					break;
				}
			}
		}
		if (!wanIpDisplay)
			wanIpDisplay = '—';

		var extIp4Display = (natRes && natRes.extIp4) || (self._natChecking ? _('проверка...') : _('не проверен'));
		var extIp6Display = (natRes && natRes.extIp6) || (self._natChecking ? _('проверка...') : (natRes ? _('нет IPv6') : _('не проверен')));

		var preliminaryStatus = 'muted';
		var preliminaryBadge = _('НЕ ПРОВЕРЕНО');
		if (wanIpDisplay && wanIpDisplay !== '—') {
			if (/^100\.(6[4-9]|[7-9][0-9]|1[0-1][0-9]|12[0-7])\./.test(wanIpDisplay)) {
				preliminaryStatus = 'warn';
				preliminaryBadge = _('CGNAT (СЕРЫЙ IP)');
			} else if (/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/.test(wanIpDisplay)) {
				preliminaryStatus = 'warn';
				preliminaryBadge = _('ДОМАШНИЙ NAT');
			} else {
				preliminaryStatus = 'ok';
				preliminaryBadge = _('БЕЛЫЙ IP (ПРЕДВАРИТЕЛЬНО)');
			}
		}

		var natBadgeClass;
		var natBadgeText;
		if (natRes) {
			if (natRes.natType === 'public') {
				natBadgeClass = 'is-ok';
				natBadgeText = _('БЕЛЫЙ ПУБЛИЧНЫЙ IP');
			} else if (natRes.natType === 'cgnat') {
				natBadgeClass = 'is-bad';
				natBadgeText = _('CGNAT (СЕРЫЙ IP)');
			} else if (natRes.natType === 'local_nat') {
				natBadgeClass = 'is-warn';
				natBadgeText = _('ДОМАШНИЙ NAT (МОДЕМ)');
			} else if (natRes.statusCode === 'danger') {
				natBadgeClass = 'is-bad';
				natBadgeText = _('ОШИБКА ПРОВЕРКИ');
			} else {
				natBadgeClass = 'is-warn';
				natBadgeText = _('ПРОВАЙДЕРСКИЙ NAT');
			}
		} else {
			natBadgeClass = 'is-' + preliminaryStatus;
			natBadgeText = preliminaryBadge;
		}

		var natAdvice = '';
		if (natRes && natRes.message) {
			natAdvice = natRes.message;
		} else if (preliminaryBadge === _('CGNAT (СЕРЫЙ IP)')) {
			natAdvice = _('Адрес WAN находится в диапазоне CGNAT (100.64.0.0/10). Провайдер блокирует прямые входящие подключения из интернета. Нажмите «Как обойти NAT» для настройки FreeTurn или реле.');
		} else if (preliminaryBadge === _('ДОМАШНИЙ NAT')) {
			natAdvice = _('Роутер подключён через терминал/модем провайдера (192.168.x.x / 10.x.x.x). Настройте на терминале режим Bridge, DMZ или проброс порта 51820 UDP на этот роутер.');
		} else if (preliminaryBadge === _('БЕЛЫЙ IP (ПРЕДВАРИТЕЛЬНО)')) {
			natAdvice = _('WAN IP роутера похож на публичный (%s). Нажмите «Проверить доступность извне», чтобы подтвердить отсутствие скрытого NAT и доступность порта.').format(wanIpDisplay);
		} else {
			natAdvice = _('Нажмите «Проверить доступность извне», чтобы сопоставить WAN IP с реальным адресом выхода в интернет и проверить наличие IPv6.');
		}

		var natCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('strong', {}, [ _('Доступность из интернета (NAT / Внешний IP)') ]),
					xui.helpBtn({
						title: _('Диагностика доступа из интернета'),
						desc: _('Определяет, доступен ли ваш сервер AmneziaWG и FreeTurn для входящих подключений клиентов из глобальной сети.'),
						whatDoes: _('Сопоставляет локальный WAN IPv4 с публичным адресом в интернете, определяет наличие провайдерского CGNAT (RFC 6598) и проверяет поддержку IPv6.'),
						tips: _('Если у вас серый IP (CGNAT), нажмите кнопку «Как обойти NAT» для просмотра доступных решений (VPS релеи, Tailscale, IPv6).')
					}),
					wanIpDisplay !== '—' ? E('span', { 'class': 'muted' }, [ _('WAN: %s').format(wanIpDisplay) ]) : ''
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, [
					E('span', { 'class': 'xfree-vpn-status ' + natBadgeClass }, [ natBadgeText ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 8px; padding: 10px 0;' }, [
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [ _('WAN IPv4 (роутер)') ]),
					E('strong', { 'style': 'font-family: monospace; font-size: 13px;' }, [ wanIpDisplay ])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [ _('Внешний IPv4 (интернет)') ]),
					E('span', { 'style': 'font-family: monospace; font-size: 13px; font-weight: 600;' }, [ extIp4Display ])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [ _('Внешний IPv6') ]),
					E('span', { 'style': 'font-family: monospace; font-size: 12px; font-weight: 600;' }, [ extIp6Display ])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: flex-start; margin-top: 4px;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap; padding-top: 6px;' }, [ _('Рекомендация') ]),
					E('div', {
						'class': 'muted',
						'style': 'font-size: 12px; line-height: 1.45; padding: 8px 12px; border-radius: 6px; background: color-mix(in srgb, var(--card) 60%, var(--bg)); border-left: 3px solid ' + (natBadgeClass.indexOf('is-bad') !== -1 ? 'var(--bad)' : (natBadgeClass.indexOf('is-warn') !== -1 ? 'var(--warn)' : 'var(--primary)')) + ';'
					}, [ natAdvice ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-server-actions', 'style': 'display: flex; gap: 8px; flex-wrap: wrap; align-items: center;' }, [
				E('button', {
					'class': 'btn is-primary ghost-compact',
					'type': 'button',
					'disabled': self._natChecking ? true : null,
					'click': function(ev) {
						self._natChecking = true;
						self.requestPaint();
						xui.runAwgMenu('checkNat').then(function(res) {
							self._natChecking = false;
							self._natCheckResult = xui.parseNatCheck(res);
							self.requestPaint();
						}).catch(function(err) {
							self._natChecking = false;
							self._natCheckResult = {
								statusCode: 'danger',
								message: _('Ошибка проверки: ') + ((err && err.message) || String(err))
							};
							self.requestPaint();
						});
					}
				}, [ self._natChecking ? _('Проверка...') : ('🔍 ' + _('Проверить доступность извне')) ]),
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function() { self._openNatHelpDialog(); }
				}, [ 'ℹ️ ' + _('Как обойти NAT') ])
			])
		]);

		// Card 2: FreeTurn Proxy (Next-gen transport)
		var freeTurnPortShow = awg.freeTurnPort || '56000';
		var freeTurnCard;

		if (!awg.freeTurnInstalled) {
			freeTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [ _('FreeTurn Proxy (Транспорт)') ]),
						xui.helpBtn({
							title: _('FreeTurn Proxy'),
							desc: _('Современный UDP-транспорт нового поколения (протокол v4), маскирующий туннельный трафик AmneziaWG под RTP/Opus медиа-звонки с профилем rtpopus3 и 64-символьным ключом шифрования.'),
							whatDoes: _('Позволяет обходить блокировки WireGuard/AWG операторами связи (включая жесткие белые списки мобильных операторов). Принимает трафик на порту 56000/UDP и пересылает на локальный порт 51820 awg_ingress.'),
							tips: _('Устанавливается нажатием одной кнопки. При установке автоматически скачивается бинарник под процессор вашего роутера, создаётся ключ обфускации, настраивается Firewall и безопасно отключается старый vk-turn.')
						}),
						E('span', { 'class': 'muted' }, [ _('UDP 56000') ])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('НЕ УСТАНОВЛЕН') ])
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 12px 0;' }, [
					E('p', { 'style': 'margin: 0; font-size: 13px;' }, [
						_('FreeTurn — современный преемник VK-Turn с протоколом v4 и обфускацией rtpopus3 под голосовой трафик.')
					]),
					E('div', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
						_('На роутере пока не установлен. Нажмите кнопку ниже для автоматической загрузки бинарника с GitHub и первоначальной настройки.')
					])
				]),
				E('div', { 'class': 'xfree-vpn-server-actions' }, [
					E('div', { 'class': 'xfree-vpn-actions-group' }, [
						E('button', {
							'class': 'btn is-primary ghost-compact',
							'type': 'button',
							'title': _('Установить и запустить FreeTurn прокси «под ключ»'),
							'click': function(ev) {
								self._act(ev, 'freeTurnSetup', '', {
									title: _('Установка FreeTurn прокси'),
									message: _('Установить и запустить FreeTurn прокси на порту %s?').format(freeTurnPortShow),
									detail: _('Будет скачан бинарник free-turn-proxy с GitHub под процессор роутера, сгенерирован 64-hex ключ obf.key, создан procd сервис /etc/init.d/free-turn, настроен Firewall и корректно отключён устаревший vk-turn.'),
									confirmText: _('Установить'),
									tone: 'primary',
									icon: '📥'
								});
							}
						}, [ '📥 ' + _('Установить FreeTurn') ])
					])
				])
			]);
		} else {
			var freeTurnParamsRows = [
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('входящий порт') ]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:8px;' }, [
						E('strong', {}, [ '0.0.0.0:' + freeTurnPortShow + ' (UDP)' ]),
						'WAN ➔ Router',
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'padding: 2px 8px; font-size: 11px;',
							'title': _('Изменить внешний порт FreeTurn'),
							'click': function(ev) {
								ev.preventDefault();
								self._openFreeTurnConfigDialog(awg);
							}
						}, [ '✏️ ' + _('Изменить') ])
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('целевой порт (AWG)') ]),
					E('span', {}, [
						E('strong', {}, [ '127.0.0.1:' + (awg.port || '51820') ]),
						' (' + (awg.iface || 'awg_ingress') + ')'
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('обфускация') ]),
					E('span', {}, [
						E('strong', {}, [ awg.freeTurnObfProfile || 'rtpopus3' ]),
						' ' + _('(маскировка под голосовой трафик)')
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('ключ обфускации') ]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px; font-family:monospace;' }, [
						E('span', { 'title': awg.freeTurnObfKey || '' }, [
							awg.freeTurnObfKey ? (awg.freeTurnObfKey.slice(0, 14) + '…' + awg.freeTurnObfKey.slice(-10)) : '—'
						]),
						awg.freeTurnObfKey ? E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'padding: 2px 6px; font-size: 11px;',
							'title': _('Скопировать ключ обфускации'),
							'click': function(ev) { copyToClipboard(awg.freeTurnObfKey, ev.target); }
						}, [ _('Копировать') ]) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('статус сервиса') ]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
						E('span', { 'class': 'xfree-vpn-badge is-' + (awg.freeTurnRunning ? 'ok' : 'bad') }, [
							awg.freeTurnRunning ? _('работает') : _('остановлен')
						]),
						E('span', {}, [
							awg.freeTurnRunning
								? _('Служба /etc/init.d/free-turn работает (PID активен)')
								: _('Служба /etc/init.d/free-turn остановлена')
						])
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('firewall') ]),
					E('span', {}, [
						awg.freeTurnRunning
							? _('Входящий UDP %s разрешён (WAN ➔ Router)').format(freeTurnPortShow)
							: _('Входящий UDP %s (настроен в Firewall)').format(freeTurnPortShow)
					])
				])
			];

			var freeTurnActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
				E('div', { 'class': 'xfree-vpn-actions-group' }, [
					awg.freeTurnRunning ? E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Перезапустить службу FreeTurn'),
						'click': function(ev) {
							self._act(ev, 'freeTurnRestart', '', {
								title: _('Перезапуск FreeTurn'),
								message: _('Перезапустить службу FreeTurn прокси?'),
								detail: _('Служба /etc/init.d/free-turn будет перезапущена с текущими параметрами.'),
								confirmText: _('Перезапустить'),
								tone: 'primary',
								icon: '🔄'
							});
						}
					}, [ '🔄 ' + _('Перезапустить') ]) : E('button', {
						'class': 'btn is-primary ghost-compact',
						'type': 'button',
						'title': _('Запустить службу FreeTurn'),
						'click': function(ev) {
							self._act(ev, 'freeTurnRestart', '', {
								title: _('Запуск FreeTurn'),
								message: _('Запустить службу FreeTurn прокси на порту %s?').format(freeTurnPortShow),
								detail: _('Служба /etc/init.d/free-turn будет запущена.'),
								confirmText: _('Запустить'),
								tone: 'primary',
								icon: '▶️'
							});
						}
					}, [ '▶️ ' + _('Запустить') ]),

					awg.freeTurnRunning ? E('button', {
						'class': 'btn ghost-compact is-stop',
						'type': 'button',
						'title': _('Остановить службу FreeTurn прокси'),
						'click': function(ev) {
							self._act(ev, 'freeTurnStop', '', {
								title: _('Остановка FreeTurn'),
								message: _('Остановить службу FreeTurn прокси?'),
								detail: _('Служба /etc/init.d/free-turn будет остановлена, порт %s освобождён. Клиенты через FreeTurn временно потеряют связь.').format(freeTurnPortShow),
								confirmText: _('Остановить'),
								tone: 'danger',
								icon: '⏹️'
							});
						}
					}, [ '⏹️ ' + _('Остановить') ]) : '',

					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Настроить внешний порт и параметры службы FreeTurn'),
						'click': function(ev) {
							ev.preventDefault();
							self._openFreeTurnConfigDialog(awg);
						}
					}, [ '⚙️ ' + _('Настроить сервер') ]),

					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Проверить и обновить бинарник FreeTurn'),
						'click': function(ev) {
							self._act(ev, 'freeTurnUpdate', '', {
								title: _('Обновление FreeTurn'),
								message: _('Обновить бинарник FreeTurn до последней версии?'),
								detail: _('Будет проверен и скачан свежий бинарник free-turn-proxy с GitHub.'),
								confirmText: _('Обновить'),
								tone: 'primary',
								icon: '⬆️'
							});
						}
					}, [ '⬆️ ' + _('Обновить') ])
				]),
				E('div', { 'class': 'xfree-vpn-actions-group is-danger' }, [
					E('button', {
						'class': 'btn ghost-compact is-bad',
						'type': 'button',
						'title': _('Полностью удалить FreeTurn с роутера (служба, бинарник, firewall)'),
						'click': function(ev) {
							self._act(ev, 'freeTurnUninstall', '', {
								title: _('Удаление FreeTurn'),
								message: _('Полностью удалить FreeTurn прокси с роутера?'),
								detail: _('Служба /etc/init.d/free-turn будет остановлена и удалена, бинарник /opt/free-turn-proxy и ключ удалены, порт %s закрыт в Firewall.').format(freeTurnPortShow),
								confirmText: _('Да, удалить FreeTurn'),
								tone: 'danger',
								icon: '🗑️'
							});
						}
					}, [ '🗑️ ' + _('Удалить FreeTurn') ])
				])
			]);

			freeTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [ _('FreeTurn Proxy (Транспорт)') ]),
						xui.helpBtn({
							title: _('FreeTurn Proxy'),
							desc: _('Современный UDP-транспорт нового поколения (протокол v4), маскирующий туннельный трафик AmneziaWG под RTP/Opus медиа-звонки с профилем rtpopus3 и 64-символьным ключом шифрования.'),
							whatDoes: _('Позволяет обходить блокировки WireGuard/AWG операторами связи (включая жесткие белые списки мобильных операторов). Принимает трафик на порту %s/UDP и пересылает на локальный порт 51820 awg_ingress.').format(freeTurnPortShow),
							tips: _('Для подключения используйте клиент FreeTurn на телефоне (turn-proxy-android) или роутере.')
						}),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'style': 'padding: 1px 6px; font-size: 11px; margin-left: 2px;',
							'title': _('Изменить внешний порт FreeTurn'),
							'click': function(ev) {
								ev.preventDefault();
								self._openFreeTurnConfigDialog(awg);
							}
						}, [ 'UDP ' + freeTurnPortShow + ' ✏️' ]),
						E('span', { 'class': 'muted' }, [ '➔ 127.0.0.1:' + (awg.port || '51820') ])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status is-' + (awg.freeTurnRunning ? 'ok' : 'bad') }, [
							awg.freeTurnRunning ? _('ПРОКСИ АКТИВЕН') : _('ОСТАНОВЛЕН')
						]),
						awg.freeTurnVersion ? E('span', { 'class': 'xfree-vpn-status is-muted' }, [ awg.freeTurnVersion ]) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, freeTurnParamsRows),
				freeTurnActions
			]);
		}

		// Card 3: VK-Turn Proxy Card (Legacy transport)
		var vkTurnPortShow = awg.vkPort || '49151';
		var vkTurnCard;

		if (!awg.vkInstalled) {
			vkTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [ _('VK-Turn Proxy (Легаси транспорт)') ]),
						xui.helpBtn({
							title: _('VK-Turn Proxy'),
							desc: _('Устаревший UDP-прокси первого поколения для обхода блокировок WireGuard через маскировку под медиа-звонки VK (порт 49151).'),
							tips: _('Рекомендуется использовать FreeTurn вместо VK-Turn. Если вы хотите установить VK-Turn, нажмите кнопку ниже.')
						}),
						E('span', { 'class': 'muted' }, [ _('UDP 49151') ])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('НЕ УСТАНОВЛЕН') ])
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 12px 0;' }, [
					E('p', { 'style': 'margin: 0; font-size: 13px;' }, [
						_('VK-Turn — транспорт первого поколения на порту 49151.')
					]),
					E('div', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
						_('На роутере не установлен. Вы можете установить его вручную или использовать более современный FreeTurn.')
					])
				]),
				E('div', { 'class': 'xfree-vpn-server-actions' }, [
					E('div', { 'class': 'xfree-vpn-actions-group' }, [
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'title': _('Установить и настроить VK-Turn прокси'),
							'click': function(ev) {
								self._act(ev, 'vkTurnSetup', '', {
									title: _('Установка VK-Turn прокси'),
									message: _('Установить и запустить VK-Turn прокси на порту %s?').format(vkTurnPortShow),
									detail: _('Будет проверен бинарник vk-turn-proxy, создан init-сервис и открыт порт 49151 в Firewall.'),
									confirmText: _('Установить'),
									tone: 'primary',
									icon: '📥'
								});
							}
						}, [ '📥 ' + _('Установить VK-Turn') ])
					])
				])
			]);
		} else {
			var vkTurnParamsRows = [
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('входящий порт') ]),
					E('span', {}, [
						E('strong', {}, [ '0.0.0.0:' + vkTurnPortShow + ' (UDP)' ]),
						' WAN ➔ Router'
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('целевой порт (AWG)') ]),
					E('span', {}, [
						E('strong', {}, [ '127.0.0.1:' + (awg.port || '51820') ]),
						' (' + (awg.iface || 'awg_ingress') + ')'
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('статус сервиса') ]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
						E('span', { 'class': 'xfree-vpn-badge is-' + (awg.vkRunning ? 'ok' : 'muted') }, [
							awg.vkRunning ? _('работает') : _('не запущен')
						]),
						E('span', {}, [
							awg.vkRunning
								? _('Служба /etc/init.d/vk-turn работает (PID активен)')
								: _('Служба /etc/init.d/vk-turn остановлена')
						])
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [ _('firewall') ]),
					E('span', {}, [
						awg.vkRunning
							? _('Входящий UDP %s разрешён (WAN ➔ Router)').format(vkTurnPortShow)
							: _('Правило firewall создаётся автоматически при настройке сервера')
					])
				])
			];

			var vkTurnActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
				E('div', { 'class': 'xfree-vpn-actions-group' }, [
					awg.vkRunning ? E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Перезапустить службу VK-Turn'),
						'click': function(ev) {
							self._act(ev, 'vkTurnRestart', '', {
								title: _('Перезапуск VK-Turn'),
								message: _('Перезапустить службу VK-Turn прокси?'),
								detail: _('Служба /etc/init.d/vk-turn будет перезапущена с текущими параметрами.'),
								confirmText: _('Перезапустить'),
								tone: 'primary',
								icon: '🔄'
							});
						}
					}, [ '🔄 ' + _('Перезапустить') ]) : E('button', {
						'class': 'btn is-primary ghost-compact',
						'type': 'button',
						'title': _('Запустить службу VK-Turn'),
						'click': function(ev) {
							self._act(ev, 'vkTurnRestart', '', {
								title: _('Запуск VK-Turn'),
								message: _('Запустить службу VK-Turn прокси на порту %s?').format(vkTurnPortShow),
								detail: _('Служба /etc/init.d/vk-turn будет запущена.'),
								confirmText: _('Запустить'),
								tone: 'primary',
								icon: '▶️'
							});
						}
					}, [ '▶️ ' + _('Запустить') ]),

					awg.vkRunning ? E('button', {
						'class': 'btn ghost-compact is-stop',
						'type': 'button',
						'title': _('Остановить службу VK-Turn прокси'),
						'click': function(ev) {
							self._act(ev, 'vkTurnStop', '', {
								title: _('Остановка VK-Turn'),
								message: _('Остановить службу VK-Turn прокси?'),
								detail: _('Служба /etc/init.d/vk-turn будет остановлена, порт %s освобождён.').format(vkTurnPortShow),
								confirmText: _('Остановить'),
								tone: 'danger',
								icon: '⏹️'
							});
						}
					}, [ '⏹️ ' + _('Остановить') ]) : '',

					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Установить и настроить VK-Turn прокси'),
						'click': function(ev) {
							self._act(ev, 'vkTurnSetup', '', {
								title: _('Настройка VK-Turn прокси'),
								message: _('Настроить и запустить VK-Turn прокси на порту %s?').format(vkTurnPortShow),
								detail: _('VK-Turn маскирует трафик AmneziaWG под медиа-звонки VK. Будет проверен бинарник, создан init-сервис и открыт порт в Firewall.'),
								confirmText: _('Настроить сервер'),
								tone: 'primary',
								icon: '⚙️'
							});
						}
					}, [ '⚙️ ' + _('Настроить сервер') ]),

					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Проверить и обновить бинарник VK-Turn'),
						'click': function(ev) {
							self._act(ev, 'vkTurnUpdate', '', {
								title: _('Обновление VK-Turn'),
								message: _('Обновить бинарник VK-Turn?'),
								detail: _('Будет проверен и скачан бинарник vk-turn-proxy.'),
								confirmText: _('Обновить'),
								tone: 'primary',
								icon: '⬆️'
							});
						}
					}, [ '⬆️ ' + _('Обновить') ])
				]),
				E('div', { 'class': 'xfree-vpn-actions-group is-danger' }, [
					E('button', {
						'class': 'btn ghost-compact is-bad',
						'type': 'button',
						'title': _('Полностью удалить VK-Turn с роутера (служба, бинарник, firewall)'),
						'click': function(ev) {
							self._act(ev, 'vkTurnUninstall', '', {
								title: _('Удаление VK-Turn'),
								message: _('Полностью удалить VK-Turn прокси с роутера?'),
								detail: _('Служба /etc/init.d/vk-turn будет остановлена и удалена, бинарник /opt/vk-turn-proxy удалён, порт %s закрыт в Firewall.').format(vkTurnPortShow),
								confirmText: _('Да, удалить VK-Turn'),
								tone: 'danger',
								icon: '🗑️'
							});
						}
					}, [ '🗑️ ' + _('Удалить VK-Turn') ])
				])
			]);

			vkTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [ _('VK-Turn Proxy (Транспорт)') ]),
						xui.helpBtn({
							title: _('VK-Turn Proxy (Легаси)'),
							desc: _('Транспортный UDP-прокси первого поколения, маскирующий трафик AmneziaWG под медиа-звонки VK на порту 49151.')
						}),
						E('span', { 'class': 'muted' }, [ 'UDP ' + vkTurnPortShow + ' ➔ 127.0.0.1:' + (awg.port || '51820') ])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status is-' + (awg.vkRunning ? 'ok' : 'bad') }, [
							awg.vkRunning ? _('ПРОКСИ АКТИВЕН') : _('НЕ АКТИВЕН')
						]),
						awg.vkVersion ? E('span', { 'class': 'xfree-vpn-status is-muted' }, [ awg.vkVersion ]) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, vkTurnParamsRows),
				vkTurnActions
			]);
		}

		// Card 4: Peers List
		var peerCards = [];
		for (var i = 0; i < peers.length; i++) {
			(function(peer) {
				var diff = peer.latestHandshake > 0 ? (Math.floor(Date.now() / 1000) - peer.latestHandshake) : -1;
				var tone = diff >= 0 ? (diff < 180 ? 'ok' : (diff < 86400 ? 'warn' : 'muted')) : 'muted';
				var hsLabel = formatHandshake(peer.latestHandshake);
				var rxLabel = formatBytes(peer.rxBytes);
				var txLabel = formatBytes(peer.txBytes);

				var card = E('div', { 'class': 'xfree-vpn-tunnel is-' + tone }, [
					E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
						E('div', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
							E('span', { 'style': 'font-size:16px;' }, [ '👤' ]),
							E('strong', {}, [ peer.name || peer.slug ])
						]),
						E('span', { 'class': 'xfree-vpn-status is-' + tone, 'title': peer.latestHandshake ? new Date(peer.latestHandshake * 1000).toLocaleString() : '' }, [ hsLabel ])
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-sub' }, [
						E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size:11px;' }, [ peer.ip || '—' ]),
						peer.endpoint ? E('span', { 'class': 'muted', 'style': 'margin-left:6px; font-size:11px;' }, [ peer.endpoint ]) : ''
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-meta' }, [
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [ _('трафик') ]),
							E('span', {}, [ rxLabel + ' ↓ / ' + txLabel + ' ↑' ])
						]),
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [ _('keepalive') ]),
							E('span', {}, [ (peer.keepalive || 25) + ' ' + _('сек') ])
						]),
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [ _('ключ') ]),
							E('span', { 'style': 'font-family:monospace; font-size:11px;' }, [
								peer.pubkey ? (peer.pubkey.slice(0, 10) + '…' + peer.pubkey.slice(-6)) : '—'
							])
						])
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-actions' }, [
						E('button', {
							'class': 'btn ghost-compact is-primary',
							'type': 'button',
							'title': _('Показать QR-код для подключения WireGuard/AmneziaWG'),
							'click': function() { self._openPeerConfigDialog(peer, 'qr'); }
						}, [ '📱 ' + _('QR-код') ]),
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'title': _('Просмотр и скачивание файла .conf'),
							'click': function() { self._openPeerConfigDialog(peer, 'conf'); }
						}, [ '📄 ' + _('.conf') ]),
						awg.freeTurnInstalled ? E('button', {
							'class': 'btn ghost-compact is-primary',
							'type': 'button',
							'style': 'border-color: color-mix(in srgb, var(--primary) 70%, var(--line));',
							'title': _('Показать QR-код и ссылку freeturn:// для мобильного приложения'),
							'click': function(ev) {
								if (ev) ev.preventDefault();
								self._openPeerFreeTurnDialog(peer, awg);
							}
						}, [ '⚡ ' + _('FreeTurn') ]) : '',
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'title': _('Изменить endpoint для этого клиента'),
							'click': function() { self._openPeerEndpointDialog(peer, awg); }
						}, [ '✏️' ]),
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'title': _('Пересоздать ключи клиента'),
							'click': function(ev) {
								self._act(ev, 'peerRecreateKeys', peer.slug, {
									title: _('Пересоздание ключей клиента'),
									message: _('Пересоздать ключи для клиента «%s»?').format(peer.name),
									detail: _('Старый файл .conf и QR-код на устройстве клиента перестанут подключаться. Потребуется импортировать обновлённый файл настроек на устройство пользователя.'),
									confirmText: _('Пересоздать'),
									tone: 'warn',
									icon: '🔄'
								});
							}
						}, [ '🔄' ]),
						E('button', {
							'class': 'btn ghost-compact is-bad',
							'type': 'button',
							'style': 'color: var(--bad);',
							'title': _('Удалить клиента'),
							'click': function(ev) {
								self._act(ev, 'peerDelete', peer.slug, {
									title: _('Удаление VPN-клиента'),
									message: _('Удалить клиента «%s» (%s)?').format(peer.name, peer.ip),
									detail: _('Клиент будет безвозвратно удалён из базы и списка доверенных пиров сервера. Он больше не сможет подключаться.'),
									confirmText: _('Удалить'),
									tone: 'danger',
									icon: '🗑️'
								});
							}
						}, [ '🗑️' ])
					])
				]);
				peerCards.push(card);
			})(peers[i]);
		}

		peerCards.push(E('div', { 'class': 'xfree-vpn-tunnel is-new' }, [
			E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
				E('strong', {}, [ _('+ Добавить клиента') ]),
				E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('новый') ])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-sub muted' }, [
				_('Генерация ключей → выделение IP → готовый .conf и QR-код')
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions xfree-vpn-create-actions' }, [
				E('button', {
					'class': 'btn is-primary ghost-compact',
					'type': 'button',
					'click': function() { self._openAddPeerDialog(awg); }
				}, [ '➕ ' + _('Создать клиента') ])
			])
		]));

		var peersSection = E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'style': 'display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; flex-wrap:wrap; gap:8px;' }, [
				E('div', { 'style': 'display:flex; align-items:center; gap:8px;' }, [
					E('h4', { 'style': 'margin:0;' }, [
						_('Клиенты сервера (%d)').format(peers.length)
					]),
					xui.helpBtn({
						title: _('Клиенты сервера (Пиры)'),
						desc: _('Список удалённых устройств (клиентов), зарегистрированных на вашем VPN-сервере. Каждому клиенту выделяется собственный IP-адрес из подсети сервера и уникальная ключевая пара.'),
						whatDoes: _('Кнопка «QR-код» открывает код для быстрого добавления туннеля через камеру смартфона в приложении AmneziaWG. Кнопка «.conf» позволяет скачать готовый файл конфигурации.'),
						tips: _('Если роутер находится за провайдерским NAT или сменился DDNS-домен, вы можете изменить Endpoint подключения для каждого клиента по отдельности кнопкой ✏️.')
					})
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnels' }, peerCards)
		]);

		return E('div', { 'class': 'xfree-vpn-server-wrap' }, [
			serverCard,
			natCard,
			freeTurnCard,
			vkTurnCard,
			peersSection
		]);
	}

	_renderSelfRouteSection(ifaces, summary, view) {
		var self = this;
		var s = this._spec || {};
		var rows = [];
		var table;
		var i;
		var quickOps = [];
		var hotplugOk = !!(summary && summary.selfRouteHotplug);

		if (!ifaces || ifaces.length === 0)
			return null;

		for (i = 0; i < ifaces.length; i++) {
			(function(row) {
				var target = row.name;
				var currentVia = row.selfRouteVia || '';
				var selEl;
				var opts = [];
				var j;
				var other;
				var applyBtn;
				var resetBtn = null;

				opts.push(E('option', {
					'value': '',
					'selected': !currentVia ? true : null
				}, [ _('WAN (напрямую, без туннеля)') ]));

				for (j = 0; j < ifaces.length; j++) {
					other = ifaces[j];
					if (other.name === target)
						continue;
					opts.push(E('option', {
						'value': other.name,
						'selected': currentVia === other.name ? true : null
					}, [ '➔ ' + other.name + (other.kind ? ' (' + other.kind + ')' : '') ]));
				}

				selEl = E('select', {
					'class': 'xfree-uplink-input xfree-selfroute-select',
					'data-selfroute-target': target
				}, opts);

				applyBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': ui.createHandlerFn(view, function(ev) {
						var selectedVia = String(selEl.value || '').trim();
						if (!selectedVia) {
							if (currentVia) {
								self._act(ev, 'selfRouteRemove', target,
									_('Сбросить маршрут для «%s» (направить напрямую через WAN)?').format(target));
							} else {
								self.setMessage(_('Туннель «%s» уже направлен напрямую через WAN').format(target), 'ok');
							}
							return;
						}
						if (selectedVia === currentVia) {
							self.setMessage(
								_('Маршрут %s ➔ %s уже сохранён. Для обновления нажмите «Обновить маршруты».').format(target, currentVia),
								'ok'
							);
							return;
						}
						self._act(ev, 'selfRouteApply', target + '|' + selectedVia,
							_('Направить туннель «%s» через «%s» (%s ➔ %s)?').format(target, selectedVia, target, selectedVia));
					})
				}, [ _('Применить') ]);

				if (currentVia) {
					resetBtn = E('button', {
						'class': 'ghost ghost-compact',
						'type': 'button',
						'click': ui.createHandlerFn(view, function(ev) {
							self._act(ev, 'selfRouteRemove', target,
								_('Сбросить каскадный маршрут для «%s» (вернуть выход через WAN)?').format(target));
						})
					}, [ _('Сбросить') ]);
				}

				rows.push(E('tr', { 'class': 'xfree-selfroute-row' }, [
					E('td', { 'class': 'xfree-selfroute-cell-target' }, [
						E('div', { 'class': 'xfree-selfroute-target-box' }, [
							E('span', { 'class': 'xfree-vpn-status-dot is-' + (row.ifaceUp ? 'ok' : 'bad') }),
							E('strong', {}, [ target ]),
							row.kind ? E('span', { 'class': 'muted font-mono' }, [ ' (' + row.kind + ')' ]) : ''
						])
					]),
					E('td', { 'class': 'xfree-selfroute-cell-route' }, [
						currentVia
							? E('span', { 'class': 'xfree-selfroute-pill is-active' }, [
								target + ' ',
								E('span', { 'class': 'xfree-vpn-arrow' }, [ '➔' ]),
								' ' + currentVia
							])
							: E('span', { 'class': 'xfree-selfroute-pill is-wan' }, [
								target + ' ',
								E('span', { 'class': 'muted' }, [ '➔ WAN' ])
							])
					]),
					E('td', { 'class': 'xfree-selfroute-cell-via' }, [ selEl ]),
					E('td', { 'class': 'xfree-selfroute-cell-actions' }, [
						applyBtn,
						resetBtn ? ' ' : '',
						resetBtn ? resetBtn : ''
					])
				]));
			})(ifaces[i]);
		}

		table = E('table', { 'class': 'xfree-selfroute-table' }, [
			E('thead', {}, [
				E('tr', {}, [
					E('th', {}, [ _('Туннель') ]),
					E('th', {}, [ _('Текущий маршрут') ]),
					E('th', {}, [ _('Маршрут через (Via)') ]),
					E('th', {}, [ _('Действия') ])
				])
			]),
			E('tbody', {}, rows)
		]);

		quickOps = [
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Обновить runtime host-routes в ядре (пункт 5)'),
				'click': ui.createHandlerFn(view, function(ev) {
					self._act(ev, 'selfRouteRunHotplug', '',
						_('Обновить runtime host-routes для всех туннелей в ядре прямо сейчас?'));
				})
			}, [ '🔄 ' + _('Обновить маршруты') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Пересобрать hotplug hook /etc/hotplug.d/iface/95-xfree-toolbox-self-route (пункт 4)'),
				'click': ui.createHandlerFn(view, function(ev) {
					self._act(ev, 'selfRouteRebuildHotplug', '',
						_('Пересобрать hotplug hook для автоматического поднятия маршрутов?'));
				})
			}, [ '⚙️ ' + _('Пересобрать hotplug') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Полная пересборка и удаление сиротских маршрутов (пункт 6)'),
				'click': ui.createHandlerFn(view, function(ev) {
					self._act(ev, 'selfRouteCleanup', '',
						_('Выполнить полную пересборку и очистку сиротских маршрутов (cleanup)?'));
				})
			}, [ '🧹 ' + _('Очистить сироты (cleanup)') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Показать текущую конфигурацию self-route и статус hotplug (пункт 1)'),
				'click': ui.createHandlerFn(view, function(ev) {
					self._act(ev, 'selfRouteStatus', '');
				})
			}, [ '📋 ' + _('Подробный статус') ])
		];

		return E('section', { 'class': 'xfree-vpn-section xfree-selfroute-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '🔀 ' + _('Исходящие маршруты туннелей (Self-route)') ]),
					E('span', {
						'class': 'xfree-vpn-status is-' + (hotplugOk ? 'ok' : 'warn')
					}, [ hotplugOk ? 'hotplug: active' : 'hotplug: not set' ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Каскадная маршрутизация (туннель через туннель). Направляет endpoint целевого VPN через промежуточный туннель, скрывая реальный IP роутера от провайдера целевого VPN.')
				])
			]),
			ifaces.length < 2
				? E('p', { 'class': 'muted' }, [
					_('Для каскадной маршрутизации требуется хотя бы два созданных туннеля (например, warp и proton).')
				])
				: table,
			E('div', { 'class': 'xfree-selfroute-ops' }, quickOps)
		]);
	}

	_renderPbrBypassSection(ifaces, summary, view) {
		var self = this;
		var s = this._spec || {};
		var uciNets = summary.uciNetworks || [];

		if (!ifaces || ifaces.length === 0)
			return null;

		// 1. Build list of networks: start with UCI networks (lan, guest, etc.)
		var availableNets = (Array.isArray(uciNets) && uciNets.length)
			? uciNets.slice()
			: [ 'lan', 'guest' ];

		if (availableNets.indexOf('lan') === -1)
			availableNets.unshift('lan');
		if (availableNets.indexOf('guest') === -1)
			availableNets.push('guest');

		// Include any networks currently stored in any tunnel's pbrBypass
		ifaces.forEach(function(row) {
			var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
			cur.forEach(function(net) {
				if (availableNets.indexOf(net) === -1)
					availableNets.push(net);
			});
		});

		// 2. Initialize matrix if needed or if summary refreshed
		if (!self._pbrMatrix || self._pbrSummarySeq !== summary) {
			self._pbrMatrix = {};
			ifaces.forEach(function(row) {
				var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
				self._pbrMatrix[row.name] = cur;
			});
			self._pbrSavedSnapshot = JSON.stringify(self._pbrMatrix);
			self._pbrSummarySeq = summary;
		} else {
			// Ensure all current ifaces exist in self._pbrMatrix
			ifaces.forEach(function(row) {
				if (!Array.isArray(self._pbrMatrix[row.name])) {
					var cur = String(row.pbrBypass || '').trim().split(/\s+/).filter(Boolean);
					self._pbrMatrix[row.name] = cur;
				}
			});
		}

		var isDirty = JSON.stringify(self._pbrMatrix) !== self._pbrSavedSnapshot;

		var initialMap = {};
		try {
			initialMap = JSON.parse(self._pbrSavedSnapshot || '{}');
		} catch (e) {
			initialMap = {};
		}

		// 3. Header
		var headerCols = [
			E('th', { 'style': 'min-width: 170px;' }, [ _('Локальная сеть (Wi-Fi / LAN)') ])
		];

		ifaces.forEach(function(row) {
			headerCols.push(E('th', { 'class': 'xfree-pbr-col-tunnel' }, [
				E('div', { 'class': 'xfree-pbr-tunnel-th' }, [
					E('span', { 'class': 'xfree-vpn-status-dot is-' + (row.ifaceUp ? 'ok' : 'bad') }),
					E('strong', {}, [ row.name ]),
					row.kind ? E('span', { 'class': 'muted font-mono', 'style': 'font-size: 10px;' }, [ ' (' + row.kind + ')' ]) : ''
				])
			]));
		});

		headerCols.push(E('th', { 'style': 'text-align: right; min-width: 190px;' }, [ _('Быстрые действия') ]));

		// 4. Rows
		var rows = [];

		availableNets.forEach(function(net) {
			var rowCells = [];
			var icon = '🌐';
			var desc = '';

			if (net === 'lan') {
				icon = '🏠';
				desc = _(' (основная сеть)');
			} else if (net === 'guest') {
				icon = '👥';
				desc = _(' (гостевой Wi-Fi)');
			} else if (net === 'iot') {
				icon = '💡';
				desc = _(' (умный дом)');
			}

			// Network name cell
			rowCells.push(E('td', { 'class': 'xfree-pbr-cell-net' }, [
				E('span', { 'style': 'margin-right: 6px;' }, [ icon ]),
				E('strong', { 'class': 'font-mono' }, [ net ]),
				desc ? E('span', { 'class': 'muted font-xs' }, [ desc ]) : ''
			]));

			// Per-tunnel checkbox cells
			ifaces.forEach(function(t) {
				var list = self._pbrMatrix[t.name] || [];
				var inBypass = list.indexOf(net) >= 0;
				var initList = initialMap[t.name] || [];
				var initInBypass = initList.indexOf(net) >= 0;
				var isCellModified = (inBypass !== initInBypass);

				var cb = E('input', {
					'type': 'checkbox',
					'class': 'xfree-pbr-matrix-cb',
					'checked': inBypass ? true : null,
					'title': inBypass
						? _('Сеть «%s» исключена из «%s» (трафик идёт в WAN). Нажмите, чтобы направить в VPN.').format(net, t.name)
						: _('Сеть «%s» использует «%s» по спискам VPN. Нажмите, чтобы исключить (пустить в WAN).').format(net, t.name),
					'change': function() {
						var cur = self._pbrMatrix[t.name] || [];
						var idx = cur.indexOf(net);
						if (this.checked && idx === -1) {
							cur.push(net);
						} else if (!this.checked && idx >= 0) {
							cur.splice(idx, 1);
						}
						self._pbrMatrix[t.name] = cur;
						self.requestPaint();
					}
				});

				var cellClasses = [ 'xfree-pbr-cell-check' ];
				if (inBypass) cellClasses.push('is-bypass');
				if (isCellModified) cellClasses.push('is-modified');

				rowCells.push(E('td', { 'class': cellClasses.join(' ') }, [
					E('label', {
						'class': 'xfree-pbr-cb-wrap' + (isCellModified ? ' is-modified' : ''),
						'title': isCellModified ? _('Это значение изменено, но ещё не сохранено') : null
					}, [
						cb,
						E('span', { 'class': 'xfree-pbr-cb-label' }, [ inBypass ? _('WAN') : _('VPN') ])
					])
				]));
			});

			// Quick action buttons for this row
			var bypassAllBtn = E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Исключить сеть «%s» из ВСЕХ туннелей (всегда направлять через WAN)').format(net),
				'click': function(ev) {
					ev.preventDefault();
					ifaces.forEach(function(t) {
						var cur = self._pbrMatrix[t.name] || [];
						if (cur.indexOf(net) === -1)
							cur.push(net);
						self._pbrMatrix[t.name] = cur;
					});
					self.requestPaint();
				}
			}, [ _('В обход всех') ]);

			var vpnAllBtn = E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Направлять сеть «%s» через все туннели по спискам маршрутов').format(net),
				'click': function(ev) {
					ev.preventDefault();
					ifaces.forEach(function(t) {
						var cur = self._pbrMatrix[t.name] || [];
						var idx = cur.indexOf(net);
						if (idx >= 0)
							cur.splice(idx, 1);
						self._pbrMatrix[t.name] = cur;
					});
					self.requestPaint();
				}
			}, [ _('Все в VPN') ]);

			rowCells.push(E('td', { 'style': 'text-align: right; white-space: nowrap;' }, [
				bypassAllBtn,
				' ',
				vpnAllBtn
			]));

			rows.push(E('tr', { 'class': 'xfree-selfroute-row' }, rowCells));
		});

		var table = E('table', { 'class': 'xfree-selfroute-table xfree-pbr-matrix' }, [
			E('thead', {}, [
				E('tr', {}, headerCols)
			]),
			E('tbody', {}, rows)
		]);

		// Unified smart action button (always working, compact, never stretches)
		var actionBtn = E('button', {
			'class': isDirty ? 'btn ghost-compact xfree-pbr-action-btn is-dirty' : 'ghost ghost-compact xfree-pbr-action-btn',
			'type': 'button',
			'title': isDirty
				? _('Сохранить изменения матрицы и переприменить правила маршрутизации')
				: _('Переприменить текущие правила маршрутизации nftables (apply-routing)'),
			'click': function(ev) {
				ev.preventDefault();
				if (isDirty) {
					var bulkArg = ifaces.map(function(t) {
						var nets = (self._pbrMatrix[t.name] || []).join(' ');
						return t.name + '=' + (nets || '-');
					}).join(';');

					self._pbrSavedSnapshot = JSON.stringify(self._pbrMatrix);
					self._act(ev, 'pbrApplyBulk', bulkArg,
						_('Применить новую матрицу исключений PBR для туннелей?'));
				} else {
					self._act(ev, 'applyRouting', '',
						_('Переприменить правила маршрутизации nftables прямо сейчас?'));
				}
			}
		}, [
			isDirty ? ('⚡ ' + _('Сохранить и применить')) : ('⚡ ' + _('Применить маршрутизацию'))
		]);

		var resetBtn = isDirty ? E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'style': 'color: var(--muted);',
			'title': _('Отменить несохранённые изменения и вернуть текущие настройки'),
			'click': function(ev) {
				ev.preventDefault();
				self._pbrMatrix = JSON.parse(self._pbrSavedSnapshot);
				self.requestPaint();
			}
		}, [ '🔄 ' + _('Отменить') ]) : null;

		var statusBtn = E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'title': _('Показать текущую конфигурацию PBR bypass и nft sets'),
			'click': ui.createHandlerFn(view, function(ev) {
				self._act(ev, 'pbrStatus', '');
			})
		}, [ '📋 ' + _('Подробный статус PBR') ]);

		var dirtyNotice = isDirty ? E('span', { 'class': 'xfree-pbr-dirty-hint' }, [
			'● ' + _('Есть несохранённые изменения')
		]) : null;

		var toolbar = E('div', { 'class': 'xfree-pbr-matrix-toolbar' }, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
				statusBtn
			]),
			E('div', { 'class': 'xfree-pbr-main-ops' }, [
				dirtyNotice ? dirtyNotice : '',
				resetBtn ? resetBtn : '',
				actionBtn
			])
		]);

		var stateBadge = isDirty
			? E('span', { 'class': 'xfree-vpn-badge is-warn', 'style': 'font-size: 11px;' }, [ '● ' + _('Есть изменения') ])
			: E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size: 11px;' }, [ '✓ ' + _('Сохранено') ]);

		return E('section', { 'class': 'xfree-vpn-section xfree-selfroute-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('h4', {}, [ '🛡️ ' + _('Матрица сетей без VPN → WAN (PBR Bypass)') ]),
						stateBadge
					]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Policy-Based Routing') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Отметьте ячейки «WAN», чтобы трафик выбранной локальной сети всегда шёл напрямую в интернет через провайдера, минуя соответствующий туннель. Ячейки «VPN» используют туннель по спискам доменов.')
				])
			]),
			table,
			toolbar
		]);
	}

	render() {
		var self = this;
		var s = this._spec || {};
		var view = s.view;
		var expert = !!(s.expert);
		var summary = this._summary || {};
		var ifaces = summary.ifaces || [];
		var warp = summary.warp || {};
		var proton = summary.proton || {};
		var count = summary.count || ifaces.length || 0;
		var stateOk = summary.stateOk || 0;
		var sourceOk = summary.sourceOk || 0;
		var viaMap = {};
		for (i = 0; i < ifaces.length; i++) {
			if (ifaces[i].selfRouteVia) {
				if (!viaMap[ifaces[i].selfRouteVia])
					viaMap[ifaces[i].selfRouteVia] = [];
				viaMap[ifaces[i].selfRouteVia].push(ifaces[i].name);
			}
		}
		var chips = [];
		var tunnelCards = [];
		var genCards = [];
		var ops = [];
		var i;
		var iface;
		var sub;
		var viewMode = this._vpnView || 'tunnels';
		var sections = [];
		var createKinds = listCreateKinds(summary);
		var createBtns = [];
		var ci;
		var ck;
		var toneApplied = count > 0 && stateOk === count ? 'ok' : (stateOk > 0 ? 'warn' : 'muted');
		var headHint = viewMode === 'server'
			? _('Управление входящим VPN-сервером AmneziaWG, клиентами, QR-кодами и конфигурациями.')
			: (viewMode === 'protocols'
				? _('Управление установкой компонентов и протоколов VPN на роутере.')
				: (viewMode === 'generators'
					? _('Импорт конфигураций (Amnezia, WireGuard, OpenVPN) и генераторы WARP / Proton.')
					: (viewMode === 'selfroute'
						? _('Каскадная маршрутизация (туннель через туннель). Направляет endpoint целевого VPN через промежуточный туннель, скрывая реальный IP роутера.')
						: (viewMode === 'pbrbypass'
							? _('Policy-Based Routing: прямой выход выбранных локальных сетей в интернет через WAN в обход VPN.')
							: _('Статус профиля и быстрые действия. Списки сайтов — Маршруты → VPN.')))));
		var headTitle = viewMode === 'server'
			? _('VPN-сервер')
			: (viewMode === 'protocols'
				? _('Компоненты')
				: (viewMode === 'generators'
					? _('Генераторы и импорт')
					: (viewMode === 'selfroute'
						? _('Self-route')
						: (viewMode === 'pbrbypass'
							? _('PBR Bypass')
							: _('VPN-туннели')))));

		this.className = 'xfree-vpn-root';
		this.setAttribute('data-xfree-vpn', '1');

		if (viewMode === 'protocols') {
			var ps = this._protocolsStatus || {};
			var isProtocolsLoading = !!(this._loading || !this._protocolsLoaded);
			if (isProtocolsLoading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ 'AmneziaWG' ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ 'OpenVPN' ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ 'Sing-box' ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ 'FreeTurn Client' ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 14px;' }) ])
				]));
			} else {
				var isInst = function(lbl) { return lbl && lbl !== 'Не установлен'; };
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (isInst(ps.awg) ? ' is-ok' : ' is-muted') }, [
					E('span', { 'class': 'k' }, [ 'AmneziaWG' ]),
					E('span', { 'class': 'v' }, [ ps.awg || _('Не установлен') ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (isInst(ps.openvpn) ? ' is-ok' : ' is-muted') }, [
					E('span', { 'class': 'k' }, [ 'OpenVPN' ]),
					E('span', { 'class': 'v' }, [ ps.openvpn || _('Не установлен') ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (isInst(ps.vless) ? ' is-ok' : ' is-muted') }, [
					E('span', { 'class': 'k' }, [ 'Sing-box' ]),
					E('span', { 'class': 'v' }, [ ps.vless || _('Не установлен') ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (isInst(ps.freeturn) ? ' is-ok' : ' is-muted') }, [
					E('span', { 'class': 'k' }, [ 'FreeTurn Client' ]),
					E('span', { 'class': 'v' }, [ ps.freeturn || _('Не установлен') ])
				]));
			}
		} else if (viewMode === 'server') {
			var isServerLoading = !!(this._loading || !this._serverLoaded);
			if (isServerLoading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Сервер') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Интерфейс : Порт') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 90px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Подсеть') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 75px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Клиентов') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 25px; height: 14px;' }) ])
				]));
			} else {
				var awg = this._awgSummary || {};
				var peerCount = (awg.peers && awg.peers.length) || 0;
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.running ? ' is-ok' : ' is-bad') }, [
					E('span', { 'class': 'k' }, [ _('Сервер') ]),
					E('span', { 'class': 'v' }, [ awg.running ? _('активен (UP)') : _('остановлен') ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [ _('Интерфейс : Порт') ]),
					E('span', { 'class': 'v' }, [ (awg.iface || 'awg_ingress') + ' : ' + (awg.port || '51820') + ' UDP' ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [ _('Подсеть') ]),
					E('span', { 'class': 'v' }, [ awg.addr || '10.200.200.1/24' ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (peerCount > 0 ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [ _('Клиентов') ]),
					E('span', { 'class': 'v' }, [ String(peerCount) ])
				]));
				if (awg.freeTurnInstalled) {
					chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.freeTurnRunning ? ' is-ok' : '') }, [
						E('span', { 'class': 'k' }, [ _('FreeTurn') ]),
						E('span', { 'class': 'v' }, [ awg.freeTurnRunning ? _('порт %s').format(awg.freeTurnPort || '56000') : _('остановлен') ])
					]));
				}
				if (awg.vkInstalled || awg.vkRunning) {
					chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.vkRunning ? ' is-ok' : '') }, [
						E('span', { 'class': 'k' }, [ _('VK-Turn') ]),
						E('span', { 'class': 'v' }, [ awg.vkRunning ? _('порт %s').format(awg.vkPort || '49151') : _('остановлен') ])
					]));
				}
			}
		} else if (viewMode === 'generators') {
			if (s.loading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('WARP .conf') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 48px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Proton .conf') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 48px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Всего файлов') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 48px; height: 14px;' }) ])
				]));
			} else {
				var confsList = summary.confs || [];
				var warpConfsCount = 0;
				var protonConfsCount = 0;
				for (i = 0; i < confsList.length; i++) {
					if (confsList[i].kind === 'warp' || /warp/i.test(confsList[i].file))
						warpConfsCount++;
					else if (confsList[i].kind === 'proton' || /proton/i.test(confsList[i].file))
						protonConfsCount++;
				}
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (warpConfsCount ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [ _('WARP .conf') ]),
					E('span', { 'class': 'v' }, [ warpConfsCount ? ('%d .conf'.format(warpConfsCount)) : _('нет') ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (protonConfsCount ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [ _('Proton .conf') ]),
					E('span', { 'class': 'v' }, [ protonConfsCount ? ('%d .conf'.format(protonConfsCount)) : _('нет') ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (confsList.length ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [ _('Всего файлов') ]),
					E('span', { 'class': 'v' }, [ confsList.length + ' .conf' ])
				]));
			}
		} else if (viewMode === 'selfroute') {
			var isSelfRouteLoading = !!(this._loading || (!ifaces.length && !this._summaryLoaded));
			if (isSelfRouteLoading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Туннелей') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Каскадных (Via)') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Прямой WAN') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Hotplug') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 50px; height: 14px;' }) ])
				]));
			} else {
				var viaCount = 0;
				for (i = 0; i < ifaces.length; i++) {
					if (ifaces[i].selfRouteVia)
						viaCount++;
				}
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [ _('Туннелей') ]),
					E('span', { 'class': 'v' }, [ String(count) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (viaCount > 0 ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [ _('Каскадных (Via)') ]),
					E('span', { 'class': 'v' }, [ String(viaCount) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [ _('Прямой WAN') ]),
					E('span', { 'class': 'v' }, [ String(count - viaCount) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (summary.selfRouteHotplug ? ' is-ok' : ' is-warn') }, [
					E('span', { 'class': 'k' }, [ _('Hotplug') ]),
					E('span', { 'class': 'v' }, [ summary.selfRouteHotplug ? _('активен') : _('не настроен') ])
				]));
			}
		} else if (viewMode === 'pbrbypass') {
			var isPbrLoading = !!(this._loading || (!ifaces.length && !this._summaryLoaded));
			if (isPbrLoading) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Сетей (LAN/VLAN)') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Туннелей') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Bypass в WAN') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 30px; height: 14px;' }) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
					E('span', { 'class': 'k' }, [ _('Режим') ]),
					E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 60px; height: 14px;' }) ])
				]));
			} else {
				var uciNets = summary.uciNetworks || [];
				var availableNets = (Array.isArray(uciNets) && uciNets.length) ? uciNets.slice() : [ 'lan', 'guest' ];
				if (availableNets.indexOf('lan') === -1)
					availableNets.unshift('lan');
				var activeBypassCount = 0;
				for (i = 0; i < ifaces.length; i++) {
					var pbrList = ifaces[i].pbrBypassNets || [];
					for (var ni = 0; ni < availableNets.length; ni++) {
						if (pbrList.indexOf(availableNets[ni]) !== -1)
							activeBypassCount++;
					}
				}
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [ _('Сетей (LAN/VLAN)') ]),
					E('span', { 'class': 'v' }, [ String(availableNets.length) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
					E('span', { 'class': 'k' }, [ _('Туннелей') ]),
					E('span', { 'class': 'v' }, [ String(ifaces.length) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (activeBypassCount > 0 ? ' is-warn' : '') }, [
					E('span', { 'class': 'k' }, [ _('Bypass в WAN') ]),
					E('span', { 'class': 'v' }, [ String(activeBypassCount) ])
				]));
				chips.push(E('div', { 'class': 'xfree-uplink-chip is-ok' }, [
					E('span', { 'class': 'k' }, [ _('Режим') ]),
					E('span', { 'class': 'v' }, [ _('Policy Routing') ])
				]));
			}
		} else if ((this._loading || s.loading) && !this._summaryLoaded) {
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('Туннели') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 28px; height: 14px;' }) ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('В state') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 44px; height: 14px;' }) ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [ _('Source') ]),
				E('span', { 'class': 'v' }, [ E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 44px; height: 14px;' }) ])
			]));
		} else {
			chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [ _('Туннели') ]),
				E('span', { 'class': 'v' }, [ String(count) ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-' + toneApplied }, [
				E('span', { 'class': 'k' }, [ _('В state') ]),
				E('span', { 'class': 'v' }, [ '%s / %s'.format(stateOk, count || '0') ])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' + (sourceOk === count && count ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [ _('Source') ]),
				E('span', { 'class': 'v' }, [ '%s / %s'.format(sourceOk, count || '0') ])
			]));
		}

		if (s.loading && !ifaces.length) {
			tunnelCards.push(renderTunnelSkeleton());
			tunnelCards.push(renderTunnelSkeleton());
		}

		for (i = 0; i < ifaces.length; i++) {
			iface = ifaces[i];
			sub = [];
			if (iface.kind)
				sub.push(iface.kind);
			if (iface.server)
				sub.push(iface.server);
			if (iface.country)
				sub.push(countryName(iface.country));
			if (iface.city && String(iface.kind || '').toLowerCase() === 'proton')
				sub.push(iface.city);
			if (iface.colo)
				sub.push(coloLabel(iface.colo));
			(function(row) {
				var tone = healthTone(row.health);
				var statusBits = [];
				var metaRows = [];
				var cardClass = 'xfree-vpn-tunnel is-' + tone;
				var kindLc = String(row.kind || '').toLowerCase();
				var cityOk = row.city && (kindLc === 'proton' ||
					!/^(cf-|[0-9])/i.test(row.city));
				var countryShow = countryName(row.country || coloCountry(row.colo));
				var coloShow = coloLabel(row.colo);

				statusBits.push(E('span', {
					'class': 'xfree-vpn-status is-' + tone
				}, [ healthLabel(row.health) ]));
				statusBits.push(E('span', {
					'class': 'xfree-vpn-status is-' + (row.ifaceUp ? 'ok' : 'bad')
				}, [ row.ifaceUp ? 'UP' : 'DOWN' ]));
				if (row.rtOk)
					statusBits.push(E('span', { 'class': 'xfree-vpn-status is-ok' }, [ 'rt' ]));
				else if (row.lists === 0)
					statusBits.push(E('span', { 'class': 'xfree-vpn-status' }, [ _('empty') ]));
				else if (row.state)
					statusBits.push(E('span', { 'class': 'xfree-vpn-status is-warn' }, [ _('apply?') ]));

				if (countryShow)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [ _('страна') ]),
						E('span', {}, [ countryShow ])
					]));
				if (cityOk)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [ _('город') ]),
						E('span', {}, [ row.city ])
					]));
				if (coloShow)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [ _('колония') ]),
						E('span', {}, [ coloShow ])
					]));
				else if (kindLc === 'warp')
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [ _('колония') ]),
						E('span', { 'class': 'muted' }, [ _('нет в meta') ])
					]));
				if (row.probe)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [ 'probe' ]),
						E('span', {}, [ row.probe ])
					]));
				if (row.proton)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [ 'proton' ]),
						E('span', {}, [ row.proton + (row.sess ? ' · ' + row.sess : '') ])
					]));
				if (row.cert)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [ 'cert' ]),
						E('span', {}, [ row.cert ])
					]));
				if (row.dev && row.dev !== row.name)
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv' }, [
						E('em', {}, [ 'dev' ]),
						E('span', {}, [ row.dev ])
					]));
				if (row.selfRouteVia) {
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv xfree-vpn-kv-route is-target' }, [
						E('em', {}, [ _('через') ]),
						E('span', { 'class': 'xfree-vpn-route-chip' }, [
							'➔ ',
							E('strong', {}, [ row.selfRouteVia ])
						])
					]));
				}
				if (viaMap[row.name] && viaMap[row.name].length) {
					metaRows.push(E('div', { 'class': 'xfree-vpn-kv xfree-vpn-kv-route is-gateway' }, [
						E('em', {}, [ _('шлюз для') ]),
						E('span', { 'class': 'xfree-vpn-gw-chip' }, [
							'⮡ ' + viaMap[row.name].join(', ')
						])
					]));
				}

				tunnelCards.push(E('div', { 'class': cardClass }, [
					E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
						E('strong', {}, [ row.name ]),
						E('div', { 'class': 'xfree-vpn-status-row' }, statusBits)
					]),
					sub.length ? E('div', { 'class': 'xfree-vpn-tunnel-sub muted' }, [ sub.join(' · ') ]) : '',
					metaRows.length
						? E('div', { 'class': 'xfree-vpn-tunnel-meta' }, metaRows)
						: E('div', { 'class': 'xfree-vpn-tunnel-meta muted' }, [
							_('Нет данных probe — проверьте монитор')
						]),
					E('div', { 'class': 'xfree-vpn-badges' }, [
						badge('work', row.work),
						badge('state', row.state),
						badge('gen', row.gen),
						badge('src', row.source)
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-actions' }, [
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'click': ui.createHandlerFn(view, function(ev) {
								self._act(ev, 'applyOne', row.name,
									_('Применить туннель «%s»?').format(row.name));
							})
						}, [ _('Применить') ]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'title': row.lists
								? _('Списки маршрутов для «%s» (%d активных). Нажмите для перехода в «Маршруты»').format(row.name, row.lists)
								: _('Списки маршрутов для «%s». Нажмите для перехода в «Маршруты»').format(row.name),
							'click': function(ev) {
								if (ev) {
									ev.preventDefault();
									ev.stopPropagation();
								}
								if (s.onNavigate)
									s.onNavigate('routing', 'vpn', row.name);
								else if (view && view.navigate)
									view.navigate('routing', 'vpn', row.name);
							}
						}, [ _('Списки') ]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'click': ui.createHandlerFn(view, function(ev) {
								self._updateIface(ev, row.name, row.kind || '');
							})
						}, [ _('Обновить') ]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'click': function(ev) {
								if (ev) {
									ev.preventDefault();
									ev.stopPropagation();
								}
								try {
									self._openRebuildDialog(row.name, row.kind || '');
								} catch (err) {
									self.setBusy(false);
									self.setMessage((err && err.message) ? err.message : String(err), 'bad');
								}
							}
						}, [ _('Пересобрать') ]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'click': ui.createHandlerFn(view, function(ev) {
								self._act(ev, 'show', row.name);
							})
						}, [ _('Файлы') ]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'click': ui.createHandlerFn(view, function(ev) {
								self._deleteIface(ev, row.name);
							})
						}, [ _('Удалить') ])
					])
				]));
			})(iface);
		}

		if (viewMode === 'tunnels') {
			for (ci = 0; ci < createKinds.length; ci++) {
				ck = createKinds[ci];
				(function(row) {
					createBtns.push(E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function(ev) {
							if (ev) {
								ev.preventDefault();
								ev.stopPropagation();
							}
							try {
								self._openNewTunnelDialog(row.kind, row.slot);
							} catch (err) {
								self.setBusy(false);
								self.setMessage((err && err.message) ? err.message : String(err), 'bad');
							}
						}
					}, [ '+ ' + createKindLabel(row.kind) ]));
				})(ck);
			}
			createBtns.push(E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					self._openAddTunnelDialog(view);
				})
			}, [ _('загрузить…') ]));
			createBtns.push(E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					self._createFromConf(ev);
				})
			}, [ _('из conf') ]));
			tunnelCards.push(E('div', { 'class': 'xfree-vpn-tunnel is-new' }, [
				E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
					E('strong', {}, [ _('Новый') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('создать') ])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-sub muted' }, [
					_('Генерация .conf → интерфейс → apply')
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-actions xfree-vpn-create-actions' }, createBtns)
			]));
		}

		var allConfs = summary.confs || [];
		var warpLatestConf = null;
		var protonLatestConf = null;
		var warpTunnel = null;
		var protonTunnel = null;
		for (i = 0; i < allConfs.length; i++) {
			if (!warpLatestConf && (allConfs[i].kind === 'warp' || /warp/i.test(allConfs[i].file)))
				warpLatestConf = allConfs[i];
			if (!protonLatestConf && (allConfs[i].kind === 'proton' || /proton/i.test(allConfs[i].file)))
				protonLatestConf = allConfs[i];
		}
		for (i = 0; i < ifaces.length; i++) {
			if (!warpTunnel && String(ifaces[i].kind || ifaces[i].name || '').toLowerCase().indexOf('warp') >= 0)
				warpTunnel = ifaces[i];
			if (!protonTunnel && String(ifaces[i].kind || ifaces[i].name || '').toLowerCase().indexOf('proton') >= 0)
				protonTunnel = ifaces[i];
		}

		var warpCard = E('div', {
			'class': 'xfree-vpn-gen',
			'style': 'align-self: start; height: auto; min-height: 0; justify-content: flex-start;'
		}, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title' }, [
					E('strong', {}, [ _('WARP') ]),
					E('span', { 'class': 'muted' }, [ _('генератор') ])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, s.loading ? [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 72px; height: 18px; border-radius: 999px;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 88px; height: 18px; border-radius: 999px;' })
				] : [
					warpLatestConf
						? E('span', { 'class': 'xfree-vpn-status is-ok', 'title': warpLatestConf.created || '' }, [ '📄 ' + warpLatestConf.file ])
						: E('span', { 'class': 'xfree-vpn-status is-warn' }, [ _('нет .conf') ]),
					warpTunnel
						? E('span', { 'class': 'xfree-vpn-status is-' + (warpTunnel.ifaceUp ? 'ok' : 'bad') }, [ '🔗 ' + warpTunnel.name + ' (' + (warpTunnel.ifaceUp ? 'UP' : 'DOWN') + ')' ])
						: E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('туннель не добавлен') ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-fields-wrap' }, [
				E('div', { 'class': 'xfree-vpn-fields' }, [
					selectField('warp_server', _('Сервер'), warp.server || 'xfree', WARP_SERVERS),
					selectField('warp_selection', _('Выбор endpoint'), warp.selection || 'best', WARP_SELECTION),
					selectField('warp_exclude_ru', _('Фильтр колоний RU'), warp.excludeRu != null ? String(warp.excludeRu) : '1', [
						{ v: '1', t: _('Вкл — без DME/LED/KJA/SVX') },
						{ v: '0', t: _('Выкл') }
					]),
					selectField('warp_profile', _('Профиль AWG'), warp.profile || '2.0:1', WARP_PROFILES),
					selectField('warp_mode', _('Режим'), warp.mode || 'local', WARP_MODES),
					selectField('warp_i1_mode', _('I1'), warp.i1Mode || 'fixed', WARP_I1),
					textField('warp_i1_domain', _('I1 domain/seed'), warp.i1Domain || '', _('для domain')),
					textField('warp_name', _('Имя файла'), warp.name || '', _('авто'))
				]),
				warpServerTip(),
				warpServerNeedsReg(warp.server)
					? E('p', { 'class': 'xfree-vpn-tip is-warn' }, [
						_('Сейчас выбран сервер со страной (рег.) — без активации в боте llimonix туннель через tribukvy может не работать.')
					])
					: '',
				warpServerIsLte(warp.server)
					? E('p', { 'class': 'xfree-vpn-tip' }, [
						_('Сейчас выбран [LTE]: без бота; endpoint tel.*.tribukvy.ltd, порты как на сайте (ltePL ≠988, lteFL ≠1010).')
					])
					: ''
			]),
			E('div', {
				'class': 'xfree-vpn-tunnel-actions',
				'style': 'margin-top: 10px; flex: 0 0 auto;'
			}, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': ui.createHandlerFn(view, function(ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('warp_'), [
							'warp_server', 'warp_profile', 'warp_mode',
							'warp_i1_mode', 'warp_i1_domain', 'warp_name',
							'warp_selection', 'warp_exclude_ru'
						]);
						self._act(ev, arg ? 'warpSaveAndGenerate' : 'warpGenerate', arg,
							_('Сгенерировать WARP .conf с текущими параметрами?'));
					})
				}, [ _('Сгенерировать') ]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function(ev) {
						self._saveWarp(ev);
					})
				}, [ _('Сохранить') ]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function(ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						try {
							self._openConfManager('warp');
						} catch (err) {
							self.setBusy(false);
							self.setMessage((err && err.message) ? err.message : String(err), 'bad');
						}
					}
				}, [ _('.conf…') ])
			])
		]);

		var protonCountryField = E('div', { 'class': 'xfree-vpn-field' }, [
			E('div', { 'class': 'xfree-vpn-field-label', 'style': 'display: flex; justify-content: space-between; align-items: center;' }, [
				E('span', {}, [ _('Страна') ]),
				E('button', {
					'class': 'ghost ghost-compact xfree-vpn-proton-country-refresh',
					'type': 'button',
					'title': _('Обновить список стран с серверов Proton'),
					'style': 'padding: 0 4px; font-size: 11px; height: 18px; line-height: 18px; border: none; background: transparent; cursor: pointer;',
					'click': function(ev) {
						ev.preventDefault();
						ev.stopPropagation();
						self._fetchProtonCountries(true);
					}
				}, [ self._protonCountriesFetching ? '⏳' : '🔄' ])
			]),
			E('select', {
				'class': 'xfree-uplink-input',
				'data-xfree-vpn-field': 'proton_country'
			})
		]);

		var protonFreeOnlySelect = E('select', {
			'class': 'xfree-uplink-input',
			'data-xfree-vpn-field': 'proton_free_only'
		}, [
			E('option', { 'value': '1', 'selected': (proton.free_only !== '0' && proton.free_only !== 0) ? true : null }, [ _('да') ]),
			E('option', { 'value': '0', 'selected': (proton.free_only === '0' || proton.free_only === 0) ? true : null }, [ _('нет') ])
		]);

		var protonIpv6Select = E('select', {
			'class': 'xfree-uplink-input',
			'data-xfree-vpn-field': 'proton_require_ipv6'
		}, [
			E('option', { 'value': '0', 'selected': (proton.require_ipv6 !== '1' && proton.require_ipv6 !== 1) ? true : null }, [ _('все') ]),
			E('option', { 'value': '1', 'selected': (proton.require_ipv6 === '1' || proton.require_ipv6 === 1) ? true : null }, [ _('только IPv6') ])
		]);

		protonFreeOnlySelect.addEventListener('change', function() {
			self._updateProtonCountriesDropdown();
		});
		protonIpv6Select.addEventListener('change', function() {
			self._updateProtonCountriesDropdown();
		});

		var protonCard = E('div', {
			'class': 'xfree-vpn-gen',
			'style': 'align-self: start; height: auto; min-height: 0; justify-content: flex-start;'
		}, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title' }, [
					E('strong', {}, [ _('Proton') ]),
					E('span', { 'class': 'muted' }, [ _('генератор') ])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, s.loading ? [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 72px; height: 18px; border-radius: 999px;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 88px; height: 18px; border-radius: 999px;' })
				] : [
					protonLatestConf
						? E('span', { 'class': 'xfree-vpn-status is-ok', 'title': protonLatestConf.created || '' }, [ '📄 ' + protonLatestConf.file ])
						: E('span', { 'class': 'xfree-vpn-status is-warn' }, [ _('нет .conf') ]),
					protonTunnel
						? E('span', { 'class': 'xfree-vpn-status is-' + (protonTunnel.ifaceUp ? 'ok' : 'bad') }, [ '🔗 ' + protonTunnel.name + ' (' + (protonTunnel.ifaceUp ? 'UP' : 'DOWN') + ')' ])
						: E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('туннель не добавлен') ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-fields-wrap' }, [
				E('div', { 'class': 'xfree-vpn-fields' }, [
					protonCountryField,
					selectField('proton_session_mode', _('Сессия'), proton.session_mode || 'guest', [
						{ v: 'guest', t: _('гостевая') },
						{ v: 'permanent', t: _('постоянная') }
					]),
					selectField('proton_profile', _('Профиль AWG'), proton.profile || '2.0:1', WARP_PROFILES),
					selectField('proton_i1_entropy', _('Энтропия I1'), proton.i1_entropy || 'r32', PROTON_ENTROPY_OPTIONS),
					selectField('proton_awg_noise', _('Шум AWG'), proton.awg_noise || '0', PROTON_NOISE_OPTIONS),
					selectField('proton_selection_mode', _('Выбор сервера'), proton.selection_mode || 'best', [
						{ v: 'best', t: 'best' },
						{ v: 'random', t: 'random' }
					]),
					textField('proton_mtu', 'MTU', proton.mtu || '1280', '1280'),
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [ _('Только free') ]),
						protonFreeOnlySelect
					]),
					E('div', { 'class': 'xfree-vpn-field' }, [
						E('div', { 'class': 'xfree-vpn-field-label' }, [ 'IPv6' ]),
						protonIpv6Select
					]),
					textField('proton_name', _('Имя файла'), proton.name || '', _('авто'))
				])
			]),
			E('div', {
				'class': 'xfree-vpn-tunnel-actions',
				'style': 'margin-top: 10px; flex: 0 0 auto;'
			}, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': ui.createHandlerFn(view, function(ev) {
						ev.preventDefault();
						var arg = self._pipeArgs(self.collectFields('proton_'), [
							'proton_country', 'proton_session_mode', 'proton_profile',
							'proton_name', 'proton_mtu', 'proton_free_only',
							'proton_require_ipv6', 'proton_selection_mode',
							'proton_i1_entropy', 'proton_awg_noise'
						]);
						self._act(ev, arg ? 'protonSaveAndGenerate' : 'protonGenerate', arg,
							_('Сгенерировать Proton .conf через API (raw)?'));
					})
				}, [ _('Сгенерировать') ]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': ui.createHandlerFn(view, function(ev) {
						self._saveProton(ev);
					})
				}, [ _('Сохранить') ]),
				E('button', {
					'class': 'ghost',
					'type': 'button',
					'click': function(ev) {
						if (ev) {
							ev.preventDefault();
							ev.stopPropagation();
						}
						try {
							self._openConfManager('proton');
						} catch (err) {
							self.setBusy(false);
							self.setMessage((err && err.message) ? err.message : String(err), 'bad');
						}
					}
				}, [ _('.conf…') ])
			])
		]);

		genCards.push(warpCard);
		genCards.push(protonCard);
		genCards.push(this._renderImportCard(view));

		setTimeout(function() {
			self._updateProtonCountriesDropdown(proton.country || 'AUTO');
			if (!self._protonServerCountries && !self._protonCountriesFetching) {
				self._fetchProtonCountries(false);
			}
		}, 0);

		var isRefreshing = !!(this._loading || this._busy);
		var topOps = [
			E('button', {
				'class': 'ghost ghost-compact xfree-vpn-head-btn' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние туннелей и интерфейсов'),
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				})
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить статус'))
			])
		];


		if (viewMode === 'tunnels' && ifaces.length > 0) {
			topOps.push(E('button', {
				'class': 'btn ghost-compact xfree-vpn-head-btn is-primary',
				'type': 'button',
				'title': _('Применить конфигурацию всех туннелей профиля'),
				'click': ui.createHandlerFn(view, function(ev) {
					self._act(ev, 'applyAll', '',
						_('Применить все туннели профиля?'));
				})
			}, [ '⚡ ' + _('Применить все') ]));
		}



		if (viewMode === 'overview') {
			var vpnHeadIco = E('span', { 'class': 'stat-ico', 'aria-hidden': 'true', 'style': 'display:inline-flex; vertical-align:middle; margin-right:6px;' });
			vpnHeadIco.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 4.5 3.2 8 8 9 4.8-1 8-4.5 8-9V7z"/><path d="M9.5 12.5 11 14l3.5-3.5"/></svg>';

			var overviewHead = E('div', { 'class': 'xfree-overview-vpn-head' }, [
				E('div', { 'class': 'xfree-overview-vpn-title-wrap' }, [
					E('h3', {}, [
						vpnHeadIco,
						_('VPN-туннели')
					]),
					E('p', { 'class': 'muted xfree-overview-vpn-subhead' }, [
						_('Туннели профиля WireGuard/AWG и маршрутизация')
					])
				]),
				E('div', { 'class': 'xfree-overview-vpn-head-actions' }, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Открыть полный раздел управления туннелями'),
						'click': function(ev) {
							self._nav(ev, 'vpn.tunnels');
						}
					}, [ _('Управление туннелями ➔') ])
				])
			]);

			sections.push(overviewHead);
			sections.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-top: 8px;' }, [
				tunnelCards.length
					? E('div', { 'class': 'xfree-vpn-tunnels' }, tunnelCards)
					: E('p', { 'class': 'muted' }, [
						_('Туннели не найдены — создайте из .conf или на вкладке «Генераторы и импорт».')
					])
			]));

			this.replaceChildren.apply(this, sections);
			if (this._busy) {
				this.querySelectorAll('button').forEach(function(el) {
					el.disabled = true;
				});
			}
			return;
		}

		sections.push(
			E('div', { 'class': 'xfree-vpn-head' }, [
				E('div', { 'class': 'xfree-vpn-head-left' }, [
					E('h3', {}, [ headTitle ]),
					E('p', { 'class': 'muted' }, [ headHint ])
				]),
				E('div', { 'class': 'xfree-vpn-head-right' }, [
					E('div', { 'class': 'xfree-vpn-head-actions' }, topOps),
					E('div', {
						'class': 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
						'data-xfree-vpn-msg': '1'
					}, [ this._msg || '' ])
				])
			]),
			E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips)
		);

		if (viewMode === 'tunnels') {
			sections.push(
				E('section', { 'class': 'xfree-vpn-section' }, [
					E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;' }, [
						E('h4', { 'style': 'margin: 0;' }, [ _('Туннели профиля') ]),
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'click': function(ev) {
								ev.preventDefault();
								self._openAddTunnelDialog(view);
							}
						}, [ _('+ Добавить туннель') ])
					]),
					tunnelCards.length
						? E('div', { 'class': 'xfree-vpn-tunnels' }, tunnelCards)
						: E('p', { 'class': 'muted' }, [
							_('Туннели не найдены — создайте из .conf или на вкладке «Генераторы и импорт».')
						])
				])
			);
		} else if (viewMode === 'server') {
			var serverSec = this._renderServerSection(this._awgSummary || {}, view);
			if (serverSec)
				sections.push(serverSec);
		} else if (viewMode === 'protocols') {
			var protoSec = this._renderProtocolsSection(view);
			if (protoSec)
				sections.push(protoSec);
		} else if (viewMode === 'selfroute') {
			var selfRouteSec = this._renderSelfRouteSection(ifaces, summary, view);
			if (selfRouteSec)
				sections.push(selfRouteSec);
			else
				sections.push(E('p', { 'class': 'muted' }, [
					_('Туннели не найдены. Создайте туннели для настройки исходящей маршрутизации.')
				]));
		} else if (viewMode === 'pbrbypass') {
			var pbrSec = this._renderPbrBypassSection(ifaces, summary, view);
			if (pbrSec)
				sections.push(pbrSec);
			else
				sections.push(E('p', { 'class': 'muted' }, [
					_('Туннели не найдены. Создайте туннели для настройки матрицы PBR.')
				]));
		} else if (viewMode === 'generators') {
			sections.push(
				E('section', { 'class': 'xfree-vpn-section' }, [
					E('div', { 'class': 'xfree-vpn-gens' }, genCards)
				])
			);
		} else {
			sections.push(
				E('section', { 'class': 'xfree-vpn-section' }, [
					E('h4', {}, [ _('Туннели профиля') ]),
					tunnelCards.length
						? E('div', { 'class': 'xfree-vpn-tunnels' }, tunnelCards)
						: E('p', { 'class': 'muted' }, [
							_('Туннели не найдены — создайте из .conf или на вкладке «Генераторы и импорт».')
						])
				])
			);
		}

		this.replaceChildren.apply(this, sections);

		if (this._busy) {
			this.querySelectorAll('button').forEach(function(el) {
				el.disabled = true;
			});
		}
	}
});

return baseclass.extend({
	tag: TAG,
	COUNTRY_RU: COUNTRY_RU,
	WARP_COLO: WARP_COLO,
	countryName: countryName,
	coloLabel: coloLabel,
	coloCountry: coloCountry,
	coloCity: coloCity,
	healthTone: healthTone,
	healthLabel: healthLabel,
	badge: badge,
	renderTunnelSkeleton: renderTunnelSkeleton
});
