'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.panels.vpn-screen as vpnScreen';
'require xfree-toolbox.panels.vpn-tunnels-panel';
'require xfree-toolbox.panels.vpn-generators-panel';
'require xfree-toolbox.panels.vpn-selfroute-panel';
'require xfree-toolbox.panels.vpn-pbrbypass-panel';
'require xfree-toolbox.panels.vpn-settings-panel';

/* Хаб VPN: выбирает экран по vpnView и монтирует готовый тег.
 * data-xfree-vpn остаётся здесь — reloadVpnHub ищет хаб, а не дочерний экран.
 * display:contents отдаёт flex-колонку .xfree-vpn-root дочернему тегу.
 * Повторный setSummary не пересоздаёт ребёнка: на генераторах живёт кэш стран Proton. */

var TAG = 'xfree-vpn';

function childTag(viewName) {
	if (viewName === 'generators')
		return 'xfree-vpn-generators';
	if (viewName === 'selfroute')
		return 'xfree-vpn-selfroute';
	if (viewName === 'pbrbypass')
		return 'xfree-vpn-pbrbypass';
	if (viewName === 'settings')
		return 'xfree-vpn-settings';
	return 'xfree-vpn-tunnels';
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		spec = spec || {};
		this._spec = spec;
		this._vpnView = spec.vpnView || 'tunnels';
		this._summary = spec.summary || { ifaces: [], warp: {}, proton: {}, count: 0 };
		this._awgSummary = spec.awgSummary || {};
		this._protocolsStatus = spec.protocolsStatus || {};
		this._output = spec.outputText || '';
		this._busy = !!spec.busy;
		this._loading = !!spec.loading;
		this._msg = spec.message || '';
		this._msgTone = spec.messageTone || '';
		this.setAttribute('data-xfree-vpn', '1');
		this.style.display = 'contents';
		this.className = '';
		this.requestPaint();
	}

	_child() {
		return this.firstElementChild;
	}

	_forward(name, args) {
		var child = this._child();

		if (child && typeof child[name] === 'function')
			return child[name].apply(child, args);
		this.requestPaint();
	}

	setLoading(loading) {
		this._loading = !!loading;
		if (this._spec)
			this._spec.loading = this._loading;
		this._forward('setLoading', [loading]);
	}

	setSummary(summary) {
		this._summary = summary || { ifaces: [], warp: {}, proton: {}, count: 0 };
		if (this._spec) {
			this._spec.summary = this._summary;
			this._spec.loading = false;
		}
		this._loading = false;
		this._forward('setSummary', [summary]);
	}

	setAwgSummary(awg) {
		this._awgSummary = awg || {};
		if (this._spec)
			this._spec.awgSummary = this._awgSummary;
		this._forward('setAwgSummary', [awg]);
	}

	setProtocolsStatus(status) {
		this._protocolsStatus = status || {};
		if (this._spec)
			this._spec.protocolsStatus = this._protocolsStatus;
		this._forward('setProtocolsStatus', [status]);
	}

	setOutputText(text) {
		this._output = text || '';
		if (this._spec)
			this._spec.outputText = this._output;
		var child = this._child();

		if (child && typeof child.setOutputText === 'function')
			child.setOutputText(text);
	}

	setBusy(busy) {
		this._busy = !!busy;
		if (this._spec)
			this._spec.busy = this._busy;
		this._forward('setBusy', [busy]);
	}

	setMessage(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		if (this._spec) {
			this._spec.message = this._msg;
			this._spec.messageTone = this._msgTone;
		}
		this._forward('setMessage', [text, tone]);
	}

	render() {
		var viewName = this._vpnView || 'tunnels';
		var el = E(childTag(viewName));
		var spec = this._spec || {};

		spec.vpnView = viewName;
		spec.summary = this._summary;
		spec.awgSummary = this._awgSummary;
		spec.protocolsStatus = this._protocolsStatus;
		spec.outputText = this._output;
		spec.loading = this._loading;
		spec.busy = this._busy;
		spec.message = this._msg;
		spec.messageTone = this._msgTone;
		this.style.display = 'contents';
		this.className = '';
		el.mount(spec);
		this.replaceChildren(el);
	}
});

return baseclass.extend({
	tag: TAG,
	COUNTRY_RU: vpnScreen.COUNTRY_RU,
	WARP_COLO: vpnScreen.WARP_COLO,
	countryName: vpnScreen.countryName,
	coloLabel: vpnScreen.coloLabel,
	coloCountry: vpnScreen.coloCountry,
	coloCity: vpnScreen.coloCity,
	healthTone: vpnScreen.healthTone,
	healthLabel: vpnScreen.healthLabel,
	badge: vpnScreen.badge,
	renderTunnelSkeleton: vpnScreen.renderTunnelSkeleton
});
