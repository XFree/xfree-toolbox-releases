'use strict';
'require baseclass';

/**
 * Hand-maintained LuCI dashboard routes (not generated from menu.compose).
 * CLI menu remains in per-module menu.yaml → menu.gen.sh.
 */
return baseclass.extend({
	data: {
		title: 'xfree-toolbox',
		defaultRoute: 'overview',
		routes: [
			{ id: 'overview', title: 'Обзор', icon: 'home' },
			{
				id: 'profiles',
				title: 'Профили',
				icon: 'profiles',
				tabs: [
					{ id: 'sync', title: 'Обновить', panel: 'templates.sync' },
					{ id: 'recreate', title: 'Пересоздать', panel: 'templates.recreate' },
					{ id: 'restore', title: 'Восстановить', panel: 'templates.restore' },
					{ id: 'create', title: 'Создать', panel: 'templates.instantiate' },
					{ id: 'delete', title: 'Удалить', panel: 'templates.delete' }
				]
			},
			{
				id: 'routing',
				title: 'Маршруты',
				icon: 'routing',
				tabs: [
					{ id: 'general', title: 'Общее', tab: 'general' },
					{ id: 'vpn', title: 'VPN', tab: 'vpn' },
					{ id: 'dns', title: 'DNS', tab: 'dns' },
					{ id: 'zapret', title: 'Zapret', tab: 'zapret' },
					{ id: 'exclude', title: 'Исключения', tab: 'exclude' },
					{ id: 'upstreams', title: 'Источники', tab: 'upstreams', panel: 'upstreams.hub' }
				]
			},
			/* Left-rail VPN: tunnel lifecycle (CLI xft → 7). Lists → Маршруты → VPN. */
			{
				id: 'vpn',
				title: 'VPN',
				icon: 'vpn',
				tabs: [
					{ id: 'tunnels', title: 'Туннели', tab: 'tunnels', panel: 'vpn.hub' },
					{ id: 'server', title: 'Сервер', tab: 'server', panel: 'vpn.server' },
					{ id: 'protocols', title: 'Компоненты', tab: 'protocols', panel: 'vpn.protocols' },
					{ id: 'selfroute', title: 'Self-route', tab: 'selfroute', panel: 'vpn.selfroute' },
					{ id: 'pbrbypass', title: 'PBR Bypass', tab: 'pbrbypass', panel: 'vpn.pbrbypass' },
					{ id: 'devicepolicy', title: 'Исключения устройств', tab: 'devicepolicy', panel: 'vpn.devicepolicy' },
					{ id: 'generators', title: 'Генераторы и импорт', tab: 'generators', panel: 'vpn.generators' }
				]
			},
			{ id: 'zapret', title: 'Zapret', icon: 'zapret' },
			{ id: 'telemt', title: 'Telemt', icon: 'telemt' },
			{
				id: 'network',
				title: 'Сеть',
				icon: 'network',
				tabs: [
					{ id: 'mesh', title: 'Mesh / Wi-Fi', panel: 'network.mesh' },
					{ id: 'modem', title: '4G / LTE Модем', panel: 'network.modem' }
				]
			},
			{
				id: 'diagnostics',
				title: 'Диагностика',
				icon: 'diagnostics',
				tabs: [
					{ id: 'uplink', title: 'Канал', panel: 'uplink.hub' },
					{ id: 'dns', title: 'DNS', panel: 'diagnostics.dns' },
					{ id: 'logs', title: 'Логи', panel: 'diagnostics.logs' },
					{ id: 'misc', title: 'Ещё', panel: 'diagnostics.misc.hub' }
				]
			},
			{
				id: 'system',
				title: 'Система',
				icon: 'system',
				tabs: [
					{ id: 'resources', title: 'Ресурсы', panel: 'system.resources' },
					{ id: 'update', title: 'Обновления', panel: 'system.toolbox' },
					{ id: 'maintenance', title: 'Обслуживание', panel: 'system.maintenance' },
					{ id: 'hardware', title: 'Оборудование', panel: 'system.hardware' },
					{ id: 'mgmt', title: 'Хаб', panel: 'mgmt.status' }
				]
			}
		],
		panels: {
			'templates.sync': {
				id: 'templates.sync',
				title: 'Обновить и применить',
				type: 'invoke',
				api: 'templatesMenu',
				visibility: 'normal',
				action: 'syncApply',
				confirm: 'Скопировать списки из шаблона в профиль и применить к системе? Живые ключи/UCI не затираются.',
				button: 'Обновить и применить',
				descr: 'Тот же пайплайн, что в CLI: toolbox + списки, в профиль копируются только списки.',
				fields: [
					{ id: 'template', title: 'Шаблон', source: 'templates' },
					{ id: 'profile', title: 'Профиль', source: 'profiles' }
				]
			},
			'templates.recreate': {
				id: 'templates.recreate',
				title: 'Пересоздать и применить',
				type: 'invoke',
				api: 'templatesMenu',
				visibility: 'normal',
				action: 'recreateApply',
				confirm: 'Пересоздать профиль из шаблона и применить к системе? Ключи и клиенты VPN-сервера сохраняются.',
				button: 'Пересоздать и применить',
				descr: 'Тот же пайплайн, что «Обновить»: toolbox + списки. Пересоздаёт исходящие соединения и списки. Ключи и клиенты VPN-сервера сохраняются.',
				fields: [
					{ id: 'template', title: 'Шаблон', source: 'templates' },
					{ id: 'profile', title: 'Профиль', source: 'profiles' }
				]
			},
			'templates.restore': {
				id: 'templates.restore',
				title: 'Восстановить из state',
				type: 'invoke',
				api: 'templatesMenu',
				visibility: 'expert',
				action: 'restoreDiff',
				descr: 'Сначала diff с текущим state, затем при необходимости восстановление каталога профиля.',
				fields: [
					{ id: 'profile', title: 'Профиль', source: 'profiles' }
				],
				buttons: [
					{ id: 'diff', title: 'Показать diff', op: 'restoreDiff' },
					{
						id: 'apply',
						title: 'Восстановить',
						op: 'restoreApply',
						confirm: 'Полностью перезаписать каталог profiles/<профиль> из состояния системы?'
					}
				]
			},
			'templates.instantiate': {
				id: 'templates.instantiate',
				title: 'Создать профиль из шаблона',
				type: 'invoke',
				api: 'templatesMenu',
				visibility: 'normal',
				action: 'instantiate',
				descr: 'Создание нового профиля из выбранного шаблона. Ключи и сертификаты будут сгенерированы автоматически.',
				fields: [
					{ id: 'template', title: 'Шаблон', source: 'templates' },
					{ id: 'profile', title: 'Имя нового профиля', type: 'text' },
					{ id: 'force', title: 'Перезаписать, если существует', type: 'checkbox' }
				],
				button: 'Создать профиль',
				confirm: 'Создать новый профиль из шаблона?'
			},
			'templates.delete': {
				id: 'templates.delete',
				title: 'Удалить профиль',
				type: 'invoke',
				api: 'templatesMenu',
				visibility: 'normal',
				action: 'deleteProfile',
				descr: 'Безвозвратное удаление каталога profiles/<профиль>. Активный и применённый профиль удалить невозможно.',
				fields: [
					{ id: 'profile', title: 'Профиль для удаления', source: 'profiles' }
				],
				button: 'Удалить профиль',
				confirm: 'Безвозвратно удалить выбранный профиль из каталога profiles/?'
			},
			'upstreams.hub': {
				id: 'upstreams.hub',
				title: 'Источники списков (Upstreams)',
				type: 'menu',
				visibility: 'normal',
				hint: 'Управление upstream-источниками доменов и IP (antifilter, reestr, custom).',
				items: [
					{
						id: 'updateApply',
						title: 'Обновить и применить',
						subtitle: 'Загрузка обновлений всех активных источников и применение изменений в профиль',
						kind: 'action',
						action: 'upstreamsUpdateApply',
						actionLabel: 'Обновить всё',
						confirm: 'Загрузить свежие списки из сети и применить изменения в профиль?'
					},
					{
						id: 'updateActive',
						title: 'Обновить активные источники',
						subtitle: 'Скачивание свежих списков без немедленного применения в профиль',
						kind: 'action',
						action: 'upstreamsUpdateActive',
						actionLabel: 'Скачать'
					},
					{
						id: 'applyDrift',
						title: 'Применить обновления',
						subtitle: 'Копирование ранее скачанных списков в активный профиль и runtime',
						kind: 'action',
						action: 'upstreamsApply',
						actionLabel: 'Применить',
						confirm: 'Применить скачанные обновления списков к активному профилю?'
					},
					{
						id: 'reindex',
						title: 'Переиндексация источников',
						subtitle: 'Пересборка метаданных, тегов и индексных файлов списков',
						kind: 'action',
						action: 'upstreamsReindex',
						actionLabel: 'Индексировать'
					}
				]
			},
			'routing.vpn': {
				id: 'routing.vpn',
				title: 'Списки для VPN',
				type: 'wizard',
				visibility: 'normal',
				steps: [
					{
						id: 'iface',
						title: 'Туннель',
						component: 'domain-interface-select',
						target: 'iface'
					},
					{
						id: 'lists',
						title: 'Списки сайтов',
						component: 'upstreams-checklist',
						target: 'iface',
						mode: 'all'
					}
				]
			},
			'routing.dns': {
				id: 'routing.dns',
				title: 'Списки для DNS',
				type: 'wizard',
				visibility: 'normal',
				steps: [
					{
						id: 'dns',
						title: 'DNS',
						component: 'domain-interface-select',
						target: 'dns'
					},
					{
						id: 'lists',
						title: 'Списки сайтов',
						component: 'upstreams-checklist',
						target: 'dns',
						mode: 'fqdn_only'
					}
				]
			},
			/* Lists wizard — opened from Маршруты → Zapret (not left-rail Zapret). */
			'zapret.lists': {
				id: 'zapret.lists',
				title: 'Списки для Zapret',
				type: 'wizard',
				visibility: 'normal',
				steps: [
					{
						id: 'section',
						title: 'Секция',
						component: 'domain-interface-select',
						target: 'zapret'
					},
					{
						id: 'lists',
						title: 'Списки сайтов',
						component: 'upstreams-checklist',
						target: 'zapret',
						mode: 'all'
					}
				]
			},
			/* Left-rail VPN: CLI xft → 7 (VPN-туннели). Lists → Маршруты → VPN. */
			'vpn.hub': {
				id: 'vpn.hub',
				title: 'VPN-туннели',
				type: 'vpn',
				vpnView: 'tunnels',
				visibility: 'normal',
				hint: 'Операции как в CLI (xft → 7). Списки сайтов для туннелей — Маршруты → VPN.',
				items: [
					{
						id: 'listsHint',
						title: 'Списки сайтов — в Маршруты → VPN',
						kind: 'note',
						note: 'Выбор upstream-списков для туннелей — вкладка «Маршруты» → «VPN».'
					},
					{
						id: 'warp',
						title: 'Генератор WARP-конфигов',
						kind: 'panel',
						panel: 'vpn.warp'
					},
					{
						id: 'proton',
						title: 'Генератор Proton-конфигов',
						kind: 'panel',
						panel: 'vpn.proton'
					},
					{
						id: 'list',
						title: 'Показать список туннелей',
						kind: 'action',
						action: 'list'
					},
					{
						id: 'create',
						title: 'Создать туннель из .conf',
						kind: 'action',
						action: 'createFromConf',
						prompt: 'iface|conf',
						promptText: 'Имя туннеля и файл .conf (пример: proton|proton-nl.conf)'
					},
					{
						id: 'update',
						title: 'Обновить туннель из .conf',
						kind: 'action',
						action: 'updateFromConf',
						prompt: 'iface|conf',
						promptText: 'Туннель и .conf (пример: warp|warp-xfree.conf)'
					},
					{
						id: 'regenerate',
						title: 'Пересобрать конфиг туннеля',
						kind: 'panel',
						panel: 'vpn.regenerate'
					},
					{
						id: 'applyOne',
						title: 'Применить туннель на роутере',
						kind: 'action',
						action: 'applyOne',
						prompt: 'iface',
						promptText: 'Имя туннеля (например proton)',
						confirm: 'Применить выбранный туннель (apply-interfaces --iface)?'
					},
					{
						id: 'applyAll',
						title: 'Применить все туннели',
						kind: 'action',
						action: 'applyAll',
						confirm: 'Применить все туннели профиля (apply-interfaces --all)?'
					},
					{
						id: 'delete',
						title: 'Удалить туннель',
						kind: 'action',
						action: 'delete',
						prompt: 'iface|mode',
						promptText: 'Туннель|режим: basic|reconcile|orphans|full (пример: warp|basic)',
						confirm: 'Удалить туннель из профиля и системы (purge)?'
					},
					{
						id: 'show',
						title: 'Показать настройки туннеля',
						kind: 'action',
						action: 'show',
						prompt: 'iface',
						promptText: 'Имя туннеля'
					},
					{
						id: 'listConfs',
						title: 'Показать последние .conf',
						kind: 'action',
						action: 'listConfs'
					},
					{
						id: 'selfroute',
						title: 'Исходящие маршруты туннелей (Self-route)',
						kind: 'panel',
						panel: 'vpn.selfroute',
						visibility: 'normal'
					},
					{
						id: 'pbrbypass',
						title: 'Матрица сетей без VPN → WAN (PBR Bypass)',
						kind: 'panel',
						panel: 'vpn.pbrbypass',
						visibility: 'normal'
					}
				]
			},
			'vpn.generators': {
				id: 'vpn.generators',
				title: 'Генераторы и импорт',
				type: 'vpn',
				vpnView: 'generators',
				visibility: 'normal',
				hint: 'Импорт конфигураций (Amnezia, WireGuard, OpenVPN) и генераторы WARP / Proton.'
			},
			'vpn.warp': {
				id: 'vpn.warp',
				title: 'Генератор WARP',
				type: 'menu',
				visibility: 'normal',
				hint: 'Настройки генератора — на экране VPN (кнопка «Настроить»). Здесь дублируются статус и generate.',
				items: [
					{ id: 'back', title: '← Назад к VPN-туннелям', kind: 'panel', panel: 'vpn.hub' },
					{ id: 'status', title: 'Показать текущие параметры', kind: 'action', action: 'warpStatus' },
					{
						id: 'generate',
						title: 'Сгенерировать конфиг',
						kind: 'action',
						action: 'warpGenerate',
						confirm: 'Сгенерировать WARP .conf с текущими параметрами?'
					},
					{ id: 'listConfs', title: 'Показать последние .conf', kind: 'action', action: 'listConfs' }
				]
			},
			'vpn.proton': {
				id: 'vpn.proton',
				title: 'Генератор Proton',
				type: 'menu',
				visibility: 'normal',
				hint: 'Настройки генератора — на экране VPN (кнопка «Настроить»).',
				items: [
					{ id: 'back', title: '← Назад к VPN-туннелям', kind: 'panel', panel: 'vpn.hub' },
					{ id: 'status', title: 'Показать текущие параметры', kind: 'action', action: 'protonStatus' },
					{
						id: 'generate',
						title: 'Сгенерировать конфиг (raw, API)',
						kind: 'action',
						action: 'protonGenerate',
						confirm: 'Сгенерировать Proton .conf через API (raw)?'
					},
					{
						id: 'importHint',
						title: 'Import --raw',
						kind: 'note',
						note: 'Import из файла/буфера пока в CLI: xft → 7 → 2 → 13.'
					},
					{ id: 'listConfs', title: 'Показать последние .conf', kind: 'action', action: 'listConfs' }
				]
			},
			'vpn.regenerate': {
				id: 'vpn.regenerate',
				title: 'Пересобрать конфиг туннеля',
				type: 'menu',
				visibility: 'normal',
				hint: 'CLI: xft → 7 → 6.',
				items: [
					{ id: 'back', title: '← Назад к VPN-туннелям', kind: 'panel', panel: 'vpn.hub' },
					{
						id: 'one',
						title: 'Выбрать интерфейс',
						kind: 'action',
						action: 'regenerateOne',
						prompt: 'iface',
						promptText: 'Имя туннеля',
						confirm: 'Пересобрать конфиг выбранного туннеля (--force)?'
					},
					{
						id: 'templates',
						title: 'Для template-интерфейсов',
						kind: 'action',
						action: 'regenerateTemplates',
						confirm: 'Пересобрать все template-туннели?'
					},
					{
						id: 'all',
						title: 'Для всех интерфейсов',
						kind: 'action',
						action: 'regenerateAll',
						confirm: 'Пересобрать все туннели профиля?'
					}
				]
			},
			'vpn.server': {
				id: 'vpn.server',
				title: 'Сервер',
				type: 'vpn',
				vpnView: 'server',
				tab: 'server',
				visibility: 'normal',
				hint: 'Управление VPN-сервером AmneziaWG (Ingress), пирами и клиентскими конфигурациями.'
			},
			'vpn.protocols': {
				id: 'vpn.protocols',
				title: 'Компоненты',
				type: 'vpn',
				vpnView: 'protocols',
				tab: 'protocols',
				visibility: 'normal',
				hint: 'Управление системными пакетами и протоколами VPN (AmneziaWG, OpenVPN, Sing-box, FreeTurn).'
			},
			'vpn.selfroute': {
				id: 'vpn.selfroute',
				title: 'Self-route',
				type: 'vpn',
				vpnView: 'selfroute',
				tab: 'selfroute',
				visibility: 'normal',
				hint: 'Каскадная маршрутизация (туннель через туннель). Направляет endpoint целевого VPN через промежуточный туннель.'
			},
			'vpn.pbrbypass': {
				id: 'vpn.pbrbypass',
				title: 'PBR Bypass',
				type: 'vpn',
				vpnView: 'pbrbypass',
				tab: 'pbrbypass',
				visibility: 'normal',
				hint: 'Policy-Based Routing: прямой выход выбранных локальных сетей в интернет через WAN в обход VPN.'
			},
			'vpn.devicepolicy': {
				id: 'vpn.devicepolicy',
				title: 'Исключения устройств',
				type: 'vpn',
				vpnView: 'devicepolicy',
				tab: 'devicepolicy',
				visibility: 'normal',
				hint: 'Прямой выход выбранных устройств (по IP или MAC) в интернет через чистый WAN в обход VPN и Zapret.'
			},
			/* Left-rail Zapret: CLI ops (install/apply/tests). Lists → routing/zapret. */
			'zapret.hub': {
				id: 'zapret.hub',
				title: 'Zapret',
				type: 'zapret',
				visibility: 'normal',
				hint: 'Операции как в CLI (xft → Обход блокировок). Выбор списков — Маршруты → Zapret.',
				items: [
					{
						id: 'listsHint',
						title: 'Списки сайтов — в Маршруты → Zapret',
						kind: 'note',
						note: 'Выбор upstream-списков для секций DPI перенесён во вкладку «Маршруты» → «Zapret».'
					},
					{
						id: 'applyLists',
						title: 'Применить списки',
						kind: 'action',
						action: 'applyLists',
						confirm: 'Применить изменённые секции Zapret (apply-changed-sections)?'
					},
					{
						id: 'testYoutube',
						title: 'Проверка: YouTube (текущие)',
						kind: 'action',
						action: 'testYoutubeCurrent'
					},
					{
						id: 'testOthers',
						title: 'Проверка: остальные (текущие)',
						kind: 'action',
						action: 'testOthersCurrent'
					},
					{
						id: 'testDpi',
						title: 'DPI: TCP 16-20 (лёгкий)',
						kind: 'action',
						action: 'testDpiTcp'
					},
					{
						id: 'strategyHint',
						title: 'Перебор стратегий (YouTube / остальные)',
						kind: 'note',
						visibility: 'normal',
						note: 'Интерактивный перебор стратегий пока только в CLI: xft → 4 → 8b / 8d.'
					},
					{
						id: 'ensure',
						title: 'Проверить/установить zapret (ensure)',
						kind: 'action',
						action: 'ensure',
						visibility: 'expert',
						confirm: 'ensure-zapret.sh --install-if-missing --upgrade-if-newer?'
					},
					{
						id: 'apply',
						title: 'Применить zapret',
						kind: 'action',
						action: 'apply',
						visibility: 'expert',
						confirm: 'Полный apply.sh --yes?'
					},
					{
						id: 'ports',
						title: 'Диагностика: конфликты портов',
						kind: 'action',
						action: 'portConflicts',
						visibility: 'expert'
					},
					{
						id: 'orderHint',
						title: 'Редактировать порядок секций',
						kind: 'note',
						visibility: 'expert',
						note: 'sections.order — в CLI (whiptail): xft → 4 → 7.'
					},
					{
						id: 'copyFake',
						title: 'Скопировать fake-файлы',
						kind: 'action',
						action: 'copyFake',
						visibility: 'expert',
						confirm: 'Скопировать fake *.bin в /opt/zapret и перезапустить zapret?'
					},
					{
						id: 'runAll',
						title: 'Выполнить всё (обновить + установить + apply)',
						subtitle: 'Обновление upstream-списков, проверка/установка бинарников zapret и полный перезапуск',
						kind: 'action',
						action: 'runAll',
						actionLabel: 'Выполнить всё',
						confirm: 'Запустить полный пайплайн Zapret (upstream + ensure + apply)?'
					}
				]
			},
			'system.resources': {
				id: 'system.resources',
				title: 'Температура и диск',
				type: 'report',
				api: 'hostResources',
				script: '/root/xfree-toolbox/system/show-host-resources.sh',
				pollInterval: 30,
				visibility: 'normal'
			},
			/* Version + update check (CLI: xft → 2 → 1). */
			'system.toolbox': {
				id: 'system.toolbox',
				title: 'Версия и обновления',
				type: 'menu',
				visibility: 'normal',
				hint: 'Локальная VERSION и проверка фида/apk (как «Проверить / обновить xfree-toolbox» в CLI).',
				statusReport: 'system.toolbox',
				pollInterval: 0,
				items: [
					{
						id: 'status',
						title: 'Показать статус',
						subtitle: 'Текущая установленная версия, хэш коммита и статус пакетов',
						kind: 'report',
						report: 'system.toolbox',
						icon: 'status',
						actionLabel: 'Показать'
					},
					{
						id: 'check',
						title: 'Проверить обновления',
						subtitle: 'Проверка наличия новых версий в репозитории и фидах пакетов',
						kind: 'action',
						action: 'checkUpdate',
						icon: 'update',
						actionLabel: 'Проверить'
					},
					{
						id: 'upgrade',
						title: 'Обновить xfree-toolbox',
						subtitle: 'Обновление утилит xfree-toolbox с сохранением пользовательских профилей',
						kind: 'action',
						action: 'upgrade',
						icon: 'update',
						actionLabel: 'Обновить',
						confirm: 'Обновить xfree-toolbox сейчас (apk upgrade / tar self-update)? Profiles сохраняются.'
					}
				]
			},
			'mgmt.status': {
				id: 'mgmt.status',
				title: 'Статус mgmt-hub',
				type: 'report',
				api: 'report',
				report: 'mgmt.status',
				script: '/root/xfree-toolbox/mgmt-hub/router/status.sh',
				pollInterval: 15,
				visibility: 'normal'
			},
			/* Full CLI mirror (uplink-monitor + diagnostics) — polish UX gradually. */
			'uplink.hub': {
				id: 'uplink.hub',
				title: 'Мониторинг канала',
				type: 'uplink',
				visibility: 'normal',
				hint: 'Статус, все параметры conf и действия — в одном экране.',
				pollInterval: 30
			},
			'diagnostics.dns': {
				id: 'diagnostics.dns',
				title: 'Диагностика DNS',
				type: 'report',
				api: 'report',
				report: 'diagnostics.dns',
				/* Poll while STATUS: running (full drill exceeds uhttpd ~60s). */
				reportStatus: 'diagnostics.dns.status',
				reportLast: 'diagnostics.dns.last',
				asyncReport: true,
				script: '/root/xfree-toolbox/diagnostics/dns-check.sh',
				/* Full drill can take minutes — do not auto-run on tab open. */
				lazy: true,
				pollInterval: 0,
				visibility: 'normal',
				descr: 'Запросы A по секциям DNS активного профиля. Долгая проверка в фоне — «Обновить», вывод подтягивается сам.'
			},
			'diagnostics.logs': {
				id: 'diagnostics.logs',
				title: 'Логи системы и фоновых задач',
				type: 'menu',
				visibility: 'normal',
				pollInterval: 0,
				hint: 'Просмотр журналов системных служб, сторожевого таймера и сетевых проверок.',
				items: [
					{
						id: 'systemLogs',
						title: 'Системный журнал (logread)',
						subtitle: 'Последние 150 строк системного журнала OpenWrt',
						kind: 'action',
						action: 'systemLogs',
						icon: 'logs',
						actionLabel: 'Показать'
					},
					{
						id: 'watchdogLogs',
						title: 'Журнал мониторинга канала (uplink-monitor)',
						subtitle: 'Журнал проверок доступности внешних хостов и сторожевого таймера',
						kind: 'action',
						action: 'watchdogLogs',
						icon: 'logs',
						actionLabel: 'Показать'
					}
				]
			},
			'diagnostics.misc.hub': {
				id: 'diagnostics.misc.hub',
				title: 'Диагностика и сервисы',
				type: 'menu',
				visibility: 'normal',
				pollInterval: 0,
				hint: 'Глубокая проверка маршрутизации туннелей, аппаратные LED-тесты, соединение с хабом и вспомогательные прокси.',
				items: [
					{
						id: 'checkRouting',
						title: 'Глубокая проверка маршрутизации туннелей',
						subtitle: 'Handshake, ICMP ping через интерфейсы, curl HTTPS и проверка правил nftables',
						kind: 'action',
						action: 'tunnelsCheck',
						icon: 'routing',
						actionLabel: 'Запустить',
						confirm: 'Запустить полную проверку iface-routing (Handshake, ping, curl, nftables)?'
					},
					{
						id: 'testDoh',
						title: 'Проверка DoH-инстансов (5060/5061 A/B)',
						subtitle: 'Тестирование доступности и задержек upstream DoH-серверов https-dns-proxy',
						kind: 'action',
						action: 'testDoh',
						icon: 'status',
						actionLabel: 'Проверить'
					},
					{
						id: 'led',
						title: 'Тест LED-индикаторов',
						subtitle: 'Поочередное мигание всеми светодиодами роутера (~5 с на лампу) для визуальной идентификации',
						kind: 'action',
						action: 'ledTest',
						icon: 'led',
						actionLabel: 'Тест LED',
						confirm: 'Мигание всех LED по очереди (~5 с на лампу), затем восстановление. Запустить?'
					},
					{
						id: 'mgmt',
						title: 'Создать соединение с хабом',
						subtitle: 'Инициализация защищенного reverse-SSH туннеля управления через XFree Hub',
						kind: 'action',
						action: 'mgmtConnect',
						icon: 'hub',
						actionLabel: 'Подключить',
						confirm: 'Запустить mgmt-hub/router/ensure-client.sh?'
					}
				]
			},
			'system.maintenance': {
				id: 'system.maintenance',
				title: 'Обслуживание и пакеты',
				type: 'menu',
				visibility: 'normal',
				hint: 'Установка базовых пакетов, обновление LuCI и ротация системных бэкапов.',
				items: [
					{
						id: 'installBase',
						title: 'Установить / обновить базовые пакеты',
						subtitle: 'Проверка и установка базовых сетевых утилит роутера (curl, jq, ip-full, kmod-*)',
						kind: 'action',
						action: 'installBase',
						icon: 'update',
						actionLabel: 'Установить',
						confirm: 'Запустить установку/обновление базовых пакетов?'
					},
					{
						id: 'installLuciRu',
						title: 'Установить русскую локализацию LuCI',
						subtitle: 'Установка пакетов luci-i18n-base-ru и перевод веб-интерфейса',
						kind: 'action',
						action: 'installLuciRu',
						icon: 'update',
						actionLabel: 'Установить',
						confirm: 'Установить русский язык для LuCI?'
					},
					{
						id: 'updateLuci',
						title: 'Обновить LuCI',
						subtitle: 'Обновление пакетов веб-интерфейса и приложения xfree-toolbox',
						kind: 'action',
						action: 'updateLuci',
						icon: 'update',
						actionLabel: 'Обновить',
						confirm: 'Обновить компоненты LuCI?'
					},
					{
						id: 'updateAll',
						title: 'Обновить все системные пакеты',
						subtitle: 'Полное обновление установленных пакетов OpenWrt (apk upgrade / opkg update)',
						kind: 'action',
						action: 'updateAll',
						icon: 'update',
						actionLabel: 'Обновить всё',
						confirm: 'Выполнить полное обновление всех установленных пакетов системы?'
					},
					{
						id: 'checkMigration',
						title: 'Проверить миграцию',
						subtitle: 'Проверка корректности структуры каталогов /etc/xfree-toolbox и состояния',
						kind: 'action',
						action: 'checkMigration',
						icon: 'status',
						actionLabel: 'Проверить'
					},
					{
						id: 'backupRotate',
						title: 'Принудительная ротация backup',
						subtitle: 'Ротация архивных копий с сохранением заданного лимита глубин',
						kind: 'action',
						action: 'backupRotate',
						icon: 'action',
						actionLabel: 'Ротация'
					},
					{
						id: 'backupCleanup',
						title: 'Чистка устаревших backup',
						subtitle: 'Удаление мусора и временных файлов бэкапов с диска роутера',
						kind: 'action',
						action: 'backupCleanup',
						icon: 'action',
						actionLabel: 'Очистить'
					},
					{
						id: 'backupPurge',
						title: 'Полная очистка backup (удалить всё)',
						subtitle: 'Полное удаление всех архивных копий для освобождения flash-памяти',
						kind: 'action',
						action: 'backupPurge',
						icon: 'action',
						actionLabel: 'Удалить всё',
						confirm: 'ВНИМАНИЕ: Безвозвратно удалить ВСЕ резервные копии из /etc/xfree-toolbox/backups?'
					}
				]
			},
			'network.mesh': {
				id: 'network.mesh',
				title: 'Беспроводная сеть и Mesh (802.11s / 802.11r)',
				type: 'custom',
				visibility: 'normal',
				hint: '802.11s mesh, быстрый роуминг 802.11r/k/v, STP и выбор роли Master / Satellite.'
			},
			'network.modem': {
				id: 'network.modem',
				title: '4G / LTE Модем',
				type: 'report',
				api: 'systemMenu',
				action: 'modemDiag',
				visibility: 'normal',
				hint: 'Диагностика USB-модемов, установка драйверов HiLink/QMI и статус интерфейсов.'
			},
			'system.mesh': {
				id: 'system.mesh',
				title: 'Беспроводная сеть и Mesh (802.11s / 802.11r)',
				type: 'menu',
				items: [
					{
						id: 'meshDiag',
						title: 'Диагностика связности Mesh / Backhaul',
						subtitle: 'Проверка связности 802.11s, STP, пиров mesh и бэкхола',
						kind: 'action',
						action: 'meshDiag',
						icon: 'status',
						actionLabel: 'Диагностика'
					},
					{
						id: 'meshRoaming',
						title: 'Выровнять бесшовный роуминг (802.11r/k/v + STP)',
						subtitle: 'Единый Mobility Domain для 2.4G и 5G, включение 802.11r/k/v без смены паролей',
						kind: 'action',
						action: 'configureMeshRoaming',
						icon: 'routing',
						actionLabel: 'Выровнять',
						confirm: 'Выровнять параметры 802.11r/k/v и STP на всех точках доступа?'
					},
					{
						id: 'meshMaster',
						title: 'Настроить этот роутер как Mesh Master',
						subtitle: 'Включение STP, 802.11r/k/v, фиксация канала 5 GHz и создание 802.11s Mesh',
						kind: 'action',
						action: 'configureMeshMaster',
						icon: 'routing',
						actionLabel: 'Настроить',
						confirm: 'Настроить этот роутер как основной узел (Mesh Master)? Существующие точки Wi-Fi сохраняются.'
					},
					{
						id: 'meshSatellite',
						title: 'Настроить этот роутер как Mesh Satellite',
						subtitle: 'Подключение сателлита: отключение DHCP/WAN, перевод LAN в мост, настройка 802.11s',
						kind: 'action',
						action: 'configureMeshSatellite',
						icon: 'routing',
						actionLabel: 'Настроить'
					},
					{
						id: 'installWpadMesh',
						title: 'Установить wpad-mesh-mbedtls (802.11s)',
						subtitle: 'Замена стандартного wpad на версию с поддержкой беспроводной Mesh-сети',
						kind: 'action',
						action: 'installWpadMesh',
						icon: 'update',
						actionLabel: 'Установить',
						confirm: 'Заменить wpad на wpad-mesh-mbedtls?'
					}
				]
			},
			'system.hardware': {
				id: 'system.hardware',
				title: 'Оборудование и периферия',
				type: 'report',
				api: 'systemMenu',
				action: 'hardwareStatus',
				visibility: 'normal',
				hint: 'Аппаратная кнопка WPS/Mesh, запись NFC и управление питанием USB.'
			},
			'system.autoupdate': {
				id: 'system.autoupdate',
				title: 'Автообновление и фид',
				type: 'menu',
				visibility: 'normal',
				hint: 'Расписание автоматических проверок обновлений и управление APK-фидом.',
				items: [
					{
						id: 'autoUpdateEnable',
						title: 'Включить фоновое автообновление',
						subtitle: 'Добавление задачи в cron для ночной проверки и установки обновлений',
						kind: 'action',
						action: 'autoUpdateEnable',
						icon: 'action',
						actionLabel: 'Включить',
						confirm: 'Включить ежедневное автообновление по cron?'
					},
					{
						id: 'autoUpdateDisable',
						title: 'Выключить автообновление',
						subtitle: 'Удаление задачи автообновления из системного cron',
						kind: 'action',
						action: 'autoUpdateDisable',
						icon: 'action',
						actionLabel: 'Выключить'
					},
					{
						id: 'apkFeedEnable',
						title: 'Включить APK-фид xfree',
						subtitle: 'Подключение официального репозитория пакетов xfree в /etc/apk/repositories.d',
						kind: 'action',
						action: 'apkFeedEnable',
						icon: 'action',
						actionLabel: 'Включить'
					},
					{
						id: 'apkFeedDisable',
						title: 'Выключить APK-фид xfree',
						subtitle: 'Отключение внешнего репозитория пакетов xfree',
						kind: 'action',
						action: 'apkFeedDisable',
						icon: 'action',
						actionLabel: 'Выключить'
					}
				]
			},
		},
		overviewCards: [
			{
				id: 'profiles',
				route: 'profiles',
				title: 'Профили',
				sub: 'Шаблоны → профиль → apply',
				chip: 'templates',
				primary: { label: 'Открыть', route: 'profiles' },
				secondary: { label: 'Обновить', route: 'profiles', panel: 'templates.sync' }
			},
			{
				id: 'routing',
				route: 'routing',
				title: 'Маршруты',
				sub: 'Общее + отдельно VPN / DNS / Zapret / Исключения',
				chips: ['общее', 'vpn', 'dns', 'zapret', 'exclude'],
				actions: [
					{ label: 'Общее', route: 'routing', tab: 'general' },
					{ label: 'VPN', route: 'routing', tab: 'vpn' },
					{ label: 'DNS', route: 'routing', tab: 'dns' },
					{ label: 'Zapret', route: 'routing', tab: 'zapret' },
					{ label: 'Исключения', route: 'routing', tab: 'exclude' }
				]
			},
			{
				id: 'vpn',
				route: 'vpn',
				title: 'VPN-туннели',
				sub: 'Создать / применить / генераторы — как в CLI',
				chips: ['warp', 'proton', 'apply'],
				actions: [
					{ label: 'Открыть', route: 'vpn' },
					{ label: 'Списки', route: 'routing', tab: 'general' }
				]
			},
			{
				id: 'diagnostics',
				route: 'diagnostics',
				title: 'Диагностика',
				sub: 'Канал, туннели, DNS — полное меню',
				chip: 'check',
				chips: ['uplink', 'dns'],
				primary: { label: 'Канал', route: 'diagnostics', panel: 'uplink.hub' },
				secondary: { label: 'DNS', route: 'diagnostics', panel: 'diagnostics.dns' }
			},
			{
				id: 'system',
				route: 'system',
				title: 'Система',
				sub: 'Ресурсы, версия и обновления',
				chip: 'host',
				actions: [
					{ label: 'Ресурсы', route: 'system', panel: 'system.resources' },
					{ label: 'Обновления', route: 'system', panel: 'system.toolbox' },
					{ label: 'Хаб', route: 'system', panel: 'mgmt.status' }
				]
			}
		]
	},

	ROUTE_ALIASES: {
		'mesh': 'network'
	},

	PANEL_ALIASES: {
		'system.mesh': 'network.mesh',
		'diagnostics.tunnels': 'uplink.hub',
		'uplink.tunnels.hub': 'uplink.hub',
		'diagnostics.uplink': 'uplink.hub'
	},

	_routeMap: null,
	_routeIndex: null,

	_ensureIndex: function() {
		if (this._routeIndex)
			return;

		this._routeMap = Object.create(null);
		this._routeIndex = Object.create(null);

		var routes = (this.data && this.data.routes) || [];
		for (var i = 0; i < routes.length; i++) {
			var r = routes[i];
			if (!r || !r.id)
				continue;

			this._routeMap[r.id] = r;

			var tabs = r.tabs || [];
			var defaultPanel = tabs.length ? (tabs[0].panel || tabs[0].id || '') : '';
			var tokens = Object.create(null);
			var normTokens = Object.create(null);

			for (var j = 0; j < tabs.length; j++) {
				var t = tabs[j];
				var target = t.panel || t.id || t.tab || '';
				if (!target)
					continue;

				if (t.id) tokens[t.id] = target;
				if (t.panel) tokens[t.panel] = target;
				if (t.tab) tokens[t.tab] = target;

				if (t.id) normTokens[t.id.toLowerCase().replace(/[-_.]/g, '')] = target;
				if (t.panel) normTokens[t.panel.toLowerCase().replace(/[-_.]/g, '')] = target;
				if (t.tab) normTokens[t.tab.toLowerCase().replace(/[-_.]/g, '')] = target;
			}

			this._routeIndex[r.id] = {
				defaultPanel: defaultPanel,
				tokens: tokens,
				normTokens: normTokens
			};
		}
	},

	findRoute: function(routeId) {
		this._ensureIndex();
		routeId = this.ROUTE_ALIASES[routeId] || routeId;
		return this._routeMap[routeId] || null;
	},

	findPanel: function(panelId) {
		return (this.data && this.data.panels && this.data.panels[panelId]) || null;
	},

	resolvePanel: function(routeId, parts) {
		this._ensureIndex();
		parts = parts || {};
		var hint = (typeof parts === 'string') ? parts : (parts.panel || parts.tab || '');
		routeId = this.ROUTE_ALIASES[routeId] || routeId;

		if (this.PANEL_ALIASES[hint])
			return this.PANEL_ALIASES[hint];

		if (hint && this.data && this.data.panels && this.data.panels[hint])
			return hint;

		var idx = this._routeIndex[routeId];
		if (idx) {
			if (hint) {
				if (idx.tokens[hint])
					return idx.tokens[hint];
				var cleanHint = hint.toLowerCase().replace(/[-_.]/g, '');
				if (idx.normTokens[cleanHint])
					return idx.normTokens[cleanHint];
			}
			if (idx.defaultPanel)
				return idx.defaultPanel;
		}

		return hint;
	}
});
