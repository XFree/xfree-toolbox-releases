'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.core.rpc-client as rpcClient';

return baseclass.extend({
	getXui: function() {
		return (this._spec && this._spec.xui) ||
			(this._spec && this._spec.view && this._spec.view.xui) ||
			window.xfreeLuciUi;
	},

	mount: function(spec) {
		this._spec = spec || {};
		this._modules = [];
		this._loading = true;
		this._error = '';
		this.requestPaint();
		this.loadCatalog();
	},

	loadCatalog: function(force) {
		var self = this;
		var xui = self.getXui();
		self._loading = true;
		self._error = '';
		self.requestPaint();

		if (!xui || !xui.systemMenu || !xui.normalizeReportResult) {
			self._loading = false;
			self._error = _('Не удалось подключить интерфейс управления xfree');
			self.requestPaint();
			return;
		}

		/* Чтение каталога кэшируется. Мутации остаются на runSystemMenu и зовут reload(force). */
		return rpcClient.request(xui.systemMenu, ['upstreamsCatalog', '', ''], {
			ttl: rpcClient.TTL_SHORT,
			force: !!force,
			key: 'xfree-toolbox:systemMenu:upstreamsCatalog'
		}).then(function(res) {
			return xui.normalizeReportResult(res, 'systemMenu');
		}).catch(function(err) {
			return xui.normalizeReportResult(null, 'systemMenu', err);
		}).then(function(res) {
			self._loading = false;
			self._modules = (res && res.modules) || [];
			self.requestPaint();
		}).catch(function(err) {
			self._loading = false;
			self._error = (err && err.message) ? err.message : String(err);
			self.requestPaint();
		});
	},

	reload: function() {
		rpcClient.invalidate('xfree-toolbox:systemMenu:upstreamsCatalog');
		this.loadCatalog(true);
	},

	_runBgAction: function(title, taskName, onFinish) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var dlg = xui.openExecOutputDialog(title);
		dlg.setStatus(_('Запуск задачи…'));
		dlg.setText(_('Инициализация…'));

		xui.runSystemMenu('upstreamsStartBg', taskName).then(function(res) {
			if (res && res.error) {
				dlg.setText(res.error);
				dlg.setDone(false);
				return;
			}

			dlg.setStatus(_('Выполняется в фоне…'));
			if (res && res.stdout)
				dlg.setText(res.stdout);

			var pollTimer = setInterval(function() {
				xui.runSystemMenu('upstreamsBgStatus').then(function(st) {
					if (!st) return;
					if (st.stdout)
						dlg.setText(st.stdout);

					if (st.running === 0) {
						clearInterval(pollTimer);
						pollTimer = null;
						var ok = (st.exitCode === '0' || st.exitCode === 0);
						dlg.setDone(ok);
						self.reload();
						if (typeof onFinish === 'function')
							onFinish(ok);
					}
				}).catch(function(err) {
					clearInterval(pollTimer);
					pollTimer = null;
					dlg.appendText('\n' + _('Ошибка опроса статуса: %s').format(err.message || String(err)));
					dlg.setDone(false);
				});
			}, 1000);
		}).catch(function(err) {
			dlg.setText(err && err.message ? err.message : String(err));
			dlg.setDone(false);
		});
	},

	_toggleModule: function(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;
		var nextState = (mod.enabled === 1) ? '0' : '1';

		xui.runSystemMenu('upstreamsToggle', modKey, nextState).then(function(res) {
			if (res && res.error) {
				ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
				return;
			}
			self.reload();
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
		});
	},

	_deleteCustomModule: function(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;

		xui.confirm({
			title: _('Удаление источника'),
			message: _('Безвозвратно удалить пользовательский источник «%s»?').format(mod.title || modKey),
			detail: _('Каталог upstreams/%s будет удален. Списки перестанут быть доступны.').format(modKey),
			tone: 'danger',
			confirmText: _('Удалить'),
			cancelText: _('Отмена')
		}).then(function(confirmed) {
			if (!confirmed) return;
			xui.runSystemMenu('upstreamsDeleteCustom', modKey).then(function(res) {
				if (res && res.error) {
					ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
					return;
				}
				ui.addNotification(null, E('p', {}, [ _('Источник «%s» удален').format(mod.title || modKey) ]), 'info');
				self.reload();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
			});
		});
	}
});
