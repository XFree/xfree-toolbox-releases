'use strict';
'require baseclass';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.vpn-server-format as serverFormat';

var copyToClipboard = serverFormat.copyToClipboard;

/* Карточка FreeTurn. Метод вешается на прототип xfree-vpn-server. */

return baseclass.extend({
	_renderFreeTurnCard: function (awg, view) {
		var self = this;
		// Card 3: FreeTurn Proxy (Next-gen transport)
		var freeTurnPortShow = awg.freeTurnPort || '56000';
		var freeTurnCard;

		if (!awg.freeTurnInstalled) {
			freeTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [_('FreeTurn Proxy (Транспорт)')]),
						xui.helpBtn({
							title: _('FreeTurn Proxy'),
							desc: _('Современный UDP-транспорт нового поколения (протокол v4), маскирующий туннельный трафик AmneziaWG под RTP/Opus медиа-звонки с профилем rtpopus3 и 64-символьным ключом шифрования.'),
							whatDoes: _('Позволяет обходить блокировки WireGuard/AWG операторами связи (включая жесткие белые списки мобильных операторов). Принимает трафик на порту 56000/UDP и пересылает на локальный порт 51820 awg_ingress.'),
							tips: _('Устанавливается нажатием одной кнопки. При установке автоматически скачивается бинарник под процессор вашего роутера, создаётся ключ обфускации, настраивается Firewall и безопасно отключается старый vk-turn.')
						}),
						E('span', { 'class': 'muted' }, [_('UDP 56000')])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: _('НЕ УСТАНОВЛЕН') })
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 12px 0;' }, [
					E('p', { 'style': 'margin: 0; font-size: 13px;' }, [
						_('FreeTurn — современный преемник VK-Turn с протоколом v4 и обфускацией rtpopus3 под голосовой трафик.')
					]),
					E('div', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
						_('На роутере пока не установлен. Нажмите кнопку ниже для автоматической загрузки бинарника с GitHub и первоначальной настройки.')
					])
				]),
				E('div', { 'class': 'xfree-vpn-server-actions' }, [
					E('div', { 'class': 'xfree-vpn-actions-group' }, [
						xcmp.button({
							variant: 'vpn',
							primary: true,
							extraClass: 'is-primary',
							title: _('Установить и запустить FreeTurn прокси «под ключ»'),
							text: '📥 ' + _('Установить FreeTurn'),
							onClick: function (ev) {
								self._act(ev, 'freeTurnSetup', '', {
									title: _('Установка FreeTurn прокси'),
									message: _('Установить и запустить FreeTurn прокси на порту %s?').format(freeTurnPortShow),
									detail: _('Будет скачан бинарник free-turn-proxy с GitHub под процессор роутера, сгенерирован 64-hex ключ obf.key, создан procd сервис /etc/init.d/free-turn, настроен Firewall и корректно отключён устаревший vk-turn.'),
									confirmText: _('Установить'),
									tone: 'primary',
									icon: '📥'
								});
							}
						})
					])
				])
			]);
		} else {
			var freeTurnParamsRows = [
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('входящий порт')]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:8px;' }, [
						E('strong', {}, ['0.0.0.0:' + freeTurnPortShow + ' (UDP)']),
						'WAN ➔ Router',
						xcmp.button({
							variant: 'vpn',
							primary: true,
							style: 'padding: 2px 8px; font-size: 11px;',
							title: _('Изменить внешний порт FreeTurn'),
							text: '✏️ ' + _('Изменить'),
							onClick: function (ev) {
								ev.preventDefault();
								self._openFreeTurnConfigDialog(awg);
							}
						})
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('целевой порт (AWG)')]),
					E('span', {}, [
						E('strong', {}, ['127.0.0.1:' + (awg.port || '51820')]),
						' (' + (awg.iface || 'awg_ingress') + ')'
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('обфускация')]),
					E('span', {}, [
						E('strong', {}, [awg.freeTurnObfProfile || 'rtpopus3']),
						' ' + _('(маскировка под голосовой трафик)')
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('ключ обфускации')]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px; font-family:monospace;' }, [
						E('span', { 'title': awg.freeTurnObfKey || '' }, [
							awg.freeTurnObfKey ? (awg.freeTurnObfKey.slice(0, 14) + '…' + awg.freeTurnObfKey.slice(-10)) : '—'
						]),
						awg.freeTurnObfKey ? xcmp.button({
							variant: 'vpn',
							primary: true,
							style: 'padding: 2px 6px; font-size: 11px;',
							title: _('Скопировать ключ обфускации'),
							text: _('Копировать'),
							onClick: function (ev) { copyToClipboard(awg.freeTurnObfKey, ev.target); }
						}) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('статус сервиса')]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
						E('span', { 'class': 'xfree-vpn-badge is-' + (awg.freeTurnRunning ? 'ok' : 'bad') }, [
							awg.freeTurnRunning ? _('работает') : _('остановлен')
						]),
						E('span', {}, [
							awg.freeTurnRunning
								? _('Служба /etc/init.d/free-turn работает (PID активен)')
								: _('Служба /etc/init.d/free-turn остановлена')
						])
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('firewall')]),
					E('span', {}, [
						awg.freeTurnRunning
							? _('Входящий UDP %s разрешён (WAN ➔ Router)').format(freeTurnPortShow)
							: _('Входящий UDP %s (настроен в Firewall)').format(freeTurnPortShow)
					])
				])
			];

			var freeTurnActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
				E('div', { 'class': 'xfree-vpn-actions-group' }, [
					awg.freeTurnRunning ? xcmp.button({
						variant: 'vpn',
						primary: true,
						title: _('Перезапустить службу FreeTurn'),
						text: '🔄 ' + _('Перезапустить'),
						onClick: function (ev) {
							self._act(ev, 'freeTurnRestart', '', {
								title: _('Перезапуск FreeTurn'),
								message: _('Перезапустить службу FreeTurn прокси?'),
								detail: _('Служба /etc/init.d/free-turn будет перезапущена с текущими параметрами.'),
								confirmText: _('Перезапустить'),
								tone: 'primary',
								icon: '🔄'
							});
						}
					}) : xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'is-primary',
						title: _('Запустить службу FreeTurn'),
						text: '▶️ ' + _('Запустить'),
						onClick: function (ev) {
							self._act(ev, 'freeTurnRestart', '', {
								title: _('Запуск FreeTurn'),
								message: _('Запустить службу FreeTurn прокси на порту %s?').format(freeTurnPortShow),
								detail: _('Служба /etc/init.d/free-turn будет запущена.'),
								confirmText: _('Запустить'),
								tone: 'primary',
								icon: '▶️'
							});
						}
					}),

					awg.freeTurnRunning ? xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'is-stop',
						title: _('Остановить службу FreeTurn прокси'),
						text: '⏹️ ' + _('Остановить'),
						onClick: function (ev) {
							self._act(ev, 'freeTurnStop', '', {
								title: _('Остановка FreeTurn'),
								message: _('Остановить службу FreeTurn прокси?'),
								detail: _('Служба /etc/init.d/free-turn будет остановлена, порт %s освобождён. Клиенты через FreeTurn временно потеряют связь.').format(freeTurnPortShow),
								confirmText: _('Остановить'),
								tone: 'danger',
								icon: '⏹️'
							});
						}
					}) : '',

					xcmp.button({
						variant: 'vpn',
						primary: true,
						title: _('Настроить внешний порт и параметры службы FreeTurn'),
						text: '⚙️ ' + _('Настроить сервер'),
						onClick: function (ev) {
							ev.preventDefault();
							self._openFreeTurnConfigDialog(awg);
						}
					}),

					xcmp.button({
						variant: 'vpn',
						primary: true,
						title: _('Проверить и обновить бинарник FreeTurn'),
						text: '⬆️ ' + _('Обновить'),
						onClick: function (ev) {
							self._act(ev, 'freeTurnUpdate', '', {
								title: _('Обновление FreeTurn'),
								message: _('Обновить бинарник FreeTurn до последней версии?'),
								detail: _('Будет проверен и скачан свежий бинарник free-turn-proxy с GitHub.'),
								confirmText: _('Обновить'),
								tone: 'primary',
								icon: '⬆️'
							});
						}
					})
				]),
				E('div', { 'class': 'xfree-vpn-actions-group is-danger' }, [
					xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'is-bad',
						title: _('Полностью удалить FreeTurn с роутера (служба, бинарник, firewall)'),
						text: '🗑️ ' + _('Удалить FreeTurn'),
						onClick: function (ev) {
							self._act(ev, 'freeTurnUninstall', '', {
								title: _('Удаление FreeTurn'),
								message: _('Полностью удалить FreeTurn прокси с роутера?'),
								detail: _('Служба /etc/init.d/free-turn будет остановлена и удалена, бинарник /opt/free-turn-proxy и ключ удалены, порт %s закрыт в Firewall.').format(freeTurnPortShow),
								confirmText: _('Да, удалить FreeTurn'),
								tone: 'danger',
								icon: '🗑️'
							});
						}
					})
				])
			]);

			freeTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [_('FreeTurn Proxy (Транспорт)')]),
						xui.helpBtn({
							title: _('FreeTurn Proxy'),
							desc: _('Современный UDP-транспорт нового поколения (протокол v4), маскирующий туннельный трафик AmneziaWG под RTP/Opus медиа-звонки с профилем rtpopus3 и 64-символьным ключом шифрования.'),
							whatDoes: _('Позволяет обходить блокировки WireGuard/AWG операторами связи (включая жесткие белые списки мобильных операторов). Принимает трафик на порту %s/UDP и пересылает на локальный порт 51820 awg_ingress.').format(freeTurnPortShow),
							tips: _('Для подключения используйте клиент FreeTurn на телефоне (turn-proxy-android) или роутере.')
						}),
						xcmp.button({
							variant: 'vpn',
							style: 'padding: 1px 6px; font-size: 11px; margin-left: 2px;',
							title: _('Изменить внешний порт FreeTurn'),
							text: 'UDP ' + freeTurnPortShow + ' ✏️',
							onClick: function (ev) {
								ev.preventDefault();
								self._openFreeTurnConfigDialog(awg);
							}
						}),
						E('span', { 'class': 'muted' }, ['➔ 127.0.0.1:' + (awg.port || '51820')])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						xcmp.badge({
							variant: 'vpn-status',
							tone: awg.freeTurnRunning ? 'ok' : 'bad',
							text: awg.freeTurnRunning ? _('ПРОКСИ АКТИВЕН') : _('ОСТАНОВЛЕН')
						}),
						awg.freeTurnVersion ? xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: awg.freeTurnVersion }) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, freeTurnParamsRows),
				freeTurnActions
			]);
		}
		return freeTurnCard;
	}
});
