'use strict';
'require baseclass';

/* Разбор текстового отчёта диагностики DNS (dns-check.sh / syslog).
 * Методы вешаются на прототип xfree-report. */

function parseDnsReport(text) {
	var lines = (text || '').split(/\r?\n/);
	var status = 'idle';
	var stamp = '';
	var primary = '';
	var summaryText = '';
	var sections = [];
	var curSec = null;
	var i;
	var line;
	var m;

	for (i = 0; i < lines.length; i++) {
		line = lines[i];
		if ((m = line.match(/^STATUS:\s*([a-z-]+)/))) {
			status = m[1];
		} else if ((m = line.match(/^=== Диагностика DNS\s+([^=]+)\s*===/))) {
			stamp = m[1].trim();
		} else if ((m = line.match(/^Основной DNS[^:]*:\s*(.+)$/))) {
			primary = m[1].trim();
		} else if ((m = line.match(/^\[\*\]\s*Итог проверки:\s*(.+)$/))) {
			summaryText = m[1].trim();
		} else if ((m = line.match(/^Секция\s+(.+)$/))) {
			if (curSec)
				sections.push(curSec);
			var secLine = m[1];
			var isPrim = /\[основной\]/.test(secLine);
			secLine = secLine.replace(/\[основной\]/, '').trim();
			var parts = secLine.split(/\s+/);
			var target = parts.length > 1 ? parts[parts.length - 1] : '';
			var label = parts.length > 1 ? parts.slice(0, parts.length - 1).join(' ') : secLine;
			curSec = {
				label: label,
				target: target,
				isPrimary: isPrim,
				hosts: [],
				okCount: 0,
				failCount: 0,
				minMs: 999999,
				maxMs: 0
			};
		} else if (curSec && (m = line.match(/^\s+([A-Za-z0-9_.-]+)\s+(OK|FAIL)\s+([A-Za-z0-9_?-]+)\s+(\d+)ms\s+A=(.+)$/))) {
			var ok = m[2] === 'OK';
			var ms = parseInt(m[4], 10);
			var hostEntry = {
				host: m[1],
				ok: ok,
				rcode: m[3],
				ms: ms,
				ip: m[5].trim()
			};
			curSec.hosts.push(hostEntry);
			if (ok) curSec.okCount++; else curSec.failCount++;
			if (ms < curSec.minMs) curSec.minMs = ms;
			if (ms > curSec.maxMs) curSec.maxMs = ms;
		}
	}
	if (curSec)
		sections.push(curSec);

	var totalOk = 0;
	var totalFail = 0;
	var overallMin = 999999;
	var overallMax = 0;

	for (i = 0; i < sections.length; i++) {
		totalOk += sections[i].okCount;
		totalFail += sections[i].failCount;
		if (sections[i].minMs === 999999)
			sections[i].minMs = 0;
		if (sections[i].minMs < overallMin)
			overallMin = sections[i].minMs;
		if (sections[i].maxMs > overallMax)
			overallMax = sections[i].maxMs;
	}
	if (overallMin === 999999)
		overallMin = 0;

	return {
		status: status,
		stamp: stamp,
		primary: primary,
		summaryText: summaryText,
		totalOk: totalOk,
		totalFail: totalFail,
		totalQueries: totalOk + totalFail,
		minMs: overallMin,
		maxMs: overallMax,
		sections: sections
	};
}

return baseclass.extend({
	_parseDnsReport: function (text) {
		return parseDnsReport(text);
	}
});
