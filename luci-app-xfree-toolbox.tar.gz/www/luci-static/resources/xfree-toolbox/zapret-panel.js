'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.zapret-strategy-dialog as zapretDialog';
'require xfree-toolbox.zapret-cards as zapretCards';
'require xfree-toolbox.zapret-view as zapretView';

var TAG = 'xfree-zapret';

var ZapretPanel = class extends wc.LightElement {
};

function mixZapret(part) {
	prototypeMix.mixInto(ZapretPanel.prototype, part);
}

mixZapret(zapretDialog);
mixZapret(zapretCards);
mixZapret(zapretView);

wc.define(TAG, ZapretPanel);

return baseclass.extend({
	tag: TAG
});
