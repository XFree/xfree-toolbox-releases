'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.luci-ui as xui';

var TAG = 'xfree-zapret';

function sectionIcon(name) {
	var n = String(name || '').toLowerCase();
	if (n.indexOf('youtube') >= 0) return '🎬';
	if (n.indexOf('discord') >= 0) return '💬';
	if (n.indexOf('telegram') >= 0) return '✈️';
	if (n.indexOf('fb') >= 0 || n.indexOf('wa') >= 0) return '📱';
	if (n.indexOf('roblox') >= 0) return '🎮';
	if (n.indexOf('dns') >= 0 || n.indexOf('dot') >= 0 || n.indexOf('tls') >= 0) return '🛡️';
	if (n.indexOf('cdn') >= 0) return '⚡';
	if (n.indexOf('user') >= 0 || n.indexOf('cust') >= 0) return '👤';
	return '📑';
}

wc.define(TAG, class extends wc.LightElement {
	_prepareSections(sections) {
		if (!sections || !sections.length) return [];
		var active = [];
		var inactive = [];
		for (var i = 0; i < sections.length; i++) {
			var s = sections[i];
			if (s.enabled)
				active.push(s);
			else
				inactive.push(s);
		}
		return active.concat(inactive);
	}

	mount(spec) {
		this._spec = spec || {};
		this._status = (spec && spec.status) || {
			running: false,
			installed: false,
			version: '',
			engine: 'zapret',
			pending: false,
			sections: []
		};
		this._displaySections = this._prepareSections(this._status.sections);
		this._busy = !!(spec && spec.busy);
		this._msg = (spec && spec.message) || '';
		this._msgTone = (spec && spec.messageTone) || '';
		this.setAttribute('data-xfree-zapret', '1');
		this.requestPaint();
	}

	setLoading(loading) {
		this._loading = !!loading;
		this.requestPaint();
	}

	setStatus(status) {
		this._status = status || {};
		this._status.loaded = true;
		this._loading = false;
		this._displaySections = this._prepareSections(this._status.sections);
		this.requestPaint();
	}

	setBusy(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button').forEach(function(el) {
			el.disabled = !!busy;
		});
		this.requestPaint();
	}

	setMessage(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		this.requestPaint();
	}

	_act(ev, action, arg, confirmText) {
		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}
		var s = this._spec || {};
		if (s.onAction)
			s.onAction(action, arg || '', confirmText || '');
	}

	_openStrategyDialog(secName) {
		var self = this;
		var st = this._status || {};

		var dialogContent = E('div', { 'class': 'xfree-dialog-body xfree-strategy-dialog', 'style': 'min-width: 480px; max-width: 720px;' }, [
			E('p', { 'class': 'xfree-dialog-hint muted' }, [
				_('Загрузка параметров стратегии секции «%s»…').format(secName)
			])
		]);

		var saveBtn = E('button', {
			'class': 'btn primary',
			'type': 'button',
			'disabled': 'disabled'
		}, [ '💾 ' + _('Сохранить стратегию') ]);

		var cancelBtn = E('button', {
			'class': 'btn secondary',
			'type': 'button',
			'click': function() {
				ui.hideModal();
			}
		}, [ _('Закрыть') ]);

		ui.showModal('⚙️ ' + _('Стратегия секции: %s').format(secName), [
			dialogContent,
			E('div', { 'class': 'xfree-dialog-actions', 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 14px;' }, [
				cancelBtn,
				saveBtn
			])
		]);

		xui.runZapretMenu('getStrategy', secName).then(function(res) {
			var strategyText = (res && (res.stdout || res.text)) || '';
			var ta = E('textarea', {
				'class': 'xfree-strategy-editor',
				'spellcheck': 'false',
				'rows': '13',
				'style': 'width: 100%; min-height: 240px; font-family: monospace; font-size: 12px; line-height: 1.45; padding: 10px; border-radius: 8px; border: 1px solid var(--line); background: var(--panel-2); color: var(--text); resize: vertical; box-sizing: border-box;'
			}, [ strategyText ]);

			saveBtn.removeAttribute('disabled');
			saveBtn.addEventListener('click', function() {
				var newContent = String(ta.value || '').trim();
				saveBtn.disabled = true;
				saveBtn.textContent = '⏳ ' + _('Сохранение…');
				xui.runZapretMenu('saveStrategy', secName, newContent).then(function() {
					ui.hideModal();
					st.pending = true;
					self.setMessage(
						_('Стратегия секции «%s» сохранена. Для применения нажмите «⚡ Применить списки».')
							.format(secName),
						'warn'
					);
					self.requestPaint();
				}).catch(function(err) {
					saveBtn.disabled = false;
					saveBtn.textContent = '💾 ' + _('Сохранить стратегию');
					ui.addNotification(null, E('p', {}, [
						_('Ошибка сохранения стратегии: %s').format(err && err.message || err)
					]), 'danger');
				});
			});

			dialogContent.replaceChildren(
				E('div', { 'style': 'margin-bottom: 8px;' }, [
					E('p', { 'class': 'muted', 'style': 'font-size: 12px; margin: 0 0 6px 0;' }, [
						_('Параметры десинхронизации NFQWS (файл config/section.text). Допускаются флаги --dpi-desync, --filter-tcp/udp, {{SELECT_LIST}} и др.')
					]),
					E('div', { 'style': 'display: flex; gap: 6px; align-items: center; margin-bottom: 8px;' }, [
						E('span', { 'class': 'xfree-vpn-status is-muted', 'style': 'font-size: 11px;' }, [ _('Синтаксис: nfqws1') ]),
						E('span', { 'class': 'muted', 'style': 'font-size: 11px; margin-left: auto;' }, [ _('Секция: %s').format(secName) ])
					])
				]),
				ta
			);
		}).catch(function(err) {
			dialogContent.replaceChildren(
				E('div', { 'class': 'alert-message danger' }, [
					_('Не удалось загрузить стратегию: %s').format(err && err.message || err)
				])
			);
		});
	}

	render() {
		var self = this;
		var s = this._spec || {};
		var view = s.view;
		var expert = !!(s.expert);
		var st = this._status || {};
		var sections = this._displaySections || st.sections || [];
		var nodes = [];

		this.className = 'xfree-vpn-wrap xfree-zapret-wrap';

		/* 1. Page Header */
		var isRefreshing = !!(this._loading || this._busy);
		var headActions = [
			E('button', {
				'class': 'ghost ghost-compact' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние Zapret'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				}
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить'))
			]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'title': _('Перейти к выбору списков доменов для Zapret в разделе «Маршруты»'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onNavigate)
						s.onNavigate('routing', 'zapret');
					else if (view && view.navigate)
						view.navigate('routing', 'zapret');
				}
			}, [ '📋 ' + _('Списки') ]),
			E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'title': _('Применить изменённые списки Zapret в runtime'),
				'click': function(ev) {
					self._act(ev, 'applyLists', '',
						_('Применить изменённые секции Zapret (apply-changed-sections)?'));
				}
			}, [ '⚡ ' + _('Применить списки') ])
		];

		nodes.push(E('div', { 'class': 'page-head' }, [
			E('div', { 'class': 'page-head-main' }, [
				E('p', { 'class': 'eyebrow' }, [ 'XFree toolbox' ]),
				E('h1', {}, [
					_('Zapret'),
					E('span', {
						'class': 'xfree-vpn-status is-' + (st.running ? 'ok' : (st.installed ? 'bad' : 'warn')),
						'style': 'margin-left: 10px; font-size: 13px; font-weight: normal; vertical-align: middle;'
					}, [ st.running ? _('Активен') : (st.installed ? _('Остановлен') : _('Не установлен')) ])
				])
			]),
			E('div', { 'class': 'page-head-actions', 'style': 'display:flex; align-items:center; gap:8px;' }, [
				E('p', { 'class': 'muted page-head-desc' }, [
					_('Обход блокировок и замедлений (nfqws/tpws)')
				]),
				E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, headActions)
			])
		]));

		/* Alert / Banner */
		if (this._msg) {
			nodes.push(E('div', {
				'class': 'alert-message ' + (this._msgTone === 'ok' ? 'success' : (this._msgTone === 'warn' ? 'warning' : 'danger')),
				'style': 'margin-bottom: 12px;'
			}, [ this._msg ]));
		}

		/* 2. Top Metric Plaques */
		var activeCount = 0;
		for (var i = 0; i < sections.length; i++) {
			if (sections[i].enabled) activeCount++;
		}

		var chips = [];
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (st.running ? 'ok' : 'bad') }, [
			E('span', { 'class': 'k' }, [ _('Служба') ]),
			E('span', { 'class': 'v' }, [ st.running ? _('работает') : _('остановлена') ])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip' }, [
			E('span', { 'class': 'k' }, [ _('Движок') ]),
			E('span', { 'class': 'v' }, [ st.engine || 'nfqws' ])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip' }, [
			E('span', { 'class': 'k' }, [ _('Версия') ]),
			E('span', { 'class': 'v' }, [ st.version || '—' ])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip' }, [
			E('span', { 'class': 'k' }, [ _('Секции') ]),
			E('span', { 'class': 'v' }, [ '%d / %d активны'.format(activeCount, sections.length) ])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (st.pending ? 'warn' : 'ok') }, [
			E('span', { 'class': 'k' }, [ _('Списки') ]),
			E('span', { 'class': 'v' }, [ st.pending ? _('есть изменения *') : _('актуальны') ])
		]));

		nodes.push(E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips));

		/* 3. Section: Управление и применение */
		nodes.push(E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '⚙️ ' + _('Управление службой и списками') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Runtime ops') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Применение списков пересобирает правила DPI на лету. Полный apply выполняет генерацию и перезапуск всех секций.')
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'padding: 8px 0;' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function(ev) {
						self._act(ev, 'applyLists', '',
							_('Применить изменённые секции Zapret (apply-changed-sections)?'));
					}
				}, [ '⚡ ' + _('Применить списки') ]),
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'click': function(ev) {
						self._act(ev, 'runAll', '',
							_('Выполнить полный пайплайн Zapret (обновить upstream + ensure + apply)?'));
					}
				}, [ '🚀 ' + _('Выполнить всё') ]),
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'click': function(ev) {
						self._act(ev, 'apply', '',
							_('Выполнить полный перезапуск и применение zapret (apply.sh --yes)?'));
					}
				}, [ '🔄 ' + _('Применить Zapret') ]),
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'click': function(ev) {
						self._act(ev, 'restart', '',
							_('Перезапустить службу Zapret?'));
					}
				}, [ '🔁 ' + _('Перезапустить службу') ]),
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'click': function(ev) {
						ev.preventDefault();
						if (s.onNavigate)
							s.onNavigate('routing', 'zapret');
						else if (view && view.navigate)
							view.navigate('routing', 'zapret');
					}
				}, [ '📋 ' + _('Настроить списки') ]),
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'click': function(ev) {
						self._act(ev, 'ensure', '',
							_('Проверить и установить/обновить бинарники zapret (ensure)?'));
					}
				}, [ '📦 ' + _('Проверить / обновить') ])
			])
		]));

		/* 4. Section: Диагностика и проверка стратегий */
		var testCards = [
			{
				icon: '🎬',
				title: _('YouTube'),
				desc: _('Проверка доступности видеопотоков, googlevideo CDN и интерфейса YouTube через текущую стратегию.'),
				action: 'testYoutubeCurrent',
				btn: _('Проверить YouTube')
			},
			{
				icon: '🌐',
				title: _('Остальные сервисы'),
				desc: _('Проверка доступности Discord, Telegram, соцсетей и прочих заблокированных сайтов.'),
				action: 'testOthersCurrent',
				btn: _('Проверить остальные')
			},
			{
				icon: '⚡',
				title: _('DPI: TCP 16-20'),
				desc: _('Быстрый лёгкий тест обхода DPI с размером окна TCP 16-20 (экспресс-проверка).'),
				action: 'testDpiTcp',
				btn: _('Тест TCP 16-20')
			},
			{
				icon: '🛡️',
				title: _('Конфликты портов'),
				desc: _('Проверка пересечения портов nfqws с правилами port forwarding и локальными сервисами роутера.'),
				action: 'portConflicts',
				btn: _('Проверить порты')
			}
		];

		var testGrid = testCards.map(function(tc) {
			return E('div', { 'class': 'xfree-zapret-test-card' }, [
				E('div', { 'class': 'xfree-zapret-card-top' }, [
					E('span', { 'class': 'xfree-zapret-card-ico' }, [ tc.icon ]),
					E('strong', {}, [ tc.title ])
				]),
				E('p', { 'class': 'muted xfree-zapret-card-desc' }, [ tc.desc ]),
				E('div', { 'class': 'xfree-zapret-card-action' }, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function(ev) {
							self._act(ev, tc.action, '');
						}
					}, [ tc.btn ])
				])
			]);
		});

		nodes.push(E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '🎯 ' + _('Диагностика и проверка стратегий') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Тестирование DPI') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Запуск проверок откроет окно с живым отчётом тестирования доступности целевых хостов.')
				])
			]),
			E('div', { 'class': 'xfree-zapret-tests-grid' }, testGrid)
		]));

		/* 5. Section: Секции DPI */
		if (sections.length > 0) {
			var filterMode = this._filter || 'all';
			var filtered = sections.filter(function(sec) {
				if (filterMode === 'active') return !!sec.enabled;
				if (filterMode === 'disabled') return !sec.enabled;
				return true;
			});

			var secGrid = filtered.map(function(sec) {
				var ico = sectionIcon(sec.name);
				var isEn = !!sec.enabled;

				var toggleInput = E('input', {
					'type': 'checkbox',
					'checked': isEn ? 'checked' : null,
					'title': isEn ? _('Отключить секцию') : _('Включить секцию')
				});
				toggleInput.checked = isEn;
				toggleInput.addEventListener('change', function(ev) {
					ev.stopPropagation();
					var targetEn = ev.target.checked;
					sec.enabled = targetEn;
					self.requestPaint();
					xui.runZapretMenu('toggleSection', sec.name + ':' + (targetEn ? '1' : '0'))
						.then(function() {
							st.pending = true;
							self.setMessage(
								_('Секция «%s» %s. Для применения правил нажмите «⚡ Применить списки».')
									.format(sec.name, targetEn ? _('включена') : _('отключена')),
								'warn'
							);
							self.requestPaint();
						})
						.catch(function(err) {
							sec.enabled = !targetEn;
							self.setMessage(_('Ошибка: %s').format(err && err.message || err), 'bad');
							self.requestPaint();
						});
				});

				var toggleSwitch = E('label', {
					'class': 'xfree-zapret-toggle',
					'title': isEn ? _('Включена (нажмите для отключения)') : _('Отключена (нажмите для включения)')
				}, [
					toggleInput,
					E('span', { 'class': 'xfree-zapret-toggle-slider' })
				]);

				return E('div', { 'class': 'xfree-zapret-section-card' + (isEn ? '' : ' is-disabled') }, [
					E('div', { 'class': 'xfree-zapret-sec-top' }, [
						E('span', { 'style': 'font-size: 16px; margin-right: 6px;' }, [ ico ]),
						E('strong', { 'class': 'xfree-zapret-sec-name' }, [ sec.name ]),
						toggleSwitch
					]),
					E('div', { 'class': 'xfree-zapret-sec-meta' }, [
						isEn
							? E('span', { 'class': 'xfree-vpn-status is-ok', 'style': 'font-size: 11px;' }, [ '● ' + _('Активна') ])
							: E('span', { 'class': 'xfree-vpn-status is-muted', 'style': 'font-size: 11px;' }, [ '○ ' + _('Отключена') ]),
						sec.hosts > 0
							? E('span', { 'class': 'xfree-vpn-status is-muted', 'style': 'font-size: 11px;' }, [ '%d хостов'.format(sec.hosts) ])
							: E('span', { 'class': 'xfree-vpn-status is-muted', 'style': 'font-size: 11px;' }, [ _('пусто') ])
					]),
					E('div', { 'class': 'xfree-zapret-sec-actions' }, [
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'title': _('Просмотр и редактирование параметров стратегии (section.text)'),
							'click': function(ev) {
								ev.preventDefault();
								self._openStrategyDialog(sec.name);
							}
						}, [ '⚙️ ' + _('Стратегия') ]),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'title': _('Перейти к спискам для секции «%s» в «Маршруты»').format(sec.name),
							'click': function(ev) {
								ev.preventDefault();
								if (s.onNavigate)
									s.onNavigate('routing', 'zapret', sec.name);
								else if (view && view.navigate)
									view.navigate('routing', 'zapret', sec.name);
							}
						}, [ '📋 ' + _('Списки') ])
					])
				]);
			});

			var filterGroup = E('div', { 'class': 'xfree-zapret-filter-group' }, [
				E('button', {
					'class': 'xfree-zapret-filter-btn' + (filterMode === 'all' ? ' is-active' : ''),
					'type': 'button',
					'click': function(ev) {
						ev.preventDefault();
						self._filter = 'all';
						self.requestPaint();
					}
				}, [ _('Все') + ' (' + sections.length + ')' ]),
				E('button', {
					'class': 'xfree-zapret-filter-btn' + (filterMode === 'active' ? ' is-active' : ''),
					'type': 'button',
					'click': function(ev) {
						ev.preventDefault();
						self._filter = 'active';
						self.requestPaint();
					}
				}, [ '● ' + _('Активные') + ' (' + activeCount + ')' ]),
				E('button', {
					'class': 'xfree-zapret-filter-btn' + (filterMode === 'disabled' ? ' is-active' : ''),
					'type': 'button',
					'click': function(ev) {
						ev.preventDefault();
						self._filter = 'disabled';
						self.requestPaint();
					}
				}, [ '○ ' + _('Отключённые') + ' (' + (sections.length - activeCount) + ')' ])
			]);

			nodes.push(E('section', { 'class': 'xfree-vpn-section' }, [
				E('div', { 'class': 'xfree-selfroute-header' }, [
					E('div', { 'class': 'xfree-selfroute-title-row' }, [
						E('h4', {}, [ '📑 ' + _('Секции DPI (%d из %d активны)').format(activeCount, sections.length) ]),
						E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('sections.order') ])
					]),
					E('p', { 'class': 'muted' }, [
						_('Секции обрабатывают сетевой трафик в порядке расположения. Для включения или отключения используйте переключатель. Для редактирования привязанных доменов нажмите «Списки».')
					]),
					filterGroup
				]),
				E('div', { 'class': 'xfree-zapret-sections-grid' }, secGrid)
			]));
		}

		/* 6. Section: Дополнительно / Экспертный режим */
		nodes.push(E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '🛠️ ' + _('Обслуживание и CLI-инструменты') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Дополнительно') ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'padding: 6px 0;' }, [
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'click': function(ev) {
						self._act(ev, 'copyFake', '',
							_('Скопировать fake *.bin в /opt/zapret и перезапустить zapret?'));
					}
				}, [ '📄 ' + _('Скопировать fake-файлы') ])
			]),
			E('p', { 'class': 'muted', 'style': 'margin-top: 8px; font-size: 12px;' }, [
				_('💡 Интерактивный перебор стратегий (blockcheck) и изменение порядка секций (sections.order) доступны также в терминале CLI: xft → 4.')
			])
		]));

		this.replaceChildren.apply(this, nodes);
	}
});

return baseclass.extend({
	tag: TAG
});
