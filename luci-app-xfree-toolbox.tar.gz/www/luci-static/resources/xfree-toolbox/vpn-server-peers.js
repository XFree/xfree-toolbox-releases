'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.vpn-server-format as serverFormat';

var copyToClipboard = serverFormat.copyToClipboard;
var slugifyPeerName = serverFormat.slugifyPeerName;
var downloadTextFile = serverFormat.downloadTextFile;
var extractConfBody = serverFormat.extractConfBody;
var loadUqr = serverFormat.loadUqr;
var renderQrSvg = serverFormat.renderQrSvg;

return baseclass.extend({
	_openPeerConfigDialog: function (peer, initialTab) {
		var self = this;
		var s = this._spec || {};
		self.setBusy(true);

		if (!s.onAction) {
			self.setBusy(false);
			return;
		}

		s.onAction('peerShowConfig', peer.slug, '', function (res, report) {
			self.setBusy(false);
			if (!res || res.code !== 0) {
				self.setMessage(_('Не удалось получить конфигурацию клиента: %s').format(report || ''), 'bad');
				return;
			}

			var confText = extractConfBody(res.stdout);
			if (!confText) {
				self.setMessage(_('Конфигурация клиента пуста'), 'warn');
				return;
			}

			loadUqr().then(function (Uqr) {
				var filename = (peer.slug || peer.name || 'client') + '.conf';
				var localSvg = renderQrSvg(Uqr, confText);
				var activeTab = (initialTab === 'conf') ? 'conf' : 'qr';

				var metaRow = E('div', {
					'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; font-size: 13px;'
				}, [
					E('div', {}, [
						E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'margin-right: 8px;' }, [peer.ip || '']),
						E('span', { 'class': 'muted' }, [_('Endpoint: ') + (peer.endpoint || 'default')])
					]),
					peer.keepalive ? E('span', { 'class': 'muted font-mono', 'style': 'font-size: 11px;' }, [_('keepalive: %ds').format(peer.keepalive)]) : ''
				]);

				var qrPaneChildren = [];
				if (localSvg) {
					var qrWrap = E('div', { 'class': 'xfree-vpn-qr-wrap' });
					qrWrap.innerHTML = localSvg;
					qrPaneChildren.push(qrWrap);
					qrPaneChildren.push(E('p', {
						'class': 'muted',
						'style': 'text-align: center; margin: 6px 0 10px 0; font-size: 12px;'
					}, [_('Отсканируйте камерой в мобильном приложении AmneziaWG или WireGuard')]));
				} else {
					qrPaneChildren.push(E('div', {
						'class': 'alert-message warning',
						'style': 'margin: 16px 0;'
					}, [
						_('Не удалось сгенерировать QR-код (модуль uqr недоступен). Используйте вкладку «Конфиг» для скачивания файла .conf или копирования настроек.')
					]));
				}

				var qrPane = E('div', { 'class': 'xfree-dialog-tab-pane' }, qrPaneChildren);

				var confTextArea = E('textarea', {
					'class': 'xfree-vpn-conf-textarea',
					'readonly': 'readonly',
					'rows': 9,
					'style': 'margin-bottom: 6px;'
				}, [confText]);

				var confPane = E('div', { 'class': 'xfree-dialog-tab-pane' }, [
					confTextArea,
					E('p', { 'class': 'muted', 'style': 'margin: 4px 0 8px 0; font-size: 12px;' }, [
						_('Импортируйте этот файл конфигурации в приложение AmneziaWG на компьютере или смартфоне.')
					])
				]);

				var tabQrBtn = E('button', {
					'class': 'xfree-dialog-tab-btn' + (activeTab === 'qr' ? ' is-active' : ''),
					'type': 'button',
					'click': function () { switchTab('qr'); }
				}, ['📱 ' + _('QR-код')]);

				var tabConfBtn = E('button', {
					'class': 'xfree-dialog-tab-btn' + (activeTab === 'conf' ? ' is-active' : ''),
					'type': 'button',
					'click': function () { switchTab('conf'); }
				}, ['📄 ' + _('Конфиг (.conf)')]);

				var tabsBar = E('div', { 'class': 'xfree-dialog-tabs' }, [tabQrBtn, tabConfBtn]);

				function switchTab(tab) {
					activeTab = tab;
					if (tab === 'qr') {
						tabQrBtn.classList.add('is-active');
						tabConfBtn.classList.remove('is-active');
						qrPane.style.display = 'block';
						confPane.style.display = 'none';
					} else {
						tabQrBtn.classList.remove('is-active');
						tabConfBtn.classList.add('is-active');
						qrPane.style.display = 'none';
						confPane.style.display = 'block';
					}
				}

				switchTab(activeTab);

				var copyBtn = xcmp.button({
					variant: 'vpn',
					primary: true,
					extraClass: 'is-primary',
					style: 'margin-right: 8px;',
					text: '📋 ' + _('Скопировать'),
					onClick: function (ev) {
						copyToClipboard(confText, ev.target);
					}
				});

				var downloadBtn = xcmp.button({
					variant: 'vpn',
					primary: true,
					style: 'margin-right: 8px;',
					text: '💾 ' + _('Скачать .conf'),
					onClick: function () {
						downloadTextFile(filename, confText);
					}
				});

				var closeBtn = xcmp.button({
					variant: 'vpn',
					primary: true,
					text: _('Закрыть'),
					onClick: function () { ui.hideModal(); }
				});

				var buttonsBar = E('div', { 'style': 'display: flex; justify-content: flex-end; margin-top: 14px;' }, [
					copyBtn,
					downloadBtn,
					closeBtn
				]);

				var modalBody = [
					metaRow,
					tabsBar,
					qrPane,
					confPane,
					buttonsBar
				];

				self._showVpnDialog(_('Клиент «%s»').format(peer.name), modalBody);
			});
		});
	},

	_openPeerFreeTurnDialog: function (peer, awg) {
		var self = this;
		var s = this._spec || {};
		self.setBusy(true);

		if (!s.onAction) {
			self.setBusy(false);
			return;
		}

		s.onAction('peerFreeTurnConfig', peer.slug, '', function (res, report) {
			self.setBusy(false);
			if (!res || res.code !== 0) {
				var errMsg = _('Не удалось сформировать ссылку FreeTurn: %s').format(report || (res && res.stderr) || '');
				self.setMessage(errMsg, 'bad');
				ui.addNotification(null, E('p', errMsg), 'danger');
				return;
			}

			var stdout = res.stdout || '';
			var m = stdout.match(/(freeturn:\/\/[^\s\r\n"']+)/);
			var freeturnUri = m ? m[1] : '';

			if (!freeturnUri) {
				var noUriMsg = _('В выводе скрипта не найдена ссылка freeturn://');
				self.setMessage(noUriMsg, 'bad');
				ui.addNotification(null, E('p', noUriMsg), 'danger');
				return;
			}

			Promise.resolve(loadUqr()).catch(function () { return null; }).then(function (Uqr) {
				try {
					var localSvg = renderQrSvg(Uqr, freeturnUri);

					var metaRow = E('div', {
						'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; font-size: 13px;'
					}, [
						E('div', {}, [
							E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'margin-right: 8px;' }, [peer.ip || '']),
							E('span', { 'class': 'muted' }, [_('Порт FreeTurn: ') + ((awg && awg.freeTurnPort) || '56000') + ' (UDP)'])
						]),
						xcmp.badge({
							variant: 'vpn-status',
							tone: 'ok',
							text: _('FreeTurn v5 ready'),
							style: 'font-size: 11px;'
						})
					]);

					var qrPaneChildren = [];
					if (localSvg) {
						var qrWrap = E('div', { 'class': 'xfree-vpn-qr-wrap' });
						qrWrap.innerHTML = localSvg;
						qrPaneChildren.push(qrWrap);
						qrPaneChildren.push(E('p', {
							'class': 'muted',
							'style': 'text-align: center; margin: 6px 0 10px 0; font-size: 12px;'
						}, [_('Отсканируйте камерой в Android-приложении turn-proxy-android (кнопка «+» ➔ «Сканировать QR-код» на вкладке «Соединение»)')]));
					} else {
						qrPaneChildren.push(E('div', {
							'class': 'alert-message warning',
							'style': 'margin: 16px 0;'
						}, [
							_('Не удалось сгенерировать QR-код (модуль uqr недоступен). Скопируйте ссылку ниже.')
						]));
					}

					var uriTextArea = E('textarea', {
						'class': 'xfree-vpn-conf-textarea',
						'readonly': 'readonly',
						'rows': 3,
						'style': 'margin-bottom: 6px; word-break: break-all; font-family: monospace; font-size: 11px;'
					}, [freeturnUri]);

					var linkPane = E('div', { 'style': 'margin-top: 10px;' }, [
						E('label', { 'style': 'font-size: 12px; font-weight: bold; margin-bottom: 4px; display: block;' }, [
							_('Ссылка для импорта в приложение (freeturn://):')
						]),
						uriTextArea,
						E('p', { 'class': 'muted', 'style': 'margin: 4px 0 8px 0; font-size: 12px;' }, [
							_('В приложении turn-proxy-android нажмите «+» ➔ «Вставить ссылку». Адрес роутера, порт 56000, ключ обфускации и ключи клиента подставятся автоматически.')
						])
					]);

					var copyBtn = xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'is-primary',
						style: 'margin-right: 8px;',
						text: '📋 ' + _('Скопировать ссылку'),
						onClick: function (ev) {
							copyToClipboard(freeturnUri, ev.target);
						}
					});

					var closeBtn = xcmp.button({
						variant: 'vpn',
						primary: true,
						text: _('Закрыть'),
						onClick: function () { ui.hideModal(); }
					});

					var buttonsBar = E('div', { 'style': 'display: flex; justify-content: flex-end; margin-top: 14px;' }, [
						copyBtn,
						closeBtn
					]);

					var modalBody = [
						metaRow,
						E('div', { 'class': 'xfree-dialog-tab-pane' }, qrPaneChildren),
						linkPane,
						buttonsBar
					];

					self._showVpnDialog(_('FreeTurn подключение «%s»').format(peer.name), modalBody);
				} catch (diagErr) {
					var renderErr = _('Ошибка отображения диалога FreeTurn: %s').format(diagErr.message || String(diagErr));
					self.setMessage(renderErr, 'bad');
					ui.addNotification(null, E('p', renderErr), 'danger');
				}
			});
		});
	},

	_openAddPeerDialog: function (awg) {
		var self = this;
		var s = this._spec || {};
		var nameInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'placeholder': 'client3, sveta, iphone...',
			'style': 'width: 100%; margin-top: 4px;'
		});

		var epOpts = [
			E('option', { 'value': '' }, [_('Default Endpoint сервера (%s)').format(awg.defaultEndpoint || 'WAN')])
		];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [choices[i].label]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'placeholder': _('Или укажите хост:порт вручную (необязательно)'),
			'style': 'width: 100%; margin-top: 6px;'
		});

		var nameHint = E('p', { 'class': 'muted', 'style': 'font-size: 11px; margin-top: 4px;' }, [
			_('Только латиница, цифры, дефис и подчёркивание')
		]);
		nameInput.addEventListener('input', function () {
			var val = nameInput.value || '';
			var slug = slugifyPeerName(val);
			if (slug && slug !== val) {
				nameHint.textContent = _('Имя для системы: %s').format(slug);
			} else {
				nameHint.textContent = _('Только латиница, цифры, дефис и подчёркивание');
			}
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('label', { 'style': 'font-weight: 600;' }, [_('Имя клиента:')]),
				nameInput,
				nameHint
			]),
			E('div', { 'style': 'margin-bottom: 16px;' }, [
				E('label', { 'style': 'font-weight: 600;' }, [_('Endpoint подключения:')]),
				epSelect,
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px;' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					text: _('Отмена'),
					onClick: function () { ui.hideModal(); }
				}),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function () {
						var rawName = String(nameInput.value || '').trim();
						if (!rawName) {
							nameInput.focus();
							return;
						}
						var cleanName = slugifyPeerName(rawName);
						if (!cleanName) {
							self.setMessage(_('Имя клиента содержит недопустимые символы'), 'bad');
							nameInput.focus();
							return;
						}
						var chosenEp = String(customEpInput.value || '').trim() || epSelect.value;
						var arg = cleanName + (chosenEp ? '|' + chosenEp : '');
						ui.hideModal();
						if (s.onAction)
							s.onAction('peerAdd', arg, _('Создать клиента «%s»?').format(cleanName));
					}
				}, [_('Создать')])
			])
		];

		self._showVpnDialog(_('Новый VPN-клиент'), body);
		setTimeout(function () { nameInput.focus(); }, 100);
	},

});
