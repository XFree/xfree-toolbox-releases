'use strict';
'require baseclass';
'require xfree-toolbox.traffic-map-svg as mapSvg';
'require xfree-toolbox.traffic-map-detail as mapDetail';
'require xfree-toolbox.traffic-map-synth as mapSynth';
'require xfree-toolbox.traffic-map-toolbar as mapToolbar';

return baseclass.extend({
	render: function() {
		var self = this;
		var s = this._spec || {};
		var summary = s.summary || {};
		var nodes = Array.isArray(summary.nodes) ? summary.nodes : [];
		var dns = [];
		var iface = [];
		var zapret = [];
		var i;
		var n;
		var hl = this._hl();
		var tracing = !!(this._trace && this._trace.code === 0);
		var clientLayer = this._layer('client');
		var ifaceLayer = this._layer('iface');
		var dnsLayer = this._layer('dns');
		var zapretLayer = this._layer('zapret');
		var egressLayer = this._layer('egress');
		var egressPath = 'wan';
		var err = '';
		var crumbs = [];
		var hitsById = {};
		var packs;
		var dnsPack;
		var vpnPack;
		var zapPack;
		var dnsStatus;
		var vpnStatus;
		var zapStatus;
		var vpnSkipped;
		var canvasCls = 'tm-flow';
		var btnLabel;
		var lanLabel = 'LAN';
		var lanSub = _('клиент');
		var clientName = '';
		var clientIp = '';

		this.className = 'tm-root';
		this.setAttribute('data-xfree-traffic-map', '1');

		for (i = 0; i < nodes.length; i++) {
			n = nodes[i] || {};
			if (n.kind === 'dns') dns.push(n);
			else if (n.kind === 'iface') iface.push(n);
			else if (n.kind === 'zapret') zapret.push(n);
		}

		if (zapretLayer && zapretLayer.scope && Array.isArray(zapretLayer.scope.hits)) {
			for (i = 0; i < zapretLayer.scope.hits.length; i++) {
				n = zapretLayer.scope.hits[i];
				if (n && n.id) hitsById[n.id] = n;
			}
		}

		/* DNS match context for tip rows (list/domain from current trace). */
		if (dnsLayer && dnsLayer.scope && dnsLayer.scope.dnsId) {
			hitsById['dns:' + dnsLayer.scope.dnsId] = {
				base: dnsLayer.scope.mappedDomain
					|| (this._trace && this._trace.query && this._trace.query.fqdn)
					|| '',
				listFile: dnsLayer.scope.listFile || '',
				strategy: dnsLayer.scope.target || ''
			};
		}

		if (this._trace) {
			if (this._trace.code === 0 && this._trace.summary) {
				egressPath = this._trace.summary.egress ||
					(egressLayer && egressLayer.scope && egressLayer.scope.path) ||
					'wan';
			} else if (this._trace.stderr) {
				err = this._trace.stderr;
			}
		}

		dnsStatus = tracing ? ((dnsLayer && dnsLayer.status) || 'none') : 'default';
		vpnStatus = tracing ? ((ifaceLayer && ifaceLayer.status) || 'none') : 'default';
		zapStatus = tracing ? ((zapretLayer && zapretLayer.status) || 'none') : 'default';
		vpnSkipped = tracing && vpnStatus !== 'match' && vpnStatus !== 'bypassed';

		if (clientLayer && clientLayer.status === 'match' && clientLayer.scope) {
			clientName = clientLayer.scope.name || '';
			clientIp = clientLayer.scope.ip || '';
			lanLabel = clientName || clientIp || 'Client';
			lanSub = (clientName && clientIp) ? clientIp : (clientLayer.title || _('клиент'));
		} else if (this._selectedClient) {
			lanSub = this._selectedClient;
		}

		dnsPack = this._buildStageChips('dns', dns, hl, tracing, !!this._expanded.dns, hitsById, 2);
		vpnPack = this._buildStageChips('iface', iface, hl, tracing, !!this._expanded.vpn, null, 3);
		zapPack = this._buildStageChips('zapret', zapret, hl, tracing, !!this._expanded.zapret, hitsById, 3);

		packs = mapSynth.buildSyntheticPacks(this, {
			tracing: tracing,
			dnsStatus: dnsStatus,
			vpnStatus: vpnStatus,
			zapStatus: zapStatus,
			vpnSkipped: vpnSkipped,
			dnsLayer: dnsLayer,
			ifaceLayer: ifaceLayer,
			zapretLayer: zapretLayer,
			clientLayer: clientLayer,
			lanSub: lanSub,
			egressPath: egressPath,
			dns: dns,
			iface: iface,
			zapret: zapret,
			dnsPack: dnsPack,
			vpnPack: vpnPack,
			zapPack: zapPack
		});
		dnsPack = packs.dnsPack;
		vpnPack = packs.vpnPack;
		zapPack = packs.zapPack;

		/* Always show plate under title: idle = schema hint, active = trace result */
		crumbs.push({ ico: 'lan', label: clientName || clientIp || 'LAN' });
		crumbs.push({ ico: 'router', label: 'Router' });
		if (tracing) {
			if (dnsStatus === 'match' && dnsLayer.scope && dnsLayer.scope.dnsId)
				crumbs.push({ ico: 'dns', label: dnsLayer.scope.dnsId });
			else if (dnsStatus === 'skipped')
				crumbs.push({ ico: 'dns', label: _('без DNS') });
			else if (dnsStatus === 'default')
				crumbs.push({ ico: 'dns', label: _('DNS default') });
			else
				crumbs.push({ ico: 'dns', label: _('DNS') });
			if (vpnStatus === 'bypassed')
				crumbs.push({ ico: 'vpn', label: _('Direct WAN') });
			else if (vpnStatus === 'match' && ifaceLayer.scope && ifaceLayer.scope.iface)
				crumbs.push({ ico: 'vpn', label: ifaceLayer.scope.iface });
			else
				crumbs.push({ ico: 'vpn', label: _('без VPN') });
			if (zapStatus === 'bypassed')
				crumbs.push({ ico: 'zapret', label: _('Direct WAN') });
			else if (zapStatus === 'match' && zapretLayer.scope && zapretLayer.scope.sections && zapretLayer.scope.sections.length)
				crumbs.push({ ico: 'zapret', label: zapretLayer.scope.sections.join(', ') });
			else
				crumbs.push({ ico: 'zapret', label: _('без Zapret') });
			crumbs.push({
				ico: 'out',
				label: egressPath.indexOf('tunnel:') === 0
					? egressPath.replace(/^tunnel:/, '')
					: (egressPath === 'wan' ? 'WAN' : egressPath)
			});
		} else {
			crumbs.push({ ico: 'dns', label: 'DNS' });
			crumbs.push({ ico: 'vpn', label: 'VPN' });
			crumbs.push({ ico: 'zapret', label: 'Zapret' });
			crumbs.push({ ico: 'out', label: _('выход') });
		}

		if (this._busy)
			canvasCls += ' is-busy';
		if (tracing)
			canvasCls += ' is-tracing';

		btnLabel = this._busy
			? [ mapSvg.iconEl(mapSvg.SVG.spin, 'tm-spin'), _('Ищем…') ]
			: [ mapSvg.iconEl(mapSvg.SVG.search, 'tm-btn-ico'), _('Путь') ];

		this.replaceChildren(
			E('div', { 'class': 'block-head tm-head' }, [
				E('h2', {}, [ _('Карта трафика') ])
			]),
			mapToolbar.renderTraceToolbar(this, {
				btnLabel: btnLabel
			}),
			this._breadcrumb(crumbs, tracing),
			err ? E('p', { 'class': 'tm-error' }, [ err ]) : '',
			E('div', { 'class': 'tm-flow-scroll' }, [
				E('div', { 'class': canvasCls }, [
					tracing ? this._rail() : '',
					this._hubBtn('lan', lanLabel, lanSub, tracing),
					this._arrow(tracing, false),
					this._hubBtn('router', 'Router', 'xfree', tracing),
					this._arrow(tracing && (dnsStatus === 'match' || dnsStatus === 'default' || dnsStatus === 'skipped'), false),
					this._stage({
						kind: 'dns',
						title: _('DNS'),
						status: dnsStatus,
						lit: tracing && (dnsStatus === 'match' || dnsStatus === 'default'),
						skipped: tracing && dnsStatus === 'skipped',
						quiet: tracing && dnsStatus === 'none',
						warn: tracing && dnsLayer && !mapDetail.runtimeOk(dnsLayer),
						chips: dnsPack.chips,
						expandKey: 'dns',
						expandLabel: this._stageExpandLabel('dns', dnsPack, dns.length, tracing)
					}),
					this._arrow(tracing, false),
					this._stage({
						kind: 'vpn',
						title: _('VPN'),
						status: vpnStatus === 'bypassed' ? 'bypassed' : (vpnSkipped ? 'skipped' : vpnStatus),
						lit: tracing && (vpnStatus === 'match' || vpnStatus === 'bypassed'),
						skipped: vpnSkipped && vpnStatus !== 'bypassed',
						skippedMsg: '',
						quiet: false,
						warn: tracing && ifaceLayer && !mapDetail.runtimeOk(ifaceLayer),
						chips: vpnPack.chips,
						empty: _('нет туннелей'),
						expandKey: 'vpn',
						expandLabel: this._stageExpandLabel('vpn', vpnPack, iface.length, tracing)
					}),
					this._arrow(tracing && (zapStatus === 'match' || zapStatus === 'none'), false),
					this._stage({
						kind: 'zapret',
						title: 'Zapret',
						status: zapStatus === 'bypassed' ? 'bypassed' : (zapStatus === 'none' && tracing ? 'skipped' : zapStatus),
						lit: tracing && (zapStatus === 'match' || zapStatus === 'bypassed'),
						skipped: tracing && zapStatus === 'none',
						quiet: false,
						warn: tracing && zapretLayer && !mapDetail.runtimeOk(zapretLayer),
						chips: zapPack.chips,
						expandKey: 'zapret',
						expandLabel: this._stageExpandLabel('zapret', zapPack, zapret.length, tracing)
					}),
					this._arrow(tracing, false),
					(function() {
						var wan = summary.wan || (self._trace && self._trace.summary && self._trace.summary.wan) || null;
						var outLabel = egressPath.indexOf('tunnel:') === 0
							? egressPath.replace(/^tunnel:/, '')
							: (egressPath === 'wan' ? 'WAN' : egressPath);
						var outHealth = 'unknown';
						var outDetail;
						var j;
						var node;
						var ch = mapDetail.channelLabel(wan);

						if (!tracing) {
							outLabel = 'WAN';
							outHealth = wan ? mapDetail.nodeHealth({ runtime: wan }) : 'unknown';
							outDetail = {
								id: 'egress:wan',
								navKind: 'out',
								title: _('Выход: WAN'),
								rows: [
									{ k: _('Канал'), v: ch || mapDetail.healthLabel(outHealth) },
									{ k: _('Интерфейс'), v: (wan && wan.probeIface) ? (wan.probeIface + ((wan.probeIfaceL2 && wan.probeIfaceL2 !== wan.probeIface) ? (' (' + wan.probeIfaceL2 + ')') : '')) : '—' },
									{ k: _('База'), v: wan && wan.probeBase != null && wan.probeBase !== ''
										? (mapDetail.probeBitOk(wan.probeBase) ? 'OK' : 'FAIL') : '—' },
									{ k: _('Доп.'), v: (wan && (wan.probeAltEnabled === 1 || wan.probeAltEnabled === '1'))
										? (mapDetail.probeBitOk(wan.probeAlt) ? 'OK' : 'FAIL')
										: _('выкл') },
									{ k: _('Последний тик'), v: (wan && wan.lastTick) || '—' }
								]
							};
						} else if (egressPath.indexOf('tunnel:') === 0) {
							for (j = 0; j < iface.length; j++) {
								if (mapDetail.nodeLabel(iface[j].id, '') === outLabel || (iface[j].label === outLabel)) {
									outHealth = mapDetail.nodeHealth(iface[j]);
									node = iface[j];
									break;
								}
							}
							outDetail = {
								id: 'egress:' + outLabel,
								navKind: 'vpn',
								navScope: outLabel,
								title: _('Выход: %s').format(outLabel),
								rows: [
									{ k: _('Тип'), v: _('туннель') },
									{ k: _('Мониторинг'), v: mapDetail.healthLabel(outHealth) },
									{ k: _('Канал WAN'), v: ch || '—' },
									{ k: _('Probe'), v: (node && node.runtime && node.runtime.monitorPing) || '—' },
									{ k: _('Last'), v: (node && node.runtime && node.runtime.monitorLast) || '—' }
								]
							};
						} else {
							outHealth = wan ? mapDetail.nodeHealth({ runtime: wan }) : 'unknown';
							outDetail = {
								id: 'egress:wan',
								navKind: 'out',
								title: _('Выход: WAN'),
								rows: [
									{ k: _('Тип'), v: _('прямой WAN') },
									{ k: _('Канал'), v: ch || mapDetail.healthLabel(outHealth) },
									{ k: _('Интерфейс'), v: (wan && wan.probeIface) ? (wan.probeIface + ((wan.probeIfaceL2 && wan.probeIfaceL2 !== wan.probeIface) ? (' (' + wan.probeIfaceL2 + ')') : '')) : '—' },
									{ k: _('База'), v: wan && wan.probeBase != null && wan.probeBase !== ''
										? (mapDetail.probeBitOk(wan.probeBase) ? 'OK' : 'FAIL') : '—' },
									{ k: _('Доп.'), v: (wan && (wan.probeAltEnabled === 1 || wan.probeAltEnabled === '1'))
										? (mapDetail.probeBitOk(wan.probeAlt) ? 'OK' : 'FAIL')
										: _('выкл') },
									{ k: _('Последний тик'), v: (wan && wan.lastTick) || '—' }
								]
							};
						}

						return self._stage({
							kind: 'out',
							title: _('Выход'),
							status: tracing ? 'inferred' : 'default',
							lit: tracing,
							chips: [
								self._chip({
									kind: 'out',
									label: outLabel,
									active: tracing,
									health: outHealth,
									detail: outDetail
								})
							],
							diag: self._wanChannelDiag(wan)
						});
					})()
				])
			])
		);

		this._placeFloatPopover();
		if (this._suggestOpen)
			this._paintSuggest();
	}
});
