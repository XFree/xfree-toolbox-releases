'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-nav';

var UPD_ICONS = {
	none: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
	available: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"/></svg>',
	error: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 9v4m0 4h.01M10.3 4.7 2.6 18a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 4.7a2 2 0 0 0-3.4 0z"/></svg>',
	unknown: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 4.2 1.8c0 2-2.7 2.7-2.7 2.7M12 17h.01"/></svg>'
};

var ICONS = {
	home: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11.5 12 4l8 7.5V20a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1z"/></svg>',
	profiles: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 4h8a2 2 0 0 1 2 2v14l-6-3-6 3V6a2 2 0 0 1 2-2z"/></svg>',
	routing: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="6" cy="12" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M8 12h6M14 8l4-2M14 16l4 2"/></svg>',
	vpn: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 4.5 3.2 8 8 9 4.8-1 8-4.5 8-9V7z"/><path d="M9.5 12.5 11 14l3.5-3.5"/></svg>',
	zapret: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 5 3.5 8.5 8 9 4.5-.5 8-4 8-9V7z"/></svg>',
	telemt: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 2-11 11M22 2l-7 20-4-9-9-4 20-7z"/></svg>',
	diagnostics: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/><circle cx="12" cy="12" r="3"/><path d="m16.2 7.8 2.1-2.1M5.7 18.3l2.1-2.1M16.2 16.2l2.1 2.1M5.7 5.7l2.1 2.1"/></svg>',
	system: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16v10H4zM8 17v2m8-2v2M9 11h.01M12 11h.01M15 11h.01"/></svg>',
	expert: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3M1 14h6m2-6h6m2 8h6"/></svg>',
	chevron: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>'
};

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this.requestPaint();
	}

	setActive(routeId, tab, panel) {
		this._spec = this._spec || {};
		this._spec.activeId = routeId;
		this._spec.activeTab = tab || '';
		this._spec.activePanel = panel || '';
		this._updateActiveClasses();
	}

	_updateActiveClasses() {
		var s = this._spec || {};
		var routeId = s.activeId;
		var tab = s.activeTab || '';
		var panel = s.activePanel || '';

		this.querySelectorAll('.rail-btn[data-route]').forEach(function(btn) {
			var r = btn.getAttribute('data-route');
			btn.classList.toggle('is-active', r === routeId);
		});

		this.querySelectorAll('.rail-tree-group').forEach(function(group) {
			var r = group.getAttribute('data-route');
			var isCurrentRoute = (r === routeId);

			var subBtns = group.querySelectorAll('.rail-sub-btn');
			var matched = false;

			subBtns.forEach(function(subBtn) {
				var subTab = subBtn.getAttribute('data-tab') || '';
				var subPanel = subBtn.getAttribute('data-panel') || '';
				var isSubActive = false;

				if (isCurrentRoute) {
					if (panel && subPanel)
						isSubActive = (panel === subPanel);
					else if (tab && subTab)
						isSubActive = (tab === subTab);
				}

				if (isSubActive)
					matched = true;

				subBtn.classList.toggle('is-active', isSubActive);
			});

			if (isCurrentRoute && !matched && subBtns.length > 0)
				subBtns[0].classList.add('is-active');
		});
	}

	setBrand(brand) {
		this._spec = this._spec || {};
		this._spec.brand = brand || {};
		var el = this.querySelector('.rail-brand');
		if (el)
			el.replaceWith(this._buildBrand(this._spec));
	}

	_updateStateKey(state) {
		switch (String(state || '').toLowerCase()) {
		case 'none': return 'none';
		case 'available': return 'available';
		case 'error': return 'error';
		default: return 'unknown';
		}
	}

	_updTitle(state, label) {
		switch (state) {
		case 'none':
			return _('Пакет актуален (%s). Открыть «Обновления»').format(label || _('актуально'));
		case 'available':
			return _('Доступно обновление (%s). Перейти к установке').format(label || '');
		case 'error':
			return _('Ошибка проверки обновлений. Открыть «Обновления»');
		default:
			return _('Статус обновлений не проверен. Открыть «Обновления»');
		}
	}

	_buildBrand(spec) {
		var s = spec || {};
		var brand = s.brand || {};
		var onNavigate = s.onNavigate;
		var view = s.view;
		var ver = String(brand.version || '').trim();
		var state = this._updateStateKey(brand.update);
		var label = String(brand.label || '').trim();
		var updBtn;
		var meta;
		var verEl;

		updBtn = E('button', {
			'class': 'rail-upd-btn is-' + state,
			'type': 'button',
			'title': this._updTitle(state, label),
			'aria-label': this._updTitle(state, label),
			'click': ui.createHandlerFn(view, function(ev) {
				ev.preventDefault();
				ev.stopPropagation();
				if (onNavigate)
					onNavigate('system', 'update', 'system.toolbox');
			})
		}, [
			E('span', { 'class': 'rail-upd-ico', 'aria-hidden': 'true' })
		]);
		updBtn.querySelector('.rail-upd-ico').innerHTML = UPD_ICONS[state] || UPD_ICONS.unknown;

		verEl = E('span', { 'class': 'rail-brand-ver' }, [
			ver ? ('v' + ver) : 'v—'
		]);

		meta = E('div', { 'class': 'rail-brand-meta' }, [ verEl, updBtn ]);

		return E('div', { 'class': 'rail-brand' }, [
			E('span', { 'class': 'rail-brand-mark' }, [ 'XF' ]),
			E('div', { 'class': 'rail-brand-col' }, [
				E('span', { 'class': 'rail-brand-text' }, [ 'xfree' ]),
				meta
			])
		]);
	}

	render() {
		var self = this;
		var s = this._spec || {};
		var routes = s.routes || [];
		var panels = s.panels || {};
		var isExpert = Boolean(s.isExpert);
		var activeId = s.activeId;
		var activeTab = s.activeTab || '';
		var activePanel = s.activePanel || '';
		var onSelect = s.onSelect;
		var onNavigate = s.onNavigate;
		var view = s.view;
		var nodes = [];

		this.className = 'rail';
		this.setAttribute('aria-label', _('Основное меню'));

		nodes.push(this._buildBrand(s));

		routes.forEach(function(route) {
			var isCurrentRoute = (route.id === activeId);
			var visibleTabs = (route.tabs || []).filter(function(t) {
				if (!t) return false;
				if (t.panel && panels[t.panel]) {
					var p = panels[t.panel];
					if (p.visibility === 'expert' && !isExpert)
						return false;
				}
				return true;
			});

			if (!visibleTabs.length) {
				var btn = E('button', {
					'class': 'rail-btn' + (isCurrentRoute ? ' is-active' : ''),
					'type': 'button',
					'title': route.title || route.id,
					'data-route': route.id,
					'click': ui.createHandlerFn(view, function(ev) {
						ev.preventDefault();
						if (onSelect)
							onSelect(route.id);
					})
				}, [
					E('span', { 'class': 'rail-ico' }),
					E('span', { 'class': 'rail-label' }, [ route.title || route.id ])
				]);

				btn.querySelector('.rail-ico').innerHTML = ICONS[route.icon] || ICONS.home;
				nodes.push(btn);
				return;
			}

			var group = E('div', {
				'class': 'rail-tree-group',
				'data-route': route.id
			});

			var headBtn = E('button', {
				'class': 'rail-btn' + (isCurrentRoute ? ' is-active' : ''),
				'type': 'button',
				'title': route.title || route.id,
				'data-route': route.id,
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					if (onSelect)
						onSelect(route.id);
				})
			}, [
				E('span', { 'class': 'rail-ico' }),
				E('span', { 'class': 'rail-label' }, [ route.title || route.id ])
			]);

			headBtn.querySelector('.rail-ico').innerHTML = ICONS[route.icon] || ICONS.home;
			group.appendChild(headBtn);

			var subContainer = E('div', { 'class': 'rail-tree-sub' });
			var matchedSub = false;

			var subBtns = visibleTabs.map(function(t) {
				var isSubActive = false;

				if (isCurrentRoute) {
					if (activePanel && t.panel)
						isSubActive = (activePanel === t.panel);
					else if (activeTab && t.tab)
						isSubActive = (activeTab === t.tab);
				}

				if (isSubActive)
					matchedSub = true;

				return E('button', {
					'class': 'rail-sub-btn' + (isSubActive ? ' is-active' : ''),
					'type': 'button',
					'data-tab': t.tab || t.id || '',
					'data-panel': t.panel || '',
					'title': t.title || t.id,
					'click': ui.createHandlerFn(view, function(ev) {
						ev.preventDefault();
						ev.stopPropagation();
						if (onNavigate)
							onNavigate(route.id, t.tab || '', t.panel || '');
						else if (onSelect)
							onSelect(route.id);
					})
				}, [
					E('span', { 'class': 'rail-sub-dot', 'aria-hidden': 'true' }),
					E('span', { 'class': 'rail-sub-label' }, [ t.title || t.id ])
				]);
			});

			if (isCurrentRoute && !matchedSub && subBtns.length > 0)
				subBtns[0].classList.add('is-active');

			subBtns.forEach(function(sb) { subContainer.appendChild(sb); });
			group.appendChild(subContainer);

			nodes.push(group);
		});

		var onToggleExpert = s.onToggleExpert;
		var expertBtn = E('button', {
			'class': 'rail-btn rail-expert-btn' + (isExpert ? ' is-expert' : ''),
			'type': 'button',
			'title': isExpert ? _('Экспертный режим включён. Кликните для простого режима') : _('Простой режим. Кликните для экспертного режима'),
			'click': ui.createHandlerFn(view, function(ev) {
				ev.preventDefault();
				if (onToggleExpert)
					onToggleExpert();
			})
		}, [
			E('span', { 'class': 'rail-ico' }),
			E('span', { 'class': 'rail-label' }, [
				isExpert ? _('Простой режим') : _('Экспертный режим')
			])
		]);
		expertBtn.querySelector('.rail-ico').innerHTML = ICONS.expert;
		nodes.push(expertBtn);

		this.replaceChildren.apply(this, nodes);
	}
});

return baseclass.extend({
	tag: TAG
});
