'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';

/* Диалог политики устройства. Кнопки сохранения остаются сырыми:
 * у варианта vpn у кнопки всегда есть ghost-compact. */

return baseclass.extend({
	_openEditDialog: function (dev, defaultValues) {
		var self = this;
		var isNew = !dev;
		var cur = dev || defaultValues || {};

		var availableIfaces = (self._ifaces && self._ifaces.length) ? self._ifaces : [
			{ id: 'warp', name: 'warp', label: 'warp' },
			{ id: 'proton', name: 'proton', label: 'proton' }
		];

		// Initial routing target
		var initTarget = 'default';
		if (cur.forceIface) {
			initTarget = 'tunnel:' + cur.forceIface;
		} else if (cur.skipVpn) {
			initTarget = 'wan';
		}

		// Initial zapret mode
		var initZapret = 'auto';
		if (cur.forceZapret) {
			initZapret = 'force';
		} else if (cur.skipZapret) {
			initZapret = 'bypass';
		}

		var nameInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': _('Например: Proxmox VM, Smart TV'),
			'value': cur.name || ''
		});

		var ipInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text font-mono',
			'style': 'width: 100%;',
			'placeholder': _('192.168.31.51 или 192.168.31.0/24'),
			'value': cur.ip || ''
		});

		var macInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text font-mono',
			'style': 'width: 100%;',
			'placeholder': _('aa:bb:cc:dd:ee:ff'),
			'value': cur.mac || ''
		});

		var targetOptions = [
			E('option', { 'value': 'default', 'selected': initTarget === 'default' ? '' : null }, [
				_('🌐 По спискам (Direct default — стандартная маршрутизация роутера)')
			]),
			E('option', { 'value': 'wan', 'selected': initTarget === 'wan' ? '' : null }, [
				_('⚡ Прямой WAN (Direct WAN — весь трафик напрямую в обход VPN и Zapret)')
			])
		];

		availableIfaces.forEach(function (ifc) {
			var iname = ifc.name || ifc.id || ifc.label;
			var ilbl = ifc.label || ifc.name || ifc.id;
			var val = 'tunnel:' + iname;
			targetOptions.push(E('option', {
				'value': val,
				'selected': initTarget === val ? '' : null
			}, ['🛡️ ' + _('Весь трафик в туннель %s').format(ilbl) + (ifc.kind ? ' (' + ifc.kind + ')' : '')]));
		});

		var targetSelect = E('select', {
			'class': 'cbi-input-select',
			'style': 'width: 100%;'
		}, targetOptions);

		var zapretSelect = E('select', {
			'class': 'cbi-input-select',
			'style': 'width: 100%;'
		}, [
			E('option', { 'value': 'auto', 'selected': initZapret === 'auto' ? '' : null }, [
				_('🌐 Автоматически (десинхронизация только по спискам Zapret)')
			]),
			E('option', { 'value': 'force', 'selected': initZapret === 'force' ? '' : null }, [
				_('⚡ Принудительно в Zapret (весь веб-трафик устройства в NFQUEUE)')
			]),
			E('option', { 'value': 'bypass', 'selected': initZapret === 'bypass' ? '' : null }, [
				_('🚫 В обход Zapret (пропустить десинхронизацию DPI)')
			])
		]);

		var zapretDesc = E('div', { 'class': 'cbi-value-description' }, [
			_('Управление десинхронизацией DPI для исходящего трафика данного устройства')
		]);

		var zapretRow = E('div', { 'class': 'cbi-value' }, [
			E('label', { 'class': 'cbi-value-title' }, [_('Режим Zapret (DPI) *')]),
			E('div', { 'class': 'cbi-value-field' }, [
				zapretSelect,
				zapretDesc
			])
		]);

		function updateTargetUi() {
			var t = targetSelect.value;
			if (t === 'wan') {
				zapretSelect.value = 'bypass';
				zapretSelect.disabled = true;
				zapretRow.style.opacity = '0.5';
				zapretDesc.textContent = _('При чистом Direct WAN десинхронизация Zapret автоматически отключена');
			} else {
				zapretSelect.disabled = false;
				zapretRow.style.opacity = '1';
				zapretDesc.textContent = _('Управление десинхронизацией DPI для исходящего трафика данного устройства');
			}
		}

		targetSelect.addEventListener('change', updateTargetUi);
		updateTargetUi();

		var commentInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': _('Комментарий или назначение устройства'),
			'value': cur.comment || ''
		});

		var errorBox = E('div', {
			'class': 'xfree-vpn-msg is-bad',
			'style': 'margin-top: 8px; display: none;'
		});

		var modalContent = E('div', { 'class': 'xfree-dialog-body', 'style': 'display: flex; flex-direction: column; gap: 12px;' }, [
			E('p', { 'class': 'muted' }, [
				_('Укажите параметры устройства (IP или MAC) и выберите целевой шлюз (WAN, списки или конкретный VPN-туннель) и режим десинхронизации Zapret.')
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Имя устройства *')]),
				E('div', { 'class': 'cbi-value-field' }, [nameInput])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('IP-адрес или CIDR')]),
				E('div', { 'class': 'cbi-value-field' }, [
					ipInput,
					E('div', { 'class': 'cbi-value-description' }, [_('Одиночный IP (192.168.31.50) или подсеть (192.168.31.0/24)')])
				])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('MAC-адрес')]),
				E('div', { 'class': 'cbi-value-field' }, [
					macInput,
					E('div', { 'class': 'cbi-value-description' }, [_('Аппаратный MAC-адрес сетевой карты (формат: 00:11:22:33:44:55)')])
				])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Целевой шлюз / Туннель *')]),
				E('div', { 'class': 'cbi-value-field' }, [
					targetSelect,
					E('div', { 'class': 'cbi-value-description' }, [
						_('Выберите, куда направлять основной трафик: в обход в WAN, по стандартным спискам или в выделенный VPN')
					])
				])
			]),
			zapretRow,
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Примечание')]),
				E('div', { 'class': 'cbi-value-field' }, [commentInput])
			]),
			errorBox
		]);

		ui.showModal(isNew ? _('Добавить политику устройства') : _('Редактировать политику устройства'), [
			modalContent,
			E('div', { 'class': 'right', 'style': 'margin-top: 16px; display: flex; justify-content: flex-end; gap: 8px;' }, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': function () { ui.hideModal(); }
				}, [_('Отмена')]),
				E('button', {
					'class': 'btn primary-large is-primary',
					'type': 'button',
					'click': function () {
						var name = nameInput.value.trim();
						var ip = ipInput.value.trim();
						var mac = macInput.value.trim();
						var com = commentInput.value.trim();

						if (!name) {
							errorBox.textContent = _('Укажите имя устройства');
							errorBox.style.display = 'block';
							nameInput.focus();
							return;
						}
						if (!ip && !mac) {
							errorBox.textContent = _('Необходимо указать хотя бы IP-адрес или MAC-адрес устройства');
							errorBox.style.display = 'block';
							ipInput.focus();
							return;
						}

						var tgt = targetSelect.value;
						var zap = zapretSelect.value;
						var sv = 0, sz = 0, fi = '', fz = 0;

						if (tgt === 'wan') {
							sv = 1;
							sz = 1;
							fi = '';
							fz = 0;
						} else if (tgt === 'default') {
							sv = 0;
							fi = '';
							sz = (zap === 'bypass') ? 1 : 0;
							fz = (zap === 'force') ? 1 : 0;
						} else if (tgt === 'tunnel' || tgt.indexOf('tunnel:') === 0) {
							sv = 0;
							fi = (tgt === 'tunnel') ? (availableIfaces[0] ? (availableIfaces[0].name || availableIfaces[0].id) : 'warp') : tgt.substring(7);
							sz = (zap === 'bypass') ? 1 : 0;
							fz = (zap === 'force') ? 1 : 0;
						}

						var devId = isNew ? self._deviceId(name) : (cur.id || self._deviceId(name));
						var arg = [devId, name, ip, mac, sv, sz, com, fi, fz].join('|');

						errorBox.style.display = 'none';
						ui.showModal(_('Сохранение'), [
							E('p', { 'class': 'spinning' }, [_('Сохранение правила…')])
						]);

						xui.runIfaceMenu('devicePolicySave', arg).then(function () {
							ui.hideModal();
							self._setMsg(_('Правило сохранено. Нажмите «⚡ Применить правила» для активации в nftables.'), 'warn');
							self.reload();
						}).catch(function (err) {
							ui.hideModal();
							ui.addNotification(null, E('p', {}, [_('Ошибка сохранения: %s').format(err && err.message ? err.message : String(err))]), 'error');
						});
					}
				}, [_('Сохранить')])
			])
		]);
	},
});
