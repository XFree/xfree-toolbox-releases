'use strict';
'require baseclass';

/* Сборка секции VPN-сервера. Карточки живут в соседних модулях
 * и вызываются с того же прототипа xfree-vpn-server. */

return baseclass.extend({
	_renderServerSection: function (awg, view, serverView) {
		if (serverView === 'clients') {
			return E('div', { 'class': 'xfree-vpn-server-wrap' }, [
				this._renderPeerSection(awg)
			]);
		}
		var serverCards = [
			this._renderServerIdentity(awg, view),
			this._renderNatCard(awg),
			this._renderFreeTurnCard(awg)
		];
		var vkTurnCard = this._renderVkTurnCard(awg);

		if (vkTurnCard)
			serverCards.push(vkTurnCard);
		return E('div', { 'class': 'xfree-vpn-server-wrap' }, serverCards);
	}
});
