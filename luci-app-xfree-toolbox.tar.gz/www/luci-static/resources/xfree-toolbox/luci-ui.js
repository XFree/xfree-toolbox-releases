'use strict';
'require baseclass';
'require dom';
'require fs';
'require rpc';
'require ui';
'require xfree-toolbox.wc';
'require xfree-toolbox.console-output';
'require xfree-toolbox.placeholder';
'require xfree-toolbox.report-panel';
'require xfree-toolbox.invoke-panel as InvokePanel';
'require xfree-toolbox.wizard-panel';
'require xfree-toolbox.routing-hub';
'require xfree-toolbox.menu-panel';
'require xfree-toolbox.uplink-panel';
'require xfree-toolbox.nav';

if (window.L && L.env && (L.env.rpctimeout == null || L.env.rpctimeout < 180)) {
	L.env.rpctimeout = 180;
}

var callHostResources = rpc.declare({
	object: 'xfree-toolbox',
	method: 'hostResources',
	params: []
});

var callListDomainInterfaces = rpc.declare({
	object: 'xfree-toolbox',
	method: 'listDomainInterfaces',
	params: []
});

var callUpstreamSelection = rpc.declare({
	object: 'xfree-toolbox',
	method: 'upstreamSelection',
	params: [ 'action', 'target', 'scope', 'mode', 'tags_json' ]
});

var callIfaceUpstreamSelection = rpc.declare({
	object: 'xfree-toolbox',
	method: 'ifaceUpstreamSelection',
	params: [ 'action', 'iface', 'tags_json' ]
});

var callTemplatesMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'templatesMenu',
	params: [ 'action', 'op', 'template', 'profile', 'force' ]
});

var callTrafficPath = rpc.declare({
	object: 'xfree-toolbox',
	method: 'trafficPath',
	params: [ 'action', 'fqdn', 'limit' ]
});

var callReport = rpc.declare({
	object: 'xfree-toolbox',
	method: 'report',
	params: [ 'name' ],
	/* dns-check / probe can exceed default ~30s XHR */
	timeout: 300
});

var callUplinkMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'uplinkMenu',
	params: [ 'action', 'arg', 'settings_json' ],
	timeout: 300
});

var callZapretMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'zapretMenu',
	params: [ 'action', 'arg', 'payload' ],
	timeout: 600
});

var callIfaceMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'ifaceMenu',
	params: [ 'action', 'arg' ],
	timeout: 600
});

var callSystemMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'systemMenu',
	params: [ 'action', 'arg', 'payload' ],
	timeout: 600
});

var callAwgMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'awgMenu',
	params: [ 'action', 'arg', 'payload' ],
	timeout: 600
});

function rpcErrMsg(err) {
	if (!err)
		return '';
	if (err instanceof Error && err.message)
		return err.message;
	if (typeof err === 'string')
		return err;
	return String(err);
}

function rpcObjectMissing(method, err) {
	var detail = rpcErrMsg(err);

	if (/timed?\s*out|TimeoutError|timeout/i.test(detail)) {
		return _('Запрос xfree-toolbox.%s превысил время ожидания (долгая проверка). Нажмите «Обновить» ещё раз или смотрите CLI.')
			.format(method) + '\n' + detail;
	}

	if (/abort|network|connection\s*reset/i.test(detail)) {
		return _('Соединение с роутером было сброшено или прервано во время выполнения %s (вероятно, перезапускался rpcd/веб-сервер).')
			.format(method) + '\n' + detail;
	}

	return _('Нет ubus-объекта xfree-toolbox (%s). Нужен пакет xfree-toolbox и rpcd reload.')
		.format(method) + '\n' + detail;
}

var MENU_MODE_STORAGE_KEY = 'xfree-toolbox-menu-mode';

var LuciUi = baseclass.extend({
	menuExpertMode: function() {
		try {
			return (localStorage.getItem(MENU_MODE_STORAGE_KEY) || 'normal') === 'expert';
		} catch (e) {
			return false;
		}
	},

	setMenuExpertMode: function(expert) {
		try {
			localStorage.setItem(MENU_MODE_STORAGE_KEY, expert ? 'expert' : 'normal');
		} catch (e) {
			/* ignore */
		}
	},

	menuItemVisible: function(node) {
		if (!node || !node.visibility)
			return true;
		if (node.visibility === 'expert')
			return this.menuExpertMode();
		if (node.visibility === 'host')
			return false;
		return true;
	},

	walkChildren: function(children, fn, ancestors, depth) {
		if (!children)
			return;

		children.forEach(function(node) {
			fn(node, ancestors, depth);
			if (!this.menuItemVisible(node))
				return;
			if (node.children)
				this.walkChildren(node.children, fn, ancestors.concat([ node ]), depth + 1);
		}, this);
	},

	walkSections: function(manifest, fn, ancestors) {
		var list = (manifest && manifest.sections) || [];
		var path = ancestors || [];

		list.forEach(function(section) {
			if (!this.menuItemVisible(section))
				return;
			fn(section, path, 0);
			this.walkChildren(section.children, fn, path.concat([ section ]), 1);
		}, this);
	},

	isGroup: function(node) {
		return node && Array.isArray(node.children) && node.children.length > 0 &&
			node.type !== 'report' && node.type !== 'wizard' && node.type !== 'invoke';
	},

	isLeaf: function(node) {
		return node && !this.isGroup(node);
	},

	findById: function(manifest, id) {
		var found = null;

		if (!id)
			return null;

		this.walkSections(manifest, function(node) {
			if (node.id === id)
				found = node;
		});

		return found;
	},

	firstLeafId: function(manifest) {
		var id = null;

		this.walkSections(manifest, function(node, ancestors, depth) {
			if (id)
				return;
			if (!this.menuItemVisible(node))
				return;
			if (this.isLeaf(node) && depth > 0)
				id = node.id;
		}.bind(this));

		return id;
	},

	findSectionById: function(manifest, sectionId) {
		var list = (manifest && manifest.sections) || [];

		for (var i = 0; i < list.length; i++)
			if (list[i].id === sectionId)
				return list[i];

		return null;
	},

	findSectionForLeaf: function(manifest, leafId) {
		var found = null;
		var self = this;

		if (!leafId)
			return null;

		(manifest.sections || []).forEach(function(section) {
			if (found)
				return;

			self.walkChildren(section.children, function(node) {
				if (node.id === leafId)
					found = section;
			}, [ section ], 1);
		});

		return found;
	},

	firstLeafInSection: function(section) {
		var id = null;
		var self = this;

		if (!section || !section.children)
			return null;

		this.walkChildren(section.children, function(node, ancestors, depth) {
			if (id)
				return;
			if (!self.menuItemVisible(node))
				return;
			if (self.isLeaf(node) && node.id)
				id = node.id;
		}, [ section ], 1);

		return id;
	},

	formatBreadcrumb: function(ancestors, node) {
		var parts = [];

		(ancestors || []).forEach(function(a) {
			if (a.title)
				parts.push(a.title);
		});
		if (node && node.title)
			parts.push(node.title);

		return parts.join(' → ');
	},

	formatExecReport: function(execResult) {
		var stdout = '';
		var stderr = '';

		if (execResult) {
			stdout = execResult.stdout || '';
			stderr = execResult.stderr || '';
		}

		if (execResult && execResult.code !== 0 && !stdout)
			stdout = _('Не удалось выполнить команду (код %d).').format(execResult.code);

		if (stderr)
			stdout = (stdout ? stdout + '\n' : '') + stderr;

		return (stdout || '').trim() || _('(пусто)');
	},

	cleanTaskStatusOutput: function(text) {
		if (!text) return '';
		var str = String(text);
		var idx = str.indexOf('\n---\n');
		if (idx !== -1) {
			return str.substring(idx + 5);
		}
		if (str.indexOf('---\n') === 0) {
			return str.substring(4);
		}
		return str;
	},

	/**
	 * Кнопка для xfree-dialog (модалка вне #xfree-toolbox-shell — свой CSS).
	 * opts: label, variant (secondary|primary|ghost|danger), compact?, disabled?, className?, click?
	 */
	dialogBtn: function(opts) {
		var o = opts || {};
		var variant = o.variant || 'secondary';
		var cls = [ 'xfree-dialog-btn', 'is-' + variant ];

		if (o.compact)
			cls.push('is-compact');
		if (o.className)
			cls.push(o.className);

		return E('button', {
			'type': 'button',
			'class': cls.join(' '),
			'disabled': o.disabled ? true : null,
			'click': function(ev) {
				if (ev) {
					ev.preventDefault();
					ev.stopPropagation();
				}
				if (typeof o.click === 'function')
					o.click(ev);
			}
		}, [ o.label || '' ]);
	},

	/**
	 * Общий модальный диалог. opts:
	 *   title, hint?, body (node|array), actions [{label, variant, compact, disabled, close, click}],
	 *   size ('md'|'lg'|'wide'), className?
	 * actions.close=true — закрыть после click (по умолчанию для кнопки без click).
	 * return: { hide, actions: [buttonEl…] }
	 */
	openDialog: function(opts) {
		var self = this;
		var o = opts || {};
		var classes = [ 'xfree-dialog', 'xfree-vpn-dialog' ];
		var bodyChildren = [];
		var actionNodes = [];
		var actions = o.actions;
		var i;
		var a;
		var autoClose;
		var btn;

		if (o.size === 'lg' || o.size === 'wide')
			classes.push('xfree-dialog--' + o.size);
		if (o.className)
			classes.push(o.className);

		if (o.hint)
			bodyChildren.push(E('p', { 'class': 'xfree-dialog-hint muted' }, [ o.hint ]));

		if (Array.isArray(o.body)) {
			for (i = 0; i < o.body.length; i++) {
				if (o.body[i])
					bodyChildren.push(o.body[i]);
			}
		} else if (o.body) {
			bodyChildren.push(o.body);
		}

		if (!actions || !actions.length) {
			actions = [{
				label: _('Закрыть'),
				variant: 'secondary',
				close: true
			}];
		}

		for (i = 0; i < actions.length; i++) {
			a = actions[i] || {};
			autoClose = (a.close === true) || (a.close == null && typeof a.click !== 'function');
			btn = self.dialogBtn({
				label: a.label,
				variant: a.variant,
				compact: a.compact,
				disabled: a.disabled,
				className: a.className,
				click: (function(act, doClose) {
					return function(ev) {
						if (doClose)
							ui.hideModal();
						if (typeof act.click === 'function')
							act.click(ev);
					};
				})(a, autoClose)
			});
			actionNodes.push(btn);
		}

		var classList = [ 'cbi-modal' ];
		classes.forEach(function(c) {
			if (!c) return;
			String(c).split(/\s+/).forEach(function(token) {
				if (token && classList.indexOf(token) === -1)
					classList.push(token);
			});
		});

		var modalArgs = [
			o.title || '',
			[
				E('div', { 'class': 'xfree-dialog-body' }, bodyChildren),
				E('div', { 'class': 'xfree-dialog-actions' }, actionNodes)
			]
		].concat(classList);

		ui.showModal.apply(ui, modalArgs);

		return {
			hide: function() {
				ui.hideModal();
			},
			actions: actionNodes
		};
	},

	/**
	 * Модальный диалог подтверждения (Promise<boolean>). opts:
	 *   title, message, detail, tone ('primary'|'warn'|'danger'), confirmText, cancelText, icon
	 */
	confirm: function(opts) {
		var self = this;
		var o = typeof opts === 'string' ? { message: opts } : (opts || {});
		var tone = o.tone || (o.danger ? 'danger' : 'primary');
		var icon = o.icon || (tone === 'danger' ? '⚠️' : (tone === 'warn' ? '⚠️' : '❓'));

		return new Promise(function(resolve) {
			var settled = false;
			var finish = function(val) {
				if (!settled) {
					settled = true;
					ui.hideModal();
					resolve(val);
				}
			};

			var bodyItems = [
				E('div', { 'class': 'xfree-confirm-wrap' }, [
					E('div', { 'class': 'xfree-confirm-icon is-' + tone }, [ icon ]),
					E('div', { 'class': 'xfree-confirm-content' }, [
						E('div', { 'class': 'xfree-confirm-msg' }, [ o.message || _('Вы уверены, что хотите продолжить?') ]),
						o.detail ? E('div', { 'class': 'xfree-confirm-detail is-' + tone }, [ o.detail ]) : ''
					])
				])
			];

			self.openDialog({
				title: o.title || _('Подтверждение'),
				size: 'md',
				className: 'xfree-confirm-dialog',
				body: bodyItems,
				actions: [
					{
						label: o.cancelText || _('Отмена'),
						variant: 'secondary',
						click: function() { finish(false); }
					},
					{
						label: o.confirmText || (tone === 'danger' ? _('Да, выполнить') : _('Подтвердить')),
						variant: tone === 'danger' ? 'danger' : 'primary',
						click: function() { finish(true); }
					}
				]
			});
		});
	},

	/**
	 * Модальный диалог контекстной справки. opts:
	 *   title, desc, whatDoes, tips, hint
	 */
	showHelp: function(opts) {
		var self = this;
		var o = typeof opts === 'string' ? { desc: opts } : (opts || {});
		var title = o.title ? (_('Справка: %s').format(o.title)) : _('Справка');
		var bodyItems = [];

		if (o.desc) {
			bodyItems.push(E('div', { 'class': 'xfree-help-desc' }, [ o.desc ]));
		}
		if (o.whatDoes) {
			bodyItems.push(E('div', { 'class': 'xfree-help-box' }, [
				E('div', { 'class': 'xfree-help-box-title' }, [ '⚙️ ' + _('Что делает действие:') ]),
				E('div', { 'class': 'xfree-help-box-text' }, [ o.whatDoes ])
			]));
		}
		if (o.tips) {
			bodyItems.push(E('div', { 'class': 'xfree-help-box' }, [
				E('div', { 'class': 'xfree-help-box-title' }, [ '💡 ' + _('Совет / Особенности:') ]),
				E('div', { 'class': 'xfree-help-box-text' }, [ o.tips ])
			]));
		}

		self.openDialog({
			title: title,
			size: 'md',
			className: 'xfree-help-dialog',
			hint: o.hint || '',
			body: E('div', { 'class': 'xfree-help-wrap' }, bodyItems),
			actions: [{
				label: _('Понятно'),
				variant: 'primary',
				close: true
			}]
		});
	},

	/**
	 * Кнопка вызова контекстной справки (?).
	 */
	helpBtn: function(opts) {
		var self = this;
		return E('button', {
			'type': 'button',
			'class': 'xfree-help-btn',
			'title': _('Справка и описание'),
			'aria-label': _('Справка'),
			'click': function(ev) {
				if (ev) {
					ev.preventDefault();
					ev.stopPropagation();
				}
				self.showHelp(opts);
			}
		}, [ '?' ]);
	},

	/**
	 * Виджет просмотра и редактирования содержимого текстовых файлов (.lst, .conf и др.)
	 */
	renderFileViewerWidget: function(opts) {
		var o = opts || {};
		var filename = o.filename || o.path || _('Список');
		var initialContent = String(o.content || '').replace(/\r\n/g, '\n');
		var isReadOnly = !!o.readOnly;
		var canEdit = !!o.canEdit && !isReadOnly;
		var canDownload = o.canDownload !== false;
		var canCopy = o.canCopy !== false;

		var countBadge = E('span', {
			'class': 'badge',
			'style': 'font-size: 12px; padding: 2px 8px;'
		});

		function calcLines(val) {
			if (!val || !val.trim()) return 0;
			return val.trim().split('\n').length;
		}

		function updateCount(val) {
			var n = calcLines(val);
			countBadge.textContent = _('%d записей').format(n);
		}

		updateCount(initialContent);

		var topActions = [];
		if (canCopy) {
			topActions.push(E('button', {
				'type': 'button',
				'class': 'btn ghost-compact',
				'style': 'font-size: 12px;',
				'title': _('Скопировать содержимое в буфер обмена'),
				'click': function(ev) {
					ev.preventDefault();
					var txt = ta.value;
					if (navigator.clipboard && navigator.clipboard.writeText) {
						navigator.clipboard.writeText(txt).then(function() {
							ui.addNotification(null, E('p', {}, [ _('Содержимое скопировано в буфер обмена') ]), 'info');
						});
					} else {
						var selTa = document.createElement('textarea');
						selTa.value = txt;
						document.body.appendChild(selTa);
						selTa.select();
						document.execCommand('copy');
						document.body.removeChild(selTa);
						ui.addNotification(null, E('p', {}, [ _('Содержимое скопировано в буфер обмена') ]), 'info');
					}
				}
			}, [ '📋 ' + _('Копировать') ]));
		}

		if (canDownload) {
			topActions.push(E('button', {
				'type': 'button',
				'class': 'btn ghost-compact',
				'style': 'font-size: 12px;',
				'title': _('Скачать файл на компьютер'),
				'click': function(ev) {
					ev.preventDefault();
					var blob = new Blob([ ta.value ], { type: 'text/plain;charset=utf-8' });
					var a = document.createElement('a');
					a.href = URL.createObjectURL(blob);
					a.download = filename.indexOf('.') === -1 ? (filename + '.lst') : filename;
					document.body.appendChild(a);
					a.click();
					document.body.removeChild(a);
					URL.revokeObjectURL(a.href);
				}
			}, [ '💾 ' + _('Скачать') ]));
		}

		var headerNode = E('div', {
			'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
				E('strong', { 'style': 'font-family: monospace; font-size: 14px;' }, [ filename ]),
				countBadge,
				isReadOnly
					? E('span', { 'class': 'badge', 'style': 'background: var(--line); font-size: 11px;' }, [ '🔒 ' + _('Только чтение') ])
					: E('span', { 'class': 'badge', 'style': 'background: var(--ok-soft); color: var(--ok); font-size: 11px;' }, [ '✏️ ' + _('Редактируемый') ])
			]),
			E('div', { 'style': 'display: flex; gap: 6px;' }, topActions)
		]);

		var hintNode = o.hint ? E('p', {
			'class': 'muted',
			'style': 'font-size: 12px; margin: 0 0 8px 0; line-height: 1.4;'
		}, [ o.hint ]) : null;

		var ta = E('textarea', {
			'class': 'cbi-input-textarea',
			'spellcheck': 'false',
			'style': 'width: 100%; min-height: 280px; max-height: 55vh; font-family: monospace; font-size: 13px; line-height: 1.5; padding: 10px; border-radius: 8px; border: 1px solid var(--line); background: var(--panel-2); color: var(--text); resize: vertical; box-sizing: border-box;',
			'placeholder': _('Список пуст. Введите записи по одной на строку…')
		}, [ initialContent ]);

		if (isReadOnly) {
			ta.setAttribute('readonly', 'readonly');
		}

		ta.addEventListener('input', function() {
			updateCount(ta.value);
		});

		var wrapNode = E('div', { 'class': 'xfree-file-viewer-widget' }, [
			headerNode,
			hintNode || '',
			ta
		]);

		return {
			node: wrapNode,
			getText: function() {
				return ta.value;
			},
			setText: function(val) {
				ta.value = String(val || '');
				updateCount(ta.value);
			}
		};
	},

	/**
	 * Диалог прямого просмотра и редактирования списка по тегу или пути
	 */
	showListDialog: function(tagOrPath, title) {
		var self = this;
		var modalContainer = E('div', { 'style': 'min-height: 200px; padding: 10px 0;' }, [
			E('p', { 'class': 'muted', 'style': 'text-align: center; padding: 30px;' }, [ '⏳ ' + _('Загрузка списка…') ])
		]);

		var dlg = self.openDialog({
			title: '📄 ' + (title || _('Просмотр списка')),
			size: 'wide',
			body: modalContainer,
			actions: [{
				label: _('Закрыть'),
				variant: 'default',
				close: true
			}]
		});

		self.runSystemMenu('upstreamsGetList', tagOrPath).then(function(res) {
			if (res && res.error) {
				modalContainer.replaceChildren(E('div', { 'class': 'alert-message danger' }, [
					E('p', {}, [ res.error ])
				]));
				return;
			}

			var files = Array.isArray(res.files) && res.files.length > 0 ? res.files : [{
				path: res.path || tagOrPath,
				filename: (res.path || tagOrPath).split('/').pop(),
				kind: 'other',
				type: 'other',
				label: _('Список'),
				lines: (res.content ? String(res.content).trim().split('\n').length : 0),
				custom: res.custom,
				content: res.content || ''
			}];

			var activeIdx = 0;
			for (var i = 0; i < files.length; i++) {
				if (files[i].type === 'fqdn') {
					activeIdx = i;
					break;
				}
			}

			var currentWidget = null;
			var widgetHost = E('div', { 'class': 'xfree-list-widget-host' });
			var tabButtons = [];
			var tabsBar = null;

			function getTabIcon(f) {
				if (f.type === 'fqdn') return '🌐';
				if (f.type === 'ipv4' || f.type === 'ipv6' || f.type === 'prefix') return '🔢';
				return '📄';
			}

			function updateTabLabel(idx) {
				var f = files[idx];
				var btn = tabButtons[idx];
				if (!f || !btn) return;
				var lines = (typeof f.lines === 'number') ? f.lines : (f.content ? f.content.trim().split('\n').length : 0);
				btn.textContent = getTabIcon(f) + ' ' + (f.label || f.filename) + ' (' + lines + ')';
			}

			function renderActiveTab() {
				var file = files[activeIdx];
				var isCustom = (file.custom === 1);
				var activeContent = (file.stagedContent !== undefined) ? file.stagedContent : (file.content || '');

				currentWidget = self.renderFileViewerWidget({
					path: file.path,
					filename: file.filename,
					content: activeContent,
					readOnly: !isCustom,
					canEdit: isCustom,
					canDownload: true,
					canCopy: true,
					hint: isCustom ?
						('✏️ ' + _('Пользовательский список: редактируйте записи по одной на строку. Изменения сохраняются на роутере.')) :
						('🔒 ' + _('Предустановленный список: только для чтения. Обновляется автоматически при синхронизации источников.'))
				});

				var actionsBar = null;
				if (isCustom) {
					actionsBar = E('div', {
						'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 14px; padding-top: 10px; border-top: 1px solid var(--line);'
					});

					var saveBtn = E('button', {
						'class': 'cbi-button cbi-button-save',
						'type': 'button',
						'click': function() {
							saveBtn.disabled = true;
							saveBtn.textContent = '⏳ ' + _('Сохранение…');
							var newTxt = currentWidget.getText();
							self.runSystemMenu('upstreamsSaveList', file.path, newTxt).then(function(sRes) {
								saveBtn.disabled = false;
								saveBtn.textContent = '💾 ' + _('Сохранить изменения');
								if (sRes && sRes.error) {
									ui.addNotification(null, E('p', {}, [ sRes.error ]), 'danger');
									return;
								}
								file.content = newTxt;
								file.stagedContent = newTxt;
								file.lines = newTxt ? newTxt.trim().split('\n').length : 0;
								updateTabLabel(activeIdx);
								ui.addNotification(null, E('p', {}, [ _('Список «%s» успешно сохранён').format(file.filename) ]), 'info');
							}).catch(function(err) {
								saveBtn.disabled = false;
								saveBtn.textContent = '💾 ' + _('Сохранить изменения');
								ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
							});
						}
					}, [ '💾 ' + _('Сохранить изменения') ]);
					actionsBar.appendChild(saveBtn);
				}

				widgetHost.replaceChildren(currentWidget.node, actionsBar || '');
			}

			function switchTab(newIdx) {
				if (newIdx === activeIdx && widgetHost.hasChildNodes()) return;
				if (currentWidget) {
					files[activeIdx].stagedContent = currentWidget.getText();
				}
				activeIdx = newIdx;
				tabButtons.forEach(function(btn, i) {
					if (i === activeIdx) {
						btn.classList.add('is-active');
					} else {
						btn.classList.remove('is-active');
					}
				});
				renderActiveTab();
			}

			if (files.length > 1) {
				tabsBar = E('div', {
					'class': 'xfree-dialog-tabs',
					'style': 'display: flex; gap: 8px; margin-bottom: 14px; border-bottom: 1px solid var(--line); padding-bottom: 8px; flex-wrap: wrap;'
				});
				files.forEach(function(f, idx) {
					var lines = (typeof f.lines === 'number') ? f.lines : (f.content ? f.content.trim().split('\n').length : 0);
					var tabBtn = E('button', {
						'class': 'xfree-dialog-tab-btn' + (idx === activeIdx ? ' is-active' : ''),
						'type': 'button',
						'style': 'cursor: pointer;',
						'click': function() {
							switchTab(idx);
						}
					}, [ getTabIcon(f) + ' ' + (f.label || f.filename) + ' (' + lines + ')' ]);
					tabButtons.push(tabBtn);
					tabsBar.appendChild(tabBtn);
				});
			}

			renderActiveTab();

			if (tabsBar) {
				modalContainer.replaceChildren(tabsBar, widgetHost);
			} else {
				modalContainer.replaceChildren(widgetHost);
			}
		}).catch(function(err) {
			modalContainer.replaceChildren(E('div', { 'class': 'alert-message danger' }, [
				E('p', {}, [ (err && err.message) ? err.message : String(err) ])
			]));
		});
	},


	/**
	 * Диалог с полным выводом команды + OK.
	 * Пока нет общего интерактива логов — для action-кнопок (и дублирует page-console, если есть).
	 */
	openExecOutputDialog: function(title) {
		var self = this;
		var consoleEl = E('xfree-console', { 'label': _('Вывод') });
		var statusEl = E('p', {
			'class': 'muted xfree-exec-output-status'
		}, [ _('Выполняется…') ]);
		var wrap;
		var okBtn;

		consoleEl.text = _('Выполняется…');

		wrap = self.openDialog({
			title: title || _('Вывод'),
			size: 'wide',
			className: 'xfree-exec-output-dialog',
			body: [ statusEl, consoleEl ],
			actions: [{
				label: _('Принять'),
				variant: 'primary',
				disabled: true,
				close: true
			}]
		});
		okBtn = wrap.actions[0];

		return {
			setText: function(text) {
				consoleEl.text = text == null ? '' : String(text);
			},
			appendText: function(chunk) {
				var cur = consoleEl.text || '';
				var add = chunk == null ? '' : String(chunk);

				if (!add)
					return;
				consoleEl.text = cur ? (cur + '\n' + add) : add;
			},
			setStatus: function(text) {
				statusEl.textContent = text == null ? '' : String(text);
			},
			setDone: function(ok) {
				if (okBtn) {
					okBtn.removeAttribute('disabled');
					okBtn.disabled = false;
				}
				statusEl.textContent = ok
					? _('Готово.')
					: _('Завершено с ошибкой.');
				statusEl.className = 'xfree-exec-output-status ' + (ok ? 'is-ok' : 'is-bad');
			}
		};
	},

	/**
	 * Запуск action с диалогом вывода. opts:
	 *   title, confirm?, root? (setBusy/setOutputText), run()→Promise(res),
	 *   onSuccess?(res), keepOpenOnBg? (не setDone, если STATUS=running)
	 */
	runActionWithOutputDialog: function(opts) {
		var self = this;
		var o = opts || {};
		var dlg;
		var root = o.root;

		var confirmPromise;
		if (o.confirm) {
			var confirmOpts = typeof o.confirm === 'object'
				? o.confirm
				: { message: o.confirm, title: o.title || _('Подтверждение') };
			confirmPromise = self.confirm(confirmOpts);
		} else {
			confirmPromise = Promise.resolve(true);
		}

		return confirmPromise.then(function(confirmed) {
			if (!confirmed)
				return null;

			dlg = self.openExecOutputDialog(o.title || _('Вывод'));
			dlg.setStatus(_('Выполняется…'));
			dlg.setText(_('Выполняется…'));
		if (root && root.setBusy)
			root.setBusy(true);
		if (root && root.setOutputText)
			root.setOutputText(_('Выполняется…'));

		return Promise.resolve()
			.then(function() {
				return typeof o.run === 'function' ? o.run(dlg) : null;
			})
			.then(function(res) {
				var text = self.formatExecReport(res || {});
				var running = self.ifaceTaskRunning(res);
				var ok = !(res && res.code && res.code !== 0);
				var displayText = running ? self.cleanTaskStatusOutput(text) : text;

				dlg.setText(displayText);
				if (root && root.setOutputText)
					root.setOutputText(displayText);

				if (running) {
					dlg.setStatus(_('Операция в фоне — лог обновляется…'));
					if (root && root.setBusy)
						root.setBusy(true);
					return self.pollExecOutputTask(dlg, root, o, 0);
				}

				dlg.setDone(ok);
				if (root && root.setBusy)
					root.setBusy(false);
				if (ok && typeof o.onSuccess === 'function')
					return Promise.resolve(o.onSuccess(res)).then(function() {
						return { res: res, text: displayText, dlg: dlg, running: false, ok: ok };
					});
				return { res: res, text: displayText, dlg: dlg, running: false, ok: ok };
			})
			.catch(function(err) {
				var errMsg = (err && err.message) ? err.message : String(err);
				var isConnDrop = /abort|network|connection\s*reset/i.test(errMsg);

				if (isConnDrop) {
					dlg.setStatus(_('Соединение кратковременно прервано (сервер перезапускается). Ожидание восстановления…'));
					dlg.setText(self.formatExecReport({
						code: 0,
						stdout: _('Связь с роутером временно прервана (вероятно, перезапуск rpcd/веб-сервера).\nВыполняется переподключение и проверка результата…'),
						stderr: ''
					}));
					return self.pollRouterAlive(8, 2000).then(function(alive) {
						if (alive) {
							dlg.setStatus(_('Связь с роутером восстановлена'));
							dlg.setText(_('✓ Роутер снова на связи. Операция завершена.'));
							dlg.setDone(true);
							if (root && root.setBusy)
								root.setBusy(false);
							if (typeof o.onSuccess === 'function') {
								return Promise.resolve(o.onSuccess({ code: 0, stdout: 'reconnected', stderr: '' })).then(function() {
									return { res: { code: 0 }, text: '', dlg: dlg, running: false, ok: true };
								});
							}
							return { res: { code: 0 }, text: '', dlg: dlg, running: false, ok: true };
						}

						var text = self.formatExecReport({
							code: 1,
							stdout: '',
							stderr: errMsg
						});
						dlg.setText(text);
						dlg.setDone(false);
						if (root && root.setOutputText)
							root.setOutputText(text);
						if (root && root.setBusy)
							root.setBusy(false);
						return { res: null, text: text, dlg: dlg, running: false, ok: false, err: err };
					});
				}

				var text = self.formatExecReport({
					code: 1,
					stdout: '',
					stderr: errMsg
				});

				dlg.setText(text);
				dlg.setDone(false);
				if (root && root.setOutputText)
					root.setOutputText(text);
				if (root && root.setBusy)
					root.setBusy(false);
				return { res: null, text: text, dlg: dlg, running: false, ok: false, err: err };
			});
		});
	},

	/**
	 * Ожидание восстановления связи с роутером при перезапуске веб-сервера / rpcd.
	 */
	pollRouterAlive: function(maxAttempts, intervalMs) {
		maxAttempts = maxAttempts || 8;
		intervalMs = intervalMs || 2000;
		var attempt = 0;

		return new Promise(function(resolve) {
			function tryOnce() {
				attempt++;
				L.resolveDefault(fs.stat('/etc/config'), null).then(function(res) {
					if (res) {
						resolve(true);
					} else if (attempt >= maxAttempts) {
						resolve(false);
					} else {
						window.setTimeout(tryOnce, intervalMs);
					}
				}).catch(function() {
					if (attempt >= maxAttempts) {
						resolve(false);
					} else {
						window.setTimeout(tryOnce, intervalMs);
					}
				});
			}
			window.setTimeout(tryOnce, intervalMs);
		});
	},

	/**
	 * Автоматический опрос фоновой задачи с выводом лога в диалог консоли.
	 */
	pollExecOutputTask: function(dlg, root, opts, attempt) {
		var self = this;
		var o = opts || {};
		var n = attempt || 0;

		var pollPromise;
		if (typeof o.pollTaskStatus === 'function') {
			pollPromise = Promise.resolve(o.pollTaskStatus());
		} else if (o.menu === 'zapretMenu') {
			pollPromise = self.runZapretMenu('taskStatus', '');
		} else if (o.menu === 'uplinkMenu') {
			pollPromise = self.runUplinkMenu('taskStatus', '');
		} else if (o.menu === 'systemMenu') {
			pollPromise = self.runSystemMenu('taskStatus', '');
		} else {
			pollPromise = self.runIfaceMenu('taskStatus', '');
		}

		return pollPromise.then(function(res) {
			var text = self.formatExecReport(res);
			var running = self.ifaceTaskRunning(res);
			var last = self.ifaceTaskLastExit(res);
			var cleanText = self.cleanTaskStatusOutput(text);

			if (dlg)
				dlg.setText(cleanText);
			if (root && root.setOutputText)
				root.setOutputText(cleanText);

			if (running) {
				if (dlg)
					dlg.setStatus(_('Операция в фоне — лог обновляется…'));
				if (n >= 180) {
					if (dlg) {
						dlg.setStatus(_('Таймаут ожидания в интерфейсе — задача может продолжать выполняться в фоне.'));
						dlg.setDone(false);
					}
					if (root && root.setBusy)
						root.setBusy(false);
					return { res: res, text: cleanText, dlg: dlg, running: false, ok: false };
				}
				return new Promise(function(resolve) {
					setTimeout(function() {
						resolve(self.pollExecOutputTask(dlg, root, o, n + 1));
					}, 1500);
				});
			}

			var ok = (last == null || last === 0);
			if (dlg)
				dlg.setDone(ok);
			if (root && root.setBusy)
				root.setBusy(false);

			if (ok && typeof o.onSuccess === 'function') {
				return Promise.resolve(o.onSuccess(res)).then(function() {
					return { res: res, text: cleanText, dlg: dlg, running: false, ok: ok };
				});
			}
			return { res: res, text: cleanText, dlg: dlg, running: false, ok: ok };
		}).catch(function(err) {
			var errMsg = (err && err.message) ? err.message : String(err);
			if (n < 180 && /abort|network|connection\s*reset/i.test(errMsg)) {
				return new Promise(function(resolve) {
					setTimeout(function() {
						resolve(self.pollExecOutputTask(dlg, root, o, n + 1));
					}, 1500);
				});
			}
			if (dlg) {
				dlg.appendText('\n' + _('Ошибка опроса статуса: %s').format(errMsg));
				dlg.setDone(false);
			}
			if (root && root.setBusy)
				root.setBusy(false);
			return { res: null, text: '', dlg: dlg, running: false, ok: false, err: err };
		});
	},

	/** Боковое меню: <xfree-nav> (light DOM, table.cbi-section-table). */
	renderNavTreeForSection: function(section, activeId, onSelect, view) {
		var el = E('xfree-nav');

		el.mount({
			xui: this,
			section: section,
			activeId: activeId,
			onSelect: onSelect,
			view: view
		});
		return el;
	},

	updateNavActiveRow: function(pane, leafId) {
		var nav = pane && pane.querySelector ? pane.querySelector('xfree-nav') : null;

		if (nav && nav.setActive)
			nav.setActive(leafId);
	},

	placeholderPanel: function(node, manifest) {
		var ancestors = [];
		var section = null;
		var self = this;
		var el = E('xfree-placeholder');

		this.walkSections(manifest, function(n, path) {
			if (n.id === node.id) {
				ancestors = path;
				if (path.length)
					section = path[0];
			}
		});

		el.mount({
			title: node.title || node.id,
			id: node.id,
			cli: ((section && section.cli) ? section.cli + ' · ' : '') + (node.cli || '—'),
			path: self.formatBreadcrumb(ancestors, node)
		});
		return el;
	},

	/** Лог: custom element <xfree-console> (AMD регистрирует тег, стили в Shadow DOM). */
	consoleOutput: function(text, extraClass) {
		var attrs = { 'label': _('Вывод') };
		var el;

		if (extraClass)
			attrs['class'] = extraClass;
		if (extraClass === 'xfree-report-output')
			attrs.style = '--xfree-console-max-height:70vh';

		el = E('xfree-console', attrs);
		el.text = text || '';
		return el;
	},

	findConsole: function(root) {
		if (root && root.querySelector)
			return root.querySelector('xfree-console');

		return document.querySelector('xfree-console');
	},

	setConsoleText: function(root, text) {
		var inv;
		var report;
		var el;

		if (root && root.querySelector) {
			inv = root.querySelector('xfree-invoke');
			if (inv && inv.setOutput) {
				inv.setOutput(text);
				return;
			}
			report = root.querySelector('xfree-report');
			if (report) {
				report.text = text || '';
				return;
			}
		}

		el = this.findConsole(root);

		if (el)
			el.text = text || '';
	},

	reportPanel: function(title, reportText, view, reloadFn, pollSec, descr) {
		var el = E('xfree-report');

		el.mount({
			title: title,
			text: reportText || '',
			view: view,
			onReload: reloadFn,
			pollSec: pollSec,
			descr: descr || ''
		});
		return el;
	},

	menuPanel: function(spec) {
		var el = E('xfree-menu');

		el.mount(spec || {});
		return el;
	},

	vpnPanel: function(spec) {
		var el = E('xfree-vpn');

		el.mount(spec || {});
		return el;
	},

	zapretPanel: function(spec) {
		var el = E('xfree-zapret');

		el.mount(spec || {});
		return el;
	},

	telemtPanel: function(spec) {
		var el = E('xfree-telemt');

		el.mount(spec || {});
		return el;
	},

	parseTelemtStatus: function(execResult) {
		var text = this.formatExecReport(execResult || {});
		var lines = String(text || '').split(/\n/);
		var out = {
			running: false,
			pid: '',
			enabled: false,
			coreInstalled: false,
			coreVersion: '',
			coreLatestVersion: '',
			coreUpdateAvailable: false,
			luciInstalled: false,
			luciVersion: '',
			luciLatestVersion: '',
			luciUpdateAvailable: false,
			updateAvailable: false,
			port: '8443',
			secret: '',
			secretMasked: '',
			host: '',
			tgLink: '',
			userCount: 0,
			users: [],
			rawOutput: text
		};
		var userMap = {};
		var i, line, kv, k, v, m;

		for (i = 0; i < lines.length; i++) {
			line = lines[i].replace(/\r$/, '').trim();
			if (!line) continue;
			kv = line.split('=');
			if (kv.length >= 2) {
				k = kv[0].trim();
				v = kv.slice(1).join('=').trim().replace(/^"|"$/g, '');
				if (k === 'running') out.running = (v === '1' || v === 'true');
				else if (k === 'pid') out.pid = v;
				else if (k === 'enabled') out.enabled = (v === '1' || v === 'true');
				else if (k === 'core_installed') out.coreInstalled = (v === '1' || v === 'true');
				else if (k === 'core_version') out.coreVersion = v;
				else if (k === 'core_latest_version') out.coreLatestVersion = v;
				else if (k === 'core_update_available') out.coreUpdateAvailable = (v === '1' || v === 'true');
				else if (k === 'luci_installed') out.luciInstalled = (v === '1' || v === 'true');
				else if (k === 'luci_version') out.luciVersion = v;
				else if (k === 'luci_latest_version') out.luciLatestVersion = v;
				else if (k === 'luci_update_available') out.luciUpdateAvailable = (v === '1' || v === 'true');
				else if (k === 'update_available') out.updateAvailable = (v === '1' || v === 'true');
				else if (k === 'port') out.port = v || '8443';
				else if (k === 'secret') out.secret = v;
				else if (k === 'secret_masked') out.secretMasked = v;
				else if (k === 'host') out.host = v;
				else if (k === 'tg_link') out.tgLink = v;
				else if (k === 'user_count') out.userCount = parseInt(v, 10) || 0;
				else {
					m = k.match(/^user_(\d+)_(.+)$/);
					if (m) {
						var idx = parseInt(m[1], 10);
						var prop = m[2];
						if (!userMap[idx]) {
							userMap[idx] = { id: idx, name: '', enabled: true, secret: '', secretMasked: '', link: '', comment: '' };
						}
						if (prop === 'name') userMap[idx].name = v;
						else if (prop === 'enabled') userMap[idx].enabled = (v === '1' || v === 'true');
						else if (prop === 'secret') userMap[idx].secret = v;
						else if (prop === 'secret_masked') userMap[idx].secretMasked = v;
						else if (prop === 'link') userMap[idx].link = v;
						else if (prop === 'comment') userMap[idx].comment = v;
					}
				}
			}
		}

		var userKeys = Object.keys(userMap).map(function(n) { return parseInt(n, 10); }).sort(function(a, b) { return a - b; });
		for (var u = 0; u < userKeys.length; u++) {
			var usr = userMap[userKeys[u]];
			if (usr && (usr.name || usr.secret)) {
				if (!usr.name) usr.name = 'user' + usr.id;
				out.users.push(usr);
			}
		}

		if (out.users.length === 0 && (out.secret || out.tgLink)) {
			out.users.push({
				id: 1,
				name: 'default',
				enabled: true,
				secret: out.secret,
				secretMasked: out.secretMasked,
				link: out.tgLink,
				comment: ''
			});
		}

		if (out.users.length > 0 && !out.userCount) {
			out.userCount = out.users.length;
		}

		out.installed = out.coreInstalled || out.luciInstalled;
		return out;
	},

	parseZapretStatus: function(execResult) {
		var text = this.formatExecReport(execResult || {});
		var lines = String(text || '').split(/\n/);
		var out = {
			running: false,
			installed: false,
			version: '',
			engine: 'zapret',
			pending: false,
			sections: []
		};
		var i, line, parts, j, kv, sec;

		for (i = 0; i < lines.length; i++) {
			line = lines[i].replace(/\r$/, '').trim();
			if (!line) continue;
			if (line.indexOf('STATUS|') === 0) {
				parts = line.substring(7).split('|');
				for (j = 0; j < parts.length; j++) {
					kv = parts[j].split('=');
					if (kv[0] === 'running') out.running = (kv[1] === '1');
					else if (kv[0] === 'installed') out.installed = (kv[1] === '1');
					else if (kv[0] === 'version') out.version = kv[1] || '';
					else if (kv[0] === 'engine') out.engine = kv[1] || 'zapret';
					else if (kv[0] === 'pending') out.pending = (kv[1] === '1');
				}
			} else if (line.indexOf('SECTION|') === 0) {
				sec = { name: '', hosts: 0, enabled: true };
				parts = line.substring(8).split('|');
				for (j = 0; j < parts.length; j++) {
					kv = parts[j].split('=');
					if (kv[0] === 'name') sec.name = kv[1] || '';
					else if (kv[0] === 'hosts') sec.hosts = parseInt(kv[1], 10) || 0;
					else if (kv[0] === 'enabled') sec.enabled = (kv[1] !== '0');
				}
				if (sec.name) out.sections.push(sec);
			}
		}
		return out;
	},

	parseIfaceSummary: function(execResult) {
		var text = this.formatExecReport(execResult || {});
		var lines = String(text || '').split(/\n/);
		var out = {
			ifaces: [],
			confs: [],
			createSlots: [],
			warp: {},
			proton: {},
			count: 0,
			stateOk: 0,
			sourceOk: 0,
			genOk: 0,
			selfRouteHotplug: 0,
			uciNetworks: []
		};
		var i;
		var line;
		var m;
		var parts;
		var j;
		var kv;
		var row;
		var key;
		var val;

		for (i = 0; i < lines.length; i++) {
			line = lines[i].replace(/\r$/, '').trim();
			if (!line || line.indexOf('===') === 0)
				continue;

			m = line.match(/^IFACE=([^|]+)\|(.*)$/);
			if (m) {
				row = {
					name: m[1], work: 0, state: 0, gen: 0, source: 0,
					kind: '', server: '', country: '', city: '', colo: '',
					health: 'unknown', ifaceUp: 0,
					probe: '', proton: '', sess: '', cert: '', dev: '', rtOk: 0, lists: 0,
					selfRouteVia: '', pbrBypass: ''
				};
				parts = m[2].split('|');
				for (j = 0; j < parts.length; j++) {
					kv = parts[j].split('=');
					key = kv[0];
					val = kv.slice(1).join('=');
					if (key === 'work' || key === 'state' || key === 'gen' || key === 'source' ||
						key === 'iface_up' || key === 'rt_ok')
						row[key === 'iface_up' ? 'ifaceUp' : (key === 'rt_ok' ? 'rtOk' : key)] =
							val === '1' ? 1 : 0;
					else if (key === 'lists')
						row.lists = parseInt(val, 10) || 0;
					else if (key === 'kind' || key === 'server' || key === 'country' ||
						key === 'city' || key === 'colo' || key === 'health' ||
						key === 'probe' || key === 'proton' || key === 'sess' ||
						key === 'cert' || key === 'dev' || key === 'self_route_via' ||
						key === 'pbr_bypass')
						row[key === 'self_route_via' ? 'selfRouteVia' : (key === 'pbr_bypass' ? 'pbrBypass' : key)] = val || '';
				}
				out.ifaces.push(row);
				continue;
			}

			m = line.match(/^CONF=([^|]+)\|([^|]+)(?:\|([^|]*))?(?:\|(.*))?$/);
			if (m) {
				out.confs.push({
					kind: m[1],
					file: m[2],
					created: (m[3] || '').trim(),
					usedBy: (m[4] || '').trim()
				});
				continue;
			}

			m = line.match(/^CREATE_SLOT=([^|]+)\|(.*)$/);
			if (m) {
				row = { slot: m[1], kind: '', occupied: 0 };
				parts = m[2].split('|');
				for (j = 0; j < parts.length; j++) {
					kv = parts[j].split('=');
					key = kv[0];
					val = kv.slice(1).join('=');
					if (key === 'kind')
						row.kind = val || '';
					else if (key === 'occupied')
						row.occupied = val === '1' ? 1 : 0;
				}
				out.createSlots.push(row);
				continue;
			}

			m = line.match(/^([A-Z0-9_]+)=(.*)$/);
			if (!m)
				continue;
			key = m[1];
			val = m[2];
			if (key === 'SELF_ROUTE_HOTPLUG')
				out.selfRouteHotplug = parseInt(val, 10) || 0;
			else if (key === 'COUNT')
				out.count = parseInt(val, 10) || 0;
			else if (key === 'STATE_OK')
				out.stateOk = parseInt(val, 10) || 0;
			else if (key === 'SOURCE_OK')
				out.sourceOk = parseInt(val, 10) || 0;
			else if (key === 'GEN_OK')
				out.genOk = parseInt(val, 10) || 0;
			else if (key === 'FREE_WARP_IFACE')
				out.freeWarpIface = val;
			else if (key === 'FREE_PROTON_IFACE')
				out.freeProtonIface = val;
			else if (key.indexOf('WARP_') === 0) {
				if (key === 'WARP_SERVER') out.warp.server = val;
				else if (key === 'WARP_PROFILE') out.warp.profile = val;
				else if (key === 'WARP_MODE') out.warp.mode = val;
				else if (key === 'WARP_I1_MODE') out.warp.i1Mode = val;
				else if (key === 'WARP_I1_DOMAIN') out.warp.i1Domain = val;
				else if (key === 'WARP_NAME') out.warp.name = val;
				else if (key === 'WARP_SELECTION') out.warp.selection = val;
				else if (key === 'WARP_EXCLUDE_RU') out.warp.excludeRu = val;
			}
			else if (key.indexOf('PROTON_') === 0)
				out.proton[key.replace(/^PROTON_/, '').toLowerCase()] = val;
			else if (key === 'UCI_NETWORKS')
				out.uciNetworks = (val || '').trim().split(/\s+/).filter(Boolean);
		}

		if (!out.count)
			out.count = out.ifaces.length;
		return out;
	},

	runUplinkMenu: function(action, arg, settingsJson) {
		var view = this;
		var settings = settingsJson != null ? String(settingsJson) : '';

		return callUplinkMenu(action || '', arg != null ? String(arg) : '', settings).then(function(res) {
			/* getConfig/saveConfig return structured JSON; actions return report envelope. */
			if (action === 'getConfig' || action === 'saveConfig')
				return res || {};
			return view.normalizeReportResult(res, 'uplinkMenu');
		}).catch(function(err) {
			if (action === 'getConfig' || action === 'saveConfig') {
				return {
					code: 1,
					stderr: rpcObjectMissing('uplinkMenu', err),
					settings: {},
					runtime: {}
				};
			}
			return view.normalizeReportResult(null, 'uplinkMenu', err);
		});
	},

	runTelemtMenu: function(action, arg, payload) {
		var view = this;
		var rpcAction = action;
		if (action === 'status') rpcAction = 'telemtStatus';
		else if (action === 'checkUpdate') rpcAction = 'telemtCheckUpdate';
		else if (action === 'install') rpcAction = 'telemtInstall';
		else if (action === 'upgrade') rpcAction = 'telemtUpgrade';
		else if (action === 'service') rpcAction = 'telemtService';

		return callSystemMenu(rpcAction || 'telemtStatus', arg != null ? String(arg) : '', payload != null ? String(payload) : '').then(function(res) {
			return view.normalizeReportResult(res, 'systemMenu');
		}).catch(function(err) {
			return view.normalizeReportResult(null, 'systemMenu', err);
		});
	},

	runZapretMenu: function(action, arg, payload) {
		var view = this;

		return callZapretMenu(action || '', arg != null ? String(arg) : '', payload != null ? String(payload) : '').then(function(res) {
			return view.normalizeReportResult(res, 'zapretMenu');
		}).catch(function(err) {
			return view.normalizeReportResult(null, 'zapretMenu', err);
		});
	},

	runIfaceMenu: function(action, arg) {
		var view = this;

		return callIfaceMenu(action || '', arg != null ? String(arg) : '').then(function(res) {
			return view.normalizeReportResult(res, 'ifaceMenu');
		}).catch(function(err) {
			return view.normalizeReportResult(null, 'ifaceMenu', err);
		});
	},

	runAwgMenu: function(action, arg, payload) {
		var view = this;

		return callAwgMenu(action || '', arg != null ? String(arg) : '', payload != null ? String(payload) : '').then(function(res) {
			return view.normalizeReportResult(res, 'awgMenu');
		}).catch(function(err) {
			return view.normalizeReportResult(null, 'awgMenu', err);
		});
	},

	parseAwgStatus: function(stdout) {
		var text = (stdout && typeof stdout === 'object') ? (stdout.stdout != null ? stdout.stdout : (stdout.report != null ? stdout.report : '')) : stdout;
		var lines = String(text || '').split(/\r?\n/);
		var out = {
			installed: false,
			version: '',
			iface: 'awg_ingress',
			addr: '',
			port: '51820',
			running: false,
			pubkey: '',
			defaultEndpoint: '',
			obfuscation: '',
			vkInstalled: false,
			vkRunning: false,
			vkPort: '3478',
			peers: [],
			endpointChoices: []
		};
		var i, line, m, k, v, p, ep;
		for (i = 0; i < lines.length; i++) {
			line = lines[i].trim();
			if (!line) continue;
			m = line.match(/^([^=]+)=(.*)$/);
			if (!m) continue;
			k = m[1];
			v = m[2];
			if (k === 'SERVER_INSTALLED') out.installed = (v === '1');
			else if (k === 'AWG_VERSION') out.version = v;
			else if (k === 'SERVER_IFACE') out.iface = v;
			else if (k === 'SERVER_ADDR') out.addr = v;
			else if (k === 'SERVER_PORT') out.port = v;
			else if (k === 'SERVER_RUNNING') out.running = (v === '1');
			else if (k === 'SERVER_PUBKEY') out.pubkey = v;
			else if (k === 'DEFAULT_ENDPOINT') out.defaultEndpoint = v;
			else if (k === 'OBFUSCATION') out.obfuscation = v;
			else if (k === 'WAN_IP') out.wanIp = v;
			else if (k === 'VKTURN_INSTALLED') out.vkInstalled = (v === '1');
			else if (k === 'VKTURN_RUNNING') out.vkRunning = (v === '1');
			else if (k === 'VKTURN_PORT') out.vkPort = v;
			else if (k === 'FREETURN_INSTALLED') out.freeTurnInstalled = (v === '1');
			else if (k === 'FREETURN_RUNNING') out.freeTurnRunning = (v === '1');
			else if (k === 'FREETURN_PORT') out.freeTurnPort = v;
			else if (k === 'FREETURN_VERSION') out.freeTurnVersion = v;
			else if (k === 'FREETURN_OBF_PROFILE') out.freeTurnObfProfile = v;
			else if (k === 'FREETURN_OBF_KEY') out.freeTurnObfKey = v;
			else if (k === 'PEER') {
				p = v.split('|');
				out.peers.push({
					slug: p[0] || '',
					name: p[1] || p[0] || '',
					ip: p[2] || '',
					pubkey: p[3] || '',
					endpoint: p[4] || '',
					latestHandshake: parseInt(p[5] || '0', 10) || 0,
					rxBytes: parseInt(p[6] || '0', 10) || 0,
					txBytes: parseInt(p[7] || '0', 10) || 0,
					keepalive: parseInt(p[8] || '25', 10) || 25
				});
			} else if (k === 'ENDPOINT_CHOICE') {
				ep = v.split('|');
				out.endpointChoices.push({
					id: ep[0] || '',
					label: ep[1] || ep[0] || '',
					endpoint: ep[2] || ''
				});
			}
		}
		return out;
	},

	parseNatCheck: function(stdout) {
		var text = (stdout && typeof stdout === 'object') ? (stdout.stdout != null ? stdout.stdout : (stdout.report != null ? stdout.report : '')) : stdout;
		var lines = String(text || '').split(/\r?\n/);
		var out = {
			wanIp4: '',
			wanIp6: '',
			extIp4: '',
			extIp6: '',
			natType: 'unknown',
			statusCode: 'warning',
			message: ''
		};
		var i, m;
		for (i = 0; i < lines.length; i++) {
			m = lines[i].trim().match(/^([^=]+)=(.*)$/);
			if (!m) continue;
			if (m[1] === 'WAN_IPV4') out.wanIp4 = m[2];
			else if (m[1] === 'WAN_IPV6') out.wanIp6 = m[2];
			else if (m[1] === 'EXT_IPV4') out.extIp4 = m[2];
			else if (m[1] === 'EXT_IPV6') out.extIp6 = m[2];
			else if (m[1] === 'NAT_TYPE') out.natType = m[2];
			else if (m[1] === 'STATUS_CODE') out.statusCode = m[2];
			else if (m[1] === 'MESSAGE') out.message = m[2];
		}
		return out;
	},

	parseProtocolsStatus: function(stdout) {
		var text = (stdout && typeof stdout === 'object') ? (stdout.stdout != null ? stdout.stdout : (stdout.report != null ? stdout.report : '')) : stdout;
		var lines = String(text || '').split(/\r?\n/);
		var out = {
			awg: 'Не установлен',
			awg_version: '',
			awg_update: '0',
			openvpn: 'Не установлен',
			vless: 'Не установлен',
			freeturn: 'Не установлен'
		};
		var i, m;
		for (i = 0; i < lines.length; i++) {
			m = lines[i].trim().match(/^([^=]+)=(.*)$/);
			if (!m) continue;
			if (m[1] === 'AWG') out.awg = m[2];
			else if (m[1] === 'AWG_VERSION') out.awg_version = m[2];
			else if (m[1] === 'AWG_UPDATE') out.awg_update = m[2];
			else if (m[1] === 'OPENVPN') out.openvpn = m[2];
			else if (m[1] === 'VLESS') out.vless = m[2];
			else if (m[1] === 'FREETURN') out.freeturn = m[2];
		}
		return out;
	},

	ifaceTaskRunning: function(execResult) {
		var text = String((execResult && execResult.stdout) || '');

		return /^STATUS=(running|already_running)/m.test(text);
	},

	ifaceTaskLastExit: function(execResult) {
		var text = String((execResult && execResult.stdout) || '');
		var m = text.match(/^LAST_EXIT=(\d+)/m);

		if (!m)
			return null;
		return parseInt(m[1], 10);
	},

	runSystemMenu: function(action, arg, payload) {
		var view = this;

		return callSystemMenu(action || '', arg != null ? String(arg) : '', payload != null ? String(payload) : '').then(function(res) {
			return view.normalizeReportResult(res, 'systemMenu');
		}).catch(function(err) {
			return view.normalizeReportResult(null, 'systemMenu', err);
		});
	},

	loadUplinkConfig: function() {
		return this.runUplinkMenu('getConfig', '', '');
	},

	saveUplinkConfig: function(settings) {
		var json;

		try {
			json = JSON.stringify(settings || {});
		} catch (e) {
			json = '{}';
		}

		return this.runUplinkMenu('saveConfig', '', json);
	},

	uplinkPanel: function(spec) {
		var el = E('xfree-uplink');

		el.mount(spec || {});
		return el;
	},

	upstreamsPanel: function(spec) {
		var el = E('xfree-upstreams');

		el.mount(spec || {});
		return el;
	},

	loadNamedReport: function(name) {
		return this.loadReportApi('report', name);
	},

	normalizeReportResult: function(res, method, err) {
		if (err) {
			return {
				code: 1,
				stdout: '',
				stderr: rpcObjectMissing(method, err)
			};
		}

		var out = (res && typeof res === 'object') ? Object.assign({}, res) : {};
		out.code = (res && res.code != null) ? res.code : 0;
		out.stdout = (res && (res.stdout != null ? res.stdout : res.report)) || '';
		out.stderr = (res && res.stderr) || '';
		return out;
	},

	loadReportApi: function(api, reportName) {
		var view = this;

		if (api === 'hostResources') {
			return callHostResources().then(function(res) {
				return view.normalizeReportResult(res, 'hostResources');
			}).catch(function(err) {
				return view.normalizeReportResult(null, 'hostResources', err);
			});
		}

		if (api === 'report') {
			return callReport(reportName || '').then(function(res) {
				return view.normalizeReportResult(res, 'report');
			}).catch(function(err) {
				return view.normalizeReportResult(null, 'report', err);
			});
		}

		return Promise.reject(new Error('unknown report api: ' + api));
	},

	loadReport: function(node) {
		if (node && node.api === 'report')
			return this.loadReportApi('report', node.report || node.id);

		if (node && node.api)
			return this.loadReportApi(node.api);

		/* Prefer ubus report over fs.exec — cgi-io /bin/sh is not in ACL. */
		if (node && node.script)
			return this.loadReportApi('report', node.report || node.id).catch(function() {
				return fs.exec('/bin/sh', [ node.script ]);
			});

		return Promise.reject(new Error('report node needs api or script'));
	},

	wizardStepById: function(node, stepId) {
		var steps = (node && node.steps) || [];

		for (var i = 0; i < steps.length; i++)
			if (steps[i].id === stepId)
				return steps[i];

		return steps[0] || null;
	},

	wizardMeta: function(node) {
		var steps = (node && node.steps) || [];
		var target = 'iface';
		var mode = 'all';
		var i;

		for (i = 0; i < steps.length; i++) {
			if (steps[i].target)
				target = steps[i].target;
			if (steps[i].component === 'upstreams-checklist' && steps[i].mode)
				mode = steps[i].mode;
		}

		return { target: target, mode: mode };
	},

	wizardScopeNoun: function(target) {
		switch (target) {
		case 'dns':
			return _('DNS');
		case 'zapret':
			return _('секция');
		default:
			return _('туннель');
		}
	},

	wizardEmptyHint: function(target, bootstrapError) {
		if (bootstrapError)
			return bootstrapError;

		switch (target) {
		case 'dns':
			return _('нет DNS-инстансов (https-dns-proxy и profiles/…/dns-routing/dns/).');
		case 'zapret':
			return _('нет секций Zapret (profiles/…/zapret/sections/).');
		default:
			return _('нет доменных интерфейсов (profiles/…/iface-routing/interfaces/).');
		}
	},

	wizardEmptyAction: function(target) {
		switch (target) {
		case 'dns':
			return _('Нужен https-dns-proxy (CLI: «DNS для сайтов» → установить / копировать конфигурацию).');
		case 'zapret':
			return _('Создайте секцию в CLI (раздел «Обход блокировок») или проверьте BASE_DIR в ui.conf.');
		default:
			return _('Создайте интерфейс в CLI (раздел «Интерфейсы») или проверьте BASE_DIR в ui.conf.');
		}
	},

	wizardTabsHint: function(target) {
		switch (target) {
		case 'dns':
			return _('вкладки: DNS; внутри — списки upstream (как пункты подменю в CLI).');
		case 'zapret':
			return _('вкладки: секции; внутри — списки upstream. Исключения — только в CLI.');
		default:
			return _('вкладки: туннели; внутри — списки upstream (как пункты подменю в CLI).');
		}
	},

	wizardSupportsScope: function(node) {
		var steps = (node && node.steps) || [];
		var i;

		for (i = 0; i < steps.length; i++) {
			if (steps[i].component === 'domain-interface-select')
				return true;
		}

		return false;
	},

	wizardInterfacesFromResponse: function(res) {
		/* ubus code 5 (no data) arrives as a bare number when rpcd exits before JSON. */
		if (typeof res === 'number')
			throw new Error(_('ubus %s').format(res));

		if (Array.isArray(res))
			res = (res[0] && typeof res[0] === 'object') ? res[0] : res[1];

		/* Backend: selection_json_ok_scopes → "scopes"; alias → "interfaces". */
		if (res && res.code !== 0 && res.code != null)
			throw new Error(res.stderr || _('Ошибка загрузки интерфейсов'));

		var list = (res && (res.scopes || res.interfaces)) || [];

		if (list && !Array.isArray(list) && typeof list === 'object')
			list = Object.keys(list).map(function(k) { return list[k]; });

		return Array.isArray(list) ? list : [];
	},

	parseWizardModelResponse: function(res, methodName) {
		if (typeof res === 'number' || !res)
			return Promise.reject(new Error(_('Нет ответа от rpcd (%s).').format(methodName)));

		if (res.code !== 0 && res.code != null)
			return Promise.reject(new Error(res.stderr || _('Ошибка загрузки списков')));

		return res;
	},

	loadWizardBootstrap: function(node) {
		if (!this.wizardSupportsScope(node))
			return Promise.resolve({ interfaces: [], models: {} });

		var self = this;
		var meta = this.wizardMeta(node);

		var fromLegacy = function() {
			return callListDomainInterfaces().then(function(res) {
				return { interfaces: self.wizardInterfacesFromResponse(res), models: {} };
			});
		};

		return callUpstreamSelection('listScopes', meta.target, '-', '-', '').then(function(res) {
			return { interfaces: self.wizardInterfacesFromResponse(res), models: {} };
		}).catch(function(err) {
			if (meta.target !== 'iface') {
				return {
					interfaces: [],
					models: {},
					bootstrapError: rpcObjectMissing('upstreamSelection', err)
				};
			}

			return fromLegacy().catch(function() {
				return {
					interfaces: [],
					models: {},
					bootstrapError: rpcObjectMissing('upstreamSelection', err)
				};
			});
		});
	},

	loadWizardModel: function(node, scope) {
		if (!scope)
			return Promise.resolve(null);

		var self = this;
		var meta = this.wizardMeta(node);

		return callUpstreamSelection('get', meta.target, scope, meta.mode, '').then(function(res) {
			return self.parseWizardModelResponse(res, 'upstreamSelection');
		}).catch(function(err) {
			if (meta.target !== 'iface')
				return Promise.reject(err instanceof Error ? err : new Error(String(err)));

			return callIfaceUpstreamSelection('get', scope, '').then(function(res) {
				return self.parseWizardModelResponse(res, 'ifaceUpstreamSelection');
			});
		});
	},

	wizardSaveOk: function(res) {
		return !!(res && typeof res === 'object' && res.code === 0);
	},

	saveUpstreamTags: function(target, scope, mode, tags) {
		var self = this;
		var t = target || 'iface';
		var m = mode || (t === 'dns' ? 'fqdn_only' : 'all');
		var payload = JSON.stringify({ tags: tags || [] });

		return callUpstreamSelection('save', t, scope, m, payload).then(function(res) {
			if (!self.wizardSaveOk(res))
				return Promise.reject(new Error((res && res.stderr) || _('Ошибка сохранения')));

			return res;
		}).catch(function(err) {
			if (t !== 'iface')
				return Promise.reject(err instanceof Error ? err : new Error(String(err)));

			return callIfaceUpstreamSelection('save', scope, payload).then(function(res) {
				if (!self.wizardSaveOk(res))
					return Promise.reject(new Error((res && res.stderr) || _('Ошибка сохранения')));

				return res;
			});
		});
	},

	saveWizardSelection: function(node, scope, tags) {
		var meta = this.wizardMeta(node);

		return this.saveUpstreamTags(meta.target, scope, meta.mode, tags);
	},

	routingWizardNode: function(target) {
		var t = target || 'iface';
		var mode = t === 'dns' ? 'fqdn_only' : 'all';
		var id = t === 'iface' ? 'routing.vpn' : (t === 'dns' ? 'routing.dns' : 'zapret.lists');

		return {
			id: id,
			title: t === 'dns' ? _('Списки для DNS')
				: (t === 'zapret' ? _('Списки для Zapret') : _('Списки для VPN')),
			steps: [
				{ id: 'scope', component: 'domain-interface-select', target: t },
				{ id: 'lists', component: 'upstreams-checklist', target: t, mode: mode }
			]
		};
	},

	routingKindLabel: function(target) {
		switch (target) {
		case 'dns':
			return _('DNS');
		case 'zapret':
			return _('Zapret');
		default:
			return _('VPN');
		}
	},

	loadRoutingScopeList: function(target) {
		var self = this;

		return callUpstreamSelection('listScopes', target, '-', '-', '').then(function(res) {
			return self.wizardInterfacesFromResponse(res);
		}).catch(function(err) {
			if (target !== 'iface')
				return [];

			return callListDomainInterfaces().then(function(res) {
				return self.wizardInterfacesFromResponse(res);
			}).catch(function() {
				return [];
			});
		});
	},

	buildRoutingColumns: function(ifaceScopes, dnsScopes, zapretScopes) {
		var cols = [];
		var push = function(target, row) {
			var id = row.id || row.label || '';
			var label = row.label || id;

			if (!id)
				return;
			cols.push({
				key: target + ':' + id,
				target: target,
				scope: id,
				label: label,
				mode: target === 'dns' ? 'fqdn_only' : 'all',
				kind: this.routingKindLabel(target)
			});
		}.bind(this);

		(ifaceScopes || []).forEach(function(r) { push('iface', r); });
		(dnsScopes || []).forEach(function(r) { push('dns', r); });
		(zapretScopes || []).forEach(function(r) { push('zapret', r); });
		return cols;
	},

	parseRoutingSelection: function(parts) {
		var tab = (parts && parts.tab) || 'general';
		var panel = (parts && parts.panel) || '';
		var target;

		if (!tab || tab === 'general')
			return { view: 'general' };

		if (tab === 'vpn')
			target = 'iface';
		else if (tab === 'dns' || tab === 'zapret')
			target = tab;
		else if (tab === 'exclude')
			return { view: 'exclude', tab: 'exclude' };
		else
			return { view: 'general' };

		if (panel)
			return { view: 'scope', target: target, scope: panel, tab: tab };

		return { view: 'kind', target: target, tab: tab };
	},

	loadRoutingMatrix: function(isExclude) {
		var self = this;
		var action = isExclude ? 'matrix-exclude' : 'matrix';

		return callUpstreamSelection(action, '-', '-', '-', '').then(function(res) {
			if (typeof res === 'number' || !res)
				return Promise.reject(new Error(_('Нет ответа matrix')));
			if (res.code !== 0 && res.code != null)
				return Promise.reject(new Error(res.stderr || _('Ошибка matrix')));
			return {
				isExclude: !!isExclude,
				columns: Array.isArray(res.columns) ? res.columns : [],
				items: Array.isArray(res.items) ? res.items : [],
				checked: (res.checked && typeof res.checked === 'object') ? res.checked : {},
				modelsByKey: {},
				sel: { view: isExclude ? 'exclude' : 'general' }
			};
		});
	},

	loadRoutingHub: function(view, sel, isExclude) {
		var self = this;
		var want = sel || { view: isExclude ? 'exclude' : 'general' };
		var excludeMode = (isExclude !== undefined) ? isExclude : (want && (want.view === 'exclude' || want.tab === 'exclude'));

		return self.loadRoutingMatrix(excludeMode).then(function(hub) {
			hub.sel = want;
			return hub;
		}).catch(function(err) {
			return {
				isExclude: !!excludeMode,
				columns: [],
				items: [],
				checked: {},
				modelsByKey: {},
				sel: want,
				error: (err && err.message) ? err.message : String(err)
			};
		});
	},

	routingPanel: function(spec) {
		var el = E('xfree-routing');

		el.mount(spec || {});
		return el;
	},

	initWizardTabs: function(root, view, node, activeIfaceId) {
		var self = this;

		if (!root)
			return;

		if (root.getAttribute('data-xfree-wizard-tabs') === 'true') {
			requestAnimationFrame(function() {
				self.layoutWizardPaneHeights(root);
			});
			return;
		}

		var group = root.querySelector('[data-xfree-wizard-tab-group]');
		var panes = group ? group.querySelectorAll(':scope > [data-tab]') : [];

		if (!panes.length)
			return;

		ui.tabs.initTabGroup(panes);

		panes.forEach(function(pane) {
			var ifaceId = pane.getAttribute('data-iface-id') || pane.getAttribute('data-tab');

			if (ifaceId === activeIfaceId)
				pane.setAttribute('data-tab-active', 'true');
			else
				pane.removeAttribute('data-tab-active');

			pane.addEventListener('cbi-tab-active', function() {
				view._xfreeWizardActiveIface = ifaceId;
				self.onWizardIfaceTabActivate(node, view, ifaceId, root);
			});
		});

		root.setAttribute('data-xfree-wizard-tabs', 'true');
		self.bindWizardPaneLayout(root);

		requestAnimationFrame(function() {
			self.layoutWizardPaneHeights(root);
		});
	},

	/** Высота прокрутки = от верха списка до footer (без налезания). */
	layoutWizardPaneHeights: function(root) {
		if (!root || typeof window === 'undefined')
			return;

		root.querySelectorAll('.xfree-wizard-pane').forEach(function(pane) {
			var scroll = pane.querySelector('.xfree-wizard-pane-scroll');
			var footer = pane.querySelector('.xfree-wizard-pane-footer');
			var head = pane.querySelector('.xfree-wizard-pane-head');
			var headH;
			var footerH;
			var paneTop;
			var maxH;

			if (!scroll || !footer)
				return;

			headH = head ? head.getBoundingClientRect().height : 0;
			footerH = footer.getBoundingClientRect().height;
			paneTop = pane.getBoundingClientRect().top;
			maxH = window.innerHeight - paneTop - headH - footerH - 16;

			scroll.style.maxHeight = Math.max(96, Math.floor(maxH)) + 'px';
			scroll.style.overflowY = 'auto';
		});
	},

	bindWizardPaneLayout: function(root) {
		var self = this;
		var onResize;

		if (!root || root.getAttribute('data-xfree-layout-bound') === 'true')
			return;

		onResize = function() {
			self.layoutWizardPaneHeights(root);
		};

		window.addEventListener('resize', onResize);
		root.setAttribute('data-xfree-layout-bound', 'true');
		root._xfreeLayoutResize = onResize;
	},

	wizardActiveIface: function(view, wizardData) {
		var list = (wizardData && wizardData.interfaces) || view._xfreeWizardInterfaces || [];
		var prefer = (view && view._xfreeWizardActiveIface) || '';
		var i;
		var id;

		if (!list.length)
			return '';

		/* Prefer deep-link / last tab only when it still exists in scopes. */
		if (prefer) {
			for (i = 0; i < list.length; i++) {
				id = list[i].id || list[i].label || '';
				if (id === prefer)
					return prefer;
			}
		}

		return list[0].id || list[0].label || '';
	},

	wizardModelForIface: function(view, iface, wizardData) {
		var models = (wizardData && wizardData.models) || view._xfreeWizardModels || {};

		return models[iface] || null;
	},

	onWizardIfaceTabActivate: function(node, view, iface, root) {
		var self = this;

		if (!iface || !root)
			return;

		if (self.wizardModelForIface(view, iface)) {
			requestAnimationFrame(function() {
				self.layoutWizardPaneHeights(root);
			});
			return;
		}

		var pane = root.querySelector('[data-iface-id="' + iface + '"]');

		if (pane)
			dom.content(pane, E('div', { 'class': 'cbi-section-descr' }, [ _('Загрузка списков…') ]));

		self.loadWizardModel(node, iface).then(function(model) {
			if (!view._xfreeWizardModels)
				view._xfreeWizardModels = {};

			view._xfreeWizardModels[iface] = model;

			if (pane)
				dom.content(pane, self.renderWizardListsPane(node, view, iface, model));

			requestAnimationFrame(function() {
				self.layoutWizardPaneHeights(root);
			});
		}).catch(function(err) {
			if (pane) {
				dom.content(pane, E('div', { 'class': 'cbi-section-descr' }, [
					(err && err.message) || String(err)
				]));
			}
		});
	},

	wizardChecklistInputId: function(iface, tag) {
		return 'xfree-up-' + String(iface || 'iface') + '-' +
			String(tag || 'tag').replace(/[^a-zA-Z0-9_-]/g, '_');
	},

	listItemTitle: function(item) {
		if (item.service)
			return item.service;
		if (item.group)
			return item.group;
		return item.label || item.tag || '';
	},

	listItemKindLabel: function(kind) {
		switch (kind) {
		case 'fqdn':
			return _('имена');
		case 'prefix':
			return _('сети');
		case 'fqdn+prefix':
			return _('имена + сети');
		default:
			return '';
		}
	},

	listItemMeta: function(item) {
		var bits = [];
		var kind = this.listItemKindLabel(item.kind);

		if (item.level === 'group')
			bits.push(_('группа'));
		if (kind)
			bits.push(kind);
		if (item.service && item.group)
			bits.push(item.group);
		if (item.source)
			bits.push(item.source);

		return bits.join(' · ');
	},

	listItemHaystack: function(item) {
		return [
			item.tag, item.label, item.source, item.group, item.service, item.kind
		].join(' ').toLowerCase();
	},

	groupListItems: function(items) {
		var groups = [];
		var index = {};
		var i;
		var item;
		var key;
		var g;

		for (i = 0; i < items.length; i++) {
			item = items[i];
			key = item.source || _('Прочее');
			if (!Object.prototype.hasOwnProperty.call(index, key)) {
				index[key] = groups.length;
				groups.push({ source: key, items: [] });
			}
			g = groups[index[key]];
			g.items.push(item);
		}

		return groups;
	},

	bindListPickerFilter: function(pane) {
		var input = pane ? pane.querySelector('[data-xfree-list-filter]') : null;
		var countEl = pane ? pane.querySelector('[data-xfree-list-count]') : null;

		if (!pane || pane.getAttribute('data-xfree-list-bound') === 'true')
			return;

		var apply = function() {
			var q = input ? String(input.value || '').trim().toLowerCase() : '';
			var visible = 0;
			var checked = 0;
			var total = 0;
			var matrix = pane.getAttribute('data-xfree-routing-matrix') === '1';

			pane.querySelectorAll('[data-xfree-list-row]').forEach(function(row) {
				var hay = (row.getAttribute('data-xfree-haystack') || '').toLowerCase();
				var show = !q || hay.indexOf(q) !== -1;
				var rowChecked = false;

				row.style.display = show ? '' : 'none';
				row.classList.toggle('is-hidden', !show);
				total++;
				if (matrix) {
					row.querySelectorAll('input[data-matrix-tag]').forEach(function(el) {
						if (el.checked)
							rowChecked = true;
					});
				} else if (row.querySelector('input[data-upstream-tag]:checked')) {
					rowChecked = true;
				}
				if (rowChecked)
					checked++;
				if (show)
					visible++;
			});

			pane.querySelectorAll('[data-xfree-list-group]').forEach(function(sec) {
				var any = false;

				sec.querySelectorAll('[data-xfree-list-row]').forEach(function(row) {
					if (row.style.display !== 'none')
						any = true;
				});
				sec.style.display = any ? '' : 'none';
			});

			if (countEl) {
				countEl.textContent = q
					? _('Выбрано %s, на экране %s из %s').format(checked, visible, total)
					: _('Выбрано %s из %s').format(checked, total);
			}
		};

		if (input) {
			input.addEventListener('input', apply);
			input.addEventListener('keydown', function(ev) {
				if (ev.key === 'Enter' || ev.which === 13)
					ev.preventDefault();
			});
		}

		pane.querySelectorAll('input[data-upstream-tag], input[data-matrix-tag]').forEach(function(cb) {
			cb.addEventListener('change', apply);
		});

		pane.setAttribute('data-xfree-list-bound', 'true');
		apply();
	},

	/** Группы-источники: строка = галочка + название + мета (как плитка статуса). */
	buildWizardChecklistRows: function(items, iface) {
		var self = this;
		var rows = [];
		var rowIndex = 0;

		items.forEach(function(item) {
			var tag = item.tag || '';
			var title = self.listItemTitle(item);
			var meta = self.listItemMeta(item);
			var style = (rowIndex++ % 2) ? 'cbi-rowstyle-2' : 'cbi-rowstyle-1';
			var inputId = self.wizardChecklistInputId(iface, tag);
			var labelKids = [
				E('div', { 'class': 'xfree-list-tile-title' }, [
					E('a', {
						'href': '#',
						'class': 'xfree-list-tile-name is-clickable',
						'title': _('Просмотреть содержимое списка'),
						'style': 'cursor: pointer; text-decoration: underline dotted; font-weight: 500;',
						'click': function(ev) {
							ev.preventDefault();
							ev.stopPropagation();
							self.showListDialog(tag, title);
						}
					}, [ title ]),
					E('button', {
						'type': 'button',
						'class': 'cbi-button cbi-button-neutral xfree-list-view-btn',
						'title': _('Просмотреть список'),
						'style': 'margin-left: 6px; padding: 1px 5px; font-size: 11px; vertical-align: middle; line-height: 1.2;',
						'click': function(ev) {
							ev.preventDefault();
							ev.stopPropagation();
							self.showListDialog(tag, title);
						}
					}, [ '👁️' ]),
					item.source ? E('span', {
						'class': 'xfree-matrix-source-badge',
						'title': _('Источник (upstream): ') + item.source
					}, [ item.source ]) : ''
				])
			];

			if (meta)
				labelKids.push(E('div', { 'class': 'cbi-value-description' }, [ meta ]));

			rows.push(E('tr', {
				'class': 'tr ' + style,
				'data-xfree-list-row': '1',
				'data-xfree-haystack': self.listItemHaystack(item)
			}, [
				E('td', { 'class': 'td xfree-checklist-cb' }, [
					E('input', {
						'type': 'checkbox',
						'id': inputId,
						'data-upstream-tag': tag,
						'data-iface-id': iface,
						'checked': item.checked ? true : null
					})
				]),
				E('td', { 'class': 'td xfree-checklist-label' }, [
					E('label', { 'for': inputId }, labelKids)
				])
			]));
		});

		return rows;
	},

	renderWizardListsPane: function(node, view, iface, model) {
		var self = this;
		var items = (model && model.items) || [];
		var groups;
		var sections = [];
		var pane;

		if (!iface) {
			return E('div', { 'class': 'cbi-section-descr' }, [
				_('Нет выбранного контекста.')
			]);
		}

		if (!items.length) {
			return E('div', { 'class': 'cbi-section-descr' }, [
				model && model.stderr
					? model.stderr
					: _('Нет upstream-списков для «%s» (проверьте upstreams/ и ui.conf).').format(iface)
			]);
		}

		groups = self.groupListItems(items);
		groups.forEach(function(g) {
			sections.push(E('div', {
				'class': 'cbi-section xfree-list-group',
				'data-xfree-list-group': g.source
			}, [
				E('h3', {}, [ g.source ]),
				E('table', { 'class': 'table cbi-section-table' },
					self.buildWizardChecklistRows(g.items, iface))
			]));
		});

		pane = E('div', {
			'class': 'cbi-section-node xfree-upstream-checklist xfree-wizard-pane',
			'data-iface-pane': iface
		}, [
			E('div', { 'class': 'cbi-section-descr xfree-wizard-pane-head' }, [
				E('div', {}, [
					_('Те же списки, что в CLI (xft). «Сохранить» — в профиль; «Применить» — runtime (nft/dnsmasq).')
				]),
				E('div', { 'class': 'cbi-value xfree-list-filter-bar' }, [
					E('div', { 'class': 'xfree-list-filter-wrap' }, [
						E('input', {
							'type': 'search',
							'class': 'cbi-input-text xfree-list-filter',
							'placeholder': _('Найти сервис, группу или источник…'),
							'data-xfree-list-filter': '1'
						})
					])
				]),
				E('div', {
					'class': 'cbi-value-description',
					'data-xfree-list-count': '1'
				}, [ '' ])
			]),
			E('div', { 'class': 'xfree-wizard-pane-scroll' }, sections),
			E('div', { 'class': 'xfree-wizard-pane-footer' }, [
				E('div', { 'class': 'cbi-page-actions right' }, [
					E('button', {
						'class': 'cbi-button cbi-button-save',
						'click': ui.createHandlerFn(view, function() {
							self.onWizardSave(node, view, iface);
						})
					}, [ _('Сохранить выбор') ]),
					E('button', {
						'class': 'cbi-button cbi-button-apply important',
						'click': ui.createHandlerFn(view, function() {
							self.onWizardApply(node, view, iface);
						})
					}, [ _('Применить') ])
				]),
				E('div', {
					'class': 'cbi-section-descr xfree-wizard-status',
					'data-iface-status': iface
				}, [ (view._xfreeWizardStatus && view._xfreeWizardStatusIface === iface)
					? view._xfreeWizardStatus : '' ])
			])
		]);

		requestAnimationFrame(function() {
			self.bindListPickerFilter(pane);
		});

		return pane;
	},

	wizardCheckedTags: function(root, iface) {
		var pane = root ? root.querySelector('[data-iface-pane="' + iface + '"]') : null;
		var inputs = pane
			? pane.querySelectorAll('input[data-upstream-tag]:checked')
			: (root
				? root.querySelectorAll('[data-iface-pane="' + iface + '"] input[data-upstream-tag]:checked')
				: []);
		var tags = [];

		inputs.forEach(function(el) {
			var t = el.getAttribute('data-upstream-tag');

			if (t)
				tags.push(t);
		});
		return tags;
	},

	onWizardSave: function(node, view, iface) {
		var ui = this;
		var root = document.querySelector('[data-xfree-wizard="' + node.id + '"]');
		var tags;

		iface = iface || view._xfreeWizardActiveIface;

		if (!iface || !root)
			return;

		tags = ui.wizardCheckedTags(root, iface);

		view._xfreeWizardStatus = _('Сохранение…');
		view._xfreeWizardStatusIface = iface;
		ui.rerenderWizardStatus(root, view, iface);

		ui.saveWizardSelection(node, iface, tags).then(function() {
			view._xfreeWizardStatus = _('Сохранено.');
			view._xfreeWizardStatusIface = iface;
			ui.rerenderWizardStatus(root, view, iface);
			return ui.loadWizardModel(node, iface);
		}).then(function(model) {
			if (!view._xfreeWizardModels)
				view._xfreeWizardModels = {};

			view._xfreeWizardModels[iface] = model;

			if (view._xfreeWizardReload)
				view._xfreeWizardReload();
		}).catch(function(err) {
			view._xfreeWizardStatus = (err && err.message) || String(err);
			view._xfreeWizardStatusIface = iface;
			ui.rerenderWizardStatus(root, view, iface);
		});
	},

	wizardApplyConfirm: function(target) {
		switch (target) {
		case 'zapret':
			return _('Сохранить выбор и применить секции Zapret (apply-changed-sections)?');
		case 'dns':
			return _('Сохранить выбор и применить DNS redirect + маршрутизацию (как в CLI)?');
		default:
			return _('Сохранить выбор и применить маршрутизацию списков (nft/dnsmasq, как в CLI)?');
		}
	},

	runWizardRuntimeApply: function(node) {
		var self = this;
		var meta = this.wizardMeta(node);

		if (meta.target === 'zapret')
			return self.runZapretMenu('applyLists', '');

		return self.runIfaceMenu('applyRouting', '');
	},

	pollWizardApplyTask: function(root, view, iface, dlg, attempt) {
		var self = this;
		var n = attempt || 0;

		return self.runIfaceMenu('taskStatus', '').then(function(res) {
			var text = self.formatExecReport(res);
			var running = self.ifaceTaskRunning(res);
			var last = self.ifaceTaskLastExit(res);
			var tail;

			if (dlg)
				dlg.setText(text);

			tail = text.split('\n').slice(-4).join(' ').replace(/\s+/g, ' ').trim();
			if (running) {
				view._xfreeWizardStatus = _('Применение… %s').format(tail || '');
				view._xfreeWizardStatusIface = iface;
				self.rerenderWizardStatus(root, view, iface);
				if (dlg)
					dlg.setStatus(_('Применение в фоне…'));
				if (n >= 90) {
					view._xfreeWizardStatus = _('Применение ещё идёт в фоне — смотрите лог.');
					self.rerenderWizardStatus(root, view, iface);
					if (dlg) {
						dlg.setStatus(_('Таймаут ожидания — задача может ещё идти.'));
						dlg.setDone(false);
					}
					return { ok: false, text: text };
				}
				return new Promise(function(resolve) {
					setTimeout(function() {
						resolve(self.pollWizardApplyTask(root, view, iface, dlg, n + 1));
					}, 2000);
				});
			}

			if (last != null && last !== 0) {
				view._xfreeWizardStatus = _('Ошибка apply (exit %s).').format(String(last));
				view._xfreeWizardStatusIface = iface;
				self.rerenderWizardStatus(root, view, iface);
				if (dlg) {
					dlg.setStatus(_('Ошибка apply (exit %s).').format(String(last)));
					dlg.setDone(false);
				}
				return { ok: false, text: text };
			}

			view._xfreeWizardStatus = _('Применено.');
			view._xfreeWizardStatusIface = iface;
			self.rerenderWizardStatus(root, view, iface);
			if (dlg) {
				dlg.setStatus(_('Применено.'));
				dlg.setDone(true);
			}
			return { ok: true, text: text };
		});
	},

	onWizardApply: function(node, view, iface) {
		var xui = this;
		var root = document.querySelector('[data-xfree-wizard="' + node.id + '"]');
		var meta = this.wizardMeta(node);
		var tags;
		var dlg;
		var logParts = [];

		iface = iface || view._xfreeWizardActiveIface;

		if (!iface || !root)
			return;

		if (!window.confirm(xui.wizardApplyConfirm(meta.target)))
			return;

		tags = xui.wizardCheckedTags(root, iface);
		dlg = xui.openExecOutputDialog(_('Применить'));

		view._xfreeWizardStatus = _('Сохранение…');
		view._xfreeWizardStatusIface = iface;
		xui.rerenderWizardStatus(root, view, iface);
		dlg.setStatus(_('Сохранение выбора…'));
		dlg.setText(_('Сохранение выбора в профиль…'));

		xui.saveWizardSelection(node, iface, tags).then(function(saveRes) {
			logParts.push(_('=== Сохранение ==='));
			logParts.push(xui.formatExecReport(saveRes));
			dlg.setText(logParts.join('\n'));
			view._xfreeWizardStatus = _('Сохранено. Применение…');
			view._xfreeWizardStatusIface = iface;
			xui.rerenderWizardStatus(root, view, iface);
			dlg.setStatus(_('Применение…'));
			return xui.runWizardRuntimeApply(node);
		}).then(function(res) {
			var text = xui.formatExecReport(res);

			logParts.push('');
			logParts.push(_('=== Применение ==='));
			logParts.push(text);
			dlg.setText(logParts.join('\n'));

			if (res && res.code && res.code !== 0)
				return Promise.reject(new Error((res && res.stderr) || text || _('Ошибка apply')));

			if (meta.target !== 'zapret' && xui.ifaceTaskRunning(res)) {
				view._xfreeWizardStatus = _('Применение в фоне…');
				view._xfreeWizardStatusIface = iface;
				xui.rerenderWizardStatus(root, view, iface);
				dlg.setStatus(_('Применение в фоне…'));
				return xui.pollWizardApplyTask(root, view, iface, dlg, 0).then(function(poll) {
					if (poll && poll.text) {
						logParts.push('');
						logParts.push(_('=== Лог задачи ==='));
						logParts.push(poll.text);
						dlg.setText(logParts.join('\n'));
					}
					if (poll && poll.ok === false)
						return Promise.reject(new Error(_('Ошибка apply')));
					return xui.loadWizardModel(node, iface).then(function(model) {
						if (!view._xfreeWizardModels)
							view._xfreeWizardModels = {};
						view._xfreeWizardModels[iface] = model;
						if (view._xfreeWizardReload)
							view._xfreeWizardReload();
						return poll;
					});
				});
			}

			view._xfreeWizardStatus = _('Применено.');
			view._xfreeWizardStatusIface = iface;
			xui.rerenderWizardStatus(root, view, iface);
			dlg.setStatus(_('Применено.'));
			dlg.setDone(true);
			return xui.loadWizardModel(node, iface).then(function(model) {
				if (!view._xfreeWizardModels)
					view._xfreeWizardModels = {};
				view._xfreeWizardModels[iface] = model;
				if (view._xfreeWizardReload)
					view._xfreeWizardReload();
			});
		}).catch(function(err) {
			var msg = (err && err.message) || String(err);

			view._xfreeWizardStatus = msg;
			view._xfreeWizardStatusIface = iface;
			xui.rerenderWizardStatus(root, view, iface);
			if (dlg) {
				logParts.push('');
				logParts.push(_('=== Ошибка ==='));
				logParts.push(msg);
				dlg.setText(logParts.join('\n'));
				dlg.setStatus(msg);
				dlg.setDone(false);
			}
		});
	},

	rerenderWizardStatus: function(root, view, iface) {
		var el;

		if (!root)
			return;

		el = iface
			? root.querySelector('.xfree-wizard-status[data-iface-status="' + iface + '"]')
			: root.querySelector('.xfree-wizard-status');

		if (el)
			el.textContent = view._xfreeWizardStatus || '';
	},

	wizardPanel: function(node, manifest, view, wizardData) {
		var el = E('xfree-wizard');

		el.mount({
			xui: this,
			node: node,
			view: view,
			wizardData: wizardData || {}
		});
		return el;
	},

	loadWizard: function(node, view) {
		var self = this;

		return self.loadWizardBootstrap(node).then(function(wizardData) {
			var interfaces = wizardData.interfaces || [];
			var active;

			if (!interfaces.length)
				return wizardData;

			active = self.wizardActiveIface(view, wizardData);

			return self.loadWizardModel(node, active).then(function(model) {
				if (!view._xfreeWizardModels)
					view._xfreeWizardModels = {};

				view._xfreeWizardModels[active] = model;
				view._xfreeWizardActiveIface = active;
				wizardData.models = view._xfreeWizardModels;
				return wizardData;
			}).catch(function(err) {
				wizardData.modelError = (err && err.message) ? err.message : String(err);
				return wizardData;
			});
		});
	},

	unwrapRpc: function(res) {
		if (typeof res === 'number')
			throw new Error(_('ubus %s').format(res));

		if (Array.isArray(res))
			res = (res[0] && typeof res[0] === 'object') ? res[0] : res[1];

		return res || {};
	},

	invokeButtons: function(node) {
		if (node && Array.isArray(node.buttons) && node.buttons.length)
			return node.buttons;

		return [{
			id: 'run',
			title: (node && (node.button || node.title)) || _('Выполнить'),
			op: (node && node.action) || '',
			confirm: node && node.confirm
		}];
	},

	invokeFieldValue: function(root, field) {
		var el;

		if (!root || !field || !field.id)
			return '';

		el = root.querySelector('[data-xfree-invoke-field="' + field.id + '"]');

		if (!el)
			return '';

		if (field.type === 'checkbox')
			return el.checked ? '1' : '0';

		return String(el.value || '').trim();
	},

	invokeCollectValues: function(root, node) {
		var values = {};
		var fields = (node && node.fields) || [];
		var i;
		var field;

		for (i = 0; i < fields.length; i++) {
			field = fields[i];
			if (field && field.id)
				values[field.id] = this.invokeFieldValue(root, field);
		}

		if (values.name && !values.profile)
			values.profile = values.name;

		return values;
	},

	invokeMissingRequired: function(node, values) {
		var fields = (node && node.fields) || [];
		var i;
		var field;
		var missing = [];

		for (i = 0; i < fields.length; i++) {
			field = fields[i];
			if (!field || !field.id || field.optional || field.type === 'checkbox')
				continue;
			if (!values[field.id])
				missing.push(field.title || field.id);
		}

		return missing;
	},

	invokeConfirmText: function(node, btn, values) {
		var base = (btn && btn.confirm) || (node && node.confirm) || '';
		var template = (values && values.template) || '';
		var profile = (values && values.profile) || '';
		var bits = [];

		if (template || profile) {
			if (template)
				bits.push(_('Шаблон: %s').format(template));
			if (profile)
				bits.push(_('Профиль: %s').format(profile));
			if (template && profile && template !== profile)
				bits.push(_('Имена разные: в профиль %s попадут списки из шаблона %s, не из одноимённого шаблона.').format(profile, template));
		}
		if (base)
			bits.push(base);

		return bits.join('\n\n');
	},

	formatInvokeOutput: function(status) {
		var bits = [];
		var stdout;
		var stderr;

		status = status || {};
		stdout = status.stdout || '';
		stderr = status.stderr || '';

		if (status.running)
			bits.push(_('Выполняется: %s').format(status.task || _('задача')));
		else if (status.lastStatus)
			bits.push(_('Последний статус: %s (код %s)').format(
				status.lastStatus, status.lastExit != null ? status.lastExit : '—'));

		if (stderr)
			bits.push(stderr);
		if (stdout)
			bits.push(stdout);

		return bits.join('\n\n').trim() || _('(пока нет вывода)');
	},

	invokePanel: function(node, view, invokeData) {
		var self = this;
		var catalog = (invokeData && invokeData.catalog) || {};
		var status = (invokeData && invokeData.status) || {};
		var values = (invokeData && invokeData.values) || view._xfreeInvokeValues || {};
		var el = E('xfree-invoke');

		if (InvokePanel && InvokePanel.suggestValues)
			values = InvokePanel.suggestValues(catalog, values);

		view._xfreeInvokeValues = values;
		el.mount({
			node: node,
			view: view,
			catalog: catalog,
			status: status,
			values: values,
			buttons: self.invokeButtons(node),
			output: self.formatInvokeOutput(status),
			onRun: function(btn, host) {
				self.onInvokeRun(node, view, btn, host);
			}
		});
		return el;
	},

	onInvokeRun: function(node, view, btn, host) {
		var self = this;
		var root = host || document.querySelector('xfree-invoke[data-xfree-invoke="' + node.id + '"]') ||
			document.querySelector('[data-xfree-invoke="' + node.id + '"]');
		var values;
		var missing;
		var confirmText;
		var op;
		var sectionId;

		if (!root)
			return;

		values = (root.getValues) ? root.getValues() : self.invokeCollectValues(root, node);
		view._xfreeInvokeValues = values;
		op = (btn && btn.op) || node.action || '';
		confirmText = self.invokeConfirmText(node, btn, values);

		missing = self.invokeMissingRequired(node, values);
		if (op === 'instantiate' && !values.profile) {
			missing = [ _('профиль или новое имя') ];
		}

		if (missing.length) {
			view._xfreeInvokeStatus = {
				code: 1,
				running: 0,
				stderr: _('Заполните: %s').format(missing.join(', ')),
				stdout: ''
			};
			if (view.reloadInvokeInPlace)
				view.reloadInvokeInPlace(node, { keepValues: true });
			return;
		}

		if (confirmText && !window.confirm(confirmText))
			return;

		sectionId = view._xfreeWizardSectionId;
		view._xfreeInvokeStatus = {
			code: 0,
			running: 1,
			task: op,
			stdout: _('Запуск…'),
			stderr: ''
		};
		if (view.mountLeafContent && sectionId) {
			view.mountLeafContent(sectionId, {
				id: node.id,
				invoke: {
					catalog: view._xfreeInvokeCatalog || {},
					status: view._xfreeInvokeStatus,
					values: values
				}
			});
		}

		self.runInvoke(node, op, values).then(function(status) {
			view._xfreeInvokeStatus = status || {};
			if (view.reloadInvokeInPlace)
				view.reloadInvokeInPlace(node, { keepValues: true, startPoll: !!status.running });
		}).catch(function(err) {
			view._xfreeInvokeStatus = {
				code: 1,
				running: 0,
				stderr: (err && err.message) ? err.message : String(err),
				stdout: ''
			};
			if (view.reloadInvokeInPlace)
				view.reloadInvokeInPlace(node, { keepValues: true });
		});
	},

	runInvoke: function(node, op, values) {
		var self = this;
		var api = (node && node.api) || 'templatesMenu';
		var template = (values && values.template) || '-';
		var profile = (values && values.profile) || '-';
		var force = (values && values.force) || '0';

		if (api !== 'templatesMenu')
			return Promise.reject(new Error('unknown invoke api: ' + api));

		return callTemplatesMenu('run', op || '-', template, profile, force).then(function(res) {
			return self.unwrapRpc(res);
		}).catch(function(err) {
			return {
				code: 1,
				running: 0,
				stdout: '',
				stderr: rpcObjectMissing('templatesMenu', err)
			};
		});
	},

	loadInvokeCatalog: function(node) {
		var self = this;
		var api = (node && node.api) || 'templatesMenu';

		if (api !== 'templatesMenu')
			return Promise.reject(new Error('unknown invoke api: ' + api));

		return callTemplatesMenu('catalog', '-', '-', '-', '-').then(function(res) {
			res = self.unwrapRpc(res);
			if (res.code !== 0 && res.code != null)
				throw new Error(res.stderr || _('Ошибка каталога шаблонов'));
			return res;
		}).catch(function(err) {
			return {
				code: 1,
				templates: [],
				profiles: [],
				stderr: rpcObjectMissing('templatesMenu', err)
			};
		});
	},

	loadInvokeStatus: function(node) {
		var self = this;
		var api = (node && node.api) || 'templatesMenu';

		if (api !== 'templatesMenu')
			return Promise.resolve({ running: 0, stdout: '', stderr: '' });

		return callTemplatesMenu('status', '-', '-', '-', '-').then(function(res) {
			return self.unwrapRpc(res);
		}).catch(function(err) {
			return {
				code: 1,
				running: 0,
				stdout: '',
				stderr: rpcObjectMissing('templatesMenu', err)
			};
		});
	},

	loadInvoke: function(node, view) {
		var self = this;

		return Promise.all([
			self.loadInvokeCatalog(node),
			self.loadInvokeStatus(node)
		]).then(function(parts) {
			var catalog = parts[0] || {};
			var status = parts[1] || {};

			if (view) {
				view._xfreeInvokeCatalog = catalog;
				view._xfreeInvokeStatus = status;
			}

			if (catalog.stderr && !status.stderr)
				status.stderr = catalog.stderr;

			return {
				catalog: catalog,
				status: status,
				values: (view && view._xfreeInvokeValues) || {}
			};
		});
	},

	/* Overview traffic map / site tracer (config + light runtime). */
	trafficPath: function(action, fqdn, limit) {
		var a = action || 'summary';
		var q = fqdn || '-';
		var lim = (limit == null || limit === '') ? '-' : String(limit);

		return callTrafficPath(a, q, lim).then(function(res) {
			return res || { code: 1, stderr: 'empty trafficPath response' };
		}).catch(function(err) {
			return {
				code: 1,
				stderr: rpcObjectMissing('trafficPath', err)
			};
		});
	}
});

return LuciUi;
