'use strict';
'require baseclass';
'require ui';

return baseclass.extend({
	_renderRoamingSection: function(ifaces) {
		var self = this;

		var domainInput = E('input', {
			'type': 'text',
			'class': 'xfree-mesh-domain-input',
			'maxlength': '4',
			'value': this._mobilityDomain || '4f2a',
			'change': function(ev) {
				self._mobilityDomain = (ev.target.value || '').trim().toLowerCase();
			}
		});

		var generateBtn = E('button', {
			'type': 'button',
			'class': 'cbi-button cbi-button-neutral',
			'click': function(ev) {
				ev.preventDefault();
				var randHex = ((Math.random() * 0xffff) | 0).toString(16).padStart(4, '0').toLowerCase();
				domainInput.value = randHex;
				self._mobilityDomain = randHex;
			}
		}, [ '🎲 ' + _('Сгенерировать') ]);

		var domainBar = E('div', { 'class': 'xfree-mesh-domain-bar' }, [
			E('strong', {}, [ _('Mobility Domain:') ]),
			domainInput,
			generateBtn,
			E('span', { 'class': 'muted', 'style': 'font-size: 12px; margin-left: 8px;' }, [
				_('4 hex-символа (0-9, a-f). Должен быть одинаковым на всех роутерах и точках доступа домашней сети.')
			])
		]);

		/* Table of Wi-Fi APs */
		var tableRows = [];
		if (ifaces.length === 0) {
			tableRows.push(E('tr', {}, [
				E('td', { 'colspan': '6', 'class': 'muted', 'style': 'text-align: center; padding: 20px;' }, [
					_('Точки доступа Wi-Fi не найдены в конфигурации /etc/config/wireless')
				])
			]));
		} else {
			ifaces.forEach(function(iface) {
				var sec = iface.section;
				var isChecked = !!self._selectedIfaces[sec];
				var chkBox = E('input', {
					'type': 'checkbox',
					'checked': isChecked ? true : null,
					'change': function(ev) {
						self._selectedIfaces[sec] = ev.target.checked;
					}
				});

				var statusBadge = iface.ftEnabled
					? E('span', { 'class': 'xfree-vpn-status is-ok' }, [ _('Включен') + (iface.mobilityDomain ? (' (' + iface.mobilityDomain + ')') : '') ])
					: E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Выключен') ]);

				var isGuest = /guest|гост/i.test(iface.ssid || '') || iface.network === 'guest';
				var isIot = /iot/i.test(iface.ssid || '');
				var ssidNodes = [ E('strong', {}, [ iface.ssid || _('(Скрытая сеть)') ]) ];

				if (isGuest) {
					ssidNodes.push(E('span', {
						'class': 'xfree-vpn-status is-warn',
						'style': 'margin-left: 6px; font-size: 11px; padding: 1px 6px;',
						'title': _('Гостевая сеть: роуминг обычно не требуется')
					}, [ '⚠️ ' + _('Гостевая сеть') ]));
				} else if (isIot) {
					ssidNodes.push(E('span', {
						'class': 'xfree-vpn-status is-warn',
						'style': 'margin-left: 6px; font-size: 11px; padding: 1px 6px;',
						'title': _('Сеть умного дома (IoT): старые датчики и розетки (ESP8266/ESP32, Tuya) могут терять связь при включенном 802.11r FT')
					}, [ '⚠️ ' + _('IoT / Умный дом') ]));
				}

				var bandBadge = iface.band && iface.band.indexOf('5') >= 0
					? E('span', { 'class': 'xfree-vpn-status is-ok', 'style': 'font-size: 11px; padding: 1px 6px;' }, [ iface.band ])
					: E('span', { 'class': 'xfree-vpn-status is-muted', 'style': 'font-size: 11px; padding: 1px 6px;' }, [ iface.band || '2.4 GHz' ]);

				tableRows.push(E('tr', {}, [
					E('td', { 'style': 'width: 40px; text-align: center;' }, [ chkBox ]),
					E('td', {}, ssidNodes),
					E('td', {}, [ bandBadge ]),
					E('td', {}, [ E('code', {}, [ iface.section + ' (' + iface.device + ')' ]) ]),
					E('td', {}, [ E('span', { 'class': 'xfree-vpn-status is-muted' }, [ iface.network || 'lan' ]) ]),
					E('td', {}, [ statusBadge ])
				]));
			});
		}

		var table = E('table', { 'class': 'xfree-mesh-table' }, [
			E('thead', {}, [
				E('tr', {}, [
					E('th', { 'style': 'width: 40px; text-align: center;' }, [ '✓' ]),
					E('th', {}, [ _('Имя сети (SSID)') ]),
					E('th', {}, [ _('Диапазон') ]),
					E('th', {}, [ _('Интерфейс') ]),
					E('th', {}, [ _('Зона') ]),
					E('th', {}, [ _('Fast Roaming (802.11r)') ])
				])
			]),
			E('tbody', {}, tableRows)
		]);

		/* Apply roaming button */
		var applyRoamingBtn = E('button', {
			'type': 'button',
			'class': 'cbi-button cbi-button-action important',
			'click': function(ev) {
				var dom = (domainInput.value || self._mobilityDomain || '').trim().toLowerCase();
				if (!/^[0-9a-fA-F]{4}$/.test(dom)) {
					ui.addNotification(null, E('p', {}, [ _('Mobility Domain должен состоять ровно из 4 шестнадцатеричных символов (0-9, a-f)') ]), 'error');
					return;
				}

				var selectedSecs = [];
				var selectedSsids = [];
				var unselectedSsids = [];
				ifaces.forEach(function(iface) {
					if (self._selectedIfaces[iface.section]) {
						selectedSecs.push(iface.section);
						selectedSsids.push(iface.ssid || iface.section);
					} else {
						unselectedSsids.push(iface.ssid || iface.section);
					}
				});

				var confirmMsg = _('Применить параметры Fast Roaming (802.11r/k/v)?\n\n') +
					_('• Mobility Domain: ') + dom + '\n' +
					_('• Включить роуминг на сетях: ') + (selectedSsids.join(', ') || _('ни на одной')) + '\n' +
					(unselectedSsids.length ? (_('• Отключить роуминг на сетях: ') + unselectedSsids.join(', ')) : '');

				var arg = dom + ' ' + selectedSecs.join(',');
				self._act(ev, 'configureMeshRoaming', arg, confirmMsg);
			}
		}, [ '⚡ ' + _('Применить Fast Roaming к выбранным сетям') ]);

		var disableAllRoamingBtn = E('button', {
			'type': 'button',
			'class': 'cbi-button cbi-button-neutral',
			'click': function(ev) {
				self._act(ev, 'disableMeshRoaming', '', _('Отключить Fast Roaming (802.11r) на всех беспроводных точках доступа?'));
			}
		}, [ _('Отключить роуминг на всех сетях') ]);

		var tableActions = E('div', { 'class': 'xfree-mesh-table-actions' }, [
			applyRoamingBtn,
			disableAllRoamingBtn
		]);

		return E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 1.25rem;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📱 ' + _('Бесшовный роуминг клиентов (Fast Roaming)') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Клиентский Wi-Fi') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Мгновенный переход клиентов между точками доступа (802.11r Fast BSS Transition). Отметьте галочками сети, которые должны участвовать в роуминге (рекомендуется исключить сети умного дома / IoT во избежание сбоев старых устройств).')
				])
			]),
			E('div', { 'class': 'xfree-mesh-table-card' }, [
				domainBar,
				table,
				tableActions
			])
		]);
	}
});
