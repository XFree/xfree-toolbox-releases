'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.traffic-map-svg as mapSvg';
'require xfree-toolbox.traffic-map-detail as mapDetail';

return baseclass.extend({
	_hubBtn: function(kind, title, sub, active) {
		var self = this;
		var view = this._spec && this._spec.view;
		var cls = 'tm-hub-node kind-' + kind + (active ? ' is-active' : '');
		var kids = [
			E('span', { 'class': 'tm-hub-main' }, [
				mapSvg.iconEl(mapSvg.SVG[kind] || mapSvg.SVG.router, 'tm-hub-ico'),
				E('span', { 'class': 'tm-hub-copy' }, [
					E('span', { 'class': 'tm-hub-k' }, [ title ]),
					E('span', { 'class': 'tm-hub-v' }, [ sub ])
				])
			])
		];

		if (kind === 'router') {
			cls += ' is-router';
			kids.push(E('span', { 'class': 'tm-ports', 'aria-hidden': 'true' }, [
				E('span', { 'class': 'tm-port' }, [ 'in' ]),
				E('span', { 'class': 'tm-port' }, [ 'out' ])
			]));
		}

		return E('button', {
			'class': cls,
			'type': 'button',
			'title': title,
			'click': ui.createHandlerFn(view, function(ev) {
				ev.preventDefault();
				self._nav(kind);
			})
		}, kids);
	},

	_arrow: function(active, skipped) {
		var cls = 'tm-arrow';
		if (active) cls += ' is-active';
		if (skipped) cls += ' is-skipped';
		return E('div', { 'class': cls, 'aria-hidden': 'true' }, [
			E('span', { 'class': 'tm-arrow-line' }),
			E('span', { 'class': 'tm-arrow-head' })
		]);
	},

	_rail: function() {
		/* continuous path under nodes (visual only) */
		return E('div', { 'class': 'tm-rail', 'aria-hidden': 'true' });
	},

	_chip: function(opts) {
		var self = this;
		var view = this._spec && this._spec.view;
		/* health only for monitorable links (VPN tunnels / WAN egress) */
		var health = opts.health;
		var cls = 'tm-chip kind-' + (opts.kind || 'x');
		var title = opts.title || opts.label;
		var kids;
		if (opts.active) cls += ' is-active';
		if (opts.dim) cls += ' is-dim';
		if (opts.warn && !health) cls += ' is-warn';
		if (health === 'ok' || health === 'warn' || health === 'fail' || health === 'unknown') {
			cls += ' is-health-' + health;
			if (!opts.titleFull)
				title = (title || '') + ' · ' + mapDetail.healthLabel(health);
		}

		kids = [
			E('span', { 'class': 'tm-chip-label' }, [ opts.label ]),
			opts.active ? mapSvg.iconEl(mapSvg.SVG.ok, 'tm-chip-check') : ''
		];
		if (health)
			kids.unshift(E('span', { 'class': 'tm-chip-dot', 'aria-hidden': 'true' }));

		return E('button', {
			'class': cls,
			'type': 'button',
			'title': title,
			'data-chip-id': (opts.detail && opts.detail.id) || null,
			'click': ui.createHandlerFn(view, function(ev) {
				ev.preventDefault();
				ev.stopPropagation();
				if (opts.detail) {
					self._togglePopover(opts.detail);
					return;
				}
				self._nav(opts.kind);
			})
		}, kids);
	},

	_stage: function(opts) {
		var self = this;
		var view = this._spec && this._spec.view;
		var cls = 'tm-stage kind-' + opts.kind;
		var body = [];

		if (opts.lit) cls += ' is-lit';
		if (opts.quiet) cls += ' is-quiet';
		if (opts.skipped) cls += ' is-skipped';
		if (opts.status)
			cls += ' layer-' + opts.status;

		if (opts.skippedMsg) {
			body.push(E('p', { 'class': 'tm-skip-msg' }, [ opts.skippedMsg ]));
		}

		if (opts.chips && opts.chips.length) {
			body.push(E('div', { 'class': 'tm-chips' }, opts.chips));
		} else if (!opts.skippedMsg && !opts.expandLabel && !opts.diag) {
			body.push(E('span', { 'class': 'tm-empty muted' }, [ opts.empty || _('нет') ]));
		}

		if (opts.diag)
			body.push(opts.diag);

		if (opts.expandLabel) {
			body.push(E('button', {
				'class': 'tm-expand',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					self._toggleExpand(opts.expandKey);
				})
			}, [ opts.expandLabel ]));
		}

		return E('div', { 'class': cls, 'data-stage': opts.kind }, [
			E('div', { 'class': 'tm-stage-head' }, [
				E('span', { 'class': 'tm-stage-title' }, [
					mapSvg.iconEl(mapSvg.SVG[opts.kind] || mapSvg.SVG.dns, 'tm-stage-ico'),
					opts.title
				]),
				mapSvg.statusIcon(opts.status, opts.warn)
			]),
			E('div', { 'class': 'tm-stage-body' }, body)
		]);
	},

	/* Compact uplink channel strip for Exit/WAN (not DNS host checks). */
	_wanChannelDiag: function(wan) {
		var ch = mapDetail.channelLabel(wan);
		var tone = 'muted';
		var rows = [];
		var altEn;
		var baseOk;
		var altOk;

		if (!wan)
			return E('div', { 'class': 'tm-wan-diag is-empty' }, [
				E('span', { 'class': 'tm-wan-diag-k' }, [ _('Канал') ]),
				E('span', { 'class': 'tm-wan-diag-v muted' }, [ _('нет данных') ])
			]);

		if (ch === 'FULL') tone = 'ok';
		else if (ch === 'PARTIAL') tone = 'warn';
		else if (ch === 'FAIL') tone = 'fail';

		baseOk = mapDetail.probeBitOk(wan.probeBase);
		altEn = wan.probeAltEnabled === 1 || wan.probeAltEnabled === '1';
		altOk = mapDetail.probeBitOk(wan.probeAlt);

		rows.push(E('div', { 'class': 'tm-wan-diag-row' }, [
			E('span', { 'class': 'tm-wan-diag-k' }, [ _('Канал') ]),
			E('span', { 'class': 'tm-wan-diag-v is-' + tone }, [ ch || '—' ])
		]));
		rows.push(E('div', { 'class': 'tm-wan-diag-row' }, [
			E('span', { 'class': 'tm-wan-diag-k' }, [ _('база') ]),
			E('span', {
				'class': 'tm-wan-diag-mark is-' + (wan.probeBase === '' || wan.probeBase == null ? 'muted' : (baseOk ? 'ok' : 'fail')),
				'title': _('Базовый probe URL')
			}, [ wan.probeBase === '' || wan.probeBase == null ? '—' : (baseOk ? '✓' : '✗') ])
		]));
		rows.push(E('div', { 'class': 'tm-wan-diag-row' }, [
			E('span', { 'class': 'tm-wan-diag-k' }, [ _('доп.') ]),
			E('span', {
				'class': 'tm-wan-diag-mark is-' + (!altEn ? 'muted' : (altOk ? 'ok' : 'fail')),
				'title': _('Доп. probe (полный интернет)')
			}, [ !altEn ? _('выкл') : (altOk ? '✓' : '✗') ])
		]));

		return E('div', {
			'class': 'tm-wan-diag is-' + tone,
			'title': (wan.lastTick ? _('Тик: %s').format(wan.lastTick) : _('Мониторинг канала'))
		}, rows);
	},

	_breadcrumb: function(parts, active) {
		var nodes = [];
		var i;
		var cls = 'tm-breadcrumb' + (active ? ' is-active' : ' is-idle');
		for (i = 0; i < parts.length; i++) {
			if (i)
				nodes.push(E('span', { 'class': 'tm-bc-sep', 'aria-hidden': 'true' }, [ '→' ]));
			nodes.push(E('span', { 'class': 'tm-bc-item' }, [
				mapSvg.iconEl(mapSvg.SVG[parts[i].ico] || mapSvg.SVG.out, 'tm-bc-ico'),
				parts[i].label
			]));
		}
		return E('nav', {
			'class': cls,
			'aria-label': _('Путь'),
			'title': active ? _('Результат трассировки') : _('Схема пути — заполняется после «Путь»')
		}, nodes);
	},

	/* Shared expand control for DNS / VPN / Zapret stages. */
	_stageExpandLabel: function(key, pack, total, tracing) {
		if (this._expanded[key])
			return total > 0 ? _('Скрыть') : '';
		if (pack && pack.hidden > 0)
			return tracing
				? _('+%d').format(pack.hidden)
				: _('все +%d').format(pack.hidden);
		return '';
	},

	_buildStageChips: function(kind, allNodes, hl, tracing, expanded, hitsById, maxVisible) {
		var chips = [];
		var hidden = 0;
		var shown = 0;
		var i;
		var n;
		var id;
		var active;
		var label;
		var hit;
		var show;
		/* null/undefined → default 3; explicit 0 means collapse to expand-only. */
		var cap = maxVisible == null ? 3 : maxVisible;

		for (i = 0; i < allNodes.length; i++) {
			n = allNodes[i] || {};
			id = n.id || '';
			active = !!(tracing && hl[id]);
			if (tracing)
				show = expanded || active;
			else if (expanded)
				show = true;
			else
				show = shown < cap;

			if (!show) {
				hidden++;
				continue;
			}
			shown++;
			label = n.label || mapDetail.nodeLabel(id, id);
			hit = hitsById && hitsById[id];
			chips.push(this._chip({
				kind: kind,
				label: label,
				active: active,
				dim: tracing && !active,
				warn: !mapDetail.runtimeOk(n),
				health: kind === 'iface'
					? mapDetail.nodeHealth(n)
					: (kind === 'dns' ? mapDetail.dnsCheckHealth(n) : null),
				title: label,
				titleFull: kind === 'iface' || (kind === 'dns' && !!mapDetail.dnsCheckHealth(n)),
				/* Always tip — CTA «Списки» deep-links to this scope. */
				detail: {
					id: id,
					navKind: kind === 'iface' ? 'vpn' : kind,
					navScope: mapDetail.tipNavScope(id),
					title: active
						? _('Сработало: %s').format(label)
						: (kind === 'iface'
							? _('Туннель: %s').format(label)
							: (kind === 'dns'
								? _('DNS: %s').format(label)
								: _('Секция: %s').format(label))),
					rows: (function() {
						var fqdn = (hit && hit.base)
							|| (this._trace && this._trace.query && this._trace.query.fqdn)
							|| '';
						var rows;
						if (kind === 'iface') {
							rows = mapDetail.tunnelDetailRows(n);
							if (fqdn || (hit && hit.strategy)) {
								rows = [
									{ k: _('Домен'), v: fqdn || '—' },
									{ k: _('Стратегия'), v: (hit && hit.strategy) || '—' }
								].concat(rows);
							}
							return rows;
						}
						if (kind === 'dns')
							return mapDetail.dnsDetailRows(n, hit, active ? fqdn : '');
						return mapDetail.zapretDetailRows(n, hit, active ? fqdn : '');
					}.call(this))
				}
			}));
		}
		return { chips: chips, hidden: hidden };
	}
});
