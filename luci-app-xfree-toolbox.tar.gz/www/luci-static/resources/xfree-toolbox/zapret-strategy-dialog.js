'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.luci-ui as xui';

return baseclass.extend({
	_openStrategyDialog: function(secName) {
		var self = this;
		var st = this._status || {};

		var dialogContent = E('div', { 'class': 'xfree-strategy-dialog' }, [
			E('p', { 'class': 'xfree-dialog-hint muted' }, [
				_('Загрузка параметров стратегии секции «%s»…').format(secName)
			])
		]);

		var dlgHandle = xui.openDialog({
			title: '⚙️ ' + _('Стратегия секции: %s').format(secName),
			size: 'wide',
			body: dialogContent,
			actions: [
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				},
				{
					label: '💾 ' + _('Сохранить стратегию'),
					variant: 'primary',
					disabled: true
				}
			]
		});

		xui.runZapretMenu('getStrategy', secName).then(function(res) {
			var strategyText = (res && (res.stdout || res.text)) || '';
			var ta = E('textarea', {
				'class': 'xfree-strategy-editor',
				'spellcheck': 'false',
				'rows': '13',
				'style': 'width: 100%; min-height: 240px; font-family: monospace; font-size: 12px; line-height: 1.45; padding: 10px; border-radius: 8px; border: 1px solid var(--line); background: var(--panel-2); color: var(--text); resize: vertical; box-sizing: border-box;'
			}, [ strategyText ]);

			dlgHandle.setActions([
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				},
				{
					label: '💾 ' + _('Сохранить стратегию'),
					variant: 'primary',
					disabled: false,
					click: function() {
						var newContent = String(ta.value || '').trim();
						dlgHandle.setActions([
							{
								label: _('Закрыть'),
								variant: 'secondary',
								close: true
							},
							{
								label: '⏳ ' + _('Сохранение…'),
								variant: 'primary',
								disabled: true
							}
						]);
						xui.runZapretMenu('saveStrategy', secName, newContent).then(function() {
							dlgHandle.hide();
							st.pending = true;
							self.setMessage(
								_('Стратегия секции «%s» сохранена. Для применения нажмите «⚡ Применить списки».')
									.format(secName),
								'warn'
							);
							self.requestPaint();
						}).catch(function(err) {
							dlgHandle.setActions([
								{
									label: _('Закрыть'),
									variant: 'secondary',
									close: true
								},
								{
									label: '💾 ' + _('Сохранить стратегию'),
									variant: 'primary',
									disabled: false
								}
							]);
							ui.addNotification(null, E('p', {}, [
								_('Ошибка сохранения стратегии: %s').format(err && err.message || err)
							]), 'danger');
						});
					}
				}
			]);

			dialogContent.replaceChildren(
				E('div', { 'style': 'margin-bottom: 8px;' }, [
					E('p', { 'class': 'muted', 'style': 'font-size: 12px; margin: 0 0 6px 0;' }, [
						_('Параметры десинхронизации NFQWS (файл config/section.text). Допускаются флаги --dpi-desync, --filter-tcp/udp, {{SELECT_LIST}} и др.')
					]),
					E('div', { 'style': 'display: flex; gap: 6px; align-items: center; margin-bottom: 8px;' }, [
						xcmp.badge({
							variant: 'vpn-status',
							tone: 'muted',
							text: _('Синтаксис: nfqws1'),
							style: 'font-size: 11px;'
						}),
						E('span', { 'class': 'muted', 'style': 'font-size: 11px; margin-left: auto;' }, [ _('Секция: %s').format(secName) ])
					])
				]),
				ta
			);
		}).catch(function(err) {
			dialogContent.replaceChildren(
				E('div', { 'class': 'alert-message danger' }, [
					_('Не удалось загрузить стратегию: %s').format(err && err.message || err)
				])
			);
		});
	}
});
