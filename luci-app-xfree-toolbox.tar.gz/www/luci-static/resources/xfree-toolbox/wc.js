'use strict';
'require baseclass';

/**
 * Регистрация Custom Elements для LuCI (AMD).
 * Light DOM — CBI-классы и темы; Shadow DOM — только изоляция (эталон: xfree-console).
 * Модуль обязан `return baseclass.extend(...)`.
 */
function defineXfreeElement(tag, Klass) {
	if (typeof customElements === 'undefined' || customElements.get(tag))
		return tag;

	customElements.define(tag, Klass);
	return tag;
}

var XfreeLightElement = class extends HTMLElement {
	connectedCallback() {
		this._xfreeConnected = true;
		if (this._xfreeDirty)
			this.paint();
	}

	disconnectedCallback() {
		this._xfreeConnected = false;
	}

	requestPaint() {
		this._xfreeDirty = true;
		if (this._xfreeConnected || this.isConnected)
			this.paint();
	}

	paint() {
		this._xfreeDirty = false;
		this.render();
	}

	render() {
	}
};

return baseclass.extend({
	define: defineXfreeElement,
	LightElement: XfreeLightElement
});
