'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.core.loading as loading';
'require xfree-toolbox.luci-ui as xui';

var xcmp = components;

/**
 * Парсер текстового отчета apply-client.sh --status
 * @param {string} text
 * @returns {Object}
 */
function parseMgmtReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		iface: 'xft_mgmt',
		stateDir: '',
		savedConf: '',
		storeId: '',
		routerId: '',
		manual: '',
		status: 'disabled',
		proto: '',
		defaultroute: '0',
		addresses: '',
		endpoint: '',
		allowedIps: '',
		awgMissing: false,
		isInterfaceUp: false,
		latestHandshake: '',
		transfer: '',
		rawText: String(text || '')
	};

	var inIfstatus = false;
	var inAwg = false;
	var ifstatusBuf = [];

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i].trim();
		if (!line)
			continue;

		if (line === '--- ifstatus ---') {
			inIfstatus = true;
			inAwg = false;
			continue;
		}
		if (line === '--- awg ---') {
			inIfstatus = false;
			inAwg = true;
			continue;
		}

		if (inIfstatus) {
			ifstatusBuf.push(line);
			if (line.indexOf('"up": true') !== -1 || line.indexOf('"up":true') !== -1)
				res.isInterfaceUp = true;
			continue;
		}

		if (inAwg) {
			var mHs = line.match(/^latest handshake:\s*(.+)$/i);
			if (mHs) res.latestHandshake = mHs[1].trim();

			var mTr = line.match(/^transfer:\s*(.+)$/i);
			if (mTr) res.transfer = mTr[1].trim();
			continue;
		}

		var mIf = line.match(/^iface:\s*(.+)$/i);
		if (mIf) { res.iface = mIf[1].trim(); continue; }

		var mSd = line.match(/^state_dir:\s*(.+)$/i);
		if (mSd) { res.stateDir = mSd[1].trim(); continue; }

		var mSc = line.match(/^saved_conf:\s*(.+)$/i);
		if (mSc) { res.savedConf = mSc[1].trim(); continue; }

		var mStore = line.match(/^store_id:\s*(.+)$/i);
		if (mStore) { res.storeId = mStore[1].trim(); continue; }

		var mRid = line.match(/^router_id:\s*(.+)$/i);
		if (mRid) { res.routerId = mRid[1].trim(); continue; }

		var mMan = line.match(/^manual:\s*(.+)$/i);
		if (mMan) { res.manual = mMan[1].trim(); continue; }

		var mSt = line.match(/^status:\s*(.+)$/i);
		if (mSt) { res.status = mSt[1].trim().toLowerCase(); continue; }

		var mPr = line.match(/^proto:\s*(.+)$/i);
		if (mPr) { res.proto = mPr[1].trim(); continue; }

		var mDr = line.match(/^defaultroute:\s*(.+)$/i);
		if (mDr) { res.defaultroute = mDr[1].trim(); continue; }

		var mAd = line.match(/^addresses:\s*(.+)$/i);
		if (mAd) { res.addresses = mAd[1].trim(); continue; }

		var mEp = line.match(/^endpoint:\s*(.+)$/i);
		if (mEp) { res.endpoint = mEp[1].trim(); continue; }

		var mAl = line.match(/^allowed_ips:\s*(.+)$/i);
		if (mAl) { res.allowedIps = mAl[1].trim(); continue; }

		if (line.indexOf('awg: missing') !== -1) {
			res.awgMissing = true;
		}
	}

	if (res.status === 'enabled' && res.latestHandshake) {
		res.isInterfaceUp = true;
	}

	return res;
}

/**
 * Карточка 1: Состояние оверлея
 */
function renderStatusCard(info) {
	var isEnabled = info.status === 'enabled';
	var isUp = isEnabled && info.isInterfaceUp;
	var tone = isUp ? 'ok' : (isEnabled ? 'warn' : 'muted');
	var badgeText = isUp ? _('Активен') : (isEnabled ? _('Подключение…') : _('Отключен'));

	var rows = [
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Сетевой интерфейс') ]),
			E('strong', {}, [ info.iface + (info.proto ? ' (' + info.proto + ')' : '') ])
		]),
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Состояние туннеля') ]),
			xcmp.badge({ text: isUp ? _('Соединение установлено') : (isEnabled ? _('Ожидание Handshake') : _('Интерфейс остановлен')), tone: tone })
		])
	];

	if (info.latestHandshake) {
		rows.push(E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Последний Handshake') ]),
			E('span', { 'style': 'font-family: monospace; font-size: 12px;' }, [ info.latestHandshake ])
		]));
	}

	if (info.transfer) {
		rows.push(E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Передано / Принято') ]),
			E('span', { 'style': 'font-family: monospace; font-size: 12px;' }, [ info.transfer ])
		]));
	}

	if (info.status === 'enabled') {
		var modeText = info.manual === '1'
			? _('Удерживается вручную (до разрыва)')
			: _('Авто-окно по расписанию (cron)');
		rows.push(E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Режим сессии') ]),
			E('span', { 'style': 'font-size: 12px;' }, [ modeText ])
		]));
	}

	if (info.awgMissing) {
		rows.push(E('div', {
			'class': 'alert-message warning',
			'style': 'margin-top: 10px; font-size: 12px; padding: 8px 12px;'
		}, [
			_('Пакет amneziawg не установлен в системе. Установите модуль AmneziaWG для работы оверлея.')
		]));
	}

	return xcmp.card({
		title: _('Оверлей управления'),
		subtitle: _('Защищенный AmneziaWG-туннель для удаленного мониторинга и координации'),
		badge: xcmp.badge({ text: badgeText, tone: tone, pulse: isEnabled }),
		tone: tone,
		content: rows
	});
}

/**
 * Карточка 2: Параметры сети и маршрутизации
 */
function renderNetworkCard(info) {
	var rows = [
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Адрес в оверлее') ]),
			E('strong', { 'style': 'font-family: monospace;' }, [ info.addresses || '—' ])
		]),
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Мастер-хаб (Endpoint)') ]),
			E('span', { 'style': 'font-family: monospace;' }, [ (info.endpoint && info.endpoint !== ':') ? info.endpoint : '—' ])
		]),
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Разрешенные подсети') ]),
			E('span', { 'style': 'font-family: monospace;' }, [ info.allowedIps || '10.77.0.0/24' ])
		]),
		E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ _('Конфигурация клиента') ]),
			E('span', { 'class': 'muted', 'style': 'font-size: 12px; font-family: monospace; word-break: break-all;' }, [ info.savedConf || '(none)' ])
		])
	];

	if (info.storeId) {
		rows.push(E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ 'Store ID' ]),
			E('span', { 'style': 'font-family: monospace; font-size: 12px;' }, [ info.storeId ])
		]));
	}

	if (info.routerId) {
		rows.push(E('div', { 'class': 'xfree-field-row', 'style': 'display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--line, rgba(0,0,0,0.06)); font-size: 13px;' }, [
			E('span', { 'class': 'muted' }, [ 'Router ID' ]),
			E('span', { 'style': 'font-family: monospace; font-size: 12px;' }, [ info.routerId ])
		]));
	}

	return xcmp.card({
		title: _('Параметры подключения'),
		subtitle: _('Сетевые реквизиты, адресация и маршрутизация оверлея'),
		badge: xcmp.badge({ text: '10.77.0.0/24', tone: 'standby' }),
		content: rows
	});
}

/**
 * Кодирует текст в однострочник xft-hub://<base64> (или оставляет уже готовый xft-hub://...).
 * @param {string} raw
 * @returns {string}
 */
function encodeHubToken(raw) {
	var text = String(raw || '').trim();
	if (!text) return '';
	if (text.indexOf('xft-hub://') === 0) {
		return 'xft-hub://' + text.slice('xft-hub://'.length).replace(/\s+/g, '');
	}
	var bytes = encodeURIComponent(text).replace(/%([0-9A-F]{2})/g, function (_m, p1) {
		return String.fromCharCode(parseInt(p1, 16));
	});
	return 'xft-hub://' + btoa(bytes);
}

/**
 * Диалог вставки ключа от хаба (xft-hub://... или client.conf)
 */
function openImportKeyModal(panelView, onRefresh) {
	var textarea = E('textarea', {
		'rows': '6',
		'placeholder': _('Вставьте однострочник xft-hub://... или содержимое client.conf'),
		'style': 'width: 100%; font-family: monospace; font-size: 12px; padding: 8px; box-sizing: border-box;'
	});
	var errBox = E('div', {
		'class': 'alert-message error',
		'style': 'display: none; margin-top: 8px; font-size: 12px; padding: 8px 10px;'
	});

	var saveBtn = xcmp.button({
		text: _('Сохранить и применить'),
		tone: 'primary',
		onClick: function () {
			var raw = (textarea.value || '').trim();
			if (!raw) {
				errBox.textContent = _('Вставьте ключ подключения (xft-hub://... или client.conf).');
				errBox.style.display = 'block';
				return;
			}
			var token;
			try {
				token = encodeHubToken(raw);
			} catch (e) {
				errBox.textContent = _('Некорректный формат ключа: ') + (e.message || String(e));
				errBox.style.display = 'block';
				return;
			}
			ui.hideModal();
			panelView.runSystemAction('mgmtImportConf', '', token).then(function () {
				ui.addNotification(null, E('p', {}, [ _('Ключ хаба сохранён. Теперь можно подключиться.') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function (err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка импорта ключа: ') + (err.message || String(err)) ]), 'error');
			});
		}
	});

	var cancelBtn = xcmp.button({
		text: _('Отмена'),
		tone: 'ghost',
		onClick: function () {
			ui.hideModal();
		}
	});

	ui.showModal(_('Ключ подключения к хабу'), [
		E('p', { 'class': 'muted', 'style': 'margin-bottom: 10px;' }, [
			_('Скопируйте однострочник на карточке роутера в веб-интерфейсе хаба («Ключ») и вставьте сюда.')
		]),
		textarea,
		errBox,
		E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 12px;' }, [
			cancelBtn,
			saveBtn
		])
	]);

	if (typeof textarea.focus === 'function')
		textarea.focus();
}

/**
 * Карточка 3: Действия
 */
function renderActionsCard(info, panelView, onRefresh) {
	var isEnabled = info.status === 'enabled';
	var hasConfig = isEnabled || !!(info.savedConf && info.savedConf !== '(none)');
	var isTunnelActive = isEnabled && (info.isInterfaceUp || info.manual === '1');
	var buttons = [];

	if (!hasConfig) {
		buttons.push(xcmp.button({
			text: '🔑 ' + _('Вставить ключ'),
			tone: 'primary',
			onClick: function () {
				openImportKeyModal(panelView, onRefresh);
			}
		}));
		buttons.push(xcmp.button({
			text: '☁ ' + _('Подключить через Cloud (ensure-client)'),
			tone: 'ghost',
			onClick: function (ev) {
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtConnect').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Команда подключения к хабу выполнена') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка подключения: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
	} else if (!isTunnelActive) {
		buttons.push(xcmp.button({
			text: '⚡ ' + _('Подключить и удерживать'),
			tone: 'primary',
			onClick: function (ev) {
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtEnable').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Туннель к хабу запущен') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка подключения: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
		buttons.push(xcmp.button({
			text: '🔑 ' + _('Заменить ключ'),
			tone: 'ghost',
			onClick: function () {
				openImportKeyModal(panelView, onRefresh);
			}
		}));
		buttons.push(xcmp.button({
			text: _('Удалить конфигурацию'),
			tone: 'danger',
			onClick: function (ev) {
				if (!confirm(_('Удалить конфигурацию сетевого интерфейса xft_mgmt?')))
					return;
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtDisable').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Конфигурация оверлея удалена') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка удаления: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
	} else {
		buttons.push(xcmp.button({
			text: '⏹ ' + _('Разорвать соединение'),
			tone: 'primary',
			onClick: function (ev) {
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtDisconnect').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Туннель xft_mgmt остановлен') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка остановки: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
		buttons.push(xcmp.button({
			text: '🔑 ' + _('Заменить ключ'),
			tone: 'ghost',
			onClick: function () {
				openImportKeyModal(panelView, onRefresh);
			}
		}));
		buttons.push(xcmp.button({
			text: _('Удалить конфигурацию'),
			tone: 'danger',
			onClick: function (ev) {
				if (!confirm(_('Отключить и удалить конфигурацию сетевого интерфейса xft_mgmt?')))
					return;
				var btn = ev.target;
				loading.track(btn, panelView.runSystemAction('mgmtDisable').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Конфигурация оверлея удалена') ]), 'info');
					if (typeof onRefresh === 'function') return onRefresh();
				}).catch(function (err) {
					ui.addNotification(null, E('p', {}, [ _('Ошибка удаления: ') + (err.message || String(err)) ]), 'error');
				}));
			}
		}));
	}

	return xcmp.card({
		title: _('Управление подключением'),
		subtitle: _('Включение, выключение и автоматическая инициализация клиента'),
		badge: xcmp.badge({ text: 'Control', tone: 'standby' }),
		content: E('div', { 'style': 'display: flex; gap: 8px; flex-wrap: wrap; align-items: center;' }, buttons)
	});
}

return baseclass.extend({
	parseReport: parseMgmtReport,
	openImportKeyModal: openImportKeyModal,

	render: function (opts) {
		opts = opts || {};
		var view = opts.view || {};
		var execResult = opts.execResult || (opts.data && opts.data.execResult) || {};
		var rawText = (execResult && execResult.stdout) ? execResult.stdout : (typeof execResult === 'string' ? execResult : '');
		var info = parseMgmtReport(rawText);
		var onRefresh = opts.onRefresh;
		var isRefreshing = !!(opts && opts.isRefreshing);

		var panelView = {
			runSystemAction: function (action, arg, payload) {
				var x = (typeof xui !== 'undefined') ? xui : null;
				if (x && typeof x.runSystemMenuWithOutput === 'function') {
					return x.runSystemMenuWithOutput(action, arg, payload);
				}
				if (typeof view.runSystemAction === 'function') {
					return view.runSystemAction(action, arg, payload);
				}
				if (view && typeof view.runSystemMenu === 'function') {
					return view.runSystemMenu(action, arg, payload);
				}
				return Promise.reject(new Error('runSystemMenu is not available'));
			}
		};

		var cards = [
			renderStatusCard(info),
			renderNetworkCard(info),
			renderActionsCard(info, panelView, onRefresh)
		];

		var refreshBtn = xcmp.refreshButton({
			isRefreshing: isRefreshing,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(refreshBtn, res);
					}
				}
			}
		});

		var actionBar = xcmp.actionBar({
			title: _('Хаб управления (XFree Mgmt Hub)'),
			description: _('Удаленный доступ, телеметрия и координация роутера через защищенный оверлей AmneziaWG'),
			actions: [ refreshBtn ]
		});

		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод status.sh)'),
			rawText: rawText,
			maxHeight: '300px'
		});

		return E('div', { 'class': 'xfree-web xfree-system-mgmt-panel' }, [
			actionBar,
			E('div', {
				'class': 'xfree-card-grid',
				'style': 'display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 16px;'
			}, cards),
			spoiler
		]);
	}
});
