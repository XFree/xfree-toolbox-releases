'use strict';
'require baseclass';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.vpn-server-format as serverFormat';

var formatBytes = serverFormat.formatBytes;
var formatHandshake = serverFormat.formatHandshake;

/* Сетка клиентов сервера. Метод вешается на прототип xfree-vpn-server. */

return baseclass.extend({
	_renderPeerSection: function (awg) {
		var self = this;
		var peers = awg.peers || [];
		var peerCards = [];
		for (var i = 0; i < peers.length; i++) {
			(function (peer) {
				var diff = peer.latestHandshake > 0 ? (Math.floor(Date.now() / 1000) - peer.latestHandshake) : -1;
				var tone = diff >= 0 ? (diff < 180 ? 'ok' : (diff < 86400 ? 'warn' : 'muted')) : 'muted';
				var hsLabel = formatHandshake(peer.latestHandshake);
				var rxLabel = formatBytes(peer.rxBytes);
				var txLabel = formatBytes(peer.txBytes);

				var card = E('div', { 'class': 'xfree-vpn-tunnel is-' + tone }, [
					E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
						E('div', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
							E('span', { 'style': 'font-size:16px;' }, ['👤']),
							E('strong', {}, [peer.name || peer.slug])
						]),
						xcmp.badge({
							variant: 'vpn-status',
							tone: tone,
							text: hsLabel,
							title: peer.latestHandshake ? new Date(peer.latestHandshake * 1000).toLocaleString() : ''
						})
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-sub' }, [
						E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size:11px;' }, [peer.ip || '—']),
						peer.endpoint ? E('span', { 'class': 'muted', 'style': 'margin-left:6px; font-size:11px;' }, [peer.endpoint]) : ''
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-meta' }, [
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [_('трафик')]),
							E('span', {}, [rxLabel + ' ↓ / ' + txLabel + ' ↑'])
						]),
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [_('keepalive')]),
							E('span', {}, [(peer.keepalive || 25) + ' ' + _('сек')])
						]),
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [_('ключ')]),
							E('span', { 'style': 'font-family:monospace; font-size:11px;' }, [
								peer.pubkey ? (peer.pubkey.slice(0, 10) + '…' + peer.pubkey.slice(-6)) : '—'
							])
						])
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-actions' }, [
						xcmp.button({
							variant: 'vpn',
							primary: true,
							extraClass: 'is-primary',
							title: _('Показать QR-код для подключения WireGuard/AmneziaWG'),
							text: '📱 ' + _('QR-код'),
							onClick: function () { self._openPeerConfigDialog(peer, 'qr'); }
						}),
						xcmp.button({
							variant: 'vpn',
							primary: true,
							title: _('Просмотр и скачивание файла .conf'),
							text: '📄 ' + _('.conf'),
							onClick: function () { self._openPeerConfigDialog(peer, 'conf'); }
						}),
						awg.freeTurnInstalled ? xcmp.button({
							variant: 'vpn',
							primary: true,
							extraClass: 'is-primary',
							style: 'border-color: color-mix(in srgb, var(--primary) 70%, var(--line));',
							title: _('Показать QR-код и ссылку freeturn:// для мобильного приложения'),
							text: '⚡ ' + _('FreeTurn'),
							onClick: function (ev) {
								if (ev) ev.preventDefault();
								self._openPeerFreeTurnDialog(peer, awg);
							}
						}) : '',
						(function () {
							var editBtn = xcmp.button({
								variant: 'vpn',
								primary: true,
								style: 'display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; padding: 0 !important; font-size: 13px; border-radius: 6px;',
								title: _('Изменить endpoint для этого клиента'),
								ariaLabel: _('Изменить'),
								onClick: function () { self._openPeerEndpointDialog(peer, awg); }
							});
							editBtn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
							return editBtn;
						})(),
						(function () {
							var recBtn = xcmp.button({
								variant: 'vpn',
								primary: true,
								style: 'display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; padding: 0 !important; font-size: 13px; border-radius: 6px;',
								title: _('Пересоздать ключи клиента'),
								ariaLabel: _('Пересоздать'),
								onClick: function (ev) {
									self._act(ev, 'peerRecreateKeys', peer.slug, {
										title: _('Пересоздание ключей клиента'),
										message: _('Пересоздать ключи для клиента «%s»?').format(peer.name),
										detail: _('Старый файл .conf и QR-код на устройстве клиента перестанут подключаться. Потребуется импортировать обновлённый файл настроек на устройство пользователя.'),
										confirmText: _('Пересоздать'),
										tone: 'warn',
										icon: '🔄'
									});
								}
							});
							recBtn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/></svg>';
							return recBtn;
						})(),
						(function () {
							var delBtn = xcmp.button({
								variant: 'vpn',
								primary: true,
								extraClass: 'is-bad',
								style: 'display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; padding: 0 !important; font-size: 13px; border-radius: 6px; color: var(--bad);',
								title: _('Удалить клиента'),
								ariaLabel: _('Удалить'),
								onClick: function (ev) {
									self._act(ev, 'peerDelete', peer.slug, {
										title: _('Удаление VPN-клиента'),
										message: _('Удалить клиента «%s» (%s)?').format(peer.name, peer.ip),
										detail: _('Клиент будет безвозвратно удалён из базы и списка доверенных пиров сервера. Он больше не сможет подключаться.'),
										confirmText: _('Удалить'),
										tone: 'danger',
										icon: '🗑️'
									});
								}
							});
							delBtn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg>';
							return delBtn;
						})()
					])
				]);
				peerCards.push(card);
			})(peers[i]);
		}

		peerCards.push(E('div', { 'class': 'xfree-vpn-tunnel is-new' }, [
			E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
				E('strong', {}, [_('+ Добавить клиента')]),
				xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: _('новый') })
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-sub muted' }, [
				_('Генерация ключей → выделение IP → готовый .conf и QR-код')
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions xfree-vpn-create-actions' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					extraClass: 'is-primary',
					text: '➕ ' + _('Создать клиента'),
					onClick: function () { self._openAddPeerDialog(awg); }
				})
			])
		]));

		var peersSection = E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'style': 'display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; flex-wrap:wrap; gap:8px;' }, [
				E('div', { 'style': 'display:flex; align-items:center; gap:8px;' }, [
					E('h4', { 'style': 'margin:0;' }, [
						_('Клиенты сервера (%d)').format(peers.length)
					]),
					xui.helpBtn({
						title: _('Клиенты сервера (Пиры)'),
						desc: _('Список удалённых устройств (клиентов), зарегистрированных на вашем VPN-сервере. Каждому клиенту выделяется собственный IP-адрес из подсети сервера и уникальная ключевая пара.'),
						whatDoes: _('Кнопка «QR-код» открывает код для быстрого добавления туннеля через камеру смартфона в приложении AmneziaWG. Кнопка «.conf» позволяет скачать готовый файл конфигурации.'),
						tips: _('Если роутер находится за провайдерским NAT или сменился DDNS-домен, вы можете изменить Endpoint подключения для каждого клиента по отдельности кнопкой ✏️.')
					})
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnels' }, peerCards)
		]);
		return peersSection;
	}
});
