'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.luci-ui as xui';

/**
 * Диалог быстрого автоподбора стратегий Zapret (YouTube / Discord / Остальные сервисы).
 * Отображает интерактивный прогресс-бар в процентах, текущую проверяемую стратегию,
 * живую ленту найденных результатов и кнопку активации / переключения на Proton.
 */

function parseProbeOutput(text) {
	var lines = (text || '').split(/\r?\n/);
	var rows = [];
	var inTable = false;
	var i, line, m;
	var wanIf = '';
	var isYt = false;
	var bestPass = '';

	for (i = 0; i < lines.length; i++) {
		line = lines[i];
		if ((m = line.match(/WAN:\s*([a-zA-Z0-9_.-]+)/))) {
			wanIf = m[1];
		}
		if (/YouTube/i.test(line)) {
			isYt = true;
		}
		if ((m = line.match(/^best_pass=([a-zA-Z0-9_.@-]+)/))) {
			bestPass = m[1];
		}

		// Парсинг промежуточных строк CHECK_ROW
		if (line.indexOf('CHECK_ROW|') === 0) {
			var fields = {};
			var parts = line.substring(10).split('|');
			for (var j = 0; j < parts.length; j++) {
				var kv = parts[j].split('=');
				if (kv.length >= 2) {
					fields[kv[0]] = kv.slice(1).join('=');
				}
			}
			var secName = fields.service || fields.host;
			if (!rows.some(function(r) { return r.section === secName; })) {
				rows.push({
					section: secName,
					host: fields.host || '',
					proto: fields.proto || '',
					status: fields.status || 'FAIL',
					code: fields.code || '',
					latency: fields.latency || '',
					isPass: fields.status === 'PASS'
				});
			}
			continue;
		}

		if (/^-{20,}/.test(line)) {
			inTable = true;
			continue;
		}
		if (inTable) {
			if (!line.trim() || /^YouTube:|^Примечание:|^---/i.test(line)) {
				inTable = false;
				continue;
			}
			var tparts = line.trim().split(/\s+/);
			if (tparts.length >= 2) {
				var sec = tparts[0];
				var st = tparts[1];
				var code = tparts.length >= 3 ? tparts[2] : '';
				var lat = tparts.length >= 4 ? tparts[3] : '';
				var existingIdx = rows.findIndex(function(r) { return r.section === sec; });
				var prev = existingIdx >= 0 ? rows[existingIdx] : null;
				var rowObj = {
					section: sec,
					host: (prev && prev.host) || '',
					proto: (prev && prev.proto) || '',
					status: st,
					code: code,
					latency: lat,
					isPass: st === 'PASS'
				};
				if (existingIdx >= 0) {
					rows[existingIdx] = rowObj;
				} else {
					rows.push(rowObj);
				}
			}
		}
	}

	return {
		wanIf: wanIf,
		isYt: isYt,
		bestPass: bestPass,
		rows: rows
	};
}

return baseclass.extend({
	openProbeDialog: function(view, opts) {
		var self = this;
		self._selectedByGroup = {};
		self._updateComposeSummary = null;
		self._probeCancelled = false;
		self._lastParsed = null;
		var o = opts || {};
		var scopeTitle = o.sectionName
			? _('Секция «%s»').format(o.sectionName)
			: (o.isYt ? _('YouTube') : (o.target === 'discord' ? _('Discord') : _('Остальные сервисы')));

		var modalContent = E('div', {
			'class': 'xfree-zapret-probe-dialog',
			'style': 'width: 100%; box-sizing: border-box; background: transparent;'
		});

		var statusText = E('p', {
			'class': 'muted xfree-probe-status-text',
			'style': 'margin-bottom: 8px; font-size: 13px;'
		}, [ _('Подготовка и запуск быстрого подбора на канале WAN…') ]);

		var progressBar = E('div', {
			'class': 'xfree-progress-bar-bg',
			'style': 'width: 100%; height: 8px; background: rgba(120, 140, 160, 0.2); border-radius: 4px; overflow: hidden; margin: 8px 0 10px 0;'
		}, [
			E('div', {
				'class': 'xfree-progress-bar-fill',
				'style': 'width: 0%; height: 100%; background: #3498db; transition: width 0.3s ease;'
			})
		]);

		var progressWrap = E('div', {
			'class': 'xfree-probe-progress-wrap',
			'style': 'margin: 12px 0; padding: 12px; background: var(--panel-2); border-radius: 8px; border: 1px solid var(--line);'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;' }, [
				E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('span', { 'class': 'is-spinning', 'style': 'font-size: 16px;' }, [ '⚡' ]),
					E('strong', { 'class': 'xfree-probe-step-title' }, [ _('Инициализация тестовой очереди…') ])
				]),
				E('span', {
					'class': 'xfree-probe-percent-label',
					'style': 'font-size: 12px; font-weight: 600; color: #3498db;'
				}, [ '0%' ])
			]),
			progressBar,
			E('p', {
				'class': 'muted xfree-probe-step-detail',
				'style': 'margin: 0; font-size: 12px; font-family: monospace;'
			}, [ _('Инициализация тестовой очереди NFQUEUE на WAN…') ])
		]);

		var liveTableWrap = E('div', {
			'class': 'xfree-probe-live-table-wrap',
			'style': 'margin-top: 12px;'
		});

		modalContent.appendChild(statusText);
		modalContent.appendChild(progressWrap);
		modalContent.appendChild(liveTableWrap);

		var dlgHandle = xui.openDialog({
			title: '⚡ ' + _('Автоподбор стратегий: %s').format(scopeTitle),
			size: 'wide',
			body: modalContent,
			actions: [
				{
					label: '⏹ ' + _('Остановить'),
					variant: 'secondary',
					click: function() {
						self._probeCancelled = true;
						xui.runZapretMenu('stopProbe', '').catch(function() {});
						self._finalizeProbe(view, modalContent, dlgHandle, self._lastParsed || { rows: [] }, o, true);
					}
				},
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				}
			]
		});

		// Запуск RPC команды
		var rpcAction = o.isYt ? 'probeYoutube' : (o.target === 'discord' ? 'probeDiscord' : 'probeOthers');
		xui.runZapretMenu(rpcAction, '').then(function(res) {
			return self._pollProbeTask(view, modalContent, dlgHandle, o, 0);
		}).catch(function(err) {
			modalContent.replaceChildren(
				E('div', { 'class': 'alert-message danger' }, [
					_('Ошибка запуска автоподбора: %s').format(err && err.message || err)
				])
			);
		});
	},

	_pollProbeTask: function(view, container, dlgHandle, opts, attempt) {
		var self = this;
		var n = attempt || 0;
		if (self._probeCancelled) {
			return Promise.resolve();
		}

		return xui.runZapretMenu('taskStatus', '').then(function(res) {
			if (self._probeCancelled) {
				return;
			}
			var text = xui.formatExecReport(res || {});
			var running = xui.ifaceTaskRunning(res);
			var cleanText = xui.cleanTaskStatusOutput(text);

			var curIdx = 0, totIdx = 0, curPct = 0, curTitle = '', curDetail = '';

			// 1. Формат PROGRESS|idx=...|total=...|percent=...|action=...|detail=...
			var progMatch = cleanText.match(/PROGRESS\|idx=(\d+)\|total=(\d+)\|percent=(\d+)\|action=([^|]+)\|detail=([^\r\n|]+)/g);
			if (progMatch && progMatch.length > 0) {
				var lastProg = progMatch[progMatch.length - 1];
				var pm = lastProg.match(/idx=(\d+)\|total=(\d+)\|percent=(\d+)\|action=([^|]+)\|detail=([^\r\n|]+)/);
				if (pm) {
					curIdx = pm[1];
					totIdx = pm[2];
					curPct = pm[3];
					curTitle = pm[4];
					curDetail = pm[5];
				}
			} else {
				// 2. Формат PROBE_STEP|idx=...|total=...|section=...|host=...
				var stepMatch = cleanText.match(/PROBE_STEP\|idx=(\d+)\|total=(\d+)\|section=([^|]+)\|host=([^\r\n|]+)/g);
				if (stepMatch && stepMatch.length > 0) {
					var lastStep = stepMatch[stepMatch.length - 1];
					var sm = lastStep.match(/idx=(\d+)\|total=(\d+)\|section=([^|]+)\|host=([^\r\n|]+)/);
					if (sm) {
						curIdx = sm[1];
						totIdx = sm[2];
						curPct = Math.round((parseInt(curIdx, 10) / parseInt(totIdx, 10)) * 100);
						curTitle = sm[3];
						curDetail = _('Тестирование обхода DPI для %s (NFQWS)…').format(sm[4]);
					}
				}
			}

			// Обновляем прогресс-бар
			if (totIdx > 0) {
				var titleEl = container.querySelector('.xfree-probe-step-title');
				var detailEl = container.querySelector('.xfree-probe-step-detail');
				var fillEl = container.querySelector('.xfree-progress-bar-fill');
				var pctEl = container.querySelector('.xfree-probe-percent-label');

				if (titleEl) {
					titleEl.textContent = _('Тестирование [%s / %s]: %s').format(curIdx, totIdx, curTitle);
				}
				if (detailEl && curDetail) {
					detailEl.textContent = curDetail;
				}
				if (fillEl) {
					fillEl.style.width = curPct + '%';
				}
				if (pctEl) {
					pctEl.textContent = curPct + '%';
				}
			}

			// Живая таблица результатов
			var parsed = parseProbeOutput(cleanText);
			self._lastParsed = parsed;
			var liveTableWrap = container.querySelector('.xfree-probe-live-table-wrap');
			if (liveTableWrap && parsed.rows.length > 0) {
				self._renderRowsTableOnly(liveTableWrap, parsed.rows, view, opts);
			}

			if (running && n < 120 && !self._probeCancelled) {
				return new Promise(function(resolve) {
					setTimeout(function() {
						resolve(self._pollProbeTask(view, container, dlgHandle, opts, n + 1));
					}, 1200);
				});
			}

			// Завершение автоподбора
			if (!self._probeCancelled) {
				self._finalizeProbe(view, container, dlgHandle, parsed, opts, false);
			}
		}).catch(function(err) {
			container.replaceChildren(
				E('div', { 'class': 'alert-message danger' }, [
					_('Ошибка опроса результатов: %s').format(err && err.message || err)
				])
			);
		});
	},

	_renderRowsTableOnly: function(wrap, rows, view, opts) {
		var self = this;
		var filter = self._currentFilter || 'all';
		var passCount = rows.filter(function(r) { return r.isPass; }).length;
		var failCount = rows.length - passCount;

		var filteredRows = rows.filter(function(r) {
			if (filter === 'pass') return r.isPass;
			if (filter === 'fail') return !r.isPass;
			return true;
		});

		var groups = [];
		var groupMap = {};
		filteredRows.forEach(function(r) {
			var protoLabel = r.proto || _('Проверка обхода DPI');
			var hostLabel = r.host || '';
			var gKey = protoLabel + '||' + hostLabel;
			if (!groupMap[gKey]) {
				groupMap[gKey] = {
					key: gKey,
					proto: protoLabel,
					host: hostLabel,
					items: []
				};
				groups.push(groupMap[gKey]);
			}
			groupMap[gKey].items.push(r);
		});

		var isCompound = !!(opts && opts.target === 'discord');
		if (!self._selectedByGroup) self._selectedByGroup = {};
		if (isCompound) {
			groups.forEach(function(grp) {
				if (!self._selectedByGroup[grp.key]) {
					var passItems = grp.items.filter(function(x) { return x.isPass; });
					if (passItems.length > 0) {
						passItems.sort(function(a, b) {
							return (parseFloat(a.latency) || 999) - (parseFloat(b.latency) || 999);
						});
						self._selectedByGroup[grp.key] = passItems[0].section;
					}
				}
			});
		}

		var trs = [];
		groups.forEach(function(grp) {
			var grpPass = grp.items.filter(function(x) { return x.isPass; }).length;
			var grpTotal = grp.items.length;
			var grpIcon = '🎯';
			if (/WAN6|IPv6/i.test(grp.proto)) grpIcon = '🌍';
			else if (/Голос|Voice|UDP/i.test(grp.proto)) grpIcon = '🎙️';
			else if (/Медиа|Media|Screen/i.test(grp.proto)) grpIcon = '🎬';
			else if (/Основные|Web/i.test(grp.proto)) grpIcon = '🌐';
			else if (/fake/i.test(grp.proto)) grpIcon = '🎭';

			var grpBadge = xcmp.badge({
				variant: 'vpn-status',
				tone: grpPass > 0 ? 'ok' : 'bad',
				text: grpPass + ' / ' + grpTotal + ' PASS',
				style: 'font-size: 11px; padding: 2px 8px;'
			});

			trs.push(E('tr', { 'style': 'background-color: #f1f5f9 !important;' }, [
				E('td', {
					'colspan': '2',
					'style': 'padding: 8px 12px; border-bottom: 1px solid #cbd5e1; border-top: 1px solid #cbd5e1; font-weight: 600; font-size: 12.5px; color: #0f172a; background-color: inherit;'
				}, [
					E('span', { 'style': 'margin-right: 6px;' }, [ grpIcon ]),
					E('span', {}, [ grp.proto ]),
					grp.host ? E('span', { 'style': 'font-weight: 400; font-size: 11.5px; color: #64748b; margin-left: 8px;' }, [ '· ' + grp.host ]) : ''
				]),
				E('td', {
					'colspan': '2',
					'style': 'padding: 8px 12px; text-align: right; border-bottom: 1px solid #cbd5e1; border-top: 1px solid #cbd5e1; background-color: inherit;'
				}, [ grpBadge ])
			]));

			grp.items.forEach(function(r, idx) {
				var isLast = idx === grp.items.length - 1;
				var badge = xcmp.badge({
					variant: 'vpn-status',
					tone: r.isPass ? 'ok' : 'bad',
					text: r.isPass ? 'PASS (' + r.code + ')' : (r.code || 'FAIL'),
					style: 'font-size: 11px; padding: 2px 7px;'
				});

				var isSelected = isCompound && self._selectedByGroup[grp.key] === r.section;
				var actionCellEl = '';
				if (r.isPass) {
					if (isCompound) {
						var toggleInput = E('input', {
							'type': 'checkbox',
							'checked': isSelected ? 'checked' : null,
							'title': _('Выбрать эту стратегию для блока «%s»').format(grp.proto),
							'change': function() {
								self._selectedByGroup[grp.key] = r.section;
								self._renderRowsTableOnly(wrap, rows, view, opts);
								if (typeof self._updateComposeSummary === 'function') {
									self._updateComposeSummary();
								}
							}
						});
						toggleInput.checked = isSelected;
						actionCellEl = E('label', {
							'class': 'xfree-zapret-toggle',
							'title': _('Выбрать эту стратегию для блока «%s»').format(grp.proto)
						}, [
							toggleInput,
							E('span', { 'class': 'xfree-zapret-toggle-slider' })
						]);
					} else {
						actionCellEl = E('button', {
							'class': 'btn primary',
							'style': 'padding: 4px 10px; font-size: 11.5px;',
							'click': function() {
								self._activateStrategy(view, r.section, opts);
							}
						}, [ _('Активировать') ]);
					}
				}

				var rowBg = isSelected
					? 'background-color: #dcfce7 !important; font-weight: 600;'
					: (r.isPass
						? 'background-color: #f0fdf4 !important; font-weight: 500;'
						: (idx % 2 === 1 ? 'background-color: #f8fafc !important;' : 'background-color: #ffffff !important;'));

				trs.push(E('tr', { 'style': rowBg }, [
					E('td', { 'style': 'padding: 7px 12px 7px 26px; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [
						E('span', { 'style': 'color: #94a3b8; font-family: monospace; margin-right: 6px;' }, [ isLast ? '└─' : '├─' ]),
						E('span', {}, [ r.isPass ? '⭐ ' + r.section : r.section ])
					]),
					E('td', { 'style': 'padding: 7px 12px; text-align: center; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [ badge ]),
					E('td', { 'style': 'padding: 7px 12px; text-align: right; font-family: monospace; font-size: 12px; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [
						r.latency || '-'
					]),
					E('td', { 'style': 'padding: 7px 12px; text-align: right; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [
						actionCellEl
					])
				]));
			});
		});

		var thStyle = 'padding: 10px 12px; position: sticky; top: 0; z-index: 10; background-color: #ffffff !important; border-bottom: 2px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08); font-weight: 600; font-size: 12px; color: #1e293b;';

		var filterBar = E('div', {
			'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 12px;'
		}, [
			E('div', { 'style': 'display: flex; gap: 6px;' }, [
				E('button', {
					'class': 'btn ' + (filter === 'all' ? 'primary' : 'secondary'),
					'style': 'padding: 3px 10px; font-size: 11.5px; border-radius: 4px;',
					'click': function() {
						self._currentFilter = 'all';
						self._renderRowsTableOnly(wrap, rows, view, opts);
					}
				}, [ _('Все (%s)').format(rows.length) ]),
				E('button', {
					'class': 'btn ' + (filter === 'pass' ? 'primary' : 'secondary'),
					'style': 'padding: 3px 10px; font-size: 11.5px; border-radius: 4px;' + (filter !== 'pass' && passCount > 0 ? ' color: #27ae60;' : ''),
					'click': function() {
						self._currentFilter = 'pass';
						self._renderRowsTableOnly(wrap, rows, view, opts);
					}
				}, [ '⭐ ' + _('Рабочие (%s)').format(passCount) ]),
				E('button', {
					'class': 'btn ' + (filter === 'fail' ? 'primary' : 'secondary'),
					'style': 'padding: 3px 10px; font-size: 11.5px; border-radius: 4px;',
					'click': function() {
						self._currentFilter = 'fail';
						self._renderRowsTableOnly(wrap, rows, view, opts);
					}
				}, [ _('Сбои (%s)').format(failCount) ])
			]),
			E('span', { 'class': 'muted', 'style': 'font-size: 11.5px;' }, [
				passCount > 0
					? _('Найдено %s рабочих стратегий').format(passCount)
					: _('Идёт тестирование кандидатов…')
			])
		]);

		var table = E('div', {
			'style': 'max-height: 420px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 8px; background-color: #ffffff !important;'
		}, [
			E('table', { 'class': 'table', 'style': 'width: 100%; margin: 0; font-size: 12.5px; border-collapse: separate; border-spacing: 0; background-color: #ffffff !important;' }, [
				E('thead', {}, [
					E('tr', {}, [
						E('th', { 'style': thStyle }, [ _('Стратегия / Секция') ]),
						E('th', { 'style': thStyle + ' text-align: center;' }, [ _('Результат') ]),
						E('th', { 'style': thStyle + ' text-align: right;' }, [ _('Отклик') ]),
						E('th', { 'style': thStyle + ' text-align: right;' }, [ _('Действие') ])
					])
				]),
				E('tbody', {}, trs.length > 0 ? trs : [
					E('tr', {}, [
						E('td', { 'colspan': 4, 'style': 'padding: 24px; text-align: center; color: var(--text-muted); background-color: #ffffff !important;' }, [
							_('Нет записей в выбранном фильтре.')
						])
					])
				])
			])
		]);

		wrap.replaceChildren(filterBar, table);
	},

	_finalizeProbe: function(view, container, dlgHandle, data, opts, wasCancelled) {
		var self = this;
		var rows = data.rows || [];
		var hasPass = rows.some(function(r) { return r.isPass; });
		var bestRow = rows.find(function(r) { return r.isPass; });

		// Фиксируем прогресс-бар на 100% (или статус остановки)
		var fillEl = container.querySelector('.xfree-progress-bar-fill');
		var pctEl = container.querySelector('.xfree-probe-percent-label');
		var titleEl = container.querySelector('.xfree-probe-step-title');
		var detailEl = container.querySelector('.xfree-probe-step-detail');
		var spinner = container.querySelector('.is-spinning');

		if (fillEl) {
			if (!wasCancelled) fillEl.style.width = '100%';
			if (wasCancelled) fillEl.style.backgroundColor = '#f59e0b';
		}
		if (pctEl && !wasCancelled) pctEl.textContent = '100%';
		if (titleEl) titleEl.textContent = wasCancelled ? _('Автоподбор остановлен') : _('Автоподбор завершён');
		if (detailEl) detailEl.textContent = wasCancelled
			? _('Подбор остановлен пользователем. Доступны уже проверенные стратегии.')
			: _('Тестирование пула кандидатов завершено.');
		if (spinner) {
			spinner.className = '';
			spinner.textContent = wasCancelled ? '⏹' : (hasPass ? '⚡' : '⚠️');
		}

		// Итоговый баннер с гарантированной изоляцией ширины (box-sizing: border-box)
		var existingBanner = container.querySelector('.xfree-probe-result-banner');
		if (existingBanner) existingBanner.remove();

		var banner;
		if (hasPass) {
			banner = E('div', {
				'class': 'xfree-probe-result-banner',
				'style': 'margin: 12px 0; padding: 12px 16px; border-radius: 8px; background-color: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; box-sizing: border-box; width: 100%;'
			}, [
				E('strong', { 'style': 'display: block; font-size: 13px; font-weight: 600; color: #047857;' }, [ _('Найдена рабочая стратегия: %s!').format(bestRow.section) ]),
				E('p', { 'style': 'margin: 4px 0 0 0; font-size: 12px; color: #065f46;' }, [
					_('HTTP-код: %s, время отклика: %s. Вы можете активировать её прямо сейчас.').format(bestRow.code, bestRow.latency || 'OK')
				])
			]);
		} else {
			banner = E('div', {
				'class': 'xfree-probe-result-banner',
				'style': 'margin: 12px 0; padding: 12px 16px; border-radius: 8px; background-color: #fffbeb; border: 1px solid #fde68a; color: #92400e; box-sizing: border-box; width: 100%;'
			}, [
				E('strong', { 'style': 'display: block; font-size: 13px; font-weight: 600; color: #b45309;' }, [ _('Ни одна стратегия не смогла обойти блокировку на канале WAN.') ]),
				E('p', { 'style': 'margin: 4px 0 0 0; font-size: 12px; color: #92400e;' }, [
					opts.isYt
						? _('Провайдер блокирует прямой доступ на IPv4. Рекомендуется переключить YouTube в туннель Proton VPN.')
						: _('Все кандидаты завершились тайм-аутом или ошибкой.')
				])
			]);
		}

		var progressWrap = container.querySelector('.xfree-probe-progress-wrap');
		if (progressWrap) {
			progressWrap.insertAdjacentElement('afterend', banner);
		}

		var liveTableWrap = container.querySelector('.xfree-probe-live-table-wrap');
		if (liveTableWrap && rows.length > 0) {
			self._renderRowsTableOnly(liveTableWrap, rows, view, opts);
		}

		// Кнопки действий в подвале через унифицированный xui dialog API
		var actionBtns = [];

		if (opts.isYt && !hasPass) {
			actionBtns.push({
				label: '🛡️ ' + _('Переключить YouTube на Proton VPN'),
				variant: 'primary',
				click: function() {
					dlgHandle.hide();
					self._switchToProton(view);
				}
			});
		} else if (opts.target === 'discord' && hasPass) {
			var getChosenFor = function(re) {
				var sel = self._selectedByGroup || {};
				var keys = Object.keys(sel);
				for (var k = 0; k < keys.length; k++) {
					if (re.test(keys[k])) return sel[keys[k]];
				}
				return '-';
			};
			var secNameInput = E('input', {
				'type': 'text',
				'class': 'cbi-input-text',
				'value': 'discord',
				'placeholder': 'discord',
				'style': 'width: 180px; padding: 5px 8px; font-size: 12.5px; border: 1px solid #cbd5e1; border-radius: 6px;'
			});
			var comboSummary = E('div', { 'class': 'muted', 'style': 'font-size: 11.5px; margin-top: 4px;' });
			self._updateComposeSummary = function() {
				var w = getChosenFor(/Основные|Web/i);
				var m = getChosenFor(/Медиа|Media/i);
				var v = getChosenFor(/Голос|Voice/i);
				comboSummary.textContent = _('Выбрано: %s · %s · %s').format(w, m, v);
			};
			self._updateComposeSummary();

			var composeBox = E('div', {
				'style': 'margin-top: 10px; padding: 10px 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;'
			}, [
				E('div', {}, [
					E('div', { 'style': 'font-size: 12.5px; font-weight: 600; color: #0f172a;' }, [ _('Сборка единой секции из отмеченных стратегий') ]),
					comboSummary
				]),
				E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('span', { 'style': 'font-size: 12px; color: #475569;' }, [ _('Имя секции:') ]),
					secNameInput
				])
			]);
			container.appendChild(composeBox);

			actionBtns.push({
				label: '⚡ ' + _('Собрать и активировать'),
				variant: 'primary',
				click: function() {
					var targetName = (secNameInput.value || 'discord').replace(/[^A-Za-z0-9._-]/g, '') || 'discord';
					var w = getChosenFor(/Основные|Web/i);
					var m = getChosenFor(/Медиа|Media/i);
					var v = getChosenFor(/Голос|Voice/i);
					dlgHandle.hide();
					self._activateStrategy(view, 'compose:' + targetName + ':' + w + ':' + m + ':' + v, opts);
				}
			});
		} else if (bestRow) {
			actionBtns.push({
				label: '⚡ ' + _('Активировать лучшую (%s)').format(bestRow.section),
				variant: 'primary',
				click: function() {
					dlgHandle.hide();
					self._activateStrategy(view, bestRow.section, opts);
				}
			});
		}

		actionBtns.push({
			label: _('Закрыть'),
			variant: 'secondary',
			close: true
		});

		dlgHandle.setActions(actionBtns);
	},

	_activateStrategy: function(view, secName, opts) {
		var displaySec = secName;
		if (secName && secName.indexOf('compose:') === 0) {
			displaySec = secName.split(':')[1] || 'discord';
		}
		var waitDlg = xui.openDialog({
			title: '⏳ ' + _('Применение стратегии…'),
			body: [
				E('p', { 'class': 'muted' }, [ _('Сборка и применение секции «%s» в Zapret…').format(displaySec) ])
			],
			actions: []
		});

		xui.runZapretMenu('activateStrategy', secName).then(function() {
			waitDlg.hide();
			if (view && typeof view.reloadZapret === 'function') {
				view.reloadZapret();
			} else if (view && typeof view.onRefresh === 'function') {
				view.onRefresh();
			} else if (view && view._spec && typeof view._spec.onRefresh === 'function') {
				view._spec.onRefresh();
			} else if (view && typeof view.requestPaint === 'function') {
				view.requestPaint();
			} else {
				window.location.reload();
			}
			ui.addNotification(null, E('p', {}, [
				_('Стратегия «%s» успешно активирована и применена.').format(secName)
			]), 'info');
		}).catch(function(err) {
			waitDlg.hide();
			ui.addNotification(null, E('p', {}, [
				_('Ошибка активации: %s').format(err && err.message || err)
			]), 'danger');
		});
	},

	_switchToProton: function(view) {
		var waitDlg = xui.openDialog({
			title: '⏳ ' + _('Переключение маршрутизации…'),
			body: [
				E('p', { 'class': 'muted' }, [ _('Отключение секций Zapret и перенаправление YouTube в Proton VPN…') ])
			],
			actions: []
		});

		xui.runZapretMenu('routeYoutubeProton', '').then(function() {
			waitDlg.hide();
			if (view && view.reloadZapret)
				view.reloadZapret();
			ui.addNotification(null, E('p', {}, [
				_('YouTube успешно переключён на Proton VPN (Zapret исключён).')
			]), 'info');
		}).catch(function(err) {
			waitDlg.hide();
			ui.addNotification(null, E('p', {}, [
				_('Ошибка переключения на Proton: %s').format(err && err.message || err)
			]), 'danger');
		});
	}
});
