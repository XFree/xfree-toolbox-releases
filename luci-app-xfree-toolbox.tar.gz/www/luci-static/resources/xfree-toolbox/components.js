'use strict';
'require baseclass';
'require ui';

/**
 * Библиотека атомарных компонентов xfree-toolbox (Atomic Design).
 * Предоставляет чистые функции построения UI-элементов поверх LuCI DOM-билдера E().
 */

/**
 * Бейдж статуса (Atom).
 * @param {Object} opts
 * @param {string|Node} opts.text Текст бейджа
 * @param {'ok'|'warn'|'err'|'muted'|'standby'|'info'} [opts.tone='muted'] Цветовая тональность
 * @param {string|Node} [opts.icon] Иконка перед текстом
 * @param {boolean} [opts.pulse] Пульсирующая анимация (для активных состояний)
 * @param {string} [opts.extraClass] Дополнительный CSS класс
 * @param {string} [opts.title] Тултип
 * @returns {Node}
 */
function uiBadge(opts) {
	opts = opts || {};
	var tone = opts.tone || 'muted';
	var cls = 'xfree-badge is-' + tone;
	if (opts.pulse) cls += ' is-pulse';
	if (opts.extraClass) cls += ' ' + opts.extraClass;

	var children = [];
	if (opts.icon) {
		children.push(E('span', { 'class': 'badge-icon', 'style': 'margin-right: 4px;' }, [opts.icon]));
	}
	if (opts.text != null) {
		children.push(opts.text);
	}

	return E('span', { 'class': cls, 'title': opts.title || '' }, children);
}

/**
 * Кнопка действия (Atom).
 * @param {Object} opts
 * @param {string|Node} opts.text Текст кнопки
 * @param {'primary'|'danger'|'ghost'|'ghost-compact'} [opts.tone] Стиль кнопки
 * @param {'sm'|'md'} [opts.size='md'] Размер кнопки
 * @param {string|Node} [opts.icon] Иконка
 * @param {boolean} [opts.loading] Режим загрузки со спиннером
 * @param {boolean} [opts.disabled] Заблокирована ли кнопка
 * @param {Function} [opts.onClick] Обработчик клика
 * @param {string} [opts.extraClass] Дополнительный класс
 * @param {string} [opts.title] Тултип
 * @returns {Node}
 */
function uiButton(opts) {
	opts = opts || {};
	var cls = 'btn';
	if (opts.size === 'sm' || opts.tone === 'ghost-compact') cls += ' ghost-compact';
	if (opts.tone && opts.tone !== 'ghost-compact') cls += ' is-' + opts.tone;
	if (opts.extraClass) cls += ' ' + opts.extraClass;

	var children = [];
	if (opts.loading) {
		children.push(E('span', { 'class': 'spinner is-sm', 'style': 'display: inline-block; width: 12px; height: 12px; border: 2px solid currentColor; border-right-color: transparent; border-radius: 50%; vertical-align: middle; margin-right: 6px; animation: xfree-spin 0.6s linear infinite;' }));
	} else if (opts.icon) {
		children.push(E('span', { 'class': 'btn-icon', 'style': 'margin-right: 4px;' }, [opts.icon]));
	}
	if (opts.text != null) {
		children.push(opts.text);
	}

	var btnAttrs = {
		'class': cls,
		'type': 'button',
		'title': opts.title || ''
	};
	if (opts.disabled || opts.loading) {
		btnAttrs.disabled = '';
	}
	if (opts.id) {
		btnAttrs.id = opts.id;
	}

	var btn = E('button', btnAttrs, children);
	if (opts.disabled || opts.loading) {
		btn.disabled = true;
	}

	if (typeof opts.onClick === 'function') {
		btn.addEventListener('click', function (ev) {
			if (!opts.disabled && !opts.loading) {
				opts.onClick(ev);
			}
		});
	}

	return btn;
}

/**
 * Скелетон загрузки данных (Atom).
 * @param {Object} [opts]
 * @param {string} [opts.width='100%']
 * @param {string} [opts.height='14px']
 * @param {string} [opts.extraClass]
 * @returns {Node}
 */
function uiSkeleton(opts) {
	opts = opts || {};
	var style = 'width: ' + (opts.width || '100%') + '; height: ' + (opts.height || '14px') + ';';
	return E('span', {
		'class': 'xfree-skeleton-line' + (opts.extraClass ? ' ' + opts.extraClass : ''),
		'style': style
	});
}

/**
 * Информационный чип статистики / статуса (Atom/Molecule).
 * @param {Object} opts
 * @param {string|Node} opts.label Название метрики
 * @param {string|Node} [opts.value] Значение метрики
 * @param {'ok'|'warn'|'err'|'muted'} [opts.tone] Тональность
 * @param {boolean} [opts.loading] Режим загрузки
 * @param {Function} [opts.onClick] Клик по чипу
 * @param {string} [opts.extraClass]
 * @returns {Node}
 */
function uiChip(opts) {
	opts = opts || {};
	if (opts.loading) {
		return E('div', { 'class': 'xfree-uplink-chip is-loading' + (opts.extraClass ? ' ' + opts.extraClass : '') }, [
			E('span', { 'class': 'k' }, [opts.label || '']),
			E('span', { 'class': 'v' }, [uiSkeleton({ width: '65px', height: '14px' })])
		]);
	}

	var cls = 'xfree-uplink-chip' + (opts.tone ? ' is-' + opts.tone : '') + (opts.extraClass ? ' ' + opts.extraClass : '');
	var chip = E('div', { 'class': cls }, [
		E('span', { 'class': 'k' }, [opts.label || '']),
		E('span', { 'class': 'v' }, [opts.value != null ? opts.value : '—'])
	]);

	if (typeof opts.onClick === 'function') {
		chip.style.cursor = 'pointer';
		chip.addEventListener('click', opts.onClick);
	}

	return chip;
}

/**
 * Текстовое поле формы CBI (Molecule).
 * @param {Object} opts
 * @param {string} [opts.id] ID элемента
 * @param {string} [opts.label] Заголовок поля
 * @param {string} [opts.value] Текущее значение
 * @param {string} [opts.placeholder] Подсказка в поле
 * @param {string} [opts.type='text'] Тип input
 * @param {string} [opts.hint] Поясняющее описание
 * @param {string} [opts.error] Текст ошибки валидации
 * @param {boolean} [opts.disabled] Заблокировано
 * @param {Function} [opts.onChange] Коллбэк изменения значения
 * @param {Function} [opts.onInput] Коллбэк ввода
 * @returns {Node}
 */
function uiInputField(opts) {
	opts = opts || {};
	var inputAttrs = {
		'class': 'cbi-input-text',
		'type': opts.type || 'text',
		'value': opts.value != null ? String(opts.value) : '',
		'placeholder': opts.placeholder || ''
	};
	if (opts.disabled) {
		inputAttrs.disabled = '';
	}
	if (opts.id) {
		inputAttrs.id = opts.id;
		inputAttrs.name = opts.id;
	}

	var inputEl = E('input', inputAttrs);
	if (opts.onInput) {
		inputEl.addEventListener('input', function (e) { opts.onInput(e.target.value, e); });
	}
	if (opts.onChange) {
		inputEl.addEventListener('change', function (e) { opts.onChange(e.target.value, e); });
	}

	var fieldChildren = [inputEl];
	if (opts.hint) {
		fieldChildren.push(E('div', { 'class': 'cbi-value-description' }, [opts.hint]));
	}
	if (opts.error) {
		fieldChildren.push(E('div', { 'class': 'cbi-value-error-msg', 'style': 'color: var(--err-color, #c00); font-size: 12px; margin-top: 4px;' }, [opts.error]));
	}

	return E('div', { 'class': 'cbi-value' + (opts.error ? ' cbi-value-error' : '') }, [
		opts.label ? E('label', { 'class': 'cbi-value-title', 'for': opts.id || '' }, [opts.label]) : null,
		E('div', { 'class': 'cbi-value-field' }, fieldChildren)
	]);
}

/**
 * Выпадающий список формы CBI (Molecule).
 * @param {Object} opts
 * @param {string} [opts.id] ID элемента
 * @param {string} [opts.label] Заголовок поля
 * @param {string} [opts.value] Выбранное значение
 * @param {Array<string|{value: string, label: string, disabled?: boolean}>} [opts.options] Варианты
 * @param {string} [opts.hint] Поясняющее описание
 * @param {string} [opts.error] Текст ошибки
 * @param {boolean} [opts.disabled] Заблокировано
 * @param {Function} [opts.onChange] Коллбэк изменения
 * @returns {Node}
 */
function uiSelectField(opts) {
	opts = opts || {};
	var optEls = (opts.options || []).map(function (item) {
		var val = typeof item === 'object' && item !== null ? item.value : item;
		var lbl = typeof item === 'object' && item !== null ? item.label : item;
		var optAttrs = { 'value': val };
		if (String(val) === String(opts.value)) {
			optAttrs.selected = 'selected';
		}
		if (item && item.disabled) {
			optAttrs.disabled = 'disabled';
		}
		return E('option', optAttrs, [lbl]);
	});

	var selectAttrs = {
		'class': 'cbi-input-select'
	};
	if (opts.disabled) {
		selectAttrs.disabled = '';
	}
	if (opts.id) {
		selectAttrs.id = opts.id;
		selectAttrs.name = opts.id;
	}

	var selectEl = E('select', selectAttrs, optEls);
	if (opts.onChange) {
		selectEl.addEventListener('change', function (e) { opts.onChange(e.target.value, e); });
	}

	var fieldChildren = [selectEl];
	if (opts.hint) {
		fieldChildren.push(E('div', { 'class': 'cbi-value-description' }, [opts.hint]));
	}
	if (opts.error) {
		fieldChildren.push(E('div', { 'class': 'cbi-value-error-msg', 'style': 'color: var(--err-color, #c00); font-size: 12px; margin-top: 4px;' }, [opts.error]));
	}

	return E('div', { 'class': 'cbi-value' + (opts.error ? ' cbi-value-error' : '') }, [
		opts.label ? E('label', { 'class': 'cbi-value-title', 'for': opts.id || '' }, [opts.label]) : null,
		E('div', { 'class': 'cbi-value-field' }, fieldChildren)
	]);
}

/**
 * Карточка контента / туннеля / компонента (Molecule / Organism).
 * @param {Object} opts
 * @param {string|Node} [opts.title] Заголовок карточки
 * @param {string|Node} [opts.subtitle] Подзаголовок
 * @param {Node} [opts.badge] Бейдж в шапке
 * @param {'ok'|'warn'|'err'|'muted'} [opts.tone] Тональность рамки / индикатора
 * @param {Array<Node>} [opts.actions] Кнопки действий в шапке карточки
 * @param {Node|Array<Node>} [opts.content] Тело карточки
 * @param {string} [opts.extraClass] Дополнительный класс карточки
 * @param {string} [opts.bodyClass] Дополнительный класс тела
 * @returns {Node}
 */
function uiCard(opts) {
	opts = opts || {};
	var cardCls = 'xfree-card' + (opts.tone ? ' is-' + opts.tone : '') + (opts.extraClass ? ' ' + opts.extraClass : '');
	var cardParts = [];

	var hasHeader = opts.title || opts.subtitle || opts.badge || (opts.actions && opts.actions.length);
	if (hasHeader) {
		var titleBlock = [];
		if (opts.title) {
			titleBlock.push(E('div', { 'class': 'xfree-card-title', 'style': 'font-weight: 600; font-size: 15px;' }, [opts.title]));
		}
		if (opts.subtitle) {
			titleBlock.push(E('div', { 'class': 'xfree-card-subtitle muted', 'style': 'font-size: 12px; opacity: 0.8;' }, [opts.subtitle]));
		}

		var leftBlock = E('div', { 'class': 'xfree-card-header-left' }, titleBlock);
		var rightItems = [];
		if (opts.badge) {
			rightItems.push(E('span', { 'class': 'xfree-card-badge' }, [opts.badge]));
		}
		if (opts.actions && opts.actions.length) {
			rightItems.push(E('div', { 'class': 'xfree-card-actions', 'style': 'display: flex; gap: 6px; align-items: center;' }, opts.actions));
		}
		var rightBlock = E('div', { 'class': 'xfree-card-header-right', 'style': 'display: flex; gap: 8px; align-items: center;' }, rightItems);

		cardParts.push(E('div', {
			'class': 'xfree-card-header',
			'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid var(--border-color, rgba(0,0,0,0.08));'
		}, [leftBlock, rightBlock]));
	}

	if (opts.content) {
		var contentArray = Array.isArray(opts.content) ? opts.content : [opts.content];
		cardParts.push(E('div', { 'class': 'xfree-card-body' + (opts.bodyClass ? ' ' + opts.bodyClass : '') }, contentArray));
	}

	return E('div', { 'class': cardCls }, cardParts);
}

/**
 * Модальный диалог подтверждения / настройки (Organism).
 * @param {Object} opts
 * @param {string} opts.title Заголовок диалога
 * @param {Node|Array<Node>} opts.body Содержимое
 * @param {string} [opts.confirmText='Применить'] Текст кнопки действия
 * @param {string} [opts.cancelText='Отмена'] Текст отмены
 * @param {'primary'|'danger'} [opts.confirmTone='primary'] Тон кнопки действия
 * @param {Function} opts.onConfirm Коллбэк подтверждения (возврат Promise сохраняет модалку до резолва)
 * @param {Function} [opts.onCancel] Коллбэк отмены
 */
function uiModalDialog(opts) {
	opts = opts || {};
	var bodyContent = Array.isArray(opts.body) ? opts.body : [opts.body];
	var confirmBtn;

	var cancelBtn = uiButton({
		text: opts.cancelText || _('Отмена'),
		tone: 'ghost',
		onClick: function () {
			ui.hideModal();
			if (typeof opts.onCancel === 'function') {
				opts.onCancel();
			}
		}
	});

	confirmBtn = uiButton({
		text: opts.confirmText || _('Применить'),
		tone: opts.confirmTone || 'primary',
		onClick: function () {
			if (typeof opts.onConfirm !== 'function') {
				ui.hideModal();
				return;
			}
			confirmBtn.disabled = true;
			cancelBtn.disabled = true;
			try {
				var res = opts.onConfirm();
				if (res && typeof res.then === 'function') {
					res.then(function () {
						ui.hideModal();
					}).catch(function (err) {
						confirmBtn.disabled = false;
						cancelBtn.disabled = false;
						ui.addNotification(null, E('p', {}, [err.message || String(err)]), 'error');
					});
				} else {
					ui.hideModal();
				}
			} catch (err) {
				confirmBtn.disabled = false;
				cancelBtn.disabled = false;
				ui.addNotification(null, E('p', {}, [err.message || String(err)]), 'error');
			}
		}
	});

	var modalNode = E('div', { 'class': 'xfree-modal-inner' }, [
		E('div', { 'class': 'xfree-modal-body', 'style': 'margin-bottom: 16px;' }, bodyContent),
		E('div', { 'class': 'xfree-modal-actions', 'style': 'display: flex; justify-content: flex-end; gap: 8px;' }, [
			cancelBtn,
			confirmBtn
		])
	]);

	ui.showModal(opts.title || _('Настройка'), [modalNode]);
}

/**
 * Прогресс-бар заполнения ресурса (память, диск, нагрузка) (Atom).
 * @param {Object} opts
 * @param {number} opts.value Процент от 0 до 100
 * @param {'ok'|'warn'|'err'|'accent'} [opts.tone]
 * @param {string} [opts.height='8px']
 * @param {string} [opts.extraClass]
 * @returns {Node}
 */
function uiProgressBar(opts) {
	opts = opts || {};
	var pct = Math.min(100, Math.max(0, Math.round(Number(opts.value) || 0)));
	var tone = opts.tone;
	if (!tone) {
		if (pct >= 90) tone = 'err';
		else if (pct >= 75) tone = 'warn';
		else tone = 'ok';
	}
	var trackCls = 'xfree-progress-track' + (opts.extraClass ? ' ' + opts.extraClass : '');
	var barCls = 'xfree-progress-fill is-' + tone;
	return E('div', {
		'class': trackCls,
		'style': 'height: ' + (opts.height || '8px') + ';'
	}, [
		E('div', {
			'class': barCls,
			'style': 'width: ' + pct + '%;'
		})
	]);
}

/**
 * Круговой индикатор загрузки (Atom: Spinner).
 * @param {Object} [opts]
 * @param {'sm'|'md'|'lg'} [opts.size='md']
 * @param {string} [opts.extraClass]
 * @returns {Node}
 */
function uiSpinner(opts) {
	opts = opts || {};
	var cls = 'xfree-spinner';
	if (opts.size === 'sm') cls += ' xfree-spinner-sm';
	else if (opts.size === 'lg') cls += ' xfree-spinner-lg';
	if (opts.extraClass) cls += ' ' + opts.extraClass;
	return E('span', { 'class': cls });
}

/**
 * Панель заголовка страницы / секции с описанием и действиями (Molecule).
 * @param {Object} opts
 * @param {string|Node} opts.title Заголовок секции
 * @param {string|Node} [opts.description] Описание
 * @param {Node|Array<Node>} [opts.actions] Элементы действий справа
 * @param {string} [opts.extraClass]
 * @returns {Node}
 */
function uiActionBar(opts) {
	opts = opts || {};
	var leftChildren = [];
	if (opts.title) {
		leftChildren.push(E('div', { 'style': 'font-weight: 600; font-size: 15px;' }, [ opts.title ]));
	}
	if (opts.description) {
		leftChildren.push(E('div', { 'class': 'muted', 'style': 'font-size: 12px; margin-top: 2px;' }, [ opts.description ]));
	}

	var rightChildren = [];
	if (opts.actions) {
		var actionArray = Array.isArray(opts.actions) ? opts.actions : [ opts.actions ];
		rightChildren = actionArray.filter(Boolean);
	}

	var cls = 'xfree-action-bar' + (opts.extraClass ? ' ' + opts.extraClass : '');
	return E('div', {
		'class': cls,
		'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding: 12px 16px; background: var(--panel-2, #ffffff); border: 1px solid var(--line, rgba(0,0,0,0.08)); border-radius: 12px;'
	}, [
		E('div', {}, leftChildren),
		E('div', { 'style': 'display: flex; gap: 8px; align-items: center; flex-wrap: wrap;' }, rightChildren)
	]);
}

/**
 * Кнопка «Обновить» со встроенным состоянием загрузки и спиннером (Molecule).
 * @param {Object} opts
 * @param {boolean} [opts.isRefreshing=false] Состояние обновления
 * @param {Function} opts.onRefresh Обработчик клика
 * @param {string} [opts.text='Обновить'] Текст кнопки
 * @param {string} [opts.extraClass]
 * @returns {Node}
 */
function uiRefreshButton(opts) {
	opts = opts || {};
	var isRefreshing = !!opts.isRefreshing;
	var text = opts.text || _('Обновить');
	var cls = 'cbi-button cbi-button-action' + (isRefreshing ? ' is-loading' : '') + (opts.extraClass ? ' ' + opts.extraClass : '');

	var icon = isRefreshing
		? uiSpinner({ size: 'sm', extraClass: 'btn-spinner' })
		: E('span', { 'class': 'refresh-icon', 'style': 'display: inline-block; margin-right: 4px;' }, ['↻']);

	var btnAttrs = {
		'class': cls,
		'type': 'button'
	};
	if (isRefreshing)
		btnAttrs.disabled = '';

	var btn = E('button', btnAttrs, [
		icon,
		' ' + text
	]);

	if (isRefreshing)
		btn.disabled = true;

	if (typeof opts.onRefresh === 'function') {
		btn.addEventListener('click', function(ev) {
			ev.preventDefault();
			if (!isRefreshing) {
				opts.onRefresh(ev);
			}
		});
	}

	return btn;
}

/**
 * Сворачиваемый спойлер полного терминального вывода (Molecule).
 * @param {Object} opts
 * @param {string} [opts.title] Заголовок спойлера (по умолчанию 'Терминал')
 * @param {string} [opts.rawText] Необработанный текст консоли
 * @param {boolean} [opts.defaultOpen=false] Открыт ли по умолчанию
 * @param {string} [opts.maxHeight='400px']
 * @param {string} [opts.emptyText] Текст если пусто (по умолчанию '(нет данных)')
 * @param {string} [opts.extraClass]
 * @returns {Node}
 */
function uiTerminalSpoiler(opts) {
	opts = opts || {};
	var title = opts.title || _('Терминал');
	var rawText = opts.rawText;
	var emptyText = opts.emptyText || _('(нет данных)');
	var maxHeight = opts.maxHeight || '400px';

	var detailsAttrs = {
		'class': 'xfree-spoiler' + (opts.extraClass ? ' ' + opts.extraClass : ''),
		'style': 'margin-top: 16px; border: 1px solid var(--line, rgba(0,0,0,0.08)); border-radius: 10px; padding: 8px 12px; background: var(--panel-2, #ffffff);'
	};
	if (opts.defaultOpen)
		detailsAttrs.open = 'open';

	return E('details', detailsAttrs, [
		E('summary', {
			'style': 'cursor: pointer; font-size: 13px; font-weight: 550; color: var(--muted, #7d776c); user-select: none;'
		}, [ title ]),
		E('pre', {
			'class': 'xfree-console-text terminal-pre',
			'style': 'margin-top: 10px; max-height: ' + maxHeight + '; overflow: auto; padding: 10px; background: var(--surface, #1e1e1e); color: #d4d4d4; border-radius: 6px; font-size: 12px; line-height: 1.4;'
		}, [ rawText ? String(rawText) : emptyText ])
	]);
}

return baseclass.extend({
	badge: uiBadge,
	button: uiButton,
	spinner: uiSpinner,
	progressBar: uiProgressBar,
	skeleton: uiSkeleton,
	chip: uiChip,
	inputField: uiInputField,
	selectField: uiSelectField,
	card: uiCard,
	modalDialog: uiModalDialog,
	actionBar: uiActionBar,
	refreshButton: uiRefreshButton,
	terminalSpoiler: uiTerminalSpoiler
});

