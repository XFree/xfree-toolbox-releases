'use strict';
'require baseclass';

return baseclass.extend({
	mount: function(spec) {
		var self = this;
		this._spec = spec || {};
		this._status = (spec && spec.status) || {
			hasWpadMesh: false,
			hasMeshIf: false,
			meshDisabled: false,
			meshId: '',
			mobilityDomain: '',
			channel5g: '',
			stp: false,
			role: 'standalone',
			interfaces: []
		};
		this._interfaces = (this._status.interfaces || []).slice();
		this._mobilityDomain = this._status.mobilityDomain || (this._status.meshId ? (this._status.meshId.replace(/[^a-fA-F0-9]/g, '').slice(0, 4) || '4f2a') : '4f2a');
		if (!this._mobilityDomain || this._mobilityDomain.length !== 4)
			this._mobilityDomain = '4f2a';

		this._selectedIfaces = {};
		var anyFt = false;
		this._interfaces.forEach(function(iface) {
			if (iface.ftEnabled)
				anyFt = true;
		});
		this._interfaces.forEach(function(iface) {
			if (anyFt) {
				self._selectedIfaces[iface.section] = !!iface.ftEnabled;
			} else {
				var isIotOrGuest = /iot|guest|гост/i.test(iface.ssid || '') || iface.network === 'guest';
				self._selectedIfaces[iface.section] = !isIotOrGuest;
			}
		});

		this._busy = !!(spec && spec.busy);
		this.setAttribute('data-xfree-mesh', '1');
		this.requestPaint();
	},

	setStatus: function(st) {
		var self = this;
		this._status = st || {};
		this._interfaces = (this._status.interfaces || []).slice();
		if (st.mobilityDomain && st.mobilityDomain.length === 4)
			this._mobilityDomain = st.mobilityDomain;

		var anyFt = false;
		this._interfaces.forEach(function(iface) {
			if (iface.ftEnabled)
				anyFt = true;
		});
		this._interfaces.forEach(function(iface) {
			if (anyFt) {
				self._selectedIfaces[iface.section] = !!iface.ftEnabled;
			} else if (self._selectedIfaces[iface.section] === undefined) {
				var isIotOrGuest = /iot|guest|гост/i.test(iface.ssid || '') || iface.network === 'guest';
				self._selectedIfaces[iface.section] = !isIotOrGuest;
			}
		});

		this._loading = false;
		this.requestPaint();
	},

	setBusy: function(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button, input').forEach(function(el) {
			el.disabled = !!busy;
		});
		this.requestPaint();
	},

	_act: function(ev, action, arg, confirmText) {
		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}
		var s = this._spec || {};
		if (s.onAction)
			s.onAction(action, arg || '', confirmText || '');
	},

	render: function() {
		var s = this._spec || {};
		var st = this._status || {};
		var ifaces = this._interfaces || [];
		var nodes = [];

		this.className = 'xfree-page';

		/* 1. Page Header */
		var isRefreshing = !!(s.loading || this._busy);
		nodes.push(this._renderHeader(s, st, isRefreshing));

		/* 2. Top Metric Plaques (Chips) */
		var meshActive = !!(st.hasMeshIf && !st.meshDisabled);
		nodes.push(this._renderChips(st, meshActive));

		/* 3. Section 1: Межроутерная связь (802.11s Mesh Backhaul & STP) */
		nodes.push(this._renderBackhaulSection(st, meshActive));

		/* 4. Section 2: Бесшовный роуминг клиентов (802.11r FT / 802.11k / 802.11v) */
		nodes.push(this._renderRoamingSection(ifaces));

		/* 5. Section 3: Диагностика и мониторинг */
		nodes.push(this._renderDiagSection());

		/* 6. Section 4: Системные пакеты */
		nodes.push(this._renderPkgSection(st));

		this.replaceChildren.apply(this, nodes);
	}
});
