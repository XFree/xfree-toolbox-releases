'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.traffic-map-detail as mapDetail';

return baseclass.extend({
	_togglePopover: function(payload) {
		if (this._popover && this._popover.id === payload.id)
			this._closeFloatPopover(false);
		else
			this._popover = payload;
		this.requestPaint();
	},

	/* Hide/remove shell-hosted popover (survives map re-render / route change). */
	_closeFloatPopover: function(remove) {
		var el = this._floatPopoverEl;
		var host;
		var nodes;
		var i;

		this._popover = null;
		if (el) {
			el.hidden = true;
			el.classList.remove('is-open');
			el.setAttribute('aria-hidden', 'true');
			if (remove && el.parentNode) {
				el.parentNode.removeChild(el);
				this._floatPopoverEl = null;
			}
		}
		/* Scrub orphans from previous map instances. */
		if (typeof document !== 'undefined') {
			host = document.getElementById('xfree-toolbox-shell');
			if (host) {
				nodes = host.querySelectorAll('.tm-float-popover');
				for (i = 0; i < nodes.length; i++) {
					if (remove && nodes[i] !== this._floatPopoverEl) {
						if (nodes[i].parentNode)
							nodes[i].parentNode.removeChild(nodes[i]);
						continue;
					}
					nodes[i].hidden = true;
					nodes[i].classList.remove('is-open');
					nodes[i].setAttribute('aria-hidden', 'true');
				}
			}
		}
	},

	disconnectedCallback: function() {
		if (this._onFloatOutside && typeof document !== 'undefined') {
			document.removeEventListener('pointerdown', this._onFloatOutside, true);
			document.removeEventListener('click', this._onFloatOutside, true);
			this._onFloatOutside = null;
			this._floatPopoverBound = false;
		}
		this._closeFloatPopover(true);
		this._xfreeConnected = false;
	},

	/* Fixed popover outside .tm-flow-scroll — absolute children are clipped by overflow-x. */
	_ensureFloatPopover: function() {
		var self = this;
		var el = this._floatPopoverEl;
		var host;

		if (el && el.isConnected)
			return el;

		if (typeof document === 'undefined')
			return null;

		host = document.getElementById('xfree-toolbox-shell') || document.body;
		el = E('div', {
			'class': 'tm-float-popover',
			'hidden': true,
			'role': 'dialog',
			'aria-hidden': 'true'
		});
		host.appendChild(el);
		this._floatPopoverEl = el;

		if (!this._floatPopoverBound) {
			this._floatPopoverBound = true;
			this._onFloatOutside = function(ev) {
				var t;
				if (!self._popover || !self._floatPopoverEl || !self.isConnected)
					return;
				t = ev.target;
				if (self._floatPopoverEl.contains(t))
					return;
				/* Chip click toggles via its own handler — don't steal. */
				if (t && t.closest && t.closest('xfree-traffic-map .tm-chip'))
					return;
				self._closeFloatPopover(false);
				if (self.isConnected)
					self.requestPaint();
			};
			this.addEventListener('scroll', function() {
				self._placeFloatPopover();
			}, true);
			/* Capture: runs before LuCI nav handlers that replace the overview. */
			document.addEventListener('pointerdown', this._onFloatOutside, true);
			document.addEventListener('click', this._onFloatOutside, true);
		}
		return el;
	},

	_placeFloatPopover: function() {
		var self = this;
		var view = this._spec && this._spec.view;
		var pop = this._popover;
		var el;
		var anchor;
		var kids;
		var dlKids;
		var i;
		var r;
		var tipH;
		var tipW;
		var top;
		var left;
		var gap = 8;
		var navKind;
		var navScope;
		var ctaLabel;
		var idSel;

		if (!pop) {
			this._closeFloatPopover(false);
			return;
		}

		el = this._ensureFloatPopover();
		if (!el)
			return;

		idSel = String(pop.id || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
		anchor = this.querySelector('[data-chip-id="' + idSel + '"]');

		dlKids = [];
		for (i = 0; i < (pop.rows || []).length; i++) {
			dlKids.push(E('dt', {}, [ pop.rows[i].k ]));
			dlKids.push(E('dd', {
				'class': pop.rows[i].mark
					? ('tm-mark tm-mark-' + String(pop.rows[i].mark))
					: '',
				'title': pop.rows[i].hint || ''
			}, [ pop.rows[i].v ]));
		}

		navKind = pop.navKind || mapDetail.nodeKind(pop.id) || 'system';
		navScope = pop.navScope;
		if (navScope == null)
			navScope = mapDetail.tipNavScope(pop.id);
		ctaLabel = (navKind === 'dns' || navKind === 'vpn' || navKind === 'iface' || navKind === 'zapret')
			? _('Списки')
			: _('Открыть настройки');
		kids = [
			E('p', { 'class': 'tm-popover-title' }, [ pop.title || '' ]),
			E('dl', { 'class': 'tm-popover-dl' }, dlKids),
			xcmp.button({
				variant: 'vpn',
				text: ctaLabel,
				onClick: ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					self._popover = null;
					self._placeFloatPopover();
					self._nav(navKind, navScope);
				})
			})
		];
		el.replaceChildren.apply(el, kids);
		el.hidden = false;
		el.classList.add('is-open');
		el.setAttribute('aria-hidden', 'false');

		if (!anchor) {
			el.style.top = '72px';
			el.style.left = '24px';
			return;
		}

		r = anchor.getBoundingClientRect();
		tipH = el.offsetHeight || 0;
		tipW = el.offsetWidth || 0;
		if (r.bottom + gap + tipH <= window.innerHeight - 4)
			top = r.bottom + gap;
		else
			top = Math.max(4, r.top - gap - tipH);
		left = r.left + (r.width / 2) - (tipW / 2);
		if (left < 4)
			left = 4;
		if (left + tipW > window.innerWidth - 4)
			left = Math.max(4, window.innerWidth - 4 - tipW);

		el.style.top = Math.round(top) + 'px';
		el.style.left = Math.round(left) + 'px';
	}
});
