'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.luci-ui as xui';

var TAG = 'xfree-telemt';

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._status = (spec && spec.status) || {
			running: false,
			installed: false,
			coreInstalled: false,
			coreVersion: '',
			coreLatestVersion: '',
			coreUpdateAvailable: false,
			luciInstalled: false,
			luciVersion: '',
			luciLatestVersion: '',
			luciUpdateAvailable: false,
			updateAvailable: false,
			port: '1443',
			secret: '',
			secretMasked: '',
			host: '',
			tgLink: '',
			enabled: false,
			pid: ''
		};
		this._busy = !!(spec && spec.busy);
		this._loading = false;
		this._checkingUpdates = false;
		this._showSecret = false;
		this._msg = (spec && spec.message) || '';
		this._msgTone = (spec && spec.messageTone) || '';
		this.setAttribute('data-xfree-telemt', '1');
		this.requestPaint();
	}

	setLoading(loading) {
		this._loading = !!loading;
		this.requestPaint();
	}

	setCheckingUpdates(checking) {
		this._checkingUpdates = !!checking;
		this.requestPaint();
	}

	setStatus(status) {
		this._status = status || {};
		this._status.loaded = true;
		this._loading = false;
		this._checkingUpdates = false;
		this.requestPaint();
	}

	setBusy(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button').forEach(function(el) {
			el.disabled = !!busy;
		});
		this.requestPaint();
	}

	setMessage(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		this.requestPaint();
	}

	_act(ev, action, arg, confirmText) {
		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}
		var s = this._spec || {};
		if (s.onAction)
			s.onAction(action, arg || '', confirmText || '');
	}

	_copyToClipboard(text, btn) {
		if (!text) return;
		var originalText = btn.textContent;
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(function() {
				btn.textContent = '✓ Скопировано!';
				setTimeout(function() { btn.textContent = originalText; }, 2000);
			}).catch(function() {
				ui.addNotification(null, E('p', {}, [ _('Скопируйте ссылку вручную:') + ' ' + text ]));
			});
		} else {
			var ta = E('textarea', { 'style': 'position:fixed;opacity:0;' }, [ text ]);
			document.body.appendChild(ta);
			ta.select();
			try {
				document.execCommand('copy');
				btn.textContent = '✓ Скопировано!';
				setTimeout(function() { btn.textContent = originalText; }, 2000);
			} catch {
				ui.addNotification(null, E('p', {}, [ text ]));
			}
			document.body.removeChild(ta);
		}
	}

	render() {
		var self = this;
		var s = this._spec || {};
		var st = this._status || {};
		var nodes = [];

		this.className = 'xfree-vpn-wrap xfree-telemt-wrap';

		/* 1. Page Header */
		var isRefreshing = !!(this._loading || this._busy);
		var isChecking = !!this._checkingUpdates;

		var headActions = [
			E('button', {
				'class': 'ghost ghost-compact' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние статуса Telemt'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				}
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить статус'))
			]),
			E('button', {
				'class': 'ghost ghost-compact' + (isChecking ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isChecking || isRefreshing ? true : null,
				'title': _('Проверить доступные релизы Telemt на GitHub'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onCheckUpdates)
						s.onCheckUpdates();
					else
						self._act(ev, 'checkUpdate', '');
				}
			}, [
				E('span', { 'class': isChecking ? 'is-spinning' : '' }, [ '🔍' ]),
				' ' + (isChecking ? _('Проверка…') : _('Проверить обновления'))
			])
		];

		if (st.luciInstalled) {
			headActions.push(E('a', {
				'class': 'ghost ghost-compact',
				'href': L.url('admin/services/telemt'),
				'target': '_blank',
				'title': _('Открыть панель LuCI Telemt в новой вкладке')
			}, [ '⚙️ ' + _('LuCI Telemt') ]));
		}

		nodes.push(E('div', { 'class': 'page-head' }, [
			E('div', { 'class': 'page-head-main' }, [
				E('p', { 'class': 'eyebrow' }, [ 'XFree toolbox' ]),
				E('h1', {}, [
					_('Telemt MTProxy'),
					E('span', {
						'class': 'xfree-vpn-status is-' + (st.running ? 'ok' : (st.installed ? 'bad' : 'warn')),
						'style': 'margin-left: 10px; font-size: 13px; font-weight: normal; vertical-align: middle;'
					}, [ st.running ? _('Работает') : (st.installed ? _('Остановлен') : _('Не установлен')) ])
				])
			]),
			E('div', { 'class': 'page-head-actions', 'style': 'display:flex; align-items:center; gap:8px;' }, [
				E('p', { 'class': 'muted page-head-desc' }, [
					_('MTProto-прокси для Telegram на роутере (Rust core + LuCI)')
				]),
				E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, headActions)
			])
		]));

		/* User Feedback / Message */
		if (this._msg) {
			nodes.push(E('div', {
				'class': 'alert-message ' + (this._msgTone === 'ok' ? 'success' : (this._msgTone === 'warn' ? 'warning' : 'danger')),
				'style': 'margin-bottom: 14px;'
			}, [ this._msg ]));
		}

		/* 2. Banner: Update Available or Not Installed */
		if (st.updateAvailable) {
			nodes.push(E('div', {
				'class': 'xfree-telemt-update-banner',
				'style': 'background: linear-gradient(135deg, rgba(37,99,235,0.12), rgba(59,130,246,0.06)); border: 1px solid rgba(59,130,246,0.3); border-radius: 10px; padding: 14px 18px; margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap;'
			}, [
				E('div', { 'style': 'display:flex; align-items:center; gap:12px;' }, [
					E('div', { 'style': 'font-size: 26px; line-height: 1;' }, [ '🚀' ]),
					E('div', {}, [
						E('div', { 'style': 'font-weight: 600; font-size: 14px; color: #1d4ed8;' }, [
							_('Доступно обновление Telemt MTProxy!')
						]),
						E('div', { 'class': 'muted', 'style': 'font-size: 12px; margin-top: 2px;' }, [
							st.coreUpdateAvailable ? ('Core: ' + (st.coreVersion || _('не установлен')) + ' → ' + st.coreLatestVersion + '  ') : '',
							st.luciUpdateAvailable ? ('LuCI: ' + (st.luciVersion || _('не установлен')) + ' → ' + st.luciLatestVersion) : ''
						])
					])
				]),
				E('div', { 'style': 'display:flex; gap: 8px;' }, [
					E('button', {
						'class': 'btn primary',
						'type': 'button',
						'click': function(ev) {
							self._act(ev, 'upgrade', '', _('Обновить Telemt MTProxy (Core + LuCI) до актуальной версии?'));
						}
					}, [ '⚡ ' + _('Обновить сейчас') ])
				])
			]));
		} else if (!st.installed) {
			nodes.push(E('div', {
				'class': 'xfree-telemt-install-banner',
				'style': 'background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: 10px; padding: 14px 18px; margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap;'
			}, [
				E('div', { 'style': 'display:flex; align-items:center; gap:12px;' }, [
					E('div', { 'style': 'font-size: 24px; line-height: 1;' }, [ '📦' ]),
					E('div', {}, [
						E('div', { 'style': 'font-weight: 600; font-size: 14px; color: #b45309;' }, [
							_('Telemt MTProxy не установлен на роутере')
						]),
						E('div', { 'class': 'muted', 'style': 'font-size: 12px; margin-top: 2px;' }, [
							_('Установите пакет демона telemt и веб-интерфейс luci-app-telemt в один клик.')
						])
					])
				]),
				E('button', {
					'class': 'btn primary',
					'type': 'button',
					'click': function(ev) {
						self._act(ev, 'install', '', _('Скачать и установить компоненты Telemt MTProxy с GitHub?'));
					}
				}, [ '📥 ' + _('Установить Telemt') ])
			]));
		}

		/* 3. Top Metrics Cards Grid */
		var metrics = [
			{
				title: _('Служба MTProxy'),
				value: st.running ? _('Работает') : (st.installed ? _('Остановлен') : _('Не установлен')),
				desc: st.running && st.pid ? ('PID: ' + st.pid + ' · Порт: ' + st.port) : ('Порт: ' + st.port),
				statusTone: st.running ? 'ok' : (st.installed ? 'bad' : 'warn')
			},
			{
				title: _('Ядро (telemt_wrt)'),
				value: st.coreVersion ? ('v' + st.coreVersion) : _('Не установлен'),
				desc: st.coreUpdateAvailable ? ('⬆️ Доступно v' + st.coreLatestVersion) : (st.coreLatestVersion ? '✓ ' + _('Актуально') : _('Демон MTProxy')),
				statusTone: st.coreInstalled ? (st.coreUpdateAvailable ? 'warn' : 'ok') : 'warn'
			},
			{
				title: _('Интерфейс (LuCI)'),
				value: st.luciVersion ? ('v' + st.luciVersion) : _('Не установлен'),
				desc: st.luciUpdateAvailable ? ('⬆️ Доступно v' + st.luciLatestVersion) : (st.luciLatestVersion ? '✓ ' + _('Актуально') : _('Веб-панель LuCI')),
				statusTone: st.luciInstalled ? (st.luciUpdateAvailable ? 'warn' : 'ok') : 'warn'
			},
			{
				title: _('Автозапуск службы'),
				value: st.enabled ? _('Включен') : _('Отключен'),
				desc: 'procd /etc/init.d/telemt',
				statusTone: st.enabled ? 'ok' : 'muted'
			}
		];

		var metricCards = metrics.map(function(m) {
			return E('div', {
				'class': 'card',
				'style': 'padding: 14px 16px; display: flex; flex-direction: column; justify-content: space-between; border-radius: 8px;'
			}, [
				E('div', { 'style': 'display:flex; justify-content:space-between; align-items:center; margin-bottom: 6px;' }, [
					E('span', { 'class': 'muted', 'style': 'font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;' }, [ m.title ]),
					E('span', { 'class': 'xfree-vpn-status-dot is-' + m.statusTone })
				]),
				E('div', { 'style': 'font-size: 17px; font-weight: 700; margin-bottom: 2px;' }, [ m.value ]),
				E('div', { 'class': 'muted', 'style': 'font-size: 11px;' }, [ m.desc ])
			]);
		});

		nodes.push(E('div', {
			'style': 'display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 16px;'
		}, metricCards));

		/* 4. Users & Telegram Connection Table */
		var tgConnectContent = [];
		var users = (Array.isArray(st.users) && st.users.length > 0) ? st.users : [];
		if (users.length === 0 && (st.tgLink || st.secret)) {
			users = [{
				id: 1,
				name: 'default',
				enabled: true,
				secret: st.secret || '',
				secretMasked: st.secretMasked || '••••••••',
				link: st.tgLink || '',
				comment: ''
			}];
		}

		if (users.length > 0) {
			var tableRows = users.map(function(u) {
				var secDisplay = self._showSecret ? (u.secret || '—') : (u.secretMasked || '••••••••');
				var actionBtns = [];
				if (u.link) {
					actionBtns.push(E('a', {
						'class': 'btn primary',
						'style': 'padding: 4px 10px; font-size: 12px;',
						'href': u.link,
						'title': _('Открыть Telegram и подключить прокси для') + ' ' + u.name
					}, [ '✈️ ' + _('В Telegram') ]));
					actionBtns.push(E('button', {
						'class': 'ghost ghost-compact',
						'type': 'button',
						'title': _('Скопировать ссылку подключения для') + ' ' + u.name,
						'click': function(ev) {
							ev.preventDefault();
							self._copyToClipboard(u.link, this);
						}
					}, [ '📋 ' + _('Скопировать ссылку') ]));
				}

				return E('tr', {}, [
					E('td', { 'style': 'font-weight: 600; vertical-align: middle;' }, [
						'👤 ' + u.name
					]),
					E('td', { 'style': 'vertical-align: middle;' }, [
						E('span', {
							'class': 'xfree-vpn-status is-' + (u.enabled ? 'ok' : 'muted'),
							'style': 'font-size: 11px; padding: 2px 8px;'
						}, [ u.enabled ? _('Активен') : _('Отключен') ])
					]),
					E('td', { 'style': 'font-family: monospace; font-size: 12px; vertical-align: middle;' }, [
						secDisplay
					]),
					E('td', { 'style': 'text-align: right; vertical-align: middle;' }, [
						E('div', { 'style': 'display:inline-flex; gap: 6px; align-items:center;' }, actionBtns)
					])
				]);
			});

			var connectBlock = E('div', { 'style': 'display:flex; flex-direction:column; gap: 12px;' }, [
				E('div', {
					'style': 'display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap: 10px; padding: 10px 14px; background: rgba(0,0,0,0.02); border: 1px solid rgba(0,0,0,0.06); border-radius: 6px; font-size: 12px;'
				}, [
					E('div', { 'style': 'display:flex; gap: 18px; flex-wrap:wrap; align-items:center;' }, [
						E('div', {}, [
							E('span', { 'class': 'muted' }, [ _('Сервер / Хост') + ': ' ]),
							E('strong', {}, [ st.host || '—' ])
						]),
						E('div', {}, [
							E('span', { 'class': 'muted' }, [ _('Порт') + ': ' ]),
							E('strong', {}, [ st.port || '8443' ])
						])
					]),
					E('button', {
						'class': 'ghost ghost-compact',
						'style': 'padding: 2px 8px; font-size: 11px;',
						'type': 'button',
						'click': function(ev) {
							ev.preventDefault();
							self._showSecret = !self._showSecret;
							self.requestPaint();
						}
					}, [ self._showSecret ? ('👁️ ' + _('Скрыть секреты')) : ('👁️ ' + _('Показать секреты')) ])
				]),
				E('div', { 'class': 'table-wrapper', 'style': 'overflow-x: auto; border: 1px solid rgba(0,0,0,0.08); border-radius: 6px;' }, [
					E('table', { 'class': 'table', 'style': 'margin: 0; width: 100%;' }, [
						E('thead', {}, [
							E('tr', {}, [
								E('th', {}, [ _('Пользователь') ]),
								E('th', {}, [ _('Статус') ]),
								E('th', {}, [ _('Секрет') ]),
								E('th', { 'style': 'text-align: right;' }, [ _('Подключение к Telegram') ])
							])
						]),
						E('tbody', {}, tableRows)
					])
				]),
				E('div', { 'style': 'display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap: 8px; margin-top: 2px;' }, [
					E('div', { 'class': 'muted', 'style': 'font-size: 11px; line-height: 1.4; max-width: 600px;' }, [
						'💡 ' + _('Один пользователь MTProxy может использоваться на любом количестве устройств одновременно (ПК, смартфон, планшет). Если требуется раздельный учет или отзыв доступа — создавайте отдельных пользователей в LuCI Telemt.')
					]),
					st.luciInstalled ? E('a', {
						'class': 'ghost ghost-compact',
						'href': L.url('admin/services/telemt'),
						'target': '_blank',
						'title': _('Открыть панель LuCI Telemt для создания и удаления пользователей')
					}, [ '⚙️ ' + _('Управление пользователями и QR-коды в LuCI Telemt ↗') ]) : null
				])
			]);

			tgConnectContent.push(connectBlock);
		} else {
			tgConnectContent.push(E('div', { 'class': 'muted', 'style': 'font-size: 13px;' }, [
				st.installed
					? _('Прокси установлен, но пользователи не настроены. Создайте пользователя в /etc/config/telemt или через панель LuCI Telemt.')
					: _('Установите Telemt MTProxy для генерации ссылки подключения в Telegram.')
			]));
		}

		nodes.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📱 ' + _('Параметры подключения клиентов Telegram') ]),
					E('span', { 'class': 'xfree-vpn-status is-' + ((users.length > 0 && st.tgLink) ? 'ok' : 'muted') }, [
						(users.length > 0 && st.tgLink) ? _('Готов к подключению') : _('Ожидает настройки')
					])
				])
			]),
			E('div', { 'style': 'padding: 12px 14px;' }, tgConnectContent)
		]));

		/* 5. Service Controls Section */
		var serviceBtns = [
			E('button', {
				'class': 'btn' + (st.running ? '' : ' primary'),
				'type': 'button',
				'disabled': (!st.installed || st.running) ? true : null,
				'click': function(ev) {
					self._act(ev, 'service', 'start');
				}
			}, [ '▶️ ' + _('Запустить сервис') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'disabled': (!st.installed || !st.running) ? true : null,
				'click': function(ev) {
					self._act(ev, 'service', 'stop');
				}
			}, [ '⏹️ ' + _('Остановить сервис') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'disabled': !st.installed ? true : null,
				'click': function(ev) {
					self._act(ev, 'service', 'restart');
				}
			}, [ '🔄 ' + _('Перезапустить') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'disabled': !st.installed ? true : null,
				'click': function(ev) {
					self._act(ev, 'service', st.enabled ? 'disable' : 'enable');
				}
			}, [ st.enabled ? ('⏸️ ' + _('Отключить автозапуск')) : ('✓ ' + _('Включить автозапуск')) ])
		];

		nodes.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '⚙️ ' + _('Управление демоном Telemt') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Служба OpenWrt procd') ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'padding: 10px 14px; display:flex; gap: 8px; flex-wrap:wrap;' }, serviceBtns)
		]));

		/* 6. Lifecycle & Updates Section */
		var maintenanceBtns = [
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function(ev) {
					self._act(ev, 'checkUpdate', '');
				}
			}, [ '🔍 ' + _('Проверить обновления на GitHub') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function(ev) {
					self._act(ev, 'install', '', _('Запустить установку/обновление компонентов Telemt?'));
				}
			}, [ '📥 ' + _('Установить / Обновить') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function(ev) {
					self._act(ev, 'upgrade', '', _('Выполнить принудительную переустановку Telemt (--force)?'));
				}
			}, [ '🔨 ' + _('Принудительная переустановка (--force)') ])
		];

		nodes.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📦 ' + _('Установка и обслуживание релизов') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('GitHub Releases') ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'padding: 10px 14px; display:flex; gap: 8px; flex-wrap:wrap;' }, maintenanceBtns),
			E('p', { 'class': 'muted', 'style': 'padding: 0 14px 10px 14px; font-size: 12px; margin: 0;' }, [
				_('💡 Мажорная и минорная версии Core (telemt_wrt) и LuCI (luci-app-telemt) синхронизированы для полной совместимости рантайма и конфигурации.')
			])
		]));

		this.replaceChildren.apply(this, nodes);
	}
});

return baseclass.extend({
	tag: TAG
});
