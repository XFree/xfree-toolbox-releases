'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.telemt-cards as telemtCards';
'require xfree-toolbox.telemt-connect as telemtConnect';
'require xfree-toolbox.telemt-view as telemtView';

var TAG = 'xfree-telemt';

var TelemtPanel = class extends wc.LightElement {
};

function mixTelemt(part) {
	prototypeMix.mixInto(TelemtPanel.prototype, part);
}

mixTelemt(telemtCards);
mixTelemt(telemtConnect);
mixTelemt(telemtView);

wc.define(TAG, TelemtPanel);

return baseclass.extend({
	tag: TAG
});
