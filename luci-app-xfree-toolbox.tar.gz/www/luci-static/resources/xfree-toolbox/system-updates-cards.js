'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.core.loading as loading';
'require xfree-toolbox.system-updates-report as updatesReport';

var xcmp = components;
var isUpdateAvailable = updatesReport.isUpdateAvailable;
var isUpdateCurrent = updatesReport.isUpdateCurrent;
var formatNewVersionValue = updatesReport.formatNewVersionValue;

function renderMetricRow(label, valueNode) {
	return E('div', { 'class': 'xfree-metric-row' }, [
		E('span', { 'class': 'xfree-metric-label' }, [ label ]),
		E('div', { 'class': 'xfree-metric-value' }, [ valueNode ])
	]);
}

function renderPlatformCard(info, view, onRefresh) {
	var tb = (info && info.toolbox) || {};
	var luci = (info && info.luci) || {};
	var isTbAvail = isUpdateAvailable(tb);
	var isLuciAvail = isUpdateAvailable(luci);
	var isAvail = isTbAvail || isLuciAvail;
	var isOk = isUpdateCurrent(tb) && (isUpdateCurrent(luci) || !luci.version);

	var badgeTone = isAvail ? 'warning' : (isOk ? 'ok' : 'neutral');
	var badgeText = isAvail ? _('Доступно обновление') : (isOk ? _('Актуально') : _('Не проверено'));

	var rows = [];

	// Строка 1: Ядро и CLI (xfree-toolbox)
	var tbVal = E('div', { 'style': 'display: flex; gap: 8px; align-items: center;' }, [
		E('span', { 'class': 'font-mono', 'style': 'font-weight: 700;' }, [
			tb.version ? ('v' + tb.version) : _('Не определена')
		]),
		xcmp.badge({
			text: isTbAvail ? _('Есть обновление') : (isUpdateCurrent(tb) ? _('Актуально') : (tb.updateLabel || '—')),
			tone: isTbAvail ? 'warning' : (isUpdateCurrent(tb) ? 'ok' : 'neutral')
		})
	]);
	rows.push(renderMetricRow(_('Ядро и CLI (xfree-toolbox)'), tbVal));

	// Строка 2: Веб-панель (LuCI)
	var luciVal = E('div', { 'style': 'display: flex; gap: 8px; align-items: center;' }, [
		E('span', { 'class': 'font-mono', 'style': 'font-weight: 700;' }, [
			luci.version ? ('v' + luci.version) : _('Установлен')
		]),
		xcmp.badge({
			text: isLuciAvail ? _('Есть обновление') : (isUpdateCurrent(luci) ? _('Актуально') : (luci.updateLabel || '—')),
			tone: isLuciAvail ? 'warning' : (isUpdateCurrent(luci) ? 'ok' : 'neutral')
		})
	]);
	rows.push(renderMetricRow(_('Веб-панель (LuCI)'), luciVal));

	// Строка 3: Канал обновлений
	rows.push(renderMetricRow(_('Канал обновлений'), E('span', {}, [
		tb.channel ? tb.channel.toUpperCase() : _('APK (OpenWrt 25+)')
	])));

	// Строка 4: Последняя проверка
	rows.push(renderMetricRow(_('Последняя проверка'), E('span', { 'class': 'muted font-mono', 'style': 'font-size: 12px;' }, [
		tb.checkedAt || _('Ещё не выполнялась')
	])));

	// Строка 5: Новая версия (если есть)
	var newVerText = isAvail
		? (isTbAvail ? formatNewVersionValue(tb) : formatNewVersionValue(luci))
		: _('нет');
	rows.push(renderMetricRow(_('Новая версия'), E('span', {
		'class': isAvail ? '' : 'muted',
		'style': isAvail ? 'color: var(--accent); font-weight: 600;' : ''
	}, [ newVerText ])));

	var upgradeBtn = xcmp.button({
		text: _('⚡ Обновить платформу (Core + LuCI)'),
		tone: 'action',
		disabled: !isAvail,
		title: isAvail ? _('Синхронно обновить пакет xfree-toolbox и интерфейс LuCI') : _('Обновлений не обнаружено'),
		onClick: function(ev) {
			if (!confirm(_('Обновить платформу XFree Toolbox (ядро и веб-панель LuCI) сейчас? Пользовательские профили сохраняются.'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('upgrade').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Платформа XFree Toolbox успешно обновлена!') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [upgradeBtn]);

	return xcmp.card({
		title: _('Платформа (xfree-toolbox & LuCI)'),
		subtitle: _('Системные скрипты, службы маршрутизации и веб-панель LuCI'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderToolboxCard(info, view, onRefresh) {
	var tb = info.toolbox;
	var isAvail = isUpdateAvailable(tb);
	var isOk = isUpdateCurrent(tb);
	var newVer = formatNewVersionValue(tb);

	var badgeTone = isAvail ? 'warning' : (isOk ? 'ok' : 'neutral');
	var badgeText = isAvail ? _('Доступно обновление') : (isOk ? _('Актуально') : (tb.updateLabel || _('Не проверено')));

	var rows = [];

	rows.push(renderMetricRow(_('Текущая версия'), E('span', { 'class': 'font-mono', 'style': 'font-weight: 700;' }, [
		tb.version ? ('v' + tb.version) : _('Не определена')
	])));

	rows.push(renderMetricRow(_('Канал обновлений'), E('span', {}, [
		tb.channel ? tb.channel.toUpperCase() : _('APK (OpenWrt 25+)')
	])));

	rows.push(renderMetricRow(_('Последняя проверка'), E('span', { 'class': 'muted font-mono', 'style': 'font-size: 12px;' }, [
		tb.checkedAt || _('Ещё не выполнялась')
	])));

	rows.push(renderMetricRow(_('Новая версия'), E('span', {
		'class': isAvail ? '' : 'muted',
		'style': isAvail ? 'color: var(--accent); font-weight: 600;' : ''
	}, [ newVer ])));

	var upgradeBtn = xcmp.button({
		text: _('⚡ Обновить xfree-toolbox'),
		tone: 'action',
		disabled: !isAvail,
		title: isAvail ? _('Обновить пакет xfree-toolbox сейчас') : _('Обновлений не обнаружено'),
		onClick: function(ev) {
			if (!confirm(_('Обновить xfree-toolbox сейчас? Пользовательские профили сохраняются.'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('upgrade').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Обновление xfree-toolbox завершено!') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [upgradeBtn]);

	return xcmp.card({
		title: _('Ядро и CLI (xfree-toolbox)'),
		subtitle: _('Системные скрипты и службы xfree-toolbox'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderLuciCard(info, view, onRefresh) {
	var luci = info.luci;
	var isAvail = isUpdateAvailable(luci);
	var isOk = isUpdateCurrent(luci);
	var newVer = formatNewVersionValue(luci);

	var badgeTone = isAvail ? 'warning' : (isOk ? 'ok' : 'neutral');
	var badgeText = isAvail ? _('Доступно обновление') : (isOk ? _('Актуально') : (luci.updateLabel || _('Не проверено')));

	var rows = [];

	rows.push(renderMetricRow(_('Текущая версия'), E('span', { 'class': 'font-mono', 'style': 'font-weight: 700;' }, [
		luci.version ? ('v' + luci.version) : _('Установлен')
	])));

	rows.push(renderMetricRow(_('Компонент интерфейса'), E('span', {}, [
		'luci-app-xfree-toolbox'
	])));

	rows.push(renderMetricRow(_('Среда интерфейса'), E('span', {}, [
		_('OpenWrt LuCI (client-side JS)')
	])));

	rows.push(renderMetricRow(_('Новая версия'), E('span', {
		'class': isAvail ? '' : 'muted',
		'style': isAvail ? 'color: var(--accent); font-weight: 600;' : ''
	}, [ newVer ])));

	var upgradeLuciBtn = xcmp.button({
		text: _('⚡ Обновить веб-панель (LuCI)'),
		tone: 'action',
		disabled: !isAvail,
		title: isAvail ? _('Обновить пакет веб-интерфейса luci-app-xfree-toolbox') : _('Обновлений интерфейса не обнаружено'),
		onClick: function(ev) {
			if (!confirm(_('Обновить веб-интерфейс LuCI сейчас? После обновления страница будет перезагружена.'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('upgradeLuci').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Веб-интерфейс LuCI успешно обновлён!') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка обновления LuCI: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [upgradeLuciBtn]);

	return xcmp.card({
		title: _('Веб-панель (LuCI)'),
		subtitle: _('Интерфейс управления роутером luci-app-xfree-toolbox'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderApkFeedCard(info, view, onRefresh) {
	var feed = info.apkFeed;
	var isEnabled = feed.enabled;
	var isGithub = !feed.source || feed.source.toLowerCase().indexOf('github') !== -1;

	var badgeTone = isEnabled ? 'ok' : 'neutral';
	var badgeText = isEnabled ? _('Фид активен') : _('Фид отключён');

	var rows = [];

	rows.push(renderMetricRow(_('Основной источник'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		E('span', { 'style': isGithub ? 'font-weight: 700;' : '' }, [
			isGithub ? '★ GitHub (активен)' : 'GitHub'
		]),
		xcmp.badge({
			text: feed.githubOk ? 'доступен ✓' : 'недоступен ✗',
			tone: feed.githubOk ? 'ok' : 'critical'
		})
	])));

	rows.push(renderMetricRow(_('Резервное зеркало'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		E('span', { 'style': !isGithub ? 'font-weight: 700;' : '' }, [
			!isGithub ? '★ Nextcloud (активен)' : 'Nextcloud'
		]),
		xcmp.badge({
			text: feed.nextcloudOk ? 'доступен ✓' : 'недоступен ✗',
			tone: feed.nextcloudOk ? 'ok' : 'critical'
		})
	])));

	if (feed.url) {
		rows.push(renderMetricRow(_('URL пакетов'), E('span', {
			'class': 'font-mono muted',
			'style': 'font-size: 11px; word-break: break-all; max-width: 260px; text-align: right;'
		}, [feed.url])));
	}

	var switchSourceBtn = xcmp.button({
		text: isGithub ? _('⇄ На Nextcloud') : _('⇄ На GitHub'),
		tone: 'secondary',
		disabled: !isEnabled,
		title: isGithub ? _('Переключить активный источник на Nextcloud') : _('Переключить активный источник на GitHub'),
		onClick: function(ev) {
			var targetSource = isGithub ? 'cloud' : 'github';
			var targetName = isGithub ? 'Nextcloud' : 'GitHub';
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('apkFeedSetSource', targetSource).then(function() {
				ui.addNotification(null, E('p', {}, [ _('Источник APK-фида переключён на: ') + targetName ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка переключения: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var failoverBtn = xcmp.button({
		text: _('⚡ Failover'),
		tone: 'secondary',
		disabled: !isEnabled,
		title: _('Проверить доступность и автоматически переключить на рабочее зеркало при сбое'),
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('apkFeedFailover').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Проверка доступности и failover завершены') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка failover: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var toggleFeedBtn = xcmp.button({
		text: isEnabled ? _('Отключить фид') : _('Включить фид'),
		tone: isEnabled ? 'ghost' : 'primary',
		onClick: function(ev) {
			var action = isEnabled ? 'apkFeedDisable' : 'apkFeedEnable';
			var btn = ev.target;
			loading.track(btn, view.runSystemAction(action).then(function() {
				ui.addNotification(null, E('p', {}, [ isEnabled ? _('APK-фид отключён') : _('APK-фид подключён') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [switchSourceBtn, failoverBtn, toggleFeedBtn]);

	return xcmp.card({
		title: _('Каналы APK и репозиторий'),
		subtitle: _('Официальный репозиторий пакетов OpenWrt'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

return baseclass.extend({
	renderMetricRow: renderMetricRow,
	renderPlatformCard: renderPlatformCard,
	renderToolboxCard: renderToolboxCard,
	renderLuciCard: renderLuciCard,
	renderApkFeedCard: renderApkFeedCard
});
