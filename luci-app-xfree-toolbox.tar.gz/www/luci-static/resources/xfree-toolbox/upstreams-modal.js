'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.upstreams-editor-dialog as upstreamsEditor';
'require xfree-toolbox.upstreams-wizard-dialog as upstreamsWizard';
'require xfree-toolbox.upstreams-table as upstreamsTable';

return baseclass.extend({
	_showListsModal: function(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;
		var isCustom = (mod.custom === 1);

		var modalContainer = E('div', { 'class': 'xfree-lists-modal-container', 'style': 'min-height: 400px;' });

		// Open dialog once: stays open during navigation between lists, editor, and create form!
		xui.openDialog({
			title: '📑 ' + _('Списки источника: %s').format(mod.title || mod.name),
			size: 'wide',
			body: modalContainer,
			actions: [{
				label: _('Закрыть'),
				variant: 'default',
				close: true
			}]
		});

		modalContainer.appendChild(E('div', { 'style': 'text-align: center; padding: 48px;' }, [
			E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка файлов…') ])
		]));

		function loadAndRenderLists(forceRefresh) {
			if (mod._cachedLists && !forceRefresh) {
				renderListsView(mod._cachedLists, mod._cachedMatrix || null);
				return;
			}
			Promise.all([
				xui.runSystemMenu('upstreamsGetLists', modKey),
				(xui.loadRoutingMatrix ? xui.loadRoutingMatrix() : Promise.resolve(null)).catch(function(e) {
					console.warn('Matrix load failed', e);
					return null;
				})
			]).then(function(resArr) {
				var res = resArr[0];
				var matrix = resArr[1];
				var lists = (res && res.lists) || [];
				mod._cachedLists = lists;
				mod._cachedMatrix = matrix;
				renderListsView(lists, matrix);
			}).catch(function(err) {
				modalContainer.replaceChildren(E('div', { 'class': 'alert-message danger' }, [
					E('p', {}, [ (err && err.message) ? err.message : String(err) ])
				]));
			});
		}

		function showTargetsView(relPath, targets) {
			var items = targets.map(function(t) {
				var icon = (t.target === 'iface') ? '🛡️' : ((t.target === 'dns') ? '🌐' : '⚡');
				var kindLabel = (t.target === 'iface') ? _('VPN-туннель (маршрутизация трафика)') :
					((t.target === 'dns') ? _('DNS-профиль (перенаправление доменов)') : _('Zapret DPI (секция стратегии обхода)'));

				return E('div', {
					'style': 'display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px; margin-bottom: 8px;'
				}, [
					E('div', {}, [
						E('div', { 'style': 'font-weight: 600; font-size: 15px;' }, [ icon + ' ' + (t.label || t.scope) ]),
						E('div', { 'class': 'muted', 'style': 'font-size: 12px; margin-top: 3px;' }, [ kindLabel ])
					]),
					E('span', {
						'class': 'badge',
						'style': 'background: var(--ok-soft); color: var(--ok); font-size: 12px; padding: 4px 8px;'
					}, [ '✓ ' + _('Активно') ])
				]);
			});

			var viewEl = E('div', { 'class': 'xfree-targets-view' }, [
				E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; padding-bottom: 12px; border-bottom: 1px solid var(--line);'
				}, [
					xcmp.button({
						variant: 'vpn',
						primary: true,
						text: '← ' + _('Назад к спискам'),
						onClick: function() {
							renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
						}
					}),
					E('span', { 'class': 'badge', 'style': 'background: var(--ok-soft); color: var(--ok); font-weight: 600;' }, [
						_('Используется в %d правилах').format(targets.length)
					])
				]),
				E('div', { 'style': 'margin-bottom: 8px; font-size: 14px; font-family: monospace; word-break: break-all; color: var(--accent); font-weight: 600;' }, [
					'📄 ' + modKey + '/upstream/' + relPath
				]),
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 14px; font-size: 13px;' }, [
					_('Этот список включён в следующих правилах маршрутизации и профилях:')
				]),
				E('div', { 'style': 'max-height: 48vh; overflow-y: auto;' }, items)
			]);

			modalContainer.replaceChildren(viewEl);
		}

		function renderListsView(lists, matrix) {
			upstreamsTable.renderListsTable({
				modalContainer: modalContainer,
				lists: lists,
				matrix: matrix,
				modKey: modKey,
				isCustom: isCustom,
				onShowFileView: function(relPath, ro) {
					upstreamsEditor.showFileView({
						xui: xui,
						modalContainer: modalContainer,
						mod: mod,
						relPath: relPath,
						readOnly: ro,
						isCustom: isCustom,
						onBack: function() {
							renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
						},
						onReload: function() {
							self.reload();
						}
					});
				},
				onShowCreateView: function() {
					upstreamsWizard.showCreateView({
						xui: xui,
						modalContainer: modalContainer,
						mod: mod,
						onBack: function() {
							renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
						},
						onReload: function(force) {
							loadAndRenderLists(force);
							self.reload();
						},
						onShowFileView: function(p, ro) {
							upstreamsEditor.showFileView({
								xui: xui,
								modalContainer: modalContainer,
								mod: mod,
								relPath: p,
								readOnly: ro,
								isCustom: isCustom,
								onBack: function() {
									renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
								},
								onReload: function() {
									self.reload();
								}
							});
						}
					});
				},
				onShowTargetsView: function(relPath, targets) {
					showTargetsView(relPath, targets);
				},
				onDownloadDirect: function(relPath) {
					downloadDirect(relPath);
				},
				onDeleteList: function(relPath) {
					deleteList(relPath);
				}
			});
		}

		function downloadDirect(relPath) {
			var fullRel = modKey + '/upstream/' + relPath;
			xui.runSystemMenu('upstreamsGetList', fullRel).then(function(res) {
				var content = (res && res.content) || '';
				var blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
				var url = URL.createObjectURL(blob);
				var a = document.createElement('a');
				a.href = url;
				a.download = relPath.split('/').pop() || 'list.lst';
				document.body.appendChild(a);
				a.click();
				document.body.removeChild(a);
				setTimeout(function() { URL.revokeObjectURL(url); }, 2000);
			});
		}

		function deleteList(relPath) {
			var fullRel = modKey + '/upstream/' + relPath;
			xui.confirm({
				title: _('Удаление списка'),
				message: _('Удалить файл списка «%s»?').format(relPath),
				detail: _('Файл будет удален с роутера, а индекс модуля пересобран.'),
				tone: 'danger',
				confirmText: _('Удалить'),
				cancelText: _('Отмена')
			}).then(function(confirmed) {
				if (!confirmed) return;
				xui.runSystemMenu('upstreamsDeleteList', fullRel).then(function(res) {
					if (res && res.error) {
						ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
						return;
					}
					ui.addNotification(null, E('p', {}, [ _('Список «%s» удален').format(relPath) ]), 'info');
					if (mod._cachedLists) {
						mod._cachedLists = mod._cachedLists.filter(function(x) { return x.path !== relPath; });
					}
					renderListsView(mod._cachedLists || []);
					self.reload();
				}).catch(function(err) {
					ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
				});
			});
		}

		// Initial load
		loadAndRenderLists(false);
	}
});
