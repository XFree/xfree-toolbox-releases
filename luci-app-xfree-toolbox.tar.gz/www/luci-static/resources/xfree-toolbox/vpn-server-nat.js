'use strict';
'require baseclass';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.components as xcmp';

/* Карточка диагностики NAT. Метод вешается на прототип xfree-vpn-server. */

return baseclass.extend({
	_renderNatCard: function (awg) {
		var self = this;
		// Card 2: NAT / External IP Accessibility Diagnostic
		var natRes = self._natCheckResult;
		var wanIpDisplay = (natRes && natRes.wanIp4) || awg.wanIp || '';
		if (!wanIpDisplay && awg.endpointChoices && Array.isArray(awg.endpointChoices)) {
			for (var eci = 0; eci < awg.endpointChoices.length; eci++) {
				if (awg.endpointChoices[eci].id === 'net:wan') {
					wanIpDisplay = (awg.endpointChoices[eci].endpoint || '').split(':')[0];
					break;
				}
			}
		}
		if (!wanIpDisplay)
			wanIpDisplay = '—';

		var extIp4Display = (natRes && natRes.extIp4) || (self._natChecking ? _('проверка...') : _('не проверен'));
		var extIp6Display = (natRes && natRes.extIp6) || (self._natChecking ? _('проверка...') : (natRes ? _('нет IPv6') : _('не проверен')));

		var preliminaryStatus = 'muted';
		var preliminaryBadge = _('НЕ ПРОВЕРЕНО');
		if (wanIpDisplay && wanIpDisplay !== '—') {
			if (/^100\.(6[4-9]|[7-9][0-9]|1[0-1][0-9]|12[0-7])\./.test(wanIpDisplay)) {
				preliminaryStatus = 'warn';
				preliminaryBadge = _('CGNAT (СЕРЫЙ IP)');
			} else if (/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/.test(wanIpDisplay)) {
				preliminaryStatus = 'warn';
				preliminaryBadge = _('ДОМАШНИЙ NAT');
			} else {
				preliminaryStatus = 'ok';
				preliminaryBadge = _('БЕЛЫЙ IP (ПРЕДВАРИТЕЛЬНО)');
			}
		}

		var natBadgeClass;
		var natBadgeText;
		if (natRes) {
			if (natRes.natType === 'public') {
				natBadgeClass = 'is-ok';
				natBadgeText = _('БЕЛЫЙ ПУБЛИЧНЫЙ IP');
			} else if (natRes.natType === 'cgnat') {
				natBadgeClass = 'is-bad';
				natBadgeText = _('CGNAT (СЕРЫЙ IP)');
			} else if (natRes.natType === 'local_nat') {
				natBadgeClass = 'is-warn';
				natBadgeText = _('ДОМАШНИЙ NAT (МОДЕМ)');
			} else if (natRes.statusCode === 'danger') {
				natBadgeClass = 'is-bad';
				natBadgeText = _('ОШИБКА ПРОВЕРКИ');
			} else {
				natBadgeClass = 'is-warn';
				natBadgeText = _('ПРОВАЙДЕРСКИЙ NAT');
			}
		} else {
			natBadgeClass = 'is-' + preliminaryStatus;
			natBadgeText = preliminaryBadge;
		}

		var natAdvice = '';
		if (natRes && natRes.message) {
			natAdvice = natRes.message;
		} else if (preliminaryBadge === _('CGNAT (СЕРЫЙ IP)')) {
			natAdvice = _('Адрес WAN находится в диапазоне CGNAT (100.64.0.0/10). Провайдер блокирует прямые входящие подключения из интернета. Нажмите «Как обойти NAT» для настройки FreeTurn или реле.');
		} else if (preliminaryBadge === _('ДОМАШНИЙ NAT')) {
			natAdvice = _('Роутер подключён через терминал/модем провайдера (192.168.x.x / 10.x.x.x). Настройте на терминале режим Bridge, DMZ или проброс порта 51820 UDP на этот роутер.');
		} else if (preliminaryBadge === _('БЕЛЫЙ IP (ПРЕДВАРИТЕЛЬНО)')) {
			natAdvice = _('WAN IP роутера похож на публичный (%s). Нажмите «Проверить доступность извне», чтобы подтвердить отсутствие скрытого NAT и доступность порта.').format(wanIpDisplay);
		} else {
			natAdvice = _('Нажмите «Проверить доступность извне», чтобы сопоставить WAN IP с реальным адресом выхода в интернет и проверить наличие IPv6.');
		}

		var natCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('strong', {}, [_('Доступность из интернета (NAT / Внешний IP)')]),
					xui.helpBtn({
						title: _('Диагностика доступа из интернета'),
						desc: _('Определяет, доступен ли ваш сервер AmneziaWG и FreeTurn для входящих подключений клиентов из глобальной сети.'),
						whatDoes: _('Сопоставляет локальный WAN IPv4 с публичным адресом в интернете, определяет наличие провайдерского CGNAT (RFC 6598) и проверяет поддержку IPv6.'),
						tips: _('Если у вас серый IP (CGNAT), нажмите кнопку «Как обойти NAT» для просмотра доступных решений (VPS релеи, Tailscale, IPv6).')
					}),
					wanIpDisplay !== '—' ? E('span', { 'class': 'muted' }, [_('WAN: %s').format(wanIpDisplay)]) : ''
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, [
					xcmp.badge({ variant: 'vpn-status', extraClass: natBadgeClass, text: natBadgeText })
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 8px; padding: 10px 0;' }, [
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('WAN IPv4 (роутер)')]),
					E('strong', { 'style': 'font-family: monospace; font-size: 13px;' }, [wanIpDisplay])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Внешний IPv4 (интернет)')]),
					E('span', { 'style': 'font-family: monospace; font-size: 13px; font-weight: 600;' }, [extIp4Display])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Внешний IPv6')]),
					E('span', { 'style': 'font-family: monospace; font-size: 12px; font-weight: 600;' }, [extIp6Display])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: flex-start; margin-top: 4px;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap; padding-top: 6px;' }, [_('Рекомендация')]),
					E('div', {
						'class': 'muted',
						'style': 'font-size: 12px; line-height: 1.45; padding: 8px 12px; border-radius: 6px; background: color-mix(in srgb, var(--card) 60%, var(--bg)); border-left: 3px solid ' + (natBadgeClass.indexOf('is-bad') !== -1 ? 'var(--bad)' : (natBadgeClass.indexOf('is-warn') !== -1 ? 'var(--warn)' : 'var(--primary)')) + ';'
					}, [natAdvice])
				])
			]),
			E('div', { 'class': 'xfree-vpn-server-actions', 'style': 'display: flex; gap: 8px; flex-wrap: wrap; align-items: center;' }, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					extraClass: 'is-primary',
					disabled: !!self._natChecking,
					text: self._natChecking ? _('Проверка...') : ('🔍 ' + _('Проверить доступность извне')),
					onClick: function () {
						self._natChecking = true;
						self.requestPaint();
						xui.runAwgMenu('checkNat').then(function (res) {
							self._natChecking = false;
							self._natCheckResult = xui.parseNatCheck(res);
							self.requestPaint();
						}).catch(function (err) {
							self._natChecking = false;
							self._natCheckResult = {
								statusCode: 'danger',
								message: _('Ошибка проверки: ') + ((err && err.message) || String(err))
							};
							self.requestPaint();
						});
					}
				}),
				xcmp.button({
					variant: 'vpn',
					primary: true,
					text: 'ℹ️ ' + _('Как обойти NAT'),
					onClick: function () { self._openNatHelpDialog(); }
				})
			])
		]);
		return natCard;
	}
});
