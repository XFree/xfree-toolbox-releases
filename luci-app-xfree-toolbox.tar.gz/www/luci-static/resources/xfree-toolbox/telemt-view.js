'use strict';
'require baseclass';

return baseclass.extend({
	mount: function(spec) {
		this._spec = spec || {};
		this._status = (spec && spec.status) || {
			running: false,
			installed: false,
			coreInstalled: false,
			coreVersion: '',
			coreLatestVersion: '',
			coreUpdateAvailable: false,
			luciInstalled: false,
			luciVersion: '',
			luciLatestVersion: '',
			luciUpdateAvailable: false,
			updateAvailable: false,
			port: '1443',
			secret: '',
			secretMasked: '',
			host: '',
			tgLink: '',
			enabled: false,
			pid: ''
		};
		this._busy = !!(spec && spec.busy);
		this._loading = false;
		this._checkingUpdates = false;
		this._showSecret = false;
		this._msg = (spec && spec.message) || '';
		this._msgTone = (spec && spec.messageTone) || '';
		this.setAttribute('data-xfree-telemt', '1');
		this.requestPaint();
	},

	setLoading: function(loading) {
		this._loading = !!loading;
		this.requestPaint();
	},

	setCheckingUpdates: function(checking) {
		this._checkingUpdates = !!checking;
		this.requestPaint();
	},

	setStatus: function(status) {
		this._status = status || {};
		this._status.loaded = true;
		this._loading = false;
		this._checkingUpdates = false;
		this.requestPaint();
	},

	setBusy: function(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button').forEach(function(el) {
			el.disabled = !!busy;
		});
		this.requestPaint();
	},

	setMessage: function(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		this.requestPaint();
	},

	_act: function(ev, action, arg, confirmText) {
		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}
		var s = this._spec || {};
		if (s.onAction)
			s.onAction(action, arg || '', confirmText || '');
	},

	render: function() {
		var s = this._spec || {};
		var st = this._status || {};
		var nodes = [];

		this.className = 'xfree-vpn-wrap xfree-telemt-wrap';

		/* 1. Page Header */
		var isRefreshing = !!(this._loading || this._busy);
		var isChecking = !!this._checkingUpdates;
		nodes.push(this._renderHeader(s, st, isRefreshing, isChecking));

		/* User Feedback / Message */
		if (this._msg) {
			nodes.push(E('div', {
				'class': 'alert-message ' + (this._msgTone === 'ok' ? 'success' : (this._msgTone === 'warn' ? 'warning' : 'danger')),
				'style': 'margin-bottom: 14px;'
			}, [ this._msg ]));
		}

		/* 2. Banner: Update Available or Not Installed */
		var banner = this._renderBanner(st);
		if (banner)
			nodes.push(banner);

		/* 3. Top Metrics Cards Grid */
		nodes.push(this._renderMetrics(st));

		/* 4. Users & Telegram Connection Table */
		nodes.push(this._renderConnectSection(st));

		/* 5. Service Controls Section */
		nodes.push(this._renderServiceSection(st));

		/* 6. Lifecycle & Updates Section */
		nodes.push(this._renderMaintenanceSection());

		this.replaceChildren.apply(this, nodes);
	}
});
