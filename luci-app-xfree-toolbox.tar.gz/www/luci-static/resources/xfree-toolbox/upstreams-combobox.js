'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';

function createCombobox(config) {
	var placeholder = config.placeholder || '';
	var currentValue = String(config.value !== undefined ? config.value : '');
	var optionsList = config.options || [];
	var onChange = config.onChange || function() {};
	var onSelect = config.onSelect || function() {};

	var wrap = E('div', {
		'class': 'xfree-combobox-wrap',
		'style': 'position: relative; width: 100%; margin-bottom: 4px;' + (config.style || '')
	});

	var input = E('input', {
		'type': 'text',
		'class': 'cbi-input-text',
		'placeholder': placeholder,
		'autocomplete': 'off',
		'style': 'width: 100%; padding-right: 36px; box-sizing: border-box;'
	});
	input.value = currentValue;

	var toggleBtn = xcmp.button({
		variant: 'vpn',
		primary: true,
		text: '▼',
		style: 'position: absolute; right: 2px; top: 2px; bottom: 2px; width: 32px; border: none; background: transparent; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 11px; color: var(--muted); padding: 0;'
	});

	var menu = E('div', {
		'class': 'xfree-combobox-menu',
		'style': 'position: absolute; top: calc(100% + 4px); left: 0; right: 0; z-index: 1050; background: var(--panel-2, #ffffff); border: 1px solid var(--line, #e4d8c4); border-radius: 8px; box-shadow: 0 8px 24px rgba(43, 40, 35, 0.15); max-height: 220px; overflow-y: auto; display: none; padding: 4px 0;'
	});

	wrap.appendChild(input);
	wrap.appendChild(toggleBtn);
	wrap.appendChild(menu);

	var isOpen = false;

	function renderMenu(filterText) {
		menu.textContent = '';
		var q = String(filterText || '').trim().toLowerCase();
		var visibleCount = 0;

		optionsList.forEach(function(opt) {
			if (typeof opt === 'string') {
				opt = { value: opt, label: opt };
			}
			if (opt.isHeader) {
				var headerEl = E('div', {
					'style': 'padding: 6px 12px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); background: var(--panel); border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); pointer-events: none; margin-top: 4px;'
				}, [ opt.label || opt.value ]);
				menu.appendChild(headerEl);
				return;
			}

			var valStr = String(opt.value !== undefined ? opt.value : '');
			var lblStr = String(opt.label !== undefined ? opt.label : valStr);
			var hintStr = String(opt.hint || '');

			if (q) {
				var hit = valStr.toLowerCase().indexOf(q) !== -1 ||
						lblStr.toLowerCase().indexOf(q) !== -1 ||
						hintStr.toLowerCase().indexOf(q) !== -1;
				if (!hit) return;
			}

			visibleCount++;

			var isSelected = (valStr === input.value);
			var itemEl = E('div', {
				'class': 'xfree-combobox-item' + (isSelected ? ' selected' : ''),
				'style': 'padding: 7px 12px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 13px; transition: background 0.15s;' +
						(isSelected ? ' background: var(--accent-soft); color: var(--accent); font-weight: 600;' : '')
			}, [
				E('div', { 'style': 'display: flex; align-items: center; gap: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;' }, [
					opt.icon ? E('span', {}, [ opt.icon ]) : '',
					E('span', { 'style': 'overflow: hidden; text-overflow: ellipsis;' }, [ lblStr ])
				]),
				hintStr ? E('span', {
					'class': 'badge',
					'style': 'font-size: 11px; font-weight: normal; padding: 1px 6px; opacity: 0.85; flex-shrink: 0;'
				}, [ hintStr ]) : ''
			]);

			itemEl.addEventListener('mouseenter', function() {
				if (valStr !== input.value) itemEl.style.background = 'var(--panel)';
			});
			itemEl.addEventListener('mouseleave', function() {
				if (valStr !== input.value) itemEl.style.background = '';
			});

			itemEl.addEventListener('mousedown', function(ev) {
				ev.preventDefault();
				selectItem(opt);
			});

			menu.appendChild(itemEl);
		});

		if (visibleCount === 0) {
			menu.appendChild(E('div', {
				'style': 'padding: 10px 12px; font-size: 12px; color: var(--muted); font-style: italic;'
			}, [
				q ? _('Совпадений нет. Будет использовано введенное: «%s»').format(q) : _('Список вариантов пуст')
			]));
		}
	}

	function openMenu(filterText) {
		if (isOpen && filterText === undefined) return;
		isOpen = true;
		renderMenu(filterText !== undefined ? filterText : input.value);
		menu.style.display = 'block';
		document.addEventListener('click', onDocClick, true);
	}

	function closeMenu() {
		if (!isOpen) return;
		isOpen = false;
		menu.style.display = 'none';
		document.removeEventListener('click', onDocClick, true);
	}

	function onDocClick(ev) {
		if (!wrap.contains(ev.target)) {
			closeMenu();
		}
	}

	function selectItem(opt) {
		input.value = opt.value;
		closeMenu();
		onChange(input.value);
		onSelect(opt);
	}

	toggleBtn.addEventListener('click', function(ev) {
		ev.stopPropagation();
		if (isOpen) {
			closeMenu();
		} else {
			renderMenu('');
			isOpen = true;
			menu.style.display = 'block';
			document.addEventListener('click', onDocClick, true);
			input.focus();
		}
	});

	input.addEventListener('focus', function() {
		openMenu(input.value);
	});

	input.addEventListener('input', function() {
		openMenu(input.value);
		onChange(input.value);
	});

	input.addEventListener('keydown', function(ev) {
		if (ev.key === 'Escape') {
			closeMenu();
		} else if (ev.key === 'ArrowDown') {
			if (!isOpen) {
				openMenu('');
			}
		}
	});

	return {
		node: wrap,
		input: input,
		getValue: function() {
			return String(input.value || '').trim();
		},
		setValue: function(val, triggerChange) {
			input.value = val !== undefined ? String(val) : '';
			if (triggerChange) onChange(input.value);
		},
		setOptions: function(newOptions) {
			optionsList = newOptions || [];
			if (isOpen) renderMenu(input.value);
		},
		focus: function() {
			input.focus();
		}
	};
}

return baseclass.extend({
	createCombobox: createCombobox
});
