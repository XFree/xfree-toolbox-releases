'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-placeholder';

var HINT = _(
	'Действие пока доступно только в CLI (xft / menu.sh). ' +
	'Здесь будет запуск через LuCI после подключения rpcd/ubus.'
);

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this.requestPaint();
	}

	render() {
		var s = this._spec || {};

		this.className = 'cbi-section';
		this.replaceChildren(
			E('h3', {}, [ s.title || s.id || '' ]),
			E('div', { 'class': 'cbi-section-descr' }, [ s.hint || HINT ]),
			E('div', { 'class': 'cbi-section-node' }, [
				E('div', { 'class': 'cbi-value' }, [
					E('label', { 'class': 'cbi-value-title' }, [ _('CLI') ]),
					E('div', { 'class': 'cbi-value-field' }, [ s.cli || '—' ])
				]),
				E('div', { 'class': 'cbi-value' }, [
					E('label', { 'class': 'cbi-value-title' }, [ _('Путь в меню') ]),
					E('div', { 'class': 'cbi-value-field' }, [ s.path || '' ])
				])
			])
		);
	}
});

return baseclass.extend({
	tag: TAG,
	hint: HINT
});
