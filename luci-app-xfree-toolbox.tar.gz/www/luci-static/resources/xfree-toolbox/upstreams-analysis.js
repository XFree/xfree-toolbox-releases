'use strict';
'require baseclass';

var KNOWN_GROUPS = [ 'custom', 'ai', 'video', 'music', 'vpn', 'tools', 'others', 'dns', 'zapret', 'xft' ];
var KNOWN_SERVICES = [ 'youtube', 'discord', 'telegram', 'chatgpt', 'openai', 'spotify', 'netflix', 'instagram', 'twitter', 'twitch', 'github', 'cloudflare' ];

function analyzeModuleLists(rawLists) {
	var groupMap = {};
	var allItems = [];

	(rawLists || []).forEach(function(item) {
		if (!item || !item.path) return;
		var parts = item.path.split('/');
		var group = parts[0] || '';
		var service = parts.length > 2 ? parts[1] : '';
		var filename = parts[parts.length - 1] || '';

		var parsedType = 'other';
		var stem = filename.replace(/\.lst$/i, '');

		var m = filename.match(/^(fqdn|prefixes-ipv4|prefixes-ipv6|prefixes)-(.+)\.lst$/i);
		if (m) {
			var pfx = m[1].toLowerCase();
			stem = m[2];
			if (pfx === 'fqdn') parsedType = 'fqdn';
			else if (pfx === 'prefixes-ipv4') parsedType = 'ipv4';
			else if (pfx === 'prefixes-ipv6') parsedType = 'ipv6';
			else if (pfx === 'prefixes') parsedType = 'prefix';
		}

		var fileInfo = {
			path: item.path,
			group: group,
			service: service,
			filename: filename,
			type: parsedType,
			stem: stem,
			lines: item.lines || 0
		};
		allItems.push(fileInfo);

		if (!groupMap[group]) {
			groupMap[group] = { name: group, files: [], services: {} };
		}
		groupMap[group].files.push(fileInfo);

		if (service) {
			if (!groupMap[group].services[service]) {
				groupMap[group].services[service] = { name: service, files: [] };
			}
			groupMap[group].services[service].files.push(fileInfo);
		}
	});

	return {
		groups: groupMap,
		allItems: allItems
	};
}

function buildGroupOptions(ana) {
	var opts = [];
	var existingGroups = Object.keys(ana.groups).sort();
	if (existingGroups.length > 0) {
		opts.push({ isHeader: true, label: '📁 ' + _('В этом источнике') });
		existingGroups.forEach(function(g) {
			var svcCount = Object.keys(ana.groups[g].services).length;
			var fileCount = ana.groups[g].files.length;
			var hint = svcCount > 0 ?
				_('%d сервисов, %d списков').format(svcCount, fileCount) :
				_('%d списков').format(fileCount);
			opts.push({
				value: g,
				label: g,
				icon: '📁',
				hint: hint
			});
		});
	}

	opts.push({ isHeader: true, label: '💡 ' + _('Рекомендуемые категории') });
	KNOWN_GROUPS.forEach(function(g) {
		if (existingGroups.indexOf(g) === -1) {
			opts.push({
				value: g,
				label: g,
				icon: '📂'
			});
		}
	});
	return opts;
}

function buildServiceOptions(ana, currentGroup) {
	var opts = [];
	opts.push({
		value: '',
		label: '— ' + _('(без подгруппы, список в корне группы)'),
		icon: '📂'
	});

	var grp = ana.groups[currentGroup];
	if (grp && Object.keys(grp.services).length > 0) {
		opts.push({ isHeader: true, label: '📁 ' + _('Существующие сервисы в группе «%s»').format(currentGroup) });
		Object.keys(grp.services).sort().forEach(function(s) {
			var sFiles = grp.services[s].files;
			var fileNames = sFiles.map(function(f) { return f.filename; }).join(', ');
			opts.push({
				value: s,
				label: s,
				icon: '⚡',
				hint: fileNames
			});
		});
	}

	opts.push({ isHeader: true, label: '💡 ' + _('Популярные сервисы') });
	KNOWN_SERVICES.forEach(function(s) {
		if (!grp || !grp.services[s]) {
			opts.push({
				value: s,
				label: s,
				icon: '🌐'
			});
		}
	});
	return opts;
}

function buildStemOptions(ana, currentGroup, currentService) {
	var opts = [];
	var seen = {};

	if (currentService) {
		opts.push({ value: currentService, label: currentService, hint: _('по имени сервиса'), icon: '⚡' });
		seen[currentService] = true;
	}

	var grp = ana.groups[currentGroup];
	if (grp) {
		var targetFiles = currentService ?
			(grp.services[currentService] ? grp.services[currentService].files : []) :
			grp.files.filter(function(f) { return !f.service; });

		targetFiles.forEach(function(f) {
			if (f.stem && !seen[f.stem]) {
				seen[f.stem] = true;
				opts.push({
					value: f.stem,
					label: f.stem,
					hint: _('из %s').format(f.filename),
					icon: '📑'
				});
			}
		});
	}

	if (currentGroup && !seen[currentGroup]) {
		opts.push({ value: currentGroup, label: currentGroup, hint: _('по имени группы'), icon: '📁' });
		seen[currentGroup] = true;
	}

	return opts;
}

function checkFolderPairings(g, s, files, quickPickPills) {
	var fqdnFile = files.find(function(f) { return f.type === 'fqdn'; });
	var ipv4File = files.find(function(f) { return f.type === 'ipv4' || f.type === 'prefix'; });

	if (fqdnFile && !ipv4File) {
		var st = fqdnFile.stem;
		quickPickPills.push({
			group: g,
			service: s,
			stem: st,
			type: 'ipv4',
			badgeText: '+prefixes-ipv4',
			badgeBg: 'var(--ok-soft)',
			badgeColor: 'var(--ok)',
			label: (g + (s ? (' / ' + s) : '')),
			title: _('В «%s» есть %s. Создать парный prefixes-ipv4-%s.lst').format(g + (s ? ('/' + s) : ''), fqdnFile.filename, st)
		});
	} else if (ipv4File && !fqdnFile) {
		var st2 = ipv4File.stem;
		quickPickPills.push({
			group: g,
			service: s,
			stem: st2,
			type: 'fqdn',
			badgeText: '+fqdn',
			badgeBg: 'var(--accent-soft)',
			badgeColor: 'var(--accent)',
			label: (g + (s ? (' / ' + s) : '')),
			title: _('В «%s» есть %s. Создать парный fqdn-%s.lst').format(g + (s ? ('/' + s) : ''), ipv4File.filename, st2)
		});
	}
}

return baseclass.extend({
	KNOWN_GROUPS: KNOWN_GROUPS,
	KNOWN_SERVICES: KNOWN_SERVICES,
	analyzeModuleLists: analyzeModuleLists,
	buildGroupOptions: buildGroupOptions,
	buildServiceOptions: buildServiceOptions,
	buildStemOptions: buildStemOptions,
	checkFolderPairings: checkFolderPairings
});
