'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';

function renderTraceToolbar(mapInst, opt) {
	var btnLabel = opt.btnLabel;
	var self = mapInst;

	var devOpts = [
		E('option', { 'value': '' }, ['— ' + _('Любое устройство') + ' —'])
	];
	var devList = self._devices || [];
	for (var di = 0; di < devList.length; di++) {
		var dev = devList[di];
		var devVal = dev.ip || dev.id;
		var devText = (dev.name ? (dev.name + ' (' + (dev.ip || dev.mac || dev.id) + ')') : (dev.ip || dev.mac || dev.id));
		if (dev.skipVpn && dev.skipZapret) {
			devText += ' [WAN]';
		} else if (dev.forceIface) {
			devText += ' [' + dev.forceIface + ']';
		}
		devOpts.push(E('option', {
			'value': devVal,
			'selected': (self._selectedClient === devVal || self._selectedClient === dev.id || self._selectedClient === dev.ip) ? 'selected' : null
		}, [ devText ]));
	}

	var clientSelect = E('select', {
		'class': 'cbi-input-select tm-client-select',
		'aria-label': _('Устройство клиента'),
		'title': _('Выбрать клиента для персональной трассировки политики маршрутизации'),
		'change': function(ev) {
			self._selectedClient = ev.target.value || '';
			if (self._selectedClient && !self._fqdn) {
				self._fqdn = self._selectedClient;
				var inp = self.querySelector('.tm-trace-input');
				if (inp) inp.value = self._fqdn;
			}
		}
	}, devOpts);

	var fqdnInput = E('input', {
		'class': 'tm-trace-input',
		'type': 'text',
		'name': 'fqdn',
		'placeholder': 'youtube.com',
		'autocomplete': 'off',
		'spellcheck': 'false',
		'value': self._fqdn || '',
		'aria-label': _('Сайт'),
		'aria-autocomplete': 'list',
		'aria-expanded': self._suggestOpen ? 'true' : 'false',
		'focus': function() {
			self._openSuggest();
		},
		'blur': function() {
			window.setTimeout(function() {
				self._closeSuggest();
			}, 120);
		},
		'keydown': function(ev) {
			var box = self.querySelector('.tm-suggest');
			var vals = (box && box._suggestValues) || [];
			var n = vals.length;
			var idx;

			self._fqdn = (ev.target && ev.target.value) || self._fqdn || '';
			if (ev.key === 'ArrowDown' && n) {
				ev.preventDefault();
				self._suggestOpen = true;
				self._suggestActive = Math.min(n - 1, (self._suggestActive < 0 ? 0 : self._suggestActive + 1));
				self._paintSuggest();
				return;
			}
			if (ev.key === 'ArrowUp' && n) {
				ev.preventDefault();
				self._suggestActive = Math.max(-1, self._suggestActive - 1);
				self._paintSuggest();
				return;
			}
			if (ev.key === 'Escape') {
				ev.preventDefault();
				self._closeSuggest();
				return;
			}
			if (ev.key === 'Enter') {
				ev.preventDefault();
				idx = self._suggestActive;
				if (self._suggestOpen && idx >= 0 && idx < n)
					self._pickSuggest(vals[idx]);
				else {
					self._closeSuggest();
					self._runTrace();
				}
			}
		},
		'input': function(ev) {
			self._fqdn = (ev.target && ev.target.value) || '';
			self._suggestOpen = true;
			self._suggestActive = -1;
			self._paintSuggest();
		}
	});

	var traceBtn = xcmp.button({
		extraClass: 'tm-trace-btn',
		disabled: !!self._busy,
		children: btnLabel,
		onClick: function(ev) {
			ev.preventDefault();
			self._closeSuggest();
			self._runTrace();
		}
	});

	var suggestBox = E('div', {
		'class': 'tm-suggest',
		'hidden': true,
		'role': 'listbox',
		'aria-label': _('Подсказки доменов')
	});

	return E('div', { 'class': 'tm-trace-wrap' }, [
		E('div', { 'class': 'tm-trace-bar' }, [
			clientSelect,
			fqdnInput,
			traceBtn
		]),
		suggestBox
	]);
}

return baseclass.extend({
	renderTraceToolbar: renderTraceToolbar
});
