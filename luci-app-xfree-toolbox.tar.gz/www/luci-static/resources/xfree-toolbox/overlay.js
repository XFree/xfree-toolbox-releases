'use strict';
'require baseclass';
'require dom';

/**
 * @file overlay.js
 * Core Service: Управление слоями интерфейса (Z-Index Stack, Glasspane, Modal Manager).
 */

var Z_INDEX = {
	BASE: 1,
	STICKY: 100,
	DROPDOWN: 500,
	BACKDROP: 1000,
	MODAL: 1050,
	POPOVER: 1100,
	TOAST: 1200
};

var modalStack = [];
var scrollLockCount = 0;

/**
 * Заблокировать скролл страницы под модальным окном.
 */
function lockScroll() {
	scrollLockCount++;
	if (scrollLockCount === 1) {
		document.body.style.overflow = 'hidden';
	}
}

/**
 * Разблокировать скролл страницы.
 */
function unlockScroll() {
	scrollLockCount = Math.max(0, scrollLockCount - 1);
	if (scrollLockCount === 0) {
		document.body.style.overflow = '';
	}
}

/**
 * Создать подложку (Glasspane / Backdrop) с перехватом клика и Escape.
 * @param {Object} [opts]
 * @param {Function} [opts.onClick] Клик по подложке
 * @param {Function} [opts.onEsc] Нажатие клавиши Escape
 * @param {number} [opts.zIndex] Пользовательский z-index
 * @returns {HTMLElement}
 */
function createGlasspane(opts) {
	opts = opts || {};
	var z = opts.zIndex || Z_INDEX.BACKDROP;

	var el = E('div', {
		'class': 'xfree-glasspane',
		'style': 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; ' +
			'background: rgba(0, 0, 0, 0.45); backdrop-filter: blur(2px); ' +
			'z-index: ' + z + '; display: flex; align-items: center; justify-content: center; ' +
			'animation: xfree-fade-in 0.15s ease-out;'
	});

	if (opts.onClick) {
		el.addEventListener('click', function (ev) {
			if (ev.target === el) {
				opts.onClick(ev);
			}
		});
	}

	var escHandler = function (ev) {
		if (ev.key === 'Escape' || ev.keyCode === 27) {
			if (opts.onEsc) {
				opts.onEsc(ev);
			}
		}
	};

	document.addEventListener('keydown', escHandler);

	// Очистка при удалении элемента из DOM
	var origRemove = el.remove;
	el.remove = function () {
		document.removeEventListener('keydown', escHandler);
		unlockScroll();
		if (typeof origRemove === 'function') {
			origRemove.call(el);
		}
	};

	lockScroll();
	return el;
}

/**
 * Зарегистрировать открытую модалку в стеке.
 * @param {HTMLElement} el
 */
function pushModal(el) {
	modalStack.push(el);
}

/**
 * Закрыть верхнюю модалку в стеке.
 */
function popModal() {
	var el = modalStack.pop();
	if (el && typeof el.remove === 'function') {
		el.remove();
	}
}

return baseclass.extend({
	Z: Z_INDEX,
	lockScroll: lockScroll,
	unlockScroll: unlockScroll,
	createGlasspane: createGlasspane,
	pushModal: pushModal,
	popModal: popModal
});

