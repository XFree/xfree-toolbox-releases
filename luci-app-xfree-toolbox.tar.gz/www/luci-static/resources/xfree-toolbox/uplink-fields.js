'use strict';
'require baseclass';

/* Схема полей конфигурации usb-power-watch и рендеринг формы.
 * Методы вешаются на прототип xfree-uplink. */

var FIELD_GROUPS = [
	{
		id: 'monitor',
		title: _('Мониторинг'),
		fields: [
			{ id: 'ENABLED', title: _('Включён (ENABLED)'), type: 'toggle', hint: _('1 = опрос разрешён; нужен cron') },
			{ id: 'LED_STATUS', title: _('LED статус'), type: 'toggle', hint: _('blue:wan / red:fault') },
			{ id: 'INTERVAL_MIN', title: _('Период cron, мин'), type: 'number', min: 1, max: 60 },
			{ id: 'PROBE_INTERVAL_SEC', title: _('Интервал probe, с'), type: 'number', min: 5, max: 300 }
		]
	},
	{
		id: 'probe',
		title: _('Проверка канала'),
		fields: [
			{ id: 'PROBE_IFACE', title: _('Интерфейс probe'), type: 'text', hint: _('auto / wan / lte…') },
			{ id: 'TEST_URL', title: _('Базовый URL'), type: 'text' },
			{ id: 'TEST_URL_ALT', title: _('Доп. URL (полный интернет)'), type: 'text' },
			{ id: 'FAIL_MAX', title: _('Порог FAIL → USB/recovery'), type: 'number', min: 1, max: 20 }
		]
	},
	{
		id: 'vpn',
		title: _('VPN / туннели'),
		fields: [
			{ id: 'TUNNEL_PROBE_ENABLED', title: _('Probe VPN'), type: 'toggle' },
			{ id: 'TUNNEL_ICMP_FAIL_MAX', title: _('FAIL до restart'), type: 'number', min: 1, max: 20 },
			{ id: 'TUNNEL_BOUNCE_MAX', title: _('Макс. restart'), type: 'number', min: 1, max: 20 },
			{ id: 'TUNNEL_BOUNCE_RETRY_MIN', title: _('Пауза до повтора, мин'), type: 'number', min: 0, max: 120 },
			{ id: 'TUNNEL_PROBE_SETTLE_SEC', title: _('Settle после restart, с'), type: 'number', min: 1, max: 300 }
		]
	},
	{
		id: 'vpn_rebuild',
		title: _('Автопересборка VPN (генераторы WARP и Proton)'),
		fields: [
			{
				id: 'TUNNEL_AUTO_REBUILD',
				title: _('Автопересборка'),
				type: 'toggle',
				hint: _('WARP и Proton: при отказе 3/3 после перебора портов; Proton также по сроку сертификата')
			},
			{
				id: 'WARP_PROBE_ATTEMPT_MAX',
				title: _('Макс. серверов WARP при подборе'),
				type: 'number',
				min: 5,
				max: 100,
				hint: _('Сколько серверов проверять при автопересборке WARP')
			}
		]
	},
	{
		id: 'dns',
		title: _('DNS / резолв'),
		fields: [
			{ id: 'DNS_PROBE_ENABLED', title: _('Проверка DNS'), type: 'toggle', hint: _('1 = резолв хостов в каждом тике cron') },
			{ id: 'DNS_PROBE_HOSTS', title: _('Хосты для проверки'), type: 'textarea', rows: 5, hint: _('Домены для проверки локальным резолвером (127.0.0.1), по одному на строку') }
		]
	},
	{
		id: 'usb',
		title: _('USB power-cycle'),
		expert: true,
		fields: [
			{
				id: 'POWER_CYCLE',
				title: _('Режим'),
				type: 'select',
				options: [
					{ v: 'auto', t: 'auto' },
					{ v: 'on', t: 'on' },
					{ v: 'off', t: 'off' }
				]
			},
			{ id: 'CYCLE_MAX', title: _('Макс. попыток'), type: 'number', min: 0, max: 20 },
			{ id: 'OFF_SEC', title: _('OFF, с'), type: 'number', min: 1, max: 60 },
			{ id: 'ON_SEC', title: _('ON, с'), type: 'number', min: 1, max: 60 },
			{ id: 'SETTLE_SEC', title: _('Settle, с'), type: 'number', min: 10, max: 600 }
		]
	}
];

function fieldValue(settings, id) {
	if (!settings)
		return '';
	if (id === 'TUNNEL_AUTO_REBUILD') {
		var warpOn = String(settings.TUNNEL_WARP_REBUILD_ON_FAIL || '') === '1';
		var protonVal = String(settings.PROTON_GUEST_RENEW || '').toLowerCase();
		var protonOn = protonVal !== '' && protonVal !== 'off';
		return (warpOn || protonOn) ? '1' : '0';
	}
	if (settings[id] == null)
		return '';
	return String(settings[id]);
}

return baseclass.extend({
	fieldGroups: FIELD_GROUPS,

	collectSettings: function () {
		var out = {};

		this.querySelectorAll('[data-xfree-uplink-field]').forEach(function(el) {
			var id = el.getAttribute('data-xfree-uplink-field');
			var typ = el.getAttribute('data-field-type') || 'text';

			if (!id)
				return;
			if (id === 'TUNNEL_AUTO_REBUILD') {
				out.TUNNEL_WARP_REBUILD_ON_FAIL = el.checked ? '1' : '0';
				out.PROTON_GUEST_RENEW = el.checked ? 'both' : 'off';
				return;
			}
			if (typ === 'toggle')
				out[id] = el.checked ? '1' : '0';
			else if (typ === 'textarea')
				out[id] = String(el.value || '').trim().split(/\s+/).filter(Boolean).join(' ');
			else
				out[id] = String(el.value || '').trim();
		});

		return out;
	},

	_renderField: function (field, settings) {
		var id = field.id;
		var val = fieldValue(settings, id);
		var control;
		var opts;
		var i;

		if (field.type === 'toggle') {
			control = E('label', { 'class': 'xfree-uplink-toggle' }, [
				E('input', {
					'type': 'checkbox',
					'data-xfree-uplink-field': id,
					'data-field-type': 'toggle',
					'checked': val === '1' ? true : null
				}),
				E('span', { 'class': 'muted' }, [ _('вкл / выкл') ])
			]);
		} else if (field.type === 'select') {
			opts = [];
			for (i = 0; i < (field.options || []).length; i++) {
				opts.push(E('option', {
					'value': field.options[i].v,
					'selected': field.options[i].v === val ? true : null
				}, [ field.options[i].t ]));
			}
			control = E('select', {
				'class': 'xfree-uplink-input',
				'data-xfree-uplink-field': id,
				'data-field-type': 'select'
			}, opts);
		} else if (field.type === 'textarea') {
			var textLines = String(val || '').trim().split(/\s+/).filter(Boolean).join('\n');
			control = E('textarea', {
				'class': 'xfree-uplink-input xfree-uplink-textarea font-mono',
				'rows': field.rows ? String(field.rows) : '5',
				'data-xfree-uplink-field': id,
				'data-field-type': 'textarea',
				'placeholder': 'ya.ru\ngoogle.com\nchatgpt.com\ninstagram.com\nkino.watch\nroblox.com'
			}, [ textLines ]);
		} else {
			control = E('input', {
				'class': 'xfree-uplink-input',
				'type': field.type === 'number' ? 'number' : 'text',
				'data-xfree-uplink-field': id,
				'data-field-type': field.type || 'text',
				'value': val,
				'min': field.min != null ? String(field.min) : null,
				'max': field.max != null ? String(field.max) : null
			});
		}

		var fieldClasses = 'xfree-uplink-field' + (field.type === 'textarea' ? ' is-textarea' : '');
		var fieldStyle = field.type === 'textarea' ? 'grid-column: 1 / -1; max-width: 32rem;' : null;

		/* div wrapper — LuCI themes style bare <label> like CBI titles. */
		return E('div', { 'class': fieldClasses, 'style': fieldStyle }, [
			E('div', { 'class': 'xfree-uplink-field-label' }, [ field.title ]),
			control,
			field.hint ? E('div', { 'class': 'muted xfree-uplink-field-hint' }, [ field.hint ]) : ''
		]);
	},

	_renderFieldGroups: function (expert, settings) {
		var groups = [];
		var g;
		var i;
		var s;
		var fields;
		var subgroups;
		var subFields;

		for (g = 0; g < FIELD_GROUPS.length; g++) {
			if (FIELD_GROUPS[g].expert && !expert)
				continue;
			if (FIELD_GROUPS[g].subgroups) {
				subgroups = [];
				for (s = 0; s < FIELD_GROUPS[g].subgroups.length; s++) {
					subFields = [];
					for (i = 0; i < FIELD_GROUPS[g].subgroups[s].fields.length; i++)
						subFields.push(this._renderField(FIELD_GROUPS[g].subgroups[s].fields[i], settings));
					subgroups.push(E('div', { 'class': 'xfree-uplink-subgroup' }, [
						E('div', { 'class': 'xfree-uplink-subgroup-title' }, [ FIELD_GROUPS[g].subgroups[s].title ]),
						E('div', { 'class': 'xfree-uplink-fields' }, subFields)
					]));
				}
				groups.push(E('section', { 'class': 'xfree-uplink-group' }, [
					E('h4', {}, [ FIELD_GROUPS[g].title ]),
					E('div', { 'class': 'xfree-uplink-subgroups' }, subgroups)
				]));
				continue;
			}
			fields = [];
			for (i = 0; i < FIELD_GROUPS[g].fields.length; i++)
				fields.push(this._renderField(FIELD_GROUPS[g].fields[i], settings));
			groups.push(E('section', { 'class': 'xfree-uplink-group' }, [
				E('h4', {}, [ FIELD_GROUPS[g].title ]),
				E('div', { 'class': 'xfree-uplink-fields' }, fields)
			]));
		}

		return groups;
	}
});
