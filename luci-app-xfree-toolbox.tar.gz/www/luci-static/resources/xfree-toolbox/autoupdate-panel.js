'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-autoupdate-panel';

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this.requestPaint();
	}

	render() {
		this.className = 'cbi-section';
		this.replaceChildren(
			E('h3', {}, [ _('Автообновление') ]),
			E('div', { 'class': 'cbi-section-descr' }, [
				_('Настройка автообновления списков и компонентов xfree-toolbox.')
			])
		);
	}
});

return baseclass.extend({
	tag: TAG
});
