'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';

/* Шапка экрана устройств и сборка. Матрица рисуется соседним модулем. */

return baseclass.extend({
	render: function () {
		var self = this;
		var leases = this._leases || [];
		var ifaces = this._ifaces || [];
		var isLoading = this._loading;
		var isScanning = this._scanning;
		var scanScope = this._scanScope || 'lan';

		// 1. Matrix Model
		var matrixData = this._buildMatrixData();
		var allItems = matrixData.list;

		// Summary counters
		var totalRules = 0;
		var directWanCount = 0;
		var forceTunnelCount = 0;
		var forceZapretCount = 0;

		for (var k = 0; k < allItems.length; k++) {
			var itm = allItems[k];
			var st = (self._matrixState && self._matrixState[itm.id]) || { target: itm.target, zapret: itm.zapret };
			if (st.target !== 'default' || st.zapret !== 'auto') {
				totalRules++;
			}
			if (st.target === 'wan') {
				directWanCount++;
			} else if (st.target.indexOf('tunnel:') === 0) {
				forceTunnelCount++;
			}
			if (st.zapret === 'force') {
				forceZapretCount++;
			}
		}

		var isDirty = this._isDirty();
		var dirtyCount = this._getDirtyCount();

		// 2. Header
		var head = E('div', { 'class': 'xfree-vpn-head' }, [
			E('div', { 'class': 'xfree-vpn-head-left' }, [
				E('h3', {}, [_('Матрица маршрутизации устройств (Device Routing Matrix)')]),
				E('p', { 'class': 'muted' }, [
					_('Наглядное переключение маршрута для каждого устройства в один клик: прямой WAN, обычные списки или выделенный VPN-туннель. Для обхода туннелей целыми подсетями используйте вкладку «PBR Bypass».')
				])
			]),
			E('div', { 'class': 'xfree-vpn-head-right' }, [
				E('div', { 'class': 'xfree-vpn-head-actions' }, [
					xcmp.button({
						variant: 'vpn',
						primary: true,
						title: _('Перейти к настройке обхода туннелей для целых подсетей и интерфейсов (LAN, Guest, VLAN)'),
						text: '🌐 ' + _('PBR Bypass сетей →'),
						onClick: function () {
							if (self._view && typeof self._view.navigate === 'function')
								self._view.navigate('vpn', 'pbrbypass', 'vpn.pbrbypass');
						}
					}),
					xcmp.button({
						variant: 'vpn',
						primary: true,
						disabled: isLoading || isScanning,
						onClick: function () { self.reload(); },
						children: [
							E('span', { 'class': isLoading ? 'is-spinning' : '' }, ['🔄']),
							' ' + (isLoading ? _('Обновление…') : _('Обновить'))
						]
					}),
					xcmp.button({
						variant: 'vpn',
						primary: true,
						text: '+ ' + _('Добавить устройство'),
						onClick: function () { self._openEditDialog(); }
					}),
					xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'xfree-vpn-head-btn is-primary' + (isDirty ? ' is-dirty' : ''),
						text: isDirty ? ('⚡ ' + _('Сохранить и применить')) : ('⚡ ' + _('Применить правила')),
						onClick: function () {
							if (isDirty) self._saveMatrix();
							else self._applyRules();
						}
					})
				]),
				this._msg ? E('div', {
					'class': 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
					'data-xfree-dp-msg': '1'
				}, [this._msg]) : ''
			])
		]);

		// 3. Status Chips
		var chips = E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, [
			xcmp.chip({ label: _('Правил'), value: String(totalRules) }),
			xcmp.chip({
				label: _('Direct WAN'),
				value: String(directWanCount),
				tone: directWanCount > 0 ? 'ok' : ''
			}),
			xcmp.chip({
				label: _('В туннелях'),
				value: String(forceTunnelCount),
				tone: forceTunnelCount > 0 ? 'ok' : ''
			}),
			xcmp.chip({
				label: _('В Zapret'),
				value: String(forceZapretCount),
				tone: forceZapretCount > 0 ? 'ok' : ''
			}),
			xcmp.chip({ label: _('Клиентов в сети'), value: String(leases.length) }),
			xcmp.chip({
				label: _('Сети PBR'),
				value: _('Открыть →'),
				extraClass: 'is-link',
				title: _('Перейти к матрице PBR Bypass для целых интерфейсов и подсетей'),
				onClick: function () {
					if (self._view && typeof self._view.navigate === 'function')
						self._view.navigate('vpn', 'pbrbypass', 'vpn.pbrbypass');
				}
			})
		]);
		var matrix = this._renderDeviceMatrix({
			allItems: allItems,
			ifaces: ifaces,
			isLoading: isLoading,
			isScanning: isScanning,
			scanScope: scanScope,
			isDirty: isDirty,
			dirtyCount: dirtyCount
		});

		this.replaceChildren(head, chips, matrix);
	}
});
