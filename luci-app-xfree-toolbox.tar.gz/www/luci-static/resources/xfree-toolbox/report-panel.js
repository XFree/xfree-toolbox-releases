'use strict';
'require baseclass';
'require ui';
'require rpc';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-report';

var callUplinkMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'uplinkMenu',
	params: [ 'action', 'arg', 'settings' ]
});

function parseDnsReport(text) {
	var lines = (text || '').split(/\r?\n/);
	var status = 'idle';
	var stamp = '';
	var primary = '';
	var summaryText = '';
	var sections = [];
	var curSec = null;
	var i;
	var line;
	var m;

	for (i = 0; i < lines.length; i++) {
		line = lines[i];
		if ((m = line.match(/^STATUS:\s*([a-z-]+)/))) {
			status = m[1];
		} else if ((m = line.match(/^=== Диагностика DNS\s+([^=]+)\s*===/))) {
			stamp = m[1].trim();
		} else if ((m = line.match(/^Основной DNS[^:]*:\s*(.+)$/))) {
			primary = m[1].trim();
		} else if ((m = line.match(/^\[\*\]\s*Итог проверки:\s*(.+)$/))) {
			summaryText = m[1].trim();
		} else if ((m = line.match(/^Секция\s+(.+)$/))) {
			if (curSec)
				sections.push(curSec);
			var secLine = m[1];
			var isPrim = /\[основной\]/.test(secLine);
			secLine = secLine.replace(/\[основной\]/, '').trim();
			var parts = secLine.split(/\s+/);
			var target = parts.length > 1 ? parts[parts.length - 1] : '';
			var label = parts.length > 1 ? parts.slice(0, parts.length - 1).join(' ') : secLine;
			curSec = {
				label: label,
				target: target,
				isPrimary: isPrim,
				hosts: [],
				okCount: 0,
				failCount: 0,
				minMs: 999999,
				maxMs: 0
			};
		} else if (curSec && (m = line.match(/^\s+([A-Za-z0-9_.-]+)\s+(OK|FAIL)\s+([A-Za-z0-9_?-]+)\s+(\d+)ms\s+A=(.+)$/))) {
			var ok = m[2] === 'OK';
			var ms = parseInt(m[4], 10);
			var hostEntry = {
				host: m[1],
				ok: ok,
				rcode: m[3],
				ms: ms,
				ip: m[5].trim()
			};
			curSec.hosts.push(hostEntry);
			if (ok) curSec.okCount++; else curSec.failCount++;
			if (ms < curSec.minMs) curSec.minMs = ms;
			if (ms > curSec.maxMs) curSec.maxMs = ms;
		}
	}
	if (curSec)
		sections.push(curSec);

	var totalOk = 0;
	var totalFail = 0;
	var overallMin = 999999;
	var overallMax = 0;

	for (i = 0; i < sections.length; i++) {
		totalOk += sections[i].okCount;
		totalFail += sections[i].failCount;
		if (sections[i].minMs === 999999)
			sections[i].minMs = 0;
		if (sections[i].minMs < overallMin)
			overallMin = sections[i].minMs;
		if (sections[i].maxMs > overallMax)
			overallMax = sections[i].maxMs;
	}
	if (overallMin === 999999)
		overallMin = 0;

	return {
		status: status,
		stamp: stamp,
		primary: primary,
		summaryText: summaryText,
		totalOk: totalOk,
		totalFail: totalFail,
		totalQueries: totalOk + totalFail,
		minMs: overallMin,
		maxMs: overallMax,
		sections: sections
	};
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._filterMode = 'all';
		this._searchQuery = '';
		this._showConsole = false;
		this.requestPaint();
	}

	get text() {
		var el = this.querySelector('xfree-console');

		return el ? el.text : (this._spec && this._spec.text) || '';
	}

	set text(value) {
		var el = this.querySelector('xfree-console');

		if (this._spec)
			this._spec.text = value || '';
		if (el)
			el.text = value || '';
		if (this._isDns)
			this.requestPaint();
	}

	_openDomainDialog() {
		var self = this;
		var s = this._spec || {};
		var defaultHosts = 'ya.ru\ngoogle.com\nyoutube.com\ngithub.com\ncloudflare.com\nexample.com';
		var extendedHosts = defaultHosts + '\nt.me\nvk.com\nwikipedia.org\nkinopoisk.ru';

		callUplinkMenu('dnsHostsGet', '', '').then(function(res) {
			var currentHosts = (res && res.stdout && res.stdout.trim()) ? res.stdout.trim() : defaultHosts;
			var ta = E('textarea', {
				'class': 'xfree-dns-hosts-textarea',
				'rows': '7',
				'placeholder': defaultHosts
			}, [ currentHosts ]);

			var presets = E('div', { 'class': 'xfree-dns-presets' }, [
				E('span', { 'class': 'muted font-xs', 'style': 'align-self:center; margin-right:4px;' }, [ _('Пресеты:') ]),
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'click': function(ev) {
						ev.preventDefault();
						ta.value = defaultHosts;
					}
				}, [ _('Стандартный (6)') ]),
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'click': function(ev) {
						ev.preventDefault();
						ta.value = extendedHosts;
					}
				}, [ _('Расширенный (10)') ])
			]);

			ui.showModal(_('🌐 Домены для диагностики DNS'), [
				E('div', { 'class': 'xfree-dialog-body' }, [
					E('p', { 'class': 'xfree-dialog-hint muted' }, [
						_('Список опрашиваемых доменов (по одному на строку). Сохраняется в /etc/xfree-toolbox/system/dns-check-hosts.txt.')
					]),
					ta,
					presets
				]),
				E('div', { 'class': 'xfree-dialog-actions' }, [
					E('button', {
						'class': 'btn primary',
						'type': 'button',
						'click': function() {
							ui.hideModal();
							var val = String(ta.value || '').trim();
							callUplinkMenu('dnsHostsSave', val, '').then(function() {
								if (s.onReload)
									s.onReload();
							});
						}
					}, [ _('Сохранить и запустить') ]),
					E('button', {
						'class': 'btn secondary',
						'type': 'button',
						'click': function() {
							ui.hideModal();
							var val = String(ta.value || '').trim();
							callUplinkMenu('dnsHostsSave', val, '');
						}
					}, [ _('Сохранить') ]),
					E('button', {
						'class': 'btn ghost',
						'type': 'button',
						'click': function() {
							ui.hideModal();
							callUplinkMenu('dnsHostsReset', '', '').then(function() {
								if (s.onReload)
									s.onReload();
							});
						}
					}, [ _('Сбросить к исходным') ]),
					E('button', {
						'class': 'btn ghost',
						'type': 'button',
						'click': function() {
							ui.hideModal();
						}
					}, [ _('Отмена') ])
				])
			], 'cbi-modal', 'xfree-dialog', 'xfree-vpn-dialog');
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ _('Ошибка получения списка доменов: %s').format(err) ]), 'danger');
		});
	}

	_renderGenericReport(s, desc, pollSec, view, reloadFn) {
		var consoleEl = E('xfree-console', {
			'label': _('Вывод'),
			'class': 'xfree-report-output',
			'style': '--xfree-console-max-height:70vh'
		});
		consoleEl.text = s.text || '';

		this.className = 'panel-block';
		this.replaceChildren(
			E('h3', {}, [ s.title || '' ]),
			E('p', { 'class': 'muted' }, [ desc ]),
			E('div', { 'class': 'actions', 'style': 'grid-template-columns:1fr;max-width:16rem' }, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': ui.createHandlerFn(view, reloadFn)
				}, [ _('Обновить') ])
			]),
			consoleEl
		);
	}

	_renderDnsDashboard(s, view, reloadFn) {
		var self = this;
		var parsed = parseDnsReport(s.text || '');
		var isRunning = parsed.status === 'running';
		var failSecCount = 0;
		var totalSecCount = parsed.sections.length;
		var i;
		var j;

		for (i = 0; i < parsed.sections.length; i++) {
			if (parsed.sections[i].failCount > 0)
				failSecCount++;
		}

		// Hero stats cards
		var statusBadge;
		if (isRunning) {
			statusBadge = E('span', { 'class': 'xfree-vpn-status is-warn spinning' }, [ _('Проверка идёт в фоне…') ]);
		} else if (parsed.stamp) {
			statusBadge = E('span', { 'class': 'xfree-vpn-status is-ok' }, [ '✓ ' + _('Готов') + ' · ' + parsed.stamp ]);
		} else {
			statusBadge = E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Нет данных') ]);
		}

		var resultVal;
		if (parsed.totalQueries === 0) {
			resultVal = E('span', { 'class': 'muted' }, [ '—' ]);
		} else if (parsed.totalFail === 0) {
			resultVal = E('span', { 'style': 'color: var(--ok, #16a34a);' }, [
				'✓ ' + parsed.totalOk + '/' + parsed.totalQueries + ' OK'
			]);
		} else {
			resultVal = E('span', { 'style': 'color: var(--bad, #dc2626);' }, [
				'✗ ' + parsed.totalFail + ' ' + _('сбоев') + ' (' + parsed.totalOk + ' OK)'
			]);
		}

		var statsBlock = E('div', { 'class': 'xfree-dns-stats' }, [
			E('div', { 'class': 'xfree-dns-stat-card' }, [
				E('div', { 'class': 'k' }, [ _('Результат') ]),
				E('div', { 'class': 'v' }, [ resultVal ])
			]),
			E('div', { 'class': 'xfree-dns-stat-card' }, [
				E('div', { 'class': 'k' }, [ _('Секции DNS') ]),
				E('div', { 'class': 'v' }, [ String(totalSecCount) + ' ' + _('резолверов') ])
			]),
			E('div', { 'class': 'xfree-dns-stat-card' }, [
				E('div', { 'class': 'k' }, [ _('Основной DNS') ]),
				E('div', { 'class': 'v font-mono', 'style': 'font-size: 13px;' }, [ parsed.primary || _('не задан') ])
			]),
			E('div', { 'class': 'xfree-dns-stat-card' }, [
				E('div', { 'class': 'k' }, [ _('Задержка') ]),
				E('div', { 'class': 'v' }, [
					parsed.totalQueries > 0
						? String(parsed.minMs) + '–' + String(parsed.maxMs) + ' ms'
						: '—'
				])
			])
		]);

		// Toolbar: Action buttons & Filter
		var updateBtn = E('button', {
			'class': 'btn',
			'type': 'button',
			'click': ui.createHandlerFn(view, function(ev) {
				if (ev) ev.preventDefault();
				if (reloadFn) reloadFn();
			})
		}, [ isRunning ? ('⏳ ' + _('Проверка идёт…')) : ('🔄 ' + _('Запустить проверку')) ]);

		var domainsBtn = E('button', {
			'class': 'ghost',
			'type': 'button',
			'click': function(ev) {
				if (ev) ev.preventDefault();
				self._openDomainDialog();
			}
		}, [ '🌐 ' + _('Настроить домены') ]);

		var consoleToggleBtn = E('button', {
			'class': 'ghost',
			'type': 'button',
			'click': function(ev) {
				if (ev) ev.preventDefault();
				self._showConsole = !self._showConsole;
				self.requestPaint();
			}
		}, [ self._showConsole ? ('📋 ' + _('Скрыть лог')) : ('📋 ' + _('Терминал (лог)')) ]);

		var searchInput = E('input', {
			'type': 'text',
			'class': 'xfree-dns-search',
			'placeholder': _('Поиск домена или секции…'),
			'value': self._searchQuery || '',
			'input': function() {
				self._searchQuery = String(this.value || '').toLowerCase().trim();
				self.requestPaint();
			}
		});

		var allFilterBtn = E('button', {
			'class': (self._filterMode === 'all' ? 'btn ghost-compact' : 'ghost ghost-compact'),
			'type': 'button',
			'click': function(ev) {
				if (ev) ev.preventDefault();
				self._filterMode = 'all';
				self.requestPaint();
			}
		}, [ _('Все (%d)').format(totalSecCount) ]);

		var failFilterBtn = E('button', {
			'class': (self._filterMode === 'fail' ? 'btn ghost-compact' : 'ghost ghost-compact'),
			'type': 'button',
			'style': failSecCount > 0 ? 'color: var(--bad, #dc2626); font-weight: 600;' : '',
			'click': function(ev) {
				if (ev) ev.preventDefault();
				self._filterMode = 'fail';
				self.requestPaint();
			}
		}, [ _('⚠️ Ошибки (%d)').format(failSecCount) ]);

		var toolbar = E('div', { 'class': 'xfree-dns-toolbar' }, [
			E('div', { 'class': 'xfree-dns-actions' }, [
				updateBtn,
				domainsBtn,
				consoleToggleBtn
			]),
			E('div', { 'class': 'xfree-dns-filters' }, [
				searchInput,
				allFilterBtn,
				failFilterBtn
			])
		]);

		// Resolver Section Cards
		var cards = [];
		var query = self._searchQuery;
		var onlyFail = self._filterMode === 'fail';

		for (i = 0; i < parsed.sections.length; i++) {
			var sec = parsed.sections[i];

			if (onlyFail && sec.failCount === 0)
				continue;

			var secLabelLower = sec.label.toLowerCase();
			var secTargetLower = sec.target.toLowerCase();
			var secMatchesQuery = !query || secLabelLower.indexOf(query) >= 0 || secTargetLower.indexOf(query) >= 0;

			var rows = [];
			for (j = 0; j < sec.hosts.length; j++) {
				var h = sec.hosts[j];
				var hostMatches = !query || secMatchesQuery || h.host.toLowerCase().indexOf(query) >= 0;

				if (!hostMatches)
					continue;
				if (onlyFail && h.ok)
					continue;

				var latClass = h.ms <= 25 ? 'is-fast' : (h.ms <= 100 ? 'is-med' : 'is-slow');
				var statusBadgeEl = h.ok
					? E('span', { 'class': 'xfree-vpn-badge is-ok' }, [ '✓ ' + (h.rcode || 'OK') ])
					: E('span', { 'class': 'xfree-vpn-badge is-bad' }, [ '✗ ' + (h.rcode || 'FAIL') ]);

				rows.push(E('tr', {}, [
					E('td', { 'style': 'font-weight: 600;' }, [ h.host ]),
					E('td', {}, [ statusBadgeEl ]),
					E('td', {}, [
						E('span', { 'class': 'xfree-dns-latency ' + latClass }, [ h.ms + ' ms' ])
					]),
					E('td', { 'class': 'xfree-dns-ip' }, [ h.ip ])
				]));
			}

			if (rows.length === 0 && query && !secMatchesQuery)
				continue;

			var secBadges = [];
			if (sec.isPrimary)
				secBadges.push(E('span', { 'class': 'xfree-vpn-status is-ok', 'style': 'padding: 1px 6px; font-size: 10px;' }, [ _('основной') ]));

			if (sec.hosts.length > 0) {
				secBadges.push(E('span', { 'class': 'xfree-vpn-badge' }, [
					'⚡ ' + sec.minMs + '–' + sec.maxMs + ' ms'
				]));
				if (sec.failCount === 0) {
					secBadges.push(E('span', { 'class': 'xfree-vpn-badge is-ok' }, [
						'✓ ' + sec.okCount + '/' + sec.hosts.length + ' OK'
					]));
				} else {
					secBadges.push(E('span', { 'class': 'xfree-vpn-badge is-bad' }, [
						'✗ ' + sec.failCount + ' FAIL (' + sec.okCount + '/' + sec.hosts.length + ')'
					]));
				}
			}

			// Allow setting or clearing primary DNS directly on the card
			if (sec.target && sec.target !== '8.8.8.8#53') {
				(function(s) {
					var pBtn;
					if (s.isPrimary) {
						pBtn = E('button', {
							'class': 'ghost ghost-compact',
							'style': 'padding: 1px 7px; font-size: 10px; margin-left: auto; border: 1px solid var(--line); border-radius: 4px;',
							'title': _('Убрать этот DNS из основных (отключить catch-all редирект dnsmasq)'),
							'click': ui.createHandlerFn(view, function(ev) {
								if (ev) ev.preventDefault();
								var btn = ev.target;
								btn.disabled = true;
								btn.textContent = '⏳ ' + _('Снятие…');
								return callUplinkMenu('dnsPrimaryClear', s.target).then(function() {
									if (reloadFn) reloadFn();
								}).catch(function(err) {
									ui.addNotification(null, E('p', [ _('Ошибка: ') + (err.message || err) ]), 'error');
									btn.disabled = false;
									btn.textContent = '✕ ' + _('Убрать из основных');
								});
							})
						}, [ '✕ ' + _('Убрать из основных') ]);
					} else {
						pBtn = E('button', {
							'class': 'btn ghost-compact',
							'style': 'padding: 1px 7px; font-size: 10px; margin-left: auto; border-radius: 4px;',
							'title': _('Сделать этот DNS основным (catch-all для запросов dnsmasq)'),
							'click': ui.createHandlerFn(view, function(ev) {
								if (ev) ev.preventDefault();
								var btn = ev.target;
								btn.disabled = true;
								btn.textContent = '⏳ ' + _('Применение…');
								return callUplinkMenu('dnsPrimarySet', s.target).then(function() {
									if (reloadFn) reloadFn();
								}).catch(function(err) {
									ui.addNotification(null, E('p', [ _('Ошибка: ') + (err.message || err) ]), 'error');
									btn.disabled = false;
									btn.textContent = '★ ' + _('Сделать основным');
								});
							})
						}, [ '★ ' + _('Сделать основным') ]);
					}
					secBadges.push(pBtn);
				})(sec);
			}

			var cardClass = 'xfree-dns-card';
			if (sec.failCount > 0) cardClass += ' is-failed';
			if (sec.isPrimary) cardClass += ' is-primary';

			cards.push(E('div', { 'class': cardClass }, [
				E('div', {
					'class': 'xfree-dns-card-head',
					'style': 'display: flex; flex-direction: column; gap: 6px; border-bottom: 1px solid color-mix(in srgb, var(--line) 40%, transparent); padding-bottom: 8px;'
				}, [
					E('div', {
						'class': 'xfree-dns-card-title',
						'style': 'display: flex; align-items: baseline; justify-content: space-between; gap: 8px; font-size: 13px; min-width: 0;'
					}, [
						E('strong', {
							'title': sec.label,
							'style': 'overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'
						}, [ sec.label ]),
						E('span', {
							'class': 'muted font-mono',
							'style': 'font-size: 11px; flex-shrink: 0;'
						}, [ sec.target ])
					]),
					E('div', {
						'class': 'xfree-dns-card-badges',
						'style': 'display: flex; align-items: center; gap: 6px; flex-wrap: wrap; min-height: 24px; width: 100%;'
					}, secBadges)
				]),
				E('table', { 'class': 'xfree-dns-table' }, [
					E('thead', {}, [
						E('tr', {}, [
							E('th', {}, [ _('Домен') ]),
							E('th', {}, [ _('Статус') ]),
							E('th', {}, [ _('Задержка') ]),
							E('th', {}, [ _('A-запись (IP)') ])
						])
					]),
					E('tbody', {}, rows.length ? rows : [
						E('tr', {}, [
							E('td', { 'colspan': '4', 'class': 'muted', 'style': 'text-align: center; padding: 12px;' }, [
								_('Нет записей, соответствующих фильтру')
							])
						])
					])
				])
			]));
		}

		if (cards.length === 0) {
			cards.push(E('div', { 'class': 'panel-block', 'style': 'text-align: center; padding: 32px; color: var(--muted);' }, [
				_('Нет секций DNS, соответствующих выбранным критериям поиска')
			]));
		}

		var cardsGrid = E('div', { 'class': 'xfree-dns-cards' }, cards);

		// Raw console element
		var consoleEl = E('xfree-console', {
			'label': _('Сырой вывод терминала (dns-check.log)'),
			'class': 'xfree-report-output',
			'style': '--xfree-console-max-height:70vh; margin-top: 12px;' + (self._showConsole ? '' : 'display: none;')
		});
		consoleEl.text = s.text || '';

		this.className = 'panel-block';
		this.replaceChildren(
			E('div', { 'class': 'xfree-dns-root' }, [
				E('div', { 'style': 'display: flex; align-items: baseline; justify-content: space-between; gap: 10px; flex-wrap: wrap;' }, [
					E('div', {}, [
						E('h3', { 'style': 'margin: 0 0 4px;' }, [ s.title || _('Диагностика DNS') ]),
						E('p', { 'class': 'muted', 'style': 'margin: 0;' }, [
							s.descr || _('Запросы A по секциям DNS активного профиля и эталонам Google.')
						])
					]),
					statusBadge
				]),
				statsBlock,
				toolbar,
				cardsGrid,
				consoleEl
			])
		);
	}

	render() {
		var s = this._spec || {};
		var desc = s.descr || _('Отчёт с роутера (тот же скрипт, что в CLI).');
		var pollSec = s.pollSec || 0;
		var view = s.view;
		var reloadFn = s.onReload;

		this._isDns = (s.title && s.title.indexOf('DNS') >= 0) ||
			(s.descr && s.descr.indexOf('DNS') >= 0) ||
			/Диагностика DNS|STATUS:.*pid=|=== Диагностика DNS/.test(s.text || '');

		if (this._isDns) {
			this._renderDnsDashboard(s, view, reloadFn);
		} else {
			this._renderGenericReport(s, desc, pollSec, view, reloadFn);
		}
	}
});

return baseclass.extend({
	tag: TAG
});
