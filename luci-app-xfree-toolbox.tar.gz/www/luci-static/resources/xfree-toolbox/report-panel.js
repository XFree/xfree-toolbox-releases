'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.console-output';
'require xfree-toolbox.report-parser as reportParser';
'require xfree-toolbox.report-dns-dialog as reportDnsDialog';
'require xfree-toolbox.report-dns-cards as reportDnsCards';
'require xfree-toolbox.report-view as reportView';

/* Экран отчётов и дашборда диагностики DNS.
 * Разбор вывода, диалог доменов, карточки резолверов и сборка
 * живут в соседних модулях и вешаются на один прототип xfree-report. */

var TAG = 'xfree-report';

var ReportPanel = class extends wc.LightElement {
	get text() {
		var el = this.querySelector('xfree-console');

		return el ? el.text : (this._spec && this._spec.text) || '';
	}

	set text(value) {
		var el = this.querySelector('xfree-console');

		if (this._spec)
			this._spec.text = value || '';
		if (el)
			el.text = value || '';
		if (this._isDns)
			this.requestPaint();
	}
};

function mixReport(part) {
	prototypeMix.mixInto(ReportPanel.prototype, part);
}

mixReport(reportParser);
mixReport(reportDnsDialog);
mixReport(reportDnsCards);
mixReport(reportView);

wc.define(TAG, ReportPanel);

return baseclass.extend({
	tag: TAG
});
