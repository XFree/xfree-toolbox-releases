'use strict';
'require baseclass';
'require ui';
'require rpc';
'require xfree-toolbox.components as components';
'require xfree-toolbox.core.loading as loading';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.core.text-io as textIo';

var xcmp = components;

var callUplinkMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'uplinkMenu',
	params: [ 'action', 'arg', 'settings' ]
});

var SOURCES = [
	{
		id: 'system',
		title: _('Системный журнал'),
		sub: 'logread',
		icon: '📋',
		action: 'systemLogs',
		hint: _('Логи ядра Linux, демонов OpenWrt и системных процессов')
	},
	{
		id: 'watchdog',
		title: _('Мониторинг канала'),
		sub: 'uplink-monitor',
		icon: '⏱️',
		action: 'watchdogLogs',
		hint: _('Логи проверок доступности сети, пинга и USB-сброса модема')
	},
	{
		id: 'routing',
		title: _('Маршрутизация'),
		sub: 'routing-check',
		icon: '🌐',
		action: 'routingLogs',
		hint: _('Логи проверок сетевых интерфейсов, туннелей и правил nftables')
	},
	{
		id: 'dns',
		title: _('Диагностика DNS'),
		sub: 'dns-check',
		icon: '🔍',
		action: 'dnsLogs',
		hint: _('Логи проверок резолверов и ответов upstream-серверов')
	},
	{
		id: 'autoupdate',
		title: _('Автообновление'),
		sub: 'auto-update',
		icon: '🔄',
		action: 'autoupdateLogs',
		hint: _('Журнал автоматических ночных проверок релизов')
	}
];

function highlightLine(line) {
	var lower = line.toLowerCase();
	var tone = '';

	if (/\b(error|fail|failed|fatal|critical|panic|alert|emergency)\b/i.test(line)) {
		tone = 'color: #f87171;';
	} else if (/\b(warn|warning)\b/i.test(line)) {
		tone = 'color: #fbbf24;';
	} else if (/\b(ok|success|ready|connected|established)\b/i.test(line)) {
		tone = 'color: #4ade80;';
	}

	return E('div', {
		'class': 'xfree-log-line',
		'style': 'padding: 1px 0; border-bottom: 1px solid rgba(255,255,255,0.03); word-break: break-all;' + (tone ? (' ' + tone) : '')
	}, [ line ]);
}

return baseclass.extend({
	_activeSource: 'system',
	_linesCount: '150',
	_searchQuery: '',
	_rawText: '',
	_autoTimer: null,
	_isLoading: false,

	/**
	 * Получить лог с роутера через RPC
	 */
	fetchLog: function (sourceId, lines) {
		var src = SOURCES.find(function(s) { return s.id === sourceId; }) || SOURCES[0];
		var n = lines || this._linesCount || '150';

		return callUplinkMenu(src.action, String(n), '').then(function(res) {
			if (res && res.stdout)
				return res.stdout;
			if (res && res.stderr)
				return res.stderr;
			return _('(Журнал пуст или не содержит записей)');
		}).catch(function(err) {
			return _('Ошибка загрузки лога: ') + (err.message || String(err));
		});
	},

	render: function (opts) {
		opts = opts || {};
		var self = this;
		var view = opts.view || {};
		var onRefresh = opts.onRefresh;

		if (opts.activeSource)
			self._activeSource = opts.activeSource;

		var wrapEl = E('div', { 'class': 'xfree-dashboard-wrap xfree-logs-page' });

		// Source Selector Buttons (Tabs)
		var sourceChips = SOURCES.map(function (src) {
			var isCurrent = (src.id === self._activeSource);
			return E('button', {
				'class': isCurrent ? 'btn primary sm' : 'ghost ghost-compact',
				'type': 'button',
				'style': 'display: flex; gap: 6px; align-items: center; border-radius: 8px;',
				'title': src.hint,
				'click': function (ev) {
					ev.preventDefault();
					if (self._activeSource === src.id)
						return;
					self._activeSource = src.id;
					self.reloadLog();
				}
			}, [
				E('span', {}, [ src.icon ]),
				E('span', { 'style': 'font-weight: 550;' }, [ src.title ]),
				E('span', { 'class': 'muted font-xs', 'style': 'opacity: 0.7;' }, [ '(' + src.sub + ')' ])
			]);
		});

		var sourcesBar = E('div', {
			'class': 'xfree-log-sources-bar',
			'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; padding: 10px; background: var(--panel-2, #ffffff); border: 1px solid var(--line, rgba(0,0,0,0.06)); border-radius: 10px;'
		}, sourceChips);

		// Controls
		var searchInput = E('input', {
			'type': 'text',
			'class': 'xfree-dns-search',
			'placeholder': _('Поиск по логу…'),
			'style': 'max-width: 220px; font-size: 13px; height: 32px;',
			'value': self._searchQuery,
			'input': function () {
				self._searchQuery = String(this.value || '').trim().toLowerCase();
				self.updateTerminalContent();
			}
		});

		var lineSelect = E('select', {
			'class': 'cbi-input-select',
			'style': 'font-size: 12px; height: 32px; border-radius: 6px;',
			'change': function () {
				self._linesCount = this.value;
				self.reloadLog();
			}
		}, [
			E('option', { 'value': '100', 'selected': self._linesCount === '100' ? '' : null }, [ '100 ' + _('строк') ]),
			E('option', { 'value': '150', 'selected': self._linesCount === '150' ? '' : null }, [ '150 ' + _('строк') ]),
			E('option', { 'value': '300', 'selected': self._linesCount === '300' ? '' : null }, [ '300 ' + _('строк') ]),
			E('option', { 'value': '600', 'selected': self._linesCount === '600' ? '' : null }, [ '600 ' + _('строк') ])
		]);

		var refreshBtn = E('button', {
			'class': 'btn ghost-compact',
			'type': 'button',
			'title': _('Обновить текущий журнал'),
			'click': function (ev) {
				ev.preventDefault();
				self.reloadLog();
			}
		}, [ '🔄 ' + _('Обновить') ]);

		var autoToggleBtn = E('button', {
			'class': self._autoTimer ? 'btn primary sm' : 'ghost ghost-compact',
			'type': 'button',
			'title': _('Автоматический опрос каждые 5 секунд'),
			'click': function (ev) {
				ev.preventDefault();
				if (self._autoTimer) {
					clearInterval(self._autoTimer);
					self._autoTimer = null;
					this.className = 'ghost ghost-compact';
				} else {
					self._autoTimer = setInterval(function () {
						self.reloadLog(true);
					}, 5000);
					this.className = 'btn primary sm';
				}
			}
		}, [ '⏱️ ' + _('Авто (5с)') ]);

		var copyBtn = E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'title': _('Скопировать лог в буфер обмена'),
			'click': function (ev) {
				ev.preventDefault();
				textIo.writeText(self._rawText || '').then(function () {
					ui.addNotification(null, E('p', {}, [ _('Журнал скопирован в буфер обмена') ]), 'info');
				}, function () {});
			}
		}, [ '📋 ' + _('Скопировать') ]);

		var downloadBtn = E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'title': _('Скачать текстовый файл'),
			'click': function (ev) {
				ev.preventDefault();
				textIo.downloadText(
					'xfree-' + self._activeSource + '-' + (new Date().toISOString().replace(/[:.]/g, '-')) + '.log',
					self._rawText || ''
				);
			}
		}, [ '📥 ' + _('Скачать') ]);

		var scrollBottomBtn = E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'title': _('Прокрутить вниз'),
			'click': function (ev) {
				ev.preventDefault();
				var pre = wrapEl.querySelector('.xfree-logs-terminal');
				if (pre) pre.scrollTop = pre.scrollHeight;
			}
		}, [ '⬇️ ' + _('Вниз') ]);

		var lineCounterBadge = E('span', {
			'class': 'xfree-badge is-muted font-xs',
			'style': 'margin-left: auto; align-self: center;'
		}, [ '0 ' + _('строк') ]);

		var toolbar = E('div', {
			'class': 'xfree-logs-toolbar',
			'style': 'display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin-bottom: 12px; padding: 8px 12px; background: var(--panel-2, #ffffff); border: 1px solid var(--line, rgba(0,0,0,0.06)); border-radius: 10px;'
		}, [
			searchInput,
			lineSelect,
			refreshBtn,
			autoToggleBtn,
			copyBtn,
			downloadBtn,
			scrollBottomBtn,
			lineCounterBadge
		]);

		// Terminal container
		var terminalPre = E('div', {
			'class': 'xfree-logs-terminal font-mono',
			'style': 'height: 60vh; min-height: 380px; overflow-y: auto; padding: 12px 14px; background: #18181b; color: #e4e4e7; border-radius: 10px; font-size: 12px; line-height: 1.45; border: 1px solid rgba(255,255,255,0.08); box-shadow: inset 0 2px 4px rgba(0,0,0,0.3);'
		}, [
			E('div', { 'class': 'muted font-mono', 'style': 'padding: 20px 0; text-align: center;' }, [ _('Загрузка журнала…') ])
		]);

		// Status Footer
		var currentSrcObj = SOURCES.find(function(s) { return s.id === self._activeSource; }) || SOURCES[0];
		var statusFooter = E('div', {
			'class': 'xfree-logs-footer muted font-xs',
			'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 8px; padding: 0 4px;'
		}, [
			E('span', {}, [ _('Источник: ') + currentSrcObj.title + ' (' + currentSrcObj.sub + ')' ]),
			E('span', {}, [ _('Нажмите «Авто (5с)» для живого отслеживания новых событий') ])
		]);

		var header = xcmp.actionBar({
			title: _('Логи и системные журналы'),
			description: _('Просмотр системного журнала OpenWrt (logread), сторожевого таймера, проверок маршрутизации и обновлений'),
			actions: [
				xcmp.badge({
					text: currentSrcObj.title,
					tone: 'ok',
					icon: currentSrcObj.icon
				})
			]
		});

		wrapEl.appendChild(header);
		wrapEl.appendChild(sourcesBar);
		wrapEl.appendChild(toolbar);
		wrapEl.appendChild(terminalPre);
		wrapEl.appendChild(statusFooter);

		self._terminalEl = terminalPre;
		self._counterEl = lineCounterBadge;
		self._refreshBtn = refreshBtn;
		self._wrapEl = wrapEl;

		self.reloadLog();

		return wrapEl;
	},

	reloadLog: function (silent) {
		var self = this;
		if (self._isLoading)
			return;

		self._isLoading = true;
		if (!silent && self._refreshBtn) {
			self._refreshBtn.innerText = '⏳ ' + _('Загрузка…');
		}

		self.fetchLog(self._activeSource, self._linesCount).then(function (text) {
			self._rawText = String(text || '');
			self._isLoading = false;
			if (self._refreshBtn) {
				self._refreshBtn.innerText = '🔄 ' + _('Обновить');
			}
			self.updateTerminalContent();
		}).catch(function (err) {
			self._isLoading = false;
			if (self._refreshBtn) {
				self._refreshBtn.innerText = '🔄 ' + _('Обновить');
			}
			self._rawText = _('Ошибка получения журнала: ') + (err.message || String(err));
			self.updateTerminalContent();
		});
	},

	updateTerminalContent: function () {
		var self = this;
		if (!self._terminalEl)
			return;

		var allLines = self._rawText ? self._rawText.split(/\r?\n/) : [];
		var q = self._searchQuery;
		var filtered = allLines;

		if (q) {
			filtered = allLines.filter(function (line) {
				return line.toLowerCase().indexOf(q) !== -1;
			});
		}

		var lineNodes = [];
		for (var i = 0; i < filtered.length; i++) {
			var ln = filtered[i];
			if (!ln && i === filtered.length - 1)
				continue;
			lineNodes.push(highlightLine(ln));
		}

		if (lineNodes.length === 0) {
			lineNodes.push(E('div', {
				'class': 'muted font-mono',
				'style': 'padding: 30px 0; text-align: center;'
			}, [ q ? _('Ничего не найдено по фильтру «%s»').format(q) : _('(Журнал пуст)') ]));
		}

		self._terminalEl.replaceChildren.apply(self._terminalEl, lineNodes);

		if (self._counterEl) {
			self._counterEl.innerText = filtered.length + '/' + allLines.length + ' ' + _('строк');
		}

		// Scroll to bottom on initial load
		if (!q) {
			self._terminalEl.scrollTop = self._terminalEl.scrollHeight;
		}
	}
});
