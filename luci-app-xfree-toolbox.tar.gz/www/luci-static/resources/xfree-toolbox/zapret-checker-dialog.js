'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.zapret-probe-dialog as probeDlg';

/**
 * Диалог проверки доступности сервисов и DPI (YouTube, Discord, Остальные, DPI: TCP 16-20).
 * Отображает линейный прогресс-бар в процентах, текущий шаг с детальным описанием действия,
 * и живую таблицу результатов, наполняющуюся в реальном времени.
 */

function parseCheckerOutput(text, target) {
	var lines = (text || '').split(/\r?\n/);
	var rows = [];
	var i, line;

	for (i = 0; i < lines.length; i++) {
		line = lines[i];

		// Формат CHECK_ROW|service=...|host=...|proto=...|status=...|code=...|latency=...
		if (line.indexOf('CHECK_ROW|') === 0) {
			var fields = {};
			var parts = line.substring(10).split('|');
			for (var j = 0; j < parts.length; j++) {
				var kv = parts[j].split('=');
				if (kv.length >= 2) {
					fields[kv[0]] = kv.slice(1).join('=');
				}
			}
			rows.push({
				service: fields.service || fields.host || 'Service',
				host: fields.host || '',
				proto: fields.proto || 'TCP 443',
				status: fields.status || 'PASS',
				code: fields.code || '',
				latency: fields.latency || '',
				isPass: (fields.status === 'PASS' || fields.status === 'CLEAN' || fields.status === 'OK')
			});
			continue;
		}

		// Формат для TCP 16-20 (DPI): ID Provider Host Alive DPI
		if (target === 'dpi') {
			var dparts = line.trim().split(/\s+/);
			if (dparts.length >= 5 && /^[A-Z0-9_.-]+$/.test(dparts[0]) && dparts[0] !== 'ID') {
				var dpiStatus = dparts[dparts.length - 1];
				var isDetected = /DETECTED/i.test(dpiStatus);
				var isClean = /NOT_DETECTED|No/i.test(dpiStatus);
				var host = dparts[dparts.length - 3];
				var provider = dparts.slice(1, dparts.length - 3).join(' ');
				rows.push({
					service: provider || dparts[0],
					host: host,
					proto: 'TCP 16-20',
					status: isDetected ? 'DETECTED' : (isClean ? 'CLEAN' : dpiStatus),
					code: dpiStatus,
					latency: '-',
					isPass: isClean
				});
			}
		}
	}

	return rows;
}

return baseclass.extend({
	openCheckerDialog: function(view, opts) {
		var self = this;
		var o = opts || {};
		var title = o.title || _('Проверка доступности');
		var target = o.target || 'youtube';

		var modalContent = E('div', {
			'class': 'xfree-zapret-checker-dialog',
			'style': 'width: 100%; box-sizing: border-box; background: transparent;'
		});

		var statusText = E('p', {
			'class': 'muted xfree-checker-status-text',
			'style': 'margin-bottom: 8px; font-size: 13px;'
		}, [ _('Подготовка и запуск диагностики доступности…') ]);

		var progressBar = E('div', {
			'class': 'xfree-progress-bar-bg',
			'style': 'width: 100%; height: 8px; background: rgba(120, 140, 160, 0.2); border-radius: 4px; overflow: hidden; margin: 8px 0 10px 0;'
		}, [
			E('div', {
				'class': 'xfree-progress-bar-fill',
				'style': 'width: 0%; height: 100%; background: #3498db; transition: width 0.3s ease;'
			})
		]);

		var progressWrap = E('div', {
			'class': 'xfree-checker-progress-wrap',
			'style': 'margin: 12px 0; padding: 12px; background: var(--panel-2); border-radius: 8px; border: 1px solid var(--line);'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 4px;' }, [
				E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('span', { 'class': 'is-spinning', 'style': 'font-size: 16px;' }, [ '⏳' ]),
					E('strong', { 'class': 'xfree-checker-step-title' }, [ _('Инициализация проверки…') ])
				]),
				E('span', {
					'class': 'xfree-checker-percent-label',
					'style': 'font-size: 12px; font-weight: 600; color: #3498db;'
				}, [ '0%' ])
			]),
			progressBar,
			E('p', {
				'class': 'muted xfree-checker-step-detail',
				'style': 'margin: 0; font-size: 12px; font-family: monospace;'
			}, [ _('Подключение к тестовым серверам…') ])
		]);

		var liveTableWrap = E('div', {
			'class': 'xfree-checker-live-table-wrap',
			'style': 'margin-top: 12px;'
		});

		modalContent.appendChild(statusText);
		modalContent.appendChild(progressWrap);
		modalContent.appendChild(liveTableWrap);

		var dlgHandle = xui.openDialog({
			title: '🎯 ' + title,
			size: 'wide',
			body: modalContent,
			actions: [
				{
					label: _('Закрыть'),
					variant: 'secondary',
					close: true
				}
			]
		});

		// Запуск RPC команды
		var rpcAction = o.action;
		if (!rpcAction) {
			if (o.target === 'discord') {
				rpcAction = 'testDiscordCurrent';
			} else if (o.target === 'others') {
				rpcAction = 'testOthersCurrent';
			} else if (o.target === 'dpi') {
				rpcAction = 'testDpiTcp';
			} else {
				rpcAction = 'testYoutubeCurrent';
			}
		}
		xui.runZapretMenu(rpcAction, '').then(function(res) {
			return self._pollCheckerTask(view, modalContent, dlgHandle, o, 0);
		}).catch(function(err) {
			modalContent.replaceChildren(
				E('div', { 'class': 'alert-message danger' }, [
					_('Ошибка запуска проверки: %s').format(err && err.message || err)
				])
			);
		});
	},

	_pollCheckerTask: function(view, container, dlgHandle, opts, attempt) {
		var self = this;
		var n = attempt || 0;

		return xui.runZapretMenu('taskStatus', '').then(function(res) {
			var text = xui.formatExecReport(res || {});
			var running = xui.ifaceTaskRunning(res);
			var cleanText = xui.cleanTaskStatusOutput(text);

			// Парсим актуальный прогресс
			var curIdx = 0, totIdx = 0, curPct = 0, curTitle = '', curDetail = '';

			// 1. Формат PROGRESS|idx=...|total=...|percent=...|action=...|detail=...
			var progMatch = cleanText.match(/PROGRESS\|idx=(\d+)\|total=(\d+)\|percent=(\d+)\|action=([^|]+)\|detail=([^\r\n|]+)/g);
			if (progMatch && progMatch.length > 0) {
				var lastProg = progMatch[progMatch.length - 1];
				var pm = lastProg.match(/idx=(\d+)\|total=(\d+)\|percent=(\d+)\|action=([^|]+)\|detail=([^\r\n|]+)/);
				if (pm) {
					curIdx = pm[1];
					totIdx = pm[2];
					curPct = pm[3];
					curTitle = pm[4];
					curDetail = pm[5];
				}
			} else {
				// 2. Формат PROBE_STEP|idx=...|total=...|service=...|host=...
				var stepMatch = cleanText.match(/PROBE_STEP\|idx=(\d+)\|total=(\d+)\|(?:service|section)=([^|]+)\|host=([^\r\n|]+)/g);
				if (stepMatch && stepMatch.length > 0) {
					var lastStep = stepMatch[stepMatch.length - 1];
					var sm = lastStep.match(/idx=(\d+)\|total=(\d+)\|(?:service|section)=([^|]+)\|host=([^\r\n|]+)/);
					if (sm) {
						curIdx = sm[1];
						totIdx = sm[2];
						curPct = Math.round((parseInt(curIdx, 10) / parseInt(totIdx, 10)) * 100);
						curTitle = sm[3];
						curDetail = _('Запрос FQDN: %s (TCP/TLS)…').format(sm[4]);
					}
				}
			}

			// Обновляем прогресс-бар в реальном времени
			if (totIdx > 0) {
				var titleEl = container.querySelector('.xfree-checker-step-title');
				var detailEl = container.querySelector('.xfree-checker-step-detail');
				var fillEl = container.querySelector('.xfree-progress-bar-fill');
				var pctEl = container.querySelector('.xfree-checker-percent-label');

				if (titleEl) {
					titleEl.textContent = _('Шаг [%s / %s]: %s').format(curIdx, totIdx, curTitle);
				}
				if (detailEl && curDetail) {
					detailEl.textContent = curDetail;
				}
				if (fillEl) {
					fillEl.style.width = curPct + '%';
				}
				if (pctEl) {
					pctEl.textContent = curPct + '%';
				}
			}

			// Промежуточный рендер завершенных строк прямо в таблицу
			var rows = parseCheckerOutput(cleanText, opts.target);
			var liveTableWrap = container.querySelector('.xfree-checker-live-table-wrap');
			if (liveTableWrap && rows.length > 0) {
				self._renderRowsTableOnly(liveTableWrap, rows, opts);
			}

			if (running && n < 60) {
				return new Promise(function(resolve) {
					setTimeout(function() {
						resolve(self._pollCheckerTask(view, container, dlgHandle, opts, n + 1));
					}, 1000);
				});
			}

			// Финализация: для YouTube дополнительно запускаем клиентский тест видеострима и QUIC из браузера
			if (opts.target === 'youtube') {
				var titleEl = container.querySelector('.xfree-checker-step-title');
				var detailEl = container.querySelector('.xfree-checker-step-detail');
				var fillEl = container.querySelector('.xfree-progress-bar-fill');
				var pctEl = container.querySelector('.xfree-checker-percent-label');

				if (titleEl) titleEl.textContent = _('Шаг [5 / 5]: Тестирование видеострима и QUIC в браузере…');
				if (detailEl) detailEl.textContent = _('Запрос эндпоинта https://www.youtube.com/generate_204 из вашего браузера…');
				if (fillEl) fillEl.style.width = '88%';
				if (pctEl) pctEl.textContent = '88%';

				self._testClientYouTubeStream().then(function(clientRow) {
					if (clientRow) {
						rows.push(clientRow);
						if (liveTableWrap) {
							self._renderRowsTableOnly(liveTableWrap, rows, opts);
						}
					}
					self._finalizeChecker(view, container, dlgHandle, rows, opts);
				});
			} else {
				self._finalizeChecker(view, container, dlgHandle, rows, opts);
			}
		}).catch(function(err) {
			container.replaceChildren(
				E('div', { 'class': 'alert-message danger' }, [
					_('Ошибка получения данных проверки: %s').format(err && err.message || err)
				])
			);
		});
	},

	_testClientYouTubeStream: function() {
		return new Promise(function(resolve) {
			var testUrl = 'https://www.youtube.com/generate_204?client_stream_test=' + Date.now();
			var startTime = performance.now();
			var resolved = false;

			var timer = setTimeout(function() {
				if (resolved) return;
				resolved = true;
				resolve({
					service: _('Клиент: Видеопоток / QUIC'),
					host: 'www.youtube.com',
					proto: 'HTTP/3 (QUIC / UDP 443)',
					status: 'FAIL',
					code: 'TIMEOUT',
					latency: '>3.0s',
					isPass: false,
					isClientStream: true,
					isH3: false,
					clientInfo: _('Таймаут соединения из браузера. Трафик UDP 443 (QUIC) может блокироваться провайдером.')
				});
			}, 3000);

			fetch(testUrl, {
				mode: 'no-cors',
				cache: 'no-store'
			}).then(function() {
				if (resolved) return;
				resolved = true;
				clearTimeout(timer);
				var elapsed = Math.round(performance.now() - startTime);
				var protoName = 'HTTP/3 (QUIC / UDP 443)';
				var isH3 = false;

				// Проверка Resource Timing API браузера на предмет протокола
				try {
					var entries = performance.getEntriesByName(testUrl);
					if (entries && entries.length > 0) {
						var p = entries[entries.length - 1].nextHopProtocol || '';
						if (/h3|quic/i.test(p)) {
							protoName = 'HTTP/3 (QUIC / UDP 443)';
							isH3 = true;
						} else if (/h2/i.test(p)) {
							protoName = 'HTTP/2 (TCP fallback)';
						} else if (p) {
							protoName = p.toUpperCase();
						}
					}
				} catch (e) {}

				resolve({
					service: _('Клиент: Видеопоток / QUIC'),
					host: 'www.youtube.com',
					proto: protoName,
					status: 'PASS',
					code: isH3 ? 'H3_OK' : 'OK',
					latency: elapsed + 'ms',
					isPass: true,
					isClientStream: true,
					isH3: isH3,
					clientInfo: isH3
						? _('Прямой видеопоток HTTP/3 (QUIC / UDP 443) активен и успешно открывается в вашем браузере.')
						: _('Видеопоток доступен в браузере с быстрым откликом (%sms).').format(elapsed)
				});
			}).catch(function() {
				if (resolved) return;
				resolved = true;
				clearTimeout(timer);
				var elapsed = Math.round(performance.now() - startTime);
				resolve({
					service: _('Клиент: Видеопоток / QUIC'),
					host: 'www.youtube.com',
					proto: 'HTTP/3 (QUIC / UDP 443)',
					status: 'FAIL',
					code: 'BLOCKED',
					latency: elapsed + 'ms',
					isPass: false,
					isClientStream: true,
					isH3: false,
					clientInfo: _('Браузер не смог установить соединение с сервером YouTube.')
				});
			});
		});
	},

	_renderRowsTableOnly: function(wrap, rows, opts) {
		var isDpi = opts.target === 'dpi';
		var trs = rows.map(function(r) {
			var badgeTone = r.isPass ? 'ok' : 'bad';
			var badgeText = r.isPass ? (r.code ? 'OK (' + r.code + ')' : 'OK') : (r.code ? 'FAIL (' + r.code + ')' : 'FAIL');
			if (isDpi) {
				badgeTone = r.isPass ? 'ok' : (r.status === 'DETECTED' ? 'bad' : 'warn');
				badgeText = r.code || r.status;
			}

			var badge = xcmp.badge({
				variant: 'vpn-status',
				tone: badgeTone,
				text: badgeText,
				style: 'font-size: 11px; padding: 2px 6px;'
			});

			var rowStyle = 'background-color: #ffffff !important;';
			if (r.isClientStream) {
				rowStyle = r.isPass ? 'background-color: #eff6ff !important; font-weight: 500;' : 'background-color: #fef2f2 !important;';
			} else if (r.isPass) {
				rowStyle = 'background-color: #f0fdf4 !important; font-weight: 500;';
			} else {
				rowStyle = 'background-color: #fef2f2 !important;';
			}

			return E('tr', { 'style': rowStyle }, [
				E('td', { 'style': 'padding: 8px 12px; font-weight: 500; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [
					r.isClientStream ? '🎬 ' + r.service : r.service
				]),
				E('td', { 'style': 'padding: 8px 12px; font-family: monospace; font-size: 12px; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [ r.host ]),
				E('td', { 'style': 'padding: 8px 12px; font-size: 12px; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [
					r.isClientStream
						? E('span', { 'style': 'color: #2563eb; font-weight: 600;' }, [ r.proto ])
						: r.proto
				]),
				E('td', { 'style': 'padding: 8px 12px; text-align: center; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [ badge ]),
				E('td', { 'style': 'padding: 8px 12px; text-align: right; font-family: monospace; font-size: 12px; border-bottom: 1px solid #e2e8f0; background-color: inherit;' }, [
					r.latency || '-'
				])
			]);
		});

		var thStyle = 'padding: 10px 12px; position: sticky; top: 0; z-index: 10; background-color: #ffffff !important; border-bottom: 2px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08); font-weight: 600; font-size: 12px; color: #1e293b;';

		var table = E('div', {
			'style': 'max-height: 400px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 8px; background-color: #ffffff !important;'
		}, [
			E('table', { 'class': 'table', 'style': 'width: 100%; margin: 0; font-size: 12.5px; border-collapse: separate; border-spacing: 0; background-color: #ffffff !important;' }, [
				E('thead', {}, [
					E('tr', {}, [
						E('th', { 'style': thStyle }, [ _('Сервис / Узел') ]),
						E('th', { 'style': thStyle }, [ _('Хост (FQDN)') ]),
						E('th', { 'style': thStyle }, [ _('Протокол') ]),
						E('th', { 'style': thStyle + ' text-align: center;' }, [ _('Статус') ]),
						E('th', { 'style': thStyle + ' text-align: right;' }, [ _('Отклик') ])
					])
				]),
				E('tbody', {}, trs)
			])
		]);

		wrap.replaceChildren(table);
	},

	_finalizeChecker: function(view, container, dlgHandle, rows, opts) {
		var self = this;
		var isDpi = opts.target === 'dpi';
		var allPass = rows.length > 0 && rows.every(function(r) { return r.isPass; });
		var hasFail = rows.some(function(r) { return !r.isPass; });

		// Фиксируем прогресс-бар на 100%
		var fillEl = container.querySelector('.xfree-progress-bar-fill');
		var pctEl = container.querySelector('.xfree-checker-percent-label');
		var titleEl = container.querySelector('.xfree-checker-step-title');
		var detailEl = container.querySelector('.xfree-checker-step-detail');
		var spinner = container.querySelector('.is-spinning');

		if (fillEl) fillEl.style.width = '100%';
		if (pctEl) pctEl.textContent = '100%';
		if (titleEl) titleEl.textContent = _('Диагностика завершена');
		if (detailEl) detailEl.textContent = _('Все запланированные проверки выполнены.');
		if (spinner) {
			spinner.className = '';
			spinner.textContent = allPass ? '✅' : '⚠️';
		}

		// Вставляем итоговый баннер перед таблицей с гарантированной изоляцией ширины (box-sizing: border-box)
		var existingBanner = container.querySelector('.xfree-checker-result-banner');
		if (existingBanner) existingBanner.remove();

		var banner;
		if (allPass) {
			banner = E('div', {
				'class': 'xfree-checker-result-banner',
				'style': 'margin: 12px 0; padding: 12px 16px; border-radius: 8px; background-color: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; box-sizing: border-box; width: 100%;'
			}, [
				E('strong', { 'style': 'display: block; font-size: 13px; font-weight: 600; color: #047857;' }, [ isDpi ? _('DPI-блокировки не обнаружены!') : _('Все проверенные компоненты доступны!') ]),
				E('p', { 'style': 'margin: 4px 0 0 0; font-size: 12px; color: #065f46;' }, [
					isDpi
						? _('Пакеты с окном TCP 16-20 проходят штатно без разрыва соединений.')
						: _('Текущая стратегия Zapret успешно пропускает трафик целевых сервисов.')
				])
			]);
		} else {
			banner = E('div', {
				'class': 'xfree-checker-result-banner',
				'style': 'margin: 12px 0; padding: 12px 16px; border-radius: 8px; background-color: #fffbeb; border: 1px solid #fde68a; color: #92400e; box-sizing: border-box; width: 100%;'
			}, [
				E('strong', { 'style': 'display: block; font-size: 13px; font-weight: 600; color: #b45309;' }, [ isDpi ? _('Обнаружены следы активности DPI!') : _('Обнаружены блокировки или недоступность части узлов.') ]),
				E('p', { 'style': 'margin: 4px 0 0 0; font-size: 12px; color: #92400e;' }, [
					isDpi
						? _('Ряд проверочных серверов сбрасывают или задерживают соединения при размере окна TCP 16-20.')
						: _('Вы можете запустить быстрый автоподбор стратегии для восстановления доступа.')
				])
			]);
		}

		var progressWrap = container.querySelector('.xfree-checker-progress-wrap');
		if (progressWrap) {
			progressWrap.insertAdjacentElement('afterend', banner);

			// Для YouTube отображаем карточку клиентского стрима
			if (opts.target === 'youtube') {
				var existingStreamCard = container.querySelector('.xfree-quic-stream-card');
				if (existingStreamCard) existingStreamCard.remove();

				var clientRow = rows.find(function(r) { return r.isClientStream; });
				if (clientRow) {
					var streamCard = E('div', {
						'class': 'xfree-quic-stream-card',
						'style': 'margin: 10px 0; padding: 10px 14px; background: ' + (clientRow.isPass ? 'rgba(46, 204, 113, 0.08)' : 'rgba(231, 76, 60, 0.08)') + '; border: 1px solid ' + (clientRow.isPass ? 'rgba(46, 204, 113, 0.3)' : 'rgba(231, 76, 60, 0.3)') + '; border-radius: 8px;'
					}, [
						E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center;' }, [
							E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
								E('span', { 'style': 'font-size: 16px;' }, [ '🎬' ]),
								E('strong', {}, [ _('Клиентский видеострим (Браузер):') ]),
								xcmp.badge({
									variant: 'vpn-status',
									tone: clientRow.isPass ? 'ok' : 'bad',
									text: clientRow.proto,
									style: 'font-size: 11px; padding: 2px 6px;'
								})
							]),
							E('span', { 'style': 'font-family: monospace; font-size: 12px; font-weight: 600;' }, [
								_('Отклик: %s').format(clientRow.latency || '-')
							])
						]),
						E('p', { 'style': 'margin: 4px 0 0 24px; font-size: 12px; color: var(--text-muted);' }, [
							clientRow.clientInfo
						])
					]);
					banner.insertAdjacentElement('afterend', streamCard);
				}
			}
		}

		// Кнопки в подвале через унифицированный xui dialog API
		var actionBtns = [];

		if (opts.target === 'youtube') {
			actionBtns.push({
				label: '🎬 ' + _('Замерить стрим / QUIC'),
				variant: 'secondary',
				click: function(ev) {
					var btn = ev.target;
					btn.disabled = true;
					btn.textContent = '⏳ ' + _('Замер стрима…');
					self._testClientYouTubeStream().then(function(newClientRow) {
						var idx = rows.findIndex(function(r) { return r.isClientStream; });
						if (idx >= 0) rows[idx] = newClientRow;
						else rows.push(newClientRow);
						var liveTableWrap = container.querySelector('.xfree-checker-live-table-wrap');
						if (liveTableWrap) self._renderRowsTableOnly(liveTableWrap, rows, opts);
						self._finalizeChecker(view, container, dlgHandle, rows, opts);
					});
				}
			});
		}

		if (opts.probeOpts) {
			actionBtns.push({
				label: '⚡ ' + (hasFail ? _('Подобрать стратегию') : _('Переподобрать стратегию')),
				variant: hasFail ? 'primary' : 'secondary',
				click: function() {
					dlgHandle.hide();
					probeDlg.openProbeDialog(view, opts.probeOpts);
				}
			});
		}

		actionBtns.push({
			label: '🔄 ' + _('Повторить'),
			variant: 'secondary',
			click: function() {
				dlgHandle.hide();
				self.openCheckerDialog(view, opts);
			}
		});

		actionBtns.push({
			label: _('Закрыть'),
			variant: 'secondary',
			close: true
		});

		dlgHandle.setActions(actionBtns);
	}
});
