'use strict';
'require baseclass';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.components as xcmp';

/* Карточка устаревшего VK-Turn. Метод вешается на прототип xfree-vpn-server. */

return baseclass.extend({
	_renderVkTurnCard: function (awg) {
		var self = this;
		// Card 4: VK-Turn Proxy Card (Legacy transport - only shown if installed, offers removal only)
		var vkTurnPortShow = awg.vkPort || '49151';
		var vkTurnCard = null;

		if (awg.vkInstalled) {
			var vkTurnParamsRows = [
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('входящий порт')]),
					E('span', {}, [
						E('strong', {}, ['0.0.0.0:' + vkTurnPortShow + ' (UDP)']),
						' WAN ➔ Router'
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('статус службы')]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
						E('span', { 'class': 'xfree-vpn-badge is-' + (awg.vkRunning ? 'warn' : 'muted') }, [
							awg.vkRunning ? _('работает (устарел)') : _('остановлена')
						]),
						E('span', {}, [
							awg.vkRunning
								? _('Служба /etc/init.d/vk-turn активна')
								: _('Служба /etc/init.d/vk-turn не запущена')
						])
					])
				])
			];

			var vkTurnActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
				E('div', { 'class': 'xfree-vpn-actions-group is-danger' }, [
					xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'is-bad',
						title: _('Полностью удалить устаревший VK-Turn с роутера (служба, бинарник, firewall)'),
						text: '🗑️ ' + _('Удалить VK-Turn'),
						onClick: function (ev) {
							self._act(ev, 'vkTurnUninstall', '', {
								title: _('Удаление VK-Turn'),
								message: _('Полностью удалить устаревший VK-Turn прокси с роутера?'),
								detail: _('Служба /etc/init.d/vk-turn будет остановлена и удалена, файлы /opt/vk-turn-proxy удалены, порт %s закрыт в Firewall для освобождения ресурсов.').format(vkTurnPortShow),
								confirmText: _('Да, удалить VK-Turn'),
								tone: 'danger',
								icon: '🗑️'
							});
						}
					})
				])
			]);

			vkTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px; border-color: color-mix(in srgb, var(--bad, #ef4444) 40%, var(--line));' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', { 'style': 'color: var(--bad);' }, [_('VK-Turn Proxy (Устаревший легаси-транспорт)')]),
						xui.helpBtn({
							title: _('VK-Turn Proxy (Легаси)'),
							desc: _('Устаревший UDP-прокси первого поколения. Поддержка и разработка прекращены в пользу FreeTurn. Рекомендуется удалить его для освобождения ресурсов роутера.')
						}),
						E('span', { 'class': 'muted' }, ['UDP ' + vkTurnPortShow])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						xcmp.badge({ variant: 'vpn-status', tone: 'bad', text: _('ОБНАРУЖЕН НА РОУТЕРЕ') }),
						awg.vkVersion ? xcmp.badge({ variant: 'vpn-status', tone: 'muted', text: awg.vkVersion }) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, [
					E('p', { 'style': 'margin: 0 0 6px 0; font-size: 13px; color: var(--text);' }, [
						_('На роутере обнаружен устаревший транспортный прокси VK-Turn. Разработка и установка VK-Turn прекращены в пользу FreeTurn. Рекомендуется удалить его для освобождения flash-памяти и оперативной памяти роутера.')
					]),
					E('div', {}, vkTurnParamsRows)
				]),
				vkTurnActions
			]);
		}
		return vkTurnCard;
	}
});
