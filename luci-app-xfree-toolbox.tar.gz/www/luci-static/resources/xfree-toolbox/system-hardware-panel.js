'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.core.loading as loading';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.system-hardware-report as hardwareReport';
'require xfree-toolbox.system-hardware-cards as hardwareCards';

var xcmp = components;

return baseclass.extend({
	parseReport: hardwareReport.parseHardwareReport,

	/**
	 * Главный рендер панели «Оборудование»
	 * @param {Object} opts — { data, view, onRefresh }
	 * @returns {Node}
	 */
	render: function (opts) {
		opts = opts || {};
		var data = opts.data || {};
		var view = opts.view || {};
		var onRefresh = opts.onRefresh;

		var rawText = '';
		if (data.execResult) {
			rawText = data.execResult.stdout || data.execResult.stderr || '';
		}

		var info = hardwareReport.parseHardwareReport(rawText);

		var panelView = {
			runSystemAction: function (action, arg, payload) {
				var x = (typeof xui !== 'undefined') ? xui : null;
				if (x && typeof x.runSystemMenuWithOutput === 'function') {
					return x.runSystemMenuWithOutput(action, arg, payload);
				}
				if (view && typeof view.runSystemMenu === 'function') {
					return view.runSystemMenu(action, arg, payload);
				}
				if (x && typeof x.runSystemMenu === 'function') {
					return x.runSystemMenu(action, arg, payload);
				}
				return Promise.reject(new Error('runSystemMenu is not available'));
			}
		};

		var cards = [
			hardwareCards.renderWpsButtonCard(info, panelView, onRefresh),
			hardwareCards.renderNfcCard(info, panelView),
			hardwareCards.renderUsbPowerCard(info, panelView),
			hardwareCards.renderLedTestCard(info, panelView)
		];

		var refreshBtn = xcmp.refreshButton({
			isRefreshing: false,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(refreshBtn, res);
					}
				}
			}
		});

		var actionBar = xcmp.actionBar({
			title: _('Оборудование и периферия'),
			description: _('Управление аппаратными кнопками, NFC-метками, питанием USB и светодиодами'),
			actions: [ refreshBtn ]
		});

		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод hardwareStatus)'),
			rawText: rawText,
			maxHeight: '250px'
		});

		return E('div', { 'class': 'xfree-dashboard-wrap' }, [
			actionBar,
			E('div', {
				'class': 'xfree-card-grid',
				'style': 'display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 16px;'
			}, cards),
			spoiler
		]);
	}
});
