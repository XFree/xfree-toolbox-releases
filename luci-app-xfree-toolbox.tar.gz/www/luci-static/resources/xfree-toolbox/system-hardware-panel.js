'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.loading as loading';
'require xfree-toolbox.luci-ui as xui';

var xcmp = components;

/**
 * Парсер текстового отчета hardwareStatus
 * @param {string} text
 * @returns {Object}
 */
function parseHardwareReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		wpsEnabled: false,
		nfcAvailable: false,
		nfcBoard: '',
		nfcBoardName: '',
		usbPower: {
			board: '',
			backends: {
				xhciMtk: false,
				gpioSwitch: false,
				uhubctl: false
			},
			anyBackendReady: false,
			autoSelect: ''
		},
		rawText: String(text || '')
	};

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i].trim();
		if (!line)
			continue;

		if (line.indexOf('Обновление профиля кнопкой WPS/Mesh: ВКЛЮЧЕНО') !== -1 ||
		    (line.indexOf('WPS/Mesh') !== -1 && line.indexOf('ВКЛЮЧЕНО') !== -1)) {
			res.wpsEnabled = true;
		}

		if (line.indexOf('NFC_BOARD=unsupported') !== -1) {
			res.nfcBoard = 'unsupported';
		} else if (line.indexOf('NFC_BOARD=supported') !== -1) {
			res.nfcBoard = 'supported';
		} else if (line.indexOf('NFC_BOARD=unknown') !== -1) {
			res.nfcBoard = 'unknown';
		}

		var nfcBoardName = line.match(/^NFC_BOARD_NAME=(.*)$/);
		if (nfcBoardName && nfcBoardName[1])
			res.nfcBoardName = nfcBoardName[1].trim();

		if (line.indexOf('NFC_SCRIPT=available') !== -1) {
			res.nfcAvailable = true;
		}

		if (line.indexOf('=== USB power') !== -1) {
			var matchBoard = line.match(/model=(.*?)\)\s*===/);
			if (matchBoard && matchBoard[1]) {
				res.usbPower.board = matchBoard[1].trim();
			} else {
				var matchShort = line.match(/board=([^ ]+)/);
				if (matchShort && matchShort[1])
					res.usbPower.board = matchShort[1].trim();
			}
		}

		if (line.indexOf('xhci-mtk:') !== -1 && line.indexOf('нет') === -1) {
			res.usbPower.backends.xhciMtk = true;
			res.usbPower.anyBackendReady = true;
		}
		if (line.indexOf('gpio-switch:') !== -1 && line.indexOf('нет') === -1) {
			res.usbPower.backends.gpioSwitch = true;
			res.usbPower.anyBackendReady = true;
		}
		if (line.indexOf('uhubctl:') !== -1 && line.indexOf('нет') === -1) {
			res.usbPower.backends.uhubctl = true;
			res.usbPower.anyBackendReady = true;
		}

		if (line.indexOf('Автовыбор:') !== -1) {
			res.usbPower.autoSelect = line.substring(10).trim();
		}
	}

	return res;
}

function renderMetricRow(label, valueNode) {
	return E('div', { 'class': 'xfree-metric-row' }, [
		E('span', { 'class': 'xfree-metric-label' }, [ label ]),
		E('div', { 'class': 'xfree-metric-value' }, [ valueNode ])
	]);
}

function renderWpsButtonCard(info, view, onRefresh) {
	var isEn = info.wpsEnabled;
	var badgeTone = isEn ? 'ok' : 'neutral';
	var badgeText = isEn ? _('Включено (sync 3с)') : _('Штатный режим');

	var rows = [];

	rows.push(renderMetricRow(_('Статус перехвата'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		xcmp.badge({
			text: isEn ? _('Перехват активен') : _('Штатный WPS OpenWrt'),
			tone: isEn ? 'ok' : 'neutral'
		})
	])));

	rows.push(renderMetricRow(_('Действие по удержанию'), E('span', {}, [
		_('Синхронизация профиля (sync-apply)')
	])));

	rows.push(renderMetricRow(_('Время зажатия кнопки'), E('span', { 'class': 'font-mono' }, [
		_('3 секунды')
	])));

	rows.push(renderMetricRow(_('Hotplug обработчик'), E('span', { 'class': 'font-mono muted', 'style': 'font-size: 11px;' }, [
		'/etc/hotplug.d/button/90-xfree-wps-sync-apply'
	])));

	var btnAction = isEn ? xcmp.button({
		text: _('Вернуть штатный WPS'),
		tone: 'secondary',
		onClick: function (ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('wpsButtonDisable').then(function () {
				ui.addNotification(null, E('p', {}, [ _('Перехват кнопки WPS отключен') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function (err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	}) : xcmp.button({
		text: _('⚡ Включить перехват WPS (3с)'),
		tone: 'primary',
		onClick: function (ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('wpsButtonEnable').then(function () {
				ui.addNotification(null, E('p', {}, [ _('Перехват кнопки WPS включен') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function (err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [ btnAction ]);

	return xcmp.card({
		title: _('Аппаратная кнопка (WPS / Mesh)'),
		subtitle: _('Запуск синхронизации списков и профиля по зажатию кнопки на корпусе роутера'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderNfcCard(info, view) {
	var unsupported = info.nfcBoard === 'unsupported';
	var unknown = info.nfcBoard === 'unknown';
	var isAvail = !!(info.nfcAvailable && !unsupported && !unknown);
	var badgeTone = isAvail ? 'ok' : 'neutral';
	var badgeText = unsupported ? _('Нет NFC') : (isAvail ? _('Готов') : _('Не настроен'));
	var supportText = _('Скрипт записи не найден');
	if (unsupported)
		supportText = _('На этой модели нет NFC-метки');
	else if (unknown)
		supportText = _('Модель не подтверждена');
	else if (isAvail)
		supportText = _('Утилита доступна');

	var rows = [];

	if (info.nfcBoardName) {
		rows.push(renderMetricRow(_('Модель'), E('span', { 'class': 'font-mono' }, [
			info.nfcBoardName
		])));
	}

	rows.push(renderMetricRow(_('Модуль / Скрипт'), E('span', { 'class': 'font-mono muted', 'style': 'font-size: 11px;' }, [
		'xinfc/write-nfc-5g.sh'
	])));

	rows.push(renderMetricRow(_('Статус поддержки'), E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
		xcmp.badge({
			text: supportText,
			tone: isAvail ? 'ok' : 'neutral'
		})
	])));

	rows.push(renderMetricRow(_('Целевая сеть Wi-Fi'), E('span', {}, [
		_('5 GHz / Гостевая сеть')
	])));

	var writeBtn = xcmp.button({
		text: _('📶 Записать Wi-Fi в NFC'),
		tone: isAvail ? 'primary' : 'ghost',
		disabled: !isAvail,
		onClick: function (ev) {
			if (!confirm(_('Записать текущие параметры Wi-Fi на NFC-метку роутера?'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('writeNfc').then(function () {
				ui.addNotification(null, E('p', {}, [ _('Параметры Wi-Fi успешно записаны на NFC-метку') ]), 'info');
			}).catch(function (err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка записи NFC: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [ writeBtn ]);

	return xcmp.card({
		title: _('NFC-метка / Модуль (Wi-Fi 5 GHz)'),
		subtitle: _('Быстрое подключение смартфонов в одно касание к гостевой или 5 GHz сети'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

function renderUsbPowerCard(info, view) {
	var usb = info.usbPower;
	var isSupported = usb.anyBackendReady;
	var badgeTone = isSupported ? 'ok' : 'neutral';
	var badgeText = isSupported ? _('Поддерживается') : _('Не поддерживается');

	var rows = [];

	rows.push(renderMetricRow(_('Платформа / Модель'), E('span', { 'class': 'font-mono' }, [
		usb.board || _('Не определена')
	])));

	var backendsList = [];
	if (usb.backends.xhciMtk) backendsList.push('xhci-mtk (MediaTek)');
	if (usb.backends.gpioSwitch) backendsList.push('gpio-switch');
	if (usb.backends.uhubctl) backendsList.push('uhubctl');
	if (backendsList.length === 0) backendsList.push(_('нет доступных бэкендов'));

	rows.push(renderMetricRow(_('Аппаратный бэкенд'), E('span', { 'class': 'font-mono muted', 'style': 'font-size: 11px;' }, [
		backendsList.join(', ')
	])));

	rows.push(renderMetricRow(_('Режим автовыбора'), E('span', { 'class': 'font-mono' }, [
		usb.autoSelect || (isSupported ? 'auto' : _('недоступен'))
	])));

	var cycleBtn = xcmp.button({
		text: _('⚡ Перезагрузить USB'),
		tone: isSupported ? 'primary' : 'ghost',
		disabled: !isSupported,
		onClick: function (ev) {
			if (!confirm(_('Отключить питание USB на 8 секунд и подать снова для перезапуска модема?'))) {
				return;
			}
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('usbPowerCycle').then(function () {
				ui.addNotification(null, E('p', {}, [ _('Сброс питания USB успешно выполнен') ]), 'info');
			}).catch(function (err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка USB power-cycle: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var testBtn = xcmp.button({
		text: _('🔍 Тест питания USB'),
		tone: 'secondary',
		disabled: !isSupported,
		onClick: function (ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('usbPowerTest').then(function () {
				ui.addNotification(null, E('p', {}, [ _('Тест питания USB завершён') ]), 'info');
			}).catch(function (err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка теста: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, [ cycleBtn, testBtn ]);

	return xcmp.card({
		title: _('Управление питанием USB'),
		subtitle: _('Аппаратный сброс питания USB-портов для перезагрузки зависших 4G/LTE модемов'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

return baseclass.extend({
	parseReport: parseHardwareReport,

	/**
	 * Главный рендер панели «Оборудование»
	 * @param {Object} opts — { data, view, onRefresh }
	 * @returns {Node}
	 */
	render: function (opts) {
		opts = opts || {};
		var data = opts.data || {};
		var view = opts.view || {};
		var onRefresh = opts.onRefresh;

		var rawText = '';
		if (data.execResult) {
			rawText = data.execResult.stdout || data.execResult.stderr || '';
		}

		var info = parseHardwareReport(rawText);

		var panelView = {
			runSystemAction: function (action, arg, payload) {
				var x = (typeof xui !== 'undefined') ? xui : null;
				if (x && typeof x.runSystemMenuWithOutput === 'function') {
					return x.runSystemMenuWithOutput(action, arg, payload);
				}
				if (view && typeof view.runSystemMenu === 'function') {
					return view.runSystemMenu(action, arg, payload);
				}
				if (x && typeof x.runSystemMenu === 'function') {
					return x.runSystemMenu(action, arg, payload);
				}
				return Promise.reject(new Error('runSystemMenu is not available'));
			}
		};

		var cards = [
			renderWpsButtonCard(info, panelView, onRefresh),
			renderNfcCard(info, panelView),
			renderUsbPowerCard(info, panelView)
		];

		var refreshBtn = xcmp.refreshButton({
			isRefreshing: false,
			onRefresh: function() {
				if (typeof onRefresh === 'function') {
					var res = onRefresh();
					if (loading && res && typeof res.then === 'function') {
						loading.track(refreshBtn, res);
					}
				}
			}
		});

		var actionBar = xcmp.actionBar({
			title: _('Оборудование и периферия'),
			description: _('Управление аппаратными кнопками, NFC-метками и питанием USB'),
			actions: [ refreshBtn ]
		});

		var spoiler = xcmp.terminalSpoiler({
			title: _('Терминал (полный вывод hardwareStatus)'),
			rawText: rawText,
			maxHeight: '250px'
		});

		return E('div', { 'class': 'xfree-dashboard-wrap' }, [
			actionBar,
			E('div', {
				'class': 'xfree-card-grid',
				'style': 'display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 16px;'
			}, cards),
			spoiler
		]);
	}
});
