'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';

/* Состояние матрицы устройств и команды iface-routing.
 * Методы вешаются на прототип xfree-vpn-devicepolicy. */

function escapeId(name) {
	return String(name || '')
		.toLowerCase()
		.replace(/[^a-z0-9_-]+/g, '_')
		.replace(/^_+|_+$/g, '') || 'dev_' + Date.now().toString(36);
}

return baseclass.extend({
	_deviceId: function (name) {
		return escapeId(name);
	},
	mount: function (spec) {
		this._spec = spec || {};
		this._view = spec.view || null;
		this._devices = spec.devices || [];
		this._leases = spec.leases || [];
		this._ifaces = spec.ifaces || [];
		this._loading = !!spec.loading;
		this._scanning = false;
		this._scanScope = spec.scanScope || (typeof window !== 'undefined' && window.localStorage && window.localStorage.getItem('xfree_dp_scan_scope')) || 'lan';
		this._msg = spec.message || '';
		this._msgTone = spec.messageTone || '';
		this._searchFilter = '';

		this._matrixState = {};
		this._matrixInitial = {};
		this._initMatrixState();

		if (!this._devices.length && !this._loading) {
			this.reload();
		} else {
			this.requestPaint();
		}
	},
	_initMatrixState: function () {
		var data = this._buildMatrixData();
		var list = data.list;
		this._matrixState = {};
		this._matrixInitial = {};

		for (var i = 0; i < list.length; i++) {
			var it = list[i];
			var st = {
				target: it.target || 'default',
				zapret: it.zapret || 'auto'
			};
			this._matrixState[it.id] = Object.assign({}, st);
			this._matrixInitial[it.id] = Object.assign({}, st);
		}
	},
	reload: function () {
		if (this._scanning) return Promise.resolve();
		var self = this;
		this._loading = true;
		this._msg = '';
		this._msgTone = '';
		this.requestPaint();

		var scope = this._scanScope || 'lan';
		var leasesArg = 'passive|' + scope;

		return Promise.all([
			xui.runIfaceMenu('devicePolicyList').catch(function () { return ''; }),
			xui.runIfaceMenu('devicePolicyLeases', leasesArg).catch(function () { return ''; }),
			xui.runIfaceMenu('summary').catch(function () { return ''; })
		]).then(function (results) {
			self._devices = xui.parseDevicePolicyList(results[0]);
			self._leases = xui.parseDevicePolicyLeases(results[1]);
			var sum = xui.parseIfaceSummary(results[2]);
			self._ifaces = (sum && Array.isArray(sum.ifaces)) ? sum.ifaces : [];
			self._initMatrixState();
			self._loading = false;
			self.requestPaint();
		}).catch(function (err) {
			self._loading = false;
			self._msg = (err && err.message) || String(err);
			self._msgTone = 'bad';
			self.requestPaint();
		});
	},
	_triggerScan: function () {
		var self = this;
		if (this._scanning) return Promise.resolve();

		this._scanning = true;
		var scope = this._scanScope || 'lan';
		this._msg = '';
		this._msgTone = '';
		this.requestPaint();

		var scanArg = 'active|' + scope;

		return xui.runIfaceMenu('devicePolicyLeases', scanArg).then(function (res) {
			self._scanning = false;
			self._leases = xui.parseDevicePolicyLeases(res);
			self._initMatrixState();
			self._msg = '';
			self._msgTone = '';
			self.requestPaint();
		}).catch(function (err) {
			self._scanning = false;
			var errMsg = (err && err.message) || String(err);
			self._setMsg(_('Ошибка сканирования: %s').format(errMsg), 'bad');
			self.requestPaint();
		});
	},
	_setMsg: function (text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var msgEl = this.querySelector('[data-xfree-dp-msg]');
		if (msgEl) {
			msgEl.className = 'xfree-vpn-msg' + (tone ? ' is-' + tone : '');
			msgEl.textContent = text || '';
		}
	},
	_buildMatrixData: function () {
		var devices = this._devices || [];
		var leases = this._leases || [];
		var list = [];
		var map = {};
		var i;
		var d;
		var l;
		var key;

		// 1. Configured entries from devices.conf
		for (i = 0; i < devices.length; i++) {
			d = devices[i];
			key = d.id || escapeId(d.name || d.ip || d.mac);
			var target = 'default';
			if (d.forceIface) {
				target = 'tunnel:' + d.forceIface;
			} else if (d.skipVpn && d.skipZapret) {
				target = 'wan';
			} else if (d.skipVpn) {
				target = 'wan';
			}

			var zapret = 'auto';
			if (d.forceZapret) {
				zapret = 'force';
			} else if (d.skipZapret) {
				zapret = 'bypass';
			}

			var item = {
				id: key,
				name: d.name || d.ip || d.mac || _('Устройство'),
				ip: d.ip || '',
				mac: d.mac || '',
				comment: d.comment || '',
				target: target,
				zapret: zapret,
				isConfigured: true,
				source: 'profile'
			};
			map[key] = item;
			list.push(item);
		}

		// 2. Discovered network clients (DHCP / ARP)
		for (i = 0; i < leases.length; i++) {
			l = leases[i];
			var lip = l.ip || '';
			var lmac = (l.mac || '').toLowerCase();
			var already = false;

			for (var j = 0; j < list.length; j++) {
				if ((lip && list[j].ip === lip) || (lmac && list[j].mac.toLowerCase() === lmac)) {
					already = true;
					if (!list[j].name && l.hostname) {
						list[j].name = l.hostname;
					}
					break;
				}
			}
			if (already) continue;

			key = escapeId(l.hostname || lip || lmac);
			var leaseItem = {
				id: key,
				name: l.hostname || (lip ? _('Клиент %s').format(lip) : lmac),
				ip: lip,
				mac: l.mac || '',
				comment: '',
				target: 'default',
				zapret: 'auto',
				isConfigured: false,
				source: l.hostname ? 'dhcp' : 'arp'
			};
			map[key] = leaseItem;
			list.push(leaseItem);
		}

		return { list: list, map: map };
	},
	_isDirty: function () {
		if (!this._matrixState || !this._matrixInitial) return false;
		var keys = Object.keys(this._matrixState);
		for (var i = 0; i < keys.length; i++) {
			var k = keys[i];
			var cur = this._matrixState[k];
			var init = this._matrixInitial[k];
			if (!init) {
				if (cur && (cur.target !== 'default' || cur.zapret !== 'auto')) return true;
			} else {
				if (cur.target !== init.target || cur.zapret !== init.zapret) return true;
			}
		}
		return false;
	},
	_getDirtyCount: function () {
		var cnt = 0;
		if (!this._matrixState || !this._matrixInitial) return 0;
		var keys = Object.keys(this._matrixState);
		for (var i = 0; i < keys.length; i++) {
			var k = keys[i];
			var cur = this._matrixState[k];
			var init = this._matrixInitial[k];
			if (!init) {
				if (cur && (cur.target !== 'default' || cur.zapret !== 'auto')) cnt++;
			} else {
				if (cur.target !== init.target || cur.zapret !== init.zapret) cnt++;
			}
		}
		return cnt;
	},
	_resetMatrix: function () {
		this._matrixState = JSON.parse(JSON.stringify(this._matrixInitial || {}));
		this.requestPaint();
	},
	_saveMatrix: function () {
		var self = this;
		var changes = [];
		var data = this._buildMatrixData();
		var list = data.list;

		for (var i = 0; i < list.length; i++) {
			var item = list[i];
			var cur = (self._matrixState && self._matrixState[item.id]) || { target: item.target, zapret: item.zapret };
			var init = (self._matrixInitial && self._matrixInitial[item.id]) || { target: item.target, zapret: item.zapret };

			var isModified = (cur.target !== init.target) || (cur.zapret !== init.zapret);
			if (!isModified) continue;

			// If configured device reset back to default, remove from devices.conf
			if (item.isConfigured && cur.target === 'default' && cur.zapret === 'auto') {
				changes.push([item.id, item.name, item.ip, item.mac, 0, 0, '', '', 0, 'del'].join('|'));
			} else if (cur.target !== 'default' || cur.zapret !== 'auto') {
				var sv = (cur.target === 'wan') ? 1 : 0;
				var sz = (cur.zapret === 'bypass' || cur.target === 'wan') ? 1 : 0;
				var fi = (cur.target.indexOf('tunnel:') === 0) ? cur.target.replace(/^tunnel:/, '') : '';
				var fz = (cur.zapret === 'force') ? 1 : 0;
				changes.push([item.id, item.name, item.ip, item.mac, sv, sz, item.comment || '', fi, fz, 'save'].join('|'));
			}
		}

		if (changes.length === 0) {
			return self._applyRules();
		}

		ui.showModal(_('Применение матрицы маршрутизации'), [
			E('p', { 'class': 'spinning' }, [_('Сохранение конфигурации и применение nftables…')])
		]);

		var bulkArg = changes.join(';');
		return xui.runIfaceMenu('devicePolicySaveBulk', bulkArg).then(function () {
			ui.hideModal();
			self._setMsg(_('Матрица маршрутизации устройств успешно сохранена и применена в nftables.'), 'ok');
			self._matrixState = {};
			self._matrixInitial = {};
			self.reload();
			ui.addNotification(null, E('p', {}, [_('Политики устройств успешно сохранены и применены.')]), 'info');
		}).catch(function (err) {
			ui.hideModal();
			self._setMsg((err && err.message) || String(err), 'bad');
			ui.addNotification(null, E('p', {}, [_('Ошибка сохранения матрицы: %s').format(err && err.message ? err.message : String(err))]), 'error');
		});
	},
	_applyRules: function () {
		var self = this;

		ui.showModal(_('Применение исключений устройств'), [
			E('p', { 'class': 'spinning' }, [_('Применение правил маршрутизации устройств в nftables…')])
		]);

		return xui.runIfaceMenu('devicePolicyApply').then(function (res) {
			ui.hideModal();
			var out = xui.formatExecReport(res);
			self._setMsg(_('Правила исключений успешно применены в nftables.'), 'ok');
			self.reload();
			if (res && res.code === 0) {
				ui.addNotification(null, E('p', {}, [_('Политики устройств успешно применены.')]), 'info');
			} else {
				ui.addNotification(null, E('p', {}, [_('Результат применения: %s').format(out || 'OK')]), 'info');
			}
		}).catch(function (err) {
			ui.hideModal();
			self._setMsg((err && err.message) || String(err), 'bad');
			ui.addNotification(null, E('p', {}, [_('Ошибка применения: %s').format(err && err.message ? err.message : String(err))]), 'error');
		});
	},
	_deleteRule: function (dev) {
		var self = this;
		if (!dev || !dev.id) return;

		var confirmMsg = _('Удалить политику для «%s» (%s)?').format(dev.name, dev.ip || dev.mac || dev.id);

		if (!confirm(confirmMsg))
			return;

		ui.showModal(_('Удаление'), [
			E('p', { 'class': 'spinning' }, [_('Удаление правила…')])
		]);

		xui.runIfaceMenu('devicePolicyDelete', dev.id).then(function () {
			ui.hideModal();
			self._setMsg(_('Правило удалено. Нажмите «⚡ Применить правила» для обновления nftables.'), 'warn');
			self.reload();
		}).catch(function (err) {
			ui.hideModal();
			ui.addNotification(null, E('p', {}, [_('Ошибка удаления: %s').format(err && err.message ? err.message : String(err))]), 'error');
		});
	},
});
