'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.upstreams-util as upstreamsUtil';

return baseclass.extend({
	_showCreateModal: function() {
		var self = this;
		var titleInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'placeholder': _('Мой список доменов'),
			'style': 'width: 100%; margin-bottom: 4px;'
		});

		var slugEl = E('code', {
			'style': 'color: var(--accent); font-weight: 600;'
		}, [ '—' ]);

		var idHint = E('div', {
			'style': 'font-size: 12px; color: var(--muted); margin-bottom: 12px; display: flex; align-items: center; gap: 6px;'
		}, [
			_('Идентификатор источника (id):'),
			slugEl
		]);

		function updateSlug() {
			var raw = String(titleInput.value || '').trim();
			var s = upstreamsUtil.slugify(raw);
			slugEl.textContent = s || '—';
		}

		titleInput.addEventListener('input', updateSlug);

		var descArea = E('textarea', {
			'class': 'cbi-input-textarea',
			'rows': 3,
			'placeholder': _('Пользовательские домены, сервисы и подсети…'),
			'style': 'width: 100%; margin-bottom: 12px;'
		});

		var body = E('div', { 'class': 'xfree-custom-upstream-form' }, [
			E('label', { 'class': 'cbi-input-title' }, [ _('Название источника:') ]),
			titleInput,
			idHint,
			E('label', { 'class': 'cbi-input-title' }, [ _('Описание источника:') ]),
			descArea,
			E('p', { 'class': 'muted', 'style': 'margin-top: 8px; font-size: 12px;' }, [
				'🔒 ' + _('Этот источник создаётся локально на роутере в upstreams/<id>/ и никогда не перезаписывается при обновлении внешних репозиториев. После создания вы сможете добавить в него любые списки (домены, CIDR-префиксы IPv4/IPv6) с разделением по сервисам и категориям.')
			])
		]);

		var xui = self.getXui();
		if (!xui) return;
		xui.openDialog({
			title: '➕ ' + _('Создать пользовательский Upstream'),
			size: 'md',
			body: body,
			actions: [
				{
					label: _('Отмена'),
					variant: 'default',
					close: true
				},
				{
					label: _('Создать'),
					variant: 'primary',
					click: function() {
						var title = String(titleInput.value || '').trim();
						if (!title) {
							ui.addNotification(null, E('p', {}, [ _('Укажите название источника') ]), 'danger');
							titleInput.focus();
							return;
						}

						var name = upstreamsUtil.slugify(title);
						if (!name) {
							ui.addNotification(null, E('p', {}, [ _('Не удалось сформировать идентификатор из названия') ]), 'danger');
							titleInput.focus();
							return;
						}

						var exists = (self._modules || []).some(function(m) {
							return (m && (m.id === name || m.name === name));
						});
						if (exists) {
							ui.addNotification(null, E('p', {}, [ _('Источник с идентификатором «%s» уже существует').format(name) ]), 'danger');
							return;
						}

						var payload = JSON.stringify({
							name: name,
							title: title,
							desc: String(descArea.value || '').trim()
						});

						ui.hideModal();
						xui.runSystemMenu('upstreamsCreateCustom', name, payload).then(function(res) {
							if (res && res.error) {
								ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
								return;
							}
							ui.addNotification(null, E('p', {}, [ _('Источник %s успешно создан!').format(name) ]), 'info');
							self.reload();
						}).catch(function(err) {
							ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
						});
					}
				}
			]
		});
	}
});
