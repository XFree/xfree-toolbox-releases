'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';

function showFileView(options) {
	var xui = options.xui;
	var modalContainer = options.modalContainer;
	var mod = options.mod;
	var modKey = mod.id || mod.name;
	var relPath = options.relPath;
	var readOnly = options.readOnly;
	var isCustom = options.isCustom;
	var onBack = options.onBack || function() {};
	var onReload = options.onReload || function() {};

	modalContainer.replaceChildren(E('div', { 'style': 'text-align: center; padding: 50px;' }, [
		E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка: %s…').format(relPath) ])
	]));

	var fullRel = modKey + '/upstream/' + relPath;
	xui.runSystemMenu('upstreamsGetList', fullRel).then(function(res) {
		if (res && res.error) {
			ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
			onBack();
			return;
		}

		var parts = relPath.split('/');
		var clickedFilename = parts[parts.length - 1];
		var dirpart = parts.length > 1 ? parts.slice(0, -1).join('/') : '';

		var mStem = clickedFilename.match(/^(fqdn|prefixes-ipv4|prefixes-ipv6|prefixes)-(.+)\.lst$/i);
		var stem = mStem ? mStem[2] : clickedFilename.replace(/\.lst$/i, '');
		if (!stem && dirpart) {
			var dParts = dirpart.split('/');
			stem = dParts[dParts.length - 1];
		}
		if (!stem) stem = 'list';

		var canonicalFormats = [
			{ type: 'fqdn', filename: 'fqdn-' + stem + '.lst', label: 'FQDN', icon: '🌐' },
			{ type: 'ipv4', filename: 'prefixes-ipv4-' + stem + '.lst', label: 'IPv4', icon: '🔢' },
			{ type: 'ipv6', filename: 'prefixes-ipv6-' + stem + '.lst', label: 'IPv6', icon: '🔢' }
		];

		var foundMap = {};
		(res.files || []).forEach(function(f) {
			foundMap[f.filename] = f;
		});

		var tabFiles = [];

		canonicalFormats.forEach(function(c) {
			var existing = foundMap[c.filename];
			var fRel = (dirpart ? (dirpart + '/') : '') + c.filename;
			var fPath = modKey + '/upstream/' + fRel;

			if (existing) {
				tabFiles.push({
					path: existing.path || fPath,
					relPath: fRel,
					filename: c.filename,
					type: c.type,
					label: c.label,
					icon: c.icon,
					lines: (typeof existing.lines === 'number') ? existing.lines : (existing.content ? existing.content.trim().split('\n').filter(Boolean).length : 0),
					content: existing.content || '',
					exists: true,
					custom: isCustom ? 1 : (existing.custom || 0)
				});
				delete foundMap[c.filename];
			} else if (isCustom) {
				tabFiles.push({
					path: fPath,
					relPath: fRel,
					filename: c.filename,
					type: c.type,
					label: c.label,
					icon: c.icon,
					lines: 0,
					content: '',
					exists: false,
					custom: 1
				});
			}
		});

		Object.keys(foundMap).forEach(function(fn) {
			var f = foundMap[fn];
			var fRel = (dirpart ? (dirpart + '/') : '') + fn;
			tabFiles.push({
				path: f.path || (modKey + '/upstream/' + fRel),
				relPath: fRel,
				filename: fn,
				type: f.type || 'other',
				label: f.label || fn,
				icon: (f.type === 'fqdn') ? '🌐' : '📄',
				lines: (typeof f.lines === 'number') ? f.lines : (f.content ? f.content.trim().split('\n').filter(Boolean).length : 0),
				content: f.content || '',
				exists: true,
				custom: isCustom ? 1 : (f.custom || 0)
			});
		});

		var activeIdx = 0;
		for (var i = 0; i < tabFiles.length; i++) {
			if (tabFiles[i].filename === clickedFilename) {
				activeIdx = i;
				break;
			}
		}

		var currentWidget = null;
		var widgetHost = E('div', { 'class': 'xfree-list-widget-host' });
		var tabButtons = [];
		var tabsBar = null;

		function updateTabLabel(idx) {
			var f = tabFiles[idx];
			var btn = tabButtons[idx];
			if (!f || !btn) return;
			var lCount = (typeof f.lines === 'number') ? f.lines : 0;
			btn.textContent = (f.icon || '📄') + ' ' + (f.label || f.filename) + ' (' + lCount + ')';
		}

		function switchTab(newIdx) {
			if (newIdx === activeIdx && widgetHost.hasChildNodes()) return;
			if (currentWidget) {
				tabFiles[activeIdx].stagedContent = currentWidget.getText();
			}
			activeIdx = newIdx;
			tabButtons.forEach(function(btn, bIdx) {
				if (bIdx === activeIdx) {
					btn.classList.add('is-active');
					btn.style.background = 'var(--accent, #3b82f6)';
					btn.style.color = '#ffffff';
					btn.style.borderColor = 'var(--accent, #3b82f6)';
				} else {
					btn.classList.remove('is-active');
					btn.style.background = 'var(--panel-2)';
					btn.style.color = 'var(--muted)';
					btn.style.borderColor = 'var(--line)';
				}
			});
			renderActiveTab();
		}

		function renderActiveTab() {
			var file = tabFiles[activeIdx];
			var canEdit = !readOnly && isCustom;
			var activeContent = (file.stagedContent !== undefined) ? file.stagedContent : (file.content || '');

			var hintText = !canEdit ?
				('🔒 ' + _('Предустановленный список: только для чтения. Обновляется автоматически при синхронизации источников.')) :
				(!file.exists ?
					('✏️ ' + _('Новый формат для этой подгруппы: введите записи по одной на строку и нажмите «Сохранить изменения» для создания файла.')) :
					('✏️ ' + _('Пользовательский список: редактируйте записи по одной на строку. Очистите список и сохраните, чтобы удалить файл.'))
				);

			currentWidget = xui.renderFileViewerWidget({
				path: file.relPath,
				filename: file.filename,
				content: activeContent,
				readOnly: !canEdit,
				canEdit: canEdit,
				canDownload: true,
				canCopy: true,
				hint: hintText
			});

			var ta = currentWidget.node.querySelector('textarea');
			if (ta) {
				if (file.type === 'fqdn') {
					ta.placeholder = 'example.com\n*.domain.org\napi.service.net';
				} else if (file.type === 'ipv6') {
					ta.placeholder = '2001:db8::/32\n2606:4700::/32';
				} else {
					ta.placeholder = '1.2.3.4\n192.168.1.0/24\n10.0.0.0/8';
				}
			}

			var bottomBar = E('div', {
				'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line);'
			}, [
				xcmp.button({
					variant: 'vpn',
					primary: true,
					text: '← ' + _('Назад к спискам'),
					style: 'font-size: 13px;',
					onClick: function() {
						onBack();
					}
				}),

				canEdit ? xcmp.button({
					variant: 'vpn',
					primary: true,
					text: '💾 ' + _('Сохранить изменения'),
					style: 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px; font-weight: 600;',
					onClick: function() {
						saveActiveFile();
					}
				}) : ''
			]);

			widgetHost.replaceChildren(currentWidget.node, bottomBar);
		}

		function saveActiveFile() {
			var file = tabFiles[activeIdx];
			var newTxt = currentWidget.getText();
			var trimmed = String(newTxt || '').trim();
			var linesArr = trimmed ? trimmed.split(/\r?\n/).map(function(x) { return x.trim(); }).filter(Boolean) : [];

			if (linesArr.length > 0) {
				var contentToSave = linesArr.join('\n') + '\n';
				xui.runSystemMenu('upstreamsSaveList', file.path, contentToSave).then(function(sRes) {
					if (sRes && sRes.error) {
						ui.addNotification(null, E('p', {}, [ sRes.error ]), 'danger');
						return;
					}
					file.exists = true;
					file.content = contentToSave;
					file.stagedContent = contentToSave;
					file.lines = linesArr.length;
					updateTabLabel(activeIdx);
					renderActiveTab();
					ui.addNotification(null, E('p', {}, [ _('Список «%s» сохранён (%d записей)').format(file.filename, file.lines) ]), 'info');

					if (mod._cachedLists) {
						var found = false;
						for (var k = 0; k < mod._cachedLists.length; k++) {
							if (mod._cachedLists[k].path === file.relPath) {
								mod._cachedLists[k].lines = file.lines;
								found = true;
								break;
							}
						}
						if (!found) {
							mod._cachedLists.push({ path: file.relPath, lines: file.lines });
						}
					}
					onReload();
				}).catch(function(err) {
					ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
				});
			} else {
				if (file.exists) {
					xui.runSystemMenu('upstreamsDeleteList', file.path).then(function(dRes) {
						if (dRes && dRes.error) {
							ui.addNotification(null, E('p', {}, [ dRes.error ]), 'danger');
							return;
						}
						file.exists = false;
						file.content = '';
						file.stagedContent = '';
						file.lines = 0;
						updateTabLabel(activeIdx);
						renderActiveTab();
						ui.addNotification(null, E('p', {}, [ _('Список «%s» очищен и удалён с роутера').format(file.filename) ]), 'info');

						if (mod._cachedLists) {
							mod._cachedLists = mod._cachedLists.filter(function(x) { return x.path !== file.relPath; });
						}
						onReload();
					}).catch(function(err) {
						ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
					});
				} else {
					ui.addNotification(null, E('p', {}, [ _('Список пуст, файл не создан') ]), 'info');
				}
			}
		}

		if (tabFiles.length > 1) {
			tabsBar = E('div', {
				'class': 'xfree-dialog-tabs',
				'style': 'display: flex; gap: 8px; margin-bottom: 14px; border-bottom: 1px solid var(--line); padding-bottom: 8px; flex-wrap: wrap;'
			});
			tabFiles.forEach(function(f, idx) {
				var lCount = (typeof f.lines === 'number') ? f.lines : 0;
				var isActive = (idx === activeIdx);
				var tabBtn = E('button', {
					'class': 'xfree-dialog-tab-btn' + (isActive ? ' is-active' : ''),
					'type': 'button',
					'style': 'cursor: pointer; padding: 6px 14px; font-size: 13px; font-weight: 500; border-radius: 6px; border: 1px solid ' +
						(isActive ? 'var(--accent, #3b82f6)' : 'var(--line)') + '; background: ' +
						(isActive ? 'var(--accent, #3b82f6)' : 'var(--panel-2)') + '; color: ' +
						(isActive ? '#ffffff' : 'var(--muted)') + '; transition: all 0.15s ease;',
					'click': function() {
						switchTab(idx);
					}
				}, [ (f.icon || '📄') + ' ' + (f.label || f.filename) + ' (' + lCount + ')' ]);
				tabButtons.push(tabBtn);
				tabsBar.appendChild(tabBtn);
			});
		}

		renderActiveTab();

		if (tabsBar) {
			modalContainer.replaceChildren(tabsBar, widgetHost);
		} else {
			modalContainer.replaceChildren(widgetHost);
		}
	}).catch(function(err) {
		ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
		onBack();
	});
}

return baseclass.extend({
	showFileView: showFileView
});
