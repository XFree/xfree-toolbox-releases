'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';

/* Таблица матрицы, поиск и нижний тулбар экрана устройств.
 * Бейдж xfree-vpn-badge остаётся сырым. */

return baseclass.extend({
	_renderDeviceMatrix: function (spec) {
		var self = this;
		var allItems = spec.allItems;
		var ifaces = spec.ifaces;
		var isLoading = spec.isLoading;
		var isScanning = spec.isScanning;
		var scanScope = spec.scanScope;
		var isDirty = spec.isDirty;
		var dirtyCount = spec.dirtyCount;
		// 4. Matrix Table Columns
		var headerCols = [
			E('th', { 'class': 'xfree-device-col-device' }, [_('Устройство (Клиент сети)')]),
			E('th', { 'class': 'xfree-device-col-center', 'title': _('Весь трафик клиента напрямую в физический WAN без VPN и Zapret') }, [
				'⚡ ' + _('Прямой WAN')
			]),
			E('th', { 'class': 'xfree-device-col-center', 'title': _('Стандартный маршрут роутера: в туннели идут только ресурсы из списков') }, [
				'🌐 ' + _('По спискам')
			])
		];

		ifaces.forEach(function (t) {
			var tName = t.name || t.id;
			headerCols.push(E('th', { 'class': 'xfree-pbr-col-tunnel xfree-device-col-center', 'title': _('Направить ВЕСЬ трафик клиента принудительно в туннель %s').format(tName) }, [
				E('div', { 'class': 'xfree-pbr-tunnel-th' }, [
					E('span', { 'class': 'xfree-vpn-status-dot is-' + (t.ifaceUp ? 'ok' : 'bad') }),
					E('strong', {}, [tName]),
					t.kind ? E('span', { 'class': 'muted font-mono', 'style': 'font-size: 10px;' }, [' (' + t.kind + ')']) : ''
				])
			]));
		});

		headerCols.push(E('th', { 'class': 'xfree-device-col-zapret xfree-device-col-center', 'title': _('Режим десинхронизации Zapret DPI') }, [_('🛡️ Zapret (DPI)')]));
		headerCols.push(E('th', { 'class': 'xfree-device-col-actions', 'title': _('Действия') }, [_('Действия')]));

		// Filter items by search query if any
		var filterQuery = (this._searchFilter || '').toLowerCase().trim();
		var filteredItems = allItems.filter(function (it) {
			if (!filterQuery) return true;
			return (it.name && it.name.toLowerCase().indexOf(filterQuery) !== -1) ||
				(it.ip && it.ip.indexOf(filterQuery) !== -1) ||
				(it.mac && it.mac.toLowerCase().indexOf(filterQuery) !== -1);
		});

		// 5. Matrix Rows
		var rows = [];
		filteredItems.forEach(function (it) {
			var curSt = (self._matrixState && self._matrixState[it.id]) || { target: it.target, zapret: it.zapret };
			var initSt = (self._matrixInitial && self._matrixInitial[it.id]) || { target: it.target, zapret: it.zapret };
			var isModified = (curSt.target !== initSt.target) || (curSt.zapret !== initSt.zapret);

			var rowCols = [];

			// Device identity
			var subDetail = [];
			if (it.ip) subDetail.push(it.ip);
			if (it.mac) subDetail.push(it.mac);

			rowCols.push(E('td', { 'class': 'xfree-device-cell-device' }, [
				E('div', { 'style': 'display: flex; align-items: center; gap: 6px;' }, [
					E('div', { 'style': 'font-weight: 600;' }, [it.name || it.ip || it.mac]),
					it.isConfigured
						? E('span', { 'class': 'xfree-vpn-badge is-ok font-xs', 'title': _('Правило сохранено в devices.conf') }, ['✓ ' + _('В профиле')])
						: E('span', { 'class': 'xfree-vpn-badge font-xs muted', 'title': _('Обнаружен в локальной сети') }, [it.source === 'dhcp' ? 'DHCP' : 'ARP'])
				]),
				E('div', { 'class': 'font-mono font-xs muted' }, [subDetail.join(' · ') || '—']),
				it.comment ? E('div', { 'class': 'font-xs muted', 'style': 'font-style: italic;' }, [it.comment]) : ''
			]));

			// 1. Direct WAN radio
			var isWan = curSt.target === 'wan';
			var isWanMod = (initSt.target !== 'wan' && isWan) || (initSt.target === 'wan' && !isWan);
			var wanRb = E('input', {
				'type': 'radio',
				'name': 'matrix_target_' + it.id,
				'value': 'wan',
				'checked': isWan ? 'checked' : null,
				'change': function () {
					if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
					self._matrixState[it.id].target = 'wan';
					self._matrixState[it.id].zapret = 'bypass';
					self.requestPaint();
				}
			});
			rowCols.push(E('td', { 'class': 'xfree-device-cell-radio is-wan' + (isWan ? ' is-active' : '') + (isWanMod ? ' is-modified' : '') }, [
				E('label', { 'class': 'xfree-device-radio-wrap', 'title': _('Direct WAN: направить весь трафик мимо VPN и Zapret') }, [
					wanRb,
					E('span', {}, [_('WAN')])
				])
			]));

			// 2. Default (По спискам) radio
			var isDef = curSt.target === 'default';
			var isDefMod = (initSt.target !== 'default' && isDef) || (initSt.target === 'default' && !isDef);
			var defRb = E('input', {
				'type': 'radio',
				'name': 'matrix_target_' + it.id,
				'value': 'default',
				'checked': isDef ? 'checked' : null,
				'change': function () {
					if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
					self._matrixState[it.id].target = 'default';
					self._matrixState[it.id].zapret = 'auto';
					self.requestPaint();
				}
			});
			rowCols.push(E('td', { 'class': 'xfree-device-cell-radio' + (isDef ? ' is-active' : '') + (isDefMod ? ' is-modified' : '') }, [
				E('label', { 'class': 'xfree-device-radio-wrap', 'title': _('По спискам: использовать VPN только для доменов из списков роутера') }, [
					defRb,
					E('span', {}, [_('Списки')])
				])
			]));

			// 3. Tunnels radio columns
			ifaces.forEach(function (t) {
				var tName = t.name || t.id;
				var tVal = 'tunnel:' + tName;
				var isThisT = curSt.target === tVal;
				var isThisTMod = (initSt.target !== tVal && isThisT) || (initSt.target === tVal && !isThisT);

				var tRb = E('input', {
					'type': 'radio',
					'name': 'matrix_target_' + it.id,
					'value': tVal,
					'checked': isThisT ? 'checked' : null,
					'change': function () {
						if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
						self._matrixState[it.id].target = tVal;
						if (self._matrixState[it.id].zapret === 'bypass') {
							self._matrixState[it.id].zapret = 'auto';
						}
						self.requestPaint();
					}
				});

				rowCols.push(E('td', { 'class': 'xfree-device-cell-radio' + (isThisT ? ' is-active' : '') + (isThisTMod ? ' is-modified' : '') }, [
					E('label', { 'class': 'xfree-device-radio-wrap', 'title': _('Принудительно направлять весь трафик в туннель %s').format(tName) }, [
						tRb,
						E('span', {}, [tName])
					])
				]));
			});

			// 4. Zapret selector
			var isZapMod = curSt.zapret !== initSt.zapret;
			var zapSelect = E('select', {
				'class': 'cbi-input-select font-xs' + (isZapMod ? ' is-modified' : ''),
				'style': 'width: 100%; max-width: 135px; height: 26px; padding: 2px 4px; font-size: 11px;',
				'title': _('Политика десинхронизации Zapret'),
				'change': function (ev) {
					if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
					self._matrixState[it.id].zapret = ev.target.value;
					self.requestPaint();
				}
			}, [
				E('option', { 'value': 'auto', 'selected': curSt.zapret === 'auto' ? '' : null }, [_('Авто (списки)')]),
				E('option', { 'value': 'force', 'selected': curSt.zapret === 'force' ? '' : null }, [_('NFQUEUE (Все)')]),
				E('option', { 'value': 'bypass', 'selected': curSt.zapret === 'bypass' ? '' : null }, [_('Обход (Выкл)')])
			]);

			rowCols.push(E('td', { 'class': 'xfree-device-cell-zapret xfree-device-col-center' }, [zapSelect]));

			// 5. Actions column
			var editBtn = xcmp.button({
				variant: 'vpn',
				primary: true,
				style: 'display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; padding: 0 !important; font-size: 13px; border-radius: 6px;',
				title: _('Детальная настройка устройства'),
				ariaLabel: _('Изменить'),
				onClick: function () {
					self._openEditDialog(it.isConfigured ? it : null, {
						name: it.name,
						ip: it.ip,
						mac: it.mac,
						comment: it.comment,
						forceIface: (curSt.target.indexOf('tunnel:') === 0) ? curSt.target.replace(/^tunnel:/, '') : '',
						forceZapret: curSt.zapret === 'force',
						skipVpn: curSt.target === 'wan',
						skipZapret: curSt.zapret === 'bypass' || curSt.target === 'wan'
					});
				}
			});
			editBtn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';

			var resetBtn = xcmp.button({
				variant: 'vpn',
				primary: true,
				style: 'display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; padding: 0 !important; font-size: 13px; border-radius: 6px; color: var(--bad);',
				title: it.isConfigured ? _('Удалить правило из профиля') : _('Сбросить в настройки по умолчанию'),
				ariaLabel: _('Удалить / сбросить'),
				onClick: function () {
					if (it.isConfigured) {
						self._deleteRule(it);
					} else {
						if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
						self._matrixState[it.id].target = 'default';
						self._matrixState[it.id].zapret = 'auto';
						self.requestPaint();
					}
				}
			});
			resetBtn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg>';

			rowCols.push(E('td', { 'class': 'xfree-device-cell-actions' }, [
				editBtn, ' ', resetBtn
			]));

			rows.push(E('tr', { 'class': 'xfree-device-row' + (isModified ? ' is-dirty-row' : '') }, rowCols));
		});

		// 6. Matrix Table
		var matrixTable = E('table', { 'class': 'table xfree-device-matrix' }, [
			E('thead', {}, [
				E('tr', {}, headerCols)
			]),
			E('tbody', {}, rows.length ? rows : [
				E('tr', {}, [
					E('td', { 'colspan': headerCols.length, 'class': 'muted', 'style': 'text-align: center; padding: 20px;' }, [
						_('Устройства не найдены. Нажмите «Сканировать сеть» или добавьте устройство вручную.')
					])
				])
			])
		]);

		var matrixScroll = E('div', { 'class': 'xfree-device-matrix-scroll' }, [ matrixTable ]);

		// 7. Matrix Controls Bar (Search + Scope + Scan)
		var searchInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text font-xs',
			'style': 'height: 30px; min-width: 180px; padding: 2px 8px;',
			'placeholder': _('🔍 Поиск по имени или IP…'),
			'value': this._searchFilter || '',
			'input': function (ev) {
				self._searchFilter = ev.target.value;
				self.requestPaint();
			}
		});

		var scopeSelect = E('select', {
			'class': 'cbi-input-select font-xs',
			'style': 'height: 30px; padding: 2px 8px;',
			'disabled': (isLoading || isScanning) ? true : null,
			'title': _('Область сканирования и отображения клиентов')
		}, [
			E('option', { 'value': 'lan', 'selected': scanScope === 'lan' ? '' : null }, [_('Только LAN-клиенты')]),
			E('option', { 'value': 'all', 'selected': scanScope === 'all' ? '' : null }, [_('Вся сеть (включая WAN)')])
		]);
		scopeSelect.addEventListener('change', function () {
			self._scanScope = scopeSelect.value;
			if (typeof window !== 'undefined' && window.localStorage) {
				window.localStorage.setItem('xfree_dp_scan_scope', self._scanScope);
			}
			self.reload();
		});

		var scanBtn = xcmp.button({
			variant: 'vpn',
			primary: true,
			style: 'height: 30px; display: inline-flex; align-items: center; gap: 6px;',
			disabled: isLoading || isScanning,
			title: _('Запустить активное сканирование (ping sweep + обратный DNS)'),
			onClick: function () { self._triggerScan(); },
			children: [
				E('span', { 'class': isScanning ? 'is-spinning' : '' }, [isScanning ? '⏳' : '🔍']),
				' ' + (isScanning ? _('Сканирование…') : _('Сканировать сеть'))
			]
		});

		var matrixFilterBar = E('div', {
			'style': 'display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 10px;'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
				searchInput,
				scopeSelect,
				scanBtn
			]),
			E('div', { 'class': 'muted font-xs' }, [
				_('Отображается устройств: %d из %d').format(filteredItems.length, allItems.length)
			])
		]);

		// 8. Toolbar
		var statusBadge = isDirty
			? E('span', { 'class': 'xfree-pbr-dirty-hint' }, ['● ' + _('Есть несохранённые изменения: %d').format(dirtyCount)])
			: E('span', { 'class': 'xfree-vpn-badge is-ok font-xs' }, ['✓ ' + _('Настройки сохранены')]);

		var revertBtn = isDirty ? xcmp.button({
			variant: 'vpn',
			style: 'color: var(--muted);',
			title: _('Отменить несохранённые изменения матрицы'),
			text: '🔄 ' + _('Отменить'),
			onClick: function () { self._resetMatrix(); }
		}) : null;

		var mainActionBtn = xcmp.button({
			variant: 'vpn',
			primary: !!isDirty,
			extraClass: 'xfree-pbr-action-btn' + (isDirty ? ' is-dirty' : ''),
			title: isDirty
				? _('Сохранить изменения матрицы и переприменить правила nftables')
				: _('Переприменить текущие правила маршрутизации в nftables'),
			text: isDirty ? ('⚡ ' + _('Сохранить и применить')) : ('⚡ ' + _('Применить правила')),
			onClick: function () {
				if (isDirty) self._saveMatrix();
				else self._applyRules();
			}
		});

		var toolbar = E('div', { 'class': 'xfree-pbr-matrix-toolbar' }, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
				statusBadge
			]),
			E('div', { 'class': 'xfree-pbr-main-ops' }, [
				revertBtn ? revertBtn : '',
				mainActionBtn
			])
		]);
		return E('section', { 'class': 'xfree-vpn-section' }, [
			matrixFilterBar,
			matrixScroll,
			toolbar
		]);
	}
});
