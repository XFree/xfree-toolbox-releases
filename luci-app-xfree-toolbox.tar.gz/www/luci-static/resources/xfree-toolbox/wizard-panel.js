'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-wizard';

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this.requestPaint();
	}

	render() {
		var s = this._spec || {};
		var xui = s.xui;
		var node = s.node;
		var view = s.view;
		var wizardData = s.wizardData || {};
		var sectionId = view && view._xfreeWizardSectionId;
		var leafId = node && node.id;
		var interfaces;
		var activeIface;
		var tabPanes = [];
		var i;

		if (!xui || !node) {
			this.replaceChildren();
			return;
		}

		interfaces = wizardData.interfaces || [];
		view._xfreeWizardInterfaces = interfaces;
		this.className = 'cbi-section';
		this.setAttribute('data-xfree-wizard', node.id);

		if (wizardData.loading) {
			var skelLines = [];
			var wi;
			for (wi = 0; wi < 4; wi++) {
				skelLines.push(E('div', { 'class': 'xfree-skeleton-matrix-row' }, [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: ' + (120 + (wi % 3) * 30) + 'px; height: 14px;' }),
					E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 44px; height: 16px; margin-left: auto;' })
				]));
			}

			this.replaceChildren(
				E('h3', {}, [ node.title || node.id ]),
				E('div', { 'class': 'cbi-section-descr' }, [
					E('span', { 'class': 'spinning' }, [ _('Загрузка списков…') ])
				]),
				E('div', { 'class': 'xfree-matrix-skeleton', 'style': 'margin-top: 10px;' }, skelLines)
			);
			return;
		}

		if (!view._xfreeWizardModels)
			view._xfreeWizardModels = wizardData.models || {};

		if (wizardData.models)
			view._xfreeWizardModels = wizardData.models;

		activeIface = xui.wizardActiveIface(view, wizardData);
		view._xfreeWizardActiveIface = activeIface;

		if (!interfaces.length) {
			var emptyTarget = xui.wizardMeta(node).target;
			var emptyHint = xui.wizardEmptyHint(emptyTarget, wizardData.bootstrapError);

			this.replaceChildren(
				E('h3', {}, [ node.title || node.id ]),
				E('div', { 'class': 'cbi-section-descr' }, [
					(node.cli || '') + ' — ' + emptyHint
				]),
				E('div', { 'class': 'cbi-section-descr' }, [
					xui.wizardEmptyAction(emptyTarget)
				])
			);
			return;
		}

		for (i = 0; i < interfaces.length; i++) {
			(function(row) {
				var id = row.id || row.label || '';
				var title = row.label || id;
				var model = xui.wizardModelForIface(view, id, wizardData);
				var paneBody;

				if (model)
					paneBody = xui.renderWizardListsPane(node, view, id, model);
				else if (id === activeIface && wizardData.modelError)
					paneBody = E('div', { 'class': 'cbi-section-descr' }, [ wizardData.modelError ]);
				else if (id === activeIface)
					paneBody = E('div', { 'class': 'cbi-section-descr' }, [ _('Загрузка списков…') ]);
				else
					paneBody = E('div', { 'class': 'cbi-section-descr' }, [
						_('Переключитесь на вкладку, чтобы загрузить списки.')
					]);

				tabPanes.push(E('div', {
					'data-tab': id,
					'data-iface-id': id,
					'data-tab-title': title,
					'data-tab-active': (id === activeIface) ? 'true' : null
				}, [ paneBody ]));
			})(interfaces[i]);
		}

		view._xfreeWizardReload = function() {
			if (view.mountLeafContent && sectionId)
				view.mountLeafContent(sectionId, {
					id: leafId,
					wizard: {
						interfaces: view._xfreeWizardInterfaces || [],
						models: view._xfreeWizardModels || {}
					}
				});
		};

		this.className = 'cbi-section xfree-wizard-panel';
		this.replaceChildren(
			E('h3', {}, [ node.title || node.id ]),
			E('div', { 'class': 'cbi-section-descr xfree-wizard-panel-head' }, [
				(node.cli || '') + ' — ' + xui.wizardTabsHint(xui.wizardMeta(node).target)
			]),
			E('div', {
				'class': 'xfree-wizard-tab-body',
				'data-xfree-wizard-tab-group': '1'
			}, tabPanes)
		);
	}
});

return baseclass.extend({
	tag: TAG
});
