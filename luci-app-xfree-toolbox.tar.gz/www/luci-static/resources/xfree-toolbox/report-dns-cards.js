'use strict';
'require baseclass';
'require ui';
'require rpc';
'require xfree-toolbox.components as xcmp';

/* Статистика, панель фильтров и карточки секций резолверов DNS.
 * Методы вешаются на прототип xfree-report. */

var callUplinkMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'uplinkMenu',
	params: [ 'action', 'arg', 'settings' ]
});

return baseclass.extend({
	_renderDnsStats: function (parsed, isRunning) {
		var totalSecCount = parsed.sections.length;
		var statusBadge;
		if (isRunning) {
			statusBadge = xcmp.badge({
				variant: 'vpn-status',
				tone: 'warn',
				extraClass: 'spinning',
				text: _('Проверка идёт в фоне…')
			});
		} else if (parsed.stamp) {
			statusBadge = xcmp.badge({
				variant: 'vpn-status',
				tone: 'ok',
				text: '✓ ' + _('Готов') + ' · ' + parsed.stamp
			});
		} else {
			statusBadge = xcmp.badge({
				variant: 'vpn-status',
				tone: 'muted',
				text: _('Нет данных')
			});
		}

		var resultVal;
		if (parsed.totalQueries === 0) {
			resultVal = E('span', { 'class': 'muted' }, [ '—' ]);
		} else if (parsed.totalFail === 0) {
			resultVal = E('span', { 'style': 'color: var(--ok, #16a34a);' }, [
				'✓ ' + parsed.totalOk + '/' + parsed.totalQueries + ' OK'
			]);
		} else {
			resultVal = E('span', { 'style': 'color: var(--bad, #dc2626);' }, [
				'✗ ' + parsed.totalFail + ' ' + _('сбоев') + ' (' + parsed.totalOk + ' OK)'
			]);
		}

		var statsBlock = E('div', { 'class': 'xfree-dns-stats' }, [
			E('div', { 'class': 'xfree-dns-stat-card' }, [
				E('div', { 'class': 'k' }, [ _('Результат') ]),
				E('div', { 'class': 'v' }, [ resultVal ])
			]),
			E('div', { 'class': 'xfree-dns-stat-card' }, [
				E('div', { 'class': 'k' }, [ _('Секции DNS') ]),
				E('div', { 'class': 'v' }, [
					totalSecCount > 0 ? (String(totalSecCount) + ' ' + _('резолверов')) : E('span', { 'class': 'muted' }, [ _('Не проверено') ])
				])
			]),
			E('div', { 'class': 'xfree-dns-stat-card' }, [
				E('div', { 'class': 'k' }, [ _('Основной DNS') ]),
				E('div', { 'class': 'v font-mono', 'style': 'font-size: 13px;' }, [
					parsed.primary || (totalSecCount > 0 ? _('не задан') : E('span', { 'class': 'muted' }, [ '—' ]))
				])
			]),
			E('div', { 'class': 'xfree-dns-stat-card' }, [
				E('div', { 'class': 'k' }, [ _('Задержка') ]),
				E('div', { 'class': 'v' }, [
					parsed.totalQueries > 0
						? String(parsed.minMs) + '–' + String(parsed.maxMs) + ' ms'
						: '—'
				])
			])
		]);

		return {
			statusBadge: statusBadge,
			statsBlock: statsBlock
		};
	},

	_renderDnsToolbar: function (parsed, view, reloadFn, totalSecCount, failSecCount, isRunning) {
		var self = this;

		var updateBtn = E('button', {
			'class': 'btn',
			'type': 'button',
			'click': ui.createHandlerFn(view, function(ev) {
				if (ev) ev.preventDefault();
				if (reloadFn) reloadFn();
			})
		}, [ isRunning ? ('⏳ ' + _('Проверка идёт…')) : ('🔄 ' + _('Запустить проверку')) ]);

		var domainsBtn = E('button', {
			'class': 'ghost',
			'type': 'button',
			'click': function(ev) {
				if (ev) ev.preventDefault();
				self._openDomainDialog();
			}
		}, [ '🌐 ' + _('Настроить домены') ]);

		var testDohBtn = E('button', {
			'class': 'ghost',
			'type': 'button',
			'click': function(ev) {
				if (ev) ev.preventDefault();
				self._openDohDialog();
			}
		}, [ '🔒 ' + _('Тест DoH (A/B)') ]);

		var consoleToggleBtn = E('button', {
			'class': 'ghost',
			'type': 'button',
			'click': function(ev) {
				if (ev) ev.preventDefault();
				self._showConsole = !self._showConsole;
				self.requestPaint();
			}
		}, [ self._showConsole ? ('📋 ' + _('Скрыть лог')) : ('📋 ' + _('Терминал (лог)')) ]);

		var searchInput = E('input', {
			'type': 'text',
			'class': 'xfree-dns-search',
			'placeholder': _('Поиск домена или секции…'),
			'value': self._searchQuery || '',
			'input': function() {
				self._searchQuery = String(this.value || '').toLowerCase().trim();
				self.requestPaint();
			}
		});

		var allFilterBtn = xcmp.button({
			variant: 'vpn',
			primary: self._filterMode === 'all',
			text: _('Все (%d)').format(totalSecCount),
			onClick: function(ev) {
				if (ev) ev.preventDefault();
				self._filterMode = 'all';
				self.requestPaint();
			}
		});

		var failFilterBtn = xcmp.button({
			variant: 'vpn',
			primary: self._filterMode === 'fail',
			style: failSecCount > 0 ? 'color: var(--bad, #dc2626); font-weight: 600;' : '',
			text: _('⚠️ Ошибки (%d)').format(failSecCount),
			onClick: function(ev) {
				if (ev) ev.preventDefault();
				self._filterMode = 'fail';
				self.requestPaint();
			}
		});

		return E('div', { 'class': 'xfree-dns-toolbar' }, [
			E('div', { 'class': 'xfree-dns-actions' }, [
				updateBtn,
				domainsBtn,
				testDohBtn,
				consoleToggleBtn
			]),
			E('div', { 'class': 'xfree-dns-filters' }, [
				searchInput,
				allFilterBtn,
				failFilterBtn
			])
		]);
	},

	_renderDnsSectionCards: function (parsed, view, reloadFn, totalSecCount, isRunning) {
		var self = this;
		var cards = [];
		var query = self._searchQuery;
		var onlyFail = self._filterMode === 'fail';
		var i;
		var j;

		for (i = 0; i < parsed.sections.length; i++) {
			var sec = parsed.sections[i];

			if (onlyFail && sec.failCount === 0)
				continue;

			var secLabelLower = sec.label.toLowerCase();
			var secTargetLower = sec.target.toLowerCase();
			var secMatchesQuery = !query || secLabelLower.indexOf(query) >= 0 || secTargetLower.indexOf(query) >= 0;

			var rows = [];
			for (j = 0; j < sec.hosts.length; j++) {
				var h = sec.hosts[j];
				var hostMatches = !query || secMatchesQuery || h.host.toLowerCase().indexOf(query) >= 0;

				if (!hostMatches)
					continue;
				if (onlyFail && h.ok)
					continue;

				var latClass = h.ms <= 25 ? 'is-fast' : (h.ms <= 100 ? 'is-med' : 'is-slow');
				var statusBadgeEl = h.ok
					? E('span', { 'class': 'xfree-vpn-badge is-ok' }, [ '✓ ' + (h.rcode || 'OK') ])
					: E('span', { 'class': 'xfree-vpn-badge is-bad' }, [ '✗ ' + (h.rcode || 'FAIL') ]);

				rows.push(E('tr', {}, [
					E('td', { 'style': 'font-weight: 600;' }, [ h.host ]),
					E('td', {}, [ statusBadgeEl ]),
					E('td', {}, [
						E('span', { 'class': 'xfree-dns-latency ' + latClass }, [ h.ms + ' ms' ])
					]),
					E('td', { 'class': 'xfree-dns-ip' }, [ h.ip ])
				]));
			}

			if (rows.length === 0 && query && !secMatchesQuery)
				continue;

			var secBadges = [];
			if (sec.isPrimary)
				secBadges.push(xcmp.badge({
					variant: 'vpn-status',
					tone: 'ok',
					text: _('основной'),
					style: 'padding: 1px 6px; font-size: 10px;'
				}));

			if (sec.hosts.length > 0) {
				secBadges.push(E('span', { 'class': 'xfree-vpn-badge' }, [
					'⚡ ' + sec.minMs + '–' + sec.maxMs + ' ms'
				]));
				if (sec.failCount === 0) {
					secBadges.push(E('span', { 'class': 'xfree-vpn-badge is-ok' }, [
						'✓ ' + sec.okCount + '/' + sec.hosts.length + ' OK'
					]));
				} else {
					secBadges.push(E('span', { 'class': 'xfree-vpn-badge is-bad' }, [
						'✗ ' + sec.failCount + ' FAIL (' + sec.okCount + '/' + sec.hosts.length + ')'
					]));
				}
			}

			// Allow setting or clearing primary DNS directly on the card
			if (sec.target && sec.target !== '8.8.8.8#53') {
				(function(s) {
					var pBtn;
					if (s.isPrimary) {
						pBtn = xcmp.button({
							variant: 'vpn',
							style: 'padding: 1px 7px; font-size: 10px; margin-left: auto; border: 1px solid var(--line); border-radius: 4px;',
							title: _('Убрать этот DNS из основных (отключить catch-all редирект dnsmasq)'),
							text: '✕ ' + _('Убрать из основных'),
							onClick: ui.createHandlerFn(view, function(ev) {
								if (ev) ev.preventDefault();
								var btn = ev.target;
								btn.disabled = true;
								btn.textContent = '⏳ ' + _('Снятие…');
								return callUplinkMenu('dnsPrimaryClear', s.target).then(function() {
									if (reloadFn) reloadFn();
								}).catch(function(err) {
									ui.addNotification(null, E('p', [ _('Ошибка: ') + (err.message || err) ]), 'error');
									btn.disabled = false;
									btn.textContent = '✕ ' + _('Убрать из основных');
								});
							})
						});
					} else {
						pBtn = xcmp.button({
							variant: 'vpn',
							primary: true,
							style: 'padding: 1px 7px; font-size: 10px; margin-left: auto; border-radius: 4px;',
							title: _('Сделать этот DNS основным (catch-all для запросов dnsmasq)'),
							text: '★ ' + _('Сделать основным'),
							onClick: ui.createHandlerFn(view, function(ev) {
								if (ev) ev.preventDefault();
								var btn = ev.target;
								btn.disabled = true;
								btn.textContent = '⏳ ' + _('Применение…');
								return callUplinkMenu('dnsPrimarySet', s.target).then(function() {
									if (reloadFn) reloadFn();
								}).catch(function(err) {
									ui.addNotification(null, E('p', [ _('Ошибка: ') + (err.message || err) ]), 'error');
									btn.disabled = false;
									btn.textContent = '★ ' + _('Сделать основным');
								});
							})
						});
					}
					secBadges.push(pBtn);
				})(sec);
			}

			var cardClass = 'xfree-dns-card';
			if (sec.failCount > 0) cardClass += ' is-failed';
			if (sec.isPrimary) cardClass += ' is-primary';

			cards.push(E('div', { 'class': cardClass }, [
				E('div', {
					'class': 'xfree-dns-card-head',
					'style': 'display: flex; flex-direction: column; gap: 6px; border-bottom: 1px solid color-mix(in srgb, var(--line) 40%, transparent); padding-bottom: 8px;'
				}, [
					E('div', {
						'class': 'xfree-dns-card-title',
						'style': 'display: flex; align-items: baseline; justify-content: space-between; gap: 8px; font-size: 13px; min-width: 0;'
					}, [
						E('strong', {
							'title': sec.label,
							'style': 'overflow: hidden; text-overflow: ellipsis; white-space: nowrap;'
						}, [ sec.label ]),
						E('span', {
							'class': 'muted font-mono',
							'style': 'font-size: 11px; flex-shrink: 0;'
						}, [ sec.target ])
					]),
					E('div', {
						'class': 'xfree-dns-card-badges',
						'style': 'display: flex; align-items: center; gap: 6px; flex-wrap: wrap; min-height: 24px; width: 100%;'
					}, secBadges)
				]),
				E('table', { 'class': 'xfree-dns-table' }, [
					E('thead', {}, [
						E('tr', {}, [
							E('th', {}, [ _('Домен') ]),
							E('th', {}, [ _('Статус') ]),
							E('th', {}, [ _('Задержка') ]),
							E('th', {}, [ _('A-запись (IP)') ])
						])
					]),
					E('tbody', {}, rows.length ? rows : [
						E('tr', {}, [
							E('td', { 'colspan': '4', 'class': 'muted', 'style': 'text-align: center; padding: 12px;' }, [
								_('Нет записей, соответствующих фильтру')
							])
						])
					])
				])
			]));
		}

		if (cards.length === 0) {
			if (totalSecCount === 0) {
				cards.push(E('div', { 'class': 'panel-block xfree-empty-state', 'style': 'text-align: center; padding: 48px 24px;' }, [
					E('div', { 'style': 'font-size: 38px; margin-bottom: 12px;' }, [ '🌐' ]),
					E('h4', { 'style': 'margin: 0 0 8px; font-size: 16px; font-weight: 650; color: var(--text);' }, [
						_('Диагностика DNS ещё не выполнялась')
					]),
					E('p', { 'class': 'muted', 'style': 'max-width: 520px; margin: 0 auto 20px; line-height: 1.5; font-size: 13.5px;' }, [
						_('Тестирование задержки и резолверов (Яндекс, Cloudflare, Google, AdGuard и др.) выполняется в фоновом режиме. Нажмите кнопку ниже для запуска проверки.')
					]),
					E('button', {
						'class': 'btn btn-primary',
						'type': 'button',
						'style': 'min-width: 220px; margin: 0 auto;',
						'click': ui.createHandlerFn(view, function(ev) {
							if (ev) ev.preventDefault();
							if (reloadFn) reloadFn();
						})
					}, [ isRunning ? ('⏳ ' + _('Проверка идёт…')) : ('🔄 ' + _('Запустить проверку DNS')) ])
				]));
			} else {
				cards.push(E('div', { 'class': 'panel-block', 'style': 'text-align: center; padding: 32px; color: var(--muted);' }, [
					_('Нет секций DNS, соответствующих выбранным критериям поиска')
				]));
			}
		}

		return E('div', { 'class': 'xfree-dns-cards' }, cards);
	}
});
