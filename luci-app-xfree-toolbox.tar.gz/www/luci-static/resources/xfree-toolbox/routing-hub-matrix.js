'use strict';
'require baseclass';
'require ui';

/* Таблица матрицы маршрутизации и привязка событий сортировки/фильтрации.
 * Методы вешаются на прототип xfree-routing. */

function kindLabel(target) {
	switch (target) {
	case 'wan6':
		return _('WAN6');
	case 'dns':
		return _('DNS');
	case 'zapret':
		return _('Zapret');
	default:
		return _('VPN');
	}
}

return baseclass.extend({
	_renderMatrix: function () {
		var self = this;
		var xui = this._xui();
		var view = this._view();
		var hub = this._hub();
		var cols = this._filteredCols(hub);
		var checkedMap = hub.checked || {};
		var rows = this._matrixRows(hub);
		var head = [ E('th', { 'class': 'th xfree-routing-matrix-name' }, [ _('Имя') ]) ];
		var body = [];
		var pane;
		var i;
		var r;
		var title;
		var meta;

		if (hub.loading) {
			var skeletonRows = [];
			var si;
			for (si = 0; si < 6; si++) {
				skeletonRows.push(E('div', { 'class': 'xfree-skeleton-matrix-row' }, [
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: ' + (100 + (si % 3) * 40) + 'px; height: 14px;' }),
					E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 48px; height: 16px; margin-left: auto;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 20px; height: 16px; border-radius: 4px;' }),
					E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 20px; height: 16px; border-radius: 4px;' })
				]));
			}

			return E('div', {
				'class': 'cbi-section-node xfree-wizard-pane xfree-routing-matrix-pane',
				'data-xfree-routing-matrix': '1'
			}, [
				E('div', { 'class': 'cbi-section-descr xfree-wizard-pane-head' }, [
					E('div', {}, [ self._matrixDescr(self._activeTarget || self._selTarget()) ]),
					E('div', { 'class': 'cbi-value xfree-list-filter-bar' }, [
						E('div', { 'class': 'xfree-list-filter-wrap' }, [
							E('input', {
								'type': 'search',
								'class': 'cbi-input-text xfree-list-filter',
								'placeholder': _('Найти сервис, группу или источник…'),
								'disabled': true
							})
						])
					]),
					E('div', {
						'class': 'cbi-value-description',
						'data-xfree-list-count': '1'
					}, [
						E('span', { 'class': 'spinning' }, [ _('Загрузка списков…') ])
					])
				]),
				E('div', { 'class': 'xfree-wizard-pane-scroll xfree-routing-matrix-scroll' }, [
					E('div', { 'class': 'xfree-matrix-skeleton' }, skeletonRows)
				])
			]);
		}

		if (!cols.length) {
			return E('div', { 'class': 'cbi-section-descr' }, [
				_('Нет VPN / DNS / секций Zapret для выбора списков.')
			]);
		}

		var selScope = this._selScope();

		for (i = 0; i < cols.length; i++) {
			var colCount = (checkedMap[cols[i].key] || []).length;
			var emptyColClass = colCount === 0 ? ' is-empty-col' : '';
			var isSelectedCol = selScope && (cols[i].scope === selScope || cols[i].key === selScope || cols[i].key === 'iface:' + selScope || cols[i].key === 'vpn:' + selScope);
			var selColClass = isSelectedCol ? ' is-selected-col' : '';

			head.push(E('th', {
				'class': 'th xfree-routing-matrix-col is-' + cols[i].target + emptyColClass + selColClass,
				'title': kindLabel(cols[i].target) + ' · ' + (cols[i].label || cols[i].scope) +
					(colCount > 0 ? ' (' + colCount + ')' : '')
			}, [
				E('span', { 'class': 'xfree-routing-matrix-kind' }, [ kindLabel(cols[i].target) ]),
				E('span', { 'class': 'xfree-routing-matrix-scope' }, [ cols[i].label || cols[i].scope ])
			]));
		}

		for (i = 0; i < rows.length; i++) {
			r = rows[i];
			title = xui.listItemTitle(r.item);
			meta = xui.listItemMeta(r.item);
			(function(rowTag, rowTitle, rowItem, rowChecked, rowAvailable, rowAnyChecked) {
				var rowCells = [
					E('td', { 'class': 'td xfree-routing-matrix-name' }, [
						E('div', { 'class': 'xfree-list-tile-title' }, [
							E('a', {
								'href': '#',
								'class': 'xfree-list-tile-name is-clickable',
								'title': _('Просмотреть содержимое списка'),
								'style': 'cursor: pointer; text-decoration: underline dotted; font-weight: 500;',
								'click': function(ev) {
									ev.preventDefault();
									xui.showListDialog(rowTag, rowTitle);
								}
							}, [ rowTitle ]),
							(function() {
								var vBtn = E('button', {
									'type': 'button',
									'class': 'xfree-list-view-btn',
									'title': _('Просмотреть список'),
									'click': function(ev) {
										ev.preventDefault();
										ev.stopPropagation();
										xui.showListDialog(rowTag, rowTitle);
									}
								});
								vBtn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
								return vBtn;
							})(),
							rowItem.source ? E('span', {
								'class': 'xfree-matrix-source-badge',
								'title': _('Источник (upstream): ') + rowItem.source
							}, [ rowItem.source ]) : ''
						]),
						meta ? E('div', { 'class': 'cbi-value-description' }, [ meta ]) : ''
					])
				];
				cols.forEach(function(col) {
					var avail = !!rowAvailable[col.key];
					var checked = !!rowChecked[col.key];
					var isSelectedCol = selScope && (col.scope === selScope || col.key === selScope || col.key === 'iface:' + selScope || col.key === 'vpn:' + selScope);
					var selTdClass = isSelectedCol ? ' is-selected-col' : '';
					var inputId = 'xfree-mx-' + col.key + '-' +
						String(rowTag).replace(/[^a-zA-Z0-9_-]/g, '_');

					rowCells.push(E('td', {
						'class': 'td xfree-routing-matrix-cb is-' + col.target +
							(avail ? '' : ' is-na') + selTdClass
					}, [
						avail
							? E('input', {
								'type': 'checkbox',
								'id': inputId,
								'data-matrix-tag': rowTag,
								'data-matrix-col': col.key,
								'data-matrix-target': col.target,
								'data-matrix-scope': col.scope,
								'checked': checked ? true : null,
								'click': function(ev) {
									var isChk = ev.target.checked;
									var t = ev.target.getAttribute('data-matrix-tag') || rowTag;
									var h = self._hub();
									if (!h.checked) h.checked = {};
									if (!h.checked[col.key]) h.checked[col.key] = [];
									var arr = h.checked[col.key];
									var idx = arr.indexOf(t);
									if (isChk && idx === -1) arr.push(t);
									else if (!isChk && idx !== -1) arr.splice(idx, 1);

									// Если включаем туннель VPN (target === 'iface' или 'vpn') в обычном режиме,
									// автоматически снимаем отметку с других туннелей VPN в этой строке.
									// В режиме исключений можно исключить список сразу из нескольких VPN.
									var isExcludeMode = !!(self._isExclude || self._selTarget() === 'exclude' || col.mode === 'exclude');
									if (isChk && !isExcludeMode && (col.target === 'iface' || col.target === 'vpn')) {
										var tr = ev.target.closest('tr');
										if (tr) {
											tr.querySelectorAll('input[data-matrix-tag]').forEach(function(otherInput) {
												if (otherInput === ev.target) return;
												var oTgt = otherInput.getAttribute('data-matrix-target');
												if (oTgt === 'iface' || oTgt === 'vpn') {
													if (otherInput.checked) {
														otherInput.checked = false;
														var oKey = otherInput.getAttribute('data-matrix-col');
														if (oKey && h.checked[oKey]) {
															var oIdx = h.checked[oKey].indexOf(t);
															if (oIdx !== -1) h.checked[oKey].splice(oIdx, 1);
														}
													}
												}
											});
										}
									}
								}
							})
							: E('span', {
								'class': 'xfree-routing-matrix-na',
								'title': _('Список недоступен для этой цели')
							}, [ '—' ])
					]));
				});
				body.push(E('tr', {
					'class': 'tr' + (rowAnyChecked ? ' is-selected-row' : ''),
					'data-xfree-list-row': '1',
					'data-xfree-haystack': xui.listItemHaystack(rowItem)
				}, rowCells));
			})(r.tag, title, r.item, r.checked, r.available, r.anyChecked);
		}

		pane = E('div', {
			'class': 'cbi-section-node xfree-wizard-pane xfree-routing-matrix-pane',
			'data-xfree-routing-matrix': '1'
		}, [
			E('div', { 'class': 'cbi-section-descr xfree-wizard-pane-head' }, [
				E('div', {}, [
					self._matrixDescr(self._activeTarget || self._selTarget())
				]),
				E('div', { 'class': 'cbi-value xfree-list-filter-bar' }, [
					E('div', { 'class': 'xfree-list-filter-wrap' }, [
						E('input', {
							'type': 'search',
							'class': 'cbi-input-text xfree-list-filter',
							'placeholder': _('Найти сервис, группу или источник…'),
							'data-xfree-list-filter': '1'
						})
					])
				]),
				E('div', {
					'class': 'cbi-value-description',
					'data-xfree-list-count': '1'
				}, [ '' ])
			]),
			E('div', { 'class': 'xfree-wizard-pane-scroll xfree-routing-matrix-scroll' }, [
				E('table', { 'class': 'table cbi-section-table xfree-routing-matrix' }, [
					E('thead', {}, [ E('tr', { 'class': 'tr' }, head) ]),
					E('tbody', {}, body)
				])
			]),
			E('div', { 'class': 'xfree-wizard-pane-footer' }, [
				E('div', { 'class': 'cbi-page-actions right' }, [
					E('button', {
						'class': 'btn btn-primary cbi-button cbi-button-save is-primary',
						'click': ui.createHandlerFn(view, function() {
							self._saveMatrix();
						})
					}, [ _('Сохранить выбор') ]),
					E('button', {
						'class': 'btn btn-primary cbi-button cbi-button-apply important',
						'click': ui.createHandlerFn(view, function() {
							self._applyMatrix();
						})
					}, [ _('Применить') ])
				]),
				E('div', {
					'class': 'cbi-section-descr xfree-wizard-status',
					'data-routing-status': '1'
				}, [ hub.statusText || '' ])
			])
		]);

		requestAnimationFrame(function() {
			xui.bindListPickerFilter(pane);
			self._bindMatrixResort(pane);
		});

		return pane;
	},

	_bindMatrixResort: function (pane) {
		var tbody;

		if (!pane || pane.getAttribute('data-xfree-matrix-bound') === 'true')
			return;

		tbody = pane.querySelector('tbody');
		if (!tbody)
			return;

		pane.querySelectorAll('input[data-matrix-tag]').forEach(function(cb) {
			cb.addEventListener('change', function() {
				var row = cb.closest('tr');
				var any = false;

				if (!row)
					return;
				row.querySelectorAll('input[data-matrix-tag]').forEach(function(el) {
					if (el.checked)
						any = true;
				});
				if (any)
					row.classList.add('is-selected-row');
				else
					row.classList.remove('is-selected-row');
			});
		});

		pane.setAttribute('data-xfree-matrix-bound', 'true');
	}
});
