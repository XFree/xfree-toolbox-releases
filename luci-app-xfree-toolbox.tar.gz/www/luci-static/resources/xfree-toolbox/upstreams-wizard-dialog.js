'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.upstreams-combobox as upstreamsCombobox';
'require xfree-toolbox.upstreams-analysis as upstreamsAnalysis';
'require xfree-toolbox.upstreams-wizard-quickpick as upstreamsWizardQuickpick';

function showCreateView(options) {
	var xui = options.xui;
	var modalContainer = options.modalContainer;
	var mod = options.mod;
	var modKey = mod.id || mod.name;
	var initialParams = options.initialParams || {};
	var onBack = options.onBack || function() {};
	var onReload = options.onReload || function() {};
	var onShowFileView = options.onShowFileView || function() {};

	var initGroup = initialParams.group || '';
	var initService = initialParams.service || '';
	var initType = initialParams.type || 'fqdn';
	var initStem = initialParams.stem || '';

	var analysis = upstreamsAnalysis.analyzeModuleLists(mod._cachedLists || []);

	if (!initGroup) {
		var existingGroupKeys = Object.keys(analysis.groups);
		initGroup = existingGroupKeys.length > 0 ? existingGroupKeys[0] : 'custom';
	}

	var groupCombobox = upstreamsCombobox.createCombobox({
		placeholder: 'custom',
		value: initGroup,
		options: upstreamsAnalysis.buildGroupOptions(analysis),
		onChange: function(newGroup) {
			var gClean = String(newGroup || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
			serviceCombobox.setOptions(upstreamsAnalysis.buildServiceOptions(analysis, gClean));
			stemCombobox.setOptions(upstreamsAnalysis.buildStemOptions(analysis, gClean, serviceCombobox.getValue()));
			updatePreview();
		}
	});

	var serviceCombobox = upstreamsCombobox.createCombobox({
		placeholder: _('myservice (необязательно)'),
		value: initService,
		options: upstreamsAnalysis.buildServiceOptions(analysis, initGroup),
		onChange: function(newService) {
			var gClean = String(groupCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
			var sClean = String(newService || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
			stemCombobox.setOptions(upstreamsAnalysis.buildStemOptions(analysis, gClean, sClean));
			if (!stemCombobox.getValue() || stemCombobox.getValue() === gClean) {
				stemCombobox.setValue(sClean || gClean);
			}

			// Smart type auto-selection
			var grpObj = analysis.groups[gClean];
			if (grpObj) {
				var fList = sClean ?
					(grpObj.services[sClean] ? grpObj.services[sClean].files : []) :
					grpObj.files.filter(function(f) { return !f.service; });
				var hasFqdn = fList.some(function(f) { return f.type === 'fqdn'; });
				var hasIpv4 = fList.some(function(f) { return f.type === 'ipv4' || f.type === 'prefix'; });
				if (hasFqdn && !hasIpv4 && typeSelect.value === 'fqdn') {
					typeSelect.value = 'ipv4';
				} else if (hasIpv4 && !hasFqdn && typeSelect.value === 'ipv4') {
					typeSelect.value = 'fqdn';
				}
			}

			updatePreview();
		}
	});

	var defaultInitStem = initStem || initService || initGroup || 'custom';
	var stemCombobox = upstreamsCombobox.createCombobox({
		placeholder: 'my-list',
		value: defaultInitStem,
		options: upstreamsAnalysis.buildStemOptions(analysis, initGroup, initService),
		onChange: function() {
			updatePreview();
		}
	});

	var typeSelect = E('select', {
		'class': 'cbi-input-select',
		'style': 'width: 100%; margin-bottom: 6px;'
	}, [
		E('option', { 'value': 'fqdn' }, [ '🌐 ' + _('FQDN домены (fqdn-<stem>.lst)') ]),
		E('option', { 'value': 'ipv4' }, [ '📑 ' + _('IPv4 префиксы CIDR (prefixes-ipv4-<stem>.lst)') ]),
		E('option', { 'value': 'prefix' }, [ '📑 ' + _('CIDR префиксы общие (prefixes-<stem>.lst)') ]),
		E('option', { 'value': 'ipv6' }, [ '📑 ' + _('IPv6 префиксы CIDR (prefixes-ipv6-<stem>.lst)') ])
	]);
	typeSelect.value = initType;

	var typePills = E('div', {
		'style': 'display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 10px 0; align-items: center;'
	}, [
		E('span', { 'class': 'muted', 'style': 'font-size: 11px;' }, [ _('Быстрый выбор типа:') ]),
		xcmp.button({
			variant: 'vpn',
			primary: true,
			text: '🌐 fqdn',
			style: 'font-size: 11px; padding: 2px 8px;',
			onClick: function() { typeSelect.value = 'fqdn'; updatePreview(); }
		}),
		xcmp.button({
			variant: 'vpn',
			primary: true,
			text: '📑 prefixes-ipv4',
			style: 'font-size: 11px; padding: 2px 8px;',
			onClick: function() { typeSelect.value = 'ipv4'; updatePreview(); }
		}),
		xcmp.button({
			variant: 'vpn',
			primary: true,
			text: '📑 prefixes',
			style: 'font-size: 11px; padding: 2px 8px;',
			onClick: function() { typeSelect.value = 'prefix'; updatePreview(); }
		}),
		xcmp.button({
			variant: 'vpn',
			primary: true,
			text: '📑 prefixes-ipv6',
			style: 'font-size: 11px; padding: 2px 8px;',
			onClick: function() { typeSelect.value = 'ipv6'; updatePreview(); }
		})
	]);

	var previewEl = E('code', {
		'style': 'display: block; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 6px; margin: 6px 0 8px 0; font-size: 13px; color: var(--ok); word-break: break-all; font-family: monospace;'
	}, [ '—' ]);

	var statusContainer = E('div', {
		'style': 'margin-bottom: 12px;'
	});

	var contentLabel = E('label', { 'class': 'cbi-input-title' }, [
		_('5. Начальные записи:')
	]);

	var contentArea = E('textarea', {
		'class': 'cbi-input-textarea',
		'rows': 8,
		'placeholder': 'example.com\n*.domain.org\napi.service.net',
		'style': 'width: 100%; font-family: monospace; font-size: 13px;'
	});

	var createBtn = xcmp.button({
		variant: 'vpn',
		primary: true,
		text: '➕ ' + _('Создать список'),
		style: 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px; font-weight: 600;'
	});

	function updatePreview() {
		var g = String(groupCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
		var s = String(serviceCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
		var n = String(stemCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
		var t = typeSelect.value || 'fqdn';

		var defaultStem = s || g || 'custom';
		var stem = n || defaultStem;

		var fname = (t === 'ipv4') ? ('prefixes-ipv4-' + stem + '.lst') :
			((t === 'ipv6') ? ('prefixes-ipv6-' + stem + '.lst') :
			((t === 'prefix') ? ('prefixes-' + stem + '.lst') : ('fqdn-' + stem + '.lst')));

		var relPath = (g || 'group') + '/' + (s ? (s + '/') : '') + fname;
		var fullPath = modKey + '/upstream/' + relPath;

		previewEl.textContent = fullPath;

		if (t === 'fqdn') {
			contentLabel.textContent = _('5. Начальные FQDN домены (по одному на строку):');
			contentArea.placeholder = 'example.com\n*.domain.org\napi.service.net';
		} else if (t === 'ipv6') {
			contentLabel.textContent = _('5. Начальные IPv6 CIDR префиксы (по одному на строку):');
			contentArea.placeholder = '2001:db8::/32\n2606:4700::/32';
		} else {
			contentLabel.textContent = _('5. Начальные IP-адреса и подсети CIDR (по одному на строку):');
			contentArea.placeholder = '1.2.3.4\n192.168.1.0/24\n10.0.0.0/8';
		}

		var existing = (mod._cachedLists || []).find(function(item) {
			return item && item.path === relPath;
		});

		var folderFiles = (mod._cachedLists || []).filter(function(item) {
			if (!item || !item.path) return false;
			var parts = item.path.split('/');
			if (s) {
				return parts.length === 3 && parts[0] === g && parts[1] === s;
			} else {
				return parts.length === 2 && parts[0] === g;
			}
		});

		var statusElements = upstreamsWizardQuickpick.buildFolderStatus({
			fname: fname,
			relPath: relPath,
			g: g,
			s: s,
			existing: existing,
			folderFiles: folderFiles,
			createBtn: createBtn,
			onShowFileView: onShowFileView
		});

		statusContainer.replaceChildren.apply(statusContainer, statusElements);
	}

	typeSelect.addEventListener('change', updatePreview);

	createBtn.addEventListener('click', function() {
		var g = String(groupCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
		var s = String(serviceCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
		var n = String(stemCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
		var t = typeSelect.value || 'fqdn';

		if (!g) {
			ui.addNotification(null, E('p', {}, [ _('Укажите название группы') ]), 'danger');
			groupCombobox.focus();
			return;
		}
		var stem = n || s || g;
		if (!stem) {
			ui.addNotification(null, E('p', {}, [ _('Укажите имя списка') ]), 'danger');
			stemCombobox.focus();
			return;
		}

		var payload = JSON.stringify({
			module: modKey,
			group: g,
			service: s,
			type: t,
			name: stem,
			content: String(contentArea.value || '').trim()
		});

		createBtn.disabled = true;
		createBtn.textContent = '⏳ ' + _('Создание…');

		xui.runSystemMenu('upstreamsCreateList', modKey, payload).then(function(res) {
			if (res && res.error) {
				ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
				createBtn.disabled = false;
				createBtn.textContent = '➕ ' + _('Создать список');
				return;
			}
			ui.addNotification(null, E('p', {}, [ _('Список успешно создан: %s').format(res.path || stem) ]), 'info');
			onReload(true);
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
			createBtn.disabled = false;
			createBtn.textContent = '➕ ' + _('Создать список');
		});
	});

	var quickPickSection = upstreamsWizardQuickpick.buildQuickPickSection({
		analysis: analysis,
		groupCombobox: groupCombobox,
		serviceCombobox: serviceCombobox,
		stemCombobox: stemCombobox,
		typeSelect: typeSelect,
		updatePreview: updatePreview,
		contentArea: contentArea
	});

	var formChildren = [
		E('div', {
			'style': 'margin-bottom: 12px; padding: 8px 12px; background: var(--panel-2); border-radius: 6px; font-size: 12px; color: var(--muted);'
		}, [
			'💡 ' + _('Списки организуются по канонической структуре: группа, сервис и файл с явным префиксом (fqdn-* или prefixes-*). Выберите существующую категорию/сервис из выпадающего списка или введите собственное название.')
		])
	];

	if (quickPickSection) {
		formChildren.push(quickPickSection);
	}

	formChildren.push(
		E('label', { 'class': 'cbi-input-title' }, [ _('1. Группа (категория):') ]),
		groupCombobox.node,
		E('div', { 'style': 'font-size: 11px; color: var(--muted); margin-bottom: 10px;' }, [
			'💡 ' + _('Выберите из существующих в этом источнике, стандартных (custom, ai, video…) или введите своё')
		]),

		E('label', { 'class': 'cbi-input-title' }, [ _('2. Сервис / подгруппа (необязательно, можно оставить пустым):') ]),
		serviceCombobox.node,
		E('div', { 'style': 'font-size: 11px; color: var(--muted); margin-bottom: 10px;' }, [
			'💡 ' + _('Выберите сервис из группы, популярный (youtube, telegram…) или введите своё название')
		]),

		E('label', { 'class': 'cbi-input-title' }, [ _('3. Тип записей списка:') ]),
		typeSelect,
		typePills,

		E('label', { 'class': 'cbi-input-title' }, [ _('4. Имя списка (stem):') ]),
		stemCombobox.node,
		E('div', { 'style': 'font-size: 11px; color: var(--muted); margin-bottom: 10px;' }, [
			'💡 ' + _('Выберите имя из существующих файлов подгруппы или задайте уникальное имя')
		]),

		E('label', { 'class': 'cbi-input-title' }, [ _('Итоговый путь к файлу:') ]),
		previewEl,
		statusContainer,

		contentLabel,
		contentArea,

		E('div', {
			'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line);'
		}, [
			xcmp.button({
				variant: 'vpn',
				primary: true,
				text: '← ' + _('Назад к спискам'),
				onClick: function() {
					onBack();
				}
			}),
			createBtn
		])
	);

	var form = E('div', { 'class': 'xfree-create-list-form' }, formChildren);
	modalContainer.replaceChildren(form);
	updatePreview();
}

return baseclass.extend({
	showCreateView: showCreateView
});
