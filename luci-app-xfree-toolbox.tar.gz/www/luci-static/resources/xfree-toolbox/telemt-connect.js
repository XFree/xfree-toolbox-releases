'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.core.text-io as textIo';

return baseclass.extend({
	_copyToClipboard: function(text, btn) {
		if (!text) return;
		var originalText = btn.textContent;
		textIo.writeText(text).then(function () {
			btn.textContent = '✓ ' + _('Скопировано!');
			setTimeout(function () { btn.textContent = originalText; }, 2000);
		}, function () {
			ui.addNotification(null, E('p', {}, [ _('Скопируйте ссылку вручную:') + ' ' + text ]));
		});
	},

	_renderConnectSection: function(st) {
		var self = this;
		var tgConnectContent = [];
		var users = (Array.isArray(st.users) && st.users.length > 0) ? st.users : [];
		if (users.length === 0 && (st.tgLink || st.secret)) {
			users = [{
				id: 1,
				name: 'default',
				enabled: true,
				secret: st.secret || '',
				secretMasked: st.secretMasked || '••••••••',
				link: st.tgLink || '',
				comment: ''
			}];
		}

		if (users.length > 0) {
			var tableRows = users.map(function(u) {
				var secDisplay = self._showSecret ? (u.secret || '—') : (u.secretMasked || '••••••••');
				var actionBtns = [];
				if (u.link) {
					actionBtns.push(E('a', {
						'class': 'btn primary',
						'style': 'padding: 4px 10px; font-size: 12px;',
						'href': u.link,
						'title': _('Открыть Telegram и подключить прокси для') + ' ' + u.name
					}, [ '✈️ ' + _('В Telegram') ]));
					actionBtns.push(E('button', {
						'class': 'ghost ghost-compact',
						'type': 'button',
						'title': _('Скопировать ссылку подключения для') + ' ' + u.name,
						'click': function(ev) {
							ev.preventDefault();
							self._copyToClipboard(u.link, this);
						}
					}, [ '📋 ' + _('Скопировать ссылку') ]));
				}

				return E('tr', {}, [
					E('td', { 'style': 'font-weight: 600; vertical-align: middle;' }, [
						'👤 ' + u.name
					]),
					E('td', { 'style': 'vertical-align: middle;' }, [
						E('span', {
							'class': 'xfree-vpn-status is-' + (u.enabled ? 'ok' : 'muted'),
							'style': 'font-size: 11px; padding: 2px 8px;'
						}, [ u.enabled ? _('Активен') : _('Отключен') ])
					]),
					E('td', { 'style': 'font-family: monospace; font-size: 12px; vertical-align: middle;' }, [
						secDisplay
					]),
					E('td', { 'style': 'text-align: right; vertical-align: middle;' }, [
						E('div', { 'style': 'display:inline-flex; gap: 6px; align-items:center;' }, actionBtns)
					])
				]);
			});

			var connectBlock = E('div', { 'style': 'display:flex; flex-direction:column; gap: 12px;' }, [
				E('div', {
					'style': 'display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap: 10px; padding: 10px 14px; background: rgba(0,0,0,0.02); border: 1px solid rgba(0,0,0,0.06); border-radius: 6px; font-size: 12px;'
				}, [
					E('div', { 'style': 'display:flex; gap: 18px; flex-wrap:wrap; align-items:center;' }, [
						E('div', {}, [
							E('span', { 'class': 'muted' }, [ _('Сервер / Хост') + ': ' ]),
							E('strong', {}, [ st.host || '—' ])
						]),
						E('div', {}, [
							E('span', { 'class': 'muted' }, [ _('Порт') + ': ' ]),
							E('strong', {}, [ st.port || '8443' ])
						])
					]),
					(function() {
						var tBtn = E('button', {
							'class': 'btn ghost ghost-compact',
							'style': 'display: inline-flex; align-items: center; gap: 6px; padding: 3px 8px; font-size: 12px; border-radius: 6px;',
							'type': 'button',
							'click': function(ev) {
								ev.preventDefault();
								self._showSecret = !self._showSecret;
								self.requestPaint();
							}
						});
						var svgEye = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
						var svgEyeOff = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>';
						tBtn.innerHTML = (self._showSecret ? svgEyeOff : svgEye) + '<span>' + (self._showSecret ? _('Скрыть секреты') : _('Показать секреты')) + '</span>';
						return tBtn;
					})()
				]),
				E('div', { 'class': 'table-wrapper', 'style': 'overflow-x: auto; border: 1px solid rgba(0,0,0,0.08); border-radius: 6px;' }, [
					E('table', { 'class': 'table', 'style': 'margin: 0; width: 100%;' }, [
						E('thead', {}, [
							E('tr', {}, [
								E('th', {}, [ _('Пользователь') ]),
								E('th', {}, [ _('Статус') ]),
								E('th', {}, [ _('Секрет') ]),
								E('th', { 'style': 'text-align: right;' }, [ _('Подключение к Telegram') ])
							])
						]),
						E('tbody', {}, tableRows)
					])
				]),
				E('div', { 'style': 'display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap: 8px; margin-top: 2px;' }, [
					E('div', { 'class': 'muted', 'style': 'font-size: 11px; line-height: 1.4; max-width: 600px;' }, [
						'💡 ' + _('Один пользователь MTProxy может использоваться на любом количестве устройств одновременно (ПК, смартфон, планшет). Если требуется раздельный учет или отзыв доступа — создавайте отдельных пользователей в LuCI Telemt.')
					]),
					st.luciInstalled ? E('a', {
						'class': 'ghost ghost-compact',
						'href': L.url('admin/services/telemt'),
						'target': '_blank',
						'title': _('Открыть панель LuCI Telemt для создания и удаления пользователей')
					}, [ '⚙️ ' + _('Управление пользователями и QR-коды в LuCI Telemt ↗') ]) : null
				])
			]);

			tgConnectContent.push(connectBlock);
		} else {
			tgConnectContent.push(E('div', { 'class': 'muted', 'style': 'font-size: 13px;' }, [
				st.installed
					? _('Прокси установлен, но пользователи не настроены. Создайте пользователя в /etc/config/telemt или через панель LuCI Telemt.')
					: _('Установите Telemt MTProxy для генерации ссылки подключения в Telegram.')
			]));
		}

		return E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📱 ' + _('Параметры подключения клиентов Telegram') ]),
					E('span', { 'class': 'xfree-vpn-status is-' + ((users.length > 0 && st.tgLink) ? 'ok' : 'muted') }, [
						(users.length > 0 && st.tgLink) ? _('Готов к подключению') : _('Ожидает настройки')
					])
				])
			]),
			E('div', { 'style': 'padding: 12px 14px;' }, tgConnectContent)
		]);
	}
});
