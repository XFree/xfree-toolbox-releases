'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-traffic-map';

var SVG = {
	lan: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="6" y="3" width="12" height="14" rx="1.5"/><path d="M9 21h6M12 17v4"/><circle cx="12" cy="9" r="2"/></svg>',
	router: '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="9" width="20" height="10" rx="2.5"/><path d="M6 9V6.5A2.5 2.5 0 0 1 8.5 4h7A2.5 2.5 0 0 1 18 6.5V9M7 14h.01M12 14h.01M17 14h.01"/><path d="M8 4l-.8-2M16 4l.8-2"/><circle cx="2" cy="14" r="1.2" fill="currentColor" stroke="none"/><circle cx="22" cy="14" r="1.2" fill="currentColor" stroke="none"/></svg>',
	dns: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>',
	vpn: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 5 3.5 8.5 8 9 4.5-.5 8-4 8-9V7z"/><path d="M9 12l2 2 4-4"/></svg>',
	zapret: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 5 3.5 8.5 8 9 4.5-.5 8-4 8-9V7z"/></svg>',
	out: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
	ok: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/></svg>',
	skip: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8 12h8"/></svg>',
	warn: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 2.5 20h19L12 3z"/><path d="M12 9v5M12 17h.01"/></svg>',
	search: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
	spin: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 3a9 9 0 1 1-9 9"/></svg>'
};

function nodeKind(id) {
	if (!id) return '';
	var i = String(id).indexOf(':');
	return i > 0 ? id.slice(0, i) : id;
}

function nodeLabel(id, fallback) {
	if (!id) return fallback || '';
	var i = String(id).indexOf(':');
	return i > 0 ? id.slice(i + 1) : id;
}

function runtimeOk(node) {
	return !node || !node.runtime || node.runtime.ok !== false;
}

/* Monitor palette: ok | warn | fail | unknown (from usb-power-watch). */
function nodeHealth(node) {
	var h;

	if (node && node.runtime && node.runtime.health)
		h = String(node.runtime.health);
	else if (node && node.health)
		h = String(node.health);
	else if (node && node.runtime && node.runtime.ok === false)
		h = 'fail';
	else
		h = 'unknown';

	if (h === 'ok' || h === 'warn' || h === 'fail' || h === 'unknown')
		return h;
	return 'unknown';
}

function healthLabel(h) {
	/* Do not gettext "OK" — LuCI maps it to «Принять». */
	if (h === 'ok')
		return 'OK';
	if (h === 'warn')
		return _('частично');
	if (h === 'fail')
		return 'FAIL';
	return _('нет данных');
}

function channelLabel(wan) {
	var c = wan && wan.channel;
	var ev;

	if (c === 'FULL' || c === 'PARTIAL' || c === 'FAIL')
		return c;
	ev = wan && wan.probeEval != null ? String(wan.probeEval) : '';
	if (ev === '0') return 'FULL';
	if (ev === '1') return 'FAIL';
	if (ev === '2') return 'PARTIAL';
	return '';
}

function probeBitOk(v) {
	return v === 1 || v === '1' || v === true || v === 'ok';
}

/* Click-popover rows for VPN tunnel chips (proton / warp / …). */
function tunnelDetailRows(node) {
	var rt = (node && node.runtime) || {};
	var rows;
	var up;
	var ifaceLabel = '—';
	var hs = rt.monitorHs || '';
	var act = rt.monitorAction || '';
	var line = rt.monitorLine || '';

	up = rt.ifaceUp;
	if (up === true || up === 'true')
		ifaceLabel = 'UP';
	else if (up === false || up === 'false')
		ifaceLabel = 'DOWN';

	rows = [
		{ k: _('статус'), v: healthLabel(nodeHealth(node)) }
	];
	if (line) {
		rows.push({ k: _('probe'), v: line });
	} else {
		rows.push({ k: 'ping', v: rt.monitorPing || '—' });
		rows.push({ k: 'hs', v: hs || '—' });
		rows.push({ k: 'last', v: act || rt.monitorLast || '—' });
	}
	if (rt.protonAuth)
		rows.push({ k: 'proton', v: String(rt.protonAuth) });
	if (rt.protonSess)
		rows.push({ k: 'sess', v: String(rt.protonSess) });
	if (rt.certLocal)
		rows.push({ k: 'cert', v: String(rt.certLocal) });
	rows.push({ k: _('iface'), v: ifaceLabel });
	if (rt.vpnDev)
		rows.push({ k: _('dev'), v: String(rt.vpnDev) });
	rows.push({
		k: _('Runtime'),
		v: runtimeOk(node) ? 'ok' : _('нужен apply / iface down')
	});
	if (rt.detail && !line)
		rows.push({ k: _('деталь'), v: String(rt.detail) });
	return rows;
}

/* DNS tip: last dns-check summary (preferred) + optional trace match. */
function dnsCheckHealth(node) {
	var rt = (node && node.runtime) || {};
	var fail;
	var ok;

	if (rt.checkSummary == null && rt.checkOk == null && rt.checkFail == null)
		return null;
	fail = Number(rt.checkFail);
	ok = Number(rt.checkOk);
	if (fail > 0)
		return 'fail';
	if (ok > 0)
		return 'ok';
	return 'unknown';
}

function dnsDetailRows(node, hit, fqdn) {
	var rt = (node && node.runtime) || {};
	var rows;
	var id = nodeLabel(node && node.id, '') || rt.dnsId || '';
	var hosts;
	var hi;
	var h;
	var ok;

	rows = [
		{ k: _('DNS'), v: id || '—' }
	];
	if (rt.checkSummary) {
		rows.push({ k: _('тест'), v: String(rt.checkSummary) });
		if (rt.checkWhen)
			rows.push({ k: _('когда'), v: String(rt.checkWhen) });
	} else {
		rows.push({ k: _('тест'), v: _('нет данных') });
		rows.push({
			k: _('UCI'),
			v: runtimeOk(node) ? 'ok' : (rt.detail || _('https-dns-proxy пуст'))
		});
	}
	/* Per-host dns-check probes — ✓ / ✗ instead of bare "fail". */
	hosts = Array.isArray(rt.checkHosts) ? rt.checkHosts : [];
	for (hi = 0; hi < hosts.length; hi++) {
		h = hosts[hi] || {};
		if (!h.h)
			continue;
		ok = h.ok === true || h.ok === 1 || h.ok === '1';
		rows.push({
			k: String(h.h),
			v: ok ? '✓' : '✗',
			mark: ok ? 'ok' : 'fail',
			hint: h.rcode ? String(h.rcode) + (h.ms != null ? ' · ' + h.ms + 'ms' : '') : ''
		});
	}
	if (fqdn)
		rows.push({ k: _('Домен'), v: fqdn });
	if (hit && hit.listFile)
		rows.push({ k: _('Список'), v: String(hit.listFile) });
	else if (hit && hit.base)
		rows.push({ k: _('map'), v: String(hit.base) });
	return rows;
}

function zapretDetailRows(node, hit, fqdn) {
	var rows = [
		{ k: _('Секция'), v: nodeLabel(node && node.id, '') || '—' },
		{ k: _('Домен'), v: (hit && hit.base) || fqdn || '—' },
		{ k: _('Стратегия'), v: (hit && hit.strategy) || '—' },
		{ k: _('Runtime'), v: runtimeOk(node) ? 'ok' : _('нужен apply') }
	];
	var rt = (node && node.runtime) || {};

	if (rt.detail)
		rows.push({ k: _('деталь'), v: String(rt.detail) });
	return rows;
}

/* Real wizard scopes only — skip synthetic tip ids (dns:default, …). */
function tipNavScope(id) {
	var kind = nodeKind(id);
	var scope = nodeLabel(id, '');

	if (!scope)
		return '';
	if (kind === 'dns' || kind === 'iface' || kind === 'zapret') {
		if (scope === 'default' || scope === 'skipped')
			return '';
		return scope;
	}
	return '';
}

function iconEl(html, cls) {
	var span = E('span', { 'class': cls || 'tm-ico', 'aria-hidden': 'true' });
	span.innerHTML = html;
	return span;
}

function statusIcon(status, runtimeBad) {
	if (runtimeBad)
		return iconEl(SVG.warn, 'tm-status is-warn');
	if (status === 'match' || status === 'inferred' || status === 'default')
		return iconEl(SVG.ok, 'tm-status is-ok');
	if (status === 'skipped' || status === 'none')
		return iconEl(SVG.skip, 'tm-status is-skip');
	return iconEl(SVG.skip, 'tm-status is-skip');
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._fqdn = this._fqdn || '';
		this._busy = false;
		this._trace = null;
		this._expanded = {};
		this._popover = null;
		this._suggestItems = this._suggestItems || [];
		this._suggestLoaded = !!this._suggestLoaded;
		this._suggestLoading = false;
		this._suggestOpen = !!this._suggestOpen;
		this._suggestActive = this._suggestActive == null ? -1 : this._suggestActive;
		this.requestPaint();
	}

	/* Active FQDNs from iface/dns/zapret generated lists (free text still allowed). */
	_ensureSuggest() {
		var self = this;
		var onSuggest = this._spec && this._spec.onSuggest;

		if (!onSuggest || this._suggestLoaded || this._suggestLoading)
			return;

		this._suggestLoading = true;
		Promise.resolve(onSuggest('')).then(function(res) {
			self._suggestLoading = false;
			self._suggestLoaded = true;
			self._suggestItems = (res && Array.isArray(res.items)) ? res.items : [];
			self._paintSuggest();
		}).catch(function() {
			self._suggestLoading = false;
			self._suggestLoaded = true;
			self._suggestItems = [];
			self._paintSuggest();
		});
	}

	_filteredSuggest(q) {
		var all = this._suggestItems || [];
		var needle = String(q || '').toLowerCase().replace(/^\s+|\s+$/g, '');
		var out = [];
		var i;
		var max = 40;

		for (i = 0; i < all.length && out.length < max; i++) {
			if (!needle || String(all[i]).indexOf(needle) === 0)
				out.push(all[i]);
		}
		return out;
	}

	_openSuggest() {
		this._suggestOpen = true;
		this._suggestActive = -1;
		this._ensureSuggest();
		this._paintSuggest();
	}

	_closeSuggest() {
		this._suggestOpen = false;
		this._suggestActive = -1;
		this._paintSuggest();
	}

	_pickSuggest(value) {
		var input = this.querySelector('.tm-trace-input');
		this._fqdn = value || '';
		if (input)
			input.value = this._fqdn;
		this._closeSuggest();
		this._runTrace();
	}

	/* In-place update — do not requestPaint (would steal focus). */
	_paintSuggest() {
		var box = this.querySelector('.tm-suggest');
		var items;
		var i;
		var row;
		var self = this;

		if (!box)
			return;

		items = this._suggestOpen ? this._filteredSuggest(this._fqdn) : [];
		box.replaceChildren();
		if (!items.length) {
			box.hidden = true;
			box.classList.remove('is-open');
			return;
		}

		for (i = 0; i < items.length; i++) {
			/* plain div — avoid <button> and role=option (LuCI/Bootstrap crush layout) */
			row = E('div', {
				'class': 'tm-suggest-item' + (i === this._suggestActive ? ' is-active' : ''),
				'tabindex': '-1',
				'data-idx': String(i)
			}, [ String(items[i]) ]);
			row.addEventListener('mousedown', function(ev) {
				/* mousedown before blur — keep pick working */
				ev.preventDefault();
			});
			row.addEventListener('click', (function(val) {
				return function(ev) {
					ev.preventDefault();
					self._pickSuggest(val);
				};
			})(items[i]));
			box.appendChild(row);
		}
		box._suggestValues = items;
		box.hidden = false;
		box.classList.add('is-open');
	}

	setSummary(summary) {
		if (!this._spec) this._spec = {};
		this._spec.summary = summary || null;
		this.requestPaint();
	}

	setTrace(trace) {
		this._trace = trace || null;
		this._expanded = {};
		this._popover = null;
		this.requestPaint();
	}

	_layer(id) {
		var layers = (this._trace && this._trace.layers) || [];
		var i;
		for (i = 0; i < layers.length; i++) {
			if (layers[i] && layers[i].id === id)
				return layers[i];
		}
		return null;
	}

	_hl() {
		var out = {};
		var list = (this._trace && this._trace.summary && this._trace.summary.highlight) || [];
		var i;
		for (i = 0; i < list.length; i++) {
			if (list[i]) out[list[i]] = true;
		}
		return out;
	}

	_nav(kind, scopeId) {
		var onNavigate = this._spec && this._spec.onNavigate;
		var scope = scopeId || '';
		/* Close before leaving overview — float popover lives on #xfree-toolbox-shell. */
		this._closeFloatPopover(false);
		if (!onNavigate) return;
		if (kind === 'iface' || kind === 'vpn') onNavigate('routing', 'vpn', scope);
		else if (kind === 'dns') onNavigate('routing', 'dns', scope);
		else if (kind === 'zapret') onNavigate('routing', 'zapret', scope);
		else onNavigate('system');
	}

	_toggleExpand(key) {
		this._expanded[key] = !this._expanded[key];
		this._closeFloatPopover(false);
		this.requestPaint();
	}

	_togglePopover(payload) {
		if (this._popover && this._popover.id === payload.id)
			this._closeFloatPopover(false);
		else
			this._popover = payload;
		this.requestPaint();
	}

	/* Hide/remove shell-hosted popover (survives map re-render / route change). */
	_closeFloatPopover(remove) {
		var el = this._floatPopoverEl;
		var host;
		var nodes;
		var i;

		this._popover = null;
		if (el) {
			el.hidden = true;
			el.classList.remove('is-open');
			el.setAttribute('aria-hidden', 'true');
			if (remove && el.parentNode) {
				el.parentNode.removeChild(el);
				this._floatPopoverEl = null;
			}
		}
		/* Scrub orphans from previous map instances. */
		host = document.getElementById('xfree-toolbox-shell');
		if (host) {
			nodes = host.querySelectorAll('.tm-float-popover');
			for (i = 0; i < nodes.length; i++) {
				if (remove && nodes[i] !== this._floatPopoverEl) {
					if (nodes[i].parentNode)
						nodes[i].parentNode.removeChild(nodes[i]);
					continue;
				}
				nodes[i].hidden = true;
				nodes[i].classList.remove('is-open');
				nodes[i].setAttribute('aria-hidden', 'true');
			}
		}
	}

	disconnectedCallback() {
		if (this._onFloatOutside) {
			document.removeEventListener('pointerdown', this._onFloatOutside, true);
			document.removeEventListener('click', this._onFloatOutside, true);
			this._onFloatOutside = null;
			this._floatPopoverBound = false;
		}
		this._closeFloatPopover(true);
		this._xfreeConnected = false;
	}

	/* Fixed popover outside .tm-flow-scroll — absolute children are clipped by overflow-x. */
	_ensureFloatPopover() {
		var self = this;
		var el = this._floatPopoverEl;
		var host;

		if (el && el.isConnected)
			return el;

		host = document.getElementById('xfree-toolbox-shell') || document.body;
		el = E('div', {
			'class': 'tm-float-popover',
			'hidden': true,
			'role': 'dialog',
			'aria-hidden': 'true'
		});
		host.appendChild(el);
		this._floatPopoverEl = el;

		if (!this._floatPopoverBound) {
			this._floatPopoverBound = true;
			this._onFloatOutside = function(ev) {
				var t;
				if (!self._popover || !self._floatPopoverEl || !self.isConnected)
					return;
				t = ev.target;
				if (self._floatPopoverEl.contains(t))
					return;
				/* Chip click toggles via its own handler — don't steal. */
				if (t && t.closest && t.closest('xfree-traffic-map .tm-chip'))
					return;
				self._closeFloatPopover(false);
				if (self.isConnected)
					self.requestPaint();
			};
			this.addEventListener('scroll', function() {
				self._placeFloatPopover();
			}, true);
			/* Capture: runs before LuCI nav handlers that replace the overview. */
			document.addEventListener('pointerdown', this._onFloatOutside, true);
			document.addEventListener('click', this._onFloatOutside, true);
		}
		return el;
	}

	_placeFloatPopover() {
		var self = this;
		var view = this._spec && this._spec.view;
		var pop = this._popover;
		var el;
		var anchor;
		var kids;
		var dlKids;
		var i;
		var r;
		var tipH;
		var tipW;
		var top;
		var left;
		var gap = 8;
		var navKind;
		var navScope;
		var ctaLabel;
		var idSel;

		if (!pop) {
			this._closeFloatPopover(false);
			return;
		}

		el = this._ensureFloatPopover();

		idSel = String(pop.id || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
		anchor = this.querySelector('[data-chip-id="' + idSel + '"]');

		dlKids = [];
		for (i = 0; i < (pop.rows || []).length; i++) {
			dlKids.push(E('dt', {}, [ pop.rows[i].k ]));
			dlKids.push(E('dd', {
				'class': pop.rows[i].mark
					? ('tm-mark tm-mark-' + String(pop.rows[i].mark))
					: '',
				'title': pop.rows[i].hint || ''
			}, [ pop.rows[i].v ]));
		}

		navKind = pop.navKind || nodeKind(pop.id) || 'system';
		navScope = pop.navScope;
		if (navScope == null)
			navScope = tipNavScope(pop.id);
		ctaLabel = (navKind === 'dns' || navKind === 'vpn' || navKind === 'iface' || navKind === 'zapret')
			? _('Списки')
			: _('Открыть настройки');
		kids = [
			E('p', { 'class': 'tm-popover-title' }, [ pop.title || '' ]),
			E('dl', { 'class': 'tm-popover-dl' }, dlKids),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					self._popover = null;
					self._placeFloatPopover();
					self._nav(navKind, navScope);
				})
			}, [ ctaLabel ])
		];
		el.replaceChildren.apply(el, kids);
		el.hidden = false;
		el.classList.add('is-open');
		el.setAttribute('aria-hidden', 'false');

		if (!anchor) {
			el.style.top = '72px';
			el.style.left = '24px';
			return;
		}

		r = anchor.getBoundingClientRect();
		tipH = el.offsetHeight || 0;
		tipW = el.offsetWidth || 0;
		if (r.bottom + gap + tipH <= window.innerHeight - 4)
			top = r.bottom + gap;
		else
			top = Math.max(4, r.top - gap - tipH);
		left = r.left + (r.width / 2) - (tipW / 2);
		if (left < 4)
			left = 4;
		if (left + tipW > window.innerWidth - 4)
			left = Math.max(4, window.innerWidth - 4 - tipW);

		el.style.top = Math.round(top) + 'px';
		el.style.left = Math.round(left) + 'px';
	}

	_runTrace() {
		var self = this;
		var onTrace = this._spec && this._spec.onTrace;
		var input = this.querySelector('.tm-trace-input');
		var fqdn = (((input && input.value) || this._fqdn || '') + '').trim();

		this._fqdn = fqdn;
		if (!onTrace || !fqdn || this._busy)
			return;

		this._busy = true;
		this._popover = null;
		this.requestPaint();

		Promise.resolve(onTrace(fqdn)).then(function(res) {
			self._busy = false;
			self._trace = res || null;
			self._expanded = {};
			self.requestPaint();
		}).catch(function(err) {
			self._busy = false;
			self._trace = {
				code: 1,
				stderr: (err && err.message) ? err.message : String(err)
			};
			self.requestPaint();
		});
	}

	_hubBtn(kind, title, sub, active) {
		var self = this;
		var view = this._spec && this._spec.view;
		var cls = 'tm-hub-node kind-' + kind + (active ? ' is-active' : '');
		var kids = [
			E('span', { 'class': 'tm-hub-main' }, [
				iconEl(SVG[kind] || SVG.router, 'tm-hub-ico'),
				E('span', { 'class': 'tm-hub-copy' }, [
					E('span', { 'class': 'tm-hub-k' }, [ title ]),
					E('span', { 'class': 'tm-hub-v' }, [ sub ])
				])
			])
		];

		if (kind === 'router') {
			cls += ' is-router';
			kids.push(E('span', { 'class': 'tm-ports', 'aria-hidden': 'true' }, [
				E('span', { 'class': 'tm-port' }, [ 'in' ]),
				E('span', { 'class': 'tm-port' }, [ 'out' ])
			]));
		}

		return E('button', {
			'class': cls,
			'type': 'button',
			'title': title,
			'click': ui.createHandlerFn(view, function(ev) {
				ev.preventDefault();
				self._nav(kind);
			})
		}, kids);
	}

	_arrow(active, skipped) {
		var cls = 'tm-arrow';
		if (active) cls += ' is-active';
		if (skipped) cls += ' is-skipped';
		return E('div', { 'class': cls, 'aria-hidden': 'true' }, [
			E('span', { 'class': 'tm-arrow-line' }),
			E('span', { 'class': 'tm-arrow-head' })
		]);
	}

	_rail() {
		/* continuous path under nodes (visual only) */
		return E('div', { 'class': 'tm-rail', 'aria-hidden': 'true' });
	}

	_chip(opts) {
		var self = this;
		var view = this._spec && this._spec.view;
		/* health only for monitorable links (VPN tunnels / WAN egress) */
		var health = opts.health;
		var cls = 'tm-chip kind-' + (opts.kind || 'x');
		var title = opts.title || opts.label;
		var kids;
		if (opts.active) cls += ' is-active';
		if (opts.dim) cls += ' is-dim';
		if (opts.warn && !health) cls += ' is-warn';
		if (health === 'ok' || health === 'warn' || health === 'fail' || health === 'unknown') {
			cls += ' is-health-' + health;
			if (!opts.titleFull)
				title = (title || '') + ' · ' + healthLabel(health);
		}

		kids = [
			E('span', { 'class': 'tm-chip-label' }, [ opts.label ]),
			opts.active ? iconEl(SVG.ok, 'tm-chip-check') : ''
		];
		if (health)
			kids.unshift(E('span', { 'class': 'tm-chip-dot', 'aria-hidden': 'true' }));

		return E('button', {
			'class': cls,
			'type': 'button',
			'title': title,
			'data-chip-id': (opts.detail && opts.detail.id) || null,
			'click': ui.createHandlerFn(view, function(ev) {
				ev.preventDefault();
				ev.stopPropagation();
				if (opts.detail) {
					self._togglePopover(opts.detail);
					return;
				}
				self._nav(opts.kind);
			})
		}, kids);
	}

	_stage(opts) {
		var self = this;
		var view = this._spec && this._spec.view;
		var cls = 'tm-stage kind-' + opts.kind;
		var body = [];
		var i;

		if (opts.lit) cls += ' is-lit';
		if (opts.quiet) cls += ' is-quiet';
		if (opts.skipped) cls += ' is-skipped';
		if (opts.status)
			cls += ' layer-' + opts.status;

		if (opts.skippedMsg) {
			body.push(E('p', { 'class': 'tm-skip-msg' }, [ opts.skippedMsg ]));
		}

		if (opts.chips && opts.chips.length) {
			body.push(E('div', { 'class': 'tm-chips' }, opts.chips));
		} else if (!opts.skippedMsg && !opts.expandLabel && !opts.diag) {
			body.push(E('span', { 'class': 'tm-empty muted' }, [ opts.empty || _('нет') ]));
		}

		if (opts.diag)
			body.push(opts.diag);

		if (opts.expandLabel) {
			body.push(E('button', {
				'class': 'tm-expand',
				'type': 'button',
				'click': ui.createHandlerFn(view, function(ev) {
					ev.preventDefault();
					self._toggleExpand(opts.expandKey);
				})
			}, [ opts.expandLabel ]));
		}

		return E('div', { 'class': cls, 'data-stage': opts.kind }, [
			E('div', { 'class': 'tm-stage-head' }, [
				E('span', { 'class': 'tm-stage-title' }, [
					iconEl(SVG[opts.kind] || SVG.dns, 'tm-stage-ico'),
					opts.title
				]),
				statusIcon(opts.status, opts.warn)
			]),
			E('div', { 'class': 'tm-stage-body' }, body)
		]);
	}

	/* Compact uplink channel strip for Exit/WAN (not DNS host checks). */
	_wanChannelDiag(wan) {
		var ch = channelLabel(wan);
		var tone = 'muted';
		var rows = [];
		var altEn;
		var baseOk;
		var altOk;

		if (!wan)
			return E('div', { 'class': 'tm-wan-diag is-empty' }, [
				E('span', { 'class': 'tm-wan-diag-k' }, [ _('Канал') ]),
				E('span', { 'class': 'tm-wan-diag-v muted' }, [ _('нет данных') ])
			]);

		if (ch === 'FULL') tone = 'ok';
		else if (ch === 'PARTIAL') tone = 'warn';
		else if (ch === 'FAIL') tone = 'fail';

		baseOk = probeBitOk(wan.probeBase);
		altEn = wan.probeAltEnabled === 1 || wan.probeAltEnabled === '1';
		altOk = probeBitOk(wan.probeAlt);

		rows.push(E('div', { 'class': 'tm-wan-diag-row' }, [
			E('span', { 'class': 'tm-wan-diag-k' }, [ _('Канал') ]),
			E('span', { 'class': 'tm-wan-diag-v is-' + tone }, [ ch || '—' ])
		]));
		rows.push(E('div', { 'class': 'tm-wan-diag-row' }, [
			E('span', { 'class': 'tm-wan-diag-k' }, [ _('база') ]),
			E('span', {
				'class': 'tm-wan-diag-mark is-' + (wan.probeBase === '' || wan.probeBase == null ? 'muted' : (baseOk ? 'ok' : 'fail')),
				'title': _('Базовый probe URL')
			}, [ wan.probeBase === '' || wan.probeBase == null ? '—' : (baseOk ? '✓' : '✗') ])
		]));
		rows.push(E('div', { 'class': 'tm-wan-diag-row' }, [
			E('span', { 'class': 'tm-wan-diag-k' }, [ _('доп.') ]),
			E('span', {
				'class': 'tm-wan-diag-mark is-' + (!altEn ? 'muted' : (altOk ? 'ok' : 'fail')),
				'title': _('Доп. probe (полный интернет)')
			}, [ !altEn ? _('выкл') : (altOk ? '✓' : '✗') ])
		]));

		return E('div', {
			'class': 'tm-wan-diag is-' + tone,
			'title': (wan.lastTick ? _('Тик: %s').format(wan.lastTick) : _('Мониторинг канала'))
		}, rows);
	}

	_breadcrumb(parts, active) {
		var nodes = [];
		var i;
		var cls = 'tm-breadcrumb' + (active ? ' is-active' : ' is-idle');
		for (i = 0; i < parts.length; i++) {
			if (i)
				nodes.push(E('span', { 'class': 'tm-bc-sep', 'aria-hidden': 'true' }, [ '→' ]));
			nodes.push(E('span', { 'class': 'tm-bc-item' }, [
				iconEl(SVG[parts[i].ico] || SVG.out, 'tm-bc-ico'),
				parts[i].label
			]));
		}
		return E('nav', {
			'class': cls,
			'aria-label': _('Путь'),
			'title': active ? _('Результат трассировки') : _('Схема пути — заполняется после «Путь»')
		}, nodes);
	}

	/* Shared expand control for DNS / VPN / Zapret stages. */
	_stageExpandLabel(key, pack, total, tracing) {
		if (this._expanded[key])
			return total > 0 ? _('Скрыть') : '';
		if (pack && pack.hidden > 0)
			return tracing
				? _('+%d').format(pack.hidden)
				: _('все +%d').format(pack.hidden);
		return '';
	}

	_buildStageChips(kind, allNodes, hl, tracing, expanded, hitsById, maxVisible) {
		var chips = [];
		var hidden = 0;
		var shown = 0;
		var i;
		var n;
		var id;
		var active;
		var label;
		var hit;
		var show;
		/* null/undefined → default 3; explicit 0 means collapse to expand-only. */
		var cap = maxVisible == null ? 3 : maxVisible;

		for (i = 0; i < allNodes.length; i++) {
			n = allNodes[i] || {};
			id = n.id || '';
			active = !!(tracing && hl[id]);
			if (tracing)
				show = expanded || active;
			else if (expanded)
				show = true;
			else
				show = shown < cap;

			if (!show) {
				hidden++;
				continue;
			}
			shown++;
			label = n.label || nodeLabel(id, id);
			hit = hitsById && hitsById[id];
			chips.push(this._chip({
				kind: kind,
				label: label,
				active: active,
				dim: tracing && !active,
				warn: !runtimeOk(n),
				health: kind === 'iface'
					? nodeHealth(n)
					: (kind === 'dns' ? dnsCheckHealth(n) : null),
				title: label,
				titleFull: kind === 'iface' || (kind === 'dns' && !!dnsCheckHealth(n)),
				/* Always tip — CTA «Списки» deep-links to this scope. */
				detail: {
					id: id,
					navKind: kind === 'iface' ? 'vpn' : kind,
					navScope: tipNavScope(id),
					title: active
						? _('Сработало: %s').format(label)
						: (kind === 'iface'
							? _('Туннель: %s').format(label)
							: (kind === 'dns'
								? _('DNS: %s').format(label)
								: _('Секция: %s').format(label))),
					rows: (function() {
						var fqdn = (hit && hit.base)
							|| (this._trace && this._trace.query && this._trace.query.fqdn)
							|| '';
						var rows;
						if (kind === 'iface') {
							rows = tunnelDetailRows(n);
							if (fqdn || (hit && hit.strategy)) {
								rows = [
									{ k: _('Домен'), v: fqdn || '—' },
									{ k: _('Стратегия'), v: (hit && hit.strategy) || '—' }
								].concat(rows);
							}
							return rows;
						}
						if (kind === 'dns')
							return dnsDetailRows(n, hit, active ? fqdn : '');
						return zapretDetailRows(n, hit, active ? fqdn : '');
					}.call(this))
				}
			}));
		}
		return { chips: chips, hidden: hidden };
	}

	render() {
		var self = this;
		var s = this._spec || {};
		var view = s.view;
		var summary = s.summary || {};
		var nodes = Array.isArray(summary.nodes) ? summary.nodes : [];
		var dns = [];
		var iface = [];
		var zapret = [];
		var i;
		var n;
		var hl = this._hl();
		var tracing = !!(this._trace && this._trace.code === 0);
		var ifaceLayer = this._layer('iface');
		var dnsLayer = this._layer('dns');
		var zapretLayer = this._layer('zapret');
		var egressLayer = this._layer('egress');
		var egressPath = 'wan';
		var err = '';
		var crumbs = [];
		var hitsById = {};
		var dnsPack;
		var vpnPack;
		var zapPack;
		var dnsStatus;
		var vpnStatus;
		var zapStatus;
		var vpnSkipped;
		var vpnMsg = '';
		var canvasCls = 'tm-flow';
		var btnLabel;

		this.className = 'tm-root';
		this.setAttribute('data-xfree-traffic-map', '1');

		for (i = 0; i < nodes.length; i++) {
			n = nodes[i] || {};
			if (n.kind === 'dns') dns.push(n);
			else if (n.kind === 'iface') iface.push(n);
			else if (n.kind === 'zapret') zapret.push(n);
		}

		if (zapretLayer && zapretLayer.scope && Array.isArray(zapretLayer.scope.hits)) {
			for (i = 0; i < zapretLayer.scope.hits.length; i++) {
				n = zapretLayer.scope.hits[i];
				if (n && n.id) hitsById[n.id] = n;
			}
		}

		/* DNS match context for tip rows (list/domain from current trace). */
		if (dnsLayer && dnsLayer.scope && dnsLayer.scope.dnsId) {
			hitsById['dns:' + dnsLayer.scope.dnsId] = {
				base: dnsLayer.scope.mappedDomain
					|| (this._trace && this._trace.query && this._trace.query.fqdn)
					|| '',
				listFile: dnsLayer.scope.listFile || '',
				strategy: dnsLayer.scope.target || ''
			};
		}

		if (this._trace) {
			if (this._trace.code === 0 && this._trace.summary) {
				egressPath = this._trace.summary.egress ||
					(egressLayer && egressLayer.scope && egressLayer.scope.path) ||
					'wan';
			} else if (this._trace.stderr) {
				err = this._trace.stderr;
			}
		}

		dnsStatus = tracing ? ((dnsLayer && dnsLayer.status) || 'none') : 'default';
		vpnStatus = tracing ? ((ifaceLayer && ifaceLayer.status) || 'none') : 'default';
		zapStatus = tracing ? ((zapretLayer && zapretLayer.status) || 'none') : 'default';
		vpnSkipped = tracing && vpnStatus !== 'match';

		if (vpnSkipped)
			vpnMsg = '';

		dnsPack = this._buildStageChips('dns', dns, hl, tracing, !!this._expanded.dns, hitsById, 2);
		vpnPack = this._buildStageChips('iface', iface, hl, tracing, !!this._expanded.vpn, null, 3);
		zapPack = this._buildStageChips('zapret', zapret, hl, tracing, !!this._expanded.zapret, hitsById, 3);

		/* Synthetic outcome chips — list entries alone don't show default/skip */
		if (tracing && dnsStatus === 'default') {
			dnsPack = {
				chips: [
					this._chip({
						kind: 'dns',
						label: _('По умолчанию'),
						active: true,
						title: _('Системный DNS — домена нет в dns-routing'),
						detail: {
							id: 'dns:default',
							navKind: 'dns',
							navScope: '',
							title: _('DNS по умолчанию'),
							rows: [
								{ k: _('Режим'), v: _('default') },
								{ k: _('Причина'), v: _('нет правила в dns-redirects') }
							]
						}
					})
				].concat(this._expanded.dns ? dnsPack.chips : []),
				hidden: this._expanded.dns ? 0 : dns.length
			};
		} else if (tracing && dnsStatus === 'skipped') {
			dnsPack = {
				chips: [
					this._chip({
						kind: 'dns',
						label: _('Пропущен'),
						active: true,
						title: _('DNS-редирект не нужен — домен уходит в VPN'),
						detail: {
							id: 'dns:skipped',
							navKind: 'dns',
							navScope: '',
							title: _('DNS пропущен'),
							rows: [
								{
									k: _('Причина'),
									v: (dnsLayer && dnsLayer.scope && dnsLayer.scope.reason === 'iface-covered')
										? _('покрыто VPN (iface)')
										: ((dnsLayer && dnsLayer.scope && dnsLayer.scope.reason) || _('пропуск'))
								},
								{
									k: _('VPN'),
									v: (ifaceLayer && ifaceLayer.scope && ifaceLayer.scope.iface) || '—'
								}
							]
						}
					})
				].concat(this._expanded.dns ? dnsPack.chips : []),
				hidden: this._expanded.dns ? 0 : dns.length
			};
		}

		if (vpnSkipped) {
			vpnPack = {
				chips: [
					this._chip({
						kind: 'vpn',
						label: _('Пропущен'),
						active: true,
						title: _('Нет VPN-правил для этого домена'),
						detail: {
							id: 'vpn:skipped',
							navKind: 'vpn',
							navScope: '',
							title: _('VPN не используется'),
							rows: [
								{ k: _('Причина'), v: _('домен не в списках туннеля') },
								{ k: _('Egress'), v: egressPath }
							]
						}
					})
				].concat(this._expanded.vpn ? vpnPack.chips : []),
				hidden: this._expanded.vpn ? 0 : iface.length
			};
		}

		if (tracing && zapStatus === 'none') {
			zapPack = {
				chips: [
					this._chip({
						kind: 'zapret',
						label: _('Пропущен'),
						active: true,
						title: _('Нет секций Zapret для этого домена'),
						detail: {
							id: 'zapret:skipped',
							navKind: 'zapret',
							navScope: '',
							title: _('Zapret не сработал'),
							rows: [
								{ k: _('Причина'), v: _('домен не в списках секций') }
							]
						}
					})
				].concat(this._expanded.zapret ? zapPack.chips : []),
				hidden: this._expanded.zapret ? 0 : zapret.length
			};
		}

		/* Always show plate under title: idle = schema hint, active = trace result */
		crumbs.push({ ico: 'lan', label: 'LAN' });
		crumbs.push({ ico: 'router', label: 'Router' });
		if (tracing) {
			if (dnsStatus === 'match' && dnsLayer.scope && dnsLayer.scope.dnsId)
				crumbs.push({ ico: 'dns', label: dnsLayer.scope.dnsId });
			else if (dnsStatus === 'skipped')
				crumbs.push({ ico: 'dns', label: _('без DNS') });
			else if (dnsStatus === 'default')
				crumbs.push({ ico: 'dns', label: _('DNS default') });
			else
				crumbs.push({ ico: 'dns', label: _('DNS') });
			if (vpnStatus === 'match' && ifaceLayer.scope && ifaceLayer.scope.iface)
				crumbs.push({ ico: 'vpn', label: ifaceLayer.scope.iface });
			else
				crumbs.push({ ico: 'vpn', label: _('без VPN') });
			if (zapStatus === 'match' && zapretLayer.scope && zapretLayer.scope.sections && zapretLayer.scope.sections.length)
				crumbs.push({ ico: 'zapret', label: zapretLayer.scope.sections.join(', ') });
			else
				crumbs.push({ ico: 'zapret', label: _('без Zapret') });
			crumbs.push({
				ico: 'out',
				label: egressPath.indexOf('tunnel:') === 0
					? egressPath.replace(/^tunnel:/, '')
					: (egressPath === 'wan' ? 'WAN' : egressPath)
			});
		} else {
			crumbs.push({ ico: 'dns', label: 'DNS' });
			crumbs.push({ ico: 'vpn', label: 'VPN' });
			crumbs.push({ ico: 'zapret', label: 'Zapret' });
			crumbs.push({ ico: 'out', label: _('выход') });
		}

		if (this._busy)
			canvasCls += ' is-busy';
		if (tracing)
			canvasCls += ' is-tracing';

		btnLabel = this._busy
			? [ iconEl(SVG.spin, 'tm-spin'), _('Ищем…') ]
			: [ iconEl(SVG.search, 'tm-btn-ico'), _('Путь') ];

		this.replaceChildren(
			E('div', { 'class': 'block-head tm-head' }, [
				E('h2', {}, [ _('Карта трафика') ])
			]),
			E('div', { 'class': 'tm-trace-wrap' }, [
				E('div', { 'class': 'tm-trace-bar' }, [
					E('input', {
						'class': 'tm-trace-input',
						'type': 'text',
						'name': 'fqdn',
						'placeholder': 'youtube.com',
						'autocomplete': 'off',
						'spellcheck': 'false',
						'value': this._fqdn || '',
						'aria-label': _('Сайт'),
						'aria-autocomplete': 'list',
						'aria-expanded': this._suggestOpen ? 'true' : 'false',
						/* plain handlers — ui.createHandlerFn disables+blurs the target (for buttons) */
						'focus': function() {
							self._openSuggest();
						},
						'blur': function() {
							window.setTimeout(function() {
								self._closeSuggest();
							}, 120);
						},
						'keydown': function(ev) {
							var box = self.querySelector('.tm-suggest');
							var vals = (box && box._suggestValues) || [];
							var n = vals.length;
							var idx;

							self._fqdn = (ev.target && ev.target.value) || self._fqdn || '';
							if (ev.key === 'ArrowDown' && n) {
								ev.preventDefault();
								self._suggestOpen = true;
								self._suggestActive = Math.min(n - 1, (self._suggestActive < 0 ? 0 : self._suggestActive + 1));
								self._paintSuggest();
								return;
							}
							if (ev.key === 'ArrowUp' && n) {
								ev.preventDefault();
								self._suggestActive = Math.max(-1, self._suggestActive - 1);
								self._paintSuggest();
								return;
							}
							if (ev.key === 'Escape') {
								ev.preventDefault();
								self._closeSuggest();
								return;
							}
							if (ev.key === 'Enter') {
								ev.preventDefault();
								idx = self._suggestActive;
								if (self._suggestOpen && idx >= 0 && idx < n)
									self._pickSuggest(vals[idx]);
								else {
									self._closeSuggest();
									self._runTrace();
								}
							}
						},
						'input': function(ev) {
							self._fqdn = (ev.target && ev.target.value) || '';
							self._suggestOpen = true;
							self._suggestActive = -1;
							self._paintSuggest();
						}
					}),
					E('button', {
						'class': 'btn tm-trace-btn',
						'type': 'button',
						'disabled': this._busy ? true : null,
						'click': ui.createHandlerFn(view, function(ev) {
							ev.preventDefault();
							self._closeSuggest();
							self._runTrace();
						})
					}, btnLabel)
				]),
				E('div', {
					'class': 'tm-suggest',
					'hidden': true,
					'role': 'listbox',
					'aria-label': _('Подсказки доменов')
				})
			]),
			this._breadcrumb(crumbs, tracing),
			err ? E('p', { 'class': 'tm-error' }, [ err ]) : '',
			E('div', { 'class': 'tm-flow-scroll' }, [
				E('div', { 'class': canvasCls }, [
					tracing ? this._rail() : '',
					this._hubBtn('lan', 'LAN', _('клиент'), tracing),
					this._arrow(tracing, false),
					this._hubBtn('router', 'Router', 'xfree', tracing),
					this._arrow(tracing && (dnsStatus === 'match' || dnsStatus === 'default' || dnsStatus === 'skipped'), false),
					this._stage({
						kind: 'dns',
						title: _('DNS'),
						status: dnsStatus,
						/* skipped = ghost pass-through; default/match stay solid */
						lit: tracing && (dnsStatus === 'match' || dnsStatus === 'default'),
						skipped: tracing && dnsStatus === 'skipped',
						quiet: tracing && dnsStatus === 'none',
						warn: tracing && dnsLayer && !runtimeOk(dnsLayer),
						chips: dnsPack.chips,
						expandKey: 'dns',
						expandLabel: this._stageExpandLabel('dns', dnsPack, dns.length, tracing)
					}),
					this._arrow(tracing, false),
					this._stage({
						kind: 'vpn',
						title: _('VPN'),
						status: vpnSkipped ? 'skipped' : vpnStatus,
						lit: tracing && vpnStatus === 'match',
						skipped: vpnSkipped,
						skippedMsg: vpnMsg,
						quiet: false,
						warn: tracing && ifaceLayer && !runtimeOk(ifaceLayer),
						chips: vpnPack.chips,
						empty: _('нет туннелей'),
						expandKey: 'vpn',
						expandLabel: this._stageExpandLabel('vpn', vpnPack, iface.length, tracing)
					}),
					this._arrow(tracing && (zapStatus === 'match' || zapStatus === 'none'), false),
					this._stage({
						kind: 'zapret',
						title: 'Zapret',
						status: zapStatus === 'none' && tracing ? 'skipped' : zapStatus,
						lit: tracing && zapStatus === 'match',
						skipped: tracing && zapStatus === 'none',
						quiet: false,
						warn: tracing && zapretLayer && !runtimeOk(zapretLayer),
						chips: zapPack.chips,
						expandKey: 'zapret',
						expandLabel: this._stageExpandLabel('zapret', zapPack, zapret.length, tracing)
					}),
					this._arrow(tracing, false),
					(function() {
						var wan = summary.wan || (self._trace && self._trace.summary && self._trace.summary.wan) || null;
						var outLabel = egressPath.indexOf('tunnel:') === 0
							? egressPath.replace(/^tunnel:/, '')
							: (egressPath === 'wan' ? 'WAN' : egressPath);
						var outHealth = 'unknown';
						var outDetail;
						var j;
						var node;
						var ch = channelLabel(wan);

						if (!tracing) {
							outLabel = 'WAN';
							outHealth = wan ? nodeHealth({ runtime: wan }) : 'unknown';
							outDetail = {
								id: 'egress:wan',
								navKind: 'out',
								title: _('Выход: WAN'),
								rows: [
									{ k: _('Канал'), v: ch || healthLabel(outHealth) },
									{ k: _('База'), v: wan && wan.probeBase != null && wan.probeBase !== ''
										? (probeBitOk(wan.probeBase) ? 'OK' : 'FAIL') : '—' },
									{ k: _('Доп.'), v: (wan && (wan.probeAltEnabled === 1 || wan.probeAltEnabled === '1'))
										? (probeBitOk(wan.probeAlt) ? 'OK' : 'FAIL')
										: _('выкл') },
									{ k: _('Последний тик'), v: (wan && wan.lastTick) || '—' }
								]
							};
						} else if (egressPath.indexOf('tunnel:') === 0) {
							for (j = 0; j < iface.length; j++) {
								if (nodeLabel(iface[j].id, '') === outLabel || (iface[j].label === outLabel)) {
									outHealth = nodeHealth(iface[j]);
									node = iface[j];
									break;
								}
							}
							outDetail = {
								id: 'egress:' + outLabel,
								navKind: 'vpn',
								navScope: outLabel,
								title: _('Выход: %s').format(outLabel),
								rows: [
									{ k: _('Тип'), v: _('туннель') },
									{ k: _('Мониторинг'), v: healthLabel(outHealth) },
									{ k: _('Канал WAN'), v: ch || '—' },
									{ k: _('Probe ping'), v: (node && node.runtime && node.runtime.monitorPing) || '—' },
									{ k: _('Last'), v: (node && node.runtime && node.runtime.monitorLast) || '—' }
								]
							};
						} else {
							outHealth = wan ? nodeHealth({ runtime: wan }) : 'unknown';
							outDetail = {
								id: 'egress:wan',
								navKind: 'out',
								title: _('Выход: WAN'),
								rows: [
									{ k: _('Тип'), v: _('прямой WAN') },
									{ k: _('Канал'), v: ch || healthLabel(outHealth) },
									{ k: _('База'), v: wan && wan.probeBase != null && wan.probeBase !== ''
										? (probeBitOk(wan.probeBase) ? 'OK' : 'FAIL') : '—' },
									{ k: _('Доп.'), v: (wan && (wan.probeAltEnabled === 1 || wan.probeAltEnabled === '1'))
										? (probeBitOk(wan.probeAlt) ? 'OK' : 'FAIL')
										: _('выкл') },
									{ k: _('Последний тик'), v: (wan && wan.lastTick) || '—' }
								]
							};
						}

						return self._stage({
							kind: 'out',
							title: _('Выход'),
							status: tracing ? 'inferred' : 'default',
							lit: tracing,
							chips: [
								self._chip({
									kind: 'out',
									label: outLabel,
									active: tracing,
									health: outHealth,
									detail: outDetail
								})
							],
							/* Channel monitor: FULL/PARTIAL/FAIL + base/alt ticks (not DNS hosts). */
							diag: self._wanChannelDiag(wan)
						});
					})()
				])
			])
		);

		this._placeFloatPopover();
		if (this._suggestOpen)
			this._paintSuggest();
	}
});

return baseclass.extend({
	tag: TAG
});
