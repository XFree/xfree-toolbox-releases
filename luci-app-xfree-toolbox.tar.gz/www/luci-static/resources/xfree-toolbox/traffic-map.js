'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.traffic-map-popover as mapPopover';
'require xfree-toolbox.traffic-map-suggest as mapSuggest';
'require xfree-toolbox.traffic-map-stages as mapStages';
'require xfree-toolbox.traffic-map-trace as mapTrace';
'require xfree-toolbox.traffic-map-view as mapView';

var TAG = 'xfree-traffic-map';

var TrafficMap = class extends wc.LightElement {
};

function mixMap(part) {
	prototypeMix.mixInto(TrafficMap.prototype, part);
}

mixMap(mapPopover);
mixMap(mapSuggest);
mixMap(mapStages);
mixMap(mapTrace);
mixMap(mapView);

wc.define(TAG, TrafficMap);

return baseclass.extend({
	tag: TAG
});
