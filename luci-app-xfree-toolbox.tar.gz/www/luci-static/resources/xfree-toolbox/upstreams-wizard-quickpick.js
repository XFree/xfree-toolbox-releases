'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.upstreams-analysis as upstreamsAnalysis';

function buildQuickPickSection(options) {
	var analysis = options.analysis;
	var groupCombobox = options.groupCombobox;
	var serviceCombobox = options.serviceCombobox;
	var stemCombobox = options.stemCombobox;
	var typeSelect = options.typeSelect;
	var updatePreview = options.updatePreview;
	var contentArea = options.contentArea;

	var quickPickPills = [];

	Object.keys(analysis.groups).forEach(function(gName) {
		var grp = analysis.groups[gName];
		var rootFiles = grp.files.filter(function(f) { return !f.service; });
		upstreamsAnalysis.checkFolderPairings(gName, '', rootFiles, quickPickPills);

		Object.keys(grp.services).forEach(function(sName) {
			var sFiles = grp.services[sName].files;
			upstreamsAnalysis.checkFolderPairings(gName, sName, sFiles, quickPickPills);
		});
	});

	if (quickPickPills.length === 0) return null;

	var pillsNodes = quickPickPills.map(function(p) {
		return xcmp.button({
			variant: 'vpn',
			primary: true,
			title: p.title,
			style: 'display: inline-flex; align-items: center; gap: 6px; font-size: 12px; padding: 4px 10px; border-radius: 6px; cursor: pointer;',
			onClick: function() {
				groupCombobox.setValue(p.group, true);
				serviceCombobox.setValue(p.service, true);
				stemCombobox.setValue(p.stem, true);
				typeSelect.value = p.type;
				updatePreview();
				contentArea.focus();
			},
			children: [
				'📁 ' + p.label,
				E('span', {
					'class': 'badge',
					'style': 'background: ' + p.badgeBg + '; color: ' + p.badgeColor + '; font-size: 11px; font-weight: 600; padding: 1px 6px;'
				}, [ p.badgeText ])
			]
		});
	});

	return E('div', {
		'style': 'margin-bottom: 14px; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;'
	}, [
		E('div', { 'style': 'font-size: 12px; font-weight: 600; margin-bottom: 8px; color: var(--text); display: flex; align-items: center; gap: 6px;' }, [
			'⚡ ' + _('Быстрое создание парных списков для существующих сервисов:')
		]),
		E('div', { 'style': 'display: flex; flex-wrap: wrap; gap: 8px;' }, pillsNodes)
	]);
}

function buildFolderStatus(options) {
	var fname = options.fname;
	var relPath = options.relPath;
	var g = options.g;
	var s = options.s;
	var existing = options.existing;
	var folderFiles = options.folderFiles || [];
	var createBtn = options.createBtn;
	var onShowFileView = options.onShowFileView || function() {};

	var statusElements = [];

	if (existing) {
		createBtn.disabled = true;
		createBtn.style.opacity = '0.5';
		createBtn.style.cursor = 'not-allowed';

		statusElements.push(E('div', {
			'style': 'padding: 10px 14px; background: var(--bad-soft); border: 1px solid var(--bad); border-radius: 8px; color: var(--bad); margin-bottom: 10px;'
		}, [
			E('div', { 'style': 'font-weight: 600; font-size: 13px;' }, [
				'⚠️ ' + _('Файл «%s» уже существует (%d строк)').format(fname, existing.lines || 0)
			]),
			E('div', { 'style': 'font-size: 12px; margin-top: 4px; color: var(--text);' }, [
				_('Выберите другое имя (stem), измените тип списка или отредактируйте существующий файл напрямую.')
			]),
			xcmp.button({
				variant: 'vpn',
				primary: true,
				text: '✏️ ' + _('Перейти к редактированию существующего файла'),
				style: 'margin-top: 8px; font-size: 12px; background: var(--panel-2); color: var(--bad); border-color: var(--bad);',
				onClick: function() {
					onShowFileView(relPath, false);
				}
			})
		]));
	} else {
		createBtn.disabled = false;
		createBtn.style.opacity = '1';
		createBtn.style.cursor = 'pointer';
	}

	var fileListItems = [];
	folderFiles.forEach(function(f) {
		var parts = f.path.split('/');
		var fn = parts[parts.length - 1];
		fileListItems.push(E('div', {
			'style': 'display: flex; align-items: center; justify-content: space-between; padding: 4px 0; border-bottom: 1px dashed color-mix(in srgb, var(--line) 40%, transparent); font-size: 12px;'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 6px;' }, [
				E('span', { 'style': 'color: var(--ok);' }, [ '✓' ]),
				E('code', { 'style': 'font-weight: 600; color: var(--text);' }, [ fn ])
			]),
			E('span', { 'class': 'badge', 'style': 'font-size: 11px;' }, [ _('%d строк').format(f.lines || 0) ])
		]));
	});

	if (!existing) {
		fileListItems.push(E('div', {
			'style': 'display: flex; align-items: center; justify-content: space-between; padding: 4px 0; font-size: 12px; color: var(--ok); font-weight: 600;'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 6px;' }, [
				E('span', {}, [ '➕' ]),
				E('code', { 'style': 'color: var(--ok); font-weight: 700;' }, [ fname ]),
				E('span', { 'style': 'font-size: 11px; font-weight: normal; opacity: 0.9;' }, [ '— ' + _('будет создан') ])
			]),
			E('span', { 'class': 'badge', 'style': 'background: var(--ok-soft); color: var(--ok); font-size: 11px;' }, [ _('новый файл') ])
		]));
	}

	statusElements.push(E('div', {
		'style': 'padding: 8px 12px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 6px; font-size: 12px;'
	}, [
		E('div', { 'style': 'font-weight: 600; color: var(--muted); margin-bottom: 6px; display: flex; align-items: center; gap: 6px;' }, [
			'📂 ' + _('Файлы в подгруппе: %s').format(g + (s ? (' / ' + s) : ''))
		]),
		E('div', {}, fileListItems)
	]));

	return statusElements;
}

return baseclass.extend({
	buildQuickPickSection: buildQuickPickSection,
	buildFolderStatus: buildFolderStatus
});
