'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-console';

function followLabel() {
	return (typeof _ === 'function') ? _('Автопрокрутка') : 'Автопрокрутка';
}

wc.define(TAG, class extends HTMLElement {
		static get observedAttributes() {
			return [ 'label' ];
		}

		constructor() {
			super();
			var self = this;
			var root = this.attachShadow({ mode: 'open' });

			root.innerHTML =
				'<style>' +
				':host{display:block;width:100%;box-sizing:border-box;margin:0.75rem 0 0;}' +
				'.toolbar{display:flex;align-items:center;justify-content:space-between;' +
				'gap:0.75rem;flex-wrap:wrap;margin:0 0 0.35rem;}' +
				'.caption{margin:0;font-size:0.9em;opacity:0.9;}' +
				'.opt{display:inline-flex;align-items:center;gap:0.35rem;margin:0;' +
				'font-size:0.9em;cursor:pointer;user-select:none;white-space:nowrap;}' +
				'.opt input{margin:0;}' +
				'pre{display:block;width:100%;box-sizing:border-box;margin:0;' +
				'min-height:4rem;max-height:var(--xfree-console-max-height,50vh);overflow:auto;' +
				'white-space:pre-wrap;overflow-wrap:anywhere;padding:0.75rem 1rem;' +
				'font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,"Liberation Mono",monospace;' +
				'font-size:0.8125rem;line-height:1.45;tab-size:4;' +
				'color:#aaaaaa;background:#000000;border:1px solid #333333;border-radius:8px;color-scheme:dark;}' +
				'</style>' +
				'<div class="toolbar" part="toolbar">' +
				'<div class="caption" part="caption"></div>' +
				'<label class="opt" part="autoscroll">' +
				'<input type="checkbox" checked>' +
				'<span></span>' +
				'</label>' +
				'</div>' +
				'<pre part="output"></pre>';
			this._caption = root.querySelector('.caption');
			this._pre = root.querySelector('pre');
			this._follow = root.querySelector('input[type="checkbox"]');
			root.querySelector('.opt span').textContent = followLabel();
			this._follow.addEventListener('change', function() {
				self._onFollowChange();
			});
		}

		connectedCallback() {
			this._syncLabel();
		}

		attributeChangedCallback() {
			this._syncLabel();
		}

		_syncLabel() {
			if (this._caption)
				this._caption.textContent = this.getAttribute('label') || '';
		}

		_onFollowChange() {
			if (this.autoscroll)
				this._scrollToEnd();
		}

		_scrollToEnd() {
			var pre = this._pre;

			if (!pre)
				return;

			pre.scrollTop = pre.scrollHeight;
		}

		get autoscroll() {
			return !!(this._follow && this._follow.checked);
		}

		set autoscroll(value) {
			if (!this._follow)
				return;

			this._follow.checked = !!value;
			if (value)
				this._scrollToEnd();
		}

		get text() {
			return this._pre ? this._pre.textContent : '';
		}

		set text(value) {
			var pre = this._pre;
			var keep;

			if (!pre)
				return;

			keep = pre.scrollTop;
			pre.textContent = value == null ? '' : String(value);

			if (this.autoscroll)
				this._scrollToEnd();
			else
				pre.scrollTop = keep;
		}
});

return baseclass.extend({
	tag: TAG
});
