'use strict';
'require baseclass';

return baseclass.extend({
	_renderHeader: function(s, st, isRefreshing, isChecking) {
		var self = this;
		var headActions = [
			E('button', {
				'class': 'ghost ghost-compact' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние статуса Telemt'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				}
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить статус'))
			]),
			E('button', {
				'class': 'ghost ghost-compact' + (isChecking ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isChecking || isRefreshing ? true : null,
				'title': _('Проверить доступные релизы Telemt на GitHub'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onCheckUpdates)
						s.onCheckUpdates();
					else
						self._act(ev, 'checkUpdate', '');
				}
			}, [
				E('span', { 'class': isChecking ? 'is-spinning' : '' }, [ '🔍' ]),
				' ' + (isChecking ? _('Проверка…') : _('Проверить обновления'))
			])
		];

		if (st.luciInstalled) {
			headActions.push(E('a', {
				'class': 'ghost ghost-compact',
				'href': L.url('admin/services/telemt'),
				'target': '_blank',
				'title': _('Открыть панель LuCI Telemt в новой вкладке')
			}, [ '⚙️ ' + _('LuCI Telemt') ]));
		}

		return E('div', { 'class': 'page-head' }, [
			E('div', { 'class': 'page-head-main' }, [
				E('p', { 'class': 'eyebrow' }, [ 'XFree toolbox' ]),
				E('h1', {}, [
					_('Telemt MTProxy'),
					E('span', {
						'class': 'xfree-vpn-status is-' + (st.running ? 'ok' : (st.installed ? 'bad' : 'warn')),
						'style': 'margin-left: 10px; font-size: 13px; font-weight: normal; vertical-align: middle;'
					}, [ st.running ? _('Работает') : (st.installed ? _('Остановлен') : _('Не установлен')) ])
				])
			]),
			E('div', { 'class': 'page-head-actions', 'style': 'display:flex; align-items:center; gap:8px;' }, [
				E('p', { 'class': 'muted page-head-desc' }, [
					_('MTProto-прокси для Telegram на роутере (Rust core + LuCI)')
				]),
				E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, headActions)
			])
		]);
	},

	_renderBanner: function(st) {
		var self = this;
		if (st.updateAvailable) {
			return E('div', {
				'class': 'xfree-telemt-update-banner',
				'style': 'background: linear-gradient(135deg, rgba(37,99,235,0.12), rgba(59,130,246,0.06)); border: 1px solid rgba(59,130,246,0.3); border-radius: 10px; padding: 14px 18px; margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap;'
			}, [
				E('div', { 'style': 'display:flex; align-items:center; gap:12px;' }, [
					E('div', { 'style': 'font-size: 26px; line-height: 1;' }, [ '🚀' ]),
					E('div', {}, [
						E('div', { 'style': 'font-weight: 600; font-size: 14px; color: #1d4ed8;' }, [
							_('Доступно обновление Telemt MTProxy!')
						]),
						E('div', { 'class': 'muted', 'style': 'font-size: 12px; margin-top: 2px;' }, [
							st.coreUpdateAvailable ? ('Core: ' + (st.coreVersion || _('не установлен')) + ' → ' + st.coreLatestVersion + '  ') : '',
							st.luciUpdateAvailable ? ('LuCI: ' + (st.luciVersion || _('не установлен')) + ' → ' + st.luciLatestVersion) : ''
						])
					])
				]),
				E('div', { 'style': 'display:flex; gap: 8px;' }, [
					E('button', {
						'class': 'btn primary',
						'type': 'button',
						'click': function(ev) {
							self._act(ev, 'upgrade', '', _('Обновить Telemt MTProxy (Core + LuCI) до актуальной версии?'));
						}
					}, [ '⚡ ' + _('Обновить сейчас') ])
				])
			]);
		}

		if (!st.installed) {
			return E('div', {
				'class': 'xfree-telemt-install-banner',
				'style': 'background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: 10px; padding: 14px 18px; margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap;'
			}, [
				E('div', { 'style': 'display:flex; align-items:center; gap:12px;' }, [
					E('div', { 'style': 'font-size: 24px; line-height: 1;' }, [ '📦' ]),
					E('div', {}, [
						E('div', { 'style': 'font-weight: 600; font-size: 14px; color: #b45309;' }, [
							_('Telemt MTProxy не установлен на роутере')
						]),
						E('div', { 'class': 'muted', 'style': 'font-size: 12px; margin-top: 2px;' }, [
							_('Установите пакет демона telemt и веб-интерфейс luci-app-telemt в один клик.')
						])
					])
				]),
				E('button', {
					'class': 'btn primary',
					'type': 'button',
					'click': function(ev) {
						self._act(ev, 'install', '', _('Скачать и установить компоненты Telemt MTProxy с GitHub?'));
					}
				}, [ '📥 ' + _('Установить Telemt') ])
			]);
		}

		return null;
	},

	_renderMetrics: function(st) {
		var metrics = [
			{
				title: _('Служба MTProxy'),
				value: st.running ? _('Работает') : (st.installed ? _('Остановлен') : _('Не установлен')),
				desc: st.running && st.pid ? ('PID: ' + st.pid + ' · Порт: ' + st.port) : ('Порт: ' + st.port),
				statusTone: st.running ? 'ok' : (st.installed ? 'bad' : 'warn')
			},
			{
				title: _('Ядро (telemt_wrt)'),
				value: st.coreVersion ? ('v' + st.coreVersion) : _('Не установлен'),
				desc: st.coreUpdateAvailable ? ('⬆️ Доступно v' + st.coreLatestVersion) : (st.coreLatestVersion ? '✓ ' + _('Актуально') : _('Демон MTProxy')),
				statusTone: st.coreInstalled ? (st.coreUpdateAvailable ? 'warn' : 'ok') : 'warn'
			},
			{
				title: _('Интерфейс (LuCI)'),
				value: st.luciVersion ? ('v' + st.luciVersion) : _('Не установлен'),
				desc: st.luciUpdateAvailable ? ('⬆️ Доступно v' + st.luciLatestVersion) : (st.luciLatestVersion ? '✓ ' + _('Актуально') : _('Веб-панель LuCI')),
				statusTone: st.luciInstalled ? (st.luciUpdateAvailable ? 'warn' : 'ok') : 'warn'
			},
			{
				title: _('Автозапуск службы'),
				value: st.enabled ? _('Включен') : _('Отключен'),
				desc: 'procd /etc/init.d/telemt',
				statusTone: st.enabled ? 'ok' : 'muted'
			}
		];

		var metricCards = metrics.map(function(m) {
			return E('div', {
				'class': 'card',
				'style': 'padding: 14px 16px; display: flex; flex-direction: column; justify-content: space-between; border-radius: 8px;'
			}, [
				E('div', { 'style': 'display:flex; justify-content:space-between; align-items:center; margin-bottom: 6px;' }, [
					E('span', { 'class': 'muted', 'style': 'font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;' }, [ m.title ]),
					E('span', { 'class': 'xfree-vpn-status-dot is-' + m.statusTone })
				]),
				E('div', { 'style': 'font-size: 17px; font-weight: 700; margin-bottom: 2px;' }, [ m.value ]),
				E('div', { 'class': 'muted', 'style': 'font-size: 11px;' }, [ m.desc ])
			]);
		});

		return E('div', {
			'style': 'display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 16px;'
		}, metricCards);
	},

	_renderServiceSection: function(st) {
		var self = this;
		var serviceBtns = [
			E('button', {
				'class': 'btn' + (st.running ? '' : ' primary'),
				'type': 'button',
				'disabled': (!st.installed || st.running) ? true : null,
				'click': function(ev) {
					self._act(ev, 'service', 'start');
				}
			}, [ '▶️ ' + _('Запустить сервис') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'disabled': (!st.installed || !st.running) ? true : null,
				'click': function(ev) {
					self._act(ev, 'service', 'stop');
				}
			}, [ '⏹️ ' + _('Остановить сервис') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'disabled': !st.installed ? true : null,
				'click': function(ev) {
					self._act(ev, 'service', 'restart');
				}
			}, [ '🔄 ' + _('Перезапустить') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'disabled': !st.installed ? true : null,
				'click': function(ev) {
					self._act(ev, 'service', st.enabled ? 'disable' : 'enable');
				}
			}, [ st.enabled ? ('⏸️ ' + _('Отключить автозапуск')) : ('✓ ' + _('Включить автозапуск')) ])
		];

		return E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '⚙️ ' + _('Управление демоном Telemt') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Служба OpenWrt procd') ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'padding: 10px 14px; display:flex; gap: 8px; flex-wrap:wrap;' }, serviceBtns)
		]);
	},

	_renderMaintenanceSection: function() {
		var self = this;
		var maintenanceBtns = [
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function(ev) {
					self._act(ev, 'checkUpdate', '');
				}
			}, [ '🔍 ' + _('Проверить обновления на GitHub') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function(ev) {
					self._act(ev, 'install', '', _('Запустить установку/обновление компонентов Telemt?'));
				}
			}, [ '📥 ' + _('Установить / Обновить') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function(ev) {
					self._act(ev, 'upgrade', '', _('Выполнить принудительную переустановку Telemt (--force)?'));
				}
			}, [ '🔨 ' + _('Принудительная переустановка (--force)') ])
		];

		return E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📦 ' + _('Установка и обслуживание релизов') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('GitHub Releases') ])
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'padding: 10px 14px; display:flex; gap: 8px; flex-wrap:wrap;' }, maintenanceBtns),
			E('p', { 'class': 'muted', 'style': 'padding: 0 14px 10px 14px; font-size: 12px; margin: 0;' }, [
				_('💡 Мажорная и минорная версии Core (telemt_wrt) и LuCI (luci-app-telemt) синхронизированы для полной совместимости рантайма и конфигурации.')
			])
		]);
	}
});
