'use strict';
'require baseclass';

/* Навигация вкладками (subnav chips), описание матрицы и точка входа render.
 * Методы вешаются на прототип xfree-routing. */

function kindLabel(target) {
	switch (target) {
	case 'wan6':
		return _('WAN6');
	case 'dns':
		return _('DNS');
	case 'zapret':
		return _('Zapret');
	default:
		return _('VPN');
	}
}

return baseclass.extend({
	_matrixDescr: function (target) {
		if (target === 'exclude')
			return _('Исключения: списки, исключаемые из туннелей VPN (fqdn.exclude.d) и секций Zapret.');
		if (target === 'vpn' || target === 'iface')
			return _('VPN: одна строка — список; колонки — туннели. Выбранные сверху.');
		if (target === 'zapret')
			return _('Zapret: одна строка — список; колонки — активные секции Zapret. Выбранные сверху.');
		if (target === 'dns')
			return _('DNS: одна строка — список; колонки — DNS-серверы. Выбранные сверху.');
		return _('Общее: одна строка — список; колонки — куда он может попасть (VPN / DNS / секция Zapret). Выбранные сверху.');
	},

	_chipNav: function () {
		var self = this;
		var xui = this._xui();
		var view = this._view();
		var activeTarget = this._activeTarget || this._selTarget();
		var buttons = [];

		var tabs = [
			{ id: 'all', title: _('Общее') },
			{ id: 'vpn', title: _('VPN') },
			{ id: 'dns', title: _('DNS') },
			{ id: 'zapret', title: _('Zapret') },
			{ id: 'exclude', title: _('Исключения') }
		];

		tabs.forEach(function(t) {
			var isActive = activeTarget === t.id ||
				(t.id === 'all' && (!activeTarget || activeTarget === 'general' || activeTarget === 'all'));

			buttons.push(E('button', {
				'type': 'button',
				'class': 'subnav-btn' + (isActive ? ' is-active' : ''),
				'click': function(ev) {
					if (ev) ev.preventDefault();
					if (t.id === 'exclude') {
						self._activeTarget = 'exclude';
						self._activeScope = '';
						self._isExclude = true;
						self._setStatus(_('Загрузка матрицы исключений…'));
						xui.loadRoutingHub(view, { view: 'exclude', tab: 'exclude' }, true).then(function(nextHub) {
							self._spec.hub = nextHub;
							self._initialChecked = self._cloneChecked(nextHub.checked);
							self.requestPaint();
							view.navigate('routing', 'exclude', '');
						});
					} else {
						self._activeTarget = t.id;
						self._activeScope = '';
						if (self._isExclude) {
							self._isExclude = false;
							self._setStatus(_('Загрузка общих списков…'));
							xui.loadRoutingHub(view, { view: 'general', tab: t.id }, false).then(function(nextHub) {
								self._spec.hub = nextHub;
								self._initialChecked = self._cloneChecked(nextHub.checked);
								self.requestPaint();
								view.navigate('routing', t.id === 'all' ? 'general' : t.id, '');
							});
						} else {
							self.requestPaint();
							view.navigate('routing', t.id === 'all' ? 'general' : t.id, '');
						}
					}
				}
			}, [ t.title ]));
		});

		return E('nav', {
			'class': 'subnav xfree-routing-chips',
			'aria-label': _('Цели маршрутизации')
		}, buttons);
	},

	_renderScope: function () {
		var xui = this._xui();
		var view = this._view();
		var hub = this._hub();
		var sel = this._sel();
		var node = xui.routingWizardNode(sel.target);
		var model = hub.model;
		var scope = sel.scope;

		view._xfreeWizardActiveIface = scope;
		if (!view._xfreeWizardModels)
			view._xfreeWizardModels = {};
		view._xfreeWizardModels[scope] = model;

		return E('div', {
			'class': 'xfree-routing-scope',
			'data-xfree-wizard': node.id
		}, [
			E('h3', {}, [
				kindLabel(sel.target) + ' · ' + (sel.label || scope)
			]),
			E('div', { 'class': 'cbi-section-descr' }, [
				_('Отдельный выбор списков для этой цели. «Общее» — матрица по всем целям.')
			]),
			xui.renderWizardListsPane(node, view, scope, model)
		]);
	},

	render: function () {
		var hub = this._hub();
		var body;

		this.className = 'xfree-routing-hub';
		this.setAttribute('data-xfree-routing', '1');

		if (hub.loading) {
			this.replaceChildren(
				E('div', { 'class': 'panel-block xfree-routing-body' }, [ this._renderMatrix() ])
			);
			return;
		}

		if (hub.error) {
			this.replaceChildren(
				E('div', { 'class': 'cbi-section-descr' }, [ hub.error ])
			);
			return;
		}

		body = this._renderMatrix();

		this.replaceChildren(
			E('div', { 'class': 'panel-block xfree-routing-body' }, [ body ])
		);
	}
});
