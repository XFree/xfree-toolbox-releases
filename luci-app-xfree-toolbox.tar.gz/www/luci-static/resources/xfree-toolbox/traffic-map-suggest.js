'use strict';
'require baseclass';

return baseclass.extend({
	/* Active FQDNs from iface/dns/zapret generated lists (free text still allowed). */
	_ensureSuggest: function() {
		var self = this;
		var onSuggest = this._spec && this._spec.onSuggest;

		if (!onSuggest || this._suggestLoaded || this._suggestLoading)
			return;

		this._suggestLoading = true;
		Promise.resolve(onSuggest('')).then(function(res) {
			self._suggestLoading = false;
			self._suggestLoaded = true;
			self._suggestItems = (res && Array.isArray(res.items)) ? res.items : [];
			self._paintSuggest();
		}).catch(function() {
			self._suggestLoading = false;
			self._suggestLoaded = true;
			self._suggestItems = [];
			self._paintSuggest();
		});
	},

	_filteredSuggest: function(q) {
		var all = this._suggestItems || [];
		var needle = String(q || '').toLowerCase().replace(/^\s+|\s+$/g, '');
		if (!needle)
			return all.slice(0, 40);

		var prefixMatches = [];
		var dotMatches = [];
		var subMatches = [];
		var max = 40;
		var i;

		for (i = 0; i < all.length; i++) {
			var item = String(all[i]).toLowerCase();
			var idx = item.indexOf(needle);
			if (idx === 0) {
				prefixMatches.push(all[i]);
				if (prefixMatches.length >= max)
					return prefixMatches;
			} else if (idx > 0) {
				if (item.indexOf('.' + needle) !== -1)
					dotMatches.push(all[i]);
				else
					subMatches.push(all[i]);
			}
		}

		var out = prefixMatches;
		for (i = 0; i < dotMatches.length && out.length < max; i++)
			out.push(dotMatches[i]);
		for (i = 0; i < subMatches.length && out.length < max; i++)
			out.push(subMatches[i]);

		return out;
	},

	_openSuggest: function() {
		this._suggestOpen = true;
		this._suggestActive = -1;
		this._ensureSuggest();
		this._paintSuggest();
	},

	_closeSuggest: function() {
		this._suggestOpen = false;
		this._suggestActive = -1;
		this._paintSuggest();
	},

	_pickSuggest: function(value) {
		var input = this.querySelector('.tm-trace-input');
		this._fqdn = value || '';
		if (input)
			input.value = this._fqdn;
		this._closeSuggest();
		this._runTrace();
	},

	/* In-place update — do not requestPaint (would steal focus). */
	_paintSuggest: function() {
		var box = this.querySelector('.tm-suggest');
		var items;
		var i;
		var row;
		var self = this;

		if (!box)
			return;

		items = this._suggestOpen ? this._filteredSuggest(this._fqdn) : [];
		box.replaceChildren();
		if (!items.length) {
			box.hidden = true;
			box.classList.remove('is-open');
			return;
		}

		for (i = 0; i < items.length; i++) {
			/* plain div — avoid <button> and role=option (LuCI/Bootstrap crush layout) */
			row = E('div', {
				'class': 'tm-suggest-item' + (i === this._suggestActive ? ' is-active' : ''),
				'tabindex': '-1',
				'data-idx': String(i)
			}, [ String(items[i]) ]);
			row.addEventListener('mousedown', function(ev) {
				/* mousedown before blur — keep pick working */
				ev.preventDefault();
			});
			row.addEventListener('click', (function(val) {
				return function(ev) {
					ev.preventDefault();
					self._pickSuggest(val);
				};
			})(items[i]));
			box.appendChild(row);
		}
		box._suggestValues = items;
		box.hidden = false;
		box.classList.add('is-open');
	}
});
