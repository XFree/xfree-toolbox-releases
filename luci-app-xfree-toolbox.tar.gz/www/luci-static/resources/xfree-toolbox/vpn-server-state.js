'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.components as xcmp';

return baseclass.extend({
	mount: function (spec) {
		this._spec = spec || {};
		this._view = spec.view || null;
		this._serverView = spec.serverView || 'server';
		this._awgSummary = spec.awgSummary || {};
		this._loading = !!spec.loading;
		this._busy = false;
		this._msg = spec.message || '';
		this._msgTone = spec.messageTone || '';
		this._natChecking = false;
		this._natCheckResult = null;

		var hasData = this._awgSummary && (this._awgSummary.iface || this._awgSummary.running != null);
		if (!hasData && !this._loading) {
			this.reload();
		} else {
			this.requestPaint();
		}
	},

	reload: function () {
		var self = this;
		this._loading = true;
		this.requestPaint();

		return xui.runAwgMenu('status').then(function (res) {
			self._awgSummary = xui.parseAwgStatus(res);
			self._loading = false;
			self.requestPaint();
		}).catch(function (err) {
			self._loading = false;
			self._msg = (err && err.message) || String(err);
			self._msgTone = 'bad';
			self.requestPaint();
		});
	},

	setAwgSummary: function (data) {
		this._awgSummary = data || {};
		this._loading = false;
		this.requestPaint();
	},

	setBusy: function (val) {
		this._busy = !!val;
		this.requestPaint();
	},

	setLoading: function (val) {
		this._loading = !!val;
		this.requestPaint();
	},

	setMessage: function (text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var msgEl = this.querySelector('[data-xfree-vpn-msg]');
		if (msgEl) {
			msgEl.className = 'xfree-vpn-msg' + (tone ? ' is-' + tone : '');
			msgEl.textContent = text || '';
		}
	},

	_showVpnDialog: function (title, content) {
		return ui.showModal(title, content);
	},

	_act: function (ev, action, arg, confirmOpts) {
		var s = this._spec || {};
		if (ev && typeof ev.preventDefault === 'function')
			ev.preventDefault();

		if (!s.onAction)
			return;

		if (confirmOpts && typeof confirmOpts === 'object') {
			var dialogContent = [
				E('p', { 'style': 'font-size: 14px; margin-bottom: 8px;' }, [confirmOpts.message || _('Выполнить действие?')]),
				confirmOpts.detail ? E('p', { 'class': 'muted', 'style': 'font-size: 12px; margin-bottom: 12px; line-height: 1.4;' }, [confirmOpts.detail]) : ''
			];

			var confirmBtn = E('button', {
				'class': 'btn ' + (confirmOpts.tone === 'danger' ? 'is-bad' : 'is-primary'),
				'type': 'button',
				'click': function () {
					ui.hideModal();
					s.onAction(action, arg, '');
				}
			}, [confirmOpts.confirmText || _('Подтвердить')]);

			var cancelBtn = xcmp.button({
				variant: 'vpn',
				primary: true,
				text: _('Отмена'),
				onClick: function () { ui.hideModal(); }
			});

			var actionsBar = E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px;' }, [
				cancelBtn,
				confirmBtn
			]);

			ui.showModal(confirmOpts.title || _('Подтверждение'), [
				E('div', {}, dialogContent),
				actionsBar
			]);
		} else if (typeof confirmOpts === 'string' && confirmOpts) {
			s.onAction(action, arg, confirmOpts);
		} else {
			s.onAction(action, arg, '');
		}
	},


	paint: function () {
		var s = this._spec || {};
		var view = this._view;
		var awg = this._awgSummary || {};
		var sections = [];

		this.className = 'xfree-vpn-root';
		this.setAttribute('data-xfree-vpn', '1');
		this.setAttribute('data-xfree-vpn-server', '1');

		var isRefreshing = this._busy || this._loading;
		var peerCount = (awg.peers && awg.peers.length) || 0;

		var chips = [];
		if (this._loading && !awg.iface && awg.running == null) {
			chips.push(xcmp.chip({ label: _('Сервер'), loading: true }));
			chips.push(xcmp.chip({ label: _('Интерфейс : Порт'), loading: true }));
			chips.push(xcmp.chip({ label: _('Подсеть'), loading: true }));
			chips.push(xcmp.chip({ label: _('Клиентов'), loading: true }));
		} else {
			chips.push(xcmp.chip({
				label: _('Сервер'),
				value: awg.running ? _('активен (UP)') : _('остановлен'),
				tone: awg.running ? 'ok' : 'bad'
			}));
			chips.push(xcmp.chip({
				label: _('Интерфейс : Порт'),
				value: (awg.iface || 'awg_ingress') + ' : ' + (awg.port || '51820') + ' UDP'
			}));
			chips.push(xcmp.chip({
				label: _('Подсеть'),
				value: awg.addr || '10.200.200.1/24'
			}));
			chips.push(xcmp.chip({
				label: _('Клиентов'),
				value: String(peerCount),
				tone: peerCount > 0 ? 'ok' : ''
			}));
			if (awg.freeTurnInstalled) {
				chips.push(xcmp.chip({
					label: _('FreeTurn'),
					value: awg.freeTurnRunning ? _('порт %s').format(awg.freeTurnPort || '56000') : _('остановлен'),
					tone: awg.freeTurnRunning ? 'ok' : ''
				}));
			}
			if (awg.vkInstalled || awg.vkRunning) {
				chips.push(xcmp.chip({
					label: _('VK-Turn'),
					value: _('установлен (устарел)'),
					tone: 'bad'
				}));
			}
		}

		var self = this;
		var topOps = [
			xcmp.button({
				variant: 'vpn',
				primary: true,
				extraClass: 'xfree-vpn-head-btn',
				title: _('Обновить статус сервера и пиров'),
				disabled: isRefreshing,
				onClick: ui.createHandlerFn(view, function (ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
					else
						self.reload();
				}),
				children: [
					E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, ['🔄']),
					' ' + (isRefreshing ? _('Обновление…') : _('Обновить статус'))
				]
			}),
			xcmp.button({
				variant: 'vpn',
				primary: true,
				extraClass: 'xfree-vpn-head-btn is-primary',
				text: '⚡ ' + _('Применить сервер'),
				title: _('Применить конфигурацию сервера и пиров'),
				onClick: ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'serverApply', '', {
						title: _('Применение настроек сервера'),
						message: _('Перезапустить VPN-сервер и применить конфигурацию интерфейса?'),
						detail: _('Сетевой интерфейс awg_ingress будет перезапущен с актуальными ключами, портами и списком клиентов.'),
						confirmText: _('Применить'),
						tone: 'primary',
						icon: '⚡'
					});
				})
			})
		];

		var isClientsView = this._serverView === 'clients';
		sections.push(
			E('div', { 'class': 'xfree-vpn-head' }, [
				E('div', { 'class': 'xfree-vpn-head-left' }, [
					E('h3', {}, [isClientsView ? _('Пользователи VPN-сервера') : _('VPN-сервер')]),
					E('p', { 'class': 'muted' }, [isClientsView
						? _('Клиенты AmneziaWG (Ingress), выдача .conf и QR-кодов')
						: _('Управление VPN-сервером AmneziaWG (Ingress) и транспортом')])
				]),
				E('div', { 'class': 'xfree-vpn-head-right' }, [
					E('div', { 'class': 'xfree-vpn-head-actions' }, topOps),
					E('div', {
						'class': 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
						'data-xfree-vpn-msg': '1'
					}, [this._msg || ''])
				])
			]),
			E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips)
		);

		var serverSec = this._renderServerSection(awg, view, this._serverView);
		if (serverSec)
			sections.push(serverSec);

		this.replaceChildren.apply(this, sections);
		if (this._busy) {
			this.querySelectorAll('button').forEach(function (el) {
				el.disabled = true;
			});
		}
	},
});
