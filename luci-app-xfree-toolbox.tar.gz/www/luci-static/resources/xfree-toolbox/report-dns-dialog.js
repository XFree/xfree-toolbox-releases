'use strict';
'require baseclass';
'require ui';
'require rpc';
'require xfree-toolbox.components as xcmp';

/* Диалог настройки опрашиваемых доменов DNS и тест DoH.
 * Методы вешаются на прототип xfree-report. */

var callUplinkMenu = rpc.declare({
	object: 'xfree-toolbox',
	method: 'uplinkMenu',
	params: [ 'action', 'arg', 'settings' ]
});

return baseclass.extend({
	_callUplinkMenu: function (action, arg, settings) {
		return callUplinkMenu(action, arg, settings);
	},

	_openDomainDialog: function () {
		var s = this._spec || {};
		var defaultHosts = 'ya.ru\ngoogle.com\nyoutube.com\ngithub.com\ncloudflare.com\nexample.com';
		var extendedHosts = defaultHosts + '\nt.me\nvk.com\nwikipedia.org\nkinopoisk.ru';

		callUplinkMenu('dnsHostsGet', '', '').then(function(res) {
			var currentHosts = (res && res.stdout && res.stdout.trim()) ? res.stdout.trim() : defaultHosts;
			var ta = E('textarea', {
				'class': 'xfree-dns-hosts-textarea',
				'rows': '7',
				'placeholder': defaultHosts
			}, [ currentHosts ]);

			var presets = E('div', { 'class': 'xfree-dns-presets' }, [
				E('span', { 'class': 'muted font-xs', 'style': 'align-self:center; margin-right:4px;' }, [ _('Пресеты:') ]),
				xcmp.button({
					variant: 'vpn',
					text: _('Стандартный (6)'),
					onClick: function(ev) {
						ev.preventDefault();
						ta.value = defaultHosts;
					}
				}),
				xcmp.button({
					variant: 'vpn',
					text: _('Расширенный (10)'),
					onClick: function(ev) {
						ev.preventDefault();
						ta.value = extendedHosts;
					}
				})
			]);

			ui.showModal(_('🌐 Домены для диагностики DNS'), [
				E('div', { 'class': 'xfree-dialog-body' }, [
					E('p', { 'class': 'xfree-dialog-hint muted' }, [
						_('Список опрашиваемых доменов (по одному на строку). Сохраняется в /etc/xfree-toolbox/system/dns-check-hosts.txt.')
					]),
					ta,
					presets
				]),
				E('div', { 'class': 'xfree-dialog-actions' }, [
					E('button', {
						'class': 'btn primary',
						'type': 'button',
						'click': function() {
							ui.hideModal();
							var val = String(ta.value || '').trim();
							callUplinkMenu('dnsHostsSave', val, '').then(function() {
								if (s.onReload)
									s.onReload();
							});
						}
					}, [ _('Сохранить и запустить') ]),
					E('button', {
						'class': 'btn secondary',
						'type': 'button',
						'click': function() {
							ui.hideModal();
							var val = String(ta.value || '').trim();
							callUplinkMenu('dnsHostsSave', val, '');
						}
					}, [ _('Сохранить') ]),
					E('button', {
						'class': 'btn ghost',
						'type': 'button',
						'click': function() {
							ui.hideModal();
							callUplinkMenu('dnsHostsReset', '', '').then(function() {
								if (s.onReload)
									s.onReload();
							});
						}
					}, [ _('Сбросить к исходным') ]),
					E('button', {
						'class': 'btn ghost',
						'type': 'button',
						'click': function() {
							ui.hideModal();
						}
					}, [ _('Отмена') ])
				])
			], 'cbi-modal', 'xfree-dialog', 'xfree-vpn-dialog');
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ _('Ошибка получения списка доменов: %s').format(err) ]), 'danger');
		});
	},

	_openDohDialog: function () {
		var consoleModal = E('xfree-console', {
			'label': _('Вывод теста DoH'),
			'class': 'xfree-report-output',
			'style': '--xfree-console-max-height:55vh'
		});
		consoleModal.text = _('Запуск проверки DoH-инстансов (https-dns-proxy 5060/5061 A/B)…\n');

		ui.showModal(_('🔒 Проверка DoH-инстансов'), [
			E('div', { 'class': 'xfree-dialog-body' }, [
				E('p', { 'class': 'xfree-dialog-hint muted font-xs' }, [
					_('Тестирование доступности, задержек и ответов upstream DoH-серверов https-dns-proxy.')
				]),
				consoleModal
			]),
			E('div', { 'class': 'xfree-dialog-actions' }, [
				E('button', {
					'class': 'btn primary',
					'type': 'button',
					'click': function() { ui.hideModal(); }
				}, [ _('Закрыть') ])
			])
		], 'cbi-modal', 'xfree-dialog', 'xfree-vpn-dialog');

		callUplinkMenu('testDoh', 'ab', '').then(function(res) {
			consoleModal.text = (res && res.stdout) ? res.stdout : ((res && res.stderr) ? res.stderr : _('Проверка завершена без вывода.'));
		}).catch(function(err) {
			consoleModal.text = _('Ошибка: ') + (err.message || String(err));
		});
	}
});
