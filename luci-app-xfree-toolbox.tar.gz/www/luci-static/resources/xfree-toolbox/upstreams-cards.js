'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';
'require xfree-toolbox.upstreams-util as upstreamsUtil';

return baseclass.extend({
	render: function() {
		var self = this;
		var modules = self._modules || [];

		this.className = 'xfree-upstreams-root';

		/* 1. Global Toolbar */
		var toolbar = E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 8px;' }, [
			xcmp.button({
				variant: 'vpn',
				primary: true,
				text: '🚀 ' + _('Обновить всё и применить'),
				onClick: function() {
					self._runBgAction(_('Обновление и применение всех источников'), 'upstreamsUpdateApply');
				}
			}),
			xcmp.button({
				variant: 'vpn',
				text: '📥 ' + _('Скачать активные'),
				onClick: function() {
					self._runBgAction(_('Скачивание обновлений активных источников'), 'upstreamsUpdateActive');
				}
			}),
			xcmp.button({
				variant: 'vpn',
				text: '⚡ ' + _('Применить обновления (Drift)'),
				onClick: function() {
					self._runBgAction(_('Применение обновлений (Drift)'), 'upstreamsApply');
				}
			}),
			xcmp.button({
				variant: 'vpn',
				text: '🔄 ' + _('Переиндексировать'),
				onClick: function() {
					self._runBgAction(_('Переиндексация источников списков'), 'upstreamsReindex');
				}
			}),
			xcmp.button({
				variant: 'vpn',
				primary: true,
				text: '➕ ' + _('Создать свой Upstream'),
				style: 'margin-left: auto; background: var(--ok-soft); color: var(--ok); border-color: var(--ok);',
				onClick: function() {
					self._showCreateModal();
				}
			})
		]);

		/* 2. Content cards */
		var cardsContainer;

		if (self._loading) {
			cardsContainer = E('div', { 'class': 'cbi-section', 'style': 'text-align: center; padding: 30px;' }, [
				E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка источников…') ])
			]);
		} else if (self._error) {
			cardsContainer = E('div', { 'class': 'cbi-section is-bad', 'style': 'padding: 20px;' }, [
				E('p', { 'style': 'color: var(--bad);' }, [ '⚠️ ' + self._error ])
			]);
		} else if (!modules.length) {
			cardsContainer = E('div', { 'class': 'cbi-section', 'style': 'text-align: center; padding: 30px;' }, [
				E('p', { 'class': 'muted' }, [ _('Источники списков не найдены.') ])
			]);
		} else {
			var cardEls = modules.map(function(mod) {
				var isEnabled = (mod.enabled === 1);
				var isCustom = (mod.custom === 1);
				var canDelete = isCustom && (mod.name !== 'user') && (mod.id !== 'user');

				var statusBadge = xcmp.badge({
					variant: 'vpn-status',
					tone: isEnabled ? 'ok' : 'muted',
					text: isEnabled ? _('Включен') : _('Отключен')
				});

				var isUserXfree = (mod.name === 'user' || mod.id === 'user' || (mod.title && mod.title.toLowerCase() === 'xfree'));
				var typeBadge;
				if (isCustom) {
					typeBadge = xcmp.badge({
						variant: 'vpn-status',
						tone: 'info',
						text: _('Пользовательский'),
						style: 'background: var(--accent-soft); color: var(--accent);'
					});
				} else if (isUserXfree) {
					typeBadge = xcmp.badge({
						variant: 'vpn-status',
						text: _('Встроенный'),
						style: 'background: var(--accent-soft); color: var(--accent);'
					});
				} else {
					typeBadge = xcmp.badge({
						variant: 'vpn-status',
						tone: 'muted',
						text: _('Внешний')
					});
				}

				var countBadge = E('span', {
					'class': 'badge',
					'style': 'font-size: 12px; margin-left: 6px;'
				}, [ _('%d списков').format(mod.listsCount || 0) ]);

				var toggleBtn = xcmp.button({
					variant: 'vpn',
					primary: true,
					text: isEnabled ? ('⏸️ ' + _('Выключить')) : ('▶️ ' + _('Включить')),
					title: isEnabled ? _('Отключить этот источник') : _('Включить этот источник'),
					onClick: function() {
						self._toggleModule(mod);
					}
				});

				var updateBtn = xcmp.button({
					variant: 'vpn',
					text: '🔄 ' + _('Обновить'),
					title: _('Скачать свежие списки только для этого источника'),
					onClick: function() {
						self._runBgAction(
							_('Обновление источника: %s').format(mod.title || mod.name),
							'updateOne:' + (mod.id || mod.name)
						);
					}
				});

				var viewBtn = xcmp.button({
					variant: 'vpn',
					text: '📑 ' + _('Списки (%d)').format(mod.listsCount || 0),
					title: _('Просмотреть списки внутри источника'),
					onClick: function() {
						self._showListsModal(mod);
					}
				});

				var deleteBtn = canDelete ? xcmp.button({
					variant: 'vpn',
					text: '🗑️ ' + _('Удалить'),
					title: _('Удалить пользовательский источник'),
					style: 'color: var(--bad);',
					onClick: function() {
						self._deleteCustomModule(mod);
					}
				}) : '';

				return xcmp.card({
					variant: 'upstream',
					dimmed: !isEnabled,
					icon: upstreamsUtil.moduleIcon(mod),
					title: mod.title || mod.name,
					badges: [typeBadge, statusBadge],
					description: mod.desc || _('Без описания'),
					meta: [
						E('span', { 'class': 'muted' }, [ _('Всего в источнике:') ]),
						countBadge
					],
					actions: [toggleBtn, updateBtn, viewBtn, deleteBtn]
				});
			});

			cardsContainer = E('div', {
				'class': 'xfree-upstreams-grid',
				'style': 'display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 16px;'
			}, cardEls);
		}

		this.replaceChildren(
			toolbar,
			cardsContainer
		);
	}
});
