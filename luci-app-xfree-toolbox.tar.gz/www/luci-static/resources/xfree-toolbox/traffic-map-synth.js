'use strict';
'require baseclass';

function buildSyntheticPacks(mapInst, opt) {
	var tracing = opt.tracing;
	var dnsStatus = opt.dnsStatus;
	var vpnStatus = opt.vpnStatus;
	var zapStatus = opt.zapStatus;
	var vpnSkipped = opt.vpnSkipped;
	var dnsLayer = opt.dnsLayer;
	var ifaceLayer = opt.ifaceLayer;
	var zapretLayer = opt.zapretLayer;
	var clientLayer = opt.clientLayer;
	var lanSub = opt.lanSub;
	var egressPath = opt.egressPath;
	var dns = opt.dns;
	var iface = opt.iface;
	var zapret = opt.zapret;
	var dnsPack = opt.dnsPack;
	var vpnPack = opt.vpnPack;
	var zapPack = opt.zapPack;

	/* Synthetic outcome chips — list entries alone don't show default/skip */
	if (tracing && dnsStatus === 'default') {
		dnsPack = {
			chips: [
				mapInst._chip({
					kind: 'dns',
					label: _('По умолчанию'),
					active: true,
					title: _('Системный DNS — домена нет в dns-routing'),
					detail: {
						id: 'dns:default',
						navKind: 'dns',
						navScope: '',
						title: _('DNS по умолчанию'),
						rows: [
							{ k: _('Режим'), v: _('default') },
							{ k: _('Причина'), v: _('нет правила в dns-redirects') }
						]
					}
				})
			].concat(mapInst._expanded.dns ? dnsPack.chips : []),
			hidden: mapInst._expanded.dns ? 0 : dns.length
		};
	} else if (tracing && dnsStatus === 'skipped') {
		dnsPack = {
			chips: [
				mapInst._chip({
					kind: 'dns',
					label: _('Пропущен'),
					active: true,
					title: _('DNS-редирект не нужен — домен уходит в VPN'),
					detail: {
						id: 'dns:skipped',
						navKind: 'dns',
						navScope: '',
						title: _('DNS пропущен'),
						rows: [
							{
								k: _('Причина'),
								v: (dnsLayer && dnsLayer.scope && dnsLayer.scope.reason === 'iface-covered')
									? _('покрыто VPN (iface)')
									: ((dnsLayer && dnsLayer.scope && dnsLayer.scope.reason) || _('пропуск'))
							},
							{
								k: _('VPN'),
								v: (ifaceLayer && ifaceLayer.scope && ifaceLayer.scope.iface) || '—'
							}
						]
					}
				})
			].concat(mapInst._expanded.dns ? dnsPack.chips : []),
			hidden: mapInst._expanded.dns ? 0 : dns.length
		};
	}

	if (tracing && vpnStatus === 'bypassed') {
		vpnPack = {
			chips: [
				mapInst._chip({
					kind: 'vpn',
					label: _('Direct WAN'),
					active: true,
					title: _('Обход туннелей — клиент в режиме Direct WAN'),
					detail: {
						id: 'vpn:bypassed',
						navKind: 'vpn',
						navScope: 'vpn.devicepolicy',
						title: _('Обход туннелей (Direct WAN)'),
						rows: [
							{ k: _('Клиент'), v: (clientLayer && clientLayer.scope && (clientLayer.scope.name || clientLayer.scope.ip)) || lanSub || '—' },
							{ k: _('Политика'), v: 'Direct WAN' },
							{ k: _('Причина'), v: (ifaceLayer && ifaceLayer.headline) || _('обход всех туннелей') }
						]
					}
				})
			].concat(mapInst._expanded.vpn ? vpnPack.chips : []),
			hidden: mapInst._expanded.vpn ? 0 : iface.length
		};
	} else if (vpnSkipped) {
		vpnPack = {
			chips: [
				mapInst._chip({
					kind: 'vpn',
					label: _('Пропущен'),
					active: true,
					title: _('Нет VPN-правил для этого домена'),
					detail: {
						id: 'vpn:skipped',
						navKind: 'vpn',
						navScope: '',
						title: _('VPN не используется'),
						rows: [
							{ k: _('Причина'), v: _('домен не в списках туннеля') },
							{ k: _('Egress'), v: egressPath }
						]
					}
				})
			].concat(mapInst._expanded.vpn ? vpnPack.chips : []),
			hidden: mapInst._expanded.vpn ? 0 : iface.length
		};
	}

	if (tracing && zapStatus === 'bypassed') {
		zapPack = {
			chips: [
				mapInst._chip({
					kind: 'zapret',
					label: _('Обход Zapret'),
					active: true,
					title: _('Обход Zapret — десинхронизация отключена для клиента'),
					detail: {
						id: 'zapret:bypassed',
						navKind: 'zapret',
						navScope: 'vpn.devicepolicy',
						title: _('Обход Zapret (Direct WAN)'),
						rows: [
							{ k: _('Клиент'), v: (clientLayer && clientLayer.scope && (clientLayer.scope.name || clientLayer.scope.ip)) || lanSub || '—' },
							{ k: _('Политика'), v: 'Direct WAN' },
							{ k: _('Причина'), v: (zapretLayer && zapretLayer.headline) || _('десинхронизация отключена') }
						]
					}
				})
			].concat(mapInst._expanded.zapret ? zapPack.chips : []),
			hidden: mapInst._expanded.zapret ? 0 : zapret.length
		};
	} else if (tracing && zapStatus === 'none') {
		zapPack = {
			chips: [
				mapInst._chip({
					kind: 'zapret',
					label: _('Пропущен'),
					active: true,
					title: _('Нет секций Zapret для этого домена'),
					detail: {
						id: 'zapret:skipped',
						navKind: 'zapret',
						navScope: '',
						title: _('Zapret не сработал'),
						rows: [
							{ k: _('Причина'), v: _('домен не в списках секций') }
						]
					}
				})
			].concat(mapInst._expanded.zapret ? zapPack.chips : []),
			hidden: mapInst._expanded.zapret ? 0 : zapret.length
		};
	}

	return {
		dnsPack: dnsPack,
		vpnPack: vpnPack,
		zapPack: zapPack
	};
}

return baseclass.extend({
	buildSyntheticPacks: buildSyntheticPacks
});
