'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.traffic-map';
'require xfree-toolbox.vpn-panel';

var TAG = 'xfree-overview';

/* Full SVG markup — LuCI E('svg') + path innerHTML often paints blank. */
var ICONS = {
	profiles: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 4h8a2 2 0 0 1 2 2v14l-6-3-6 3V6a2 2 0 0 1 2-2z"/></svg>',
	routing: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="6" cy="12" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M8 12h6M14 8l4-2M14 16l4 2"/></svg>',
	vpn: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 4.5 3.2 8 8 9 4.8-1 8-4.5 8-9V7z"/><path d="M9.5 12.5 11 14l3.5-3.5"/></svg>',
	zapret: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 7v5c0 5 3.5 8.5 8 9 4.5-.5 8-4 8-9V7z"/></svg>',
	diagnostics: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/><circle cx="12" cy="12" r="3"/><path d="m16.2 7.8 2.1-2.1M5.7 18.3l2.1-2.1M16.2 16.2l2.1 2.1M5.7 5.7l2.1 2.1"/></svg>',
	system: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16v10H4zM8 17v2m8-2v2M9 11h.01M12 11h.01M15 11h.01"/></svg>',
	home: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 11.5 12 4l8 7.5V20a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1z"/></svg>',
	host: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/></svg>',
	temp: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 14.5V5a2 2 0 1 1 4 0v9.5a3.5 3.5 0 1 1-4 0z"/><path d="M12 16v2"/></svg>',
	disk: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/></svg>',
	load: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M9 9h.01M15 9h.01M9 15h6"/></svg>'
};

function statIcon(key) {
	var k = String(key || '').toLowerCase();
	if (k.indexOf('темп') >= 0 || k.indexOf('temp') >= 0) return ICONS.temp;
	if (k.indexOf('диск') >= 0 || k.indexOf('disk') >= 0) return ICONS.disk;
	if (k.indexOf('load') >= 0 || k.indexOf('нагруз') >= 0) return ICONS.load;
	if (k.indexOf('vpn') >= 0 || k.indexOf('туннел') >= 0 || k.indexOf('tunnel') >= 0) return ICONS.vpn;
	return ICONS.host;
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this.requestPaint();
	}

	setBusy(busy) {
		this.querySelectorAll('button').forEach(function(el) {
			el.disabled = !!busy;
		});
	}

	setLoading(loading) {
		if (this._spec)
			this._spec.loading = !!loading;
		this.requestPaint();
	}

	render() {
		var s = this._spec || {};
		var onNavigate = s.onNavigate;
		var view = s.view;
		var hostHint = s.hostHint || '';
		var nodes = [];

		this.className = '';

		/* Use div — LuCI bootstrap styles bare <header> as the dark top navbar. */
		var headLeft = [
			E('p', { 'class': 'eyebrow' }, [ 'XFree toolbox' ]),
			E('h1', {}, [ _('Обзор') ])
		];
		var isRefreshing = !!(s.loading || this._busy);
		var headRight = [
			E('button', {
				'class': 'ghost ghost-compact' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние системы, туннелей и трафика'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				}
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить'))
			])
		];

		nodes.push(E('div', { 'class': 'page-head' }, [
			E('div', { 'class': 'page-head-main' }, headLeft),
			E('div', { 'class': 'page-head-actions', 'style': 'display:flex; align-items:center; gap:8px;' }, [
				E('p', { 'class': 'muted page-head-desc' }, [
					hostHint || _('Профиль, маршруты, VPN и Zapret')
				]),
				headRight[0]
			])
		]));

		/* 1. Top Stats Row (1 card for Tunnels) */
		var statsList = s.stats;
		var isLoadingStats = !!s.loading;
		if ((!statsList || !statsList.length) && isLoadingStats) {
			statsList = [
				{ k: _('Хост'), v: E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 16px;' }) },
				{ k: _('Туннели'), v: E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 45px; height: 16px;' }) },
				{ k: _('Темп.'), v: E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 45px; height: 16px;' }) },
				{ k: _('Диск'), v: E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 55px; height: 16px;' }) },
				{ k: _('Load'), v: E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 50px; height: 16px;' }) },
				{ k: _('Версия'), v: E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 16px;' }) },
				{ k: _('Обновл.'), v: E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 55px; height: 16px;' }) }
			];
		}

		if (statsList && statsList.length) {
			nodes.push(E('section', { 'class': 'stats' + (isLoadingStats ? ' is-loading' : '') }, statsList.map(function(stat) {
				var ico = E('span', { 'class': 'stat-ico', 'aria-hidden': 'true' });
				ico.innerHTML = statIcon(stat.k);
				var statEl = E('div', {
					'class': 'stat' + (isLoadingStats ? ' is-loading' : '') + (stat.route ? ' is-clickable' : ''),
					'style': stat.route ? 'cursor: pointer;' : ''
				}, [
					E('div', { 'class': 'stat-top' }, [
						ico,
						E('div', { 'class': 'k' }, [ stat.k || '' ])
					]),
					E('div', { 'class': 'v' }, [
						stat.v || '—',
						stat.em ? E('em', {}, [ stat.em ]) : ''
					])
				]);
				if (stat.route && onNavigate) {
					statEl.addEventListener('click', function(ev) {
						ev.preventDefault();
						onNavigate(stat.route, stat.tab || '', stat.panel || '');
					});
				}
				return statEl;
			})));
		}

		/* 2. Traffic Map FIRST */
		var mapEl = E('xfree-traffic-map');
		mapEl.mount({
			view: view,
			summary: s.trafficSummary || null,
			onNavigate: onNavigate,
			onTrace: s.onTrace,
			onSuggest: s.onSuggest
		});
		if (s.trafficTrace)
			mapEl.setTrace(s.trafficTrace);

		nodes.push(E('section', { 'class': 'block tm-block' }, [ mapEl ]));

		/* 3. VPN Section AFTER map — reusing xfree-vpn directly */
		var vpnEl = E('xfree-vpn');
		vpnEl.mount({
			view: view,
			loading: !!s.loading,
			expert: xui.menuExpertMode ? xui.menuExpertMode() : false,
			vpnView: 'overview',
			summary: s.vpnSummary || { ifaces: [], warp: {}, proton: {}, count: 0 },
			outputText: '',
			onNavigate: function(routeOrPanel, tab, panel) {
				if (onNavigate) {
					if (arguments.length > 1 || routeOrPanel === 'routing' || routeOrPanel === 'vpn')
						onNavigate(routeOrPanel, tab || '', panel || '');
					else
						onNavigate('vpn', '', routeOrPanel);
				}
			},
			onRefresh: function() {
				if (s.onRefresh)
					s.onRefresh();
			},
			onAction: function(action, arg, confirmText, onDone) {
				if (s.onAction)
					s.onAction(action, arg, confirmText, onDone);
			}
		});

		nodes.push(E('section', { 'class': 'block xfree-overview-vpn-block' }, [ vpnEl ]));

		this.replaceChildren.apply(this, nodes);
	}
});

return baseclass.extend({
	tag: TAG
});
