'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-menu';

var ICONS = {
	routing: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.5 12h5M13.5 8.5l3-2.5M13.5 15.5l3 2.5"/></svg>',
	led: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/><circle cx="12" cy="12" r="4"/></svg>',
	logs: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
	hub: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>',
	update: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>',
	status: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
	action: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="5 3 19 12 5 21 5 3"/></svg>'
};

function getItemIcon(it) {
	if (it.icon && ICONS[it.icon])
		return ICONS[it.icon];
	var id = String(it.id || it.action || '').toLowerCase();
	if (id.indexOf('routing') >= 0 || id.indexOf('tunnel') >= 0) return ICONS.routing;
	if (id.indexOf('led') >= 0) return ICONS.led;
	if (id.indexOf('log') >= 0) return ICONS.logs;
	if (id.indexOf('mgmt') >= 0 || id.indexOf('hub') >= 0) return ICONS.hub;
	if (id.indexOf('updat') >= 0 || id.indexOf('upgrad') >= 0 || id.indexOf('check') >= 0) return ICONS.update;
	if (id.indexOf('status') >= 0) return ICONS.status;
	return ICONS.action;
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this.requestPaint();
	}

	setStatusText(text) {
		var el = this.querySelector('xfree-console.xfree-menu-status');

		if (el) {
			el.text = text || '';
			el.style.display = (text && String(text).trim()) ? '' : 'none';
		}
	}

	setOutputText(text) {
		var el = this.querySelector('xfree-console.xfree-menu-output');

		if (el) {
			el.text = text || '';
			el.style.display = (text && String(text).trim()) ? '' : 'none';
		}
	}

	setBusy(busy) {
		this.querySelectorAll('[data-xfree-menu-item]').forEach(function(btn) {
			btn.disabled = !!busy;
		});
		this.querySelectorAll('.xfree-menu-item').forEach(function(card) {
			if (busy)
				card.classList.add('is-busy');
			else
				card.classList.remove('is-busy');
		});
	}

	render() {
		var s = this._spec || {};
		var node = s.node || {};
		var view = s.view;
		var items = node.items || [];
		var statusText = s.statusText || '';
		var outputText = s.outputText || '';
		var pollSec = s.pollSec || 0;
		var itemVisible = s.itemVisible || function() { return true; };
		var onItem = s.onItem;
		var statusEl;
		var outEl;
		var list = [];
		var i;
		var it;
		var desc = node.hint || '';

		if (pollSec > 0 && node.statusReport)
			desc += (desc ? ' ' : '') + _('Статус сверху обновляется каждые %d с.').format(pollSec);

		this.className = 'xfree-menu-root';
		this.setAttribute('data-xfree-menu', node.id || '');

		for (i = 0; i < items.length; i++) {
			it = items[i];
			if (!itemVisible(it))
				continue;

			var iconEl = E('span', { 'class': 'xfree-menu-item-icon', 'aria-hidden': 'true' });
			iconEl.innerHTML = getItemIcon(it);

			var btnLabel = it.actionLabel || (
				it.kind === 'note'
					? _('Справка')
					: (it.kind === 'report' ? _('Показать') : _('Запустить'))
			);

			var actionBtn = E('span', {
				'class': 'xfree-menu-btn xfree-menu-btn-' + (it.kind || 'action')
			}, [ btnLabel ]);

			list.push(E('button', {
				'class': 'xfree-menu-item' + (it.visibility === 'expert' ? ' is-expert' : ''),
				'type': 'button',
				'data-xfree-menu-item': it.id || String(i),
				'click': ui.createHandlerFn(view, (function(item) {
					return function(ev) {
						ev.preventDefault();
						if (onItem)
							onItem(item);
					};
				})(it))
			}, [
				iconEl,
				E('span', { 'class': 'xfree-menu-item-main' }, [
					E('span', { 'class': 'xfree-menu-item-title' }, [ it.title || it.id ]),
					it.subtitle
						? E('span', { 'class': 'xfree-menu-item-sub' }, [ it.subtitle ])
						: ''
				]),
				E('span', { 'class': 'xfree-menu-item-action' }, [
					it.badge
						? E('span', { 'class': 'xfree-menu-item-badge' }, [ it.badge ])
						: actionBtn
				])
			]));
		}

		statusEl = E('xfree-console', {
			'label': _('Статус'),
			'class': 'xfree-menu-status',
			'style': '--xfree-console-max-height:40vh;' + ((statusText && statusText.trim()) ? '' : 'display:none;')
		});
		statusEl.text = statusText;

		outEl = E('xfree-console', {
			'label': _('Вывод действия'),
			'class': 'xfree-menu-output',
			'style': '--xfree-console-max-height:45vh;' + ((outputText && outputText.trim()) ? '' : 'display:none;')
		});
		outEl.text = outputText;

		this.replaceChildren(
			E('div', { 'class': 'xfree-menu-header' }, [
				E('h3', { 'class': 'xfree-menu-title' }, [ node.title || '' ]),
				desc ? E('p', { 'class': 'muted xfree-menu-desc' }, [ desc ]) : ''
			]),
			(node.statusReport || statusText) ? statusEl : '',
			E('div', { 'class': 'xfree-menu-list' }, list.length ? list : [
				E('p', { 'class': 'muted' }, [ _('Нет доступных пунктов (включите экспертный режим?)') ])
			]),
			outEl
		);
	}
});

return baseclass.extend({
	tag: TAG
});
