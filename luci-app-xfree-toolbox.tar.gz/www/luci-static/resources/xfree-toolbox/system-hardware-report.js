'use strict';
'require baseclass';

/**
 * Парсер текстового отчета hardwareStatus
 * @param {string} text
 * @returns {Object}
 */
function parseHardwareReport(text) {
	var lines = String(text || '').split(/\n/);
	var res = {
		wpsEnabled: false,
		nfcAvailable: false,
		nfcBoard: '',
		nfcBoardName: '',
		ledCount: 0,
		usbPower: {
			board: '',
			backends: {
				xhciMtk: false,
				gpioSwitch: false,
				uhubctl: false
			},
			anyBackendReady: false,
			autoSelect: ''
		},
		rawText: String(text || '')
	};

	for (var i = 0; i < lines.length; i++) {
		var line = lines[i].trim();
		if (!line)
			continue;

		if (line.indexOf('Обновление профиля кнопкой WPS/Mesh: ВКЛЮЧЕНО') !== -1 ||
		    (line.indexOf('WPS/Mesh') !== -1 && line.indexOf('ВКЛЮЧЕНО') !== -1)) {
			res.wpsEnabled = true;
		}

		if (line.indexOf('NFC_BOARD=unsupported') !== -1) {
			res.nfcBoard = 'unsupported';
		} else if (line.indexOf('NFC_BOARD=supported') !== -1) {
			res.nfcBoard = 'supported';
		} else if (line.indexOf('NFC_BOARD=unknown') !== -1) {
			res.nfcBoard = 'unknown';
		}

		var nfcBoardName = line.match(/^NFC_BOARD_NAME=(.*)$/);
		if (nfcBoardName && nfcBoardName[1])
			res.nfcBoardName = nfcBoardName[1].trim();

		if (line.indexOf('NFC_SCRIPT=available') !== -1) {
			res.nfcAvailable = true;
		}

		if (line.indexOf('=== USB power') !== -1) {
			var matchBoard = line.match(/model=(.*?)\)\s*===/);
			if (matchBoard && matchBoard[1]) {
				res.usbPower.board = matchBoard[1].trim();
			} else {
				var matchShort = line.match(/board=([^ ]+)/);
				if (matchShort && matchShort[1])
					res.usbPower.board = matchShort[1].trim();
			}
		}

		if (line.indexOf('xhci-mtk:') !== -1 && line.indexOf('нет') === -1) {
			res.usbPower.backends.xhciMtk = true;
			res.usbPower.anyBackendReady = true;
		}
		if (line.indexOf('gpio-switch:') !== -1 && line.indexOf('нет') === -1) {
			res.usbPower.backends.gpioSwitch = true;
			res.usbPower.anyBackendReady = true;
		}
		if (line.indexOf('uhubctl:') !== -1 && line.indexOf('нет') === -1) {
			res.usbPower.backends.uhubctl = true;
			res.usbPower.anyBackendReady = true;
		}

		if (line.indexOf('Автовыбор:') !== -1) {
			res.usbPower.autoSelect = line.substring(10).trim();
		}

		var mLed = line.match(/^LED_COUNT=([0-9]+)$/);
		if (mLed) {
			res.ledCount = parseInt(mLed[1], 10);
		}
	}

	return res;
}

return baseclass.extend({
	parseHardwareReport: parseHardwareReport
});
