'use strict';
'require baseclass';
'require xfree-toolbox.components as xcmp';

function renderListsTable(options) {
	var modalContainer = options.modalContainer;
	var lists = options.lists || [];
	var matrix = options.matrix;
	var modKey = options.modKey;
	var isCustom = options.isCustom;
	var onShowFileView = options.onShowFileView || function() {};
	var onShowCreateView = options.onShowCreateView || function() {};
	var onShowTargetsView = options.onShowTargetsView || function() {};
	var onDownloadDirect = options.onDownloadDirect || function() {};
	var onDeleteList = options.onDeleteList || function() {};

	function getListTargets(relPath) {
		if (!matrix || !matrix.columns || !matrix.checked) return [];
		var parts = String(relPath || '').split('/');
		var group = parts[0] || '';
		var service = parts.length > 2 ? parts[1] : '';

		var grpTag = 'grp__' + modKey + '__' + group;
		var svcTag = service ? ('svc__' + modKey + '__' + group + '__' + service) : '';

		var activeTargets = [];
		matrix.columns.forEach(function(col) {
			var chk = matrix.checked[col.key];
			if (!Array.isArray(chk)) return;
			var isHit = chk.indexOf(grpTag) !== -1 || (svcTag && chk.indexOf(svcTag) !== -1);
			if (isHit) {
				var icon = (col.target === 'iface') ? '🛡️' : ((col.target === 'dns') ? '🌐' : '⚡');
				var typeName = (col.target === 'iface') ? _('VPN') : ((col.target === 'dns') ? _('DNS') : _('Zapret'));
				activeTargets.push({
					key: col.key,
					target: col.target,
					scope: col.scope || col.label,
					label: col.label || col.scope,
					displayName: icon + ' ' + typeName + ': ' + (col.label || col.scope)
				});
			}
		});
		return activeTargets;
	}

	lists.forEach(function(l) {
		l._targets = getListTargets(l.path);
	});

	var totalUsedCount = lists.filter(function(l) { return l._targets && l._targets.length > 0; }).length;

	var filterInput = E('input', {
		'type': 'text',
		'class': 'cbi-input-text',
		'placeholder': '🔍 ' + _('Фильтр по названию файла (.lst) или цели…'),
		'style': 'flex: 1; min-width: 200px; max-width: 320px; font-size: 13px; height: 32px; padding: 2px 10px; border-radius: 6px;'
	});

	var filterOnlyUsed = false;
	var onlyUsedBtn = xcmp.button({
		variant: 'vpn',
		primary: true,
		text: '🎯 ' + _('Только используемые (%d)').format(totalUsedCount),
		title: _('Показать только списки, которые сейчас выбраны в правилах маршрутизации'),
		style: 'font-size: 12px; padding: 0 10px; height: 32px;' + (totalUsedCount > 0 ? '' : 'display: none;'),
		onClick: function() {
			filterOnlyUsed = !filterOnlyUsed;
			onlyUsedBtn.style.background = filterOnlyUsed ? 'var(--accent-soft)' : '';
			onlyUsedBtn.style.color = filterOnlyUsed ? 'var(--accent)' : '';
			onlyUsedBtn.style.borderColor = filterOnlyUsed ? 'var(--accent)' : '';
			updateRows(filterInput.value);
		}
	});

	var tableBody = E('tbody');

	function updateRows(filterText) {
		var q = String(filterText || '').trim().toLowerCase();
		var filtered = lists.filter(function(l) {
			if (filterOnlyUsed && (!l._targets || !l._targets.length))
				return false;
			if (!q) return true;
			if (l.path.toLowerCase().indexOf(q) !== -1)
				return true;
			if (l._targets && l._targets.some(function(t) { return t.displayName.toLowerCase().indexOf(q) !== -1; }))
				return true;
			return false;
		});

		var rows = [];
		if (!filtered.length) {
			rows.push(E('tr', {}, [
				E('td', { 'colspan': 4, 'class': 'muted', 'style': 'text-align: center; padding: 28px;' }, [
					q ? _('Списки, соответствующие фильтру, не найдены.') : _('В этом источнике пока нет файлов списков.')
				])
			]));
		} else {
			filtered.forEach(function(l) {
				var actions = [];
				var iconBtnStyle = 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px;';

				if (!isCustom) {
					var viewBtn = xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'ghost',
						title: _('Просмотреть список'),
						ariaLabel: _('Просмотреть'),
						style: iconBtnStyle,
						onClick: function() {
							onShowFileView(l.path, true);
						}
					});
					viewBtn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
					actions.push(viewBtn);
				} else {
					var editBtn = xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'ghost',
						title: _('Редактировать список'),
						ariaLabel: _('Редактировать'),
						style: iconBtnStyle,
						onClick: function() {
							onShowFileView(l.path, false);
						}
					});
					editBtn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
					actions.push(editBtn);
				}

				var dlBtn = xcmp.button({
					variant: 'vpn',
					primary: true,
					extraClass: 'ghost',
					title: _('Скачать файл списка (.lst)'),
					ariaLabel: _('Скачать'),
					style: iconBtnStyle,
					onClick: function() {
						onDownloadDirect(l.path);
					}
				});
				dlBtn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>';
				actions.push(dlBtn);

				if (isCustom) {
					var delBtn = xcmp.button({
						variant: 'vpn',
						primary: true,
						extraClass: 'ghost',
						title: _('Удалить список'),
						ariaLabel: _('Удалить'),
						style: iconBtnStyle + ' color: var(--bad);',
						onClick: function() {
							onDeleteList(l.path);
						}
					});
					delBtn.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg>';
					actions.push(delBtn);
				}

				var targets = l._targets || [];
				var usedCell;
				if (targets.length === 0) {
					usedCell = E('td', { 'style': 'text-align: center; width: 110px;' }, [
						E('span', { 'class': 'muted', 'style': 'opacity: 0.5;' }, [ '—' ])
					]);
				} else {
					var tooltipText = _('Используется в:\n') + targets.map(function(t) { return '• ' + t.displayName; }).join('\n');
					usedCell = E('td', { 'style': 'text-align: center; width: 110px;' }, [
						xcmp.button({
							variant: 'vpn',
							primary: true,
							text: '🎯 ' + String(targets.length),
							title: tooltipText,
							ariaLabel: _('Посмотреть где используется'),
							style: 'background: var(--ok-soft); color: var(--ok); border-color: color-mix(in srgb, var(--ok) 40%, transparent); font-weight: 600; font-size: 12px; padding: 2px 8px; border-radius: 12px; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;',
							onClick: function(ev) {
								ev.stopPropagation();
								onShowTargetsView(l.path, targets);
							}
						})
					]);
				}

				rows.push(E('tr', {}, [
					E('td', { 'style': 'font-family: monospace; font-size: 13px; font-weight: 500;' }, [ l.path ]),
					E('td', { 'style': 'text-align: right; width: 110px;' }, [
						E('span', { 'class': 'badge' }, [ _('%d записей').format(l.lines || 0) ])
					]),
					usedCell,
					E('td', { 'style': 'text-align: right; width: 120px; padding-right: 12px; white-space: nowrap;' }, [
						E('div', { 'style': 'display: inline-flex; gap: 4px; justify-content: flex-end; align-items: center;' }, actions)
					])
				]));
			});
		}

		tableBody.replaceChildren.apply(tableBody, rows);
	}

	filterInput.addEventListener('input', function() {
		updateRows(filterInput.value);
	});
	updateRows('');

	var table = E('table', { 'class': 'table xfree-lists-table', 'style': 'width: 100%; margin-top: 8px;' }, [
		E('thead', {}, [
			E('tr', {}, [
				E('th', { 'style': 'text-align: left;' }, [ _('Файл списка (.lst)') ]),
				E('th', { 'style': 'text-align: right; width: 110px; white-space: nowrap;' }, [ _('Количество') ]),
				E('th', { 'style': 'text-align: center; width: 110px; white-space: nowrap;' }, [ _('Используется') ]),
				E('th', { 'style': 'text-align: right; width: 120px; padding-right: 12px; white-space: nowrap;' }, [ _('Действия') ])
			])
		]),
		tableBody
	]);

	var topBar;
	if (isCustom) {
		topBar = E('div', {
			'style': 'display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; flex-wrap: wrap; gap: 8px;' }, [
				E('span', { 'class': 'badge', 'style': 'background: var(--accent-soft); color: var(--accent);' }, [ '👤 ' + _('Пользовательский') ]),
				filterInput,
				onlyUsedBtn
			]),
			xcmp.button({
				variant: 'vpn',
				primary: true,
				text: '➕ ' + _('Добавить список'),
				style: 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px;',
				onClick: function() {
					onShowCreateView();
				}
			})
		]);
	} else {
		topBar = E('div', {
			'style': 'display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; flex-wrap: wrap; gap: 8px;' }, [
				E('span', { 'class': 'badge' }, [ '🔒 ' + _('Только чтение') ]),
				filterInput,
				onlyUsedBtn
			]),
			E('span', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
				_('Предустановленные списки защищены от редактирования.')
			])
		]);
	}

	modalContainer.replaceChildren(
		topBar,
		E('div', { 'style': 'max-height: 55vh; overflow-y: auto;' }, [ table ])
	);
}

return baseclass.extend({
	renderListsTable: renderListsTable
});
