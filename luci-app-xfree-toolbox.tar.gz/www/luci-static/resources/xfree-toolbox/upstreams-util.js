'use strict';
'require baseclass';

function moduleIcon(mod) {
	var name = String((mod && (mod.id || mod.name)) || '').toLowerCase();
	var title = String((mod && mod.title) || '').toLowerCase();
	if (name === 'user' || name === 'xfree' || title === 'xfree') return '🧰';
	if (mod && mod.custom) return '👤';
	if (name.indexOf('allow') >= 0 || name.indexOf('domain') >= 0) return '🌐';
	if (name.indexOf('rekryt') >= 0 || name.indexOf('iplist') >= 0) return '📑';
	if (name.indexOf('vpn') >= 0 || name.indexOf('proton') >= 0) return '🛡️';
	return '📦';
}

function slugify(text) {
	var ruMap = {
		'а':'a', 'б':'b', 'в':'v', 'г':'g', 'д':'d', 'е':'e', 'ё':'yo', 'ж':'zh',
		'з':'z', 'и':'i', 'й':'y', 'к':'k', 'л':'l', 'м':'m', 'н':'n', 'о':'o',
		'п':'p', 'р':'r', 'с':'s', 'т':'t', 'у':'u', 'ф':'f', 'х':'h', 'ц':'ts',
		'ч':'ch', 'ш':'sh', 'щ':'sch', 'ъ':'', 'ы':'y', 'ь':'', 'э':'e', 'ю':'yu',
		'я':'ya'
	};
	var s = String(text || '').trim().toLowerCase();
	var out = '';
	for (var i = 0; i < s.length; i++) {
		var c = s.charAt(i);
		if (ruMap[c] !== undefined) {
			out += ruMap[c];
		} else if (/[a-z0-9]/.test(c)) {
			out += c;
		} else if (c === '-' || c === '_' || c === '.') {
			out += c;
		} else if (/\s/.test(c)) {
			out += '-';
		}
	}
	return out.replace(/-+/g, '-').replace(/^[._-]+|[._-]+$/g, '');
}

return baseclass.extend({
	moduleIcon: moduleIcon,
	slugify: slugify
});
