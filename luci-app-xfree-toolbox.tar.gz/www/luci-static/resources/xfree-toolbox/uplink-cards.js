'use strict';
'require baseclass';

/* Разбор строк статуса и карточки туннелей/DNS экрана uplink.
 * Методы вешаются на прототип xfree-uplink. */

function evalTone(runtime) {
	var ev = String((runtime && runtime.last_probe_eval) || '');

	if (ev === '0')
		return 'ok';
	if (ev === '1')
		return 'bad';
	if (ev === '2')
		return 'warn';
	return 'muted';
}

function parseTunnelDetail(rawStatus, text) {
	var s = String(text || '').trim();
	var out = {
		rawStatus: rawStatus || '—',
		ok: /^OK$/i.test(rawStatus),
		paused: '',
		probe: '',
		probeOk: null,
		ping: '',
		pingOk: null,
		hs: '',
		hsOk: null,
		failCount: '',
		failMax: '',
		bounceCount: '',
		bounceMax: '',
		lastAction: '',
		isProtonGuest: false,
		guestSess: '',
		guestCert: ''
	};

	var m;
	if ((m = s.match(/paused\s*(?:\(([^)]+)\))?/i))) {
		out.paused = m[1] || 'paused';
	}

	if ((m = s.match(/\b(?:probe|ping)=([A-Za-z0-9—]+)/i))) {
		out.probe = m[1];
		out.probeOk = /^ok$/i.test(m[1]) ? true : (/^fail$/i.test(m[1]) ? false : null);
		out.ping = out.probe;
		out.pingOk = out.probeOk;
	}

	if ((m = s.match(/\bhs=([A-Za-z0-9—]+)/i))) {
		out.hs = m[1];
		out.hsOk = /^ok$/i.test(m[1]) ? true : (/^fail$/i.test(m[1]) ? false : null);
	}

	if ((m = s.match(/\bfail=([0-9]+)\/([0-9]+)/))) {
		out.failCount = m[1];
		out.failMax = m[2];
	}

	if ((m = s.match(/\bbounce=([0-9]+)\/([0-9]+)/))) {
		out.bounceCount = m[1];
		out.bounceMax = m[2];
	}

	if ((m = s.match(/\blast=([A-Za-z0-9_-]+)/))) {
		if (m[1] !== 'none') {
			out.lastAction = m[1];
		}
	}

	if (/\bproton=guest\b/i.test(s)) {
		out.isProtonGuest = true;
	}

	if ((m = s.match(/\bsess=([A-Za-z0-9_-]+)/))) {
		out.guestSess = m[1];
	}

	if ((m = s.match(/\bcert=([0-9]{4})-([0-9]{2})-([0-9]{2})/))) {
		out.guestCert = m[3] + '.' + m[2] + '.' + m[1];
	}

	return out;
}

function parseTunnelLines(text) {
	var lines = String(text || '').split(/\n/);
	var out = [];
	var i;
	var m;

	for (i = 0; i < lines.length; i++) {
		m = lines[i].match(/^\s*-\s*([A-Za-z0-9._-]+)\s*:\s*(\S+)(?:\s+(.*))?$/);
		if (!m)
			continue;
		var rawStatus = m[2];
		var detail = String(m[3] || '');
		out.push({
			name: m[1],
			ok: /^OK$/i.test(rawStatus) ? 1 : 0,
			detail: detail,
			info: parseTunnelDetail(rawStatus, detail)
		});
	}

	return out;
}

function renderTunnelCard(tunnel) {
	var info = tunnel.info || {};
	var name = tunnel.name;
	var isOk = !!tunnel.ok;
	var tone = isOk ? 'ok' : (info.paused ? 'warn' : 'bad');

	var icon = '🌐';
	var typeName = '';
	if (/proton/i.test(name)) {
		icon = '🛡️';
		typeName = 'Proton VPN';
	} else if (/warp/i.test(name)) {
		icon = '⚡';
		typeName = 'Cloudflare WARP';
	}

	var statusLabel = isOk ? 'OK' : (info.paused ? _('Пауза (%s)').format(info.paused) : _('Сбой'));

	var metrics = [];
	var probeVal = info.probe || info.ping || '—';
	var probeOk = (info.probeOk != null) ? info.probeOk : info.pingOk;
	var probeDisplay = probeVal === '—' ? '—' : probeVal.toUpperCase();
	metrics.push(E('div', {
		'class': 'xfree-tunnel-pill' + (probeOk === true ? ' is-ok' : (probeOk === false ? ' is-bad' : ' is-muted')),
		'title': (probeVal === '—' || /^skip$/i.test(probeVal)) ? _('Проба пропущена (handshake не готов или пауза)') : ''
	}, [
		E('span', { 'class': 'pill-k' }, [ 'Probe' ]),
		E('span', { 'class': 'pill-v' }, [ probeDisplay ])
	]));

	var hsVal = info.hs || '—';
	var hsDisplay = hsVal === '—' ? '—' : hsVal.toUpperCase();
	metrics.push(E('div', {
		'class': 'xfree-tunnel-pill' + (info.hsOk === true ? ' is-ok' : (info.hsOk === false ? ' is-bad' : ' is-muted'))
	}, [
		E('span', { 'class': 'pill-k' }, [ 'Handshake' ]),
		E('span', { 'class': 'pill-v' }, [ hsDisplay ])
	]));

	var diag = [];
	if (info.failCount && (info.failCount !== '0' || !isOk)) {
		diag.push(E('span', { 'class': 'xfree-tunnel-diag-item is-bad' }, [
			E('span', { 'class': 'diag-k' }, [ _('Сбои:') ]),
			E('span', { 'class': 'diag-v' }, [ info.failCount + '/' + info.failMax ])
		]));
	}

	if (info.bounceCount && info.bounceCount !== '0') {
		diag.push(E('span', { 'class': 'xfree-tunnel-diag-item is-warn' }, [
			E('span', { 'class': 'diag-k' }, [ _('Рестарты:') ]),
			E('span', { 'class': 'diag-v' }, [ info.bounceCount + '/' + info.bounceMax ])
		]));
	}

	if (info.lastAction) {
		var actText = info.lastAction === 'bounce' ? _('рестарт') :
		              info.lastAction === 'guest-renew' ? _('renew ключа') :
		              info.lastAction;
		diag.push(E('span', { 'class': 'xfree-tunnel-diag-item is-warn' }, [
			E('span', { 'class': 'diag-k' }, [ _('Действие:') ]),
			E('span', { 'class': 'diag-v' }, [ actText ])
		]));
	}

	var footer = null;
	if (info.isProtonGuest) {
		footer = E('div', { 'class': 'xfree-uplink-tunnel-footer muted' }, [
			E('span', {
				'class': 'xfree-tunnel-session-badge',
				'title': info.guestSess ? _('Сессия: %s').format(info.guestSess) : ''
			}, [
				'🔑 ', _('Proton Guest')
			]),
			info.guestCert ? E('span', { 'class': 'xfree-tunnel-cert-date' }, [
				_('сертификат до %s').format(info.guestCert)
			]) : ''
		]);
	}

	return E('div', {
		'class': 'xfree-uplink-tunnel is-' + tone
	}, [
		E('div', { 'class': 'xfree-uplink-tunnel-top' }, [
			E('div', { 'class': 'xfree-uplink-tunnel-name-wrap' }, [
				E('span', { 'class': 'xfree-uplink-tunnel-ico' }, [ icon ]),
				E('strong', { 'class': 'xfree-uplink-tunnel-name' }, [ name ]),
				typeName ? E('span', { 'class': 'xfree-uplink-tunnel-tag muted' }, [ typeName ]) : ''
			]),
			E('span', { 'class': 'xfree-uplink-tunnel-status is-' + tone }, [
				E('span', { 'class': 'dot' }),
				statusLabel
			])
		]),
		E('div', { 'class': 'xfree-uplink-tunnel-metrics' }, metrics),
		diag.length ? E('div', { 'class': 'xfree-uplink-tunnel-diag' }, diag) : '',
		footer || ''
	]);
}

function renderDnsHostCard(item) {
	var isOk = item.status === 'ok';
	var isBad = item.status === 'fail';
	var tone = isOk ? 'ok' : (isBad ? 'bad' : 'muted');
	var statusLabel = isOk ? 'OK' : (isBad ? _('FAIL') : '—');

	var pills = [];
	if (item.dns) {
		pills.push(E('div', { 'class': 'xfree-tunnel-pill' }, [
			E('span', { 'class': 'pill-k' }, [ 'DNS' ]),
			E('span', { 'class': 'pill-v' }, [ item.dns ])
		]));
	}
	if (item.route) {
		pills.push(E('div', {
			'class': 'xfree-tunnel-pill' + (/vpn/i.test(item.route) ? ' is-ok' : '')
		}, [
			E('span', { 'class': 'pill-k' }, [ _('Маршрут') ]),
			E('span', { 'class': 'pill-v' }, [ item.route ])
		]));
	}

	return E('div', {
		'class': 'xfree-uplink-tunnel is-' + tone
	}, [
		E('div', { 'class': 'xfree-uplink-tunnel-top' }, [
			E('div', { 'class': 'xfree-uplink-tunnel-name-wrap' }, [
				E('span', { 'class': 'xfree-uplink-tunnel-ico' }, [ '🌐' ]),
				E('strong', { 'class': 'xfree-uplink-tunnel-name' }, [ item.host ]),
				E('span', { 'class': 'xfree-uplink-tunnel-tag muted' }, [ _('DNS') ])
			]),
			E('span', { 'class': 'xfree-uplink-tunnel-status is-' + tone }, [
				E('span', { 'class': 'dot' }),
				statusLabel
			])
		]),
		pills.length ? E('div', { 'class': 'xfree-uplink-tunnel-metrics' }, pills) : ''
	]);
}

function renderTunnelSkeleton() {
	return E('div', { 'class': 'xfree-uplink-tunnel is-skeleton' }, [
		E('div', { 'class': 'xfree-uplink-tunnel-top' }, [
			E('div', { 'class': 'xfree-uplink-tunnel-name-wrap' }, [
				E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 80px; height: 16px;' })
			]),
			E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 45px; height: 18px;' })
		]),
		E('div', { 'class': 'xfree-uplink-tunnel-metrics' }, [
			E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 70px; height: 22px;' }),
			E('span', { 'class': 'xfree-skeleton-pill', 'style': 'width: 85px; height: 22px;' })
		])
	]);
}

return baseclass.extend({
	_evalTone: function (runtime) {
		return evalTone(runtime);
	},

	_parseTunnelDetail: function (rawStatus, text) {
		return parseTunnelDetail(rawStatus, text);
	},

	_parseTunnelLines: function (text) {
		return parseTunnelLines(text);
	},

	_renderTunnelCard: function (tunnel) {
		return renderTunnelCard(tunnel);
	},

	_renderDnsHostCard: function (item) {
		return renderDnsHostCard(item);
	},

	_renderTunnelSkeleton: function () {
		return renderTunnelSkeleton();
	}
});
