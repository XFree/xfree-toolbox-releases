'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.console-output';
'require xfree-toolbox.vpn-server-state as serverState';
'require xfree-toolbox.vpn-server-peers as serverPeers';
'require xfree-toolbox.vpn-server-endpoint as serverEndpoint';
'require xfree-toolbox.vpn-server-identity as serverIdentity';
'require xfree-toolbox.vpn-server-nat as serverNat';
'require xfree-toolbox.vpn-server-freeterm as serverFreeTurn';
'require xfree-toolbox.vpn-server-vkturn as serverVkTurn';
'require xfree-toolbox.vpn-server-peer-cards as serverPeerCards';
'require xfree-toolbox.vpn-server-section as serverSection';

/* Экран VPN-сервера. Диалоги и секция пиров живут в соседних модулях
 * и вешаются на один прототип тега xfree-vpn-server. */

var TAG = 'xfree-vpn-server';

var ServerPanel = class extends wc.LightElement {
};

function mixServer(part) {
	prototypeMix.mixInto(ServerPanel.prototype, part);
}

mixServer(serverState);
mixServer(serverPeers);
mixServer(serverEndpoint);
mixServer(serverIdentity);
mixServer(serverNat);
mixServer(serverFreeTurn);
mixServer(serverVkTurn);
mixServer(serverPeerCards);
mixServer(serverSection);

wc.define(TAG, ServerPanel);

return baseclass.extend({
	TAG: TAG
});
