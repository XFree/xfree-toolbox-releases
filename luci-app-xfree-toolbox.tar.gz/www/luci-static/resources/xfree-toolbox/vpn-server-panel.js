'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-vpn-server';

function formatBytes(bytes) {
	var b = Number(bytes);
	if (!isFinite(b) || b <= 0) return '0 B';
	var units = ['B', 'KB', 'MB', 'GB', 'TB'];
	var i = Math.min(Math.floor(Math.log(b) / Math.log(1024)), units.length - 1);
	var v = b / Math.pow(1024, i);
	return (v >= 100 ? v.toFixed(0) : v.toFixed(1)) + ' ' + units[i];
}

function formatHandshake(ts) {
	var t = Number(ts);
	if (!isFinite(t) || t <= 0) return _('никогда');
	var now = Math.floor(Date.now() / 1000);
	var diff = Math.max(0, now - t);
	if (diff < 60) return diff + ' ' + _('сек назад');
	var m = Math.floor(diff / 60);
	if (m < 60) return m + ' ' + _('мин назад');
	var h = Math.floor(m / 60);
	if (h < 24) return h + ' ' + _('ч назад');
	var d = Math.floor(h / 24);
	return d + ' ' + _('дн назад');
}

function copyToClipboard(text, btn) {
	if (!text) return;
	var done = function () {
		if (btn && btn.textContent) {
			var orig = btn.textContent;
			btn.textContent = _('Скопировано!');
			setTimeout(function () { btn.textContent = orig; }, 1500);
		}
	};
	if (navigator && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
		navigator.clipboard.writeText(text).then(done).catch(function () {
			fallbackCopy(text);
			done();
		});
	} else {
		fallbackCopy(text);
		done();
	}
}

function fallbackCopy(text) {
	var ta = document.createElement('textarea');
	ta.value = text;
	ta.style.position = 'fixed';
	ta.style.top = '0';
	ta.style.left = '0';
	ta.style.opacity = '0';
	document.body.appendChild(ta);
	ta.focus();
	ta.select();
	try { document.execCommand('copy'); } catch { /* ignore */ }
	document.body.removeChild(ta);
}

function downloadTextFile(filename, text) {
	var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
	var url = URL.createObjectURL(blob);
	var a = document.createElement('a');
	a.href = url;
	a.download = filename || 'download.txt';
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	setTimeout(function () { URL.revokeObjectURL(url); }, 500);
}

function slugifyPeerName(name) {
	var ru = {
		'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'e', 'ж': 'zh', 'з': 'z', 'и': 'i',
		'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't',
		'у': 'u', 'ф': 'f', 'х': 'h', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch', 'ъ': '', 'ы': 'y', 'ь': '',
		'э': 'e', 'ю': 'yu', 'я': 'ya'
	};
	var res = '';
	var lower = String(name || '').trim().toLowerCase();
	for (var i = 0; i < lower.length; i++) {
		var ch = lower[i];
		if (ru[ch] !== undefined) {
			res += ru[ch];
		} else if (/[a-z0-9_-]/.test(ch)) {
			res += ch;
		} else if (/\s/.test(ch)) {
			res += '-';
		}
	}
	return res.replace(/-+/g, '-').replace(/^[-_]+|[-_]+$/g, '');
}

function extractConfBody(stdout) {
	if (!stdout) return '';
	var m = stdout.match(/CONF_BODY_BEGIN\r?\n([\s\S]*?)\r?\nCONF_BODY_END/);
	if (m && m[1]) return m[1].trim();
	return stdout.trim();
}

function loadUqr() {
	if (window.UqrClass)
		return Promise.resolve(window.UqrClass);
	if (window.L && typeof window.L.require === 'function') {
		return window.L.require('uqr').then(function (Uqr) {
			window.UqrClass = Uqr;
			return Uqr;
		}).catch(function (err) {
			console.warn('uqr load error:', err);
			return null;
		});
	}
	return Promise.resolve(null);
}

function renderQrSvg(uqrEngine, text) {
	if (!uqrEngine || !text)
		return null;
	var rawSvg = null;
	var opts = {
		pixelSize: 4,
		whiteColor: '#ffffff',
		blackColor: '#000000',
		ecc: 'M',
		border: 4
	};
	try {
		if (typeof uqrEngine.renderSVG === 'function') {
			rawSvg = uqrEngine.renderSVG(text, opts);
		} else if (typeof uqrEngine === 'function') {
			var inst = new uqrEngine();
			if (typeof inst.renderSVG === 'function') {
				rawSvg = inst.renderSVG(text, opts);
			}
		}
	} catch (e) {
		console.warn('uqr renderSVG error:', e);
	}

	if (!rawSvg)
		return null;

	var m = rawSvg.match(/<svg\s+([^>]*?)>/i);
	if (!m)
		return rawSvg;

	var tagContent = m[1];
	if (/viewBox=/i.test(tagContent))
		return rawSvg;

	var wMatch = tagContent.match(/width="([^"]+)"/i);
	var hMatch = tagContent.match(/height="([^"]+)"/i);
	var w = wMatch ? parseFloat(wMatch[1]) : 0;
	var h = hMatch ? parseFloat(hMatch[1]) : 0;

	if (w > 0 && h > 0) {
		var newTag = '<svg ' + tagContent + ' viewBox="0 0 ' + w + ' ' + h + '">';
		return rawSvg.replace(m[0], newTag);
	}
	return rawSvg;
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._view = spec.view || null;
		this._awgSummary = spec.awgSummary || {};
		this._loading = !!spec.loading;
		this._busy = false;
		this._msg = spec.message || '';
		this._msgTone = spec.messageTone || '';
		this._natChecking = false;
		this._natCheckResult = null;

		var hasData = this._awgSummary && (this._awgSummary.iface || this._awgSummary.running != null);
		if (!hasData && !this._loading) {
			this.reload();
		} else {
			this.requestPaint();
		}
	}

	reload() {
		var self = this;
		this._loading = true;
		this.requestPaint();

		return xui.runAwgMenu('status').then(function (res) {
			self._awgSummary = xui.parseAwgStatus(res);
			self._loading = false;
			self.requestPaint();
		}).catch(function (err) {
			self._loading = false;
			self._msg = (err && err.message) || String(err);
			self._msgTone = 'bad';
			self.requestPaint();
		});
	}

	setAwgSummary(data) {
		this._awgSummary = data || {};
		this._loading = false;
		this.requestPaint();
	}

	setBusy(val) {
		this._busy = !!val;
		this.requestPaint();
	}

	setLoading(val) {
		this._loading = !!val;
		this.requestPaint();
	}

	setMessage(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var msgEl = this.querySelector('[data-xfree-vpn-msg]');
		if (msgEl) {
			msgEl.className = 'xfree-vpn-msg' + (tone ? ' is-' + tone : '');
			msgEl.textContent = text || '';
		}
	}

	_showVpnDialog(title, content) {
		return ui.showModal(title, content);
	}

	_act(ev, action, arg, confirmOpts) {
		var s = this._spec || {};
		if (ev && typeof ev.preventDefault === 'function')
			ev.preventDefault();

		if (!s.onAction)
			return;

		if (confirmOpts && typeof confirmOpts === 'object') {
			var dialogContent = [
				E('p', { 'style': 'font-size: 14px; margin-bottom: 8px;' }, [confirmOpts.message || _('Выполнить действие?')]),
				confirmOpts.detail ? E('p', { 'class': 'muted', 'style': 'font-size: 12px; margin-bottom: 12px; line-height: 1.4;' }, [confirmOpts.detail]) : ''
			];

			var confirmBtn = E('button', {
				'class': 'btn ' + (confirmOpts.tone === 'danger' ? 'is-bad' : 'is-primary'),
				'type': 'button',
				'click': function () {
					ui.hideModal();
					s.onAction(action, arg, '');
				}
			}, [confirmOpts.confirmText || _('Подтвердить')]);

			var cancelBtn = E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': function () { ui.hideModal(); }
			}, [_('Отмена')]);

			var actionsBar = E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px;' }, [
				cancelBtn,
				confirmBtn
			]);

			ui.showModal(confirmOpts.title || _('Подтверждение'), [
				E('div', {}, dialogContent),
				actionsBar
			]);
		} else if (typeof confirmOpts === 'string' && confirmOpts) {
			s.onAction(action, arg, confirmOpts);
		} else {
			s.onAction(action, arg, '');
		}
	}

	_openPeerConfigDialog(peer, initialTab) {
		var self = this;
		var s = this._spec || {};
		self.setBusy(true);

		if (!s.onAction) {
			self.setBusy(false);
			return;
		}

		s.onAction('peerShowConfig', peer.slug, '', function (res, report) {
			self.setBusy(false);
			if (!res || res.code !== 0) {
				self.setMessage(_('Не удалось получить конфигурацию клиента: %s').format(report || ''), 'bad');
				return;
			}

			var confText = extractConfBody(res.stdout);
			if (!confText) {
				self.setMessage(_('Конфигурация клиента пуста'), 'warn');
				return;
			}

			loadUqr().then(function (Uqr) {
				var filename = (peer.slug || peer.name || 'client') + '.conf';
				var localSvg = renderQrSvg(Uqr, confText);
				var activeTab = (initialTab === 'conf') ? 'conf' : 'qr';

				var metaRow = E('div', {
					'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; font-size: 13px;'
				}, [
					E('div', {}, [
						E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'margin-right: 8px;' }, [peer.ip || '']),
						E('span', { 'class': 'muted' }, [_('Endpoint: ') + (peer.endpoint || 'default')])
					]),
					peer.keepalive ? E('span', { 'class': 'muted font-mono', 'style': 'font-size: 11px;' }, [_('keepalive: %ds').format(peer.keepalive)]) : ''
				]);

				var qrPaneChildren = [];
				if (localSvg) {
					var qrWrap = E('div', { 'class': 'xfree-vpn-qr-wrap' });
					qrWrap.innerHTML = localSvg;
					qrPaneChildren.push(qrWrap);
					qrPaneChildren.push(E('p', {
						'class': 'muted',
						'style': 'text-align: center; margin: 6px 0 10px 0; font-size: 12px;'
					}, [_('Отсканируйте камерой в мобильном приложении AmneziaWG или WireGuard')]));
				} else {
					qrPaneChildren.push(E('div', {
						'class': 'alert-message warning',
						'style': 'margin: 16px 0;'
					}, [
						_('Не удалось сгенерировать QR-код (модуль uqr недоступен). Используйте вкладку «Конфиг» для скачивания файла .conf или копирования настроек.')
					]));
				}

				var qrPane = E('div', { 'class': 'xfree-dialog-tab-pane' }, qrPaneChildren);

				var confTextArea = E('textarea', {
					'class': 'xfree-vpn-conf-textarea',
					'readonly': 'readonly',
					'rows': 9,
					'style': 'margin-bottom: 6px;'
				}, [confText]);

				var confPane = E('div', { 'class': 'xfree-dialog-tab-pane' }, [
					confTextArea,
					E('p', { 'class': 'muted', 'style': 'margin: 4px 0 8px 0; font-size: 12px;' }, [
						_('Импортируйте этот файл конфигурации в приложение AmneziaWG на компьютере или смартфоне.')
					])
				]);

				var tabQrBtn = E('button', {
					'class': 'xfree-dialog-tab-btn' + (activeTab === 'qr' ? ' is-active' : ''),
					'type': 'button',
					'click': function () { switchTab('qr'); }
				}, ['📱 ' + _('QR-код')]);

				var tabConfBtn = E('button', {
					'class': 'xfree-dialog-tab-btn' + (activeTab === 'conf' ? ' is-active' : ''),
					'type': 'button',
					'click': function () { switchTab('conf'); }
				}, ['📄 ' + _('Конфиг (.conf)')]);

				var tabsBar = E('div', { 'class': 'xfree-dialog-tabs' }, [tabQrBtn, tabConfBtn]);

				function switchTab(tab) {
					activeTab = tab;
					if (tab === 'qr') {
						tabQrBtn.classList.add('is-active');
						tabConfBtn.classList.remove('is-active');
						qrPane.style.display = 'block';
						confPane.style.display = 'none';
					} else {
						tabQrBtn.classList.remove('is-active');
						tabConfBtn.classList.add('is-active');
						qrPane.style.display = 'none';
						confPane.style.display = 'block';
					}
				}

				switchTab(activeTab);

				var copyBtn = E('button', {
					'class': 'btn ghost-compact is-primary',
					'type': 'button',
					'style': 'margin-right: 8px;',
					'click': function (ev) {
						copyToClipboard(confText, ev.target);
					}
				}, ['📋 ' + _('Скопировать')]);

				var downloadBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'style': 'margin-right: 8px;',
					'click': function () {
						downloadTextFile(filename, confText);
					}
				}, ['💾 ' + _('Скачать .conf')]);

				var closeBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function () { ui.hideModal(); }
				}, [_('Закрыть')]);

				var buttonsBar = E('div', { 'style': 'display: flex; justify-content: flex-end; margin-top: 14px;' }, [
					copyBtn,
					downloadBtn,
					closeBtn
				]);

				var modalBody = [
					metaRow,
					tabsBar,
					qrPane,
					confPane,
					buttonsBar
				];

				self._showVpnDialog(_('Клиент «%s»').format(peer.name), modalBody);
			});
		});
	}

	_openPeerFreeTurnDialog(peer, awg) {
		var self = this;
		var s = this._spec || {};
		self.setBusy(true);

		if (!s.onAction) {
			self.setBusy(false);
			return;
		}

		s.onAction('peerFreeTurnConfig', peer.slug, '', function (res, report) {
			self.setBusy(false);
			if (!res || res.code !== 0) {
				var errMsg = _('Не удалось сформировать ссылку FreeTurn: %s').format(report || (res && res.stderr) || '');
				self.setMessage(errMsg, 'bad');
				ui.addNotification(null, E('p', errMsg), 'danger');
				return;
			}

			var stdout = res.stdout || '';
			var m = stdout.match(/(freeturn:\/\/[^\s\r\n"']+)/);
			var freeturnUri = m ? m[1] : '';

			if (!freeturnUri) {
				var noUriMsg = _('В выводе скрипта не найдена ссылка freeturn://');
				self.setMessage(noUriMsg, 'bad');
				ui.addNotification(null, E('p', noUriMsg), 'danger');
				return;
			}

			Promise.resolve(loadUqr()).catch(function () { return null; }).then(function (Uqr) {
				try {
					var localSvg = renderQrSvg(Uqr, freeturnUri);

					var metaRow = E('div', {
						'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; font-size: 13px;'
					}, [
						E('div', {}, [
							E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'margin-right: 8px;' }, [peer.ip || '']),
							E('span', { 'class': 'muted' }, [_('Порт FreeTurn: ') + ((awg && awg.freeTurnPort) || '56000') + ' (UDP)'])
						]),
						E('span', { 'class': 'xfree-vpn-status is-ok', 'style': 'font-size: 11px;' }, [_('FreeTurn v5 ready')])
					]);

					var qrPaneChildren = [];
					if (localSvg) {
						var qrWrap = E('div', { 'class': 'xfree-vpn-qr-wrap' });
						qrWrap.innerHTML = localSvg;
						qrPaneChildren.push(qrWrap);
						qrPaneChildren.push(E('p', {
							'class': 'muted',
							'style': 'text-align: center; margin: 6px 0 10px 0; font-size: 12px;'
						}, [_('Отсканируйте камерой в Android-приложении turn-proxy-android (кнопка «+» ➔ «Сканировать QR-код» на вкладке «Соединение»)')]));
					} else {
						qrPaneChildren.push(E('div', {
							'class': 'alert-message warning',
							'style': 'margin: 16px 0;'
						}, [
							_('Не удалось сгенерировать QR-код (модуль uqr недоступен). Скопируйте ссылку ниже.')
						]));
					}

					var uriTextArea = E('textarea', {
						'class': 'xfree-vpn-conf-textarea',
						'readonly': 'readonly',
						'rows': 3,
						'style': 'margin-bottom: 6px; word-break: break-all; font-family: monospace; font-size: 11px;'
					}, [freeturnUri]);

					var linkPane = E('div', { 'style': 'margin-top: 10px;' }, [
						E('label', { 'style': 'font-size: 12px; font-weight: bold; margin-bottom: 4px; display: block;' }, [
							_('Ссылка для импорта в приложение (freeturn://):')
						]),
						uriTextArea,
						E('p', { 'class': 'muted', 'style': 'margin: 4px 0 8px 0; font-size: 12px;' }, [
							_('В приложении turn-proxy-android нажмите «+» ➔ «Вставить ссылку». Адрес роутера, порт 56000, ключ обфускации и ключи клиента подставятся автоматически.')
						])
					]);

					var copyBtn = E('button', {
						'class': 'btn ghost-compact is-primary',
						'type': 'button',
						'style': 'margin-right: 8px;',
						'click': function (ev) {
							copyToClipboard(freeturnUri, ev.target);
						}
					}, ['📋 ' + _('Скопировать ссылку')]);

					var closeBtn = E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function () { ui.hideModal(); }
					}, [_('Закрыть')]);

					var buttonsBar = E('div', { 'style': 'display: flex; justify-content: flex-end; margin-top: 14px;' }, [
						copyBtn,
						closeBtn
					]);

					var modalBody = [
						metaRow,
						E('div', { 'class': 'xfree-dialog-tab-pane' }, qrPaneChildren),
						linkPane,
						buttonsBar
					];

					self._showVpnDialog(_('FreeTurn подключение «%s»').format(peer.name), modalBody);
				} catch (diagErr) {
					var renderErr = _('Ошибка отображения диалога FreeTurn: %s').format(diagErr.message || String(diagErr));
					self.setMessage(renderErr, 'bad');
					ui.addNotification(null, E('p', renderErr), 'danger');
				}
			});
		});
	}

	_openAddPeerDialog(awg) {
		var self = this;
		var s = this._spec || {};
		var nameInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'placeholder': 'client3, sveta, iphone...',
			'style': 'width: 100%; margin-top: 4px;'
		});

		var epOpts = [
			E('option', { 'value': '' }, [_('Default Endpoint сервера (%s)').format(awg.defaultEndpoint || 'WAN')])
		];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [choices[i].label]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'placeholder': _('Или укажите хост:порт вручную (необязательно)'),
			'style': 'width: 100%; margin-top: 6px;'
		});

		var nameHint = E('p', { 'class': 'muted', 'style': 'font-size: 11px; margin-top: 4px;' }, [
			_('Только латиница, цифры, дефис и подчёркивание')
		]);
		nameInput.addEventListener('input', function () {
			var val = nameInput.value || '';
			var slug = slugifyPeerName(val);
			if (slug && slug !== val) {
				nameHint.textContent = _('Имя для системы: %s').format(slug);
			} else {
				nameHint.textContent = _('Только латиница, цифры, дефис и подчёркивание');
			}
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('label', { 'style': 'font-weight: 600;' }, [_('Имя клиента:')]),
				nameInput,
				nameHint
			]),
			E('div', { 'style': 'margin-bottom: 16px;' }, [
				E('label', { 'style': 'font-weight: 600;' }, [_('Endpoint подключения:')]),
				epSelect,
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px;' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function () { ui.hideModal(); }
				}, [_('Отмена')]),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function () {
						var rawName = String(nameInput.value || '').trim();
						if (!rawName) {
							nameInput.focus();
							return;
						}
						var cleanName = slugifyPeerName(rawName);
						if (!cleanName) {
							self.setMessage(_('Имя клиента содержит недопустимые символы'), 'bad');
							nameInput.focus();
							return;
						}
						var chosenEp = String(customEpInput.value || '').trim() || epSelect.value;
						var arg = cleanName + (chosenEp ? '|' + chosenEp : '');
						ui.hideModal();
						if (s.onAction)
							s.onAction('peerAdd', arg, _('Создать клиента «%s»?').format(cleanName));
					}
				}, [_('Создать')])
			])
		];

		self._showVpnDialog(_('Новый VPN-клиент'), body);
		setTimeout(function () { nameInput.focus(); }, 100);
	}

	_openChangeEndpointDialog(awg) {
		var self = this;
		var s = this._spec || {};
		var currentEp = awg.defaultEndpoint || '';

		var epOpts = [];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [choices[i].label]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'value': currentEp,
			'placeholder': 'domain.tld:51820 или 1.2.3.4:51820',
			'style': 'width: 100%; margin-top: 6px;'
		});

		epSelect.addEventListener('change', function () {
			if (epSelect.value)
				customEpInput.value = epSelect.value;
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 8px;' }, [
					_('Default Endpoint используется как адрес сервера в создаваемых клиентских .conf-файлах.')
				]),
				E('label', { 'style': 'font-weight: 600;' }, [_('Выберите из обнаруженных адресов:')]),
				epSelect,
				E('label', { 'style': 'font-weight: 600; display: block; margin-top: 8px;' }, [_('Или укажите вручную:')]),
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px;' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function () { ui.hideModal(); }
				}, [_('Отмена')]),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function () {
						var ep = String(customEpInput.value || '').trim();
						if (!ep) {
							customEpInput.focus();
							return;
						}
						ui.hideModal();
						if (s.onAction)
							s.onAction('serverSetEndpoint', ep, _('Установить Default Endpoint сервера: %s?').format(ep));
					}
				}, [_('Сохранить')])
			])
		];

		self._showVpnDialog(_('Смена Default Endpoint сервера'), body);
	}

	_openPeerEndpointDialog(peer, awg) {
		var self = this;
		var s = this._spec || {};
		var currentEp = peer.endpoint || awg.defaultEndpoint || '';

		var epOpts = [
			E('option', { 'value': '' }, [_('Использовать Default Endpoint сервера (%s)').format(awg.defaultEndpoint || '')])
		];
		var choices = awg.endpointChoices || [];
		for (var i = 0; i < choices.length; i++) {
			epOpts.push(E('option', { 'value': choices[i].endpoint }, [choices[i].label]));
		}
		var epSelect = E('select', {
			'class': 'xfree-uplink-input',
			'style': 'width: 100%; margin-top: 4px;'
		}, epOpts);

		var customEpInput = E('input', {
			'type': 'text',
			'class': 'xfree-uplink-input',
			'value': currentEp,
			'placeholder': 'host:port',
			'style': 'width: 100%; margin-top: 6px;'
		});

		epSelect.addEventListener('change', function () {
			if (epSelect.value)
				customEpInput.value = epSelect.value;
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 12px;' }, [
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 8px;' }, [
					_('Индивидуальный Endpoint подключения для клиента «%s».').format(peer.name)
				]),
				E('label', { 'style': 'font-weight: 600;' }, [_('Выбрать из вариантов:')]),
				epSelect,
				E('label', { 'style': 'font-weight: 600; display: block; margin-top: 8px;' }, [_('Или адрес:порт:')]),
				customEpInput
			]),
			E('div', { 'style': 'display: flex; justify-content: flex-end; gap: 8px; margin-top: 16px;' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function () { ui.hideModal(); }
				}, [_('Отмена')]),
				E('button', {
					'class': 'btn is-primary',
					'type': 'button',
					'click': function () {
						var ep = String(customEpInput.value || '').trim();
						ui.hideModal();
						if (s.onAction)
							s.onAction('peerUpdateEndpoint', peer.slug + '|' + ep,
								_('Обновить Endpoint для клиента «%s» на %s?').format(peer.name, ep || _('default')));
					}
				}, [_('Сохранить')])
			])
		];

		self._showVpnDialog(_('Endpoint для «%s»').format(peer.name), body);
	}

	_openNatHelpDialog() {
		ui.showModal(_('Как обойти NAT и подключиться к домашнему серверу'), [
			E('div', { 'class': 'xfree-modal-body', 'style': 'font-size: 13px; line-height: 1.5;' }, [
				E('p', {}, [
					_('Если у роутера серый IP-адрес (провайдерский CGNAT 100.64.0.0/10), внешние входящие подключения из интернета блокируются оборудованием провайдера на корню. Ни AmneziaWG напрямую, ни FreeTurn (поскольку VK TURN должен переслать пакет на роутер) достучаться до роутера не смогут.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, ['1. ' + _('Услуга «Белый IP» у провайдера (Рекомендуется)')]),
				E('p', { 'class': 'muted' }, [
					_('Самый стабильный и простой путь. В личном кабинете вашего интернет-провайдера подключите услугу «Статический IP» или «Публичный IP» (обычно 100–150 ₽/мес). После этого роутер получит прямой белый адрес, и все клиенты смогут подключаться без костылей.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, ['2. ' + _('Использование IPv6')]),
				E('p', { 'class': 'muted' }, [
					_('Многие провайдеры с CGNAT по IPv4 параллельно бесплатно выдают полноценный публичный префикс IPv6. Если мобильный оператор вашего телефона также поддерживает IPv6, вы можете указать IPv6-адрес сервера в настройках пиров и подключаться напрямую.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, ['3. ' + _('Реверсивный туннель через VPS (Rathole / FRP / WireGuard)')]),
				E('p', { 'class': 'muted' }, [
					_('Домашний роутер сам устанавливает постоянное исходящее соединение на внешний VPS (исходящие соединения провайдер не блокирует). VPS принимает подключения клиентов из интернета и пробрасывает трафик внутрь на роутер.')
				]),
				E('h4', { 'style': 'margin: 14px 0 6px 0;' }, ['4. ' + _('Tailscale / NetBird (P2P Mesh + DERP-релеи)')]),
				E('p', { 'class': 'muted' }, [
					_('Tailscale устанавливается на роутер и клиентские устройства. Если прямое P2P соединение невозможно из-за строгого CGNAT, трафик автоматически пересылается через зашифрованные промежуточные релеи (DERP) без белого IP.')
				])
			]),
			E('div', { 'class': 'right', 'style': 'margin-top: 16px;' }, [
				E('button', {
					'class': 'btn is-primary',
					'click': ui.hideModal
				}, [_('Понятно')])
			])
		]);
	}

	_openFreeTurnConfigDialog(awg) {
		var self = this;
		var s = this._spec || {};
		var currentPort = awg.freeTurnPort || '56000';

		var portInput = E('input', {
			'type': 'number',
			'min': '1',
			'max': '65535',
			'value': currentPort,
			'class': 'cbi-input-text',
			'style': 'width: 100%; font-size: 14px; padding: 6px 10px; margin-top: 6px;'
		});

		var presets = [
			{ port: '56000', label: _('56000 (по умолчанию)') },
			{ port: '443', label: _('443 (HTTPS/QUIC)') },
			{ port: '8443', label: _('8443') },
			{ port: '3478', label: _('3478 (STUN)') },
			{ port: '51820', label: _('51820 (AWG)') },
			{ port: '1194', label: _('1194 (OpenVPN)') }
		];

		var presetBtns = presets.map(function (p) {
			return E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'style': 'font-size: 11px; padding: 3px 8px;',
				'title': _('Установить порт %s').format(p.port),
				'click': function (ev) {
					ev.preventDefault();
					portInput.value = p.port;
				}
			}, [p.label]);
		});

		var body = [
			E('div', { 'style': 'margin-bottom: 14px;' }, [
				E('p', { 'style': 'margin: 0 0 8px 0; font-size: 13px;' }, [
					_('Внешний UDP-порт роутера, на котором служба FreeTurn принимает входящий замаскированный трафик от клиентских приложений.')
				]),
				E('label', { 'style': 'font-weight: 600; display: block;' }, [_('Внешний порт (UDP):')]),
				portInput,
				E('div', { 'style': 'margin-top: 8px;' }, [
					E('span', { 'class': 'muted', 'style': 'font-size: 11px; display: block; margin-bottom: 4px;' }, [
						_('Быстрый выбор популярного порта:')
					]),
					E('div', { 'style': 'display: flex; flex-wrap: wrap; gap: 6px;' }, presetBtns)
				]),
				E('div', { 'class': 'muted', 'style': 'margin-top: 12px; font-size: 12px; line-height: 1.4;' }, [
					E('span', { 'style': 'display: block; margin-bottom: 2px;' }, [_('При сохранении:')]),
					E('span', { 'style': 'display: block;' }, ['• ' + _('Обновляется правило входящего трафика в Firewall (Allow-free-turn)')]),
					E('span', { 'style': 'display: block;' }, ['• ' + _('Перезапускается служба /etc/init.d/free-turn с новым портом')]),
					E('span', { 'style': 'display: block;' }, ['• ' + _('Все новые ссылки freeturn:// и QR-коды клиентов будут генерироваться для этого порта')])
				])
			]),
			E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 18px; border-top: 1px solid var(--border-subtle, #e5e5e5); padding-top: 12px;' }, [
				E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'title': _('Полная перенастройка бинарника, Firewall и procd'),
					'click': function (ev) {
						ui.hideModal();
						self._act(ev, 'freeTurnSetup', '', {
							title: _('Перенастройка FreeTurn прокси'),
							message: _('Перенастроить службу FreeTurn прокси?'),
							detail: _('Будет проверен бинарник, обновлена конфигурация procd сервиса /etc/init.d/free-turn и правила Firewall.'),
							confirmText: _('Перенастроить'),
							tone: 'primary',
							icon: '⚙️'
						});
					}
				}, [_('Перенастроить всё')]),
				E('div', { 'style': 'display: flex; gap: 8px;' }, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function () { ui.hideModal(); }
					}, [_('Отмена')]),
					E('button', {
						'class': 'btn is-primary',
						'type': 'button',
						'click': function () {
							var raw = String(portInput.value || '').trim();
							var p = parseInt(raw, 10);
							if (isNaN(p) || p < 1 || p > 65535) {
								ui.addNotification(null, E('p', {}, [_('Укажите корректный номер порта от 1 до 65535')]), 'danger');
								portInput.focus();
								return;
							}
							ui.hideModal();
							if (s.onAction) {
								s.onAction('freeTurnSetPort', String(p),
									_('Сменить внешний порт FreeTurn на %s (с обновлением Firewall и перезапуском службы)?').format(p));
							}
						}
					}, [_('Сохранить порт')])
				])
			])
		];

		self._showVpnDialog(_('Настройка FreeTurn Proxy'), body);
	}

	_renderServerSection(awg, view) {
		var self = this;
		var peers = awg.peers || [];

		// Card 1: Server Identity & Settings
		var pubkeyShow = awg.pubkey || '—';
		var epShow = awg.defaultEndpoint || '—';
		var obfsShow = awg.obfuscation || '—';

		var serverParamsRows = [
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Публичный ключ')]),
				E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px; font-family:monospace;' }, [
					E('span', { 'title': pubkeyShow }, [pubkeyShow.length > 28 ? pubkeyShow.slice(0, 14) + '…' + pubkeyShow.slice(-10) : pubkeyShow]),
					pubkeyShow !== '—' ? E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'style': 'padding: 2px 6px; font-size: 11px;',
						'title': _('Скопировать публичный ключ'),
						'click': function (ev) { copyToClipboard(pubkeyShow, ev.target); }
					}, [_('Копировать')]) : ''
				])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Default endpoint')]),
				E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
					E('strong', {}, [epShow]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'style': 'padding: 2px 6px; font-size: 11px;',
						'title': _('Изменить endpoint сервера'),
						'click': function () { self._openChangeEndpointDialog(awg); }
					}, [_('Изменить')])
				])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Обфускация')]),
				E('span', { 'style': 'font-family:monospace; font-size: 11px; color: var(--accent);' }, [obfsShow])
			]),
			E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
				E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Firewall')]),
				E('span', {}, [_('Входящий UDP %s разрешён (WAN → Router)').format(awg.port || '51820')])
			])
		];

		var serverActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				E('button', {
					'class': 'btn is-primary ghost-compact',
					'type': 'button',
					'title': _('Применить параметры сервера и обновить список пиров'),
					'click': ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'serverApply', '', {
							title: _('Применение настроек сервера'),
							message: _('Перезапустить VPN-сервер и применить конфигурацию интерфейса?'),
							detail: _('Сетевой интерфейс awg_ingress будет перезапущен с актуальными ключами, портами и списком клиентов. Существующие соединения кратковременно переподключатся.'),
							confirmText: _('Применить'),
							tone: 'primary',
							icon: '⚡'
						});
					})
				}, ['⚡ ' + _('Применить сервер')]),
				xui.helpBtn({
					title: _('Применить сервер'),
					desc: _('Применяет текущую конфигурацию интерфейса awg_ingress и синхронизирует пиров.'),
					whatDoes: _('Вызывает скрипт apply-peers.sh, обновляет список доверенных публичных ключей клиентов в ядре и перезапускает интерфейс.'),
					tips: _('Используйте после добавления новых клиентов, изменения обфускации или смены Default Endpoint.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'title': _('Проверить и настроить правила Firewall для входящего VPN'),
					'click': ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'serverConfigureFirewall', '', {
							title: _('Настройка Firewall'),
							message: _('Настроить правила межсетевого экрана для VPN-сервера?'),
							detail: _('Будет открыт входящий UDP-порт %s на интерфейсе WAN и разрешён форвардинг трафика между зоной awg_ingress и вашей локальной сетью LAN.').format(awg.port || '51820'),
							confirmText: _('Настроить Firewall'),
							tone: 'primary',
							icon: '🛡️'
						});
					})
				}, ['🛡️ ' + _('Настроить Firewall')]),
				xui.helpBtn({
					title: _('Настройка Firewall'),
					desc: _('Настраивает правила межсетевого экрана (nftables / firewall4) для безопасного приёма подключений клиентов.'),
					whatDoes: _('Создаёт правило разрешения входящего UDP-порта сервера в зоне WAN и настраивает forwarding между зонами awg_ingress и LAN.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group' }, [
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'title': _('Выполнить первоначальную настройку сервера'),
					'click': ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'serverSetup', '', {
							title: _('Первоначальная настройка'),
							message: _('Выполнить первичный Setup входящего VPN-сервера?'),
							detail: _('Скрипт создаст недостающие рабочие каталоги, сгенерирует ключи (если отсутствуют) и подготовит базовые конфигурационные файлы.'),
							confirmText: _('Запустить Setup'),
							tone: 'primary',
							icon: '⚙️'
						});
					})
				}, ['⚙️ ' + _('Setup сервера')]),
				xui.helpBtn({
					title: _('Setup сервера'),
					desc: _('Сценарий первичной инициализации сервера AmneziaWG на роутере.'),
					whatDoes: _('Генерирует файлы /etc/xfree-toolbox/awg-ingress/state/server.key, public.key и настраивает начальное окружение.'),
					tips: _('Полезно при первичной установке или после полного сброса настроек роутера.')
				})
			]),
			E('div', { 'class': 'xfree-vpn-action-group is-danger', 'style': 'margin-left: auto;' }, [
				E('button', {
					'class': 'btn ghost-compact is-bad',
					'type': 'button',
					'style': 'color: var(--bad); border-color: color-mix(in srgb, var(--bad) 40%, var(--line));',
					'title': _('Пересоздать приватный и публичный ключи сервера (все клиенты перестанут работать)'),
					'click': ui.createHandlerFn(view, function (ev) {
						self._act(ev, 'serverRecreateKeys', '', {
							title: _('Пересоздание ключей сервера'),
							message: _('ВНИМАНИЕ! Пересоздать ключи сервера? Все клиенты потеряют доступ!'),
							detail: _('КРИТИЧЕСКАЯ ОПЕРАЦИЯ: Будет сгенерирована абсолютно новая пара ключей сервера. Все подключённые клиенты (%d шт.) перестанут подключаться. Вам потребуется пересоздать и заново импортировать .conf и QR-коды на каждом клиентском устройстве.').format(peers.length),
							confirmText: _('Да, пересоздать ключи'),
							tone: 'danger',
							icon: '⚠️'
						});
					})
				}, ['⚠️ ' + _('Пересоздать ключи')]),
				xui.helpBtn({
					title: _('Пересоздание ключей сервера'),
					desc: _('Генерация новой ключевой пары сервера AmneziaWG.'),
					whatDoes: _('Перезаписывает приватный и публичный ключ сервера в /etc/xfree-toolbox/awg-ingress/state/.'),
					tips: _('Используйте эту операцию ТОЛЬКО при компрометации старых ключей сервера. Все выданные ранее клиентам настройки станут недействительными!')
				})
			])
		]);

		var serverCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('strong', {}, [_('AmneziaWG Server (Ingress)')]),
					xui.helpBtn({
						title: _('Входящий VPN-сервер AmneziaWG'),
						desc: _('Входящий VPN-сервер на базе протокола AmneziaWG (WireGuard с обфускацией пакетов Junk/Init/Response). Позволяет вашим смартфонам, ноутбукам и другим устройствам безопасно подключаться к домашней сети роутера из любой точки мира.'),
						whatDoes: _('Принимает зашифрованный входящий туннельный трафик на порту %s/UDP и направляет его в домашнюю сеть LAN или в интернет через настроенные аплинки.').format(awg.port || '51820'),
						tips: _('Для подключения мобильных устройств используйте приложение AmneziaWG. QR-коды для мгновенной настройки доступны в карточках клиентов ниже.')
					}),
					E('span', { 'class': 'muted' }, [(awg.iface || 'awg_ingress') + ' · ' + (awg.addr || '10.200.200.1/24')])
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, [
					E('span', { 'class': 'xfree-vpn-status is-' + (awg.running ? 'ok' : 'bad') }, [
						awg.running ? _('СЕРВЕР АКТИВЕН') : _('ОСТАНОВЛЕН')
					]),
					awg.version ? E('span', { 'class': 'xfree-vpn-status is-muted' }, [awg.version]) : ''
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, serverParamsRows),
			serverActions
		]);

		// Card 2: NAT / External IP Accessibility Diagnostic
		var natRes = self._natCheckResult;
		var wanIpDisplay = (natRes && natRes.wanIp4) || awg.wanIp || '';
		if (!wanIpDisplay && awg.endpointChoices && Array.isArray(awg.endpointChoices)) {
			for (var eci = 0; eci < awg.endpointChoices.length; eci++) {
				if (awg.endpointChoices[eci].id === 'net:wan') {
					wanIpDisplay = (awg.endpointChoices[eci].endpoint || '').split(':')[0];
					break;
				}
			}
		}
		if (!wanIpDisplay)
			wanIpDisplay = '—';

		var extIp4Display = (natRes && natRes.extIp4) || (self._natChecking ? _('проверка...') : _('не проверен'));
		var extIp6Display = (natRes && natRes.extIp6) || (self._natChecking ? _('проверка...') : (natRes ? _('нет IPv6') : _('не проверен')));

		var preliminaryStatus = 'muted';
		var preliminaryBadge = _('НЕ ПРОВЕРЕНО');
		if (wanIpDisplay && wanIpDisplay !== '—') {
			if (/^100\.(6[4-9]|[7-9][0-9]|1[0-1][0-9]|12[0-7])\./.test(wanIpDisplay)) {
				preliminaryStatus = 'warn';
				preliminaryBadge = _('CGNAT (СЕРЫЙ IP)');
			} else if (/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/.test(wanIpDisplay)) {
				preliminaryStatus = 'warn';
				preliminaryBadge = _('ДОМАШНИЙ NAT');
			} else {
				preliminaryStatus = 'ok';
				preliminaryBadge = _('БЕЛЫЙ IP (ПРЕДВАРИТЕЛЬНО)');
			}
		}

		var natBadgeClass;
		var natBadgeText;
		if (natRes) {
			if (natRes.natType === 'public') {
				natBadgeClass = 'is-ok';
				natBadgeText = _('БЕЛЫЙ ПУБЛИЧНЫЙ IP');
			} else if (natRes.natType === 'cgnat') {
				natBadgeClass = 'is-bad';
				natBadgeText = _('CGNAT (СЕРЫЙ IP)');
			} else if (natRes.natType === 'local_nat') {
				natBadgeClass = 'is-warn';
				natBadgeText = _('ДОМАШНИЙ NAT (МОДЕМ)');
			} else if (natRes.statusCode === 'danger') {
				natBadgeClass = 'is-bad';
				natBadgeText = _('ОШИБКА ПРОВЕРКИ');
			} else {
				natBadgeClass = 'is-warn';
				natBadgeText = _('ПРОВАЙДЕРСКИЙ NAT');
			}
		} else {
			natBadgeClass = 'is-' + preliminaryStatus;
			natBadgeText = preliminaryBadge;
		}

		var natAdvice = '';
		if (natRes && natRes.message) {
			natAdvice = natRes.message;
		} else if (preliminaryBadge === _('CGNAT (СЕРЫЙ IP)')) {
			natAdvice = _('Адрес WAN находится в диапазоне CGNAT (100.64.0.0/10). Провайдер блокирует прямые входящие подключения из интернета. Нажмите «Как обойти NAT» для настройки FreeTurn или реле.');
		} else if (preliminaryBadge === _('ДОМАШНИЙ NAT')) {
			natAdvice = _('Роутер подключён через терминал/модем провайдера (192.168.x.x / 10.x.x.x). Настройте на терминале режим Bridge, DMZ или проброс порта 51820 UDP на этот роутер.');
		} else if (preliminaryBadge === _('БЕЛЫЙ IP (ПРЕДВАРИТЕЛЬНО)')) {
			natAdvice = _('WAN IP роутера похож на публичный (%s). Нажмите «Проверить доступность извне», чтобы подтвердить отсутствие скрытого NAT и доступность порта.').format(wanIpDisplay);
		} else {
			natAdvice = _('Нажмите «Проверить доступность извне», чтобы сопоставить WAN IP с реальным адресом выхода в интернет и проверить наличие IPv6.');
		}

		var natCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
			E('div', { 'class': 'xfree-vpn-gen-head' }, [
				E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
					E('strong', {}, [_('Доступность из интернета (NAT / Внешний IP)')]),
					xui.helpBtn({
						title: _('Диагностика доступа из интернета'),
						desc: _('Определяет, доступен ли ваш сервер AmneziaWG и FreeTurn для входящих подключений клиентов из глобальной сети.'),
						whatDoes: _('Сопоставляет локальный WAN IPv4 с публичным адресом в интернете, определяет наличие провайдерского CGNAT (RFC 6598) и проверяет поддержку IPv6.'),
						tips: _('Если у вас серый IP (CGNAT), нажмите кнопку «Как обойти NAT» для просмотра доступных решений (VPS релеи, Tailscale, IPv6).')
					}),
					wanIpDisplay !== '—' ? E('span', { 'class': 'muted' }, [_('WAN: %s').format(wanIpDisplay)]) : ''
				]),
				E('div', { 'class': 'xfree-vpn-gen-badges' }, [
					E('span', { 'class': 'xfree-vpn-status ' + natBadgeClass }, [natBadgeText])
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 8px; padding: 10px 0;' }, [
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('WAN IPv4 (роутер)')]),
					E('strong', { 'style': 'font-family: monospace; font-size: 13px;' }, [wanIpDisplay])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Внешний IPv4 (интернет)')]),
					E('span', { 'style': 'font-family: monospace; font-size: 13px; font-weight: 600;' }, [extIp4Display])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: center;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap;' }, [_('Внешний IPv6')]),
					E('span', { 'style': 'font-family: monospace; font-size: 12px; font-weight: 600;' }, [extIp6Display])
				]),
				E('div', { 'class': 'xfree-vpn-wide-kv', 'style': 'display: grid; grid-template-columns: 190px 1fr; gap: 12px; align-items: flex-start; margin-top: 4px;' }, [
					E('em', { 'style': 'font-style: normal; color: var(--muted); font-size: 12px; white-space: nowrap; padding-top: 6px;' }, [_('Рекомендация')]),
					E('div', {
						'class': 'muted',
						'style': 'font-size: 12px; line-height: 1.45; padding: 8px 12px; border-radius: 6px; background: color-mix(in srgb, var(--card) 60%, var(--bg)); border-left: 3px solid ' + (natBadgeClass.indexOf('is-bad') !== -1 ? 'var(--bad)' : (natBadgeClass.indexOf('is-warn') !== -1 ? 'var(--warn)' : 'var(--primary)')) + ';'
					}, [natAdvice])
				])
			]),
			E('div', { 'class': 'xfree-vpn-server-actions', 'style': 'display: flex; gap: 8px; flex-wrap: wrap; align-items: center;' }, [
				E('button', {
					'class': 'btn is-primary ghost-compact',
					'type': 'button',
					'disabled': self._natChecking ? true : null,
					'click': function () {
						self._natChecking = true;
						self.requestPaint();
						xui.runAwgMenu('checkNat').then(function (res) {
							self._natChecking = false;
							self._natCheckResult = xui.parseNatCheck(res);
							self.requestPaint();
						}).catch(function (err) {
							self._natChecking = false;
							self._natCheckResult = {
								statusCode: 'danger',
								message: _('Ошибка проверки: ') + ((err && err.message) || String(err))
							};
							self.requestPaint();
						});
					}
				}, [self._natChecking ? _('Проверка...') : ('🔍 ' + _('Проверить доступность извне'))]),
				E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'click': function () { self._openNatHelpDialog(); }
				}, ['ℹ️ ' + _('Как обойти NAT')])
			])
		]);

		// Card 3: FreeTurn Proxy (Next-gen transport)
		var freeTurnPortShow = awg.freeTurnPort || '56000';
		var freeTurnCard;

		if (!awg.freeTurnInstalled) {
			freeTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [_('FreeTurn Proxy (Транспорт)')]),
						xui.helpBtn({
							title: _('FreeTurn Proxy'),
							desc: _('Современный UDP-транспорт нового поколения (протокол v4), маскирующий туннельный трафик AmneziaWG под RTP/Opus медиа-звонки с профилем rtpopus3 и 64-символьным ключом шифрования.'),
							whatDoes: _('Позволяет обходить блокировки WireGuard/AWG операторами связи (включая жесткие белые списки мобильных операторов). Принимает трафик на порту 56000/UDP и пересылает на локальный порт 51820 awg_ingress.'),
							tips: _('Устанавливается нажатием одной кнопки. При установке автоматически скачивается бинарник под процессор вашего роутера, создаётся ключ обфускации, настраивается Firewall и безопасно отключается старый vk-turn.')
						}),
						E('span', { 'class': 'muted' }, [_('UDP 56000')])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('НЕ УСТАНОВЛЕН')])
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 12px 0;' }, [
					E('p', { 'style': 'margin: 0; font-size: 13px;' }, [
						_('FreeTurn — современный преемник VK-Turn с протоколом v4 и обфускацией rtpopus3 под голосовой трафик.')
					]),
					E('div', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
						_('На роутере пока не установлен. Нажмите кнопку ниже для автоматической загрузки бинарника с GitHub и первоначальной настройки.')
					])
				]),
				E('div', { 'class': 'xfree-vpn-server-actions' }, [
					E('div', { 'class': 'xfree-vpn-actions-group' }, [
						E('button', {
							'class': 'btn is-primary ghost-compact',
							'type': 'button',
							'title': _('Установить и запустить FreeTurn прокси «под ключ»'),
							'click': function (ev) {
								self._act(ev, 'freeTurnSetup', '', {
									title: _('Установка FreeTurn прокси'),
									message: _('Установить и запустить FreeTurn прокси на порту %s?').format(freeTurnPortShow),
									detail: _('Будет скачан бинарник free-turn-proxy с GitHub под процессор роутера, сгенерирован 64-hex ключ obf.key, создан procd сервис /etc/init.d/free-turn, настроен Firewall и корректно отключён устаревший vk-turn.'),
									confirmText: _('Установить'),
									tone: 'primary',
									icon: '📥'
								});
							}
						}, ['📥 ' + _('Установить FreeTurn')])
					])
				])
			]);
		} else {
			var freeTurnParamsRows = [
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('входящий порт')]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:8px;' }, [
						E('strong', {}, ['0.0.0.0:' + freeTurnPortShow + ' (UDP)']),
						'WAN ➔ Router',
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'padding: 2px 8px; font-size: 11px;',
							'title': _('Изменить внешний порт FreeTurn'),
							'click': function (ev) {
								ev.preventDefault();
								self._openFreeTurnConfigDialog(awg);
							}
						}, ['✏️ ' + _('Изменить')])
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('целевой порт (AWG)')]),
					E('span', {}, [
						E('strong', {}, ['127.0.0.1:' + (awg.port || '51820')]),
						' (' + (awg.iface || 'awg_ingress') + ')'
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('обфускация')]),
					E('span', {}, [
						E('strong', {}, [awg.freeTurnObfProfile || 'rtpopus3']),
						' ' + _('(маскировка под голосовой трафик)')
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('ключ обфускации')]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px; font-family:monospace;' }, [
						E('span', { 'title': awg.freeTurnObfKey || '' }, [
							awg.freeTurnObfKey ? (awg.freeTurnObfKey.slice(0, 14) + '…' + awg.freeTurnObfKey.slice(-10)) : '—'
						]),
						awg.freeTurnObfKey ? E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'padding: 2px 6px; font-size: 11px;',
							'title': _('Скопировать ключ обфускации'),
							'click': function (ev) { copyToClipboard(awg.freeTurnObfKey, ev.target); }
						}, [_('Копировать')]) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('статус сервиса')]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
						E('span', { 'class': 'xfree-vpn-badge is-' + (awg.freeTurnRunning ? 'ok' : 'bad') }, [
							awg.freeTurnRunning ? _('работает') : _('остановлен')
						]),
						E('span', {}, [
							awg.freeTurnRunning
								? _('Служба /etc/init.d/free-turn работает (PID активен)')
								: _('Служба /etc/init.d/free-turn остановлена')
						])
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('firewall')]),
					E('span', {}, [
						awg.freeTurnRunning
							? _('Входящий UDP %s разрешён (WAN ➔ Router)').format(freeTurnPortShow)
							: _('Входящий UDP %s (настроен в Firewall)').format(freeTurnPortShow)
					])
				])
			];

			var freeTurnActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
				E('div', { 'class': 'xfree-vpn-actions-group' }, [
					awg.freeTurnRunning ? E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Перезапустить службу FreeTurn'),
						'click': function (ev) {
							self._act(ev, 'freeTurnRestart', '', {
								title: _('Перезапуск FreeTurn'),
								message: _('Перезапустить службу FreeTurn прокси?'),
								detail: _('Служба /etc/init.d/free-turn будет перезапущена с текущими параметрами.'),
								confirmText: _('Перезапустить'),
								tone: 'primary',
								icon: '🔄'
							});
						}
					}, ['🔄 ' + _('Перезапустить')]) : E('button', {
						'class': 'btn is-primary ghost-compact',
						'type': 'button',
						'title': _('Запустить службу FreeTurn'),
						'click': function (ev) {
							self._act(ev, 'freeTurnRestart', '', {
								title: _('Запуск FreeTurn'),
								message: _('Запустить службу FreeTurn прокси на порту %s?').format(freeTurnPortShow),
								detail: _('Служба /etc/init.d/free-turn будет запущена.'),
								confirmText: _('Запустить'),
								tone: 'primary',
								icon: '▶️'
							});
						}
					}, ['▶️ ' + _('Запустить')]),

					awg.freeTurnRunning ? E('button', {
						'class': 'btn ghost-compact is-stop',
						'type': 'button',
						'title': _('Остановить службу FreeTurn прокси'),
						'click': function (ev) {
							self._act(ev, 'freeTurnStop', '', {
								title: _('Остановка FreeTurn'),
								message: _('Остановить службу FreeTurn прокси?'),
								detail: _('Служба /etc/init.d/free-turn будет остановлена, порт %s освобождён. Клиенты через FreeTurn временно потеряют связь.').format(freeTurnPortShow),
								confirmText: _('Остановить'),
								tone: 'danger',
								icon: '⏹️'
							});
						}
					}, ['⏹️ ' + _('Остановить')]) : '',

					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Настроить внешний порт и параметры службы FreeTurn'),
						'click': function (ev) {
							ev.preventDefault();
							self._openFreeTurnConfigDialog(awg);
						}
					}, ['⚙️ ' + _('Настроить сервер')]),

					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Проверить и обновить бинарник FreeTurn'),
						'click': function (ev) {
							self._act(ev, 'freeTurnUpdate', '', {
								title: _('Обновление FreeTurn'),
								message: _('Обновить бинарник FreeTurn до последней версии?'),
								detail: _('Будет проверен и скачан свежий бинарник free-turn-proxy с GitHub.'),
								confirmText: _('Обновить'),
								tone: 'primary',
								icon: '⬆️'
							});
						}
					}, ['⬆️ ' + _('Обновить')])
				]),
				E('div', { 'class': 'xfree-vpn-actions-group is-danger' }, [
					E('button', {
						'class': 'btn ghost-compact is-bad',
						'type': 'button',
						'title': _('Полностью удалить FreeTurn с роутера (служба, бинарник, firewall)'),
						'click': function (ev) {
							self._act(ev, 'freeTurnUninstall', '', {
								title: _('Удаление FreeTurn'),
								message: _('Полностью удалить FreeTurn прокси с роутера?'),
								detail: _('Служба /etc/init.d/free-turn будет остановлена и удалена, бинарник /opt/free-turn-proxy и ключ удалены, порт %s закрыт в Firewall.').format(freeTurnPortShow),
								confirmText: _('Да, удалить FreeTurn'),
								tone: 'danger',
								icon: '🗑️'
							});
						}
					}, ['🗑️ ' + _('Удалить FreeTurn')])
				])
			]);

			freeTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [_('FreeTurn Proxy (Транспорт)')]),
						xui.helpBtn({
							title: _('FreeTurn Proxy'),
							desc: _('Современный UDP-транспорт нового поколения (протокол v4), маскирующий туннельный трафик AmneziaWG под RTP/Opus медиа-звонки с профилем rtpopus3 и 64-символьным ключом шифрования.'),
							whatDoes: _('Позволяет обходить блокировки WireGuard/AWG операторами связи (включая жесткие белые списки мобильных операторов). Принимает трафик на порту %s/UDP и пересылает на локальный порт 51820 awg_ingress.').format(freeTurnPortShow),
							tips: _('Для подключения используйте клиент FreeTurn на телефоне (turn-proxy-android) или роутере.')
						}),
						E('button', {
							'class': 'ghost ghost-compact',
							'type': 'button',
							'style': 'padding: 1px 6px; font-size: 11px; margin-left: 2px;',
							'title': _('Изменить внешний порт FreeTurn'),
							'click': function (ev) {
								ev.preventDefault();
								self._openFreeTurnConfigDialog(awg);
							}
						}, ['UDP ' + freeTurnPortShow + ' ✏️']),
						E('span', { 'class': 'muted' }, ['➔ 127.0.0.1:' + (awg.port || '51820')])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status is-' + (awg.freeTurnRunning ? 'ok' : 'bad') }, [
							awg.freeTurnRunning ? _('ПРОКСИ АКТИВЕН') : _('ОСТАНОВЛЕН')
						]),
						awg.freeTurnVersion ? E('span', { 'class': 'xfree-vpn-status is-muted' }, [awg.freeTurnVersion]) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, freeTurnParamsRows),
				freeTurnActions
			]);
		}

		// Card 4: VK-Turn Proxy Card (Legacy transport)
		var vkTurnPortShow = awg.vkPort || '49151';
		var vkTurnCard;

		if (!awg.vkInstalled) {
			vkTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [_('VK-Turn Proxy (Легаси транспорт)')]),
						xui.helpBtn({
							title: _('VK-Turn Proxy'),
							desc: _('Устаревший UDP-прокси первого поколения для обхода блокировок WireGuard через маскировку под медиа-звонки VK (порт 49151).'),
							tips: _('Рекомендуется использовать FreeTurn вместо VK-Turn. Если вы хотите установить VK-Turn, нажмите кнопку ниже.')
						}),
						E('span', { 'class': 'muted' }, [_('UDP 49151')])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('НЕ УСТАНОВЛЕН')])
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 12px 0;' }, [
					E('p', { 'style': 'margin: 0; font-size: 13px;' }, [
						_('VK-Turn — транспорт первого поколения на порту 49151.')
					]),
					E('div', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
						_('На роутере не установлен. Вы можете установить его вручную или использовать более современный FreeTurn.')
					])
				]),
				E('div', { 'class': 'xfree-vpn-server-actions' }, [
					E('div', { 'class': 'xfree-vpn-actions-group' }, [
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'title': _('Установить и настроить VK-Turn прокси'),
							'click': function (ev) {
								self._act(ev, 'vkTurnSetup', '', {
									title: _('Установка VK-Turn прокси'),
									message: _('Установить и запустить VK-Turn прокси на порту %s?').format(vkTurnPortShow),
									detail: _('Будет проверен бинарник vk-turn-proxy, создан init-сервис и открыт порт 49151 в Firewall.'),
									confirmText: _('Установить'),
									tone: 'primary',
									icon: '📥'
								});
							}
						}, ['📥 ' + _('Установить VK-Turn')])
					])
				])
			]);
		} else {
			var vkTurnParamsRows = [
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('входящий порт')]),
					E('span', {}, [
						E('strong', {}, ['0.0.0.0:' + vkTurnPortShow + ' (UDP)']),
						' WAN ➔ Router'
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('целевой порт (AWG)')]),
					E('span', {}, [
						E('strong', {}, ['127.0.0.1:' + (awg.port || '51820')]),
						' (' + (awg.iface || 'awg_ingress') + ')'
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('статус сервиса')]),
					E('span', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
						E('span', { 'class': 'xfree-vpn-badge is-' + (awg.vkRunning ? 'ok' : 'muted') }, [
							awg.vkRunning ? _('работает') : _('не запущен')
						]),
						E('span', {}, [
							awg.vkRunning
								? _('Служба /etc/init.d/vk-turn работает (PID активен)')
								: _('Служба /etc/init.d/vk-turn остановлена')
						])
					])
				]),
				E('div', { 'class': 'xfree-vpn-kv' }, [
					E('em', {}, [_('firewall')]),
					E('span', {}, [
						awg.vkRunning
							? _('Входящий UDP %s разрешён (WAN ➔ Router)').format(vkTurnPortShow)
							: _('Правило firewall создаётся автоматически при настройке сервера')
					])
				])
			];

			var vkTurnActions = E('div', { 'class': 'xfree-vpn-server-actions' }, [
				E('div', { 'class': 'xfree-vpn-actions-group' }, [
					awg.vkRunning ? E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Перезапустить службу VK-Turn'),
						'click': function (ev) {
							self._act(ev, 'vkTurnRestart', '', {
								title: _('Перезапуск VK-Turn'),
								message: _('Перезапустить службу VK-Turn прокси?'),
								detail: _('Служба /etc/init.d/vk-turn будет перезапущена с текущими параметрами.'),
								confirmText: _('Перезапустить'),
								tone: 'primary',
								icon: '🔄'
							});
						}
					}, ['🔄 ' + _('Перезапустить')]) : E('button', {
						'class': 'btn is-primary ghost-compact',
						'type': 'button',
						'title': _('Запустить службу VK-Turn'),
						'click': function (ev) {
							self._act(ev, 'vkTurnRestart', '', {
								title: _('Запуск VK-Turn'),
								message: _('Запустить службу VK-Turn прокси на порту %s?').format(vkTurnPortShow),
								detail: _('Служба /etc/init.d/vk-turn будет запущена.'),
								confirmText: _('Запустить'),
								tone: 'primary',
								icon: '▶️'
							});
						}
					}, ['▶️ ' + _('Запустить')]),

					awg.vkRunning ? E('button', {
						'class': 'btn ghost-compact is-stop',
						'type': 'button',
						'title': _('Остановить службу VK-Turn прокси'),
						'click': function (ev) {
							self._act(ev, 'vkTurnStop', '', {
								title: _('Остановка VK-Turn'),
								message: _('Остановить службу VK-Turn прокси?'),
								detail: _('Служба /etc/init.d/vk-turn будет остановлена, порт %s освобождён.').format(vkTurnPortShow),
								confirmText: _('Остановить'),
								tone: 'danger',
								icon: '⏹️'
							});
						}
					}, ['⏹️ ' + _('Остановить')]) : '',

					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Установить и настроить VK-Turn прокси'),
						'click': function (ev) {
							self._act(ev, 'vkTurnSetup', '', {
								title: _('Настройка VK-Turn прокси'),
								message: _('Настроить и запустить VK-Turn прокси на порту %s?').format(vkTurnPortShow),
								detail: _('VK-Turn маскирует трафик AmneziaWG под медиа-звонки VK. Будет проверен бинарник, создан init-сервис и открыт порт в Firewall.'),
								confirmText: _('Настроить сервер'),
								tone: 'primary',
								icon: '⚙️'
							});
						}
					}, ['⚙️ ' + _('Настроить сервер')]),

					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Проверить и обновить бинарник VK-Turn'),
						'click': function (ev) {
							self._act(ev, 'vkTurnUpdate', '', {
								title: _('Обновление VK-Turn'),
								message: _('Обновить бинарник VK-Turn?'),
								detail: _('Будет проверен и скачан бинарник vk-turn-proxy.'),
								confirmText: _('Обновить'),
								tone: 'primary',
								icon: '⬆️'
							});
						}
					}, ['⬆️ ' + _('Обновить')])
				]),
				E('div', { 'class': 'xfree-vpn-actions-group is-danger' }, [
					E('button', {
						'class': 'btn ghost-compact is-bad',
						'type': 'button',
						'title': _('Полностью удалить VK-Turn с роутера (служба, бинарник, firewall)'),
						'click': function (ev) {
							self._act(ev, 'vkTurnUninstall', '', {
								title: _('Удаление VK-Turn'),
								message: _('Полностью удалить VK-Turn прокси с роутера?'),
								detail: _('Служба /etc/init.d/vk-turn будет остановлена и удалена, бинарник /opt/vk-turn-proxy удалён, порт %s закрыт в Firewall.').format(vkTurnPortShow),
								confirmText: _('Да, удалить VK-Turn'),
								tone: 'danger',
								icon: '🗑️'
							});
						}
					}, ['🗑️ ' + _('Удалить VK-Turn')])
				])
			]);

			vkTurnCard = E('div', { 'class': 'xfree-vpn-gen', 'style': 'margin-bottom: 16px;' }, [
				E('div', { 'class': 'xfree-vpn-gen-head' }, [
					E('div', { 'class': 'xfree-vpn-gen-title', 'style': 'display: flex; align-items: center; gap: 8px;' }, [
						E('strong', {}, [_('VK-Turn Proxy (Транспорт)')]),
						xui.helpBtn({
							title: _('VK-Turn Proxy (Легаси)'),
							desc: _('Транспортный UDP-прокси первого поколения, маскирующий трафик AmneziaWG под медиа-звонки VK на порту 49151.')
						}),
						E('span', { 'class': 'muted' }, ['UDP ' + vkTurnPortShow + ' ➔ 127.0.0.1:' + (awg.port || '51820')])
					]),
					E('div', { 'class': 'xfree-vpn-gen-badges' }, [
						E('span', { 'class': 'xfree-vpn-status is-' + (awg.vkRunning ? 'ok' : 'bad') }, [
							awg.vkRunning ? _('ПРОКСИ АКТИВЕН') : _('НЕ АКТИВЕН')
						]),
						awg.vkVersion ? E('span', { 'class': 'xfree-vpn-status is-muted' }, [awg.vkVersion]) : ''
					])
				]),
				E('div', { 'class': 'xfree-vpn-tunnel-meta', 'style': 'display: flex; flex-direction: column; gap: 6px; padding: 10px 0;' }, vkTurnParamsRows),
				vkTurnActions
			]);
		}

		// Card 5: Peers List
		var peerCards = [];
		for (var i = 0; i < peers.length; i++) {
			(function (peer) {
				var diff = peer.latestHandshake > 0 ? (Math.floor(Date.now() / 1000) - peer.latestHandshake) : -1;
				var tone = diff >= 0 ? (diff < 180 ? 'ok' : (diff < 86400 ? 'warn' : 'muted')) : 'muted';
				var hsLabel = formatHandshake(peer.latestHandshake);
				var rxLabel = formatBytes(peer.rxBytes);
				var txLabel = formatBytes(peer.txBytes);

				var card = E('div', { 'class': 'xfree-vpn-tunnel is-' + tone }, [
					E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
						E('div', { 'style': 'display:inline-flex; align-items:center; gap:6px;' }, [
							E('span', { 'style': 'font-size:16px;' }, ['👤']),
							E('strong', {}, [peer.name || peer.slug])
						]),
						E('span', { 'class': 'xfree-vpn-status is-' + tone, 'title': peer.latestHandshake ? new Date(peer.latestHandshake * 1000).toLocaleString() : '' }, [hsLabel])
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-sub' }, [
						E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-size:11px;' }, [peer.ip || '—']),
						peer.endpoint ? E('span', { 'class': 'muted', 'style': 'margin-left:6px; font-size:11px;' }, [peer.endpoint]) : ''
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-meta' }, [
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [_('трафик')]),
							E('span', {}, [rxLabel + ' ↓ / ' + txLabel + ' ↑'])
						]),
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [_('keepalive')]),
							E('span', {}, [(peer.keepalive || 25) + ' ' + _('сек')])
						]),
						E('div', { 'class': 'xfree-vpn-kv' }, [
							E('em', {}, [_('ключ')]),
							E('span', { 'style': 'font-family:monospace; font-size:11px;' }, [
								peer.pubkey ? (peer.pubkey.slice(0, 10) + '…' + peer.pubkey.slice(-6)) : '—'
							])
						])
					]),
					E('div', { 'class': 'xfree-vpn-tunnel-actions' }, [
						E('button', {
							'class': 'btn ghost-compact is-primary',
							'type': 'button',
							'title': _('Показать QR-код для подключения WireGuard/AmneziaWG'),
							'click': function () { self._openPeerConfigDialog(peer, 'qr'); }
						}, ['📱 ' + _('QR-код')]),
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'title': _('Просмотр и скачивание файла .conf'),
							'click': function () { self._openPeerConfigDialog(peer, 'conf'); }
						}, ['📄 ' + _('.conf')]),
						awg.freeTurnInstalled ? E('button', {
							'class': 'btn ghost-compact is-primary',
							'type': 'button',
							'style': 'border-color: color-mix(in srgb, var(--primary) 70%, var(--line));',
							'title': _('Показать QR-код и ссылку freeturn:// для мобильного приложения'),
							'click': function (ev) {
								if (ev) ev.preventDefault();
								self._openPeerFreeTurnDialog(peer, awg);
							}
						}, ['⚡ ' + _('FreeTurn')]) : '',
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'title': _('Изменить endpoint для этого клиента'),
							'click': function () { self._openPeerEndpointDialog(peer, awg); }
						}, ['✏️']),
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'title': _('Пересоздать ключи клиента'),
							'click': function (ev) {
								self._act(ev, 'peerRecreateKeys', peer.slug, {
									title: _('Пересоздание ключей клиента'),
									message: _('Пересоздать ключи для клиента «%s»?').format(peer.name),
									detail: _('Старый файл .conf и QR-код на устройстве клиента перестанут подключаться. Потребуется импортировать обновлённый файл настроек на устройство пользователя.'),
									confirmText: _('Пересоздать'),
									tone: 'warn',
									icon: '🔄'
								});
							}
						}, ['🔄']),
						E('button', {
							'class': 'btn ghost-compact is-bad',
							'type': 'button',
							'style': 'color: var(--bad);',
							'title': _('Удалить клиента'),
							'click': function (ev) {
								self._act(ev, 'peerDelete', peer.slug, {
									title: _('Удаление VPN-клиента'),
									message: _('Удалить клиента «%s» (%s)?').format(peer.name, peer.ip),
									detail: _('Клиент будет безвозвратно удалён из базы и списка доверенных пиров сервера. Он больше не сможет подключаться.'),
									confirmText: _('Удалить'),
									tone: 'danger',
									icon: '🗑️'
								});
							}
						}, ['🗑️'])
					])
				]);
				peerCards.push(card);
			})(peers[i]);
		}

		peerCards.push(E('div', { 'class': 'xfree-vpn-tunnel is-new' }, [
			E('div', { 'class': 'xfree-vpn-tunnel-top' }, [
				E('strong', {}, [_('+ Добавить клиента')]),
				E('span', { 'class': 'xfree-vpn-status is-muted' }, [_('новый')])
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-sub muted' }, [
				_('Генерация ключей → выделение IP → готовый .conf и QR-код')
			]),
			E('div', { 'class': 'xfree-vpn-tunnel-actions xfree-vpn-create-actions' }, [
				E('button', {
					'class': 'btn is-primary ghost-compact',
					'type': 'button',
					'click': function () { self._openAddPeerDialog(awg); }
				}, ['➕ ' + _('Создать клиента')])
			])
		]));

		var peersSection = E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'style': 'display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; flex-wrap:wrap; gap:8px;' }, [
				E('div', { 'style': 'display:flex; align-items:center; gap:8px;' }, [
					E('h4', { 'style': 'margin:0;' }, [
						_('Клиенты сервера (%d)').format(peers.length)
					]),
					xui.helpBtn({
						title: _('Клиенты сервера (Пиры)'),
						desc: _('Список удалённых устройств (клиентов), зарегистрированных на вашем VPN-сервере. Каждому клиенту выделяется собственный IP-адрес из подсети сервера и уникальная ключевая пара.'),
						whatDoes: _('Кнопка «QR-код» открывает код для быстрого добавления туннеля через камеру смартфона в приложении AmneziaWG. Кнопка «.conf» позволяет скачать готовый файл конфигурации.'),
						tips: _('Если роутер находится за провайдерским NAT или сменился DDNS-домен, вы можете изменить Endpoint подключения для каждого клиента по отдельности кнопкой ✏️.')
					})
				])
			]),
			E('div', { 'class': 'xfree-vpn-tunnels' }, peerCards)
		]);

		return E('div', { 'class': 'xfree-vpn-server-wrap' }, [
			serverCard,
			natCard,
			freeTurnCard,
			vkTurnCard,
			peersSection
		]);
	}

	paint() {
		var s = this._spec || {};
		var view = this._view;
		var awg = this._awgSummary || {};
		var sections = [];

		this.className = 'xfree-vpn-root';
		this.setAttribute('data-xfree-vpn', '1');
		this.setAttribute('data-xfree-vpn-server', '1');

		var isRefreshing = this._busy || this._loading;
		var peerCount = (awg.peers && awg.peers.length) || 0;

		var chips = [];
		if (this._loading && !awg.iface && awg.running == null) {
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [_('Сервер')]),
				E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 65px; height: 14px;' })])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [_('Интерфейс : Порт')]),
				E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 90px; height: 14px;' })])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [_('Подсеть')]),
				E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 75px; height: 14px;' })])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip is-loading' }, [
				E('span', { 'class': 'k' }, [_('Клиентов')]),
				E('span', { 'class': 'v' }, [E('span', { 'class': 'xfree-skeleton-line', 'style': 'width: 25px; height: 14px;' })])
			]));
		} else {
			chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.running ? ' is-ok' : ' is-bad') }, [
				E('span', { 'class': 'k' }, [_('Сервер')]),
				E('span', { 'class': 'v' }, [awg.running ? _('активен (UP)') : _('остановлен')])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [_('Интерфейс : Порт')]),
				E('span', { 'class': 'v' }, [(awg.iface || 'awg_ingress') + ' : ' + (awg.port || '51820') + ' UDP'])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [_('Подсеть')]),
				E('span', { 'class': 'v' }, [awg.addr || '10.200.200.1/24'])
			]));
			chips.push(E('div', { 'class': 'xfree-uplink-chip' + (peerCount > 0 ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [_('Клиентов')]),
				E('span', { 'class': 'v' }, [String(peerCount)])
			]));
			if (awg.freeTurnInstalled) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.freeTurnRunning ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [_('FreeTurn')]),
					E('span', { 'class': 'v' }, [awg.freeTurnRunning ? _('порт %s').format(awg.freeTurnPort || '56000') : _('остановлен')])
				]));
			}
			if (awg.vkInstalled || awg.vkRunning) {
				chips.push(E('div', { 'class': 'xfree-uplink-chip' + (awg.vkRunning ? ' is-ok' : '') }, [
					E('span', { 'class': 'k' }, [_('VK-Turn')]),
					E('span', { 'class': 'v' }, [awg.vkRunning ? _('порт %s').format(awg.vkPort || '49151') : _('остановлен')])
				]));
			}
		}

		var self = this;
		var topOps = [
			E('button', {
				'class': 'btn ghost-compact xfree-vpn-head-btn',
				'type': 'button',
				'title': _('Обновить статус сервера и пиров'),
				'disabled': isRefreshing ? true : null,
				'click': ui.createHandlerFn(view, function (ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
					else
						self.reload();
				})
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, ['🔄']),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить статус'))
			]),
			E('button', {
				'class': 'btn ghost-compact xfree-vpn-head-btn is-primary',
				'type': 'button',
				'title': _('Применить конфигурацию сервера и пиров'),
				'click': ui.createHandlerFn(view, function (ev) {
					self._act(ev, 'serverApply', '', {
						title: _('Применение настроек сервера'),
						message: _('Перезапустить VPN-сервер и применить конфигурацию интерфейса?'),
						detail: _('Сетевой интерфейс awg_ingress будет перезапущен с актуальными ключами, портами и списком клиентов.'),
						confirmText: _('Применить'),
						tone: 'primary',
						icon: '⚡'
					});
				})
			}, ['⚡ ' + _('Применить сервер')])
		];

		sections.push(
			E('div', { 'class': 'xfree-vpn-head' }, [
				E('div', { 'class': 'xfree-vpn-head-left' }, [
					E('h3', {}, [_('VPN-сервер')]),
					E('p', { 'class': 'muted' }, [_('Управление VPN-сервером AmneziaWG (Ingress), пирами и клиентскими конфигами')])
				]),
				E('div', { 'class': 'xfree-vpn-head-right' }, [
					E('div', { 'class': 'xfree-vpn-head-actions' }, topOps),
					E('div', {
						'class': 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
						'data-xfree-vpn-msg': '1'
					}, [this._msg || ''])
				])
			]),
			E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, chips)
		);

		var serverSec = this._renderServerSection(awg, view);
		if (serverSec)
			sections.push(serverSec);

		this.replaceChildren.apply(this, sections);
		if (this._busy) {
			this.querySelectorAll('button').forEach(function (el) {
				el.disabled = true;
			});
		}
	}
});

return baseclass.extend({
	TAG: TAG
});
