'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.components as components';
'require xfree-toolbox.core.loading as loading';
'require xfree-toolbox.system-updates-cards as updatesCards';

var xcmp = components;
var renderMetricRow = updatesCards.renderMetricRow;

function openAutoUpdateSettingsModal(au, view, onRefresh) {
	var curEnabled = au.enabled !== false;
	var curMode = au.modeKey || 'upstreams-lists-package';
	var curHour = (typeof au.hour === 'number' && !isNaN(au.hour)) ? au.hour : 2;
	var curMinute = (typeof au.minute === 'number' && !isNaN(au.minute)) ? au.minute : 0;

	// Mode options
	var modeOptions = [
		{ value: 'upstreams-lists-package', label: _('Списки upstream + пакет toolbox (рекомендуется)') },
		{ value: 'upstreams-lists', label: _('Только списки upstream (без пакета)') },
		{ value: 'templates-sync-apply', label: _('Обновить и применить (как в шаблонах)') }
	];

	var selectedMode = curMode;
	var selectedHour = curHour;
	var selectedMinute = curMinute;

	var selMode = E('select', {
		'class': 'cbi-input-select',
		'style': 'width: 100%; font-size: 13px;',
		'change': function(ev) { selectedMode = ev.target.value; }
	}, modeOptions.map(function(opt) {
		var attrs = { value: opt.value };
		if (opt.value === curMode) attrs.selected = 'selected';
		return E('option', attrs, [opt.label]);
	}));
	selMode.value = curMode;

	// Hour options (0..23)
	var hourOptions = [];
	for (var h = 0; h < 24; h++) {
		var hStr = (h < 10 ? '0' : '') + h;
		hourOptions.push({ value: String(h), label: hStr + ':00' });
	}

	var selHour = E('select', {
		'class': 'cbi-input-select',
		'style': 'min-width: 100px; font-size: 13px;',
		'change': function(ev) { selectedHour = parseInt(ev.target.value, 10); }
	}, hourOptions.map(function(opt) {
		var attrs = { value: opt.value };
		if (parseInt(opt.value, 10) === curHour) attrs.selected = 'selected';
		return E('option', attrs, [opt.label]);
	}));
	selHour.value = String(curHour);

	// Minute options (0..55 step 5)
	var minOptions = [];
	for (var m = 0; m < 60; m += 5) {
		var mStr = (m < 10 ? '0' : '') + m;
		minOptions.push({ value: String(m), label: mStr });
	}
	var hasMin = minOptions.some(function(opt) { return parseInt(opt.value, 10) === curMinute; });
	if (!hasMin) {
		var mCurStr = (curMinute < 10 ? '0' : '') + curMinute;
		minOptions.push({ value: String(curMinute), label: mCurStr });
		minOptions.sort(function(a, b) { return parseInt(a.value, 10) - parseInt(b.value, 10); });
	}

	var selMinute = E('select', {
		'class': 'cbi-input-select',
		'style': 'min-width: 90px; font-size: 13px;',
		'change': function(ev) { selectedMinute = parseInt(ev.target.value, 10); }
	}, minOptions.map(function(opt) {
		var attrs = { value: opt.value };
		if (parseInt(opt.value, 10) === curMinute) attrs.selected = 'selected';
		return E('option', attrs, [opt.label]);
	}));
	selMinute.value = String(curMinute);

	var chkEnabled = E('input', {
		'type': 'checkbox',
		'class': 'cbi-input-checkbox',
		'id': 'xfree-modal-au-enabled',
		'style': 'margin-right: 8px;'
	});
	if (curEnabled) chkEnabled.checked = true;

	var modalBody = E('div', {
		'class': 'xfree-au-settings-form',
		'style': 'display: flex; flex-direction: column; gap: 14px; min-width: 320px;'
	}, [
		E('div', {
			'style': 'display: flex; align-items: center; padding: 10px 12px; background: var(--panel-2, rgba(0,0,0,0.02)); border: 1px solid var(--line, rgba(0,0,0,0.08)); border-radius: 8px;'
		}, [
			chkEnabled,
			E('label', { 'for': 'xfree-modal-au-enabled', 'style': 'font-weight: 600; cursor: pointer; user-select: none;' }, [
				_('Включить фоновое автообновление (cron)')
			])
		]),

		E('div', { 'class': 'cbi-value', 'style': 'margin-bottom: 0;' }, [
			E('label', { 'class': 'cbi-value-title', 'style': 'font-weight: 600; margin-bottom: 6px; display: block;' }, [
				_('Режим обновления')
			]),
			E('div', { 'class': 'cbi-value-field' }, [
				selMode,
				E('div', { 'class': 'cbi-value-description muted', 'style': 'font-size: 12px; margin-top: 4px;' }, [
					_('Выберите состав обновлений: только списки маршрутов или также бинарный пакет xfree-toolbox.')
				])
			])
		]),

		E('div', { 'class': 'cbi-value', 'style': 'margin-bottom: 0;' }, [
			E('label', { 'class': 'cbi-value-title', 'style': 'font-weight: 600; margin-bottom: 6px; display: block;' }, [
				_('Время запуска (местное время)')
			]),
			E('div', { 'class': 'cbi-value-field' }, [
				E('div', { 'style': 'display: flex; gap: 10px; align-items: center;' }, [
					E('div', { 'style': 'display: flex; flex-direction: column; gap: 2px;' }, [
						E('span', { 'class': 'muted', 'style': 'font-size: 11px;' }, [_('Часы')]),
						selHour
					]),
					E('span', { 'style': 'font-weight: 700; font-size: 16px; margin-top: 14px;' }, [':']),
					E('div', { 'style': 'display: flex; flex-direction: column; gap: 2px;' }, [
						E('span', { 'class': 'muted', 'style': 'font-size: 11px;' }, [_('Минуты')]),
						selMinute
					])
				]),
				E('div', { 'class': 'cbi-value-description muted', 'style': 'font-size: 12px; margin-top: 6px;' }, [
					_('Задача crond будет выполняться ежедневно в указанное время роутера.')
				])
			])
		])
	]);

	xcmp.modalDialog({
		title: _('Параметры фонового автообновления'),
		body: modalBody,
		confirmText: _('Сохранить'),
		confirmTone: 'primary',
		cancelText: _('Отмена'),
		onConfirm: function() {
			var enVal = chkEnabled.checked ? '1' : '0';
			var modeVal = (selMode.value != null && selMode.value !== '') ? selMode.value : selectedMode;
			var hourVal = (selHour.value != null && selHour.value !== '') ? selHour.value : selectedHour;
			var minVal = (selMinute.value != null && selMinute.value !== '') ? selMinute.value : selectedMinute;
			var arg = enVal + '|' + modeVal + '|' + hourVal + '|' + minVal;

			var saveFn = (view && typeof view.runSystemMenu === 'function')
				? view.runSystemMenu.bind(view)
				: (view && typeof view.runSystemAction === 'function')
					? view.runSystemAction.bind(view)
					: null;

			if (!saveFn) {
				return Promise.reject(new Error(_('runSystemMenu is not available')));
			}

			return saveFn('autoUpdateSave', arg).then(function(res) {
				if (res && res.code != null && res.code !== 0) {
					var msg = res.stderr || res.stdout || ('exit ' + res.code);
					throw new Error(msg);
				}
				var timeStr = (parseInt(hourVal, 10) < 10 ? '0' : '') + parseInt(hourVal, 10) + ':' +
				              (parseInt(minVal, 10) < 10 ? '0' : '') + parseInt(minVal, 10);
				ui.addNotification(null, E('p', {}, [
					_('Настройки автообновления сохранены: ') + (enVal === '1' ? timeStr : _('выключено'))
				]), 'info');
				if (typeof onRefresh === 'function') {
					return onRefresh();
				}
			});
		}
	});
}

function renderAutoUpdateCard(info, view, onRefresh) {
	var au = info.autoUpdate;
	var isEnabled = au.enabled;
	var isRunning = au.running;

	var badgeTone = isRunning ? 'warning' : (isEnabled ? 'ok' : 'neutral');
	var badgeText = isRunning ? _('Выполняется…') : (isEnabled ? _('Включено') : _('Отключено'));

	var rows = [];

	var schedValEl = E('span', {
		'class': 'font-mono xfree-clickable-metric',
		'style': 'cursor: pointer; display: inline-flex; align-items: center; gap: 4px;' + (isEnabled ? ' color: var(--link-color, #1a73e8); font-weight: 600;' : ''),
		'title': _('Нажмите для изменения времени и режима'),
		'click': function() {
			openAutoUpdateSettingsModal(au, view, onRefresh);
		}
	}, [
		E('span', {}, [isEnabled ? (au.schedule || '02:00') : _('Не назначено')]),
		E('span', { 'class': 'btn-icon', 'style': 'opacity: 0.6; font-size: 11px;' }, ['✎'])
	]);

	rows.push(renderMetricRow(_('Расписание (cron)'), schedValEl));

	var modeValEl = E('span', {
		'class': 'xfree-clickable-metric',
		'style': 'cursor: pointer; display: inline-flex; align-items: center; gap: 4px; font-size: 12px; color: var(--link-color, #1a73e8);',
		'title': _('Нажмите для изменения режима'),
		'click': function() {
			openAutoUpdateSettingsModal(au, view, onRefresh);
		}
	}, [
		E('span', {}, [au.mode || _('Списки upstream + пакет toolbox')]),
		E('span', { 'class': 'btn-icon', 'style': 'opacity: 0.6; font-size: 11px;' }, ['✎'])
	]);

	rows.push(renderMetricRow(_('Режим'), modeValEl));

	rows.push(renderMetricRow(_('Служба планировщика'), E('span', {}, [
		au.cron === 'installed' ? 'crond (активен)' : (au.cron || 'crond')
	])));

	if (au.lastLogDate) {
		var logText = au.lastLogLine ? (au.lastLogDate + ' (' + au.lastLogLine + ')') : au.lastLogDate;
		rows.push(renderMetricRow(_('Последний запуск'), E('span', { 'class': 'muted font-mono', 'style': 'font-size: 11px;' }, [
			logText
		])));
	}

	// Actions
	var settingsBtn = xcmp.button({
		text: _('⚙️ Настроить…'),
		tone: 'secondary',
		title: _('Настроить время запуска и режим фонового автообновления'),
		onClick: function() {
			openAutoUpdateSettingsModal(au, view, onRefresh);
		}
	});

	var toggleBtn = xcmp.button({
		text: isEnabled ? _('Выключить автообновление') : _('Включить автообновление'),
		tone: isEnabled ? 'ghost' : 'primary',
		onClick: function(ev) {
			var action = isEnabled ? 'autoUpdateDisable' : 'autoUpdateEnable';
			var btn = ev.target;
			loading.track(btn, view.runSystemAction(action).then(function() {
				ui.addNotification(null, E('p', {}, [ isEnabled ? _('Автообновление выключено') : _('Автообновление включено') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var runNowBtn = xcmp.button({
		text: _('▶ Запустить сейчас'),
		tone: 'secondary',
		disabled: isRunning,
		onClick: function(ev) {
			var btn = ev.target;
			loading.track(btn, view.runSystemAction('autoUpdateRunNow').then(function() {
				ui.addNotification(null, E('p', {}, [ _('Фоновое автообновление запущено') ]), 'info');
				if (typeof onRefresh === 'function') return onRefresh();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ _('Ошибка запуска: ') + (err.message || String(err)) ]), 'error');
			}));
		}
	});

	var actions = [settingsBtn, toggleBtn];
	if (isEnabled) {
		actions.push(runNowBtn);
	}

	var actionsBar = E('div', {
		'class': 'xfree-card-actions',
		'style': 'display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line, rgba(0,0,0,0.06));'
	}, actions);

	return xcmp.card({
		title: _('Фоновое автообновление'),
		subtitle: _('Ночная синхронизация списков и пакетов по cron'),
		badge: xcmp.badge({ text: badgeText, tone: badgeTone }),
		content: [
			E('div', { 'class': 'xfree-metric-rows' }, rows),
			actionsBar
		]
	});
}

return baseclass.extend({
	openAutoUpdateSettingsModal: openAutoUpdateSettingsModal,
	renderAutoUpdateCard: renderAutoUpdateCard
});
