'use strict';
'require baseclass';
'require rpc';
'require xfree-toolbox.core.loading as loading';

/**
 * @file core/rpc-client.js
 * Layer 1 (Core Service): Умный клиент RPC-вызовов для LuCI (AI Hub OpenWrt).
 * 
 * Возможности:
 * 1. In-flight Request Collapsing (дедупликация параллельных запросов к роутеру).
 * 2. TTL-кэширование (short = 3s, long = 30s, static = 60s).
 * 3. Инвалидация кэша по ключам или префиксам при мутациях (save, apply, install).
 * 4. Безопасная обработка таймаутов rpcd/ubus.
 */

var inFlightRequests = {};
var responseCache = {};

function makeCacheKey(object, method, params) {
	try {
		return object + ':' + method + ':' + JSON.stringify(params || []);
	} catch {
		return object + ':' + method;
	}
}

/**
 * Выполнить RPC вызов с поддержкой дедупликации и кэширования.
 * @param {Function} rpcDeclareFn Функция, объявленная через rpc.declare()
 * @param {Array} params Параметры вызова
 * @param {Object} [options]
 * @param {number} [options.ttl=0] Время жизни кэша в миллисекундах (0 - без кэша)
 * @param {boolean} [options.force=false] Игнорировать существующий кэш
 * @param {string} [options.key] Пользовательский ключ для кэша и дедупликации
 * @returns {Promise<any>}
 */
function request(rpcDeclareFn, params, options) {
	options = options || {};
	var ttl = Number(options.ttl) || 0;
	var now = Date.now();

	var key = options.key;
	if (!key && rpcDeclareFn && rpcDeclareFn.description) {
		key = makeCacheKey(
			rpcDeclareFn.description.object || 'xfree-toolbox',
			rpcDeclareFn.description.method || 'unknown',
			params
		);
	}
	if (!key) {
		key = 'rpc:' + Math.random();
	}

	// 1. Проверка TTL-кэша (если не передан force: true)
	if (!options.force && ttl > 0 && responseCache[key]) {
		if (responseCache[key].expiresAt > now) {
			return Promise.resolve(responseCache[key].data);
		}
		delete responseCache[key];
	}

	// 2. In-flight Request Collapsing (дедупликация одинаковых запросов)
	if (inFlightRequests[key]) {
		return inFlightRequests[key];
	}

	// 3. Выполнение запроса
	var promise = Promise.resolve().then(function () {
		return rpcDeclareFn.apply(null, params || []);
	}).then(function (result) {
		delete inFlightRequests[key];
		if (ttl > 0) {
			responseCache[key] = {
				data: result,
				expiresAt: Date.now() + ttl
			};
		}
		return result;
	}).catch(function (err) {
		delete inFlightRequests[key];
		throw err;
	});

	inFlightRequests[key] = promise;

	if (options.loading && typeof loading !== 'undefined' && loading && loading.track) {
		var loadingOpts = typeof options.loading === 'object' ? options.loading : {};
		return loading.track(promise, loadingOpts);
	}

	return promise;
}

/**
 * Инвалидация кэша по префиксу или точному совпадению.
 * @param {string} [prefix] Префикс ключа (например 'xfree-toolbox:ifaceMenu' или 'iface')
 */
function invalidate(prefix) {
	if (!prefix) {
		responseCache = {};
		return;
	}
	var keys = Object.keys(responseCache);
	for (var i = 0; i < keys.length; i++) {
		if (keys[i].indexOf(prefix) !== -1) {
			delete responseCache[keys[i]];
		}
	}
}

return baseclass.extend({
	request: request,
	invalidate: invalidate,

	// Стандартные TTL константы (мс)
	TTL_NONE: 0,
	TTL_SHORT: 3000,      // 3 секунды (быстро меняющиеся статусы туннелей)
	TTL_MEDIUM: 10000,    // 10 секунд (списки интерфейсов, PBR)
	TTL_LONG: 30000,      // 30 секунд (пакеты, протоколы)
	TTL_STATIC: 60000     // 60 секунд (информация о хосте, версии)
});

