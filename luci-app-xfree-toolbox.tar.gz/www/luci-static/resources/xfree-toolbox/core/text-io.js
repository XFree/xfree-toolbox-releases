'use strict';
'require baseclass';

/* Запись текста наружу: буфер обмена и скачивание файла.
 * Подпись кнопки и текст уведомления остаются у вызывающего. */

function fallbackCopy(text) {
	var ta = document.createElement('textarea');
	ta.value = text;
	ta.style.position = 'fixed';
	ta.style.top = '0';
	ta.style.left = '0';
	ta.style.opacity = '0';
	document.body.appendChild(ta);
	ta.focus();
	ta.select();
	try {
		return document.execCommand('copy');
	} catch {
		return false;
	} finally {
		document.body.removeChild(ta);
	}
}

function writeText(text) {
	return new Promise(function (resolve, reject) {
		if (!text) {
			reject(new Error('empty'));
			return;
		}
		var copied = function () { resolve(); };
		var failed = function () { reject(new Error('copy')); };
		if (navigator && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
			navigator.clipboard.writeText(text).then(copied).catch(function () {
				if (fallbackCopy(text))
					copied();
				else
					failed();
			});
			return;
		}
		if (fallbackCopy(text))
			copied();
		else
			failed();
	});
}

function downloadText(filename, text) {
	var blob = new Blob([text == null ? '' : String(text)], { type: 'text/plain;charset=utf-8' });
	var url = URL.createObjectURL(blob);
	var a = document.createElement('a');
	a.href = url;
	a.download = filename || 'download.txt';
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	setTimeout(function () { URL.revokeObjectURL(url); }, 500);
}

return baseclass.extend({
	writeText: writeText,
	downloadText: downloadText
});
