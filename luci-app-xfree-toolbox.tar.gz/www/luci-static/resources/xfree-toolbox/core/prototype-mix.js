'use strict';
'require baseclass';

/* Смешивание методов соседних модулей на один прототип.
 * LuCI require возвращает экземпляр: функции лежат и на объекте, и на его прототипе. */

var MIX_SKIP = {
	constructor: true,
	extend: true,
	super: true,
	call: true,
	apply: true,
	bind: true
};

function mixInto(targetProto, part) {
	var srcs = [part];
	var proto = part && Object.getPrototypeOf(part);

	if (!targetProto)
		return;
	if (proto && proto !== Object.prototype)
		srcs.push(proto);
	srcs.forEach(function (src) {
		if (!src)
			return;
		Object.getOwnPropertyNames(src).forEach(function (key) {
			if (MIX_SKIP[key] || key.indexOf('__') === 0)
				return;
			if (typeof src[key] !== 'function')
				return;
			targetProto[key] = src[key];
		});
	});
}

return baseclass.extend({
	mixInto: mixInto
});
