'use strict';
'require baseclass';
'require dom';

/**
 * @file core/loading.js
 * Layer 1 (Core Service): Централизованный сервис управления состояниями загрузки.
 * Предоставляет:
 * - Глобальные индикаторы (Top Progress Bar, Glasspane Overlay);
 * - Локальное затемнение контейнеров (.is-loading-container, .xfree-target-loader);
 * - Кнопочные состояния (.spinning, disabled, авто-сохранение и возврат текста);
 * - Reference Counting (счетчик параллельных задач);
 * - Дебаунс/задержку показа (delay) для исключения моргания при быстрых ответах;
 * - Автоматический трекинг Promise: track(promise, options).
 */

var globalCount = 0;
var topProgressElem = null;
var overlayElem = null;
var targetRegistry = new WeakMap();
var buttonRegistry = new WeakMap();
var listeners = [];

function notify(state) {
	for (var i = 0; i < listeners.length; i++) {
		try {
			listeners[i](state);
		} catch {
			// Изолируем ошибки внешних подписчиков
		}
	}
}

function resolveElem(el) {
	if (typeof el === 'string') {
		return document.querySelector(el);
	}
	return el;
}

function ensureTopProgress() {
	if (topProgressElem && topProgressElem.parentNode) return topProgressElem;
	if (typeof document === 'undefined') return null;
	topProgressElem = document.createElement('div');
	topProgressElem.className = 'xfree-top-progress is-indeterminate';
	var bar = document.createElement('div');
	bar.className = 'xfree-top-progress-bar';
	topProgressElem.appendChild(bar);
	document.body.appendChild(topProgressElem);
	return topProgressElem;
}

function removeTopProgress() {
	if (topProgressElem && topProgressElem.parentNode) {
		topProgressElem.parentNode.removeChild(topProgressElem);
		topProgressElem = null;
	}
}

function showOverlay(message) {
	if (typeof document === 'undefined') return;
	if (overlayElem && overlayElem.parentNode) {
		var msgNode = overlayElem.querySelector('.xfree-overlay-loader-text');
		if (msgNode && message) msgNode.textContent = message;
		return;
	}
	overlayElem = document.createElement('div');
	overlayElem.className = 'xfree-overlay-loader';

	var card = document.createElement('div');
	card.className = 'xfree-overlay-loader-card';

	var spinner = document.createElement('div');
	spinner.className = 'xfree-spinner xfree-spinner-lg';
	card.appendChild(spinner);

	if (message) {
		var text = document.createElement('div');
		text.className = 'xfree-overlay-loader-text';
		text.textContent = message;
		card.appendChild(text);
	}

	overlayElem.appendChild(card);
	document.body.appendChild(overlayElem);
}

function removeOverlay() {
	if (overlayElem && overlayElem.parentNode) {
		overlayElem.parentNode.removeChild(overlayElem);
		overlayElem = null;
	}
}

return baseclass.extend({
	/**
	 * Запуск глобальной загрузки
	 * @param {Object} [opts]
	 * @param {string} [opts.message] Текст сообщения для блокирующего оверлея
	 * @param {boolean} [opts.overlay=false] Показывать ли модальный оверлей
	 */
	startGlobal: function (opts) {
		opts = opts || {};
		globalCount++;
		ensureTopProgress();
		if (opts.message || opts.overlay) {
			showOverlay(opts.message || 'Загрузка...');
		}
		notify({ type: 'global', count: globalCount, loading: true });
	},

	/**
	 * Остановка глобальной загрузки
	 */
	stopGlobal: function () {
		if (globalCount <= 0) return;
		globalCount--;
		if (globalCount === 0) {
			removeTopProgress();
			removeOverlay();
			notify({ type: 'global', count: 0, loading: false });
		} else {
			notify({ type: 'global', count: globalCount, loading: true });
		}
	},

	/**
	 * Запуск локальной загрузки над DOM-контейнером
	 * @param {HTMLElement|string} target
	 * @param {Object} [opts]
	 * @param {string} [opts.message]
	 */
	startTarget: function (target, opts) {
		var el = resolveElem(target);
		if (!el) return;
		opts = opts || {};

		var entry = targetRegistry.get(el) || { count: 0, loader: null };
		entry.count++;

		if (entry.count === 1) {
			el.classList.add('is-loading-container');

			var loader = document.createElement('div');
			loader.className = 'xfree-target-loader';

			var spin = document.createElement('div');
			spin.className = 'xfree-spinner';
			loader.appendChild(spin);

			if (opts.message) {
				var txt = document.createElement('div');
				txt.className = 'loader-text';
				txt.textContent = opts.message;
				loader.appendChild(txt);
			}

			el.appendChild(loader);
			entry.loader = loader;
		}
		targetRegistry.set(el, entry);
		notify({ type: 'target', target: el, count: entry.count, loading: true });
	},

	/**
	 * Остановка локальной загрузки над DOM-контейнером
	 * @param {HTMLElement|string} target
	 */
	stopTarget: function (target) {
		var el = resolveElem(target);
		if (!el) return;

		var entry = targetRegistry.get(el);
		if (!entry || entry.count <= 0) return;

		entry.count--;
		if (entry.count === 0) {
			if (entry.loader && entry.loader.parentNode) {
				entry.loader.parentNode.removeChild(entry.loader);
			}
			el.classList.remove('is-loading-container');
			targetRegistry.delete(el);
			notify({ type: 'target', target: el, count: 0, loading: false });
		} else {
			targetRegistry.set(el, entry);
			notify({ type: 'target', target: el, count: entry.count, loading: true });
		}
	},

	/**
	 * Запуск загрузки на кнопке
	 * @param {HTMLElement|string} button
	 * @param {Object} [opts]
	 * @param {string} [opts.text]
	 */
	startButton: function (button, opts) {
		var btn = resolveElem(button);
		if (!btn) return;
		opts = opts || {};

		if (!buttonRegistry.has(btn)) {
			buttonRegistry.set(btn, {
				origHtml: btn.innerHTML,
				origDisabled: btn.disabled
			});
		}

		btn.disabled = true;
		btn.classList.add('spinning');
		if (opts.text) {
			btn.textContent = opts.text;
		}
		notify({ type: 'button', button: btn, loading: true });
	},

	/**
	 * Остановка загрузки на кнопке
	 * @param {HTMLElement|string} button
	 */
	stopButton: function (button) {
		var btn = resolveElem(button);
		if (!btn) return;

		var state = buttonRegistry.get(btn);
		if (state) {
			btn.innerHTML = state.origHtml;
			btn.disabled = state.origDisabled;
			buttonRegistry.delete(btn);
		}
		btn.classList.remove('spinning');
		notify({ type: 'button', button: btn, loading: false });
	},

	/**
	 * Автоматический трекинг промиса.
	 * Поддерживает оба вызова:
	 *   track(promise, opts)
	 *   track(buttonOrTarget, promise, opts)  — удобная форма панелей
	 * @param {Promise|HTMLElement|string} promiseOrTarget
	 * @param {Object|Promise} [optsOrPromise]
	 * @param {Object} [maybeOpts]
	 * @returns {Promise}
	 */
	track: function (promiseOrTarget, optsOrPromise, maybeOpts) {
		var promise = promiseOrTarget;
		var opts = optsOrPromise || {};
		var self = this;
		var type;
		var delay;
		var active = false;
		var timer = null;

		// track(btn, promise[, opts]) — первый аргумент не thenable
		if (promiseOrTarget && typeof promiseOrTarget.then !== 'function' &&
			optsOrPromise && typeof optsOrPromise.then === 'function') {
			promise = optsOrPromise;
			opts = maybeOpts || {};
			if (!opts.button && !opts.target) {
				var el = promiseOrTarget;
				// Клик часто приходит по дочернему span/иконке внутри кнопки.
				if (el && typeof el.closest === 'function') {
					var btnEl = el.closest('button, .btn, .cbi-button, .xfree-btn');
					if (btnEl) el = btnEl;
				}
				if (el && (el.tagName === 'BUTTON' ||
					(el.classList && (
						el.classList.contains('btn') ||
						el.classList.contains('cbi-button') ||
						el.classList.contains('xfree-btn')
					)))) {
					opts.button = el;
				} else {
					opts.target = el || promiseOrTarget;
				}
			}
		}

		if (!promise || typeof promise.then !== 'function') {
			return Promise.reject(new TypeError('loading.track: ожидается Promise'));
		}

		type = opts.type || (opts.button ? 'button' : (opts.target ? 'target' : 'global'));
		delay = typeof opts.delay === 'number' ? opts.delay : 0;

		function start() {
			active = true;
			if (type === 'button') {
				self.startButton(opts.button || opts.target, opts);
			} else if (type === 'target') {
				self.startTarget(opts.target, opts);
			} else {
				self.startGlobal(opts);
			}
		}

		function stop() {
			if (timer) {
				clearTimeout(timer);
				timer = null;
			}
			if (active) {
				if (type === 'button') {
					self.stopButton(opts.button || opts.target);
				} else if (type === 'target') {
					self.stopTarget(opts.target);
				} else {
					self.stopGlobal();
				}
				active = false;
			}
		}

		if (delay > 0) {
			timer = setTimeout(start, delay);
		} else {
			start();
		}

		return promise.then(
			function (res) {
				stop();
				return res;
			},
			function (err) {
				stop();
				throw err;
			}
		);
	},

	/**
	 * Подписка на изменение состояний загрузки
	 * @param {Function} cb
	 * @returns {Function} Функция отписки
	 */
	onChange: function (cb) {
		if (typeof cb === 'function') {
			listeners.push(cb);
		}
		return function () {
			var idx = listeners.indexOf(cb);
			if (idx >= 0) listeners.splice(idx, 1);
		};
	},

	/**
	 * Получить текущее количество активных глобальных операций
	 * @returns {number}
	 */
	getGlobalCount: function () {
		return globalCount;
	}
});

