'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.luci-ui as xui';

var TAG = 'xfree-mesh';

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		var self = this;
		this._spec = spec || {};
		this._status = (spec && spec.status) || {
			hasWpadMesh: false,
			hasMeshIf: false,
			meshDisabled: false,
			meshId: '',
			mobilityDomain: '',
			channel5g: '',
			stp: false,
			role: 'standalone',
			interfaces: []
		};
		this._interfaces = (this._status.interfaces || []).slice();
		this._mobilityDomain = this._status.mobilityDomain || (this._status.meshId ? (this._status.meshId.replace(/[^a-fA-F0-9]/g, '').slice(0, 4) || '4f2a') : '4f2a');
		if (!this._mobilityDomain || this._mobilityDomain.length !== 4)
			this._mobilityDomain = '4f2a';

		this._selectedIfaces = {};
		var anyFt = false;
		this._interfaces.forEach(function(iface) {
			if (iface.ftEnabled)
				anyFt = true;
		});
		this._interfaces.forEach(function(iface) {
			if (anyFt) {
				self._selectedIfaces[iface.section] = !!iface.ftEnabled;
			} else {
				var isIotOrGuest = /iot|guest|гост/i.test(iface.ssid || '') || iface.network === 'guest';
				self._selectedIfaces[iface.section] = !isIotOrGuest;
			}
		});

		this._busy = !!(spec && spec.busy);
		this.setAttribute('data-xfree-mesh', '1');
		this.requestPaint();
	}

	setStatus(st) {
		var self = this;
		this._status = st || {};
		this._interfaces = (this._status.interfaces || []).slice();
		if (st.mobilityDomain && st.mobilityDomain.length === 4)
			this._mobilityDomain = st.mobilityDomain;

		var anyFt = false;
		this._interfaces.forEach(function(iface) {
			if (iface.ftEnabled)
				anyFt = true;
		});
		this._interfaces.forEach(function(iface) {
			if (anyFt) {
				self._selectedIfaces[iface.section] = !!iface.ftEnabled;
			} else if (self._selectedIfaces[iface.section] === undefined) {
				var isIotOrGuest = /iot|guest|гост/i.test(iface.ssid || '') || iface.network === 'guest';
				self._selectedIfaces[iface.section] = !isIotOrGuest;
			}
		});

		this._loading = false;
		this.requestPaint();
	}

	setBusy(busy) {
		this._busy = !!busy;
		this.querySelectorAll('button, input').forEach(function(el) {
			el.disabled = !!busy;
		});
		this.requestPaint();
	}

	_act(ev, action, arg, confirmText) {
		if (ev) {
			ev.preventDefault();
			ev.stopPropagation();
		}
		var s = this._spec || {};
		if (s.onAction)
			s.onAction(action, arg || '', confirmText || '');
	}

	render() {
		var self = this;
		var s = this._spec || {};
		var st = this._status || {};
		var ifaces = this._interfaces || [];
		var nodes = [];

		this.className = 'xfree-page';

		/* 1. Page Header */
		var statusText = _('Автономный роутер');
		var statusTone = 'warn';
		if (st.role === 'master') {
			statusText = _('Mesh Master (основной узел)');
			statusTone = 'ok';
		} else if (st.role === 'satellite') {
			statusText = _('Mesh Satellite (ведомый узел)');
			statusTone = 'ok';
		} else if (st.hasMeshIf && !st.meshDisabled) {
			statusText = _('Mesh Backhaul активен');
			statusTone = 'ok';
		}

		var isRefreshing = !!(s.loading || this._busy);
		var headActions = [
			E('button', {
				'class': 'ghost ghost-compact' + (isRefreshing ? ' is-loading' : ''),
				'type': 'button',
				'disabled': isRefreshing ? true : null,
				'title': _('Обновить состояние беспроводной сети'),
				'click': function(ev) {
					ev.preventDefault();
					if (s.onRefresh)
						s.onRefresh();
				}
			}, [
				E('span', { 'class': isRefreshing ? 'is-spinning' : '' }, [ '🔄' ]),
				' ' + (isRefreshing ? _('Обновление…') : _('Обновить'))
			])
		];

		nodes.push(E('div', { 'class': 'page-head' }, [
			E('div', { 'class': 'page-head-main' }, [
				E('p', { 'class': 'eyebrow' }, [ 'XFree toolbox' ]),
				E('h1', {}, [
					_('Беспроводная сеть, Mesh и роуминг'),
					E('span', {
						'class': 'xfree-vpn-status is-' + statusTone,
						'style': 'margin-left: 10px; font-size: 13px; font-weight: normal; vertical-align: middle;'
					}, [ statusText ])
				])
			]),
			E('div', { 'class': 'page-head-actions', 'style': 'display:flex; align-items:center; gap:8px;' }, [
				E('p', { 'class': 'muted page-head-desc' }, [
					_('Раздельная настройка 802.11s backhaul, быстрого роуминга 802.11r/k/v и защиты STP')
				]),
				E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, headActions)
			])
		]));

		/* 2. Top Metric Plaques (Chips) */
		var chips = [];
		var meshActive = !!(st.hasMeshIf && !st.meshDisabled);
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (meshActive ? 'ok' : (st.meshDisabled ? 'warn' : 'bad')) }, [
			E('span', { 'class': 'k' }, [ _('802.11s Mesh') ]),
			E('span', { 'class': 'v' }, [
				meshActive
					? (st.meshId ? st.meshId : _('активен'))
					: (st.meshDisabled ? _('отключен (кабель)') : _('не создан'))
			])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (st.mobilityDomain ? 'ok' : 'warn') }, [
			E('span', { 'class': 'k' }, [ _('Роуминг 802.11r') ]),
			E('span', { 'class': 'v' }, [ st.mobilityDomain ? ('Domain: ' + st.mobilityDomain) : _('не включен') ])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (st.stp ? 'ok' : 'warn') }, [
			E('span', { 'class': 'k' }, [ _('Мост br-lan') ]),
			E('span', { 'class': 'v' }, [ st.stp ? _('STP включен (защита ок)') : _('STP выключен!') ])
		]));
		chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip is-' + (st.hasWpadMesh ? 'ok' : 'bad') }, [
			E('span', { 'class': 'k' }, [ _('Пакет wpad') ]),
			E('span', { 'class': 'v' }, [ st.hasWpadMesh ? 'wpad-mesh (SAE/Mesh)' : _('wpad-basic (нужен mesh)') ])
		]));
		if (st.channel5g) {
			chips.push(E('div', { 'class': 'xfree-status-chip xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [ _('Канал 5 GHz') ]),
				E('span', { 'class': 'v' }, [ st.channel5g ])
			]));
		}

		nodes.push(E('div', { 'class': 'xfree-status-panel xfree-uplink-status', 'style': 'margin-bottom: 1.25rem;' }, chips));

		/* 3. Section 1: Межроутерная связь (802.11s Mesh Backhaul & STP) */
		var backhaulCards = [
			{
				icon: '👑',
				title: _('Основной узел (Mesh Master)'),
				desc: _('Настройка главного роутера сети: фиксация канала 5 GHz на 36, включение STP/IGMP Snooping на br-lan и поднятие интерфейса 802.11s Mesh с WPA3-SAE.'),
				action: 'configureMeshMaster',
				btn: _('Настроить Master'),
				confirm: _('Настроить этот роутер как основной узел (Mesh Master)? Существующие точки Wi-Fi сохраняются.')
			},
			{
				icon: '🛰️',
				title: _('Ведомый узел (Mesh Satellite)'),
				desc: _('Визард подключения сателлита: отключение DHCP и NAT/firewall, объединение WAN и LAN в мост, настройка статического IP и бэкхола к Master.'),
				action: 'configureMeshSatellite',
				btn: _('Настроить Satellite')
			}
		];

		if (meshActive) {
			backhaulCards.push({
				icon: '🔌',
				title: _('Отключить беспроводной Mesh'),
				desc: _('Интерфейс 802.11s активен. Если роутеры соединены кабелем Ethernet, отключите беспроводной mesh для освобождения радиоэфира 5 GHz.'),
				action: 'disableMeshBackhaul',
				btn: _('Отключить Mesh (только кабель)'),
				confirm: _('Отключить интерфейс 802.11s Mesh? Используйте это, если роутеры соединены проводом Ethernet.')
			});
		} else {
			backhaulCards.push({
				icon: '📡',
				title: _('Включить беспроводной Mesh'),
				desc: _('Создание или повторное включение интерфейса 802.11s Mesh на 5 GHz для беспроводного соединения между роутерами.'),
				action: 'configureMeshBackhaul',
				btn: _('Включить 802.11s Mesh'),
				confirm: _('Включить 802.11s беспроводной Mesh backhaul на 5 GHz?')
			});
		}

		nodes.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 1.25rem;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '🔗 ' + _('Межроутерная связь (Backhaul)') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Связь роутер ↔ роутер') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Объединение роутеров в единую сеть по беспроводному каналу 802.11s на 5 GHz или через кабель Ethernet. Защита от петель моста STP.')
				])
			]),
			E('div', { 'class': 'xfree-mesh-grid' }, backhaulCards.map(function(card) {
				return E('div', { 'class': 'xfree-mesh-card' }, [
					E('div', { 'class': 'xfree-mesh-card-top' }, [
						E('span', { 'class': 'xfree-mesh-card-ico' }, [ card.icon ]),
						E('strong', {}, [ card.title ])
					]),
					E('p', { 'class': 'xfree-mesh-card-desc' }, [ card.desc ]),
					E('div', { 'class': 'xfree-mesh-card-action' }, [
						E('button', {
							'class': 'cbi-button cbi-button-action',
							'type': 'button',
							'click': function(ev) {
								self._act(ev, card.action, '', card.confirm || '');
							}
						}, [ card.btn ])
					])
				]);
			}))
		]));

		/* 4. Section 2: Бесшовный роуминг клиентов (802.11r FT / 802.11k / 802.11v) */
		var domainInput = E('input', {
			'type': 'text',
			'class': 'xfree-mesh-domain-input',
			'maxlength': '4',
			'value': this._mobilityDomain || '4f2a',
			'change': function(ev) {
				self._mobilityDomain = (ev.target.value || '').trim().toLowerCase();
			}
		});

		var generateBtn = E('button', {
			'type': 'button',
			'class': 'cbi-button cbi-button-neutral',
			'click': function(ev) {
				ev.preventDefault();
				var randHex = ((Math.random() * 0xffff) | 0).toString(16).padStart(4, '0').toLowerCase();
				domainInput.value = randHex;
				self._mobilityDomain = randHex;
			}
		}, [ '🎲 ' + _('Сгенерировать') ]);

		var domainBar = E('div', { 'class': 'xfree-mesh-domain-bar' }, [
			E('strong', {}, [ _('Mobility Domain:') ]),
			domainInput,
			generateBtn,
			E('span', { 'class': 'muted', 'style': 'font-size: 12px; margin-left: 8px;' }, [
				_('4 hex-символа (0-9, a-f). Должен быть одинаковым на всех роутерах и точках доступа домашней сети.')
			])
		]);

		/* Table of Wi-Fi APs */
		var tableRows = [];
		if (ifaces.length === 0) {
			tableRows.push(E('tr', {}, [
				E('td', { 'colspan': '6', 'class': 'muted', 'style': 'text-align: center; padding: 20px;' }, [
					_('Точки доступа Wi-Fi не найдены в конфигурации /etc/config/wireless')
				])
			]));
		} else {
			ifaces.forEach(function(iface) {
				var sec = iface.section;
				var isChecked = !!self._selectedIfaces[sec];
				var chkBox = E('input', {
					'type': 'checkbox',
					'checked': isChecked ? true : null,
					'change': function(ev) {
						self._selectedIfaces[sec] = ev.target.checked;
					}
				});

				var statusBadge = iface.ftEnabled
					? E('span', { 'class': 'xfree-vpn-status is-ok' }, [ _('Включен') + (iface.mobilityDomain ? (' (' + iface.mobilityDomain + ')') : '') ])
					: E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Выключен') ]);

				var isGuest = /guest|гост/i.test(iface.ssid || '') || iface.network === 'guest';
				var isIot = /iot/i.test(iface.ssid || '');
				var ssidNodes = [ E('strong', {}, [ iface.ssid || _('(Скрытая сеть)') ]) ];

				if (isGuest) {
					ssidNodes.push(E('span', {
						'class': 'xfree-vpn-status is-warn',
						'style': 'margin-left: 6px; font-size: 11px; padding: 1px 6px;',
						'title': _('Гостевая сеть: роуминг обычно не требуется')
					}, [ '⚠️ ' + _('Гостевая сеть') ]));
				} else if (isIot) {
					ssidNodes.push(E('span', {
						'class': 'xfree-vpn-status is-warn',
						'style': 'margin-left: 6px; font-size: 11px; padding: 1px 6px;',
						'title': _('Сеть умного дома (IoT): старые датчики и розетки (ESP8266/ESP32, Tuya) могут терять связь при включенном 802.11r FT')
					}, [ '⚠️ ' + _('IoT / Умный дом') ]));
				}

				var bandBadge = iface.band && iface.band.indexOf('5') >= 0
					? E('span', { 'class': 'xfree-vpn-status is-ok', 'style': 'font-size: 11px; padding: 1px 6px;' }, [ iface.band ])
					: E('span', { 'class': 'xfree-vpn-status is-muted', 'style': 'font-size: 11px; padding: 1px 6px;' }, [ iface.band || '2.4 GHz' ]);

				tableRows.push(E('tr', {}, [
					E('td', { 'style': 'width: 40px; text-align: center;' }, [ chkBox ]),
					E('td', {}, ssidNodes),
					E('td', {}, [ bandBadge ]),
					E('td', {}, [ E('code', {}, [ iface.section + ' (' + iface.device + ')' ]) ]),
					E('td', {}, [ E('span', { 'class': 'xfree-vpn-status is-muted' }, [ iface.network || 'lan' ]) ]),
					E('td', {}, [ statusBadge ])
				]));
			});
		}

		var table = E('table', { 'class': 'xfree-mesh-table' }, [
			E('thead', {}, [
				E('tr', {}, [
					E('th', { 'style': 'width: 40px; text-align: center;' }, [ '✓' ]),
					E('th', {}, [ _('Имя сети (SSID)') ]),
					E('th', {}, [ _('Диапазон') ]),
					E('th', {}, [ _('Интерфейс') ]),
					E('th', {}, [ _('Зона') ]),
					E('th', {}, [ _('Fast Roaming (802.11r)') ])
				])
			]),
			E('tbody', {}, tableRows)
		]);

		/* Apply roaming button */
		var applyRoamingBtn = E('button', {
			'type': 'button',
			'class': 'cbi-button cbi-button-action important',
			'click': function(ev) {
				var dom = (domainInput.value || self._mobilityDomain || '').trim().toLowerCase();
				if (!/^[0-9a-fA-F]{4}$/.test(dom)) {
					ui.addNotification(null, E('p', {}, [ _('Mobility Domain должен состоять ровно из 4 шестнадцатеричных символов (0-9, a-f)') ]), 'error');
					return;
				}

				var selectedSecs = [];
				var selectedSsids = [];
				var unselectedSsids = [];
				ifaces.forEach(function(iface) {
					if (self._selectedIfaces[iface.section]) {
						selectedSecs.push(iface.section);
						selectedSsids.push(iface.ssid || iface.section);
					} else {
						unselectedSsids.push(iface.ssid || iface.section);
					}
				});

				var confirmMsg = _('Применить параметры Fast Roaming (802.11r/k/v)?\n\n') +
					_('• Mobility Domain: ') + dom + '\n' +
					_('• Включить роуминг на сетях: ') + (selectedSsids.join(', ') || _('ни на одной')) + '\n' +
					(unselectedSsids.length ? (_('• Отключить роуминг на сетях: ') + unselectedSsids.join(', ')) : '');

				var arg = dom + ' ' + selectedSecs.join(',');
				self._act(ev, 'configureMeshRoaming', arg, confirmMsg);
			}
		}, [ '⚡ ' + _('Применить Fast Roaming к выбранным сетям') ]);

		var disableAllRoamingBtn = E('button', {
			'type': 'button',
			'class': 'cbi-button cbi-button-neutral',
			'click': function(ev) {
				self._act(ev, 'disableMeshRoaming', '', _('Отключить Fast Roaming (802.11r) на всех беспроводных точках доступа?'));
			}
		}, [ _('Отключить роуминг на всех сетях') ]);

		var tableActions = E('div', { 'class': 'xfree-mesh-table-actions' }, [
			applyRoamingBtn,
			disableAllRoamingBtn
		]);

		nodes.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 1.25rem;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📱 ' + _('Бесшовный роуминг клиентов (Fast Roaming)') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Клиентский Wi-Fi') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Мгновенный переход клиентов между точками доступа (802.11r Fast BSS Transition). Отметьте галочками сети, которые должны участвовать в роуминге (рекомендуется исключить сети умного дома / IoT во избежание сбоев старых устройств).')
				])
			]),
			E('div', { 'class': 'xfree-mesh-table-card' }, [
				domainBar,
				table,
				tableActions
			])
		]));

		/* 5. Section 3: Диагностика и мониторинг */
		var diagCards = [
			{
				icon: '📡',
				title: _('Диагностика связности Mesh / Backhaul'),
				desc: _('Комплексная проверка: обнаружение 802.11s пиров, качество сигнала (RSSI), битрейт, таблица маршрутов mpath и защита от петель STP на сетевом мосту.'),
				action: 'meshDiag',
				btn: _('Запустить диагностику')
			}
		];

		nodes.push(E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-bottom: 1.25rem;' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '📊 ' + _('Диагностика и мониторинг') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Связность и пиры') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Проверка качества беспроводного бэкхола между узлами и предотвращение сетевых петель.')
				])
			]),
			E('div', { 'class': 'xfree-mesh-grid' }, diagCards.map(function(card) {
				return E('div', { 'class': 'xfree-mesh-card' }, [
					E('div', { 'class': 'xfree-mesh-card-top' }, [
						E('span', { 'class': 'xfree-mesh-card-ico' }, [ card.icon ]),
						E('strong', {}, [ card.title ])
					]),
					E('p', { 'class': 'xfree-mesh-card-desc' }, [ card.desc ]),
					E('div', { 'class': 'xfree-mesh-card-action' }, [
						E('button', {
							'class': 'cbi-button cbi-button-action',
							'type': 'button',
							'click': function(ev) {
								self._act(ev, card.action, '');
							}
						}, [ card.btn ])
					])
				]);
			}))
		]));

		/* 6. Section 4: Системные пакеты */
		var pkgCards = [
			{
				icon: '📦',
				title: _('Пакет wpad-mesh-mbedtls (802.11s)'),
				desc: _('Замена стандартного облегченного wpad-basic-mbedtls на версию с полной поддержкой 802.11s Mesh и WPA3-SAE. Требуется для беспроводного соединения узлов.'),
				action: 'installWpadMesh',
				btn: _('Установить wpad-mesh'),
				confirm: _('Заменить wpad на wpad-mesh-mbedtls? Роутер будет перезагружен после установки.')
			}
		];

		nodes.push(E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'class': 'xfree-selfroute-header' }, [
				E('div', { 'class': 'xfree-selfroute-title-row' }, [
					E('h4', {}, [ '🧩 ' + _('Системные пакеты и зависимости') ]),
					E('span', { 'class': 'xfree-vpn-status is-muted' }, [ _('Драйверы Wi-Fi') ])
				]),
				E('p', { 'class': 'muted' }, [
					_('Управление демонами аутентификации беспроводной сети.')
				])
			]),
			E('div', { 'class': 'xfree-mesh-grid' }, pkgCards.map(function(card) {
				return E('div', { 'class': 'xfree-mesh-card' }, [
					E('div', { 'class': 'xfree-mesh-card-top' }, [
						E('span', { 'class': 'xfree-mesh-card-ico' }, [ card.icon ]),
						E('strong', {}, [ card.title ])
					]),
					E('p', { 'class': 'xfree-mesh-card-desc' }, [ card.desc ]),
					E('div', { 'class': 'xfree-mesh-card-action' }, [
						E('button', {
							'class': 'cbi-button ' + (st.hasWpadMesh ? 'cbi-button-neutral' : 'cbi-button-action important'),
							'type': 'button',
							'click': function(ev) {
								self._act(ev, card.action, '', card.confirm || '');
							}
						}, [ st.hasWpadMesh ? _('Переустановить') : card.btn ])
					])
				]);
			}))
		]));

		this.replaceChildren.apply(this, nodes);
	}
});

return baseclass.extend({
	tag: TAG
});
