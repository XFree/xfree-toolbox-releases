'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.mesh-cards as meshCards';
'require xfree-toolbox.mesh-roaming as meshRoaming';
'require xfree-toolbox.mesh-view as meshView';

var TAG = 'xfree-mesh';

var MeshPanel = class extends wc.LightElement {
};

function mixMesh(part) {
	prototypeMix.mixInto(MeshPanel.prototype, part);
}

mixMesh(meshCards);
mixMesh(meshRoaming);
mixMesh(meshView);

wc.define(TAG, MeshPanel);

return baseclass.extend({
	tag: TAG
});
