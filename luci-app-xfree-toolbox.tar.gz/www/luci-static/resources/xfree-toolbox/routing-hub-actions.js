'use strict';
'require baseclass';

/* Действия сохранения и применения матрицы маршрутизации.
 * Методы вешаются на прототип xfree-routing. */

return baseclass.extend({
	_syncDomChecked: function () {
		var hub = this._hub();
		if (!hub.checked)
			hub.checked = {};

		var visibleCols = this._filteredCols(hub);
		var domChecked = {};
		for (var i = 0; i < visibleCols.length; i++)
			domChecked[visibleCols[i].key] = [];

		this.querySelectorAll('input[data-matrix-tag]').forEach(function(el) {
			var key = el.getAttribute('data-matrix-col') || '';
			var tag = el.getAttribute('data-matrix-tag') || '';
			if (!key || !tag || !el.checked)
				return;
			if (domChecked[key])
				domChecked[key].push(tag);
		});

		for (var j = 0; j < visibleCols.length; j++) {
			var k = visibleCols[j].key;
			if (domChecked[k])
				hub.checked[k] = domChecked[k];
		}
	},

	_collectMatrixByColumn: function () {
		this._syncDomChecked();
		var hub = this._hub();
		var cols = this._filteredCols(hub);
		var map = {};
		var i;

		for (i = 0; i < cols.length; i++) {
			var k = cols[i].key;
			map[k] = { col: cols[i], tags: (hub.checked && hub.checked[k]) || [] };
		}

		return map;
	},

	_detectColumnChanges: function () {
		this._syncDomChecked();
		var self = this;
		var hub = this._hub();
		var allCols = (hub && hub.columns) || [];
		var curChecked = (hub && hub.checked) || {};
		var initial = self._initialChecked || {};
		var changedKeys = [];
		var changedTargets = {
			iface: false,
			wan6: false,
			dns: false,
			zapret: false
		};
		var colMap = {};

		allCols.forEach(function(col) {
			colMap[col.key] = col;
			var curTags = curChecked[col.key] || [];
			var initTags = initial[col.key] || [];
			if (!self._tagsEqual(initTags, curTags)) {
				changedKeys.push(col.key);
				var tgt = col.target;
				if (tgt === 'vpn') tgt = 'iface';
				if (changedTargets[tgt] !== undefined)
					changedTargets[tgt] = true;
			}
		});

		return {
			changedKeys: changedKeys,
			changedTargets: changedTargets,
			hasRouting: changedTargets.iface || changedTargets.wan6 || changedTargets.dns,
			hasZapret: changedTargets.zapret,
			colMap: colMap
		};
	},

	_setStatus: function (text) {
		var hub = this._hub();
		var el = this.querySelector('[data-routing-status]');

		hub.statusText = text || '';
		if (el)
			el.textContent = hub.statusText;
	},

	_persistMatrix: function (keysToSave) {
		var self = this;
		var xui = this._xui();
		var hub = this._hub();
		var allCols = (hub && hub.columns) || [];
		var curChecked = (hub && hub.checked) || {};
		var colMap = {};
		allCols.forEach(function(c) { colMap[c.key] = c; });

		this._syncDomChecked();

		var keys = Array.isArray(keysToSave) && keysToSave.length > 0 ? keysToSave : Object.keys(colMap);
		var chain = Promise.resolve();
		var n = 0;

		this._setStatus(_('Сохранение…'));

		keys.forEach(function(key) {
			var col = colMap[key];
			if (!col) return;
			var tags = curChecked[key] || [];

			chain = chain.then(function() {
				n++;
				self._setStatus(_('Сохранение %s/%s: %s…').format(
					n, keys.length, col.label || col.scope));
				return xui.saveUpstreamTags(col.target, col.scope, col.mode, tags);
			});
		});

		return chain;
	},

	_reloadGeneral: function () {
		var self = this;
		var xui = this._xui();
		var view = this._view();
		var curTarget = this._activeTarget || this._selTarget();
		var isExclude = !!this._isExclude;

		return xui.loadRoutingHub(view, { view: isExclude ? 'exclude' : 'general', tab: isExclude ? 'exclude' : curTarget }, isExclude).then(function(next) {
			self._initialChecked = self._cloneChecked(next.checked);
			self._lastMountedHub = next;
			self.mount({ xui: xui, view: view, hub: next });
			self._activeTarget = curTarget;
			self.requestPaint();
		});
	},

	_saveMatrix: function () {
		var self = this;
		var changes = this._detectColumnChanges();
		var keysToSave = changes.changedKeys.length > 0 ? changes.changedKeys : null;

		return this._persistMatrix(keysToSave).then(function() {
			self._setStatus(_('Сохранено.'));
			return self._reloadGeneral();
		}).catch(function(err) {
			self._setStatus((err && err.message) || String(err));
		});
	},

	_applyMatrix: function () {
		var self = this;
		var xui = this._xui();
		var dlg;
		var logParts = [];
		var changes = this._detectColumnChanges();
		var activeTarget = this._activeTarget || this._selTarget();
		var hasZapretCol = (this._hub().columns || []).some(function(c) {
			return c.target === 'zapret';
		});

		var shouldApplyRouting = false;
		var shouldApplyZapret = false;

		if (changes.hasRouting && changes.hasZapret) {
			shouldApplyRouting = true;
			shouldApplyZapret = true;
		} else if (changes.hasZapret) {
			shouldApplyZapret = true;
			shouldApplyRouting = false;
		} else if (changes.hasRouting) {
			shouldApplyRouting = true;
			shouldApplyZapret = false;
		} else {
			// No changes detected: apply based on active tab or all
			if (activeTarget === 'zapret') {
				shouldApplyZapret = true;
				shouldApplyRouting = false;
			} else if (activeTarget === 'vpn' || activeTarget === 'dns') {
				shouldApplyRouting = true;
				shouldApplyZapret = false;
			} else {
				shouldApplyRouting = true;
				shouldApplyZapret = hasZapretCol;
			}
		}

		var confirmMsg;
		if (shouldApplyZapret && !shouldApplyRouting) {
			confirmMsg = _('Сохранить и применить списки для Zapret?');
		} else if (shouldApplyRouting && !shouldApplyZapret) {
			confirmMsg = _('Сохранить и применить маршрутизацию (VPN/DNS)?');
		} else {
			confirmMsg = _('Сохранить матрицу и применить маршрутизацию (VPN/DNS) и Zapret?');
		}

		if (!window.confirm(confirmMsg))
			return;

		dlg = xui.openExecOutputDialog(_('Применить'));
		dlg.setStatus(_('Сохранение…'));
		dlg.setText(_('Сохранение матрицы…'));
		this._setStatus(_('Сохранение…'));

		var keysToSave = changes.changedKeys.length > 0 ? changes.changedKeys : null;

		this._persistMatrix(keysToSave).then(function() {
			logParts.push(_('=== Сохранение ==='));
			logParts.push(_('Готово.'));
			dlg.setText(logParts.join('\n'));

			if (!shouldApplyRouting)
				return null;

			dlg.setStatus(_('Применение маршрутизации…'));
			return xui.runIfaceMenu('applyRouting', '');
		}).then(function(res) {
			if (res) {
				logParts.push('');
				logParts.push(_('=== VPN / DNS ==='));
				logParts.push(xui.formatExecReport(res));
				dlg.setText(logParts.join('\n'));
				if (res && res.code && res.code !== 0)
					return Promise.reject(new Error((res && res.stderr) || _('Ошибка apply routing')));
				if (xui.ifaceTaskRunning(res)) {
					dlg.setStatus(_('Применение в фоне…'));
					return xui.pollWizardApplyTask(self, self._view(), 'matrix', dlg, 0);
				}
			}
			return null;
		}).then(function() {
			if (!shouldApplyZapret)
				return null;
			dlg.setStatus(_('Применение Zapret…'));
			return xui.runZapretMenu('applyLists', '');
		}).then(function(res) {
			if (res) {
				logParts.push('');
				logParts.push(_('=== Zapret ==='));
				logParts.push(xui.formatExecReport(res));
				dlg.setText(logParts.join('\n'));
				if (res.code && res.code !== 0)
					return Promise.reject(new Error((res && res.stderr) || _('Ошибка apply zapret')));
			}
			dlg.setStatus(_('Применено.'));
			dlg.setDone(true);
			self._setStatus(_('Применено.'));
			return self._reloadGeneral();
		}).catch(function(err) {
			var msg = (err && err.message) || String(err);

			logParts.push('');
			logParts.push(msg);
			dlg.setText(logParts.join('\n'));
			dlg.setStatus(msg);
			dlg.setDone(false);
			self._setStatus(msg);
		});
	}
});
