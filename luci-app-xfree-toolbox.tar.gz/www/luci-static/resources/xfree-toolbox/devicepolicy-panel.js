'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-vpn-devicepolicy';

function escapeId(name) {
	return String(name || '')
		.toLowerCase()
		.replace(/[^a-z0-9_-]+/g, '_')
		.replace(/^_+|_+$/g, '') || 'dev_' + Date.now().toString(36);
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._view = spec.view || null;
		this._devices = spec.devices || [];
		this._leases = spec.leases || [];
		this._loading = !!spec.loading;
		this._msg = spec.message || '';
		this._msgTone = spec.messageTone || '';
		this._dirty = false;

		if (!this._devices.length && !this._loading) {
			this.reload();
		} else {
			this.requestPaint();
		}
	}

	reload() {
		var self = this;
		this._loading = true;
		this.requestPaint();

		return Promise.all([
			xui.runIfaceMenu('devicePolicyList').catch(function () { return ''; }),
			xui.runIfaceMenu('devicePolicyLeases').catch(function () { return ''; })
		]).then(function (results) {
			self._devices = xui.parseDevicePolicyList(results[0]);
			self._leases = xui.parseDevicePolicyLeases(results[1]);
			self._loading = false;
			self.requestPaint();
		}).catch(function (err) {
			self._loading = false;
			self._msg = (err && err.message) || String(err);
			self._msgTone = 'bad';
			self.requestPaint();
		});
	}

	_setMsg(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var msgEl = this.querySelector('[data-xfree-dp-msg]');
		if (msgEl) {
			msgEl.className = 'xfree-vpn-msg' + (tone ? ' is-' + tone : '');
			msgEl.textContent = text || '';
		}
	}

	_applyRules() {
		var self = this;

		ui.showModal(_('Применение исключений устройств'), [
			E('p', { 'class': 'spinning' }, [_('Применение правил Direct WAN Bypass в nftables…')])
		]);

		return xui.runIfaceMenu('devicePolicyApply').then(function (res) {
			ui.hideModal();
			var out = xui.formatExecReport(res);
			self._setMsg(_('Правила исключений успешно применены в nftables.'), 'ok');
			self.reload();
			if (res && res.code === 0) {
				ui.addNotification(null, E('p', {}, [_('Исключения устройств успешно применены.')]), 'info');
			} else {
				ui.addNotification(null, E('p', {}, [_('Результат применения: %s').format(out || 'OK')]), 'info');
			}
		}).catch(function (err) {
			ui.hideModal();
			self._setMsg((err && err.message) || String(err), 'bad');
			ui.addNotification(null, E('p', {}, [_('Ошибка применения: %s').format(err && err.message ? err.message : String(err))]), 'error');
		});
	}

	_openEditDialog(dev, defaultValues) {
		var self = this;
		var isNew = !dev;
		var cur = dev || defaultValues || {};

		var nameInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': _('Например: Proxmox VM, Smart TV'),
			'value': cur.name || ''
		});

		var ipInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text font-mono',
			'style': 'width: 100%;',
			'placeholder': _('192.168.31.51 или 192.168.31.0/24'),
			'value': cur.ip || ''
		});

		var macInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text font-mono',
			'style': 'width: 100%;',
			'placeholder': _('aa:bb:cc:dd:ee:ff'),
			'value': cur.mac || ''
		});

		var skipVpnCheck = E('input', {
			'type': 'checkbox',
			'id': 'dp_skip_vpn',
			'checked': cur.skipVpn !== false ? true : null
		});

		var skipZapretCheck = E('input', {
			'type': 'checkbox',
			'id': 'dp_skip_zapret',
			'checked': cur.skipZapret !== false ? true : null
		});

		var commentInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': _('Комментарий или назначение устройства'),
			'value': cur.comment || ''
		});

		var errorBox = E('div', {
			'class': 'xfree-vpn-msg is-bad',
			'style': 'margin-top: 8px; display: none;'
		});

		var modalContent = E('div', { 'class': 'xfree-dialog-body', 'style': 'display: flex; flex-direction: column; gap: 12px;' }, [
			E('p', { 'class': 'muted' }, [
				_('Укажите сетевые параметры устройства (IP-адрес или MAC-адрес). Трафик клиента будет направлен напрямую в физический WAN провайдера.')
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Имя устройства *')]),
				E('div', { 'class': 'cbi-value-field' }, [nameInput])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('IP-адрес или CIDR')]),
				E('div', { 'class': 'cbi-value-field' }, [
					ipInput,
					E('div', { 'class': 'cbi-value-description' }, [_('Одиночный IP (192.168.1.50) или подсеть (192.168.1.0/24)')])
				])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('MAC-адрес')]),
				E('div', { 'class': 'cbi-value-field' }, [
					macInput,
					E('div', { 'class': 'cbi-value-description' }, [_('Аппаратный MAC-адрес сетевой карты (формат: 00:11:22:33:44:55)')])
				])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Правила обхода')]),
				E('div', { 'class': 'cbi-value-field', 'style': 'display: flex; flex-direction: column; gap: 8px;' }, [
					E('label', { 'style': 'display: flex; align-items: center; gap: 8px; cursor: pointer;' }, [
						skipVpnCheck,
						E('span', {}, [
							E('strong', {}, [_('Обход VPN-туннелей (Direct WAN)')]),
							E('span', { 'class': 'muted' }, [_(' — трафик не маркируется и не идет в VPN')])
						])
					]),
					E('label', { 'style': 'display: flex; align-items: center; gap: 8px; cursor: pointer;' }, [
						skipZapretCheck,
						E('span', {}, [
							E('strong', {}, [_('Обход Zapret (NFQUEUE)')]),
							E('span', { 'class': 'muted' }, [_(' — трафик не подвергается десинхронизации')])
						])
					])
				])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Примечание')]),
				E('div', { 'class': 'cbi-value-field' }, [commentInput])
			]),
			errorBox
		]);

		ui.showModal(isNew ? _('Добавить исключение устройства') : _('Редактировать исключение устройства'), [
			modalContent,
			E('div', { 'class': 'right', 'style': 'margin-top: 16px; display: flex; justify-content: flex-end; gap: 8px;' }, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': function () { ui.hideModal(); }
				}, [_('Отмена')]),
				E('button', {
					'class': 'btn primary-large is-primary',
					'type': 'button',
					'click': function () {
						var name = nameInput.value.trim();
						var ip = ipInput.value.trim();
						var mac = macInput.value.trim();
						var sv = skipVpnCheck.checked ? 1 : 0;
						var sz = skipZapretCheck.checked ? 1 : 0;
						var com = commentInput.value.trim();

						if (!name) {
							errorBox.textContent = _('Укажите имя устройства');
							errorBox.style.display = 'block';
							nameInput.focus();
							return;
						}
						if (!ip && !mac) {
							errorBox.textContent = _('Необходимо указать хотя бы IP-адрес или MAC-адрес устройства');
							errorBox.style.display = 'block';
							ipInput.focus();
							return;
						}

						var devId = isNew ? escapeId(name) : (cur.id || escapeId(name));
						var arg = [devId, name, ip, mac, sv, sz, com].join('|');

						errorBox.style.display = 'none';
						ui.showModal(_('Сохранение'), [
							E('p', { 'class': 'spinning' }, [_('Сохранение правила…')])
						]);

						xui.runIfaceMenu('devicePolicySave', arg).then(function () {
							ui.hideModal();
							self._setMsg(_('Правило сохранено. Нажмите «⚡ Применить правила» для активации в nftables.'), 'warn');
							self.reload();
						}).catch(function (err) {
							ui.hideModal();
							ui.addNotification(null, E('p', {}, [_('Ошибка сохранения: %s').format(err && err.message ? err.message : String(err))]), 'error');
						});
					}
				}, [_('Сохранить')])
			])
		]);
	}

	_deleteRule(dev) {
		var self = this;
		if (!dev || !dev.id) return;

		var confirmMsg = _('Удалить исключение для «%s» (%s)?').format(dev.name, dev.ip || dev.mac || dev.id);

		if (!confirm(confirmMsg))
			return;

		ui.showModal(_('Удаление'), [
			E('p', { 'class': 'spinning' }, [_('Удаление правила…')])
		]);

		xui.runIfaceMenu('devicePolicyDelete', dev.id).then(function () {
			ui.hideModal();
			self._setMsg(_('Правило удалено. Нажмите «⚡ Применить правила» для обновления nftables.'), 'warn');
			self.reload();
		}).catch(function (err) {
			ui.hideModal();
			ui.addNotification(null, E('p', {}, [_('Ошибка удаления: %s').format(err && err.message ? err.message : String(err))]), 'error');
		});
	}

	render() {
		var self = this;
		var devices = this._devices || [];
		var leases = this._leases || [];
		var isLoading = this._loading;

		// Summary counters
		var totalRules = devices.length;
		var skipVpnCount = 0;
		var skipZapretCount = 0;
		var existingIps = {};
		var existingMacs = {};

		for (var i = 0; i < devices.length; i++) {
			var d = devices[i];
			if (d.skipVpn) skipVpnCount++;
			if (d.skipZapret) skipZapretCount++;
			if (d.ip) existingIps[d.ip] = true;
			if (d.mac) existingMacs[d.mac.toLowerCase()] = true;
		}

		// 1. Header
		var head = E('div', { 'class': 'xfree-vpn-head' }, [
			E('div', { 'class': 'xfree-vpn-head-left' }, [
				E('h3', {}, [_('Исключения устройств (Direct WAN Bypass)')]),
				E('p', { 'class': 'muted' }, [
					_('Прямой выход выбранных клиентов (по IP или MAC) в интернет через чистый WAN в обход всех VPN-туннелей и десинхронизации Zapret.')
				])
			]),
			E('div', { 'class': 'xfree-vpn-head-right' }, [
				E('div', { 'class': 'xfree-vpn-head-actions' }, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'disabled': isLoading ? true : null,
						'click': function () { self.reload(); }
					}, [
						E('span', { 'class': isLoading ? 'is-spinning' : '' }, ['🔄']),
						' ' + (isLoading ? _('Обновление…') : _('Обновить'))
					]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function () { self._openEditDialog(); }
					}, ['+ ' + _('Добавить устройство')]),
					E('button', {
						'class': 'btn ghost-compact xfree-vpn-head-btn is-primary',
						'type': 'button',
						'click': function () { self._applyRules(); }
					}, ['⚡ ' + _('Применить правила')])
				]),
				E('div', {
					'class': 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
					'data-xfree-dp-msg': '1'
				}, [this._msg || ''])
			])
		]);

		// 2. Status Chips
		var chips = E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, [
			E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [_('Исключений')]),
				E('span', { 'class': 'v' }, [String(totalRules)])
			]),
			E('div', { 'class': 'xfree-uplink-chip' + (skipVpnCount > 0 ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [_('Обход VPN')]),
				E('span', { 'class': 'v' }, [String(skipVpnCount)])
			]),
			E('div', { 'class': 'xfree-uplink-chip' + (skipZapretCount > 0 ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [_('Обход Zapret')]),
				E('span', { 'class': 'v' }, [String(skipZapretCount)])
			]),
			E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [_('Клиентов в сети')]),
				E('span', { 'class': 'v' }, [String(leases.length)])
			])
		]);

		// 3. Section: Configured Rules Table
		var rulesTable;
		if (devices.length === 0) {
			rulesTable = E('div', { 'class': 'xfree-card', 'style': 'padding: 16px; text-align: center;' }, [
				E('p', { 'class': 'muted' }, [
					_('Нет настроенных исключений. Добавьте устройство вручную или выберите из списка обнаруженных клиентов сети ниже.')
				])
			]);
		} else {
			var rows = [];
			devices.forEach(function (dev) {
				var isDirectWan = dev.skipVpn && dev.skipZapret;
				var modeBadge = isDirectWan
					? E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'font-weight: 600;' }, ['⚡ ' + _('Direct WAN')])
					: E('span', { 'class': 'xfree-vpn-badge is-muted' }, [_('Выборочно')]);

				rows.push(E('tr', {}, [
					E('td', {}, [
						E('div', { 'style': 'font-weight: 600;' }, [dev.name || dev.id]),
						dev.comment ? E('div', { 'class': 'muted font-xs' }, [dev.comment]) : ''
					]),
					E('td', { 'class': 'font-mono' }, [dev.ip || '—']),
					E('td', { 'class': 'font-mono' }, [dev.mac || '—']),
					E('td', {}, [
						dev.skipVpn
							? E('span', { 'class': 'xfree-vpn-status-dot is-ok', 'title': _('Обход VPN активен') })
							: E('span', { 'class': 'xfree-vpn-status-dot is-bad', 'title': _('VPN включен') }),
						dev.skipVpn ? ' ' + _('Да') : ' ' + _('Нет')
					]),
					E('td', {}, [
						dev.skipZapret
							? E('span', { 'class': 'xfree-vpn-status-dot is-ok', 'title': _('Обход Zapret активен') })
							: E('span', { 'class': 'xfree-vpn-status-dot is-bad', 'title': _('Zapret включен') }),
						dev.skipZapret ? ' ' + _('Да') : ' ' + _('Нет')
					]),
					E('td', {}, [modeBadge]),
					E('td', { 'style': 'text-align: right;' }, [
						E('div', { 'style': 'display: flex; gap: 4px; justify-content: flex-end;' }, [
							E('button', {
								'class': 'btn ghost-compact',
								'type': 'button',
								'title': _('Редактировать правило'),
								'click': function () { self._openEditDialog(dev); }
							}, ['✏️']),
							E('button', {
								'class': 'btn ghost-compact',
								'type': 'button',
								'style': 'color: var(--bad);',
								'title': _('Удалить правило'),
								'click': function () { self._deleteRule(dev); }
							}, ['🗑️'])
						])
					])
				]));
			});

			rulesTable = E('table', { 'class': 'table xfree-routing-matrix', 'style': 'width: 100%;' }, [
				E('thead', {}, [
					E('tr', {}, [
						E('th', {}, [_('Устройство')]),
						E('th', {}, [_('IP-адрес / Подсеть')]),
						E('th', {}, [_('MAC-адрес')]),
						E('th', {}, [_('Обход VPN')]),
						E('th', {}, [_('Обход Zapret')]),
						E('th', {}, [_('Режим')]),
						E('th', { 'style': 'text-align: right; min-width: 90px;' }, [_('Действия')])
					])
				]),
				E('tbody', {}, rows)
			]);
		}

		var configuredSection = E('section', { 'class': 'xfree-vpn-section' }, [
			E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;' }, [
				E('h4', { 'style': 'margin: 0;' }, [_('Настроенные исключения клиентов')]),
				E('span', { 'class': 'muted font-xs' }, [
					_('Файл профиля: routing/devices.conf')
				])
			]),
			rulesTable
		]);

		// 4. Section: Network Clients (DHCP / ARP)
		var leaseCards = [];
		leases.forEach(function (c) {
			var isAdded = (c.ip && existingIps[c.ip]) || (c.mac && existingMacs[c.mac.toLowerCase()]);

			leaseCards.push(E('div', {
				'class': 'xfree-vpn-tunnel' + (isAdded ? ' is-ok' : ''),
				'style': 'padding: 8px 10px; min-height: auto;'
			}, [
				E('div', { 'style': 'display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;' }, [
					E('div', {}, [
						E('div', { 'style': 'font-weight: 600;' }, [c.hostname || c.ip]),
						E('div', { 'class': 'font-mono font-xs muted' }, [
							c.ip ? c.ip : '',
							(c.ip && c.mac) ? ' · ' : '',
							c.mac ? c.mac : ''
						])
					]),
					isAdded
						? E('span', { 'class': 'xfree-vpn-badge is-ok', 'style': 'white-space: nowrap;' }, ['✓ ' + _('Исключено')])
						: E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'white-space: nowrap;',
							'title': _('Добавить устройство в прямой WAN'),
							'click': function () {
								self._openEditDialog(null, {
									name: c.hostname || c.ip,
									ip: c.ip,
									mac: c.mac,
									skipVpn: true,
									skipZapret: true,
									comment: _('DHCP клиент') + (c.hostname ? ': ' + c.hostname : '')
								});
							}
						}, ['+ ' + _('В исключения')])
				])
			]));
		});

		var leasesSection = E('section', { 'class': 'xfree-vpn-section', 'style': 'margin-top: 16px;' }, [
			E('div', { 'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;' }, [
				E('h4', { 'style': 'margin: 0;' }, [_('Обнаруженные клиенты локальной сети')]),
				E('span', { 'class': 'muted font-xs' }, [
					_('DHCP leases (/tmp/dhcp.leases) и ARP')
				])
			]),
			leaseCards.length
				? E('div', {
					'style': 'display: grid; grid-template-columns: repeat(auto-fill, minmax(18rem, 1fr)); gap: 8px;'
				}, leaseCards)
				: E('p', { 'class': 'muted' }, [_('Активные клиенты сети не обнаружены.')])
		]);

		this.replaceChildren(head, chips, configuredSection, leasesSection);
	}
});

return baseclass.extend({
	tag: TAG
});

