'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.console-output';

var TAG = 'xfree-vpn-devicepolicy';

function escapeId(name) {
	return String(name || '')
		.toLowerCase()
		.replace(/[^a-z0-9_-]+/g, '_')
		.replace(/^_+|_+$/g, '') || 'dev_' + Date.now().toString(36);
}

wc.define(TAG, class extends wc.LightElement {
	mount(spec) {
		this._spec = spec || {};
		this._view = spec.view || null;
		this._devices = spec.devices || [];
		this._leases = spec.leases || [];
		this._ifaces = spec.ifaces || [];
		this._loading = !!spec.loading;
		this._scanning = false;
		this._scanScope = spec.scanScope || (typeof window !== 'undefined' && window.localStorage && window.localStorage.getItem('xfree_dp_scan_scope')) || 'lan';
		this._msg = spec.message || '';
		this._msgTone = spec.messageTone || '';
		this._searchFilter = '';

		this._matrixState = {};
		this._matrixInitial = {};
		this._initMatrixState();

		if (!this._devices.length && !this._loading) {
			this.reload();
		} else {
			this.requestPaint();
		}
	}

	_initMatrixState() {
		var data = this._buildMatrixData();
		var list = data.list;
		this._matrixState = {};
		this._matrixInitial = {};

		for (var i = 0; i < list.length; i++) {
			var it = list[i];
			var st = {
				target: it.target || 'default',
				zapret: it.zapret || 'auto'
			};
			this._matrixState[it.id] = Object.assign({}, st);
			this._matrixInitial[it.id] = Object.assign({}, st);
		}
	}

	reload() {
		if (this._scanning) return Promise.resolve();
		var self = this;
		this._loading = true;
		this._msg = '';
		this._msgTone = '';
		this.requestPaint();

		var scope = this._scanScope || 'lan';
		var leasesArg = 'passive|' + scope;

		return Promise.all([
			xui.runIfaceMenu('devicePolicyList').catch(function () { return ''; }),
			xui.runIfaceMenu('devicePolicyLeases', leasesArg).catch(function () { return ''; }),
			xui.runIfaceMenu('summary').catch(function () { return ''; })
		]).then(function (results) {
			self._devices = xui.parseDevicePolicyList(results[0]);
			self._leases = xui.parseDevicePolicyLeases(results[1]);
			var sum = xui.parseIfaceSummary(results[2]);
			self._ifaces = (sum && Array.isArray(sum.ifaces)) ? sum.ifaces : [];
			self._initMatrixState();
			self._loading = false;
			self.requestPaint();
		}).catch(function (err) {
			self._loading = false;
			self._msg = (err && err.message) || String(err);
			self._msgTone = 'bad';
			self.requestPaint();
		});
	}

	_triggerScan() {
		var self = this;
		if (this._scanning) return Promise.resolve();

		this._scanning = true;
		var scope = this._scanScope || 'lan';
		this._msg = '';
		this._msgTone = '';
		this.requestPaint();

		var scanArg = 'active|' + scope;

		return xui.runIfaceMenu('devicePolicyLeases', scanArg).then(function (res) {
			self._scanning = false;
			self._leases = xui.parseDevicePolicyLeases(res);
			self._initMatrixState();
			self._msg = '';
			self._msgTone = '';
			self.requestPaint();
		}).catch(function (err) {
			self._scanning = false;
			var errMsg = (err && err.message) || String(err);
			self._setMsg(_('Ошибка сканирования: %s').format(errMsg), 'bad');
			self.requestPaint();
		});
	}

	_setMsg(text, tone) {
		this._msg = text || '';
		this._msgTone = tone || '';
		var msgEl = this.querySelector('[data-xfree-dp-msg]');
		if (msgEl) {
			msgEl.className = 'xfree-vpn-msg' + (tone ? ' is-' + tone : '');
			msgEl.textContent = text || '';
		}
	}

	_buildMatrixData() {
		var devices = this._devices || [];
		var leases = this._leases || [];
		var list = [];
		var map = {};
		var i;
		var d;
		var l;
		var key;

		// 1. Configured entries from devices.conf
		for (i = 0; i < devices.length; i++) {
			d = devices[i];
			key = d.id || escapeId(d.name || d.ip || d.mac);
			var target = 'default';
			if (d.forceIface) {
				target = 'tunnel:' + d.forceIface;
			} else if (d.skipVpn && d.skipZapret) {
				target = 'wan';
			} else if (d.skipVpn) {
				target = 'wan';
			}

			var zapret = 'auto';
			if (d.forceZapret) {
				zapret = 'force';
			} else if (d.skipZapret) {
				zapret = 'bypass';
			}

			var item = {
				id: key,
				name: d.name || d.ip || d.mac || _('Устройство'),
				ip: d.ip || '',
				mac: d.mac || '',
				comment: d.comment || '',
				target: target,
				zapret: zapret,
				isConfigured: true,
				source: 'profile'
			};
			map[key] = item;
			list.push(item);
		}

		// 2. Discovered network clients (DHCP / ARP)
		for (i = 0; i < leases.length; i++) {
			l = leases[i];
			var lip = l.ip || '';
			var lmac = (l.mac || '').toLowerCase();
			var already = false;

			for (var j = 0; j < list.length; j++) {
				if ((lip && list[j].ip === lip) || (lmac && list[j].mac.toLowerCase() === lmac)) {
					already = true;
					if (!list[j].name && l.hostname) {
						list[j].name = l.hostname;
					}
					break;
				}
			}
			if (already) continue;

			key = escapeId(l.hostname || lip || lmac);
			var leaseItem = {
				id: key,
				name: l.hostname || (lip ? _('Клиент %s').format(lip) : lmac),
				ip: lip,
				mac: l.mac || '',
				comment: '',
				target: 'default',
				zapret: 'auto',
				isConfigured: false,
				source: l.hostname ? 'dhcp' : 'arp'
			};
			map[key] = leaseItem;
			list.push(leaseItem);
		}

		return { list: list, map: map };
	}

	_isDirty() {
		if (!this._matrixState || !this._matrixInitial) return false;
		var keys = Object.keys(this._matrixState);
		for (var i = 0; i < keys.length; i++) {
			var k = keys[i];
			var cur = this._matrixState[k];
			var init = this._matrixInitial[k];
			if (!init) {
				if (cur && (cur.target !== 'default' || cur.zapret !== 'auto')) return true;
			} else {
				if (cur.target !== init.target || cur.zapret !== init.zapret) return true;
			}
		}
		return false;
	}

	_getDirtyCount() {
		var cnt = 0;
		if (!this._matrixState || !this._matrixInitial) return 0;
		var keys = Object.keys(this._matrixState);
		for (var i = 0; i < keys.length; i++) {
			var k = keys[i];
			var cur = this._matrixState[k];
			var init = this._matrixInitial[k];
			if (!init) {
				if (cur && (cur.target !== 'default' || cur.zapret !== 'auto')) cnt++;
			} else {
				if (cur.target !== init.target || cur.zapret !== init.zapret) cnt++;
			}
		}
		return cnt;
	}

	_resetMatrix() {
		this._matrixState = JSON.parse(JSON.stringify(this._matrixInitial || {}));
		this.requestPaint();
	}

	_saveMatrix() {
		var self = this;
		var changes = [];
		var data = this._buildMatrixData();
		var list = data.list;

		for (var i = 0; i < list.length; i++) {
			var item = list[i];
			var cur = (self._matrixState && self._matrixState[item.id]) || { target: item.target, zapret: item.zapret };
			var init = (self._matrixInitial && self._matrixInitial[item.id]) || { target: item.target, zapret: item.zapret };

			var isModified = (cur.target !== init.target) || (cur.zapret !== init.zapret);
			if (!isModified) continue;

			// If configured device reset back to default, remove from devices.conf
			if (item.isConfigured && cur.target === 'default' && cur.zapret === 'auto') {
				changes.push([item.id, item.name, item.ip, item.mac, 0, 0, '', '', 0, 'del'].join('|'));
			} else if (cur.target !== 'default' || cur.zapret !== 'auto') {
				var sv = (cur.target === 'wan') ? 1 : 0;
				var sz = (cur.zapret === 'bypass' || cur.target === 'wan') ? 1 : 0;
				var fi = (cur.target.indexOf('tunnel:') === 0) ? cur.target.replace(/^tunnel:/, '') : '';
				var fz = (cur.zapret === 'force') ? 1 : 0;
				changes.push([item.id, item.name, item.ip, item.mac, sv, sz, item.comment || '', fi, fz, 'save'].join('|'));
			}
		}

		if (changes.length === 0) {
			return self._applyRules();
		}

		ui.showModal(_('Применение матрицы маршрутизации'), [
			E('p', { 'class': 'spinning' }, [_('Сохранение конфигурации и применение nftables…')])
		]);

		var bulkArg = changes.join(';');
		return xui.runIfaceMenu('devicePolicySaveBulk', bulkArg).then(function () {
			ui.hideModal();
			self._setMsg(_('Матрица маршрутизации устройств успешно сохранена и применена в nftables.'), 'ok');
			self._matrixState = {};
			self._matrixInitial = {};
			self.reload();
			ui.addNotification(null, E('p', {}, [_('Политики устройств успешно сохранены и применены.')]), 'info');
		}).catch(function (err) {
			ui.hideModal();
			self._setMsg((err && err.message) || String(err), 'bad');
			ui.addNotification(null, E('p', {}, [_('Ошибка сохранения матрицы: %s').format(err && err.message ? err.message : String(err))]), 'error');
		});
	}

	_applyRules() {
		var self = this;

		ui.showModal(_('Применение исключений устройств'), [
			E('p', { 'class': 'spinning' }, [_('Применение правил маршрутизации устройств в nftables…')])
		]);

		return xui.runIfaceMenu('devicePolicyApply').then(function (res) {
			ui.hideModal();
			var out = xui.formatExecReport(res);
			self._setMsg(_('Правила исключений успешно применены в nftables.'), 'ok');
			self.reload();
			if (res && res.code === 0) {
				ui.addNotification(null, E('p', {}, [_('Политики устройств успешно применены.')]), 'info');
			} else {
				ui.addNotification(null, E('p', {}, [_('Результат применения: %s').format(out || 'OK')]), 'info');
			}
		}).catch(function (err) {
			ui.hideModal();
			self._setMsg((err && err.message) || String(err), 'bad');
			ui.addNotification(null, E('p', {}, [_('Ошибка применения: %s').format(err && err.message ? err.message : String(err))]), 'error');
		});
	}

	_openEditDialog(dev, defaultValues) {
		var self = this;
		var isNew = !dev;
		var cur = dev || defaultValues || {};

		var availableIfaces = (self._ifaces && self._ifaces.length) ? self._ifaces : [
			{ id: 'warp', name: 'warp', label: 'warp' },
			{ id: 'proton', name: 'proton', label: 'proton' }
		];

		// Initial routing target
		var initTarget = 'default';
		if (cur.forceIface) {
			initTarget = 'tunnel:' + cur.forceIface;
		} else if (cur.skipVpn) {
			initTarget = 'wan';
		}

		// Initial zapret mode
		var initZapret = 'auto';
		if (cur.forceZapret) {
			initZapret = 'force';
		} else if (cur.skipZapret) {
			initZapret = 'bypass';
		}

		var nameInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': _('Например: Proxmox VM, Smart TV'),
			'value': cur.name || ''
		});

		var ipInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text font-mono',
			'style': 'width: 100%;',
			'placeholder': _('192.168.31.51 или 192.168.31.0/24'),
			'value': cur.ip || ''
		});

		var macInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text font-mono',
			'style': 'width: 100%;',
			'placeholder': _('aa:bb:cc:dd:ee:ff'),
			'value': cur.mac || ''
		});

		var targetOptions = [
			E('option', { 'value': 'default', 'selected': initTarget === 'default' ? '' : null }, [
				_('🌐 По спискам (Direct default — стандартная маршрутизация роутера)')
			]),
			E('option', { 'value': 'wan', 'selected': initTarget === 'wan' ? '' : null }, [
				_('⚡ Прямой WAN (Direct WAN — весь трафик напрямую в обход VPN и Zapret)')
			])
		];

		availableIfaces.forEach(function (ifc) {
			var iname = ifc.name || ifc.id || ifc.label;
			var ilbl = ifc.label || ifc.name || ifc.id;
			var val = 'tunnel:' + iname;
			targetOptions.push(E('option', {
				'value': val,
				'selected': initTarget === val ? '' : null
			}, ['🛡️ ' + _('Весь трафик в туннель %s').format(ilbl) + (ifc.kind ? ' (' + ifc.kind + ')' : '')]));
		});

		var targetSelect = E('select', {
			'class': 'cbi-input-select',
			'style': 'width: 100%;'
		}, targetOptions);

		var zapretSelect = E('select', {
			'class': 'cbi-input-select',
			'style': 'width: 100%;'
		}, [
			E('option', { 'value': 'auto', 'selected': initZapret === 'auto' ? '' : null }, [
				_('🌐 Автоматически (десинхронизация только по спискам Zapret)')
			]),
			E('option', { 'value': 'force', 'selected': initZapret === 'force' ? '' : null }, [
				_('⚡ Принудительно в Zapret (весь веб-трафик устройства в NFQUEUE)')
			]),
			E('option', { 'value': 'bypass', 'selected': initZapret === 'bypass' ? '' : null }, [
				_('🚫 В обход Zapret (пропустить десинхронизацию DPI)')
			])
		]);

		var zapretDesc = E('div', { 'class': 'cbi-value-description' }, [
			_('Управление десинхронизацией DPI для исходящего трафика данного устройства')
		]);

		var zapretRow = E('div', { 'class': 'cbi-value' }, [
			E('label', { 'class': 'cbi-value-title' }, [_('Режим Zapret (DPI) *')]),
			E('div', { 'class': 'cbi-value-field' }, [
				zapretSelect,
				zapretDesc
			])
		]);

		function updateTargetUi() {
			var t = targetSelect.value;
			if (t === 'wan') {
				zapretSelect.value = 'bypass';
				zapretSelect.disabled = true;
				zapretRow.style.opacity = '0.5';
				zapretDesc.textContent = _('При чистом Direct WAN десинхронизация Zapret автоматически отключена');
			} else {
				zapretSelect.disabled = false;
				zapretRow.style.opacity = '1';
				zapretDesc.textContent = _('Управление десинхронизацией DPI для исходящего трафика данного устройства');
			}
		}

		targetSelect.addEventListener('change', updateTargetUi);
		updateTargetUi();

		var commentInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': _('Комментарий или назначение устройства'),
			'value': cur.comment || ''
		});

		var errorBox = E('div', {
			'class': 'xfree-vpn-msg is-bad',
			'style': 'margin-top: 8px; display: none;'
		});

		var modalContent = E('div', { 'class': 'xfree-dialog-body', 'style': 'display: flex; flex-direction: column; gap: 12px;' }, [
			E('p', { 'class': 'muted' }, [
				_('Укажите параметры устройства (IP или MAC) и выберите целевой шлюз (WAN, списки или конкретный VPN-туннель) и режим десинхронизации Zapret.')
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Имя устройства *')]),
				E('div', { 'class': 'cbi-value-field' }, [nameInput])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('IP-адрес или CIDR')]),
				E('div', { 'class': 'cbi-value-field' }, [
					ipInput,
					E('div', { 'class': 'cbi-value-description' }, [_('Одиночный IP (192.168.31.50) или подсеть (192.168.31.0/24)')])
				])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('MAC-адрес')]),
				E('div', { 'class': 'cbi-value-field' }, [
					macInput,
					E('div', { 'class': 'cbi-value-description' }, [_('Аппаратный MAC-адрес сетевой карты (формат: 00:11:22:33:44:55)')])
				])
			]),
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Целевой шлюз / Туннель *')]),
				E('div', { 'class': 'cbi-value-field' }, [
					targetSelect,
					E('div', { 'class': 'cbi-value-description' }, [
						_('Выберите, куда направлять основной трафик: в обход в WAN, по стандартным спискам или в выделенный VPN')
					])
				])
			]),
			zapretRow,
			E('div', { 'class': 'cbi-value' }, [
				E('label', { 'class': 'cbi-value-title' }, [_('Примечание')]),
				E('div', { 'class': 'cbi-value-field' }, [commentInput])
			]),
			errorBox
		]);

		ui.showModal(isNew ? _('Добавить политику устройства') : _('Редактировать политику устройства'), [
			modalContent,
			E('div', { 'class': 'right', 'style': 'margin-top: 16px; display: flex; justify-content: flex-end; gap: 8px;' }, [
				E('button', {
					'class': 'btn',
					'type': 'button',
					'click': function () { ui.hideModal(); }
				}, [_('Отмена')]),
				E('button', {
					'class': 'btn primary-large is-primary',
					'type': 'button',
					'click': function () {
						var name = nameInput.value.trim();
						var ip = ipInput.value.trim();
						var mac = macInput.value.trim();
						var com = commentInput.value.trim();

						if (!name) {
							errorBox.textContent = _('Укажите имя устройства');
							errorBox.style.display = 'block';
							nameInput.focus();
							return;
						}
						if (!ip && !mac) {
							errorBox.textContent = _('Необходимо указать хотя бы IP-адрес или MAC-адрес устройства');
							errorBox.style.display = 'block';
							ipInput.focus();
							return;
						}

						var tgt = targetSelect.value;
						var zap = zapretSelect.value;
						var sv = 0, sz = 0, fi = '', fz = 0;

						if (tgt === 'wan') {
							sv = 1;
							sz = 1;
							fi = '';
							fz = 0;
						} else if (tgt === 'default') {
							sv = 0;
							fi = '';
							sz = (zap === 'bypass') ? 1 : 0;
							fz = (zap === 'force') ? 1 : 0;
						} else if (tgt === 'tunnel' || tgt.indexOf('tunnel:') === 0) {
							sv = 0;
							fi = (tgt === 'tunnel') ? (availableIfaces[0] ? (availableIfaces[0].name || availableIfaces[0].id) : 'warp') : tgt.substring(7);
							sz = (zap === 'bypass') ? 1 : 0;
							fz = (zap === 'force') ? 1 : 0;
						}

						var devId = isNew ? escapeId(name) : (cur.id || escapeId(name));
						var arg = [devId, name, ip, mac, sv, sz, com, fi, fz].join('|');

						errorBox.style.display = 'none';
						ui.showModal(_('Сохранение'), [
							E('p', { 'class': 'spinning' }, [_('Сохранение правила…')])
						]);

						xui.runIfaceMenu('devicePolicySave', arg).then(function () {
							ui.hideModal();
							self._setMsg(_('Правило сохранено. Нажмите «⚡ Применить правила» для активации в nftables.'), 'warn');
							self.reload();
						}).catch(function (err) {
							ui.hideModal();
							ui.addNotification(null, E('p', {}, [_('Ошибка сохранения: %s').format(err && err.message ? err.message : String(err))]), 'error');
						});
					}
				}, [_('Сохранить')])
			])
		]);
	}

	_deleteRule(dev) {
		var self = this;
		if (!dev || !dev.id) return;

		var confirmMsg = _('Удалить политику для «%s» (%s)?').format(dev.name, dev.ip || dev.mac || dev.id);

		if (!confirm(confirmMsg))
			return;

		ui.showModal(_('Удаление'), [
			E('p', { 'class': 'spinning' }, [_('Удаление правила…')])
		]);

		xui.runIfaceMenu('devicePolicyDelete', dev.id).then(function () {
			ui.hideModal();
			self._setMsg(_('Правило удалено. Нажмите «⚡ Применить правила» для обновления nftables.'), 'warn');
			self.reload();
		}).catch(function (err) {
			ui.hideModal();
			ui.addNotification(null, E('p', {}, [_('Ошибка удаления: %s').format(err && err.message ? err.message : String(err))]), 'error');
		});
	}

	render() {
		var self = this;
		var leases = this._leases || [];
		var ifaces = this._ifaces || [];
		var isLoading = this._loading;
		var isScanning = this._scanning;
		var scanScope = this._scanScope || 'lan';

		// 1. Matrix Model
		var matrixData = this._buildMatrixData();
		var allItems = matrixData.list;

		// Summary counters
		var totalRules = 0;
		var directWanCount = 0;
		var forceTunnelCount = 0;
		var forceZapretCount = 0;

		for (var k = 0; k < allItems.length; k++) {
			var itm = allItems[k];
			var st = (self._matrixState && self._matrixState[itm.id]) || { target: itm.target, zapret: itm.zapret };
			if (st.target !== 'default' || st.zapret !== 'auto') {
				totalRules++;
			}
			if (st.target === 'wan') {
				directWanCount++;
			} else if (st.target.indexOf('tunnel:') === 0) {
				forceTunnelCount++;
			}
			if (st.zapret === 'force') {
				forceZapretCount++;
			}
		}

		var isDirty = this._isDirty();
		var dirtyCount = this._getDirtyCount();

		// 2. Header
		var head = E('div', { 'class': 'xfree-vpn-head' }, [
			E('div', { 'class': 'xfree-vpn-head-left' }, [
				E('h3', {}, [_('Матрица маршрутизации устройств (Device Routing Matrix)')]),
				E('p', { 'class': 'muted' }, [
					_('Наглядное переключение маршрута для каждого устройства в один клик: прямой WAN, обычные списки или выделенный VPN-туннель. Для обхода туннелей целыми подсетями используйте вкладку «PBR Bypass».')
				])
			]),
			E('div', { 'class': 'xfree-vpn-head-right' }, [
				E('div', { 'class': 'xfree-vpn-head-actions' }, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'title': _('Перейти к настройке обхода туннелей для целых подсетей и интерфейсов (LAN, Guest, VLAN)'),
						'click': function () {
							if (self._view && typeof self._view.navigate === 'function')
								self._view.navigate('vpn', 'pbrbypass', 'vpn.pbrbypass');
						}
					}, ['🌐 ' + _('PBR Bypass сетей →')]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'disabled': (isLoading || isScanning) ? true : null,
						'click': function () { self.reload(); }
					}, [
						E('span', { 'class': isLoading ? 'is-spinning' : '' }, ['🔄']),
						' ' + (isLoading ? _('Обновление…') : _('Обновить'))
					]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function () { self._openEditDialog(); }
					}, ['+ ' + _('Добавить устройство')]),
					E('button', {
						'class': 'btn ghost-compact xfree-vpn-head-btn is-primary' + (isDirty ? ' is-dirty' : ''),
						'type': 'button',
						'click': function () {
							if (isDirty) self._saveMatrix();
							else self._applyRules();
						}
					}, [isDirty ? ('⚡ ' + _('Сохранить и применить')) : ('⚡ ' + _('Применить правила'))])
				]),
				this._msg ? E('div', {
					'class': 'xfree-vpn-msg' + (this._msgTone ? ' is-' + this._msgTone : ''),
					'data-xfree-dp-msg': '1'
				}, [this._msg]) : ''
			])
		]);

		// 3. Status Chips
		var chips = E('div', { 'class': 'xfree-status-panel xfree-uplink-status' }, [
			E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [_('Правил')]),
				E('span', { 'class': 'v' }, [String(totalRules)])
			]),
			E('div', { 'class': 'xfree-uplink-chip' + (directWanCount > 0 ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [_('Direct WAN')]),
				E('span', { 'class': 'v' }, [String(directWanCount)])
			]),
			E('div', { 'class': 'xfree-uplink-chip' + (forceTunnelCount > 0 ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [_('В туннелях')]),
				E('span', { 'class': 'v' }, [String(forceTunnelCount)])
			]),
			E('div', { 'class': 'xfree-uplink-chip' + (forceZapretCount > 0 ? ' is-ok' : '') }, [
				E('span', { 'class': 'k' }, [_('В Zapret')]),
				E('span', { 'class': 'v' }, [String(forceZapretCount)])
			]),
			E('div', { 'class': 'xfree-uplink-chip' }, [
				E('span', { 'class': 'k' }, [_('Клиентов в сети')]),
				E('span', { 'class': 'v' }, [String(leases.length)])
			]),
			E('div', {
				'class': 'xfree-uplink-chip is-link',
				'style': 'cursor: pointer;',
				'title': _('Перейти к матрице PBR Bypass для целых интерфейсов и подсетей'),
				'click': function () {
					if (self._view && typeof self._view.navigate === 'function')
						self._view.navigate('vpn', 'pbrbypass', 'vpn.pbrbypass');
				}
			}, [
				E('span', { 'class': 'k' }, [_('Сети PBR')]),
				E('span', { 'class': 'v' }, [_('Открыть →')])
			])
		]);

		// 4. Matrix Table Columns
		var headerCols = [
			E('th', { 'class': 'xfree-device-col-device' }, [_('Устройство (Клиент сети)')]),
			E('th', { 'class': 'xfree-device-col-center', 'title': _('Весь трафик клиента напрямую в физический WAN без VPN и Zapret') }, [
				'⚡ ' + _('Прямой WAN')
			]),
			E('th', { 'class': 'xfree-device-col-center', 'title': _('Стандартный маршрут роутера: в туннели идут только ресурсы из списков') }, [
				'🌐 ' + _('По спискам')
			])
		];

		ifaces.forEach(function (t) {
			var tName = t.name || t.id;
			headerCols.push(E('th', { 'class': 'xfree-pbr-col-tunnel xfree-device-col-center', 'title': _('Направить ВЕСЬ трафик клиента принудительно в туннель %s').format(tName) }, [
				E('div', { 'class': 'xfree-pbr-tunnel-th' }, [
					E('span', { 'class': 'xfree-vpn-status-dot is-' + (t.ifaceUp ? 'ok' : 'bad') }),
					E('strong', {}, [tName]),
					t.kind ? E('span', { 'class': 'muted font-mono', 'style': 'font-size: 10px;' }, [' (' + t.kind + ')']) : ''
				])
			]));
		});

		headerCols.push(E('th', { 'class': 'xfree-device-col-zapret xfree-device-col-center', 'title': _('Режим десинхронизации Zapret DPI') }, [_('🛡️ Zapret (DPI)')]));
		headerCols.push(E('th', { 'class': 'xfree-device-col-actions', 'title': _('Действия') }, [_('Действия')]));

		// Filter items by search query if any
		var filterQuery = (this._searchFilter || '').toLowerCase().trim();
		var filteredItems = allItems.filter(function (it) {
			if (!filterQuery) return true;
			return (it.name && it.name.toLowerCase().indexOf(filterQuery) !== -1) ||
				(it.ip && it.ip.indexOf(filterQuery) !== -1) ||
				(it.mac && it.mac.toLowerCase().indexOf(filterQuery) !== -1);
		});

		// 5. Matrix Rows
		var rows = [];
		filteredItems.forEach(function (it) {
			var curSt = (self._matrixState && self._matrixState[it.id]) || { target: it.target, zapret: it.zapret };
			var initSt = (self._matrixInitial && self._matrixInitial[it.id]) || { target: it.target, zapret: it.zapret };
			var isModified = (curSt.target !== initSt.target) || (curSt.zapret !== initSt.zapret);

			var rowCols = [];

			// Device identity
			var subDetail = [];
			if (it.ip) subDetail.push(it.ip);
			if (it.mac) subDetail.push(it.mac);

			rowCols.push(E('td', { 'class': 'xfree-device-cell-device' }, [
				E('div', { 'style': 'display: flex; align-items: center; gap: 6px;' }, [
					E('div', { 'style': 'font-weight: 600;' }, [it.name || it.ip || it.mac]),
					it.isConfigured
						? E('span', { 'class': 'xfree-vpn-badge is-ok font-xs', 'title': _('Правило сохранено в devices.conf') }, ['✓ ' + _('В профиле')])
						: E('span', { 'class': 'xfree-vpn-badge font-xs muted', 'title': _('Обнаружен в локальной сети') }, [it.source === 'dhcp' ? 'DHCP' : 'ARP'])
				]),
				E('div', { 'class': 'font-mono font-xs muted' }, [subDetail.join(' · ') || '—']),
				it.comment ? E('div', { 'class': 'font-xs muted', 'style': 'font-style: italic;' }, [it.comment]) : ''
			]));

			// 1. Direct WAN radio
			var isWan = curSt.target === 'wan';
			var isWanMod = (initSt.target !== 'wan' && isWan) || (initSt.target === 'wan' && !isWan);
			var wanRb = E('input', {
				'type': 'radio',
				'name': 'matrix_target_' + it.id,
				'value': 'wan',
				'checked': isWan ? 'checked' : null,
				'change': function () {
					if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
					self._matrixState[it.id].target = 'wan';
					self._matrixState[it.id].zapret = 'bypass';
					self.requestPaint();
				}
			});
			rowCols.push(E('td', { 'class': 'xfree-device-cell-radio is-wan' + (isWan ? ' is-active' : '') + (isWanMod ? ' is-modified' : '') }, [
				E('label', { 'class': 'xfree-device-radio-wrap', 'title': _('Direct WAN: направить весь трафик мимо VPN и Zapret') }, [
					wanRb,
					E('span', {}, [_('WAN')])
				])
			]));

			// 2. Default (По спискам) radio
			var isDef = curSt.target === 'default';
			var isDefMod = (initSt.target !== 'default' && isDef) || (initSt.target === 'default' && !isDef);
			var defRb = E('input', {
				'type': 'radio',
				'name': 'matrix_target_' + it.id,
				'value': 'default',
				'checked': isDef ? 'checked' : null,
				'change': function () {
					if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
					self._matrixState[it.id].target = 'default';
					self._matrixState[it.id].zapret = 'auto';
					self.requestPaint();
				}
			});
			rowCols.push(E('td', { 'class': 'xfree-device-cell-radio' + (isDef ? ' is-active' : '') + (isDefMod ? ' is-modified' : '') }, [
				E('label', { 'class': 'xfree-device-radio-wrap', 'title': _('По спискам: использовать VPN только для доменов из списков роутера') }, [
					defRb,
					E('span', {}, [_('Списки')])
				])
			]));

			// 3. Tunnels radio columns
			ifaces.forEach(function (t) {
				var tName = t.name || t.id;
				var tVal = 'tunnel:' + tName;
				var isThisT = curSt.target === tVal;
				var isThisTMod = (initSt.target !== tVal && isThisT) || (initSt.target === tVal && !isThisT);

				var tRb = E('input', {
					'type': 'radio',
					'name': 'matrix_target_' + it.id,
					'value': tVal,
					'checked': isThisT ? 'checked' : null,
					'change': function () {
						if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
						self._matrixState[it.id].target = tVal;
						if (self._matrixState[it.id].zapret === 'bypass') {
							self._matrixState[it.id].zapret = 'auto';
						}
						self.requestPaint();
					}
				});

				rowCols.push(E('td', { 'class': 'xfree-device-cell-radio' + (isThisT ? ' is-active' : '') + (isThisTMod ? ' is-modified' : '') }, [
					E('label', { 'class': 'xfree-device-radio-wrap', 'title': _('Принудительно направлять весь трафик в туннель %s').format(tName) }, [
						tRb,
						E('span', {}, [tName])
					])
				]));
			});

			// 4. Zapret selector
			var isZapMod = curSt.zapret !== initSt.zapret;
			var zapSelect = E('select', {
				'class': 'cbi-input-select font-xs' + (isZapMod ? ' is-modified' : ''),
				'style': 'width: 100%; max-width: 135px; height: 26px; padding: 2px 4px; font-size: 11px;',
				'title': _('Политика десинхронизации Zapret'),
				'change': function (ev) {
					if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
					self._matrixState[it.id].zapret = ev.target.value;
					self.requestPaint();
				}
			}, [
				E('option', { 'value': 'auto', 'selected': curSt.zapret === 'auto' ? '' : null }, [_('Авто (списки)')]),
				E('option', { 'value': 'force', 'selected': curSt.zapret === 'force' ? '' : null }, [_('NFQUEUE (Все)')]),
				E('option', { 'value': 'bypass', 'selected': curSt.zapret === 'bypass' ? '' : null }, [_('Обход (Выкл)')])
			]);

			rowCols.push(E('td', { 'class': 'xfree-device-cell-zapret xfree-device-col-center' }, [zapSelect]));

			// 5. Actions column
			var editBtn = E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'title': _('Детальная настройка устройства'),
				'click': function () {
					self._openEditDialog(it.isConfigured ? it : null, {
						name: it.name,
						ip: it.ip,
						mac: it.mac,
						comment: it.comment,
						forceIface: (curSt.target.indexOf('tunnel:') === 0) ? curSt.target.replace(/^tunnel:/, '') : '',
						forceZapret: curSt.zapret === 'force',
						skipVpn: curSt.target === 'wan',
						skipZapret: curSt.zapret === 'bypass' || curSt.target === 'wan'
					});
				}
			}, ['✏️']);

			var resetBtn = E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'style': 'color: var(--bad);',
				'title': it.isConfigured ? _('Удалить правило из профиля') : _('Сбросить в настройки по умолчанию'),
				'click': function () {
					if (it.isConfigured) {
						self._deleteRule(it);
					} else {
						if (!self._matrixState[it.id]) self._matrixState[it.id] = {};
						self._matrixState[it.id].target = 'default';
						self._matrixState[it.id].zapret = 'auto';
						self.requestPaint();
					}
				}
			}, ['🗑️']);

			rowCols.push(E('td', { 'class': 'xfree-device-cell-actions' }, [
				editBtn, ' ', resetBtn
			]));

			rows.push(E('tr', { 'class': 'xfree-device-row' + (isModified ? ' is-dirty-row' : '') }, rowCols));
		});

		// 6. Matrix Table
		var matrixTable = E('table', { 'class': 'table xfree-device-matrix' }, [
			E('thead', {}, [
				E('tr', {}, headerCols)
			]),
			E('tbody', {}, rows.length ? rows : [
				E('tr', {}, [
					E('td', { 'colspan': headerCols.length, 'class': 'muted', 'style': 'text-align: center; padding: 20px;' }, [
						_('Устройства не найдены. Нажмите «Сканировать сеть» или добавьте устройство вручную.')
					])
				])
			])
		]);

		var matrixScroll = E('div', { 'class': 'xfree-device-matrix-scroll' }, [ matrixTable ]);

		// 7. Matrix Controls Bar (Search + Scope + Scan)
		var searchInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text font-xs',
			'style': 'height: 30px; min-width: 180px; padding: 2px 8px;',
			'placeholder': _('🔍 Поиск по имени или IP…'),
			'value': this._searchFilter || '',
			'input': function (ev) {
				self._searchFilter = ev.target.value;
				self.requestPaint();
			}
		});

		var scopeSelect = E('select', {
			'class': 'cbi-input-select font-xs',
			'style': 'height: 30px; padding: 2px 8px;',
			'disabled': (isLoading || isScanning) ? true : null,
			'title': _('Область сканирования и отображения клиентов')
		}, [
			E('option', { 'value': 'lan', 'selected': scanScope === 'lan' ? '' : null }, [_('Только LAN-клиенты')]),
			E('option', { 'value': 'all', 'selected': scanScope === 'all' ? '' : null }, [_('Вся сеть (включая WAN)')])
		]);
		scopeSelect.addEventListener('change', function () {
			self._scanScope = scopeSelect.value;
			if (typeof window !== 'undefined' && window.localStorage) {
				window.localStorage.setItem('xfree_dp_scan_scope', self._scanScope);
			}
			self.reload();
		});

		var scanBtn = E('button', {
			'class': 'btn ghost-compact',
			'type': 'button',
			'style': 'height: 30px; display: inline-flex; align-items: center; gap: 6px;',
			'disabled': (isLoading || isScanning) ? true : null,
			'title': _('Запустить активное сканирование (ping sweep + обратный DNS)'),
			'click': function () { self._triggerScan(); }
		}, [
			E('span', { 'class': isScanning ? 'is-spinning' : '' }, [isScanning ? '⏳' : '🔍']),
			' ' + (isScanning ? _('Сканирование…') : _('Сканировать сеть'))
		]);

		var matrixFilterBar = E('div', {
			'style': 'display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 10px;'
		}, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
				searchInput,
				scopeSelect,
				scanBtn
			]),
			E('div', { 'class': 'muted font-xs' }, [
				_('Отображается устройств: %d из %d').format(filteredItems.length, allItems.length)
			])
		]);

		// 8. Toolbar
		var statusBadge = isDirty
			? E('span', { 'class': 'xfree-pbr-dirty-hint' }, ['● ' + _('Есть несохранённые изменения: %d').format(dirtyCount)])
			: E('span', { 'class': 'xfree-vpn-badge is-ok font-xs' }, ['✓ ' + _('Настройки сохранены')]);

		var revertBtn = isDirty ? E('button', {
			'class': 'ghost ghost-compact',
			'type': 'button',
			'style': 'color: var(--muted);',
			'title': _('Отменить несохранённые изменения матрицы'),
			'click': function () { self._resetMatrix(); }
		}, ['🔄 ' + _('Отменить')]) : null;

		var mainActionBtn = E('button', {
			'class': isDirty ? 'btn ghost-compact xfree-pbr-action-btn is-dirty' : 'ghost ghost-compact xfree-pbr-action-btn',
			'type': 'button',
			'title': isDirty
				? _('Сохранить изменения матрицы и переприменить правила nftables')
				: _('Переприменить текущие правила маршрутизации в nftables'),
			'click': function () {
				if (isDirty) self._saveMatrix();
				else self._applyRules();
			}
		}, [
			isDirty ? ('⚡ ' + _('Сохранить и применить')) : ('⚡ ' + _('Применить правила'))
		]);

		var toolbar = E('div', { 'class': 'xfree-pbr-matrix-toolbar' }, [
			E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
				statusBadge
			]),
			E('div', { 'class': 'xfree-pbr-main-ops' }, [
				revertBtn ? revertBtn : '',
				mainActionBtn
			])
		]);

		this.replaceChildren(
			head,
			chips,
			E('section', { 'class': 'xfree-vpn-section' }, [
				matrixFilterBar,
				matrixScroll,
				toolbar
			])
		);
	}
});

return baseclass.extend({
	tag: TAG
});
