'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.console-output';
'require xfree-toolbox.devicepolicy-model as deviceModel';
'require xfree-toolbox.devicepolicy-dialog as deviceDialog';
'require xfree-toolbox.devicepolicy-matrix as deviceMatrix';
'require xfree-toolbox.devicepolicy-view as deviceView';

/* Экран исключений устройств. Состояние, диалог и матрица живут
 * в соседних модулях и вешаются на один прототип xfree-vpn-devicepolicy. */

var TAG = 'xfree-vpn-devicepolicy';

var DevicePanel = class extends wc.LightElement {
};

function mixDevice(part) {
	prototypeMix.mixInto(DevicePanel.prototype, part);
}

mixDevice(deviceModel);
mixDevice(deviceDialog);
mixDevice(deviceMatrix);
mixDevice(deviceView);

wc.define(TAG, DevicePanel);

return baseclass.extend({
	tag: TAG
});
