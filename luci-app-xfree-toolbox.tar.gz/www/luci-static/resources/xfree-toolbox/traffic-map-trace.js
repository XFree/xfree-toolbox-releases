'use strict';
'require baseclass';

return baseclass.extend({
	mount: function(spec) {
		this._spec = spec || {};
		this._devices = (spec && spec.devices) || [];
		this._selectedClient = this._selectedClient || '';
		this._fqdn = this._fqdn || '';
		this._busy = false;
		this._trace = (spec && spec.trace !== undefined) ? spec.trace : (this._trace || null);
		this._expanded = this._expanded || {};
		this._popover = null;
		this._suggestItems = this._suggestItems || [];
		this._suggestLoaded = !!this._suggestLoaded;
		this._suggestLoading = false;
		this._suggestOpen = !!this._suggestOpen;
		this._suggestActive = this._suggestActive == null ? -1 : this._suggestActive;
		this.requestPaint();
	},

	setSummary: function(summary) {
		if (!this._spec) this._spec = {};
		this._spec.summary = summary || null;
		this.requestPaint();
	},

	setTrace: function(trace) {
		this._trace = trace || null;
		this._expanded = {};
		this._popover = null;
		this.requestPaint();
	},

	_layer: function(id) {
		var layers = (this._trace && this._trace.layers) || [];
		var i;
		for (i = 0; i < layers.length; i++) {
			if (layers[i] && layers[i].id === id)
				return layers[i];
		}
		return null;
	},

	_hl: function() {
		var out = {};
		var list = (this._trace && this._trace.summary && this._trace.summary.highlight) || [];
		var i;
		for (i = 0; i < list.length; i++) {
			if (list[i]) out[list[i]] = true;
		}
		return out;
	},

	_nav: function(kind, scopeId) {
		var onNavigate = this._spec && this._spec.onNavigate;
		var scope = scopeId || '';
		/* Close before leaving overview — float popover lives on #xfree-toolbox-shell. */
		this._closeFloatPopover(false);
		if (!onNavigate) return;
		if (kind === 'iface' || kind === 'vpn') onNavigate('routing', 'vpn', scope);
		else if (kind === 'dns') onNavigate('routing', 'dns', scope);
		else if (kind === 'zapret') onNavigate('routing', 'zapret', scope);
		else if (kind === 'lan' || kind === 'client') onNavigate('vpn', 'devicepolicy', 'vpn.devicepolicy');
		else onNavigate('system');
	},

	_toggleExpand: function(key) {
		this._expanded[key] = !this._expanded[key];
		this._closeFloatPopover(false);
		this.requestPaint();
	},

	_runTrace: function() {
		var self = this;
		var onTrace = this._spec && this._spec.onTrace;
		var input = this.querySelector('.tm-trace-input');
		var clientSelect = this.querySelector('.tm-client-select');
		var fqdn = (((input && input.value) || this._fqdn || '') + '').trim();
		var client = clientSelect ? clientSelect.value : (this._selectedClient || '');

		this._fqdn = fqdn;
		this._selectedClient = client;

		if (!fqdn && client) {
			fqdn = client;
			this._fqdn = fqdn;
			if (input) input.value = fqdn;
		}

		if (!onTrace || !fqdn || this._busy)
			return;

		this._busy = true;
		this._popover = null;
		this.requestPaint();

		Promise.resolve(onTrace(fqdn, client)).then(function(res) {
			self._busy = false;
			self._trace = res || null;
			self._expanded = {};
			self.requestPaint();
		}).catch(function(err) {
			self._busy = false;
			self._trace = {
				code: 1,
				stderr: (err && err.message) ? err.message : String(err)
			};
			self.requestPaint();
		});
	}
});
