'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-upstreams';

function moduleIcon(mod) {
	var name = String((mod && (mod.id || mod.name)) || '').toLowerCase();
	var title = String((mod && mod.title) || '').toLowerCase();
	if (name === 'user' || name === 'xfree' || title === 'xfree') return '🧰';
	if (mod && mod.custom) return '👤';
	if (name.indexOf('allow') >= 0 || name.indexOf('domain') >= 0) return '🌐';
	if (name.indexOf('rekryt') >= 0 || name.indexOf('iplist') >= 0) return '📑';
	if (name.indexOf('vpn') >= 0 || name.indexOf('proton') >= 0) return '🛡️';
	return '📦';
}

function slugify(text) {
	var ruMap = {
		'а':'a', 'б':'b', 'в':'v', 'г':'g', 'д':'d', 'е':'e', 'ё':'yo', 'ж':'zh',
		'з':'z', 'и':'i', 'й':'y', 'к':'k', 'л':'l', 'м':'m', 'н':'n', 'о':'o',
		'п':'p', 'р':'r', 'с':'s', 'т':'t', 'у':'u', 'ф':'f', 'х':'h', 'ц':'ts',
		'ч':'ch', 'ш':'sh', 'щ':'sch', 'ъ':'', 'ы':'y', 'ь':'', 'э':'e', 'ю':'yu',
		'я':'ya'
	};
	var s = String(text || '').trim().toLowerCase();
	var out = '';
	for (var i = 0; i < s.length; i++) {
		var c = s.charAt(i);
		if (ruMap[c] !== undefined) {
			out += ruMap[c];
		} else if (/[a-z0-9]/.test(c)) {
			out += c;
		} else if (c === '-' || c === '_' || c === '.') {
			out += c;
		} else if (/\s/.test(c)) {
			out += '-';
		}
	}
	return out.replace(/-+/g, '-').replace(/^[._-]+|[._-]+$/g, '');
}

wc.define(TAG, class extends wc.LightElement {
	getXui() {
		return (this._spec && this._spec.xui) ||
			(this._spec && this._spec.view && this._spec.view.xui) ||
			window.xfreeLuciUi;
	}

	mount(spec) {
		this._spec = spec || {};
		this._modules = [];
		this._loading = true;
		this._error = '';
		this.requestPaint();
		this.loadCatalog();
	}

	loadCatalog() {
		var self = this;
		var xui = self.getXui();
		self._loading = true;
		self._error = '';
		self.requestPaint();

		if (!xui || !xui.runSystemMenu) {
			self._loading = false;
			self._error = _('Не удалось подключить интерфейс управления xfree');
			self.requestPaint();
			return;
		}

		xui.runSystemMenu('upstreamsCatalog').then(function(res) {
			self._loading = false;
			self._modules = (res && res.modules) || [];
			self.requestPaint();
		}).catch(function(err) {
			self._loading = false;
			self._error = (err && err.message) ? err.message : String(err);
			self.requestPaint();
		});
	}

	reload() {
		this.loadCatalog();
	}

	_runBgAction(title, taskName, onFinish) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var dlg = xui.openExecOutputDialog(title);
		dlg.setStatus(_('Запуск задачи…'));
		dlg.setText(_('Инициализация…'));

		xui.runSystemMenu('upstreamsStartBg', taskName).then(function(res) {
			if (res && res.error) {
				dlg.setText(res.error);
				dlg.setDone(false);
				return;
			}

			dlg.setStatus(_('Выполняется в фоне…'));
			if (res && res.stdout)
				dlg.setText(res.stdout);

			var pollTimer = setInterval(function() {
				xui.runSystemMenu('upstreamsBgStatus').then(function(st) {
					if (!st) return;
					if (st.stdout)
						dlg.setText(st.stdout);

					if (st.running === 0) {
						clearInterval(pollTimer);
						pollTimer = null;
						var ok = (st.exitCode === '0' || st.exitCode === 0);
						dlg.setDone(ok);
						self.reload();
						if (typeof onFinish === 'function')
							onFinish(ok);
					}
				}).catch(function(err) {
					clearInterval(pollTimer);
					pollTimer = null;
					dlg.appendText('\n' + _('Ошибка опроса статуса: %s').format(err.message || String(err)));
					dlg.setDone(false);
				});
			}, 1000);
		}).catch(function(err) {
			dlg.setText(err && err.message ? err.message : String(err));
			dlg.setDone(false);
		});
	}

	_showCreateModal() {
		var self = this;
		var titleInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'placeholder': _('Мой список доменов'),
			'style': 'width: 100%; margin-bottom: 4px;'
		});

		var slugEl = E('code', {
			'style': 'color: var(--accent); font-weight: 600;'
		}, [ '—' ]);

		var idHint = E('div', {
			'style': 'font-size: 12px; color: var(--muted); margin-bottom: 12px; display: flex; align-items: center; gap: 6px;'
		}, [
			_('Идентификатор источника (id):'),
			slugEl
		]);

		function updateSlug() {
			var raw = String(titleInput.value || '').trim();
			var s = slugify(raw);
			slugEl.textContent = s || '—';
		}

		titleInput.addEventListener('input', updateSlug);

		var descArea = E('textarea', {
			'class': 'cbi-input-textarea',
			'rows': 3,
			'placeholder': _('Пользовательские домены, сервисы и подсети…'),
			'style': 'width: 100%; margin-bottom: 12px;'
		});

		var body = E('div', { 'class': 'xfree-custom-upstream-form' }, [
			E('label', { 'class': 'cbi-input-title' }, [ _('Название источника:') ]),
			titleInput,
			idHint,
			E('label', { 'class': 'cbi-input-title' }, [ _('Описание источника:') ]),
			descArea,
			E('p', { 'class': 'muted', 'style': 'margin-top: 8px; font-size: 12px;' }, [
				'🔒 ' + _('Этот источник создаётся локально на роутере в upstreams/<id>/ и никогда не перезаписывается при обновлении внешних репозиториев. После создания вы сможете добавить в него любые списки (домены, CIDR-префиксы IPv4/IPv6) с разделением по сервисам и категориям.')
			])
		]);

		var xui = self.getXui();
		if (!xui) return;
		xui.openDialog({
			title: '➕ ' + _('Создать пользовательский Upstream'),
			size: 'md',
			body: body,
			actions: [
				{
					label: _('Отмена'),
					variant: 'default',
					close: true
				},
				{
					label: _('Создать'),
					variant: 'primary',
					click: function() {
						var title = String(titleInput.value || '').trim();
						if (!title) {
							ui.addNotification(null, E('p', {}, [ _('Укажите название источника') ]), 'danger');
							titleInput.focus();
							return;
						}

						var name = slugify(title);
						if (!name) {
							ui.addNotification(null, E('p', {}, [ _('Не удалось сформировать идентификатор из названия') ]), 'danger');
							titleInput.focus();
							return;
						}

						var exists = (self._modules || []).some(function(m) {
							return (m && (m.id === name || m.name === name));
						});
						if (exists) {
							ui.addNotification(null, E('p', {}, [ _('Источник с идентификатором «%s» уже существует').format(name) ]), 'danger');
							return;
						}

						var payload = JSON.stringify({
							name: name,
							title: title,
							desc: String(descArea.value || '').trim()
						});

						ui.hideModal();
						xui.runSystemMenu('upstreamsCreateCustom', name, payload).then(function(res) {
							if (res && res.error) {
								ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
								return;
							}
							ui.addNotification(null, E('p', {}, [ _('Источник %s успешно создан!').format(name) ]), 'info');
							self.reload();
						}).catch(function(err) {
							ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
						});
					}
				}
			]
		});
	}

	_showListsModal(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;
		var isCustom = (mod.custom === 1);

		var modalContainer = E('div', { 'class': 'xfree-lists-modal-container', 'style': 'min-height: 400px;' });

		// Open dialog once: stays open during navigation between lists, editor, and create form!
		xui.openDialog({
			title: '📑 ' + _('Списки источника: %s').format(mod.title || mod.name),
			size: 'wide',
			body: modalContainer,
			actions: [{
				label: _('Закрыть'),
				variant: 'default',
				close: true
			}]
		});

		modalContainer.appendChild(E('div', { 'style': 'text-align: center; padding: 48px;' }, [
			E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка файлов…') ])
		]));

		function loadAndRenderLists(forceRefresh) {
			if (mod._cachedLists && !forceRefresh) {
				renderListsView(mod._cachedLists, mod._cachedMatrix || null);
				return;
			}
			Promise.all([
				xui.runSystemMenu('upstreamsGetLists', modKey),
				(xui.loadRoutingMatrix ? xui.loadRoutingMatrix() : Promise.resolve(null)).catch(function(e) {
					console.warn('Matrix load failed', e);
					return null;
				})
			]).then(function(resArr) {
				var res = resArr[0];
				var matrix = resArr[1];
				var lists = (res && res.lists) || [];
				mod._cachedLists = lists;
				mod._cachedMatrix = matrix;
				renderListsView(lists, matrix);
			}).catch(function(err) {
				modalContainer.replaceChildren(E('div', { 'class': 'alert-message danger' }, [
					E('p', {}, [ (err && err.message) ? err.message : String(err) ])
				]));
			});
		}

		function showTargetsView(relPath, targets) {
			var items = targets.map(function(t) {
				var icon = (t.target === 'iface') ? '🛡️' : ((t.target === 'dns') ? '🌐' : '⚡');
				var kindLabel = (t.target === 'iface') ? _('VPN-туннель (маршрутизация трафика)') :
					((t.target === 'dns') ? _('DNS-профиль (перенаправление доменов)') : _('Zapret DPI (секция стратегии обхода)'));

				return E('div', {
					'style': 'display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px; margin-bottom: 8px;'
				}, [
					E('div', {}, [
						E('div', { 'style': 'font-weight: 600; font-size: 15px;' }, [ icon + ' ' + (t.label || t.scope) ]),
						E('div', { 'class': 'muted', 'style': 'font-size: 12px; margin-top: 3px;' }, [ kindLabel ])
					]),
					E('span', {
						'class': 'badge',
						'style': 'background: var(--ok-soft); color: var(--ok); font-size: 12px; padding: 4px 8px;'
					}, [ '✓ ' + _('Активно') ])
				]);
			});

			var viewEl = E('div', { 'class': 'xfree-targets-view' }, [
				E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; padding-bottom: 12px; border-bottom: 1px solid var(--line);'
				}, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function() {
							renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
						}
					}, [ '← ' + _('Назад к спискам') ]),
					E('span', { 'class': 'badge', 'style': 'background: var(--ok-soft); color: var(--ok); font-weight: 600;' }, [
						_('Используется в %d правилах').format(targets.length)
					])
				]),
				E('div', { 'style': 'margin-bottom: 8px; font-size: 14px; font-family: monospace; word-break: break-all; color: var(--accent); font-weight: 600;' }, [
					'📄 ' + modKey + '/upstream/' + relPath
				]),
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 14px; font-size: 13px;' }, [
					_('Этот список включён в следующих правилах маршрутизации и профилях:')
				]),
				E('div', { 'style': 'max-height: 48vh; overflow-y: auto;' }, items)
			]);

			modalContainer.replaceChildren(viewEl);
		}

		function analyzeModuleLists(rawLists) {
			var groupMap = {};
			var allItems = [];

			(rawLists || []).forEach(function(item) {
				if (!item || !item.path) return;
				var parts = item.path.split('/');
				var group = parts[0] || '';
				var service = parts.length > 2 ? parts[1] : '';
				var filename = parts[parts.length - 1] || '';

				var parsedType = 'other';
				var stem = filename.replace(/\.lst$/i, '');

				var m = filename.match(/^(fqdn|prefixes-ipv4|prefixes-ipv6|prefixes)-(.+)\.lst$/i);
				if (m) {
					var pfx = m[1].toLowerCase();
					stem = m[2];
					if (pfx === 'fqdn') parsedType = 'fqdn';
					else if (pfx === 'prefixes-ipv4') parsedType = 'ipv4';
					else if (pfx === 'prefixes-ipv6') parsedType = 'ipv6';
					else if (pfx === 'prefixes') parsedType = 'prefix';
				}

				var fileInfo = {
					path: item.path,
					group: group,
					service: service,
					filename: filename,
					type: parsedType,
					stem: stem,
					lines: item.lines || 0
				};
				allItems.push(fileInfo);

				if (!groupMap[group]) {
					groupMap[group] = { name: group, files: [], services: {} };
				}
				groupMap[group].files.push(fileInfo);

				if (service) {
					if (!groupMap[group].services[service]) {
						groupMap[group].services[service] = { name: service, files: [] };
					}
					groupMap[group].services[service].files.push(fileInfo);
				}
			});

			return {
				groups: groupMap,
				allItems: allItems
			};
		}

		function createCombobox(config) {
			var placeholder = config.placeholder || '';
			var currentValue = String(config.value !== undefined ? config.value : '');
			var optionsList = config.options || [];
			var onChange = config.onChange || function() {};
			var onSelect = config.onSelect || function() {};

			var wrap = E('div', {
				'class': 'xfree-combobox-wrap',
				'style': 'position: relative; width: 100%; margin-bottom: 4px;' + (config.style || '')
			});

			var input = E('input', {
				'type': 'text',
				'class': 'cbi-input-text',
				'placeholder': placeholder,
				'autocomplete': 'off',
				'style': 'width: 100%; padding-right: 36px; box-sizing: border-box;'
			});
			input.value = currentValue;

			var toggleBtn = E('button', {
				'type': 'button',
				'class': 'btn ghost-compact',
				'style': 'position: absolute; right: 2px; top: 2px; bottom: 2px; width: 32px; border: none; background: transparent; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 11px; color: var(--muted); padding: 0;'
			}, [ '▼' ]);

			var menu = E('div', {
				'class': 'xfree-combobox-menu',
				'style': 'position: absolute; top: calc(100% + 4px); left: 0; right: 0; z-index: 1050; background: var(--panel-2, #ffffff); border: 1px solid var(--line, #e4d8c4); border-radius: 8px; box-shadow: 0 8px 24px rgba(43, 40, 35, 0.15); max-height: 220px; overflow-y: auto; display: none; padding: 4px 0;'
			});

			wrap.appendChild(input);
			wrap.appendChild(toggleBtn);
			wrap.appendChild(menu);

			var isOpen = false;

			function renderMenu(filterText) {
				menu.textContent = '';
				var q = String(filterText || '').trim().toLowerCase();
				var visibleCount = 0;

				optionsList.forEach(function(opt) {
					if (typeof opt === 'string') {
						opt = { value: opt, label: opt };
					}
					if (opt.isHeader) {
						var headerEl = E('div', {
							'style': 'padding: 6px 12px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); background: var(--panel); border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); pointer-events: none; margin-top: 4px;'
						}, [ opt.label || opt.value ]);
						menu.appendChild(headerEl);
						return;
					}

					var valStr = String(opt.value !== undefined ? opt.value : '');
					var lblStr = String(opt.label !== undefined ? opt.label : valStr);
					var hintStr = String(opt.hint || '');

					if (q) {
						var hit = valStr.toLowerCase().indexOf(q) !== -1 ||
								lblStr.toLowerCase().indexOf(q) !== -1 ||
								hintStr.toLowerCase().indexOf(q) !== -1;
						if (!hit) return;
					}

					visibleCount++;

					var isSelected = (valStr === input.value);
					var itemEl = E('div', {
						'class': 'xfree-combobox-item' + (isSelected ? ' selected' : ''),
						'style': 'padding: 7px 12px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 13px; transition: background 0.15s;' +
								(isSelected ? ' background: var(--accent-soft); color: var(--accent); font-weight: 600;' : '')
					}, [
						E('div', { 'style': 'display: flex; align-items: center; gap: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;' }, [
							opt.icon ? E('span', {}, [ opt.icon ]) : '',
							E('span', { 'style': 'overflow: hidden; text-overflow: ellipsis;' }, [ lblStr ])
						]),
						hintStr ? E('span', {
							'class': 'badge',
							'style': 'font-size: 11px; font-weight: normal; padding: 1px 6px; opacity: 0.85; flex-shrink: 0;'
						}, [ hintStr ]) : ''
					]);

					itemEl.addEventListener('mouseenter', function() {
						if (valStr !== input.value) itemEl.style.background = 'var(--panel)';
					});
					itemEl.addEventListener('mouseleave', function() {
						if (valStr !== input.value) itemEl.style.background = '';
					});

					itemEl.addEventListener('mousedown', function(ev) {
						ev.preventDefault();
						selectItem(opt);
					});

					menu.appendChild(itemEl);
				});

				if (visibleCount === 0) {
					menu.appendChild(E('div', {
						'style': 'padding: 10px 12px; font-size: 12px; color: var(--muted); font-style: italic;'
					}, [
						q ? _('Совпадений нет. Будет использовано введенное: «%s»').format(q) : _('Список вариантов пуст')
					]));
				}
			}

			function openMenu(filterText) {
				if (isOpen && filterText === undefined) return;
				isOpen = true;
				renderMenu(filterText !== undefined ? filterText : input.value);
				menu.style.display = 'block';
				document.addEventListener('click', onDocClick, true);
			}

			function closeMenu() {
				if (!isOpen) return;
				isOpen = false;
				menu.style.display = 'none';
				document.removeEventListener('click', onDocClick, true);
			}

			function onDocClick(ev) {
				if (!wrap.contains(ev.target)) {
					closeMenu();
				}
			}

			function selectItem(opt) {
				input.value = opt.value;
				closeMenu();
				onChange(input.value);
				onSelect(opt);
			}

			toggleBtn.addEventListener('click', function(ev) {
				ev.stopPropagation();
				if (isOpen) {
					closeMenu();
				} else {
					renderMenu('');
					isOpen = true;
					menu.style.display = 'block';
					document.addEventListener('click', onDocClick, true);
					input.focus();
				}
			});

			input.addEventListener('focus', function() {
				openMenu(input.value);
			});

			input.addEventListener('input', function() {
				openMenu(input.value);
				onChange(input.value);
			});

			input.addEventListener('keydown', function(ev) {
				if (ev.key === 'Escape') {
					closeMenu();
				} else if (ev.key === 'ArrowDown') {
					if (!isOpen) {
						openMenu('');
					}
				}
			});

			return {
				node: wrap,
				input: input,
				getValue: function() {
					return String(input.value || '').trim();
				},
				setValue: function(val, triggerChange) {
					input.value = val !== undefined ? String(val) : '';
					if (triggerChange) onChange(input.value);
				},
				setOptions: function(newOptions) {
					optionsList = newOptions || [];
					if (isOpen) renderMenu(input.value);
				},
				focus: function() {
					input.focus();
				}
			};
		}

		function renderListsView(lists, matrix) {
			function getListTargets(relPath) {
				if (!matrix || !matrix.columns || !matrix.checked) return [];
				var parts = String(relPath || '').split('/');
				var group = parts[0] || '';
				var service = parts.length > 2 ? parts[1] : '';

				var grpTag = 'grp__' + modKey + '__' + group;
				var svcTag = service ? ('svc__' + modKey + '__' + group + '__' + service) : '';

				var activeTargets = [];
				matrix.columns.forEach(function(col) {
					var chk = matrix.checked[col.key];
					if (!Array.isArray(chk)) return;
					var isHit = chk.indexOf(grpTag) !== -1 || (svcTag && chk.indexOf(svcTag) !== -1);
					if (isHit) {
						var icon = (col.target === 'iface') ? '🛡️' : ((col.target === 'dns') ? '🌐' : '⚡');
						var typeName = (col.target === 'iface') ? _('VPN') : ((col.target === 'dns') ? _('DNS') : _('Zapret'));
						activeTargets.push({
							key: col.key,
							target: col.target,
							scope: col.scope || col.label,
							label: col.label || col.scope,
							displayName: icon + ' ' + typeName + ': ' + (col.label || col.scope)
						});
					}
				});
				return activeTargets;
			}

			lists.forEach(function(l) {
				l._targets = getListTargets(l.path);
			});

			var totalUsedCount = lists.filter(function(l) { return l._targets && l._targets.length > 0; }).length;

			var filterInput = E('input', {
				'type': 'text',
				'class': 'cbi-input-text',
				'placeholder': '🔍 ' + _('Фильтр по названию файла (.lst) или цели…'),
				'style': 'flex: 1; min-width: 200px; max-width: 320px; font-size: 13px; height: 32px; padding: 2px 10px; border-radius: 6px;'
			});

			var filterOnlyUsed = false;
			var onlyUsedBtn = E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'style': 'font-size: 12px; padding: 0 10px; height: 32px;' + (totalUsedCount > 0 ? '' : 'display: none;'),
				'title': _('Показать только списки, которые сейчас выбраны в правилах маршрутизации'),
				'click': function() {
					filterOnlyUsed = !filterOnlyUsed;
					onlyUsedBtn.style.background = filterOnlyUsed ? 'var(--accent-soft)' : '';
					onlyUsedBtn.style.color = filterOnlyUsed ? 'var(--accent)' : '';
					onlyUsedBtn.style.borderColor = filterOnlyUsed ? 'var(--accent)' : '';
					updateRows(filterInput.value);
				}
			}, [ '🎯 ' + _('Только используемые (%d)').format(totalUsedCount) ]);

			var tableBody = E('tbody');

			function updateRows(filterText) {
				var q = String(filterText || '').trim().toLowerCase();
				var filtered = lists.filter(function(l) {
					if (filterOnlyUsed && (!l._targets || !l._targets.length))
						return false;
					if (!q) return true;
					if (l.path.toLowerCase().indexOf(q) !== -1)
						return true;
					if (l._targets && l._targets.some(function(t) { return t.displayName.toLowerCase().indexOf(q) !== -1; }))
						return true;
					return false;
				});

				var rows = [];
				if (!filtered.length) {
					rows.push(E('tr', {}, [
						E('td', { 'colspan': 4, 'class': 'muted', 'style': 'text-align: center; padding: 28px;' }, [
							q ? _('Списки, соответствующие фильтру, не найдены.') : _('В этом источнике пока нет файлов списков.')
						])
					]));
				} else {
					filtered.forEach(function(l) {
						var actions = [];

						// 1. View or Edit (clean icon button with tooltip)
						if (!isCustom) {
							actions.push(E('button', {
								'class': 'btn ghost ghost-compact',
								'type': 'button',
								'style': 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px;',
								'title': _('Просмотреть список'),
								'aria-label': _('Просмотреть'),
								'click': function() {
									showFileView(l.path, true);
								}
							}, [ '👁️' ]));
						} else {
							actions.push(E('button', {
								'class': 'btn ghost ghost-compact',
								'type': 'button',
								'style': 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px;',
								'title': _('Редактировать список'),
								'aria-label': _('Редактировать'),
								'click': function() {
									showFileView(l.path, false);
								}
							}, [ '✏️' ]));
						}

						// 2. Direct download button (browser Blob download)
						actions.push(E('button', {
							'class': 'btn ghost ghost-compact',
							'type': 'button',
							'style': 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px;',
							'title': _('Скачать файл списка (.lst)'),
							'aria-label': _('Скачать'),
							'click': function() {
								downloadDirect(l.path);
							}
						}, [ '📥' ]));

						// 3. Delete button for custom lists
						if (isCustom) {
							actions.push(E('button', {
								'class': 'btn ghost ghost-compact',
								'type': 'button',
								'style': 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px; color: var(--bad);',
								'title': _('Удалить список'),
								'aria-label': _('Удалить'),
								'click': function() {
									deleteList(l.path);
								}
							}, [ '🗑️' ]));
						}

						var targets = l._targets || [];
						var usedCell;
						if (targets.length === 0) {
							usedCell = E('td', { 'style': 'text-align: center; width: 110px;' }, [
								E('span', { 'class': 'muted', 'style': 'opacity: 0.5;' }, [ '—' ])
							]);
						} else {
							var tooltipText = _('Используется в:\n') + targets.map(function(t) { return '• ' + t.displayName; }).join('\n');
							usedCell = E('td', { 'style': 'text-align: center; width: 110px;' }, [
								E('button', {
									'class': 'btn ghost-compact',
									'type': 'button',
									'style': 'background: var(--ok-soft); color: var(--ok); border-color: color-mix(in srgb, var(--ok) 40%, transparent); font-weight: 600; font-size: 12px; padding: 2px 8px; border-radius: 12px; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;',
									'title': tooltipText,
									'aria-label': _('Посмотреть где используется'),
									'click': function(ev) {
										ev.stopPropagation();
										showTargetsView(l.path, targets);
									}
								}, [
									'🎯 ',
									String(targets.length)
								])
							]);
						}

						rows.push(E('tr', {}, [
							E('td', { 'style': 'font-family: monospace; font-size: 13px; font-weight: 500;' }, [ l.path ]),
							E('td', { 'style': 'text-align: right; width: 110px;' }, [
								E('span', { 'class': 'badge' }, [ _('%d записей').format(l.lines || 0) ])
							]),
							usedCell,
							E('td', { 'style': 'text-align: right; width: 120px; padding-right: 12px; white-space: nowrap;' }, [
								E('div', { 'style': 'display: inline-flex; gap: 4px; justify-content: flex-end; align-items: center;' }, actions)
							])
						]));
					});
				}

				tableBody.replaceChildren.apply(tableBody, rows);
			}

			filterInput.addEventListener('input', function() {
				updateRows(filterInput.value);
			});
			updateRows('');

			var table = E('table', { 'class': 'table xfree-lists-table', 'style': 'width: 100%; margin-top: 8px;' }, [
				E('thead', {}, [
					E('tr', {}, [
						E('th', { 'style': 'text-align: left;' }, [ _('Файл списка (.lst)') ]),
						E('th', { 'style': 'text-align: right; width: 110px; white-space: nowrap;' }, [ _('Количество') ]),
						E('th', { 'style': 'text-align: center; width: 110px; white-space: nowrap;' }, [ _('Используется') ]),
						E('th', { 'style': 'text-align: right; width: 120px; padding-right: 12px; white-space: nowrap;' }, [ _('Действия') ])
					])
				]),
				tableBody
			]);

			var topBar;
			if (isCustom) {
				topBar = E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;'
				}, [
					E('div', { 'style': 'display: flex; align-items: center; flex-wrap: wrap; gap: 8px;' }, [
						E('span', { 'class': 'badge', 'style': 'background: var(--accent-soft); color: var(--accent);' }, [ '👤 ' + _('Пользовательский') ]),
						filterInput,
						onlyUsedBtn
					]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'style': 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px;',
						'click': function() {
							showCreateView();
						}
					}, [ '➕ ' + _('Добавить список') ])
				]);
			} else {
				topBar = E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;'
				}, [
					E('div', { 'style': 'display: flex; align-items: center; flex-wrap: wrap; gap: 8px;' }, [
						E('span', { 'class': 'badge' }, [ '🔒 ' + _('Только чтение') ]),
						filterInput,
						onlyUsedBtn
					]),
					E('span', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
						_('Предустановленные списки защищены от редактирования.')
					])
				]);
			}

			modalContainer.replaceChildren(
				topBar,
				E('div', { 'style': 'max-height: 55vh; overflow-y: auto;' }, [ table ])
			);
		}

		function showFileView(relPath, readOnly) {
			modalContainer.replaceChildren(E('div', { 'style': 'text-align: center; padding: 50px;' }, [
				E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка: %s…').format(relPath) ])
			]));

			var fullRel = modKey + '/upstream/' + relPath;
			xui.runSystemMenu('upstreamsGetList', fullRel).then(function(res) {
				if (res && res.error) {
					ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
					renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
					return;
				}

				var parts = relPath.split('/');
				var clickedFilename = parts[parts.length - 1];
				var dirpart = parts.length > 1 ? parts.slice(0, -1).join('/') : '';

				var mStem = clickedFilename.match(/^(fqdn|prefixes-ipv4|prefixes-ipv6|prefixes)-(.+)\.lst$/i);
				var stem = mStem ? mStem[2] : clickedFilename.replace(/\.lst$/i, '');
				if (!stem && dirpart) {
					var dParts = dirpart.split('/');
					stem = dParts[dParts.length - 1];
				}
				if (!stem) stem = 'list';

				var canonicalFormats = [
					{ type: 'fqdn', filename: 'fqdn-' + stem + '.lst', label: 'FQDN', icon: '🌐' },
					{ type: 'ipv4', filename: 'prefixes-ipv4-' + stem + '.lst', label: 'IPv4', icon: '🔢' },
					{ type: 'ipv6', filename: 'prefixes-ipv6-' + stem + '.lst', label: 'IPv6', icon: '🔢' }
				];

				var foundMap = {};
				(res.files || []).forEach(function(f) {
					foundMap[f.filename] = f;
				});

				var tabFiles = [];

				canonicalFormats.forEach(function(c) {
					var existing = foundMap[c.filename];
					var fRel = (dirpart ? (dirpart + '/') : '') + c.filename;
					var fPath = modKey + '/upstream/' + fRel;

					if (existing) {
						tabFiles.push({
							path: existing.path || fPath,
							relPath: fRel,
							filename: c.filename,
							type: c.type,
							label: c.label,
							icon: c.icon,
							lines: (typeof existing.lines === 'number') ? existing.lines : (existing.content ? existing.content.trim().split('\n').filter(Boolean).length : 0),
							content: existing.content || '',
							exists: true,
							custom: isCustom ? 1 : (existing.custom || 0)
						});
						delete foundMap[c.filename];
					} else if (isCustom) {
						tabFiles.push({
							path: fPath,
							relPath: fRel,
							filename: c.filename,
							type: c.type,
							label: c.label,
							icon: c.icon,
							lines: 0,
							content: '',
							exists: false,
							custom: 1
						});
					}
				});

				Object.keys(foundMap).forEach(function(fn) {
					var f = foundMap[fn];
					var fRel = (dirpart ? (dirpart + '/') : '') + fn;
					tabFiles.push({
						path: f.path || (modKey + '/upstream/' + fRel),
						relPath: fRel,
						filename: fn,
						type: f.type || 'other',
						label: f.label || fn,
						icon: (f.type === 'fqdn') ? '🌐' : '📄',
						lines: (typeof f.lines === 'number') ? f.lines : (f.content ? f.content.trim().split('\n').filter(Boolean).length : 0),
						content: f.content || '',
						exists: true,
						custom: isCustom ? 1 : (f.custom || 0)
					});
				});

				var activeIdx = 0;
				for (var i = 0; i < tabFiles.length; i++) {
					if (tabFiles[i].filename === clickedFilename) {
						activeIdx = i;
						break;
					}
				}

				var currentWidget = null;
				var widgetHost = E('div', { 'class': 'xfree-list-widget-host' });
				var tabButtons = [];
				var tabsBar = null;

				function updateTabLabel(idx) {
					var f = tabFiles[idx];
					var btn = tabButtons[idx];
					if (!f || !btn) return;
					var lCount = (typeof f.lines === 'number') ? f.lines : 0;
					btn.textContent = (f.icon || '📄') + ' ' + (f.label || f.filename) + ' (' + lCount + ')';
				}

				function switchTab(newIdx) {
					if (newIdx === activeIdx && widgetHost.hasChildNodes()) return;
					if (currentWidget) {
						tabFiles[activeIdx].stagedContent = currentWidget.getText();
					}
					activeIdx = newIdx;
					tabButtons.forEach(function(btn, i) {
						if (i === activeIdx) {
							btn.classList.add('is-active');
							btn.style.background = 'var(--accent, #3b82f6)';
							btn.style.color = '#ffffff';
							btn.style.borderColor = 'var(--accent, #3b82f6)';
						} else {
							btn.classList.remove('is-active');
							btn.style.background = 'var(--panel-2)';
							btn.style.color = 'var(--muted)';
							btn.style.borderColor = 'var(--line)';
						}
					});
					renderActiveTab();
				}

				function renderActiveTab() {
					var file = tabFiles[activeIdx];
					var canEdit = !readOnly && isCustom;
					var activeContent = (file.stagedContent !== undefined) ? file.stagedContent : (file.content || '');

					var hintText = !canEdit ?
						('🔒 ' + _('Предустановленный список: только для чтения. Обновляется автоматически при синхронизации источников.')) :
						(!file.exists ?
							('✏️ ' + _('Новый формат для этой подгруппы: введите записи по одной на строку и нажмите «Сохранить изменения» для создания файла.')) :
							('✏️ ' + _('Пользовательский список: редактируйте записи по одной на строку. Очистите список и сохраните, чтобы удалить файл.'))
						);

					currentWidget = xui.renderFileViewerWidget({
						path: file.relPath,
						filename: file.filename,
						content: activeContent,
						readOnly: !canEdit,
						canEdit: canEdit,
						canDownload: true,
						canCopy: true,
						hint: hintText
					});

					var ta = currentWidget.node.querySelector('textarea');
					if (ta) {
						if (file.type === 'fqdn') {
							ta.placeholder = 'example.com\n*.domain.org\napi.service.net';
						} else if (file.type === 'ipv6') {
							ta.placeholder = '2001:db8::/32\n2606:4700::/32';
						} else {
							ta.placeholder = '1.2.3.4\n192.168.1.0/24\n10.0.0.0/8';
						}
					}

					var bottomBar = E('div', {
						'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line);'
					}, [
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'font-size: 13px;',
							'click': function() {
								renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
							}
						}, [ '← ' + _('Назад к спискам') ]),

						canEdit ? E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px; font-weight: 600;',
							'click': function() {
								saveActiveFile();
							}
						}, [ '💾 ' + _('Сохранить изменения') ]) : ''
					]);

					widgetHost.replaceChildren(currentWidget.node, bottomBar);
				}

				function saveActiveFile() {
					var file = tabFiles[activeIdx];
					var newTxt = currentWidget.getText();
					var trimmed = String(newTxt || '').trim();
					var linesArr = trimmed ? trimmed.split(/\r?\n/).map(function(x) { return x.trim(); }).filter(Boolean) : [];

					if (linesArr.length > 0) {
						var contentToSave = linesArr.join('\n') + '\n';
						xui.runSystemMenu('upstreamsSaveList', file.path, contentToSave).then(function(sRes) {
							if (sRes && sRes.error) {
								ui.addNotification(null, E('p', {}, [ sRes.error ]), 'danger');
								return;
							}
							file.exists = true;
							file.content = contentToSave;
							file.stagedContent = contentToSave;
							file.lines = linesArr.length;
							updateTabLabel(activeIdx);
							renderActiveTab();
							ui.addNotification(null, E('p', {}, [ _('Список «%s» сохранён (%d записей)').format(file.filename, file.lines) ]), 'info');

							if (mod._cachedLists) {
								var found = false;
								for (var k = 0; k < mod._cachedLists.length; k++) {
									if (mod._cachedLists[k].path === file.relPath) {
										mod._cachedLists[k].lines = file.lines;
										found = true;
										break;
									}
								}
								if (!found) {
									mod._cachedLists.push({ path: file.relPath, lines: file.lines });
								}
							}
							self.reload();
						}).catch(function(err) {
							ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
						});
					} else {
						if (file.exists) {
							xui.runSystemMenu('upstreamsDeleteList', file.path).then(function(dRes) {
								if (dRes && dRes.error) {
									ui.addNotification(null, E('p', {}, [ dRes.error ]), 'danger');
									return;
								}
								file.exists = false;
								file.content = '';
								file.stagedContent = '';
								file.lines = 0;
								updateTabLabel(activeIdx);
								renderActiveTab();
								ui.addNotification(null, E('p', {}, [ _('Список «%s» очищен и удалён с роутера').format(file.filename) ]), 'info');

								if (mod._cachedLists) {
									mod._cachedLists = mod._cachedLists.filter(function(x) { return x.path !== file.relPath; });
								}
								self.reload();
							}).catch(function(err) {
								ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
							});
						} else {
							ui.addNotification(null, E('p', {}, [ _('Список пуст, файл не создан') ]), 'info');
						}
					}
				}

				if (tabFiles.length > 1) {
					tabsBar = E('div', {
						'class': 'xfree-dialog-tabs',
						'style': 'display: flex; gap: 8px; margin-bottom: 14px; border-bottom: 1px solid var(--line); padding-bottom: 8px; flex-wrap: wrap;'
					});
					tabFiles.forEach(function(f, idx) {
						var lCount = (typeof f.lines === 'number') ? f.lines : 0;
						var isActive = (idx === activeIdx);
						var tabBtn = E('button', {
							'class': 'xfree-dialog-tab-btn' + (isActive ? ' is-active' : ''),
							'type': 'button',
							'style': 'cursor: pointer; padding: 6px 14px; font-size: 13px; font-weight: 500; border-radius: 6px; border: 1px solid ' +
								(isActive ? 'var(--accent, #3b82f6)' : 'var(--line)') + '; background: ' +
								(isActive ? 'var(--accent, #3b82f6)' : 'var(--panel-2)') + '; color: ' +
								(isActive ? '#ffffff' : 'var(--muted)') + '; transition: all 0.15s ease;',
							'click': function() {
								switchTab(idx);
							}
						}, [ (f.icon || '📄') + ' ' + (f.label || f.filename) + ' (' + lCount + ')' ]);
						tabButtons.push(tabBtn);
						tabsBar.appendChild(tabBtn);
					});
				}

				renderActiveTab();

				if (tabsBar) {
					modalContainer.replaceChildren(tabsBar, widgetHost);
				} else {
					modalContainer.replaceChildren(widgetHost);
				}
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
				renderListsView(mod._cachedLists || []);
			});
		}

		function showCreateView(initialParams) {
			initialParams = initialParams || {};
			var initGroup = initialParams.group || '';
			var initService = initialParams.service || '';
			var initType = initialParams.type || 'fqdn';
			var initStem = initialParams.stem || '';

			var knownGroups = [ 'custom', 'ai', 'video', 'music', 'vpn', 'tools', 'others', 'dns', 'zapret', 'xft' ];
			var knownServices = [ 'youtube', 'discord', 'telegram', 'chatgpt', 'openai', 'spotify', 'netflix', 'instagram', 'twitter', 'twitch', 'github', 'cloudflare' ];

			var analysis = analyzeModuleLists(mod._cachedLists || []);

			if (!initGroup) {
				var existingGroupKeys = Object.keys(analysis.groups);
				initGroup = existingGroupKeys.length > 0 ? existingGroupKeys[0] : 'custom';
			}

			function buildGroupOptions(ana) {
				var opts = [];
				var existingGroups = Object.keys(ana.groups).sort();
				if (existingGroups.length > 0) {
					opts.push({ isHeader: true, label: '📁 ' + _('В этом источнике') });
					existingGroups.forEach(function(g) {
						var svcCount = Object.keys(ana.groups[g].services).length;
						var fileCount = ana.groups[g].files.length;
						var hint = svcCount > 0 ?
							_('%d сервисов, %d списков').format(svcCount, fileCount) :
							_('%d списков').format(fileCount);
						opts.push({
							value: g,
							label: g,
							icon: '📁',
							hint: hint
						});
					});
				}

				opts.push({ isHeader: true, label: '💡 ' + _('Рекомендуемые категории') });
				knownGroups.forEach(function(g) {
					if (existingGroups.indexOf(g) === -1) {
						opts.push({
							value: g,
							label: g,
							icon: '📂'
						});
					}
				});
				return opts;
			}

			function buildServiceOptions(ana, currentGroup) {
				var opts = [];
				opts.push({
					value: '',
					label: '— ' + _('(без подгруппы, список в корне группы)'),
					icon: '📂'
				});

				var grp = ana.groups[currentGroup];
				if (grp && Object.keys(grp.services).length > 0) {
					opts.push({ isHeader: true, label: '📁 ' + _('Существующие сервисы в группе «%s»').format(currentGroup) });
					Object.keys(grp.services).sort().forEach(function(s) {
						var sFiles = grp.services[s].files;
						var fileNames = sFiles.map(function(f) { return f.filename; }).join(', ');
						opts.push({
							value: s,
							label: s,
							icon: '⚡',
							hint: fileNames
						});
					});
				}

				opts.push({ isHeader: true, label: '💡 ' + _('Популярные сервисы') });
				knownServices.forEach(function(s) {
					if (!grp || !grp.services[s]) {
						opts.push({
							value: s,
							label: s,
							icon: '🌐'
						});
					}
				});
				return opts;
			}

			function buildStemOptions(ana, currentGroup, currentService) {
				var opts = [];
				var seen = {};

				if (currentService) {
					opts.push({ value: currentService, label: currentService, hint: _('по имени сервиса'), icon: '⚡' });
					seen[currentService] = true;
				}

				var grp = ana.groups[currentGroup];
				if (grp) {
					var targetFiles = currentService ?
						(grp.services[currentService] ? grp.services[currentService].files : []) :
						grp.files.filter(function(f) { return !f.service; });

					targetFiles.forEach(function(f) {
						if (f.stem && !seen[f.stem]) {
							seen[f.stem] = true;
							opts.push({
								value: f.stem,
								label: f.stem,
								hint: _('из %s').format(f.filename),
								icon: '📑'
							});
						}
					});
				}

				if (currentGroup && !seen[currentGroup]) {
					opts.push({ value: currentGroup, label: currentGroup, hint: _('по имени группы'), icon: '📁' });
					seen[currentGroup] = true;
				}

				return opts;
			}

			var groupCombobox = createCombobox({
				placeholder: 'custom',
				value: initGroup,
				options: buildGroupOptions(analysis),
				onChange: function(newGroup) {
					var gClean = String(newGroup || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
					serviceCombobox.setOptions(buildServiceOptions(analysis, gClean));
					stemCombobox.setOptions(buildStemOptions(analysis, gClean, serviceCombobox.getValue()));
					updatePreview();
				}
			});

			var serviceCombobox = createCombobox({
				placeholder: _('myservice (необязательно)'),
				value: initService,
				options: buildServiceOptions(analysis, initGroup),
				onChange: function(newService) {
					var gClean = String(groupCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
					var sClean = String(newService || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
					stemCombobox.setOptions(buildStemOptions(analysis, gClean, sClean));
					if (!stemCombobox.getValue() || stemCombobox.getValue() === gClean) {
						stemCombobox.setValue(sClean || gClean);
					}

					// Smart type auto-selection:
					// If this subgroup already has fqdn and lacks ipv4, auto-select ipv4!
					var grpObj = analysis.groups[gClean];
					if (grpObj) {
						var fList = sClean ?
							(grpObj.services[sClean] ? grpObj.services[sClean].files : []) :
							grpObj.files.filter(function(f) { return !f.service; });
						var hasFqdn = fList.some(function(f) { return f.type === 'fqdn'; });
						var hasIpv4 = fList.some(function(f) { return f.type === 'ipv4' || f.type === 'prefix'; });
						if (hasFqdn && !hasIpv4 && typeSelect.value === 'fqdn') {
							typeSelect.value = 'ipv4';
						} else if (hasIpv4 && !hasFqdn && typeSelect.value === 'ipv4') {
							typeSelect.value = 'fqdn';
						}
					}

					updatePreview();
				}
			});

			var defaultInitStem = initStem || initService || initGroup || 'custom';
			var stemCombobox = createCombobox({
				placeholder: 'my-list',
				value: defaultInitStem,
				options: buildStemOptions(analysis, initGroup, initService),
				onChange: function() {
					updatePreview();
				}
			});

			var typeSelect = E('select', {
				'class': 'cbi-input-select',
				'style': 'width: 100%; margin-bottom: 6px;'
			}, [
				E('option', { 'value': 'fqdn' }, [ '🌐 ' + _('FQDN домены (fqdn-<stem>.lst)') ]),
				E('option', { 'value': 'ipv4' }, [ '📑 ' + _('IPv4 префиксы CIDR (prefixes-ipv4-<stem>.lst)') ]),
				E('option', { 'value': 'prefix' }, [ '📑 ' + _('CIDR префиксы общие (prefixes-<stem>.lst)') ]),
				E('option', { 'value': 'ipv6' }, [ '📑 ' + _('IPv6 префиксы CIDR (prefixes-ipv6-<stem>.lst)') ])
			]);
			typeSelect.value = initType;

			var typePills = E('div', {
				'style': 'display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 10px 0; align-items: center;'
			}, [
				E('span', { 'class': 'muted', 'style': 'font-size: 11px;' }, [ _('Быстрый выбор типа:') ]),
				E('button', {
					'type': 'button',
					'class': 'btn ghost-compact',
					'style': 'font-size: 11px; padding: 2px 8px;',
					'click': function() { typeSelect.value = 'fqdn'; updatePreview(); }
				}, [ '🌐 fqdn' ]),
				E('button', {
					'type': 'button',
					'class': 'btn ghost-compact',
					'style': 'font-size: 11px; padding: 2px 8px;',
					'click': function() { typeSelect.value = 'ipv4'; updatePreview(); }
				}, [ '📑 prefixes-ipv4' ]),
				E('button', {
					'type': 'button',
					'class': 'btn ghost-compact',
					'style': 'font-size: 11px; padding: 2px 8px;',
					'click': function() { typeSelect.value = 'prefix'; updatePreview(); }
				}, [ '📑 prefixes' ]),
				E('button', {
					'type': 'button',
					'class': 'btn ghost-compact',
					'style': 'font-size: 11px; padding: 2px 8px;',
					'click': function() { typeSelect.value = 'ipv6'; updatePreview(); }
				}, [ '📑 prefixes-ipv6' ])
			]);

			var previewEl = E('code', {
				'style': 'display: block; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 6px; margin: 6px 0 8px 0; font-size: 13px; color: var(--ok); word-break: break-all; font-family: monospace;'
			}, [ '—' ]);

			var statusContainer = E('div', {
				'style': 'margin-bottom: 12px;'
			});

			var contentLabel = E('label', { 'class': 'cbi-input-title' }, [
				_('5. Начальные записи:')
			]);

			var contentArea = E('textarea', {
				'class': 'cbi-input-textarea',
				'rows': 8,
				'placeholder': 'example.com\n*.domain.org\napi.service.net',
				'style': 'width: 100%; font-family: monospace; font-size: 13px;'
			});

			var createBtn = E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'style': 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px; font-weight: 600;'
			}, [ '➕ ' + _('Создать список') ]);

			function updatePreview() {
				var g = String(groupCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var s = String(serviceCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var n = String(stemCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var t = typeSelect.value || 'fqdn';

				var defaultStem = s || g || 'custom';
				var stem = n || defaultStem;

				var fname = (t === 'ipv4') ? ('prefixes-ipv4-' + stem + '.lst') :
					((t === 'ipv6') ? ('prefixes-ipv6-' + stem + '.lst') :
					((t === 'prefix') ? ('prefixes-' + stem + '.lst') : ('fqdn-' + stem + '.lst')));

				var relPath = (g || 'group') + '/' + (s ? (s + '/') : '') + fname;
				var fullPath = modKey + '/upstream/' + relPath;

				previewEl.textContent = fullPath;

				if (t === 'fqdn') {
					contentLabel.textContent = _('5. Начальные FQDN домены (по одному на строку):');
					contentArea.placeholder = 'example.com\n*.domain.org\napi.service.net';
				} else if (t === 'ipv6') {
					contentLabel.textContent = _('5. Начальные IPv6 CIDR префиксы (по одному на строку):');
					contentArea.placeholder = '2001:db8::/32\n2606:4700::/32';
				} else {
					contentLabel.textContent = _('5. Начальные IP-адреса и подсети CIDR (по одному на строку):');
					contentArea.placeholder = '1.2.3.4\n192.168.1.0/24\n10.0.0.0/8';
				}

				var existing = (mod._cachedLists || []).find(function(item) {
					return item && item.path === relPath;
				});

				var folderFiles = (mod._cachedLists || []).filter(function(item) {
					if (!item || !item.path) return false;
					var parts = item.path.split('/');
					if (s) {
						return parts.length === 3 && parts[0] === g && parts[1] === s;
					} else {
						return parts.length === 2 && parts[0] === g;
					}
				});

				var statusElements = [];

				if (existing) {
					createBtn.disabled = true;
					createBtn.style.opacity = '0.5';
					createBtn.style.cursor = 'not-allowed';

					statusElements.push(E('div', {
						'style': 'padding: 10px 14px; background: var(--bad-soft); border: 1px solid var(--bad); border-radius: 8px; color: var(--bad); margin-bottom: 10px;'
					}, [
						E('div', { 'style': 'font-weight: 600; font-size: 13px;' }, [
							'⚠️ ' + _('Файл «%s» уже существует (%d строк)').format(fname, existing.lines || 0)
						]),
						E('div', { 'style': 'font-size: 12px; margin-top: 4px; color: var(--text);' }, [
							_('Выберите другое имя (stem), измените тип списка или отредактируйте существующий файл напрямую.')
						]),
						E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'margin-top: 8px; font-size: 12px; background: var(--panel-2); color: var(--bad); border-color: var(--bad);',
							'click': function() {
								showFileView(relPath, false);
							}
						}, [ '✏️ ' + _('Перейти к редактированию существующего файла') ])
					]));
				} else {
					createBtn.disabled = false;
					createBtn.style.opacity = '1';
					createBtn.style.cursor = 'pointer';
				}

				var fileListItems = [];
				folderFiles.forEach(function(f) {
					var parts = f.path.split('/');
					var fn = parts[parts.length - 1];
					fileListItems.push(E('div', {
						'style': 'display: flex; align-items: center; justify-content: space-between; padding: 4px 0; border-bottom: 1px dashed color-mix(in srgb, var(--line) 40%, transparent); font-size: 12px;'
					}, [
						E('div', { 'style': 'display: flex; align-items: center; gap: 6px;' }, [
							E('span', { 'style': 'color: var(--ok);' }, [ '✓' ]),
							E('code', { 'style': 'font-weight: 600; color: var(--text);' }, [ fn ])
						]),
						E('span', { 'class': 'badge', 'style': 'font-size: 11px;' }, [ _('%d строк').format(f.lines || 0) ])
					]));
				});

				if (!existing) {
					fileListItems.push(E('div', {
						'style': 'display: flex; align-items: center; justify-content: space-between; padding: 4px 0; font-size: 12px; color: var(--ok); font-weight: 600;'
					}, [
						E('div', { 'style': 'display: flex; align-items: center; gap: 6px;' }, [
							E('span', {}, [ '➕' ]),
							E('code', { 'style': 'color: var(--ok); font-weight: 700;' }, [ fname ]),
							E('span', { 'style': 'font-size: 11px; font-weight: normal; opacity: 0.9;' }, [ '— ' + _('будет создан') ])
						]),
						E('span', { 'class': 'badge', 'style': 'background: var(--ok-soft); color: var(--ok); font-size: 11px;' }, [ _('новый файл') ])
					]));
				}

				statusElements.push(E('div', {
					'style': 'padding: 8px 12px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 6px; font-size: 12px;'
				}, [
					E('div', { 'style': 'font-weight: 600; color: var(--muted); margin-bottom: 6px; display: flex; align-items: center; gap: 6px;' }, [
						'📂 ' + _('Файлы в подгруппе: %s').format(g + (s ? (' / ' + s) : ''))
					]),
					E('div', {}, fileListItems)
				]));

				statusContainer.replaceChildren.apply(statusContainer, statusElements);
			}

			typeSelect.addEventListener('change', updatePreview);

			createBtn.addEventListener('click', function() {
				var g = String(groupCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var s = String(serviceCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var n = String(stemCombobox.getValue() || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var t = typeSelect.value || 'fqdn';

				if (!g) {
					ui.addNotification(null, E('p', {}, [ _('Укажите название группы') ]), 'danger');
					groupCombobox.focus();
					return;
				}
				var stem = n || s || g;
				if (!stem) {
					ui.addNotification(null, E('p', {}, [ _('Укажите имя списка') ]), 'danger');
					stemCombobox.focus();
					return;
				}

				var payload = JSON.stringify({
					module: modKey,
					group: g,
					service: s,
					type: t,
					name: stem,
					content: String(contentArea.value || '').trim()
				});

				createBtn.disabled = true;
				createBtn.textContent = '⏳ ' + _('Создание…');

				xui.runSystemMenu('upstreamsCreateList', modKey, payload).then(function(res) {
					if (res && res.error) {
						ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
						createBtn.disabled = false;
						createBtn.textContent = '➕ ' + _('Создать список');
						return;
					}
					ui.addNotification(null, E('p', {}, [ _('Список успешно создан: %s').format(res.path || stem) ]), 'info');
					loadAndRenderLists(true);
					self.reload();
				}).catch(function(err) {
					ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
					createBtn.disabled = false;
					createBtn.textContent = '➕ ' + _('Создать список');
				});
			});

			// Quick-pick section for paired lists
			var quickPickSection = null;
			var quickPickPills = [];

			function checkFolderPairings(g, s, files) {
				var fqdnFile = files.find(function(f) { return f.type === 'fqdn'; });
				var ipv4File = files.find(function(f) { return f.type === 'ipv4' || f.type === 'prefix'; });

				if (fqdnFile && !ipv4File) {
					var st = fqdnFile.stem;
					quickPickPills.push({
						group: g,
						service: s,
						stem: st,
						type: 'ipv4',
						badgeText: '+prefixes-ipv4',
						badgeBg: 'var(--ok-soft)',
						badgeColor: 'var(--ok)',
						label: (g + (s ? (' / ' + s) : '')),
						title: _('В «%s» есть %s. Создать парный prefixes-ipv4-%s.lst').format(g + (s ? ('/' + s) : ''), fqdnFile.filename, st)
					});
				} else if (ipv4File && !fqdnFile) {
					var st = ipv4File.stem;
					quickPickPills.push({
						group: g,
						service: s,
						stem: st,
						type: 'fqdn',
						badgeText: '+fqdn',
						badgeBg: 'var(--accent-soft)',
						badgeColor: 'var(--accent)',
						label: (g + (s ? (' / ' + s) : '')),
						title: _('В «%s» есть %s. Создать парный fqdn-%s.lst').format(g + (s ? ('/' + s) : ''), ipv4File.filename, st)
					});
				}
			}

			Object.keys(analysis.groups).forEach(function(gName) {
				var grp = analysis.groups[gName];
				var rootFiles = grp.files.filter(function(f) { return !f.service; });
				checkFolderPairings(gName, '', rootFiles);

				Object.keys(grp.services).forEach(function(sName) {
					var sFiles = grp.services[sName].files;
					checkFolderPairings(gName, sName, sFiles);
				});
			});

			if (quickPickPills.length > 0) {
				var pillsNodes = quickPickPills.map(function(p) {
					return E('button', {
						'type': 'button',
						'class': 'btn ghost-compact',
						'style': 'display: inline-flex; align-items: center; gap: 6px; font-size: 12px; padding: 4px 10px; border-radius: 6px; cursor: pointer;',
						'title': p.title,
						'click': function() {
							groupCombobox.setValue(p.group, true);
							serviceCombobox.setValue(p.service, true);
							stemCombobox.setValue(p.stem, true);
							typeSelect.value = p.type;
							updatePreview();
							contentArea.focus();
						}
					}, [
						'📁 ' + p.label,
						E('span', {
							'class': 'badge',
							'style': 'background: ' + p.badgeBg + '; color: ' + p.badgeColor + '; font-size: 11px; font-weight: 600; padding: 1px 6px;'
						}, [ p.badgeText ])
					]);
				});

				quickPickSection = E('div', {
					'style': 'margin-bottom: 14px; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;'
				}, [
					E('div', { 'style': 'font-size: 12px; font-weight: 600; margin-bottom: 8px; color: var(--text); display: flex; align-items: center; gap: 6px;' }, [
						'⚡ ' + _('Быстрое создание парных списков для существующих сервисов:')
					]),
					E('div', { 'style': 'display: flex; flex-wrap: wrap; gap: 8px;' }, pillsNodes)
				]);
			}

			var formChildren = [
				E('div', {
					'style': 'margin-bottom: 12px; padding: 8px 12px; background: var(--panel-2); border-radius: 6px; font-size: 12px; color: var(--muted);'
				}, [
					'💡 ' + _('Списки организуются по канонической структуре: группа, сервис и файл с явным префиксом (fqdn-* или prefixes-*). Выберите существующую категорию/сервис из выпадающего списка или введите собственное название.')
				])
			];

			if (quickPickSection) {
				formChildren.push(quickPickSection);
			}

			formChildren.push(
				E('label', { 'class': 'cbi-input-title' }, [ _('1. Группа (категория):') ]),
				groupCombobox.node,
				E('div', { 'style': 'font-size: 11px; color: var(--muted); margin-bottom: 10px;' }, [
					'💡 ' + _('Выберите из существующих в этом источнике, стандартных (custom, ai, video…) или введите своё')
				]),

				E('label', { 'class': 'cbi-input-title' }, [ _('2. Сервис / подгруппа (необязательно, можно оставить пустым):') ]),
				serviceCombobox.node,
				E('div', { 'style': 'font-size: 11px; color: var(--muted); margin-bottom: 10px;' }, [
					'💡 ' + _('Выберите сервис из группы, популярный (youtube, telegram…) или введите своё название')
				]),

				E('label', { 'class': 'cbi-input-title' }, [ _('3. Тип записей списка:') ]),
				typeSelect,
				typePills,

				E('label', { 'class': 'cbi-input-title' }, [ _('4. Имя списка (stem):') ]),
				stemCombobox.node,
				E('div', { 'style': 'font-size: 11px; color: var(--muted); margin-bottom: 10px;' }, [
					'💡 ' + _('Выберите имя из существующих файлов подгруппы или задайте уникальное имя')
				]),

				E('label', { 'class': 'cbi-input-title' }, [ _('Итоговый путь к файлу:') ]),
				previewEl,
				statusContainer,

				contentLabel,
				contentArea,

				E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line);'
				}, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function() {
							renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
						}
					}, [ '← ' + _('Назад к спискам') ]),
					createBtn
				])
			);

			var form = E('div', { 'class': 'xfree-create-list-form' }, formChildren);
			modalContainer.replaceChildren(form);
			updatePreview();
		}

		function downloadDirect(relPath) {
			var fullRel = modKey + '/upstream/' + relPath;
			xui.runSystemMenu('upstreamsGetList', fullRel).then(function(res) {
				var content = (res && res.content) || '';
				var blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
				var url = URL.createObjectURL(blob);
				var a = document.createElement('a');
				a.href = url;
				a.download = relPath.split('/').pop() || 'list.lst';
				document.body.appendChild(a);
				a.click();
				document.body.removeChild(a);
				setTimeout(function() { URL.revokeObjectURL(url); }, 2000);
			});
		}

		function deleteList(relPath) {
			var fullRel = modKey + '/upstream/' + relPath;
			xui.confirm({
				title: _('Удаление списка'),
				message: _('Удалить файл списка «%s»?').format(relPath),
				detail: _('Файл будет удален с роутера, а индекс модуля пересобран.'),
				tone: 'danger',
				confirmText: _('Удалить'),
				cancelText: _('Отмена')
			}).then(function(confirmed) {
				if (!confirmed) return;
				xui.runSystemMenu('upstreamsDeleteList', fullRel).then(function(res) {
					if (res && res.error) {
						ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
						return;
					}
					ui.addNotification(null, E('p', {}, [ _('Список «%s» удален').format(relPath) ]), 'info');
					if (mod._cachedLists) {
						mod._cachedLists = mod._cachedLists.filter(function(x) { return x.path !== relPath; });
					}
					renderListsView(mod._cachedLists || []);
					self.reload();
				}).catch(function(err) {
					ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
				});
			});
		}

		// Initial load
		loadAndRenderLists(false);
	}

	_toggleModule(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;
		var nextState = (mod.enabled === 1) ? '0' : '1';

		xui.runSystemMenu('upstreamsToggle', modKey, nextState).then(function(res) {
			if (res && res.error) {
				ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
				return;
			}
			self.reload();
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
		});
	}

	_deleteCustomModule(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;

		xui.confirm({
			title: _('Удаление источника'),
			message: _('Безвозвратно удалить пользовательский источник «%s»?').format(mod.title || modKey),
			detail: _('Каталог upstreams/%s будет удален. Списки перестанут быть доступны.').format(modKey),
			tone: 'danger',
			confirmText: _('Удалить'),
			cancelText: _('Отмена')
		}).then(function(confirmed) {
			if (!confirmed) return;
			xui.runSystemMenu('upstreamsDeleteCustom', modKey).then(function(res) {
				if (res && res.error) {
					ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
					return;
				}
				ui.addNotification(null, E('p', {}, [ _('Источник «%s» удален').format(mod.title || modKey) ]), 'info');
				self.reload();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
			});
		});
	}

	render() {
		var self = this;
		var modules = self._modules || [];

		this.className = 'xfree-upstreams-root';

		/* 1. Global Toolbar */
		var toolbar = E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 8px;' }, [
			E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': function() {
					self._runBgAction(_('Обновление и применение всех источников'), 'upstreamsUpdateApply');
				}
			}, [ '🚀 ' + _('Обновить всё и применить') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function() {
					self._runBgAction(_('Скачивание обновлений активных источников'), 'upstreamsUpdateActive');
				}
			}, [ '📥 ' + _('Скачать активные') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function() {
					self._runBgAction(_('Применение обновлений (Drift)'), 'upstreamsApply');
				}
			}, [ '⚡ ' + _('Применить обновления (Drift)') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function() {
					self._runBgAction(_('Переиндексация источников списков'), 'upstreamsReindex');
				}
			}, [ '🔄 ' + _('Переиндексировать') ]),
			E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'style': 'margin-left: auto; background: var(--ok-soft); color: var(--ok); border-color: var(--ok);',
				'click': function() {
					self._showCreateModal();
				}
			}, [ '➕ ' + _('Создать свой Upstream') ])
		]);

		/* 2. Content cards */
		var cardsContainer;

		if (self._loading) {
			cardsContainer = E('div', { 'class': 'cbi-section', 'style': 'text-align: center; padding: 30px;' }, [
				E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка источников…') ])
			]);
		} else if (self._error) {
			cardsContainer = E('div', { 'class': 'cbi-section is-bad', 'style': 'padding: 20px;' }, [
				E('p', { 'style': 'color: var(--bad);' }, [ '⚠️ ' + self._error ])
			]);
		} else if (!modules.length) {
			cardsContainer = E('div', { 'class': 'cbi-section', 'style': 'text-align: center; padding: 30px;' }, [
				E('p', { 'class': 'muted' }, [ _('Источники списков не найдены.') ])
			]);
		} else {
			var cardEls = modules.map(function(mod) {
				var isEnabled = (mod.enabled === 1);
				var isCustom = (mod.custom === 1);
				var canDelete = isCustom && (mod.name !== 'user') && (mod.id !== 'user');

				var statusBadge = E('span', {
					'class': 'xfree-vpn-status ' + (isEnabled ? 'is-ok' : 'is-muted')
				}, [ isEnabled ? _('Включен') : _('Отключен') ]);

				var isUserXfree = (mod.name === 'user' || mod.id === 'user' || (mod.title && mod.title.toLowerCase() === 'xfree'));
				var typeBadge;
				if (isCustom) {
					typeBadge = E('span', {
						'class': 'xfree-vpn-status is-info',
						'style': 'background: var(--accent-soft); color: var(--accent);'
					}, [ _('Пользовательский') ]);
				} else if (isUserXfree) {
					typeBadge = E('span', {
						'class': 'xfree-vpn-status',
						'style': 'background: var(--accent-soft); color: var(--accent);'
					}, [ _('Встроенный') ]);
				} else {
					typeBadge = E('span', {
						'class': 'xfree-vpn-status is-muted'
					}, [ _('Внешний') ]);
				}

				var countBadge = E('span', {
					'class': 'badge',
					'style': 'font-size: 12px; margin-left: 6px;'
				}, [ _('%d списков').format(mod.listsCount || 0) ]);

				var toggleBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'title': isEnabled ? _('Отключить этот источник') : _('Включить этот источник'),
					'click': function() {
						self._toggleModule(mod);
					}
				}, [ isEnabled ? ('⏸️ ' + _('Выключить')) : ('▶️ ' + _('Включить')) ]);

				var updateBtn = E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'title': _('Скачать свежие списки только для этого источника'),
					'click': function() {
						self._runBgAction(
							_('Обновление источника: %s').format(mod.title || mod.name),
							'updateOne:' + (mod.id || mod.name)
						);
					}
				}, [ '🔄 ' + _('Обновить') ]);

				var viewBtn = E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'title': _('Просмотреть списки внутри источника'),
					'click': function() {
						self._showListsModal(mod);
					}
				}, [ '📑 ' + _('Списки (%d)').format(mod.listsCount || 0) ]);

				var deleteBtn = canDelete ? E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'style': 'color: var(--bad);',
					'title': _('Удалить пользовательский источник'),
					'click': function() {
						self._deleteCustomModule(mod);
					}
				}, [ '🗑️ ' + _('Удалить') ]) : '';

				return E('div', {
					'class': 'xfree-zapret-test-card',
					'style': 'display: flex; flex-direction: column; justify-content: space-between; border-radius: 12px; padding: 16px; background: var(--panel-2); border: 1px solid var(--line);' + (isEnabled ? '' : 'opacity: 0.75;')
				}, [
					E('div', {}, [
						E('div', { 'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;' }, [
							E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
								E('span', { 'style': 'font-size: 20px;' }, [ moduleIcon(mod) ]),
								E('strong', { 'style': 'font-size: 16px;' }, [ mod.title || mod.name ])
							]),
							E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
								typeBadge,
								statusBadge
							])
						]),
						E('p', { 'class': 'muted', 'style': 'margin: 6px 0 12px 0; font-size: 13px;' }, [
							mod.desc || _('Без описания')
						]),
						E('div', { 'style': 'margin-bottom: 12px;' }, [
							E('span', { 'class': 'muted' }, [ _('Всего в источнике:') ]),
							countBadge
						])
					]),
					E('div', { 'style': 'display: flex; flex-wrap: wrap; gap: 6px; border-top: 1px solid var(--line); padding-top: 12px;' }, [
						toggleBtn,
						updateBtn,
						viewBtn,
						deleteBtn
					])
				]);
			});

			cardsContainer = E('div', {
				'class': 'xfree-upstreams-grid',
				'style': 'display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 16px;'
			}, cardEls);
		}

		this.replaceChildren(
			toolbar,
			cardsContainer
		);
	}
});

return baseclass.extend({
	tag: TAG
});
