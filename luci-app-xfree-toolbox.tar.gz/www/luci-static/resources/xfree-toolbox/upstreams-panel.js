'use strict';
'require baseclass';
'require xfree-toolbox.wc as wc';
'require xfree-toolbox.core.prototype-mix as prototypeMix';
'require xfree-toolbox.upstreams-actions as upstreamsActions';
'require xfree-toolbox.upstreams-cards as upstreamsCards';
'require xfree-toolbox.upstreams-create-modal as upstreamsCreateModal';
'require xfree-toolbox.upstreams-modal as upstreamsModal';

var TAG = 'xfree-upstreams';

var UpstreamsPanel = class extends wc.LightElement {
};

function mixUpstreams(part) {
	prototypeMix.mixInto(UpstreamsPanel.prototype, part);
}

mixUpstreams(upstreamsActions);
mixUpstreams(upstreamsCards);
mixUpstreams(upstreamsCreateModal);
mixUpstreams(upstreamsModal);

wc.define(TAG, UpstreamsPanel);

return baseclass.extend({
	tag: TAG
});
