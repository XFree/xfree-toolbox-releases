'use strict';
'require baseclass';
'require ui';
'require xfree-toolbox.wc as wc';

var TAG = 'xfree-upstreams';

function moduleIcon(mod) {
	var name = String((mod && (mod.id || mod.name)) || '').toLowerCase();
	var title = String((mod && mod.title) || '').toLowerCase();
	if (name === 'user' || name === 'xfree' || title === 'xfree') return '🧰';
	if (mod && mod.custom) return '👤';
	if (name.indexOf('allow') >= 0 || name.indexOf('domain') >= 0) return '🌐';
	if (name.indexOf('rekryt') >= 0 || name.indexOf('iplist') >= 0) return '📑';
	if (name.indexOf('vpn') >= 0 || name.indexOf('proton') >= 0) return '🛡️';
	return '📦';
}

wc.define(TAG, class extends wc.LightElement {
	getXui() {
		return (this._spec && this._spec.xui) ||
			(this._spec && this._spec.view && this._spec.view.xui) ||
			window.xfreeLuciUi;
	}

	mount(spec) {
		this._spec = spec || {};
		this._modules = [];
		this._loading = true;
		this._error = '';
		this.requestPaint();
		this.loadCatalog();
	}

	loadCatalog() {
		var self = this;
		var xui = self.getXui();
		self._loading = true;
		self._error = '';
		self.requestPaint();

		if (!xui || !xui.runSystemMenu) {
			self._loading = false;
			self._error = _('Не удалось подключить интерфейс управления xfree');
			self.requestPaint();
			return;
		}

		xui.runSystemMenu('upstreamsCatalog').then(function(res) {
			self._loading = false;
			self._modules = (res && res.modules) || [];
			self.requestPaint();
		}).catch(function(err) {
			self._loading = false;
			self._error = (err && err.message) ? err.message : String(err);
			self.requestPaint();
		});
	}

	reload() {
		this.loadCatalog();
	}

	_runBgAction(title, taskName, onFinish) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var dlg = xui.openExecOutputDialog(title);
		dlg.setStatus(_('Запуск задачи…'));
		dlg.setText(_('Инициализация…'));

		xui.runSystemMenu('upstreamsStartBg', taskName).then(function(res) {
			if (res && res.error) {
				dlg.setText(res.error);
				dlg.setDone(false);
				return;
			}

			dlg.setStatus(_('Выполняется в фоне…'));
			if (res && res.stdout)
				dlg.setText(res.stdout);

			var pollTimer = setInterval(function() {
				xui.runSystemMenu('upstreamsBgStatus').then(function(st) {
					if (!st) return;
					if (st.stdout)
						dlg.setText(st.stdout);

					if (st.running === 0) {
						clearInterval(pollTimer);
						pollTimer = null;
						var ok = (st.exitCode === '0' || st.exitCode === 0);
						dlg.setDone(ok);
						self.reload();
						if (typeof onFinish === 'function')
							onFinish(ok);
					}
				}).catch(function(err) {
					clearInterval(pollTimer);
					pollTimer = null;
					dlg.appendText('\n' + _('Ошибка опроса статуса: %s').format(err.message || String(err)));
					dlg.setDone(false);
				});
			}, 1000);
		}).catch(function(err) {
			dlg.setText(err && err.message ? err.message : String(err));
			dlg.setDone(false);
		});
	}

	_showCreateModal() {
		var self = this;
		var nameInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'placeholder': 'my-custom-domains',
			'style': 'width: 100%; margin-bottom: 8px;'
		});
		var titleInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'placeholder': 'Мой список доменов',
			'style': 'width: 100%; margin-bottom: 8px;'
		});
		var descInput = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'placeholder': 'Пользовательские домены и сервисы',
			'style': 'width: 100%; margin-bottom: 8px;'
		});
		var domainsArea = E('textarea', {
			'class': 'cbi-input-textarea',
			'rows': 8,
			'placeholder': 'example.com\n*.mycompany.corp\nservice.internal',
			'style': 'width: 100%; font-family: monospace; font-size: 13px;'
		});

		var body = E('div', { 'class': 'xfree-custom-upstream-form' }, [
			E('label', { 'class': 'cbi-input-title' }, [ _('Идентификатор источника (латиница, цифры, дефис):') ]),
			nameInput,
			E('label', { 'class': 'cbi-input-title' }, [ _('Название источника:') ]),
			titleInput,
			E('label', { 'class': 'cbi-input-title' }, [ _('Краткое описание:') ]),
			descInput,
			E('label', { 'class': 'cbi-input-title' }, [ _('Начальный список доменов или IP (по одному на строку):') ]),
			domainsArea,
			E('p', { 'class': 'muted', 'style': 'margin-top: 8px;' }, [
				'🔒 ' + _('Этот источник создаётся локально на роутере в upstreams/<id>/ и никогда не перезаписывается при обновлении внешних репозиториев. После создания он сразу появится в чек-листах выбора маршрутов VPN, DNS и Zapret.')
			])
		]);

		var xui = self.getXui();
		if (!xui) return;
		xui.openDialog({
			title: '➕ ' + _('Создать пользовательский Upstream'),
			size: 'md',
			body: body,
			actions: [
				{
					label: _('Отмена'),
					variant: 'default',
					close: true
				},
				{
					label: _('Создать'),
					variant: 'primary',
					click: function() {
						var rawName = String(nameInput.value || '').trim();
						var name = rawName.toLowerCase().replace(/[^a-z0-9._-]/g, '-');
						if (!name) {
							ui.addNotification(null, E('p', {}, [ _('Укажите идентификатор источника') ]), 'danger');
							return;
						}
						var payload = JSON.stringify({
							name: name,
							title: String(titleInput.value || '').trim() || name,
							desc: String(descInput.value || '').trim(),
							domains: String(domainsArea.value || '').trim()
						});

						ui.hideModal();
						xui.runSystemMenu('upstreamsCreateCustom', name, payload).then(function(res) {
							if (res && res.error) {
								ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
								return;
							}
							ui.addNotification(null, E('p', {}, [ _('Источник %s успешно создан!').format(name) ]), 'info');
							self.reload();
						}).catch(function(err) {
							ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
						});
					}
				}
			]
		});
	}

	_showListsModal(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;
		var isCustom = (mod.custom === 1);

		var modalContainer = E('div', { 'class': 'xfree-lists-modal-container', 'style': 'min-height: 400px;' });

		// Open dialog once: stays open during navigation between lists, editor, and create form!
		xui.openDialog({
			title: '📑 ' + _('Списки источника: %s').format(mod.title || mod.name),
			size: 'wide',
			body: modalContainer,
			actions: [{
				label: _('Закрыть'),
				variant: 'default',
				close: true
			}]
		});

		modalContainer.appendChild(E('div', { 'style': 'text-align: center; padding: 48px;' }, [
			E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка файлов…') ])
		]));

		function loadAndRenderLists(forceRefresh) {
			if (mod._cachedLists && !forceRefresh) {
				renderListsView(mod._cachedLists, mod._cachedMatrix || null);
				return;
			}
			Promise.all([
				xui.runSystemMenu('upstreamsGetLists', modKey),
				(xui.loadRoutingMatrix ? xui.loadRoutingMatrix() : Promise.resolve(null)).catch(function(e) {
					console.warn('Matrix load failed', e);
					return null;
				})
			]).then(function(resArr) {
				var res = resArr[0];
				var matrix = resArr[1];
				var lists = (res && res.lists) || [];
				mod._cachedLists = lists;
				mod._cachedMatrix = matrix;
				renderListsView(lists, matrix);
			}).catch(function(err) {
				modalContainer.replaceChildren(E('div', { 'class': 'alert-message danger' }, [
					E('p', {}, [ (err && err.message) ? err.message : String(err) ])
				]));
			});
		}

		function showTargetsView(relPath, targets) {
			var items = targets.map(function(t) {
				var icon = (t.target === 'iface') ? '🛡️' : ((t.target === 'dns') ? '🌐' : '⚡');
				var kindLabel = (t.target === 'iface') ? _('VPN-туннель (маршрутизация трафика)') :
					((t.target === 'dns') ? _('DNS-профиль (перенаправление доменов)') : _('Zapret DPI (секция стратегии обхода)'));

				return E('div', {
					'style': 'display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px; margin-bottom: 8px;'
				}, [
					E('div', {}, [
						E('div', { 'style': 'font-weight: 600; font-size: 15px;' }, [ icon + ' ' + (t.label || t.scope) ]),
						E('div', { 'class': 'muted', 'style': 'font-size: 12px; margin-top: 3px;' }, [ kindLabel ])
					]),
					E('span', {
						'class': 'badge',
						'style': 'background: var(--ok-soft); color: var(--ok); font-size: 12px; padding: 4px 8px;'
					}, [ '✓ ' + _('Активно') ])
				]);
			});

			var viewEl = E('div', { 'class': 'xfree-targets-view' }, [
				E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; padding-bottom: 12px; border-bottom: 1px solid var(--line);'
				}, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function() {
							renderListsView(mod._cachedLists || [], mod._cachedMatrix || null);
						}
					}, [ '← ' + _('Назад к спискам') ]),
					E('span', { 'class': 'badge', 'style': 'background: var(--ok-soft); color: var(--ok); font-weight: 600;' }, [
						_('Используется в %d правилах').format(targets.length)
					])
				]),
				E('div', { 'style': 'margin-bottom: 8px; font-size: 14px; font-family: monospace; word-break: break-all; color: var(--accent); font-weight: 600;' }, [
					'📄 ' + modKey + '/upstream/' + relPath
				]),
				E('p', { 'class': 'muted', 'style': 'margin-bottom: 14px; font-size: 13px;' }, [
					_('Этот список включён в следующих правилах маршрутизации и профилях:')
				]),
				E('div', { 'style': 'max-height: 48vh; overflow-y: auto;' }, items)
			]);

			modalContainer.replaceChildren(viewEl);
		}

		function renderListsView(lists, matrix) {
			function getListTargets(relPath) {
				if (!matrix || !matrix.columns || !matrix.checked) return [];
				var parts = String(relPath || '').split('/');
				var group = parts[0] || '';
				var service = parts.length > 2 ? parts[1] : '';

				var grpTag = 'grp__' + modKey + '__' + group;
				var svcTag = service ? ('svc__' + modKey + '__' + group + '__' + service) : '';

				var activeTargets = [];
				matrix.columns.forEach(function(col) {
					var chk = matrix.checked[col.key];
					if (!Array.isArray(chk)) return;
					var isHit = chk.indexOf(grpTag) !== -1 || (svcTag && chk.indexOf(svcTag) !== -1);
					if (isHit) {
						var icon = (col.target === 'iface') ? '🛡️' : ((col.target === 'dns') ? '🌐' : '⚡');
						var typeName = (col.target === 'iface') ? _('VPN') : ((col.target === 'dns') ? _('DNS') : _('Zapret'));
						activeTargets.push({
							key: col.key,
							target: col.target,
							scope: col.scope || col.label,
							label: col.label || col.scope,
							displayName: icon + ' ' + typeName + ': ' + (col.label || col.scope)
						});
					}
				});
				return activeTargets;
			}

			lists.forEach(function(l) {
				l._targets = getListTargets(l.path);
			});

			var totalUsedCount = lists.filter(function(l) { return l._targets && l._targets.length > 0; }).length;

			var filterInput = E('input', {
				'type': 'text',
				'class': 'cbi-input-text',
				'placeholder': '🔍 ' + _('Фильтр по названию файла (.lst) или цели…'),
				'style': 'flex: 1; min-width: 200px; max-width: 320px; font-size: 13px; height: 32px; padding: 2px 10px; border-radius: 6px;'
			});

			var filterOnlyUsed = false;
			var onlyUsedBtn = E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'style': 'font-size: 12px; padding: 0 10px; height: 32px;' + (totalUsedCount > 0 ? '' : 'display: none;'),
				'title': _('Показать только списки, которые сейчас выбраны в правилах маршрутизации'),
				'click': function() {
					filterOnlyUsed = !filterOnlyUsed;
					onlyUsedBtn.style.background = filterOnlyUsed ? 'var(--accent-soft)' : '';
					onlyUsedBtn.style.color = filterOnlyUsed ? 'var(--accent)' : '';
					onlyUsedBtn.style.borderColor = filterOnlyUsed ? 'var(--accent)' : '';
					updateRows(filterInput.value);
				}
			}, [ '🎯 ' + _('Только используемые (%d)').format(totalUsedCount) ]);

			var tableBody = E('tbody');

			function updateRows(filterText) {
				var q = String(filterText || '').trim().toLowerCase();
				var filtered = lists.filter(function(l) {
					if (filterOnlyUsed && (!l._targets || !l._targets.length))
						return false;
					if (!q) return true;
					if (l.path.toLowerCase().indexOf(q) !== -1)
						return true;
					if (l._targets && l._targets.some(function(t) { return t.displayName.toLowerCase().indexOf(q) !== -1; }))
						return true;
					return false;
				});

				var rows = [];
				if (!filtered.length) {
					rows.push(E('tr', {}, [
						E('td', { 'colspan': 4, 'class': 'muted', 'style': 'text-align: center; padding: 28px;' }, [
							q ? _('Списки, соответствующие фильтру, не найдены.') : _('В этом источнике пока нет файлов списков.')
						])
					]));
				} else {
					filtered.forEach(function(l) {
						var actions = [];

						// 1. View or Edit (clean icon button with tooltip)
						if (!isCustom) {
							actions.push(E('button', {
								'class': 'btn ghost ghost-compact',
								'type': 'button',
								'style': 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px;',
								'title': _('Просмотреть список'),
								'aria-label': _('Просмотреть'),
								'click': function() {
									showFileView(l.path, true);
								}
							}, [ '👁️' ]));
						} else {
							actions.push(E('button', {
								'class': 'btn ghost ghost-compact',
								'type': 'button',
								'style': 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px;',
								'title': _('Редактировать список'),
								'aria-label': _('Редактировать'),
								'click': function() {
									showFileView(l.path, false);
								}
							}, [ '✏️' ]));
						}

						// 2. Direct download button (browser Blob download)
						actions.push(E('button', {
							'class': 'btn ghost ghost-compact',
							'type': 'button',
							'style': 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px;',
							'title': _('Скачать файл списка (.lst)'),
							'aria-label': _('Скачать'),
							'click': function() {
								downloadDirect(l.path);
							}
						}, [ '📥' ]));

						// 3. Delete button for custom lists
						if (isCustom) {
							actions.push(E('button', {
								'class': 'btn ghost ghost-compact',
								'type': 'button',
								'style': 'display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; min-width: 32px; min-height: 32px; padding: 0 !important; font-size: 14px; border-radius: 6px; color: var(--bad);',
								'title': _('Удалить список'),
								'aria-label': _('Удалить'),
								'click': function() {
									deleteList(l.path);
								}
							}, [ '🗑️' ]));
						}

						var targets = l._targets || [];
						var usedCell;
						if (targets.length === 0) {
							usedCell = E('td', { 'style': 'text-align: center;' }, [
								E('span', { 'class': 'muted', 'style': 'opacity: 0.5;' }, [ '—' ])
							]);
						} else {
							var tooltipText = _('Используется в:\n') + targets.map(function(t) { return '• ' + t.displayName; }).join('\n');
							usedCell = E('td', { 'style': 'text-align: center;' }, [
								E('button', {
									'class': 'btn ghost-compact',
									'type': 'button',
									'style': 'background: var(--ok-soft); color: var(--ok); border-color: color-mix(in srgb, var(--ok) 40%, transparent); font-weight: 600; font-size: 12px; padding: 2px 8px; border-radius: 12px; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;',
									'title': tooltipText,
									'aria-label': _('Посмотреть где используется'),
									'click': function(ev) {
										ev.stopPropagation();
										showTargetsView(l.path, targets);
									}
								}, [
									'🎯 ',
									String(targets.length)
								])
							]);
						}

						rows.push(E('tr', {}, [
							E('td', { 'style': 'font-family: monospace; font-size: 13px; font-weight: 500;' }, [ l.path ]),
							E('td', { 'style': 'text-align: right;' }, [
								E('span', { 'class': 'badge' }, [ _('%d записей').format(l.lines || 0) ])
							]),
							usedCell,
							E('td', { 'style': 'text-align: right; white-space: nowrap;' }, [
								E('div', { 'style': 'display: inline-flex; gap: 4px; justify-content: flex-end;' }, actions)
							])
						]));
					});
				}

				tableBody.replaceChildren.apply(tableBody, rows);
			}

			filterInput.addEventListener('input', function() {
				updateRows(filterInput.value);
			});
			updateRows('');

			var table = E('table', { 'class': 'table xfree-lists-table', 'style': 'width: 100%; margin-top: 8px;' }, [
				E('thead', {}, [
					E('tr', {}, [
						E('th', {}, [ _('Файл списка (.lst)') ]),
						E('th', { 'style': 'text-align: right; width: 120px;' }, [ _('Количество') ]),
						E('th', { 'style': 'text-align: center; width: 120px;' }, [ _('Используется') ]),
						E('th', { 'style': 'text-align: right; width: 130px;' }, [ _('Действия') ])
					])
				]),
				tableBody
			]);

			var topBar;
			if (isCustom) {
				topBar = E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;'
				}, [
					E('div', { 'style': 'display: flex; align-items: center; flex-wrap: wrap; gap: 8px;' }, [
						E('span', { 'class': 'badge', 'style': 'background: var(--accent-soft); color: var(--accent);' }, [ '👤 ' + _('Пользовательский') ]),
						filterInput,
						onlyUsedBtn
					]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'style': 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px;',
						'click': function() {
							showCreateView();
						}
					}, [ '➕ ' + _('Добавить список') ])
				]);
			} else {
				topBar = E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; padding: 10px 14px; background: var(--panel-2); border: 1px solid var(--line); border-radius: 8px;'
				}, [
					E('div', { 'style': 'display: flex; align-items: center; flex-wrap: wrap; gap: 8px;' }, [
						E('span', { 'class': 'badge' }, [ '🔒 ' + _('Только чтение') ]),
						filterInput,
						onlyUsedBtn
					]),
					E('span', { 'class': 'muted', 'style': 'font-size: 12px;' }, [
						_('Предустановленные списки защищены от редактирования.')
					])
				]);
			}

			modalContainer.replaceChildren(
				topBar,
				E('div', { 'style': 'max-height: 55vh; overflow-y: auto;' }, [ table ])
			);
		}

		function showFileView(relPath, readOnly) {
			modalContainer.replaceChildren(E('div', { 'style': 'text-align: center; padding: 50px;' }, [
				E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка: %s…').format(relPath) ])
			]));

			var fullRel = modKey + '/upstream/' + relPath;
			xui.runSystemMenu('upstreamsGetList', fullRel).then(function(res) {
				var content = (res && res.content) || '';
				var widget = xui.renderFileViewerWidget({
					path: relPath,
					filename: relPath.split('/').pop(),
					content: content,
					readOnly: readOnly,
					canEdit: !readOnly,
					canDownload: true,
					canCopy: true,
					hint: readOnly ?
						('🔒 ' + _('Предустановленный список: только для чтения. Обновляется автоматически при синхронизации источников.')) :
						('✏️ ' + _('Пользовательский список: редактируйте записи по одной на строку. Изменения сохраняются локально на роутере.'))
				});

				var bottomBar = E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line);'
				}, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'style': 'font-size: 13px;',
						'click': function() {
							// Instant switch back: 0 ms, no closing of modal!
							renderListsView(mod._cachedLists || []);
						}
					}, [ '← ' + _('Назад к спискам') ]),

					E('div', { 'style': 'display: flex; gap: 8px;' }, [
						(!readOnly) ? E('button', {
							'class': 'btn ghost-compact',
							'type': 'button',
							'style': 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px;',
							'click': function() {
								var newContent = widget.getText();
								xui.runSystemMenu('upstreamsSaveList', fullRel, newContent).then(function(sRes) {
									if (sRes && sRes.error) {
										ui.addNotification(null, E('p', {}, [ sRes.error ]), 'danger');
										return;
									}
									ui.addNotification(null, E('p', {}, [ _('Список «%s» сохранён').format(relPath) ]), 'info');
									var newLines = newContent ? newContent.split(/\r?\n/).length : 0;
									if (mod._cachedLists) {
										for (var k = 0; k < mod._cachedLists.length; k++) {
											if (mod._cachedLists[k].path === relPath) {
												mod._cachedLists[k].lines = newLines;
												break;
											}
										}
									}
									self.reload();
								}).catch(function(err) {
									ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
								});
							}
						}, [ '💾 ' + _('Сохранить изменения') ]) : ''
					])
				]);

				modalContainer.replaceChildren(
					widget.node,
					bottomBar
				);
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
				renderListsView(mod._cachedLists || []);
			});
		}

		function showCreateView() {
			var knownGroups = [ 'custom', 'ai', 'video', 'music', 'vpn', 'tools', 'others', 'dns', 'zapret', 'xft' ];
			var knownServices = [ 'youtube', 'discord', 'telegram', 'chatgpt', 'openai', 'spotify', 'netflix', 'instagram', 'twitter', 'twitch', 'github', 'cloudflare' ];

			var groupSet = {};
			knownGroups.forEach(function(g) { groupSet[g] = true; });
			var serviceSet = {};
			knownServices.forEach(function(s) { serviceSet[s] = true; });

			(mod._cachedLists || []).forEach(function(item) {
				if (!item || !item.path) return;
				var parts = item.path.split('/');
				if (parts.length > 1 && parts[0])
					groupSet[parts[0]] = true;
				if (parts.length > 2 && parts[1])
					serviceSet[parts[1]] = true;
			});

			var groupOptions = Object.keys(groupSet).sort();
			var serviceOptions = Object.keys(serviceSet).sort();

			var groupDatalistId = 'xfree-groups-' + Math.random().toString(36).substring(2, 9);
			var groupDatalist = E('datalist', { 'id': groupDatalistId }, groupOptions.map(function(g) {
				return E('option', { 'value': g });
			}));

			var serviceDatalistId = 'xfree-services-' + Math.random().toString(36).substring(2, 9);
			var serviceDatalist = E('datalist', { 'id': serviceDatalistId }, serviceOptions.map(function(s) {
				return E('option', { 'value': s });
			}));

			var groupInput = E('input', {
				'type': 'text',
				'class': 'cbi-input-text',
				'list': groupDatalistId,
				'autocomplete': 'off',
				'placeholder': 'custom',
				'style': 'width: 100%; margin-bottom: 4px;'
			});
			groupInput.value = 'custom';

			var serviceInput = E('input', {
				'type': 'text',
				'class': 'cbi-input-text',
				'list': serviceDatalistId,
				'autocomplete': 'off',
				'placeholder': 'myservice (необязательно)',
				'style': 'width: 100%; margin-bottom: 4px;'
			});

			var typeSelect = E('select', {
				'class': 'cbi-input-select',
				'style': 'width: 100%; margin-bottom: 8px;'
			}, [
				E('option', { 'value': 'fqdn' }, [ '🌐 ' + _('FQDN домены (fqdn-<stem>.lst)') ]),
				E('option', { 'value': 'ipv4' }, [ '📑 ' + _('IPv4 префиксы CIDR (prefixes-ipv4-<stem>.lst)') ]),
				E('option', { 'value': 'ipv6' }, [ '📑 ' + _('IPv6 префиксы CIDR (prefixes-ipv6-<stem>.lst)') ])
			]);

			var nameInput = E('input', {
				'type': 'text',
				'class': 'cbi-input-text',
				'placeholder': 'my-list',
				'style': 'width: 100%; margin-bottom: 8px;'
			});

			var previewEl = E('code', {
				'style': 'display: block; padding: 10px 14px; background: var(--panel-2); border-radius: 6px; margin: 8px 0 12px 0; font-size: 13px; color: var(--ok); word-break: break-all;'
			}, [ '—' ]);

			function updatePreview() {
				var g = String(groupInput.value || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var s = String(serviceInput.value || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var n = String(nameInput.value || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
				var t = typeSelect.value || 'fqdn';

				nameInput.placeholder = s || g || 'my-list';

				var stem = n || s || g || 'list';
				var fname = (t === 'ipv4') ? ('prefixes-ipv4-' + stem + '.lst') :
					((t === 'ipv6') ? ('prefixes-ipv6-' + stem + '.lst') : ('fqdn-' + stem + '.lst'));

				var p = modKey + '/upstream/' + (g || 'group') + '/' + (s ? (s + '/') : '') + fname;
				previewEl.textContent = p;
			}

			groupInput.addEventListener('input', updatePreview);
			serviceInput.addEventListener('input', updatePreview);
			nameInput.addEventListener('input', updatePreview);
			typeSelect.addEventListener('change', updatePreview);
			updatePreview();

			var contentArea = E('textarea', {
				'class': 'cbi-input-textarea',
				'rows': 8,
				'placeholder': 'example.com\n*.domain.org\napi.service.net',
				'style': 'width: 100%; font-family: monospace; font-size: 13px;'
			});

			var form = E('div', { 'class': 'xfree-create-list-form' }, [
				E('div', {
					'style': 'margin-bottom: 12px; padding: 8px 12px; background: var(--panel-2); border-radius: 6px; font-size: 12px; color: var(--muted);'
				}, [
					'💡 ' + _('Списки организуются по канонической структуре: группа, сервис и файл с явным префиксом (fqdn-* или prefixes-*).')
				]),
				E('label', { 'class': 'cbi-input-title' }, [ _('1. Группа (категория):') ]),
				groupInput,
				groupDatalist,
				E('div', { 'style': 'font-size: 11px; color: var(--muted); margin-bottom: 10px;' }, [
					'💡 ' + _('Выберите из вариантов (custom, ai, video, music, vpn…) или введите своё название')
				]),
				E('label', { 'class': 'cbi-input-title' }, [ _('2. Сервис / подгруппа (необязательно, можно оставить пустым):') ]),
				serviceInput,
				serviceDatalist,
				E('div', { 'style': 'font-size: 11px; color: var(--muted); margin-bottom: 10px;' }, [
					'💡 ' + _('Выберите из вариантов (youtube, discord, telegram…) или введите своё название')
				]),
				E('label', { 'class': 'cbi-input-title' }, [ _('3. Тип записей списка:') ]),
				typeSelect,
				E('label', { 'class': 'cbi-input-title' }, [ _('4. Имя списка (stem):') ]),
				nameInput,
				E('label', { 'class': 'cbi-input-title' }, [ _('Итоговый относительный путь к файлу:') ]),
				previewEl,
				E('label', { 'class': 'cbi-input-title' }, [ _('5. Начальные записи (по одной строке на запись):') ]),
				contentArea,
				E('div', {
					'style': 'display: flex; justify-content: space-between; align-items: center; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line);'
				}, [
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'click': function() {
							renderListsView(mod._cachedLists || []);
						}
					}, [ '← ' + _('Назад к спискам') ]),
					E('button', {
						'class': 'btn ghost-compact',
						'type': 'button',
						'style': 'background: var(--ok-soft); color: var(--ok); border-color: var(--ok); font-size: 13px;',
						'click': function() {
							var g = String(groupInput.value || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
							var s = String(serviceInput.value || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
							var n = String(nameInput.value || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-');
							var t = typeSelect.value || 'fqdn';

							if (!g) {
								ui.addNotification(null, E('p', {}, [ _('Укажите название группы') ]), 'danger');
								return;
							}
							var stem = n || s || g;
							if (!stem) {
								ui.addNotification(null, E('p', {}, [ _('Укажите имя списка') ]), 'danger');
								return;
							}

							var payload = JSON.stringify({
								module: modKey,
								group: g,
								service: s,
								type: t,
								name: stem,
								content: String(contentArea.value || '').trim()
							});

							xui.runSystemMenu('upstreamsCreateList', modKey, payload).then(function(res) {
								if (res && res.error) {
									ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
									return;
								}
								ui.addNotification(null, E('p', {}, [ _('Список успешно создан: %s').format(res.path || stem) ]), 'info');
								loadAndRenderLists(true);
								self.reload();
							}).catch(function(err) {
								ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
							});
						}
					}, [ '➕ ' + _('Создать список') ])
				])
			]);

			modalContainer.replaceChildren(form);
		}

		function downloadDirect(relPath) {
			var fullRel = modKey + '/upstream/' + relPath;
			xui.runSystemMenu('upstreamsGetList', fullRel).then(function(res) {
				var content = (res && res.content) || '';
				var blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
				var url = URL.createObjectURL(blob);
				var a = document.createElement('a');
				a.href = url;
				a.download = relPath.split('/').pop() || 'list.lst';
				document.body.appendChild(a);
				a.click();
				document.body.removeChild(a);
				setTimeout(function() { URL.revokeObjectURL(url); }, 2000);
			});
		}

		function deleteList(relPath) {
			var fullRel = modKey + '/upstream/' + relPath;
			xui.confirm({
				title: _('Удаление списка'),
				message: _('Удалить файл списка «%s»?').format(relPath),
				detail: _('Файл будет удален с роутера, а индекс модуля пересобран.'),
				tone: 'danger',
				confirmText: _('Удалить'),
				cancelText: _('Отмена')
			}).then(function(confirmed) {
				if (!confirmed) return;
				xui.runSystemMenu('upstreamsDeleteList', fullRel).then(function(res) {
					if (res && res.error) {
						ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
						return;
					}
					ui.addNotification(null, E('p', {}, [ _('Список «%s» удален').format(relPath) ]), 'info');
					if (mod._cachedLists) {
						mod._cachedLists = mod._cachedLists.filter(function(x) { return x.path !== relPath; });
					}
					renderListsView(mod._cachedLists || []);
					self.reload();
				}).catch(function(err) {
					ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
				});
			});
		}

		// Initial load
		loadAndRenderLists(false);
	}

	_toggleModule(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;
		var nextState = (mod.enabled === 1) ? '0' : '1';

		xui.runSystemMenu('upstreamsToggle', modKey, nextState).then(function(res) {
			if (res && res.error) {
				ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
				return;
			}
			self.reload();
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
		});
	}

	_deleteCustomModule(mod) {
		var self = this;
		var xui = self.getXui();
		if (!xui) return;
		var modKey = mod.id || mod.name;

		xui.confirm({
			title: _('Удаление источника'),
			message: _('Безвозвратно удалить пользовательский источник «%s»?').format(mod.title || modKey),
			detail: _('Каталог upstreams/%s будет удален. Списки перестанут быть доступны.').format(modKey),
			tone: 'danger',
			confirmText: _('Удалить'),
			cancelText: _('Отмена')
		}).then(function(confirmed) {
			if (!confirmed) return;
			xui.runSystemMenu('upstreamsDeleteCustom', modKey).then(function(res) {
				if (res && res.error) {
					ui.addNotification(null, E('p', {}, [ res.error ]), 'danger');
					return;
				}
				ui.addNotification(null, E('p', {}, [ _('Источник «%s» удален').format(mod.title || modKey) ]), 'info');
				self.reload();
			}).catch(function(err) {
				ui.addNotification(null, E('p', {}, [ (err && err.message) ? err.message : String(err) ]), 'danger');
			});
		});
	}

	render() {
		var self = this;
		var s = self._spec || {};
		var view = s.view;
		var modules = self._modules || [];

		this.className = 'xfree-upstreams-root';

		/* 1. Global Toolbar */
		var toolbar = E('div', { 'class': 'xfree-vpn-tunnel-actions', 'style': 'margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 8px;' }, [
			E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'click': function() {
					self._runBgAction(_('Обновление и применение всех источников'), 'upstreamsUpdateApply');
				}
			}, [ '🚀 ' + _('Обновить всё и применить') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function() {
					self._runBgAction(_('Скачивание обновлений активных источников'), 'upstreamsUpdateActive');
				}
			}, [ '📥 ' + _('Скачать активные') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function() {
					self._runBgAction(_('Применение обновлений (Drift)'), 'upstreamsApply');
				}
			}, [ '⚡ ' + _('Применить обновления (Drift)') ]),
			E('button', {
				'class': 'ghost ghost-compact',
				'type': 'button',
				'click': function() {
					self._runBgAction(_('Переиндексация источников списков'), 'upstreamsReindex');
				}
			}, [ '🔄 ' + _('Переиндексировать') ]),
			E('button', {
				'class': 'btn ghost-compact',
				'type': 'button',
				'style': 'margin-left: auto; background: var(--ok-soft); color: var(--ok); border-color: var(--ok);',
				'click': function() {
					self._showCreateModal();
				}
			}, [ '➕ ' + _('Создать свой Upstream') ])
		]);

		/* 2. Content cards */
		var cardsContainer;

		if (self._loading) {
			cardsContainer = E('div', { 'class': 'cbi-section', 'style': 'text-align: center; padding: 30px;' }, [
				E('p', { 'class': 'muted' }, [ '⏳ ' + _('Загрузка списка источников…') ])
			]);
		} else if (self._error) {
			cardsContainer = E('div', { 'class': 'cbi-section is-bad', 'style': 'padding: 20px;' }, [
				E('p', { 'style': 'color: var(--bad);' }, [ '⚠️ ' + self._error ])
			]);
		} else if (!modules.length) {
			cardsContainer = E('div', { 'class': 'cbi-section', 'style': 'text-align: center; padding: 30px;' }, [
				E('p', { 'class': 'muted' }, [ _('Источники списков не найдены.') ])
			]);
		} else {
			var cardEls = modules.map(function(mod) {
				var isEnabled = (mod.enabled === 1);
				var isCustom = (mod.custom === 1);
				var canDelete = isCustom && (mod.name !== 'user') && (mod.id !== 'user');

				var statusBadge = E('span', {
					'class': 'xfree-vpn-status ' + (isEnabled ? 'is-ok' : 'is-muted')
				}, [ isEnabled ? _('Включен') : _('Отключен') ]);

				var isUserXfree = (mod.name === 'user' || mod.id === 'user' || (mod.title && mod.title.toLowerCase() === 'xfree'));
				var typeBadge;
				if (isCustom) {
					typeBadge = E('span', {
						'class': 'xfree-vpn-status is-info',
						'style': 'background: var(--accent-soft); color: var(--accent);'
					}, [ _('Пользовательский') ]);
				} else if (isUserXfree) {
					typeBadge = E('span', {
						'class': 'xfree-vpn-status',
						'style': 'background: var(--accent-soft); color: var(--accent);'
					}, [ _('Встроенный') ]);
				} else {
					typeBadge = E('span', {
						'class': 'xfree-vpn-status is-muted'
					}, [ _('Внешний') ]);
				}

				var countBadge = E('span', {
					'class': 'badge',
					'style': 'font-size: 12px; margin-left: 6px;'
				}, [ _('%d списков').format(mod.listsCount || 0) ]);

				var toggleBtn = E('button', {
					'class': 'btn ghost-compact',
					'type': 'button',
					'title': isEnabled ? _('Отключить этот источник') : _('Включить этот источник'),
					'click': function() {
						self._toggleModule(mod);
					}
				}, [ isEnabled ? ('⏸️ ' + _('Выключить')) : ('▶️ ' + _('Включить')) ]);

				var updateBtn = E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'title': _('Скачать свежие списки только для этого источника'),
					'click': function() {
						self._runBgAction(
							_('Обновление источника: %s').format(mod.title || mod.name),
							'updateOne:' + (mod.id || mod.name)
						);
					}
				}, [ '🔄 ' + _('Обновить') ]);

				var viewBtn = E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'title': _('Просмотреть списки внутри источника'),
					'click': function() {
						self._showListsModal(mod);
					}
				}, [ '📑 ' + _('Списки (%d)').format(mod.listsCount || 0) ]);

				var deleteBtn = canDelete ? E('button', {
					'class': 'ghost ghost-compact',
					'type': 'button',
					'style': 'color: var(--bad);',
					'title': _('Удалить пользовательский источник'),
					'click': function() {
						self._deleteCustomModule(mod);
					}
				}, [ '🗑️ ' + _('Удалить') ]) : '';

				return E('div', {
					'class': 'xfree-zapret-test-card',
					'style': 'display: flex; flex-direction: column; justify-content: space-between; border-radius: 12px; padding: 16px; background: var(--panel-2); border: 1px solid var(--line);' + (isEnabled ? '' : 'opacity: 0.75;')
				}, [
					E('div', {}, [
						E('div', { 'style': 'display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;' }, [
							E('div', { 'style': 'display: flex; align-items: center; gap: 8px;' }, [
								E('span', { 'style': 'font-size: 20px;' }, [ moduleIcon(mod) ]),
								E('strong', { 'style': 'font-size: 16px;' }, [ mod.title || mod.name ])
							]),
							E('div', { 'style': 'display: flex; gap: 6px; align-items: center;' }, [
								typeBadge,
								statusBadge
							])
						]),
						E('p', { 'class': 'muted', 'style': 'margin: 6px 0 12px 0; font-size: 13px;' }, [
							mod.desc || _('Без описания')
						]),
						E('div', { 'style': 'margin-bottom: 12px;' }, [
							E('span', { 'class': 'muted' }, [ _('Всего в источнике:') ]),
							countBadge
						])
					]),
					E('div', { 'style': 'display: flex; flex-wrap: wrap; gap: 6px; border-top: 1px solid var(--line); padding-top: 12px;' }, [
						toggleBtn,
						updateBtn,
						viewBtn,
						deleteBtn
					])
				]);
			});

			cardsContainer = E('div', {
				'class': 'xfree-upstreams-grid',
				'style': 'display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 16px;'
			}, cardEls);
		}

		this.replaceChildren(
			toolbar,
			cardsContainer
		);
	}
});

return baseclass.extend({
	tag: TAG
});
