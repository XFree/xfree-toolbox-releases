'use strict';
'require view';
'require dom';
'require ui';
'require poll';
'require xfree-toolbox.luci-routes as Routes';
'require xfree-toolbox.luci-ui as xui';
'require xfree-toolbox.nav';
'require xfree-toolbox.overview-panel';
'require xfree-toolbox.menu-panel';
'require xfree-toolbox.uplink-panel';
'require xfree-toolbox.vpn-panel';
'require xfree-toolbox.routing-hub';
'require xfree-toolbox.traffic-map';
'require xfree-toolbox.zapret-panel';
'require xfree-toolbox.telemt-panel';
'require xfree-toolbox.upstreams-panel';
'require xfree-toolbox.mesh-panel';
'require xfree-toolbox.devicepolicy-panel';
'require xfree-toolbox.vpn-server-panel';
'require xfree-toolbox.vpn-protocols-panel';
'require xfree-toolbox.system-resources-panel as systemResourcesPanel';
'require xfree-toolbox.system-updates-panel as systemUpdatesPanel';
'require xfree-toolbox.system-maintenance-panel as systemMaintenancePanel';
'require xfree-toolbox.system-hardware-panel as systemHardwarePanel';
'require xfree-toolbox.system-mgmt-panel as systemMgmtPanel';
'require xfree-toolbox.network-modem-panel as networkModemPanel';

var routesData = Routes.data;
var DEFAULT_ROUTE = routesData.defaultRoute || 'overview';
var DEFAULT_REPORT_POLL_SEC = 30;
var DEFAULT_INVOKE_POLL_SEC = 2;

function hashParts() {
	var h = (window.location.hash || '').replace(/^#/, '').trim();
	var parts;

	if (!h)
		return { route: '', tab: '', panel: '' };

	parts = decodeURIComponent(h).split('/');
	return {
		route: parts[0] || '',
		tab: parts[1] || '',
		panel: parts[2] || ''
	};
}

/* Универсальное сопоставление panelId по маршруту и хэшу через Routes resolver (O(1)) */
function reportPanelId(routeId, parts) {
	if (Routes && typeof Routes.resolvePanel === 'function')
		return Routes.resolvePanel(routeId, parts);

	parts = parts || {};
	var hint = parts.panel || parts.tab || '';
	if (hint && routesData.panels && routesData.panels[hint])
		return hint;

	var route = findRoute(routeId);
	var tabs = (route && route.tabs) || [];
	return tabs.length ? (tabs[0].panel || tabs[0].id || '') : hint;
}

function vpnPanelId(parts) {
	return reportPanelId('vpn', parts);
}

function setHash(routeId, tab, panel, push) {
	var base = L.url('admin/services/xfree-toolbox');
	var bits = [ routeId || DEFAULT_ROUTE ];
	var hash;
	var url;
	var state;

	if (tab)
		bits.push(tab);
	if (panel)
		bits.push(panel);

	hash = '#' + encodeURIComponent(bits.join('/'));
	url = base + hash;
	state = { xfree: 1, route: routeId || DEFAULT_ROUTE, tab: tab || '', panel: panel || '' };

	if (window.location.pathname + window.location.search + window.location.hash === url)
		return;

	if (push)
		window.history.pushState(state, '', url);
	else
		window.history.replaceState(state, '', url);
}

function ensureStylesheets() {
	var bust = 'v=20261025b';
	var files = [
		{ id: 'xfree-web-css', href: L.resource('xfree-toolbox/xfree-web.css') + '?' + bust },
		{ id: 'xfree-dashboard-css', href: L.resource('xfree-toolbox/xfree-dashboard.css') + '?' + bust }
	];

	files.forEach(function(item) {
		var existing = document.getElementById(item.id);

		if (existing) {
			if (existing.getAttribute('href') !== item.href)
				existing.setAttribute('href', item.href);
			return;
		}

		dom.append(document.head, E('link', {
			'id': item.id,
			'rel': 'stylesheet',
			'type': 'text/css',
			'href': item.href
		}));
	});
}

function findRoute(routeId) {
	if (Routes && typeof Routes.findRoute === 'function')
		return Routes.findRoute(routeId);

	var list = routesData.routes || [];
	var i;

	for (i = 0; i < list.length; i++) {
		if (list[i].id === routeId)
			return list[i];
	}

	return null;
}

function findPanel(panelId) {
	if (Routes && typeof Routes.findPanel === 'function')
		return Routes.findPanel(panelId);

	return (routesData.panels && routesData.panels[panelId]) || null;
}

function panelVisible(node) {
	return xui.menuItemVisible(node);
}

return view.extend({
	runSystemMenu: function(action, arg, payload) {
		return xui.runSystemMenu(action, arg, payload);
	},

	_routeCache: {},

	_getCache: function(key) {
		var entry = this._routeCache && this._routeCache[key];
		return entry ? entry.data : null;
	},

	_setCache: function(key, data) {
		if (!this._routeCache)
			this._routeCache = {};
		this._routeCache[key] = {
			time: Date.now(),
			data: Object.assign({}, data)
		};
	},

	_clearCache: function(key) {
		if (!this._routeCache)
			return;
		if (key)
			delete this._routeCache[key];
		else
			this._routeCache = {};
	},

	stopReportPoll: function() {
		if (this._xfreeReportPoll) {
			poll.remove(this._xfreeReportPoll);
			this._xfreeReportPoll = null;
		}
		this._xfreeReportNode = null;
		this._xfreeReportMain = null;
	},

	stopInvokePoll: function() {
		if (this._xfreeInvokePoll) {
			poll.remove(this._xfreeInvokePoll);
			this._xfreeInvokePoll = null;
		}
		this._xfreeInvokeNode = null;
		this._xfreeInvokeMain = null;
	},

	reportPollInterval: function(node) {
		if (!node || node.pollInterval === false || node.pollInterval === 0)
			return 0;

		var n = parseInt(node.pollInterval, 10);

		return (n > 0) ? n : DEFAULT_REPORT_POLL_SEC;
	},

	/* Hash routing/{general|vpn|dns|zapret}/<scope> → active list target. */
	applyWizardScopeFromParts: function(routeId, parts) {
		parts = parts || {};
		if (routeId !== 'routing')
			return;
		this._xfreeWizardActiveIface = parts.panel || '';
	},

	routingPanelId: function(tab) {
		if (tab === 'dns')
			return 'routing.dns';
		if (tab === 'zapret')
			return 'zapret.lists';
		if (tab === 'upstreams')
			return 'upstreams.hub';
		if (tab === 'exclude')
			return 'routing.exclude';
		if (tab === 'general')
			return 'routing.general';
		return 'routing.vpn';
	},

	load: function() {
		var view = this;
		var parts = hashParts();
		var routeId = findRoute(parts.route) ? parts.route : DEFAULT_ROUTE;

		view.applyWizardScopeFromParts(routeId, parts);

		return Promise.resolve({
			routeId: routeId,
			tab: parts.tab || '',
			panel: parts.panel || '',
			loading: true
		});
	},

	preloadRoute: function(routeId, parts) {
		var view = this;
		var panelId;
		var node;
		var tab;

		parts = parts || {};

		if (routeId === 'network' || routeId === 'mesh') {
			panelId = reportPanelId(routeId, parts);
			if (panelId === 'network.modem' || panelId === 'modem') {
				return xui.runSystemMenu('modemDiag').then(function(res) {
					return {
						routeId: 'network',
						panelId: 'network.modem',
						execResult: res
					};
				}).catch(function(err) {
					return {
						routeId: 'network',
						panelId: 'network.modem',
						execResult: { code: 1, stdout: '', stderr: (err && err.message) ? err.message : String(err) }
					};
				});
			}

			return xui.runSystemMenu('meshStatus').then(function(res) {
				var st = {};
				try {
					var raw = (res && res.stdout) ? res.stdout : (typeof res === 'string' ? res : JSON.stringify(res));
					st = JSON.parse(raw);
				} catch {
					st = { role: 'standalone', stp: false, hasWpadMesh: false, hasMeshIf: false, interfaces: [] };
				}
				return { routeId: 'network', panelId: 'network.mesh', meshStatus: st, outputText: '' };
			}).catch(function() {
				return {
					routeId: 'network',
					panelId: 'network.mesh',
					meshStatus: { role: 'standalone', stp: false, hasWpadMesh: false, hasMeshIf: false, interfaces: [] },
					outputText: ''
				};
			});
		}

		if (routeId === 'system') {
			panelId = reportPanelId(routeId, parts);
			if (panelId === 'system.resources') {
				node = findPanel(panelId);
				return Promise.all([
					xui.loadReport(node).catch(function(err) {
						return { code: 1, stdout: '', stderr: (err && err.message) ? err.message : String(err) };
					}),
					xui.systemInfo ? xui.systemInfo() : Promise.resolve(null),
					xui.systemBoard ? xui.systemBoard() : Promise.resolve(null)
				]).then(function(parts) {
					return {
						routeId: 'system',
						panelId: 'system.resources',
						execResult: parts[0],
						sysInfo: parts[1],
						boardInfo: parts[2]
					};
				});
			}
			if (panelId === 'system.toolbox') {
				return xui.runSystemMenu('autoUpdateStatus').then(function(res) {
					return {
						routeId: 'system',
						panelId: 'system.toolbox',
						execResult: res
					};
				}).catch(function(err) {
					return {
						routeId: 'system',
						panelId: 'system.toolbox',
						execResult: { code: 1, stdout: '', stderr: (err && err.message) ? err.message : String(err) }
					};
				});
			}
			if (panelId === 'system.maintenance') {
				return xui.runSystemMenu('maintenanceStatus').then(function(res) {
					return {
						routeId: 'system',
						panelId: 'system.maintenance',
						execResult: res
					};
				}).catch(function(err) {
					return {
						routeId: 'system',
						panelId: 'system.maintenance',
						execResult: { code: 1, stdout: '', stderr: (err && err.message) ? err.message : String(err) }
					};
				});
			}
			if (panelId === 'system.hardware') {
				return xui.runSystemMenu('hardwareStatus').then(function(res) {
					return {
						routeId: 'system',
						panelId: 'system.hardware',
						execResult: res
					};
				}).catch(function(err) {
					return {
						routeId: 'system',
						panelId: 'system.hardware',
						execResult: { code: 1, stdout: '', stderr: (err && err.message) ? err.message : String(err) }
					};
				});
			}
			if (panelId === 'mgmt.status') {
				return xui.runSystemMenu('mgmtStatus').then(function(res) {
					return {
						routeId: 'system',
						panelId: 'mgmt.status',
						execResult: res
					};
				}).catch(function(err) {
					return {
						routeId: 'system',
						panelId: 'mgmt.status',
						execResult: { code: 1, stdout: '', stderr: (err && err.message) ? err.message : String(err) }
					};
				});
			}
			node = findPanel(panelId);
			if (node && node.type === 'menu') {
				if (!node.statusReport)
					return Promise.resolve({ panelId: panelId, menuStatus: null, outputText: '' });
				return xui.loadNamedReport(node.statusReport).then(function(res) {
					return { panelId: panelId, menuStatus: res, outputText: '' };
				}).catch(function(err) {
					return {
						panelId: panelId,
						menuStatus: {
							code: 1,
							stdout: '',
							stderr: (err && err.message) ? err.message : String(err)
						},
						outputText: ''
					};
				});
			}
			return xui.loadReport(node).then(function(res) {
				return { execResult: res, panelId: panelId };
			}).catch(function(err) {
				return {
					panelId: panelId,
					execResult: {
						code: 1,
						stdout: '',
						stderr: (err && err.message) ? err.message : String(err)
					}
				};
			});
		}

		if (routeId === 'diagnostics') {
			panelId = reportPanelId(routeId, parts);
			node = findPanel(panelId);
			if (node && node.type === 'uplink') {
				return xui.loadUplinkConfig().then(function(cfg) {
					return { panelId: panelId, uplinkConfig: cfg, outputText: '' };
				}).catch(function(err) {
					return {
						panelId: panelId,
						uplinkConfig: {
							code: 1,
							stderr: (err && err.message) ? err.message : String(err),
							settings: {},
							runtime: {}
						},
						outputText: ''
					};
				});
			}
			if (node && node.type === 'menu') {
				if (!node.statusReport)
					return Promise.resolve({ panelId: panelId, menuStatus: null, outputText: '' });
				return xui.loadNamedReport(node.statusReport).then(function(res) {
					return { panelId: panelId, menuStatus: res, outputText: '' };
				}).catch(function(err) {
					return {
						panelId: panelId,
						menuStatus: {
							code: 1,
							stdout: '',
							stderr: (err && err.message) ? err.message : String(err)
						},
						outputText: ''
					};
				});
			}
			if (node && node.lazy) {
				if (node.reportLast) {
					return xui.loadNamedReport(node.reportLast).then(function(res) {
						return { execResult: res, panelId: panelId };
					}).catch(function(err) {
						return {
							panelId: panelId,
							execResult: {
								code: 0,
								stdout: _('Нажмите «Обновить», чтобы запустить проверку.'),
								stderr: (err && err.message) ? err.message : ''
							}
						};
					});
				}
				return Promise.resolve({
					panelId: panelId,
					execResult: {
						code: 0,
						stdout: _('Нажмите «Обновить», чтобы запустить проверку.'),
						stderr: ''
					}
				});
			}
			return xui.loadReport(node).then(function(res) {
				return { execResult: res, panelId: panelId };
			}).catch(function(err) {
				return {
					panelId: panelId,
					execResult: {
						code: 1,
						stdout: '',
						stderr: (err && err.message) ? err.message : String(err)
					}
				};
			});
		}

		if (routeId === 'profiles') {
			panelId = parts.panel || 'templates.sync';
			node = findPanel(panelId) || findPanel('templates.sync');
			return xui.loadInvoke(node, view).then(function(invoke) {
				return { invoke: invoke, panelId: node.id };
			}).catch(function(err) {
				return {
					panelId: node.id,
					invoke: {
						catalog: { templates: [], profiles: [] },
						status: {
							code: 1,
							running: 0,
							stderr: (err && err.message) ? err.message : String(err)
						},
						values: {}
					}
				};
			});
		}

		if (routeId === 'routing') {
			tab = parts.tab || 'general';
			panelId = parts.panel || view.routingPanelId(tab);
			node = findPanel(panelId);
			if (node && node.type === 'menu') {
				return Promise.resolve({
					panelId: panelId,
					tab: tab,
					panel: panelId,
					menuStatus: null,
					outputText: ''
				});
			}
			return xui.loadRoutingHub(view, xui.parseRoutingSelection(parts)).then(function(hub) {
				var sel = hub.sel || { view: 'general' };

				return {
					routing: hub,
					panelId: panelId,
					tab: tab || sel.tab || 'general',
					panel: sel.scope || parts.panel || ''
				};
			}).catch(function(err) {
				return {
					panelId: panelId,
					tab: tab || 'general',
					panel: parts.panel || '',
					routing: {
						columns: [],
						modelsByKey: {},
						sel: { view: 'general' },
						error: (err && err.message) ? err.message : String(err)
					}
				};
			});
		}

		if (routeId === 'vpn') {
			panelId = vpnPanelId(parts);
			node = findPanel(panelId) || findPanel('vpn.hub');
			if (node && node.type === 'vpn') {
				var activeVpnTab = (panelId === 'vpn.server' ? 'server' : (panelId === 'vpn.protocols' ? 'protocols' : (panelId === 'vpn.generators' ? 'generators' : (panelId === 'vpn.selfroute' ? 'selfroute' : (panelId === 'vpn.pbrbypass' ? 'pbrbypass' : (panelId === 'vpn.devicepolicy' ? 'devicepolicy' : ((node && node.tab) || 'tunnels')))))));
				if (panelId === 'vpn.devicepolicy' || activeVpnTab === 'devicepolicy') {
					return Promise.all([
						xui.runIfaceMenu('devicePolicyList').catch(function() { return ''; }),
						xui.runIfaceMenu('devicePolicyLeases').catch(function() { return ''; })
					]).then(function(results) {
						return {
							panelId: panelId,
							tab: 'devicepolicy',
							devices: xui.parseDevicePolicyList(results[0]),
							leases: xui.parseDevicePolicyLeases(results[1]),
							outputText: ''
						};
					}).catch(function() {
						return {
							panelId: panelId,
							tab: 'devicepolicy',
							devices: [],
							leases: [],
							outputText: ''
						};
					});
				}
				return Promise.all([
					xui.runIfaceMenu('summary').catch(function() { return null; }),
					xui.runAwgMenu('status').catch(function() { return null; }),
					xui.runIfaceMenu('protocolsStatus').catch(function() { return null; })
				]).then(function(results) {
					return {
						panelId: panelId,
						tab: activeVpnTab,
						vpnSummary: xui.parseIfaceSummary(results[0]),
						awgSummary: xui.parseAwgStatus(results[1]),
						protocolsStatus: xui.parseProtocolsStatus(results[2]),
						outputText: ''
					};
				}).catch(function() {
					return {
						panelId: panelId,
						tab: activeVpnTab,
						vpnSummary: { ifaces: [], warp: {}, proton: {}, count: 0 },
						awgSummary: { installed: false, running: false, peers: [], endpointChoices: [] },
						protocolsStatus: { awg: 'Не установлен', openvpn: 'Не установлен', vless: 'Не установлен', freeturn: 'Не установлен', freeturn_server: 'Не установлен' },
						outputText: ''
					};
				});
			}
			if (node && node.type === 'menu') {
				if (panelId === 'vpn.warp') {
					return xui.runIfaceMenu('warpStatus').then(function(res) {
						return {
							panelId: panelId,
							menuStatus: res,
							outputText: ''
						};
					}).catch(function() {
						return { panelId: panelId, menuStatus: null, outputText: '' };
					});
				}
				if (panelId === 'vpn.proton') {
					return xui.runIfaceMenu('protonStatus').then(function(res) {
						return {
							panelId: panelId,
							menuStatus: res,
							outputText: ''
						};
					}).catch(function() {
						return { panelId: panelId, menuStatus: null, outputText: '' };
					});
				}
			}
			return Promise.resolve({
				panelId: panelId,
				menuStatus: null,
				outputText: ''
			});
		}

		if (routeId === 'zapret') {
			panelId = 'zapret.hub';
			return xui.runZapretMenu('status').then(function(res) {
				return {
					panelId: panelId,
					zapretStatus: xui.parseZapretStatus(res),
					outputText: ''
				};
			}).catch(function() {
				return {
					panelId: panelId,
					zapretStatus: {
						running: false,
						installed: false,
						version: '',
						engine: 'zapret',
						pending: false,
						sections: []
					},
					outputText: ''
				};
			});
		}

		if (routeId === 'telemt') {
			panelId = 'telemt.hub';
			return xui.runTelemtMenu('status').then(function(res) {
				return {
					panelId: panelId,
					telemtStatus: xui.parseTelemtStatus(res),
					outputText: ''
				};
			}).catch(function() {
				return {
					panelId: panelId,
					telemtStatus: {
						running: false,
						installed: false,
						coreInstalled: false,
						luciInstalled: false,
						port: '1443',
						secret: '',
						secretMasked: '',
						tgLink: ''
					},
					outputText: ''
				};
			});
		}

		if (routeId === 'overview') {
			return Promise.all([
				xui.loadReport(findPanel('system.resources')).catch(function() {
					return null;
				}),
				xui.trafficPath('summary').catch(function() {
					return null;
				}),
				xui.loadNamedReport('system.toolbox').catch(function() {
					return null;
				}),
				xui.runIfaceMenu('summary').catch(function() {
					return null;
				})
			]).then(function(parts) {
				return {
					overviewReport: parts[0],
					trafficSummary: parts[1],
					toolboxStatus: parts[2],
					vpnSummary: xui.parseIfaceSummary(parts[3])
				};
			});
		}

		return Promise.resolve({});
	},

	findMainEl: function() {
		return document.querySelector('#xfree-toolbox-shell [data-xfree-main]');
	},

	navKey: function(route, tab, panel) {
		return [ route || '', tab || '', panel || '' ].join('\0');
	},

	pushNavHistory: function(nextRoute, nextTab, nextPanel) {
		var curRoute = this._xfreeActiveRoute || '';
		var curTab = this._xfreeActiveTab || '';
		var curPanel = this._xfreeActivePanel || '';

		if (!this._xfreeNavStack)
			this._xfreeNavStack = [];

		if (!curRoute)
			return;

		if (this.navKey(curRoute, curTab, curPanel) === this.navKey(nextRoute, nextTab, nextPanel))
			return;

		this._xfreeNavStack.push({
			route: curRoute,
			tab: curTab,
			panel: curPanel
		});

		if (this._xfreeNavStack.length > 24)
			this._xfreeNavStack.shift();
	},

	canNavigateBack: function() {
		if (this._xfreeNavStack && this._xfreeNavStack.length)
			return true;
		return !!(this._xfreeActiveRoute && this._xfreeActiveRoute !== DEFAULT_ROUTE);
	},

	navigateBack: function() {
		var prev;

		if (this._xfreeNavStack && this._xfreeNavStack.length) {
			prev = this._xfreeNavStack.pop();
			this.navigate(prev.route, prev.tab, prev.panel, { replace: true, skipHistory: true });
			return;
		}

		this.navigate(DEFAULT_ROUTE, '', '', { replace: true, skipHistory: true });
	},

	bindHistoryPop: function() {
		var view = this;

		if (view._xfreePopBound)
			return;

		view._xfreePopBound = true;
		window.addEventListener('popstate', function(ev) {
			var st = ev.state;
			var parts;

			if (st && st.xfree) {
				view.navigate(st.route || DEFAULT_ROUTE, st.tab || '', st.panel || '', {
					replace: true,
					skipHistory: true
				});
				return;
			}

			parts = hashParts();
			view.navigate(parts.route || DEFAULT_ROUTE, parts.tab || '', parts.panel || '', {
				replace: true,
				skipHistory: true
			});
		});
	},

	fetchRouteData: function(route, tab, panel) {
		var view = this;
		var cacheKey = view.navKey(route, tab || '', panel || '');

		return view.preloadRoute(route, { tab: tab || '', panel: panel || '' }).then(function(data) {
			data.routeId = route;
			data.tab = tab || data.tab || '';
			data.panel = panel || data.panelId || '';
			data.loading = false;

			view._setCache(cacheKey, data);
			if (data.toolboxStatus)
				view.updateRailBrand(view.parseToolboxStatus(data.toolboxStatus));

			if (view._xfreeActiveRoute === route &&
			    view._xfreeActiveTab === (tab || '') &&
			    view._xfreeActivePanel === (panel || '')) {
				view.mountRoute(data);
			}
			return data;
		}).catch(function(err) {
			console.error('XFree preloadRoute error:', err);
		});
	},

	navigate: function(routeId, tab, panel, opts) {
		var view = this;
		var route = findRoute(routeId) ? routeId : DEFAULT_ROUTE;
		var cacheKey = view.navKey(route, tab || '', panel || '');
		var cached = view._getCache(cacheKey);

		opts = opts || {};

		if (!opts.skipHistory)
			view.pushNavHistory(route, tab || '', panel || '');

		view._xfreeActiveRoute = route;
		view._xfreeActiveTab = tab || '';
		view._xfreeActivePanel = panel || '';

		view.applyWizardScopeFromParts(route, { tab: tab || '', panel: panel || '' });

		setHash(route, tab, panel, !opts.replace);
		view.updateRail(route, tab, panel);

		view.stopReportPoll();
		view.stopAsyncReportPoll();
		view.stopInvokePoll();
		view.stopVpnTaskPoll();
		view.stopTelemtPoll();

		if (cached) {
			cached.routeId = route;
			cached.tab = tab || cached.tab || '';
			cached.panel = panel || cached.panelId || '';
			cached.loading = false;
			view.mountRoute(cached);
		} else {
			view.mountRoute({
				routeId: route,
				tab: tab || '',
				panel: panel || '',
				loading: true
			});
		}

		view.fetchRouteData(route, tab, panel);
	},

	updateRail: function(routeId, tab, panel) {
		var nav = document.querySelector('#xfree-toolbox-shell xfree-nav');

		if (nav && nav.setActive)
			nav.setActive(routeId, tab, panel);
	},

	parseToolboxStatus: function(execResult) {
		var text = xui.formatExecReport(execResult || {});
		var ver = '';
		var upd = '';
		var missingBase = '';
		var available = '';
		var state = 'unknown';
		var lines = String(text || '').split(/\n/);
		var i;
		var line;
		var m;
		var comp;

		for (i = 0; i < lines.length; i++) {
			line = lines[i].trim();
			m = line.match(/^TOOLBOX_VERSION=(.*)$/);
			if (m) { ver = m[1]; continue; }
			m = line.match(/^TOOLBOX_UPDATE=(.*)$/);
			if (m) { state = m[1] || 'unknown'; continue; }
			m = line.match(/^TOOLBOX_UPDATE_LABEL=(.*)$/);
			if (m) { upd = m[1]; continue; }
			m = line.match(/^TOOLBOX_AVAILABLE=(.*)$/);
			if (m) { available = (m[1] || '').trim(); continue; }
			m = line.match(/^TOOLBOX_MISSING_BASE_PACKAGES=(.*)$/);
			if (m) { missingBase = (m[1] || '').trim(); continue; }
			m = line.match(/^Версия:\s*(.+)$/i);
			if (m && !ver) { ver = m[1].trim(); continue; }
			m = line.match(/^Обновления:\s*(.+)$/i);
			if (m && !upd) { upd = m[1].trim(); continue; }
			m = line.match(/^Available:\s*(.+)$/i);
			if (m && !available) { available = m[1].trim(); continue; }
		}

		/* Тот же normalizeUpdateComponent, что на вкладке «Обновления». */
		comp = {
			version: ver,
			update: state,
			updateLabel: upd,
			availablePkg: available
		};
		if (systemUpdatesPanel && typeof systemUpdatesPanel.normalizeUpdateComponent === 'function')
			systemUpdatesPanel.normalizeUpdateComponent(comp);

		return {
			version: comp.version || '',
			update: comp.update || 'unknown',
			label: comp.updateLabel || '',
			missingBase: missingBase
		};
	},

	updateRailBrand: function(brand) {
		var nav = document.querySelector('#xfree-toolbox-shell xfree-nav');

		if (nav && nav.setBrand)
			nav.setBrand(brand || {});
	},

	triggerInstallBasePackages: function() {
		var view = this;
		var pkgs = view._missingBasePackages || '';

		return xui.runActionWithOutputDialog({
			title: _('Установка базовых пакетов xfree-toolbox'),
			confirm: pkgs
				? _('Установить недостающие базовые пакеты системы (%s)?').format(pkgs)
				: _('Запустить установку базовых пакетов xfree-toolbox?'),
			menu: 'systemMenu',
			run: function() {
				return xui.runSystemMenu('installBase');
			},
			onSuccess: function() {
				view._missingBasePackages = '';
				var banner = document.querySelector('.xfree-missing-base-banner');
				if (banner)
					banner.remove();
				view.refreshRailToolbox();
			}
		});
	},

	updateMissingBaseBanner: function(mainEl) {
		var view = this;
		mainEl = mainEl || view.findMainEl();
		if (!mainEl)
			return;

		var existing = mainEl.querySelector('.xfree-missing-base-banner');
		if (!view._missingBasePackages) {
			if (existing)
				existing.remove();
			return;
		}

		if (existing)
			return;

		var banner = E('div', {
			'class': 'alert-message warning xfree-missing-base-banner',
			'style': 'margin: 0.75rem 1rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; border-left: 4px solid #f0ad4e;'
		}, [
			E('div', {}, [
				E('strong', {}, [ _('Внимание: не установлены базовые пакеты xfree-toolbox: ') ]),
				E('code', {}, [ view._missingBasePackages ]),
				E('div', { 'class': 'muted', 'style': 'font-size: 0.9em; margin-top: 0.25rem;' }, [
					_('Для полноценной работы всех функций toolbox и LuCI требуется доустановка пакетов.')
				])
			]),
			E('button', {
				'class': 'cbi-button cbi-button-action important',
				'style': 'white-space: nowrap;',
				'click': ui.createHandlerFn(view, function() {
					view.triggerInstallBasePackages();
				})
			}, [ _('Установить базовые пакеты') ])
		]);

		mainEl.insertBefore(banner, mainEl.firstChild);
	},

	promptMissingBasePackagesModal: function() {
		var view = this;
		var pkgs = view._missingBasePackages || '';
		if (!pkgs)
			return;

		ui.showModal(_('Не установлены базовые пакеты'), [
			E('p', {}, [
				_('В системе не установлены обязательные базовые пакеты xfree-toolbox:')
			]),
			E('pre', {
				'class': 'cbi-input-textarea',
				'style': 'padding: 0.5rem; background: rgba(0,0,0,0.05); font-weight: bold; white-space: pre-wrap;'
			}, [ pkgs ]),
			E('p', { 'class': 'muted' }, [
				_('Для их загрузки и установки требуется доступ в интернет. Если роутер ещё не подключен к сети (например, при локальном деплое), вы можете настроить интернет и запустить установку позже — плашка останется вверху страницы.')
			]),
			E('div', { 'class': 'right', 'style': 'margin-top: 1rem; display: flex; justify-content: flex-end; gap: 0.5rem;' }, [
				E('button', {
					'class': 'cbi-button cbi-button-neutral',
					'click': function() {
						ui.hideModal();
					}
				}, [ _('Позже') ]),
				E('button', {
					'class': 'cbi-button cbi-button-action important',
					'click': function() {
						ui.hideModal();
						view.triggerInstallBasePackages();
					}
				}, [ _('Установить сейчас') ])
			])
		]);
	},

	promptMeshSatelliteModal: function(root) {
		var inputGw = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': '192.168.1.1',
			'value': '192.168.1.1'
		});
		var inputLanIp = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': '192.168.1.2',
			'value': '192.168.1.2'
		});
		var inputSsid = E('input', {
			'type': 'text',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': 'MyNetwork',
			'value': ''
		});
		var inputKey = E('input', {
			'type': 'password',
			'class': 'cbi-input-text',
			'style': 'width: 100%;',
			'placeholder': 'Пароль сети Wi-Fi',
			'value': ''
		});

		ui.showModal(_('Настройка Mesh Satellite'), [
			E('p', {}, [
				_('Подключение этого роутера в качестве сателлита (Mesh Satellite). WAN-порт объединяется с LAN в единый мост, DHCP/NAT отключаются, настраивается 802.11s backhaul и бесшовный роуминг.')
			]),
			E('div', { 'class': 'cbi-value', 'style': 'margin-bottom: 0.5rem;' }, [
				E('label', { 'class': 'cbi-value-title', 'style': 'display: block; margin-bottom: 0.2rem; font-weight: bold;' }, [ _('IP-адрес Master (шлюз и DNS):') ]),
				E('div', { 'class': 'cbi-value-field' }, [ inputGw ])
			]),
			E('div', { 'class': 'cbi-value', 'style': 'margin-bottom: 0.5rem;' }, [
				E('label', { 'class': 'cbi-value-title', 'style': 'display: block; margin-bottom: 0.2rem; font-weight: bold;' }, [ _('Статический LAN IP сателлита:') ]),
				E('div', { 'class': 'cbi-value-field' }, [ inputLanIp ])
			]),
			E('div', { 'class': 'cbi-value', 'style': 'margin-bottom: 0.5rem;' }, [
				E('label', { 'class': 'cbi-value-title', 'style': 'display: block; margin-bottom: 0.2rem; font-weight: bold;' }, [ _('Имя Wi-Fi (SSID как на Master):') ]),
				E('div', { 'class': 'cbi-value-field' }, [ inputSsid ])
			]),
			E('div', { 'class': 'cbi-value', 'style': 'margin-bottom: 0.5rem;' }, [
				E('label', { 'class': 'cbi-value-title', 'style': 'display: block; margin-bottom: 0.2rem; font-weight: bold;' }, [ _('Пароль Wi-Fi (как на Master):') ]),
				E('div', { 'class': 'cbi-value-field' }, [ inputKey ])
			]),
			E('div', { 'class': 'right', 'style': 'margin-top: 1rem; display: flex; justify-content: flex-end; gap: 0.5rem;' }, [
				E('button', {
					'class': 'cbi-button cbi-button-neutral',
					'click': function() {
						ui.hideModal();
					}
				}, [ _('Отмена') ]),
				E('button', {
					'class': 'cbi-button cbi-button-action important',
					'click': function() {
						var gw = (inputGw.value || '').trim();
						var lanIp = (inputLanIp.value || '').trim();
						var ssid = (inputSsid.value || '').trim();
						var key = (inputKey.value || '').trim();

						if (!gw || !lanIp || !ssid || !key) {
							ui.addNotification(null, E('p', {}, [ _('Все поля обязательны для заполнения') ]), 'warning');
							return;
						}

						ui.hideModal();
						var argStr = gw + ' ' + lanIp + ' ' + ssid + ' ' + key;
						xui.runActionWithOutputDialog({
							title: _('Настройка Mesh Satellite'),
							root: root,
							menu: 'systemMenu',
							run: function() {
								return xui.runSystemMenu('configureMeshSatellite', argStr);
							}
						});
					}
				}, [ _('Применить и настроить') ])
			])
		]);
	},

	refreshRailToolbox: function() {
		var view = this;

		return xui.loadNamedReport('system.toolbox').then(function(res) {
			var parsed = view.parseToolboxStatus(res);
			view.updateRailBrand(parsed);
			view._missingBasePackages = parsed.missingBase || '';
			view.updateMissingBaseBanner();
			if (view._missingBasePackages && !view._missingBasePromptShown) {
				view._missingBasePromptShown = true;
				view.promptMissingBasePackagesModal();
			}
			return res;
		}).catch(function() {
			view.updateRailBrand({ version: '', update: 'unknown', label: '' });
			return null;
		});
	},

	afterMountRoute: function(data, main) {
		var view = this;
		var routeId = (data && data.routeId) || DEFAULT_ROUTE;
		var node;
		var panelId;
		var pollSec;

		if (!main || (data && data.loading))
			return;

		view.updateRail(routeId, data && data.tab, data && (data.panel || data.panelId));

		requestAnimationFrame(function() {
			view.updateMissingBaseBanner(main);
			if (data && data.invoke && main) {
				node = findPanel(data.panelId || data.panel);
				if (node)
					view.maybeStartInvokePoll(node, main, data.invoke.status);
			}

			if (routeId === 'system' && main) {
				panelId = reportPanelId(routeId, {
					panel: data && (data.panelId || data.panel),
					tab: data && data.tab
				});
				node = findPanel(panelId);
				pollSec = view.reportPollInterval(node);
				if (panelId === 'system.resources') {
					if (pollSec > 0) {
						view.stopReportPoll();
						view._xfreeReportNode = node;
						view._xfreeReportMain = main;
						view._xfreeReportPoll = L.bind(function() {
							view.reloadResourcesInPlace(main);
						}, view);
						poll.add(view._xfreeReportPoll, pollSec);
					}
				} else if (node && pollSec > 0) {
					view.stopReportPoll();
					view._xfreeReportNode = node;
					view._xfreeReportMain = main;
					view._xfreeReportPoll = L.bind(function() {
						view.reloadReportInPlace(node, main);
					}, view);
					poll.add(view._xfreeReportPoll, pollSec);
				}
			}

			if (routeId === 'diagnostics' && main) {
				panelId = reportPanelId(routeId, {
					panel: data && (data.panelId || data.panel),
					tab: data && data.tab
				});
				node = findPanel(panelId);
				if (node && node.type === 'uplink') {
					pollSec = view.reportPollInterval(node);
					if (pollSec > 0) {
						view.stopReportPoll();
						view._xfreeReportNode = node;
						view._xfreeReportMain = main;
						view._xfreeReportPoll = L.bind(function() {
							view.reloadUplinkConfigInPlace(main);
						}, view);
						poll.add(view._xfreeReportPoll, pollSec);
					}
				} else if (node && node.type === 'menu' && node.statusReport) {
					pollSec = view.reportPollInterval(node);
					if (pollSec > 0) {
						view.stopReportPoll();
						view._xfreeReportNode = node;
						view._xfreeReportMain = main;
						view._xfreeReportPoll = L.bind(function() {
							view.reloadMenuStatusInPlace(node, main);
						}, view);
						poll.add(view._xfreeReportPoll, pollSec);
					}
				} else if (node && node.type === 'report') {
					pollSec = view.reportPollInterval(node);
					if (pollSec > 0) {
						view.stopReportPoll();
						view._xfreeReportNode = node;
						view._xfreeReportMain = main;
						view._xfreeReportPoll = L.bind(function() {
							view.reloadReportInPlace(node, main);
						}, view);
						poll.add(view._xfreeReportPoll, pollSec);
					}
				}
			}

			if (routeId === 'routing' && main) {
				var root = main.querySelector('[data-xfree-wizard], [data-xfree-routing]');
				if (root)
					xui.layoutWizardPaneHeights(root);
			}

			if (routeId === 'telemt' && main) {
				view.maybeStartTelemtPoll(main);
			}
		});
	},

	mountRoute: function(data) {
		var view = this;
		var main = view.findMainEl();

		if (!main)
			return;

		dom.content(main, view.renderRoute(data, main));
		view.afterMountRoute(data, main);
	},

	render: function(data) {
		var view = this;
		var routeId = (data && data.routeId) || DEFAULT_ROUTE;
		var nav;

		ensureStylesheets();
		view.bindHistoryPop();
		view._xfreeActiveRoute = routeId;
		view._xfreeActiveTab = (data && data.tab) || '';
		view._xfreeActivePanel = (data && data.panel) || '';
		if (!view._xfreeNavStack)
			view._xfreeNavStack = [];

		nav = E('xfree-nav');
		nav.mount({
			routes: routesData.routes || [],
			panels: routesData.panels || {},
			activeId: routeId,
			activeTab: (data && data.tab) || '',
			activePanel: (data && (data.panel || data.panelId)) || '',
			view: view,
			brand: { version: '', update: 'unknown', label: '' },
			isExpert: (xui && xui.menuExpertMode) ? xui.menuExpertMode() : false,
			onToggleExpert: function() {
				if (xui && xui.setMenuExpertMode)
					xui.setMenuExpertMode(!xui.menuExpertMode());
				window.location.reload();
			},
			onNavigate: function(route, tab, panel) {
				view.navigate(route, tab, panel);
			},
			onSelect: function(id) {
				view.navigate(id);
			}
		});
		view.refreshRailToolbox();

		if (data && data.loading) {
			requestAnimationFrame(function() {
				view.fetchRouteData(routeId, data.tab, data.panel);
			});
		} else {
			requestAnimationFrame(function() {
				var main = view.findMainEl();
				if (main)
					view.afterMountRoute(data, main);
			});
		}

		return E('div', {
			'class': 'xfree-web',
			'id': 'xfree-toolbox-shell'
		}, [
			nav,
			E('div', { 'class': 'shell xfree-main', 'data-xfree-main': '1' }, [
				view.renderRoute(data || { routeId: routeId, loading: true }, null)
			])
		]);
	},

	renderRoute: function(data, mainEl) {
		var routeId = (data && data.routeId) || DEFAULT_ROUTE;

		if (routeId === 'overview')
			return this.renderOverview(data);
		if (routeId === 'profiles')
			return this.renderProfiles(data, mainEl);
		if (routeId === 'routing')
			return this.renderRouting(data, mainEl);
		if (routeId === 'vpn')
			return this.renderVpn(data, mainEl);
		if (routeId === 'zapret')
			return this.renderZapret(data, mainEl);
		if (routeId === 'telemt')
			return this.renderTelemt(data, mainEl);
		if (routeId === 'network' || routeId === 'mesh')
			return this.renderNetwork(data, mainEl);
		if (routeId === 'system')
			return this.renderSystem(data, mainEl);
		if (routeId === 'diagnostics')
			return this.renderDiagnostics(data, mainEl);

		return E('div', { 'class': 'empty' }, [
			E('h3', {}, [ _('Экран не найден') ]),
			E('p', {}, [ routeId ])
		]);
	},

	overviewStatsFromReport: function(execResult) {
		var text = xui.formatExecReport(execResult || {});
		var lines = String(text || '').split(/\n/);
		var host = '';
		var temp = '';
		var disk = '';
		var load = '';
		var i;
		var line;
		var m;
		var clip = function(s, n) {
			s = String(s || '');
			return s.length > n ? s.slice(0, n - 1) + '…' : s;
		};

		for (i = 0; i < lines.length; i++) {
			line = lines[i].replace(/\s+/g, ' ').trim();
			if (!line || /^[=─\-_]{3,}$/.test(line) || /^exit\b/i.test(line))
				continue;
			if (/^(состояние|status|device|температур|диск|обновить)/i.test(line) && !/[:：]/.test(line))
				continue;

			m = line.match(/^(?:host|hostname|хост)\s*[:=]\s*(.+)$/i);
			if (m) { host = m[1].trim(); continue; }

			m = line.match(/\bload average:\s*([\d.]+)/i);
			if (m && !load) { load = m[1]; continue; }

			m = line.match(/^(?:load|нагрузк\S*)\s*[:=]\s*(.+)$/i);
			if (m && !load) { load = m[1].trim(); continue; }

			/* First sensor line: "● 71.2 °C cpu-thermal норма" */
			m = line.match(/(?:^|[●▲!?\s])(\d+(?:\.\d+)?)\s*°\s*C\b/i);
			if (m && !temp && /thermal|норма|тепло|критич|°/i.test(line)) {
				temp = m[1] + ' °C';
				continue;
			}

			/* Prefer rootfs/overlay usage: "/overlay 81% […]" (%% from show-host-resources) */
			m = line.match(/^(\/overlay|\/)\s+(\d+%)(?:\s|$|\[)/);
			if (m && !disk) {
				disk = (m[1] === '/' ? 'root ' : 'overlay ') + m[2];
				continue;
			}
			m = line.match(/^(?:disk|root|диск|storage)\s*[:=]\s*(.+)$/i);
			if (m && !disk) { disk = m[1].trim(); continue; }

			m = line.match(/\bHost\s*:\s*(\S+)/i);
			if (m && !host) host = m[1];
		}

		return [
			{ k: _('Хост'), v: host ? clip(host, 28) : '—' },
			{ k: _('Темп.'), v: temp ? clip(temp, 24) : '—' },
			{ k: _('Диск'), v: disk ? clip(disk, 24) : '—' },
			{ k: _('Load'), v: load ? clip(load, 24) : '—' }
		];
	},

	overviewStatsFromToolbox: function(execResult) {
		var parsed = this.parseToolboxStatus(execResult);
		var clip = function(s, n) {
			s = String(s || '');
			return s.length > n ? s.slice(0, n - 1) + '…' : s;
		};

		return [
			{ k: _('Версия'), v: parsed.version ? clip(parsed.version, 20) : '—' },
			{ k: _('Обновл.'), v: parsed.label ? clip(parsed.label, 22) : _('не проверено') }
		];
	},

	overviewStatsFromVpn: function(vpnSummary) {
		var count = (vpnSummary && vpnSummary.count) || 0;
		var ifaces = (vpnSummary && vpnSummary.ifaces) || [];
		var upCount = 0;
		var stateOk = (vpnSummary && vpnSummary.stateOk) || 0;
		var i;

		for (i = 0; i < ifaces.length; i++) {
			if (ifaces[i].ifaceUp)
				upCount++;
		}

		var emText = '';
		if (count > 0) {
			if (upCount === count && stateOk === count)
				emText = _('все активны (%d/%d)').format(upCount, count);
			else
				emText = '%d/%d UP · %d state'.format(upCount, count, stateOk);
		} else {
			emText = _('не созданы');
		}

		return [
			{
				k: _('Туннели'),
				v: String(count),
				em: emText,
				route: 'vpn',
				tab: 'tunnels'
			}
		];
	},

	renderOverview: function(data) {
		var view = this;
		var el = E('xfree-overview');
		var stats = (data && !data.loading)
			? view.overviewStatsFromReport(data && data.overviewReport)
				.concat(view.overviewStatsFromVpn(data && data.vpnSummary))
				.concat(view.overviewStatsFromToolbox(data && data.toolboxStatus))
			: [];

		el.mount({
			view: view,
			cards: routesData.overviewCards || [],
			stats: stats,
			vpnSummary: data && data.vpnSummary,
			loading: !!(data && data.loading),
			trafficSummary: data && data.trafficSummary,
			onNavigate: function(route, tab, panel) {
				view.navigate(route, tab, panel);
			},
			onAction: function(action, arg, confirmText, onDone) {
				view.runVpnHubAction(action, arg, confirmText, view.findMainEl(), onDone);
			},
			onRefresh: function() {
				view.reloadOverview(view.findMainEl());
			},
			onTrace: function(fqdn) {
				return xui.trafficPath('trace', fqdn);
			},
			onSuggest: function(prefix) {
				/* Active FQDNs: one-shot load for datalist; free text still allowed. */
				return xui.trafficPath('suggest', prefix || '', 5000);
			}
		});

		return E('div', { 'class': 'xfree-page' }, [ el ]);
	},

	reloadOverview: function(mainEl) {
		var view = this;
		var root = (mainEl && mainEl.querySelector('xfree-overview')) ||
			document.querySelector('xfree-overview');

		if (root && root.setLoading)
			root.setLoading(true);

		return Promise.all([
			xui.loadReport(findPanel('system.resources')).catch(function() { return null; }),
			xui.trafficPath('summary').catch(function() { return null; }),
			xui.loadNamedReport('system.toolbox').catch(function() { return null; }),
			xui.runIfaceMenu('summary').catch(function() { return null; })
		]).then(function(parts) {
			var data = {
				routeId: 'overview',
				overviewReport: parts[0],
				trafficSummary: parts[1],
				toolboxStatus: parts[2],
				vpnSummary: xui.parseIfaceSummary(parts[3])
			};
			var stats = view.overviewStatsFromReport(data.overviewReport)
				.concat(view.overviewStatsFromVpn(data.vpnSummary))
				.concat(view.overviewStatsFromToolbox(data.toolboxStatus));

			if (root && root.mount) {
				root.mount({
					view: view,
					cards: routesData.overviewCards || [],
					stats: stats,
					vpnSummary: data.vpnSummary,
					loading: false,
					trafficSummary: data.trafficSummary,
					onNavigate: function(route, tab, panel) {
						view.navigate(route, tab, panel);
					},
					onAction: function(action, arg, confirmText, onDone) {
						view.runVpnHubAction(action, arg, confirmText, view.findMainEl(), onDone);
					},
					onRefresh: function() {
						view.reloadOverview(view.findMainEl());
					},
					onTrace: function(fqdn) {
						return xui.trafficPath('trace', fqdn);
					},
					onSuggest: function(prefix) {
						return xui.trafficPath('suggest', prefix || '', 5000);
					}
				});
			} else {
				view.navigate('overview', '', '', { replace: true, skipHistory: true });
			}
		}).catch(function() {
			if (root && root.setLoading)
				root.setLoading(false);
		});
	},

	renderBackControl: function() {
		var view = this;

		if (!view.canNavigateBack())
			return '';

		return E('button', {
			'class': 'ghost ghost-compact xfree-back-btn',
			'type': 'button',
			'data-xfree-back': '1',
			'title': _('Назад'),
			'click': ui.createHandlerFn(view, function(ev) {
				ev.preventDefault();
				view.navigateBack();
			})
		}, [ '← ' + _('Назад') ]);
	},

	renderPageHead: function(title, descr) {
		/* Use div — LuCI bootstrap styles bare <header> as the dark top navbar. */
		var left = [
			E('p', { 'class': 'eyebrow' }, [ 'XFree toolbox' ]),
			E('h1', {}, [ title ])
		];
		var back = this.renderBackControl();

		if (back)
			left.unshift(back);

		return E('div', { 'class': 'page-head' }, [
			E('div', { 'class': 'page-head-main' }, left),
			descr ? E('p', { 'class': 'muted page-head-desc' }, [ descr ]) : ''
		]);
	},

	/* Top submenu for the active left-nav route (tabs from luci-routes.js). */
	renderSubnav: function(routeId, data) {
		var view = this;
		var route = findRoute(routeId);
		var tabs = (route && route.tabs) || [];
		if (tabs.length <= 1)
			return E('div', { 'style': 'display: none;' });

		var buttons = [];
		var activePanel = (data && (data.panelId || data.panel)) || '';
		var activeTab = (data && data.tab) || '';
		var i;
		var t;
		var panel;
		var isActive;

		for (i = 0; i < tabs.length; i++) {
			t = tabs[i];
			if (t.panel) {
				panel = findPanel(t.panel);
				if (!panel || !panelVisible(panel))
					continue;
			}

			if (t.panel)
				isActive = activePanel === t.panel || (!activePanel && i === 0 && !activeTab);
			else if (t.tab)
				isActive = activeTab === t.tab || (!activeTab && i === 0);
			else
				isActive = false;

			buttons.push(E('button', {
				'class': 'subnav-btn' + (isActive ? ' is-active' : ''),
				'type': 'button',
				'data-tab-id': t.id || '',
				'click': ui.createHandlerFn(view, (function(spec) {
					return function(ev) {
						ev.preventDefault();
						view.navigate(routeId, spec.tab || '', spec.panel || '');
					};
				})(t))
			}, [ t.title || t.id ]));
		}

		if (!buttons.length)
			return '';

		return E('nav', {
			'class': 'subnav',
			'aria-label': _('Подменю')
		}, buttons);
	},

	renderExpertToggle: function() {
		return '';
	},

	renderProfiles: function(data, mainEl) {
		var view = this;
		var panelId = (data && (data.panelId || data.panel)) || 'templates.sync';
		var node = findPanel(panelId);
		var invokeData;
		var panel;
		var nodes = [];

		if (!node || !panelVisible(node)) {
			node = findPanel('templates.sync');
			panelId = node ? node.id : panelId;
		}

		nodes.push(view.renderPageHead(_('Профили'), _('Шаблоны → профиль → apply')));
		nodes.push(view.renderSubnav('profiles', { panel: panelId }));

		if (!node) {
			nodes.push(E('div', { 'class': 'empty' }, [ E('p', {}, [ _('Панель не найдена') ]) ]));
			return E('div', { 'class': 'xfree-page' }, nodes);
		}

		invokeData = (data && data.invoke) ? data.invoke : {
			catalog: view._xfreeInvokeCatalog || { templates: [], profiles: [] },
			status: { running: 0, stdout: '', stderr: '' },
			values: view._xfreeInvokeValues || {}
		};

		panel = xui.invokePanel(node, view, invokeData);
		nodes.push(E('div', { 'class': 'panel-block', 'data-panel-id': panelId }, [ panel ]));

		if (mainEl)
			view.maybeStartInvokePoll(node, mainEl, invokeData.status);

		return E('div', { 'class': 'xfree-page' }, nodes);
	},

	renderRouting: function(data, mainEl) {
		var view = this;
		var tab = (data && data.tab) || 'general';
		var panelId = (data && (data.panelId || data.panel)) || view.routingPanelId(tab);
		var node = findPanel(panelId);

		var pageHead = view.renderPageHead(_('Маршруты'), _('Общее и отдельно: VPN, DNS, Zapret, Исключения, Источники'));
		var subnav = view.renderSubnav('routing', { tab: tab, panel: panelId });

		if (node && (node.id === 'upstreams.hub' || panelId === 'upstreams.hub' || tab === 'upstreams')) {
			var panel = xui.upstreamsPanel({
				node: node,
				view: view,
				xui: xui,
				mainEl: mainEl || view.findMainEl()
			});

			return E('div', { 'class': 'xfree-page' }, [
				pageHead,
				subnav,
				E('div', { 'class': 'panel-block' }, [ panel ])
			]);
		}

		if (node && node.type === 'menu') {
			var panel = xui.menuPanel({
				node: node,
				view: view,
				statusText: '',
				outputText: (data && data.outputText) || '',
				pollSec: 0,
				itemVisible: function(item) {
					return xui.menuItemVisible(item);
				},
				onItem: function(item) {
					view.handleSystemMenuItem(node, item, mainEl || view.findMainEl());
				}
			});

			return E('div', { 'class': 'xfree-page' }, [
				pageHead,
				subnav,
				E('div', { 'class': 'panel-block' }, [ panel ])
			]);
		}

		var hub = (data && data.routing) || {
			columns: [],
			modelsByKey: {},
			sel: { view: 'general' }
		};
		if (data && data.loading)
			hub.loading = true;
		var foot = _('После выбора сохраните списки и примените маршрутизацию кнопкой «Применить».');

		requestAnimationFrame(function() {
			var root = (mainEl || view.findMainEl() || document).querySelector('[data-xfree-wizard]');
			var sel = hub.sel || {};

			if (sel.view === 'scope' && sel.scope && root) {
				view._xfreeWizardActiveIface = sel.scope;
				xui.layoutWizardPaneHeights(root);
			}
		});

		return E('div', { 'class': 'xfree-page' }, [
			pageHead,
			subnav,
			xui.routingPanel({ xui: xui, view: view, hub: hub, activeTarget: tab }),
			E('p', { 'class': 'muted' }, [ foot ])
		]);
	},

	renderVpn: function(data, mainEl) {
		var view = this;
		var panelId = vpnPanelId({ panel: data && (data.panelId || data.panel), tab: data && data.tab });
		var node = findPanel(panelId) || findPanel('vpn.hub');
		var panel;
		var statusText;

		if (!node) {
			return E('div', { 'class': 'xfree-page' }, [
				view.renderPageHead(_('VPN'), _('VPN-туннели')),
				E('div', { 'class': 'empty' }, [ E('p', {}, [ _('Панель не найдена') ]) ])
			]);
		}

		if (node.type === 'vpn') {
			var activeVpnView = (panelId === 'vpn.server' ? 'server' : (panelId === 'vpn.protocols' ? 'protocols' : (panelId === 'vpn.generators' ? 'generators' : (panelId === 'vpn.selfroute' ? 'selfroute' : (panelId === 'vpn.pbrbypass' ? 'pbrbypass' : (panelId === 'vpn.devicepolicy' ? 'devicepolicy' : ((node && node.vpnView) || 'tunnels')))))));
			if (activeVpnView === 'devicepolicy') {
				panel = xui.devicePolicyPanel({
					view: view,
					loading: !!(data && data.loading),
					expert: xui.menuExpertMode(),
					devices: (data && data.devices) || [],
					leases: (data && data.leases) || [],
					outputText: (data && data.outputText) || '',
					onRefresh: function() {
						view.reloadVpnHub(mainEl || view.findMainEl());
					}
				});
			} else if (activeVpnView === 'server') {
				panel = xui.vpnServerPanel({
					view: view,
					loading: !!(data && data.loading),
					expert: xui.menuExpertMode(),
					awgSummary: (data && data.awgSummary) || {},
					outputText: (data && data.outputText) || '',
					onNavigate: function(routeOrPanel, tab, panel) {
						if (arguments.length > 1 || routeOrPanel === 'routing' || routeOrPanel === 'vpn')
							view.navigate(routeOrPanel, tab || '', panel || '');
						else
							view.navigate('vpn', '', routeOrPanel);
					},
					onRefresh: function() {
						view.reloadVpnHub(mainEl || view.findMainEl());
					},
					onAction: function(action, arg, confirmText, onDone) {
						view.runVpnHubAction(action, arg, confirmText, mainEl || view.findMainEl(), onDone);
					}
				});
			} else if (activeVpnView === 'protocols') {
				panel = xui.vpnProtocolsPanel({
					view: view,
					loading: !!(data && data.loading),
					protocolsStatus: (data && data.protocolsStatus) || {},
					onAction: function(action, arg, confirmText, onDone) {
						view.runVpnHubAction(action, arg, confirmText, mainEl || view.findMainEl(), onDone);
					}
				});
			} else {
				panel = xui.vpnPanel({
					view: view,
					loading: !!(data && data.loading),
					expert: xui.menuExpertMode(),
					vpnView: activeVpnView,
					summary: (data && data.vpnSummary) || { ifaces: [], warp: {}, proton: {}, count: 0 },
					awgSummary: (data && data.awgSummary) || {},
					protocolsStatus: (data && data.protocolsStatus) || {},
					outputText: (data && data.outputText) || '',
					onNavigate: function(routeOrPanel, tab, panel) {
						if (arguments.length > 1 || routeOrPanel === 'routing' || routeOrPanel === 'vpn')
							view.navigate(routeOrPanel, tab || '', panel || '');
						else
							view.navigate('vpn', '', routeOrPanel);
					},
					onRefresh: function() {
						view.reloadVpnHub(mainEl || view.findMainEl());
					},
					onAction: function(action, arg, confirmText, onDone) {
						view.runVpnHubAction(action, arg, confirmText, mainEl || view.findMainEl(), onDone);
					}
				});
			}

			var pageTitle = activeVpnView === 'server'
				? _('VPN-сервер')
				: (activeVpnView === 'protocols'
					? _('Компоненты VPN')
					: (activeVpnView === 'devicepolicy'
						? _('Исключения устройств')
						: _('VPN-туннели')));
			var pageHint = activeVpnView === 'server'
				? _('Управление VPN-сервером AmneziaWG (Ingress), пирами и клиентскими конфигами')
				: (activeVpnView === 'protocols'
					? _('Управление системными пакетами и протоколами VPN (AmneziaWG, OpenVPN, Sing-box, FreeTurn)')
					: (activeVpnView === 'devicepolicy'
						? _('Прямой выход выбранных клиентов (IP/MAC) в чистый WAN в обход VPN и Zapret')
						: _('Создание, apply, генераторы — как в CLI (xft → 7)')));

			var footerNote = activeVpnView === 'devicepolicy'
				? _('Правила исключений сохраняются в профиле (routing/devices.conf) и применяются в цепочки nftables.')
				: _('Списки сайтов для туннелей — в «Маршруты» (Общее или кнопка VPN).');

			return E('div', { 'class': 'xfree-page' }, [
				view.renderPageHead(pageTitle, pageHint),
				view.renderSubnav('vpn', { panel: panelId, tab: data && data.tab }),
				E('div', { 'class': 'panel-block' }, [ panel ]),
				E('p', { 'class': 'muted' }, [ footerNote ])
			]);
		}

		statusText = '';
		if (data && data.menuStatus)
			statusText = xui.formatExecReport(data.menuStatus);

		panel = xui.menuPanel({
			node: node,
			view: view,
			statusText: statusText,
			outputText: (data && data.outputText) || '',
			pollSec: 0,
			itemVisible: function(item) {
				return xui.menuItemVisible(item);
			},
			onItem: function(item) {
				view.handleIfaceMenuItem(node, item, mainEl || view.findMainEl());
			}
		});

		return E('div', { 'class': 'xfree-page' }, [
			view.renderPageHead(node.title || _('VPN'), node.hint || ''),
			E('div', { 'class': 'panel-block' }, [ panel ])
		]);
	},

	reloadVpnHub: function(mainEl) {
		var root = mainEl && (
			mainEl.querySelector('[data-xfree-vpn]') ||
			mainEl.querySelector('xfree-vpn-devicepolicy') ||
			mainEl.querySelector('xfree-vpn-server') ||
			mainEl.querySelector('xfree-vpn-protocols')
		);

		if (!root)
			return Promise.resolve();

		if (typeof root.reload === 'function')
			return root.reload();

		if (root.setLoading)
			root.setLoading(true);
		else
			root.setBusy(true);

		return Promise.all([
			xui.runIfaceMenu('summary').catch(function() { return null; }),
			xui.runAwgMenu('status').catch(function() { return null; }),
			xui.runIfaceMenu('protocolsStatus').catch(function() { return null; }),
			xui.runIfaceMenu('devicePolicyList').catch(function() { return null; })
		]).then(function(results) {
			if (results[0])
				root.setSummary(xui.parseIfaceSummary(results[0]));
			if (results[1] && root.setAwgSummary)
				root.setAwgSummary(xui.parseAwgStatus(results[1]));
			if (results[2] && root.setProtocolsStatus)
				root.setProtocolsStatus(xui.parseProtocolsStatus(results[2]));
			if (results[3] && root.setDevicePolicyList)
				root.setDevicePolicyList(xui.parseDevicePolicyList(results[3]));
			if (root.setLoading)
				root.setLoading(false);
			root.setBusy(false);
			root.setMessage(_('Статус обновлён'), 'ok');
		}).catch(function(err) {
			if (root.setLoading)
				root.setLoading(false);
			root.setBusy(false);
			root.setMessage((err && err.message) ? err.message : String(err), 'bad');
		});
	},

	runVpnHubAction: function(action, arg, confirmText, mainEl, onDone) {
		var view = this;
		var root = (mainEl && mainEl.querySelector('[data-xfree-vpn]')) ||
			(mainEl && mainEl.querySelector('xfree-overview')) ||
			document.querySelector('[data-xfree-vpn]') ||
			document.querySelector('xfree-overview');
		var silent = typeof onDone === 'function';

		if (!root)
			return;

		var isAwgAction = action.indexOf('awg:') === 0 || [
			'serverApply', 'serverSetup', 'serverRecreateKeys', 'serverConfigureFirewall',
			'serverSetEndpoint', 'peerAdd', 'peerDelete', 'peerRecreateKeys',
			'peerShowConfig', 'peerFreeTurnConfig', 'peerUpdateEndpoint',
			'vkTurnStatus', 'vkTurnRestart', 'vkTurnStop', 'vkTurnSetup', 'vkTurnConfigureFirewall', 'vkTurnUpdate', 'vkTurnUninstall',
			'freeTurnStatus', 'freeTurnRestart', 'freeTurnStop', 'freeTurnSetup', 'freeTurnSetPort', 'freeTurnConfigureFirewall', 'freeTurnUpdate', 'freeTurnUninstall'
		].indexOf(action) !== -1;
		var awgAction = isAwgAction ? (action.indexOf('awg:') === 0 ? action.slice(4) : action) : '';

		function buildChain() {
			if (isAwgAction)
				return xui.runAwgMenu(awgAction, arg || '');
			if (action === 'warpSaveAndGenerate') {
				return xui.runIfaceMenu('warpSave', arg || '').then(function(res1) {
					return xui.runIfaceMenu('warpGenerate').then(function(res2) {
						return {
							code: (res2 && res2.code) || 0,
							stdout: [ xui.formatExecReport(res1), xui.formatExecReport(res2) ].join('\n\n'),
							stderr: ''
						};
					});
				});
			}
			if (action === 'protonSaveAndGenerate') {
				return xui.runIfaceMenu('protonSave', arg || '').then(function(res1) {
					return xui.runIfaceMenu('protonGenerate').then(function(res2) {
						return {
							code: (res2 && res2.code) || 0,
							stdout: [ xui.formatExecReport(res1), xui.formatExecReport(res2) ].join('\n\n'),
							stderr: ''
						};
					});
				});
			}
			return xui.runIfaceMenu(action, arg || '');
		}

		/* confShow / ifaceMeta / silent callbacks — без диалога */
		if (silent) {
			var confirmPromise = confirmText
				? (typeof confirmText === 'object' ? xui.confirm(confirmText) : xui.confirm({ message: confirmText, title: _('Подтверждение') }))
				: Promise.resolve(true);

			return confirmPromise.then(function(confirmed) {
				if (!confirmed)
					return;
				if (root.setBusy)
					root.setBusy(true);
				return buildChain().then(function(res) {
					if (root.setBusy)
						root.setBusy(false);
					onDone(res, xui.formatExecReport(res));
				}).catch(function(err) {
					if (root.setBusy)
						root.setBusy(false);
					onDone(null, (err && err.message) ? err.message : String(err));
				});
			});
		}

		view._xfreeVpnExecDlg = null;
		var awgTitles = {
			serverApply: _('Применение настроек VPN-сервера'),
			serverSetup: _('Первоначальная настройка VPN-сервера'),
			serverRecreateKeys: _('Пересоздание ключей сервера'),
			serverConfigureFirewall: _('Настройка Firewall для VPN-сервера'),
			serverSetEndpoint: _('Смена Default Endpoint сервера'),
			peerAdd: _('Добавление VPN-клиента'),
			peerDelete: _('Удаление VPN-клиента'),
			peerRecreateKeys: _('Пересоздание ключей клиента'),
			peerShowConfig: _('Конфигурация клиента'),
			peerFreeTurnConfig: _('FreeTurn конфигурация клиента'),
			peerUpdateEndpoint: _('Обновление Endpoint клиента'),
			vkTurnStatus: _('Статус VK-Turn прокси'),
			vkTurnRestart: _('Перезапуск VK-Turn прокси'),
			vkTurnStop: _('Остановка VK-Turn прокси'),
			vkTurnSetup: _('Настройка VK-Turn прокси'),
			vkTurnConfigureFirewall: _('Настройка Firewall для VK-Turn'),
			vkTurnUpdate: _('Обновление VK-Turn прокси'),
			vkTurnUninstall: _('Удаление VK-Turn прокси'),
			freeTurnStatus: _('Статус FreeTurn прокси'),
			freeTurnRestart: _('Перезапуск FreeTurn прокси'),
			freeTurnStop: _('Остановка FreeTurn прокси'),
			freeTurnSetup: _('Настройка FreeTurn прокси'),
			freeTurnSetPort: _('Смена порта FreeTurn прокси'),
			freeTurnConfigureFirewall: _('Настройка Firewall для FreeTurn'),
			freeTurnUpdate: _('Обновление FreeTurn прокси'),
			freeTurnUninstall: _('Удаление FreeTurn прокси')
		};
		var actionTitle = (isAwgAction && awgTitles[awgAction]) ? awgTitles[awgAction] : (
			action === 'warpTune'
				? _('⚡ Автоподбор параметров WARP')
				: (action === 'protonTune'
					? _('⚡ Автоподбор параметров Proton')
					: (action === 'protocolsInstall'
						? _('Установка компонентов протокола')
						: (action === 'protocolsRemove'
							? _('Удаление компонентов протокола')
							: (action === 'confDeleteUnused'
								? _('Удаление неиспользуемых конфигураций')
								: (action === 'confDelete' ? _('Удаление конфигурации') : _('VPN: %s').format(action || _('действие'))))))));
		return xui.runActionWithOutputDialog({
			title: actionTitle,
			confirm: confirmText || '',
			root: root,
			keepOpenOnBg: true,
			run: buildChain,
			onSuccess: function() {
				if (view._xfreeActiveRoute === 'vpn') {
					return view.reloadVpnHub(mainEl).catch(function() {
						if (root && root.setMessage)
							root.setMessage(
								_('Готово. Карточки не обновились — нажмите «Обновить статус»'),
								'warn'
							);
					});
				}
				return view.reloadOverview(mainEl);
			}
		}).then(function(wrap) {
			if (!wrap)
				return;
			if (wrap.running) {
				view._xfreeVpnExecDlg = wrap.dlg;
				if (root && root.setMessage)
					root.setMessage(_('Операция в фоне — лог обновляется'), 'ok');
				view.maybeStartVpnTaskPoll(mainEl);
				return;
			}
			if (!wrap.ok) {
				if (root && root.setMessage)
					root.setMessage(_('Команда завершилась с ошибкой'), 'bad');
			}
		});
	},

	stopVpnTaskPoll: function() {
		if (this._xfreeVpnTaskPoll) {
			poll.remove(this._xfreeVpnTaskPoll);
			this._xfreeVpnTaskPoll = null;
		}
		this._xfreeVpnTaskMain = null;
	},

	maybeStartVpnTaskPoll: function(mainEl) {
		var view = this;

		view.stopVpnTaskPoll();
		view._xfreeVpnTaskMain = mainEl || view.findMainEl();
		view._xfreeVpnTaskPoll = L.bind(function() {
			view.pollVpnTaskInPlace();
		}, view);
		poll.add(view._xfreeVpnTaskPoll, DEFAULT_INVOKE_POLL_SEC);
	},

	pollVpnTaskInPlace: function() {
		var view = this;
		var mainEl = view._xfreeVpnTaskMain || view.findMainEl();
		var root = mainEl && mainEl.querySelector('[data-xfree-vpn]');
		var dlg = view._xfreeVpnExecDlg;
		var lastExit;
		var text;

		if (!root)
			return view.stopVpnTaskPoll();

		return xui.runIfaceMenu('taskStatus').then(function(res) {
			text = xui.formatExecReport(res);
			root.setOutputText(text);
			if (dlg)
				dlg.setText(text);
			if (xui.ifaceTaskRunning(res)) {
				if (dlg)
					dlg.setStatus(_('Операция в фоне — лог обновляется…'));
				return;
			}

			view.stopVpnTaskPoll();
			root.setBusy(false);
			lastExit = xui.ifaceTaskLastExit(res);
			if (lastExit != null && lastExit !== 0) {
				root.setMessage(_('Фоновая задача завершилась с ошибкой (код %s)').format(lastExit), 'bad');
				if (dlg)
					dlg.setDone(false);
			} else {
				root.setMessage(_('Фоновая задача завершена'), 'ok');
				if (dlg)
					dlg.setDone(true);
			}
			view._xfreeVpnExecDlg = null;
			return view.reloadVpnHub(mainEl).catch(function() {
				root.setMessage(_('Готово — нажмите «Обновить статус» для карточек'), 'warn');
			});
		}).catch(function(err) {
			view.stopVpnTaskPoll();
			root.setBusy(false);
			if (dlg)
				dlg.setDone(false);
			view._xfreeVpnExecDlg = null;
			root.setMessage((err && err.message) ? err.message : String(err), 'bad');
		});
	},

	handleIfaceMenuItem: function(node, item, mainEl) {
		var view = this;
		var root;
		var arg;

		if (!item || !mainEl)
			return;

		root = mainEl.querySelector('[data-xfree-menu]') || mainEl.querySelector('[data-xfree-vpn]');
		if (!root)
			return;

		if (item.kind === 'note') {
			root.setOutputText(item.note || item.title || '');
			return;
		}

		if (item.action === 'configureMeshSatellite') {
			view.promptMeshSatelliteModal(root);
			return;
		}

		if (item.kind === 'panel' && item.panel) {
			view.navigate('vpn', '', item.panel);
			return;
		}

		arg = item.arg || '';
		if (item.prompt) {
			arg = window.prompt(item.promptText || item.prompt, arg || '');
			if (arg === null)
				return;
			arg = String(arg || '').trim();
			if (!arg) {
				root.setOutputText(_('Нужен аргумент: %s').format(item.promptText || item.prompt));
				return;
			}
		}

		return xui.runActionWithOutputDialog({
			title: item.title || item.action || _('VPN'),
			confirm: item.confirm || '',
			root: root,
			run: function() {
				return xui.runIfaceMenu(item.action, arg);
			},
			onSuccess: function() {
				if (node && node.statusReport === false)
					return;
				if (node.id === 'vpn.warp' && root.setStatusText) {
					return xui.runIfaceMenu('warpStatus').then(function(st) {
						root.setStatusText(xui.formatExecReport(st));
					});
				}
				if (node.id === 'vpn.proton' && root.setStatusText) {
					return xui.runIfaceMenu('protonStatus').then(function(st) {
						root.setStatusText(xui.formatExecReport(st));
					});
				}
			}
		});
	},

	renderZapret: function(data, mainEl) {
		var view = this;
		var st = (data && data.zapretStatus) || {
			running: false,
			installed: false,
			version: '',
			engine: 'zapret',
			pending: false,
			sections: []
		};
		var panel = xui.zapretPanel({
			view: view,
			expert: xui.menuExpertMode ? xui.menuExpertMode() : false,
			status: st,
			outputText: (data && data.outputText) || '',
			onRefresh: function() {
				view.reloadZapret(mainEl || view.findMainEl());
			},
			onNavigate: function(route, tab, panel) {
				view.navigate(route, tab || '', panel || '');
			},
			onAction: function(action, arg, confirmText) {
				view.runZapretAction(action, arg, confirmText, mainEl || view.findMainEl());
			}
		});

		return E('div', { 'class': 'xfree-page' }, [
			panel
		]);
	},

	reloadZapret: function(mainEl) {
		var root = mainEl && mainEl.querySelector('[data-xfree-zapret]');

		if (!root)
			return Promise.resolve();

		if (root.setLoading)
			root.setLoading(true);
		root.setBusy(true);
		return xui.runZapretMenu('status').then(function(res) {
			root.setStatus(xui.parseZapretStatus(res));
			if (root.setLoading)
				root.setLoading(false);
			root.setBusy(false);
			root.setMessage(_('Статус обновлён'), 'ok');
		}).catch(function(err) {
			if (root.setLoading)
				root.setLoading(false);
			root.setBusy(false);
			root.setMessage((err && err.message) ? err.message : String(err), 'bad');
		});
	},

	runZapretAction: function(action, arg, confirmText, mainEl) {
		var view = this;
		var root = (mainEl && mainEl.querySelector('[data-xfree-zapret]')) || document.querySelector('[data-xfree-zapret]');

		return xui.runActionWithOutputDialog({
			title: _('Zapret: %s').format(action || _('действие')),
			confirm: confirmText || '',
			root: root,
			menu: 'zapretMenu',
			run: function() {
				return xui.runZapretMenu(action, arg || '');
			},
			onSuccess: function() {
				return view.reloadZapret(mainEl || view.findMainEl());
			}
		});
	},

	renderTelemt: function(data, mainEl) {
		var view = this;
		var st = (data && data.telemtStatus) || {
			running: false,
			installed: false,
			coreInstalled: false,
			luciInstalled: false,
			port: '1443',
			secret: '',
			secretMasked: '',
			tgLink: ''
		};
		var panel = xui.telemtPanel({
			view: view,
			status: st,
			onRefresh: function() {
				view.reloadTelemt(mainEl || view.findMainEl(), false);
			},
			onCheckUpdates: function() {
				view.reloadTelemt(mainEl || view.findMainEl(), true);
			},
			onAction: function(action, arg, confirmText) {
				view.runTelemtAction(action, arg, confirmText, mainEl || view.findMainEl());
			}
		});

		return E('div', { 'class': 'xfree-page' }, [
			panel
		]);
	},

	reloadTelemt: function(mainEl, checkUpdates) {
		var root = mainEl && mainEl.querySelector('[data-xfree-telemt]');

		if (!root)
			return Promise.resolve();

		if (checkUpdates && root.setCheckingUpdates)
			root.setCheckingUpdates(true);
		else if (root.setLoading)
			root.setLoading(true);

		root.setBusy(true);
		var action = checkUpdates ? 'checkUpdate' : 'status';
		return xui.runTelemtMenu(action).then(function(res) {
			root.setStatus(xui.parseTelemtStatus(res));
			root.setBusy(false);
			root.setMessage(checkUpdates ? _('Проверка обновлений завершена') : _('Статус обновлён'), 'ok');
		}).catch(function(err) {
			if (root.setLoading)
				root.setLoading(false);
			if (root.setCheckingUpdates)
				root.setCheckingUpdates(false);
			root.setBusy(false);
			root.setMessage((err && err.message) ? err.message : String(err), 'bad');
		});
	},

	runTelemtAction: function(action, arg, confirmText, mainEl) {
		var view = this;
		var root = (mainEl && mainEl.querySelector('[data-xfree-telemt]')) || document.querySelector('[data-xfree-telemt]');

		var titleMap = {
			install: _('Установка Telemt MTProxy'),
			upgrade: _('Обновление Telemt MTProxy'),
			checkUpdate: _('Проверка обновлений Telemt'),
			service: _('Служба Telemt (%s)').format(arg || '')
		};

		return xui.runActionWithOutputDialog({
			title: titleMap[action] || _('Telemt: %s').format(action || _('действие')),
			confirm: confirmText || '',
			root: root,
			run: function() {
				return xui.runTelemtMenu(action, arg || '');
			},
			onSuccess: function() {
				return view.reloadTelemt(mainEl || view.findMainEl(), false);
			}
		});
	},

	stopTelemtPoll: function() {
		if (this._xfreeTelemtPoll) {
			poll.remove(this._xfreeTelemtPoll);
			this._xfreeTelemtPoll = null;
		}
		this._xfreeTelemtMain = null;
	},

	maybeStartTelemtPoll: function(mainEl) {
		var view = this;

		view.stopTelemtPoll();
		view._xfreeTelemtMain = mainEl || view.findMainEl();
		view._xfreeTelemtPoll = L.bind(function() {
			if (view._xfreeActiveRoute !== 'telemt')
				return view.stopTelemtPoll();

			var main = view._xfreeTelemtMain || view.findMainEl();
			var root = main && main.querySelector('[data-xfree-telemt]');
			if (!root)
				return view.stopTelemtPoll();

			if (root._busy || root._loading || root._checkingUpdates)
				return;

			return xui.runTelemtMenu('status').then(function(res) {
				if (root && root.setStatus && !root._busy)
					root.setStatus(xui.parseTelemtStatus(res));
			}).catch(function() {});
		}, view);
		poll.add(view._xfreeTelemtPoll, 5);
	},

	renderNetwork: function(data, mainEl) {
		var view = this;
		var panelId = data && (data.panelId || data.panel);
		if (!panelId) {
			panelId = 'network.mesh';
		}

		if (panelId === 'network.modem' || panelId === 'modem') {
			var modemPanel = networkModemPanel.render({
				data: data,
				view: view,
				onRefresh: function() {
					return view.reloadModemInPlace(mainEl || view.findMainEl());
				}
			});

			return E('div', { 'class': 'xfree-page' }, [
				view.renderPageHead(_('Сеть'), _('Mesh Wi-Fi, роуминг и 4G/LTE модемы')),
				view.renderSubnav('network', { panel: 'network.modem' }),
				E('div', { 'class': 'panel-block' }, [ modemPanel ])
			]);
		}

		var meshEl = E('xfree-mesh');
		meshEl.mount({
			view: view,
			status: (data && data.meshStatus) || {
				role: 'standalone',
				hasWpadMesh: false,
				hasMeshIf: false,
				stp: false
			},
			loading: !!(data && data.loading),
			busy: !!view._xfreeMeshBusy,
			onRefresh: function() {
				view.fetchRouteData(view._xfreeActiveRoute || 'network');
			},
			onAction: function(action, arg, confirmText) {
				if (action === 'configureMeshSatellite') {
					view.promptMeshSatelliteModal(meshEl);
					return;
				}

				return xui.runActionWithOutputDialog({
					title: _('Настройка беспроводной сети и Mesh'),
					confirm: confirmText || '',
					root: meshEl,
					menu: 'systemMenu',
					run: function() {
						return xui.runSystemMenu(action, arg);
					},
					onSuccess: function() {
						view.fetchRouteData(view._xfreeActiveRoute || 'network');
					}
				});
			}
		});

		return E('div', { 'class': 'xfree-page' }, [
			view.renderPageHead(_('Сеть'), _('Mesh Wi-Fi, роуминг и 4G/LTE модемы')),
			view.renderSubnav('network', { panel: 'network.mesh' }),
			E('div', { 'class': 'panel-block' }, [ meshEl ])
		]);
	},

	renderMesh: function(data, mainEl) {
		return this.renderNetwork(data, mainEl);
	},

	renderSystem: function(data, mainEl) {
		var view = this;
		var panelId = reportPanelId('system', {
			panel: data && (data.panelId || data.panel),
			tab: data && data.tab
		});

		var node = findPanel(panelId);
		var pollSec;
		var text;
		var panel;

		if (panelId === 'system.resources') {
			panel = systemResourcesPanel.render({
				data: data,
				view: view,
				xui: xui,
				onRefresh: function() {
					return view.reloadResourcesInPlace(mainEl || view.findMainEl());
				}
			});

			return E('div', { 'class': 'xfree-page' }, [
				view.renderPageHead(_('Система'), _('Ресурсы, версия и обновления')),
				view.renderSubnav('system', { panel: panelId }),
				E('div', { 'class': 'panel-block' }, [ panel ])
			]);
		}

		if (panelId === 'system.maintenance') {
			panel = systemMaintenancePanel.render({
				data: data,
				view: view,
				xui: xui,
				onRefresh: function() {
					return view.reloadMaintenanceInPlace(mainEl || view.findMainEl());
				}
			});

			return E('div', { 'class': 'xfree-page' }, [
				view.renderPageHead(_('Система'), _('Ресурсы, версия и обновления')),
				view.renderSubnav('system', { panel: panelId }),
				E('div', { 'class': 'panel-block' }, [ panel ])
			]);
		}

		if (panelId === 'system.toolbox') {
			panel = systemUpdatesPanel.render({
				data: data,
				view: view,
				xui: xui,
				onRefresh: function() {
					return view.reloadUpdatesInPlace(mainEl || view.findMainEl());
				}
			});

			return E('div', { 'class': 'xfree-page' }, [
				view.renderPageHead(_('Система'), _('Ресурсы, версия и обновления')),
				view.renderSubnav('system', { panel: panelId }),
				E('div', { 'class': 'panel-block' }, [ panel ])
			]);
		}

		if (panelId === 'system.hardware') {
			panel = systemHardwarePanel.render({
				data: data,
				view: view,
				xui: xui,
				onRefresh: function() {
					return view.reloadHardwareInPlace(mainEl || view.findMainEl());
				}
			});

			return E('div', { 'class': 'xfree-page' }, [
				view.renderPageHead(_('Система'), _('Ресурсы, версия и обновления')),
				view.renderSubnav('system', { panel: panelId }),
				E('div', { 'class': 'panel-block' }, [ panel ])
			]);
		}

		if (panelId === 'mgmt.status') {
			panel = systemMgmtPanel.render({
				data: data,
				view: view,
				xui: xui,
				onRefresh: function() {
					return view.reloadMgmtInPlace(mainEl || view.findMainEl());
				}
			});

			return E('div', { 'class': 'xfree-page' }, [
				view.renderPageHead(_('Система'), _('Ресурсы, версия и обновления')),
				view.renderSubnav('system', { panel: panelId }),
				E('div', { 'class': 'panel-block' }, [ panel ])
			]);
		}

		if (node && node.type === 'menu')
			return view.renderSystemMenu(node, data, mainEl, panelId);

		pollSec = (data && data.loading) ? 0 : view.reportPollInterval(node);
		text = (data && data.loading)
			? _('Загрузка отчёта…')
			: xui.formatExecReport(data && data.execResult);
		panel = xui.reportPanel(node.title, text, view, function() {
			view.reloadReportInPlace(node, mainEl || view.findMainEl());
		}, pollSec);

		if (pollSec > 0 && mainEl) {
			view._xfreeReportNode = node;
			view._xfreeReportMain = mainEl;
			view._xfreeReportPoll = L.bind(function() {
				view.reloadReportInPlace(node, mainEl);
			}, view);
			poll.add(view._xfreeReportPoll, pollSec);
		}

		return E('div', { 'class': 'xfree-page' }, [
			view.renderPageHead(_('Система'), _('Ресурсы, версия и обновления')),
			view.renderSubnav('system', { panel: panelId }),
			E('div', { 'class': 'panel-block' }, [ panel ])
		]);
	},

	renderSystemMenu: function(node, data, mainEl, panelId) {
		var view = this;
		var statusText = node.statusReport
			? xui.formatExecReport(data && data.menuStatus)
			: '';
		var panel = xui.menuPanel({
			node: node,
			view: view,
			statusText: statusText,
			outputText: (data && data.outputText) || '',
			pollSec: 0,
			itemVisible: function(item) {
				return xui.menuItemVisible(item);
			},
			onItem: function(item) {
				view.handleSystemMenuItem(node, item, mainEl || view.findMainEl());
			}
		});

		return E('div', { 'class': 'xfree-page' }, [
			view.renderPageHead(_('Система'), _('Ресурсы, версия и обновления')),
			view.renderSubnav('system', { panel: panelId }),
			E('div', { 'class': 'panel-block' }, [ panel ])
		]);
	},

	handleSystemMenuItem: function(node, item, mainEl) {
		var view = this;
		var root;

		if (!item || !mainEl)
			return;

		root = mainEl.querySelector('[data-xfree-menu]');
		if (!root)
			return;

		if (item.kind === 'note') {
			root.setOutputText(item.note || item.title || '');
			return;
		}

		if (item.action === 'configureMeshSatellite') {
			view.promptMeshSatelliteModal(root);
			return;
		}

		if (item.kind === 'report') {
			return xui.runActionWithOutputDialog({
				title: item.title || _('Отчёт'),
				root: root,
				run: function() {
					return xui.loadNamedReport(item.report || node.statusReport);
				},
				onSuccess: function(res) {
					if (root.setStatusText && node.statusReport)
						root.setStatusText(xui.formatExecReport(res));
				}
			});
		}

		return xui.runActionWithOutputDialog({
			title: item.title || item.action || _('Система'),
			confirm: item.confirm || '',
			root: root,
			menu: 'systemMenu',
			run: function() {
				return xui.runSystemMenu(item.action, item.arg);
			},
			onSuccess: function() {
				if (!node.statusReport)
					return;
				return xui.loadNamedReport(node.statusReport).then(function(st) {
					if (root.setStatusText)
						root.setStatusText(xui.formatExecReport(st));
				});
			}
		});
	},

	renderDiagnostics: function(data, mainEl) {
		var view = this;
		var panelId = reportPanelId('diagnostics', {
			panel: data && (data.panelId || data.panel),
			tab: data && data.tab
		});
		var node = findPanel(panelId);
		var pollSec;
		var text;
		var panel;

		if (node && node.type === 'uplink')
			return view.renderUplinkDashboard(node, data, mainEl, panelId);

		if (node && node.type === 'menu')
			return view.renderDiagnosticsMenu(node, data, mainEl, panelId);

		pollSec = (data && data.loading) ? 0 : view.reportPollInterval(node);
		text = (data && data.loading)
			? _('Загрузка отчёта…')
			: xui.formatExecReport(data && data.execResult);
		panel = xui.reportPanel(node.title, text, view, function() {
			view.reloadReportInPlace(node, mainEl || view.findMainEl());
		}, pollSec, node.descr);

		if (pollSec > 0 && mainEl) {
			view._xfreeReportNode = node;
			view._xfreeReportMain = mainEl;
			view._xfreeReportPoll = L.bind(function() {
				view.reloadReportInPlace(node, mainEl);
			}, view);
			poll.add(view._xfreeReportPoll, pollSec);
		}

		/* Resume live tail if a background DNS (etc.) job is already running. */
		if (node && node.asyncReport && mainEl)
			view.maybeStartAsyncReportPoll(node, mainEl, text);

		return E('div', { 'class': 'xfree-page' }, [
			view.renderPageHead(_('Диагностика'), _('Канал, туннели, DNS')),
			view.renderSubnav('diagnostics', { panel: panelId }),
			E('div', { 'class': 'panel-block' }, [ panel ])
		]);
	},

	renderUplinkDashboard: function(node, data, mainEl, panelId) {
		var view = this;
		var cfg = (data && data.uplinkConfig) || {};
		var pollSec = view.reportPollInterval(node);
		var panel = xui.uplinkPanel({
			view: view,
			loading: !!(data && data.loading),
			settings: cfg.settings || {},
			runtime: cfg.runtime || {},
			outputText: (data && data.outputText) || '',
			message: cfg.code && cfg.code !== 0 ? (cfg.stderr || _('Ошибка загрузки')) : '',
			expert: xui.menuExpertMode(),
			onSave: function() {
				view.saveUplinkFromPanel(mainEl || view.findMainEl());
			},
			onRefresh: function() {
				view.reloadUplinkConfigInPlace(mainEl || view.findMainEl());
			},
			onAction: function(action, arg, confirmText) {
				view.runUplinkActionFromPanel(action, arg, confirmText, mainEl || view.findMainEl());
			}
		});

		if (pollSec > 0 && mainEl) {
			view._xfreeReportNode = node;
			view._xfreeReportMain = mainEl;
			view._xfreeReportPoll = L.bind(function() {
				view.reloadUplinkConfigInPlace(mainEl);
			}, view);
			poll.add(view._xfreeReportPoll, pollSec);
		}

		return E('div', { 'class': 'xfree-page' }, [
			view.renderPageHead(_('Диагностика'), _('Канал, туннели, DNS')),
			view.renderSubnav('diagnostics', { panel: panelId }),
			E('div', { 'class': 'panel-block' }, [ panel ])
		]);
	},

	reloadUplinkConfigInPlace: function(mainEl) {
		var root = mainEl && mainEl.querySelector('[data-xfree-uplink]');

		if (root && root.setLoading)
			root.setLoading(true);
		if (root && root.setBusy)
			root.setBusy(true);

		return xui.loadUplinkConfig().then(function(cfg) {
			if (root && root.setConfig)
				root.setConfig(cfg.settings || {}, cfg.runtime || {});
			if (root && root.setLoading)
				root.setLoading(false);
			if (root && root.setBusy)
				root.setBusy(false);
			if (root && root.setMessage && cfg.code && cfg.code !== 0)
				root.setMessage(cfg.stderr || _('Ошибка'), 'bad');
		}).catch(function(err) {
			if (root && root.setLoading)
				root.setLoading(false);
			if (root && root.setBusy)
				root.setBusy(false);
			if (root && root.setMessage)
				root.setMessage((err && err.message) ? err.message : String(err), 'bad');
		});
	},

	saveUplinkFromPanel: function(mainEl) {
		var view = this;
		var root = mainEl && mainEl.querySelector('[data-xfree-uplink]');
		var settings;

		if (!root || !root.collectSettings)
			return;

		settings = root.collectSettings();
		root.setBusy(true);
		root.setMessage(_('Сохранение…'), '');
		return xui.saveUplinkConfig(settings).then(function(res) {
			root.setBusy(false);
			if (res && res.code === 0) {
				root.setMessage(_('Сохранено'), 'ok');
				return view.reloadUplinkConfigInPlace(mainEl);
			}
			root.setMessage((res && res.stderr) || _('Ошибка сохранения'), 'bad');
		}).catch(function(err) {
			root.setBusy(false);
			root.setMessage((err && err.message) ? err.message : String(err), 'bad');
		});
	},

	runUplinkActionFromPanel: function(action, arg, confirmText, mainEl) {
		var view = this;
		var root = mainEl && mainEl.querySelector('[data-xfree-uplink]');

		if (!root)
			return;

		return xui.runActionWithOutputDialog({
			title: _('Диагностика: %s').format(action || _('действие')),
			confirm: confirmText || '',
			root: root,
			run: function() {
				return xui.runUplinkMenu(action, arg);
			},
			onSuccess: function() {
				return view.reloadUplinkConfigInPlace(mainEl);
			}
		});
	},

	renderDiagnosticsMenu: function(node, data, mainEl, panelId) {
		var view = this;
		var pollSec = view.reportPollInterval(node);
		var statusText = node.statusReport
			? xui.formatExecReport(data && data.menuStatus)
			: '';
		var panel = xui.menuPanel({
			node: node,
			view: view,
			statusText: statusText,
			outputText: (data && data.outputText) || '',
			pollSec: pollSec,
			itemVisible: function(item) {
				return xui.menuItemVisible(item);
			},
			onItem: function(item) {
				view.handleDiagnosticsMenuItem(node, item, mainEl || view.findMainEl());
			}
		});

		if (pollSec > 0 && mainEl && node.statusReport) {
			view._xfreeReportNode = node;
			view._xfreeReportMain = mainEl;
			view._xfreeReportPoll = L.bind(function() {
				view.reloadMenuStatusInPlace(node, mainEl);
			}, view);
			poll.add(view._xfreeReportPoll, pollSec);
		}

		return E('div', { 'class': 'xfree-page' }, [
			view.renderPageHead(_('Диагностика'), _('Канал, DNS, системные тесты')),
			view.renderSubnav('diagnostics', { panel: panelId }),
			E('div', { 'class': 'panel-block' }, [ panel ])
		]);
	},

	handleDiagnosticsMenuItem: function(node, item, mainEl) {
		var view = this;
		var root;

		if (!item || !mainEl)
			return;

		root = mainEl.querySelector('[data-xfree-menu]');
		if (!root)
			return;

		if (item.kind === 'note') {
			root.setOutputText(item.note || item.title || '');
			return;
		}

		if (item.action === 'configureMeshSatellite') {
			view.promptMeshSatelliteModal(root);
			return;
		}

		return xui.runActionWithOutputDialog({
			title: item.title || item.action || _('Диагностика'),
			confirm: item.confirm || '',
			root: root,
			menu: (item.api === 'systemMenu' || ['telemtStatus', 'telemtInstall', 'vkturnStatus', 'vkturnSetup'].indexOf(item.action) >= 0) ? 'systemMenu' : 'uplinkMenu',
			run: function() {
				if (item.kind === 'report')
					return xui.loadNamedReport(item.report || item.id);
				if (item.api === 'systemMenu' || ['telemtStatus', 'telemtInstall', 'vkturnStatus', 'vkturnSetup'].indexOf(item.action) >= 0)
					return xui.runSystemMenu(item.action, item.arg);
				return xui.runUplinkMenu(item.action, item.arg);
			},
			onSuccess: function() {
				if (node.statusReport && (item.kind === 'action' || item.report === node.statusReport))
					return view.reloadMenuStatusInPlace(node, mainEl);
			}
		});
	},

	reloadMenuStatusInPlace: function(node, mainEl) {
		var root;

		if (!node || !node.statusReport || !mainEl)
			return Promise.resolve();

		root = mainEl.querySelector('[data-xfree-menu]');
		return xui.loadNamedReport(node.statusReport).then(function(res) {
			if (root && root.setStatusText)
				root.setStatusText(xui.formatExecReport(res));
		}).catch(function(err) {
			if (root && root.setStatusText)
				root.setStatusText(xui.formatExecReport({
					code: 1,
					stdout: '',
					stderr: (err && err.message) ? err.message : String(err)
				}));
		});
	},

	reportOutputRunning: function(text) {
		return /^STATUS:\s*running\b/m.test(String(text || ''));
	},

	stopAsyncReportPoll: function() {
		if (this._xfreeAsyncReportPoll) {
			poll.remove(this._xfreeAsyncReportPoll);
			this._xfreeAsyncReportPoll = null;
		}
		this._xfreeAsyncReportNode = null;
		this._xfreeAsyncReportMain = null;
	},

	maybeStartAsyncReportPoll: function(node, mainEl, text) {
		var view = this;

		view.stopAsyncReportPoll();
		if (!node || !node.asyncReport || !node.reportStatus || !mainEl)
			return;
		if (!view.reportOutputRunning(text))
			return;

		view._xfreeAsyncReportNode = node;
		view._xfreeAsyncReportMain = mainEl;
		view._xfreeAsyncReportPoll = L.bind(function() {
			view.pollAsyncReportInPlace();
		}, view);
		poll.add(view._xfreeAsyncReportPoll, DEFAULT_INVOKE_POLL_SEC);
	},

	pollAsyncReportInPlace: function() {
		var view = this;
		var node = view._xfreeAsyncReportNode;
		var mainEl = view._xfreeAsyncReportMain || view.findMainEl();
		var name;

		if (!node || !node.reportStatus)
			return view.stopAsyncReportPoll();

		name = node.reportStatus;
		return xui.loadNamedReport(name).then(function(res) {
			var text = xui.formatExecReport(res);

			xui.setConsoleText(mainEl, text);
			if (!view.reportOutputRunning(text))
				view.stopAsyncReportPoll();
		}).catch(function(err) {
			xui.setConsoleText(mainEl, xui.formatExecReport({
				code: 1,
				stdout: '',
				stderr: (err && err.message) ? err.message : String(err)
			}));
			view.stopAsyncReportPoll();
		});
	},

	reloadResourcesInPlace: function(mainEl) {
		var view = this;
		var node = findPanel('system.resources');
		return Promise.all([
			xui.loadReport(node).catch(function(err) {
				return { code: 1, stdout: '', stderr: (err && err.message) ? err.message : String(err) };
			}),
			xui.systemInfo ? xui.systemInfo() : Promise.resolve(null),
			xui.systemBoard ? xui.systemBoard() : Promise.resolve(null)
		]).then(function(parts) {
			var data = {
				routeId: 'system',
				panelId: 'system.resources',
				execResult: parts[0],
				sysInfo: parts[1],
				boardInfo: parts[2]
			};
			var container = mainEl ? mainEl.querySelector('.xfree-resources-container') : null;
			if (container && container.parentNode) {
				var newPanel = systemResourcesPanel.render({
					data: data,
					view: view,
					xui: xui,
					onRefresh: function() {
						return view.reloadResourcesInPlace(mainEl);
					}
				});
				container.parentNode.replaceChild(newPanel, container);
			} else {
				view.renderRoute('system', { panel: 'system.resources' }, mainEl);
			}
		});
	},

	reloadUpdatesInPlace: function(mainEl) {
		var view = this;
		return xui.runSystemMenu('autoUpdateStatus').then(function(res) {
			var data = {
				routeId: 'system',
				panelId: 'system.toolbox',
				execResult: res
			};
			var container = mainEl ? mainEl.querySelector('.xfree-system-updates-panel') : null;
			if (container && container.parentNode) {
				var newPanel = systemUpdatesPanel.render({
					data: data,
					view: view,
					xui: xui,
					onRefresh: function() {
						return view.reloadUpdatesInPlace(mainEl);
					}
				});
				container.parentNode.replaceChild(newPanel, container);
			} else {
				view.renderRoute('system', { panel: 'system.toolbox' }, mainEl);
			}
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ _('Ошибка обновления статуса: ') + (err.message || String(err)) ]), 'error');
		});
	},

	reloadMaintenanceInPlace: function(mainEl) {
		var view = this;
		return xui.runSystemMenu('maintenanceStatus').then(function(res) {
			var data = {
				routeId: 'system',
				panelId: 'system.maintenance',
				execResult: res
			};
			var container = mainEl ? mainEl.querySelector('.xfree-system-maintenance-panel') : null;
			if (container && container.parentNode) {
				var newPanel = systemMaintenancePanel.render({
					data: data,
					view: view,
					xui: xui,
					onRefresh: function() {
						return view.reloadMaintenanceInPlace(mainEl);
					}
				});
				container.parentNode.replaceChild(newPanel, container);
			} else {
				view.renderRoute('system', { panel: 'system.maintenance' }, mainEl);
			}
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
		});
	},

	reloadHardwareInPlace: function(mainEl) {
		var view = this;
		return xui.runSystemMenu('hardwareStatus').then(function(res) {
			var data = {
				routeId: 'system',
				panelId: 'system.hardware',
				execResult: res
			};
			var container = mainEl ? mainEl.querySelector('.xfree-dashboard-wrap') : null;
			if (container && container.parentNode) {
				var newPanel = systemHardwarePanel.render({
					data: data,
					view: view,
					xui: xui,
					onRefresh: function() {
						return view.reloadHardwareInPlace(mainEl);
					}
				});
				container.parentNode.replaceChild(newPanel, container);
			} else {
				view.renderRoute('system', { panel: 'system.hardware' }, mainEl);
			}
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
		});
	},

	reloadMgmtInPlace: function(mainEl) {
		var view = this;
		return xui.runSystemMenu('mgmtStatus').then(function(res) {
			var data = {
				routeId: 'system',
				panelId: 'mgmt.status',
				execResult: res
			};
			var container = mainEl ? mainEl.querySelector('.xfree-system-mgmt-panel') : null;
			if (container && container.parentNode) {
				var newPanel = systemMgmtPanel.render({
					data: data,
					view: view,
					xui: xui,
					onRefresh: function() {
						return view.reloadMgmtInPlace(mainEl);
					}
				});
				container.parentNode.replaceChild(newPanel, container);
			} else {
				view.renderRoute('system', { panel: 'mgmt.status' }, mainEl);
			}
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ _('Ошибка обновления: ') + (err.message || String(err)) ]), 'error');
		});
	},

	reloadModemInPlace: function(mainEl) {
		var view = this;
		return xui.runSystemMenu('modemDiag').then(function(res) {
			var data = {
				routeId: 'network',
				panelId: 'network.modem',
				execResult: res
			};
			var container = mainEl ? mainEl.querySelector('.xfree-dashboard-wrap') : null;
			if (container && container.parentNode) {
				var newPanel = networkModemPanel.render({
					data: data,
					view: view,
					xui: xui,
					onRefresh: function() {
						return view.reloadModemInPlace(mainEl);
					}
				});
				container.parentNode.replaceChild(newPanel, container);
			} else {
				view.renderRoute('network', { panel: 'network.modem' }, mainEl);
			}
		}).catch(function(err) {
			ui.addNotification(null, E('p', {}, [ _('Ошибка обновления статуса модема: ') + (err.message || String(err)) ]), 'error');
		});
	},

	reloadReportInPlace: function(node, mainEl) {
		var view = this;

		view.stopAsyncReportPoll();
		return xui.loadReport(node).then(function(res) {
			var text = xui.formatExecReport(res);

			xui.setConsoleText(mainEl, text);
			if (node && node.id === 'system.toolbox')
				view.updateRailBrand(view.parseToolboxStatus(res));
			if (node && node.asyncReport)
				view.maybeStartAsyncReportPoll(node, mainEl, text);
		}).catch(function(err) {
			xui.setConsoleText(mainEl, xui.formatExecReport({
				code: 1,
				stdout: '',
				stderr: (err && err.message) ? err.message : String(err)
			}));
		});
	},

	maybeStartInvokePoll: function(node, mainEl, status) {
		var view = this;

		view.stopInvokePoll();

		if (!status || !status.running || !mainEl)
			return;

		view._xfreeInvokeNode = node;
		view._xfreeInvokeMain = mainEl;
		view._xfreeInvokePoll = L.bind(function() {
			view.reloadInvokeInPlace(node, { keepValues: true, poll: true });
		}, view);
		poll.add(view._xfreeInvokePoll, DEFAULT_INVOKE_POLL_SEC);
	},

	updateInvokeOutput: function(mainEl, status) {
		var root;

		if (!mainEl)
			return;

		xui.setConsoleText(mainEl, xui.formatInvokeOutput(status));
		root = mainEl.querySelector('[data-xfree-invoke]');

		if (root) {
			root.querySelectorAll('button').forEach(function(btn) {
				btn.disabled = !!status.running;
			});
		}
	},

	reloadInvokeInPlace: function(node, opts) {
		var view = this;
		var mainEl = view._xfreeInvokeMain || view.findMainEl();

		opts = opts || {};

		return xui.loadInvoke(node, view).then(function(inv) {
			if (opts.keepValues)
				inv.values = view._xfreeInvokeValues || inv.values || {};

			view._xfreeInvokeStatus = inv.status || {};

			if (opts.poll && mainEl) {
				view.updateInvokeOutput(mainEl, inv.status);
				if (!inv.status || !inv.status.running) {
					view.stopInvokePoll();
					view.mountRoute({
						routeId: 'profiles',
						panelId: node.id,
						invoke: inv
					});
				}
				return inv;
			}

			view.mountRoute({
				routeId: 'profiles',
				panelId: node.id,
				invoke: inv
			});
			return inv;
		}).catch(function(err) {
			var status = {
				code: 1,
				running: 0,
				stderr: (err && err.message) ? err.message : String(err),
				stdout: ''
			};

			view._xfreeInvokeStatus = status;
			if (opts.poll && mainEl)
				view.updateInvokeOutput(mainEl, status);
		});
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
